from bson import ObjectId

from portal.shared.dates import get_utcnow
from portal.testing.faker import DocumentFaker


class AccountApprovalFaker(DocumentFaker):

    def custom_levels(self, quantity):
        return [
            self._generate_level(i)
            for i in range(1, quantity + 1)
        ]

    def _generate_document(self, i):
        now = get_utcnow()
        return {
            '_id': ObjectId(),
            'levels': [
                {
                    'approver': {
                        '_id': ObjectId(),
                        '_type': 'user',
                        'name': f'user{i+2}',
                        'username': f'username{i+2}@example.com'
                    },
                    'amount': i + 2
                }, {
                    'approver': {
                        '_id': ObjectId(),
                        '_type': 'user',
                        'name': f'user{i}',
                        'username': f'username{i}@example.com'
                    },
                    'amount': i
                }, {
                    'approver': {
                        '_id': ObjectId(),
                        '_type': 'user',
                        'name': f'user{i+1}',
                        'username': f'username{i+1}@example.com'
                    },
                    'amount': i + 1
                }
            ],
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now
        }

    def _generate_level(self, i):
        return {
            'approver': {
                '_id': ObjectId(),
                '_type': 'level',
                'username': f'user{i}@example.com'
            },
            'amount': i
        }
