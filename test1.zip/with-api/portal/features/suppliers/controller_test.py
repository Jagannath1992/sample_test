import pytest
from bson import ObjectId
from flask import request
import io

from portal.conftest import get_account_id_from_header, get_user_from_header
from portal.features.suppliers.schema import SupplierResponse, SupplierSearchResponse, SupplierInviteRequest, SupplierInviteResponse
from portal.shared.enums import AccountType, UserRole, AccountStatus
from portal.shared.repositories import account_repository, user_repository
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.enums import UserRole, AccountType
from portal.shared.repositories import account_approval_repository, account_repository, instance_settings_repository, user_repository
from portal.shared.services import auth_service, flag_service


class TestSupplierssResource:
    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get(self, client, custom_auth_header, mocker, fakers):
        # arrange
        count = 3
        procurement_account = fakers.account.generate_single({'type': AccountType.PROCUREMENT.value})
        supplier_accounts = fakers.account.generate_many(
            count, {'type': AccountType.SUPPLIER.value, 'instance._id': procurement_account['instance']['_id']})
        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        mocker.patch.object(account_repository(), 'get_page', return_value=(count, supplier_accounts))

        results = []
        for i in range(len(supplier_accounts)):
            user = fakers.user.insert_single({'accountId': supplier_accounts[i]['_id']})
            results.append({'account': supplier_accounts[i], 'user': user})

        account_id = get_account_id_from_header(custom_auth_header)
        query_params = {
            'accountId': account_id,
            'orderBy': 'id',
            'offset': 0,
            'count': 10
        }

        # act
        response = client.get('/suppliers', query_string=query_params, headers=custom_auth_header)
        expected = SupplierSearchResponse().dump({
            'totalCount': count,
            'results': results
        })
        # assert
        assert response.status_code == 200
        assert response.json['results'] == expected['results']

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get_wrong_account_type(self, client, custom_auth_header, mocker, fakers):
        # arrange
        account = fakers.account.generate_single({'type': AccountType.DEFAULT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=account)

        account_id = get_account_id_from_header(custom_auth_header)
        query_params = {
            'accountId': account_id,
            'orderBy': 'id',
            'offset': 0,
            'count': 10
        }

        # act
        response = client.get('/suppliers', query_string=query_params, headers=custom_auth_header)

        # assert
        assert response.status_code == 403
        assert response.json['message'] == 'You do not have permission to access this resource'

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get_403(self, client, custom_auth_header, mocker, fakers):
        # arrange
        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10
        }

        # act
        response = client.get('/suppliers', query_string=query_params, headers=custom_auth_header)

        # assert
        assert response.status_code == 403
        assert response.json['message'] == 'You do not have permission to access this resource'


class TestRegistration:
    @pytest.fixture()
    def post_init(self, mocker, fakers):
        mocker.patch.object(flag_service(), 'validate_domains', return_value=True)
        mocker.patch.object(user_repository(), 'domain_exists', return_value=False)
        mocker.patch.object(account_repository(), 'company_exists', return_value=False)

        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(instance_settings_repository(), 'patch', return_value=instance)

        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'insert', return_value=account)
        mocker.patch.object(account_approval_repository(), 'insert')

        procurment = fakers.account.generate_single({'type': AccountType.PROCUREMENT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=procurment)

        user = fakers.user.generate_single()
        mocker.patch.object(auth_service(), 'create_user', return_value=user)

        return account, user, instance, procurment

    @pytest.fixture()
    def post_request_json(self, post_init, custom_auth_header, fakers, mocker):
        account_id = get_account_id_from_header(custom_auth_header)
        account, user, _, _ = post_init
        return SupplierInviteRequest().dump({
            'accountId': account_id,
            'suppliers':
            [{'user': user,
              'account': account}]
        })

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_post_200(self, custom_auth_header, client, post_init,  post_request_json):
        # arrange
        account, user, instance, procurment = post_init
        caller_user = get_user_from_header(custom_auth_header)
        expected_response = {'suppliers': [{'user': user, 'message': 'Success'}]}
        expected_account = {
            **SupplierInviteRequest().load(post_request_json)['suppliers'][0]['account'],
            'type': AccountType.SUPPLIER.value,
            'instance': {
                '_id': instance['_id'],
                '_type': 'instance_settings',
                'name': instance['name']
            }
        }

        expected_account['invitedBy'] = {
            '_id': procurment['_id'],
            '_type': 'account',
            'name': procurment['company']['name']
        }

        with client:
            # act
            response = client.post("/suppliers/invite", json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single.assert_called_once_with(request.user['accountId'])
            instance_settings_repository().get_single.assert_called_once_with(procurment['instance']['_id'])
            flag_service().validate_domains.assert_called_once()
            user_repository().domain_exists.assert_called_once_with(user['username'])
            account_repository().company_exists.assert_called_once_with(account['company']['name'])
            account_repository().insert.assert_called_once_with(expected_account, caller_user['username'])
            account_approval_repository().insert.assert_called_once_with(
                {'_id': account['_id'], 'levels': []},  caller_user['username'])
            auth_service().create_user.assert_called_once_with(
                request.parsed_obj['suppliers'][0]['user'],
                account['_id'],
                'An error occurred while attempting to create the account',
                caller_user['username'])
            assert response.status_code == 200
            assert response.json == SupplierInviteResponse().dump(expected_response)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_post_missing_instance(self, custom_auth_header, client, mocker, fakers):
        # arrange
        account_id = get_account_id_from_header(custom_auth_header)
        account = fakers.account.generate_single()
        user = fakers.user.generate_single()
        procurement_account = fakers.account.generate_single({'type': AccountType.PROCUREMENT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=(procurement_account))
        post_request_json = SupplierInviteRequest().dump({
            'accountId': account_id,
            'suppliers':
            [{'user': user,
              'account': account}]
        })

        with client:
            # act
            response = client.post("/suppliers/invite", json=post_request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 404
            assert response.json['message'] == "Instance not found"

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_post_account_type(self, custom_auth_header, client, mocker, fakers, post_init, post_request_json):
        # arrange
        _, _, _, _ = post_init
        account = fakers.account.generate_single({'type': AccountType.DEFAULT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=account)

        with client:
            # act
            response = client.post("/suppliers/invite", json=post_request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json['message'] == "You do not have permission to access this resource"

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_post_account_number_mismatch(self, custom_auth_header, post_init, client):
        # arrange
        account, user, _, _ = post_init
        post_request_json = SupplierInviteRequest().dump({
            'accountId': account['_id'],
            'suppliers':
            [{'user': user,
              'account': account}]
        })

        with client:
            # act
            response = client.post("/suppliers/invite", json=post_request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json['message'] == "You do not have permission to access this resource"

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_post_user_403(self, custom_auth_header, client, post_request_json):
        # arrange

        with client:
            # act
            response = client.post("/suppliers/invite", json=post_request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json['message'] == "You do not have permission to access this resource"

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_post_duplicate_account(self, custom_auth_header, client, post_init, post_request_json):
        # arrange
        user_repository().domain_exists.return_value = True
        _, user, instance, _ = post_init

        with client:
            # act
            response = client.post('/suppliers/invite', json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single.assert_called_once_with(request.user['accountId'])
            instance_settings_repository().get_single_by_filter({'_id': instance['_id']})
            flag_service().validate_domains()
            user_repository().domain_exists(user['username'])
            account_repository().company_exists.assert_not_called()
            account_repository().insert.assert_not_called()
            account_approval_repository().insert.assert_not_called()
            auth_service().create_user.assert_not_called()
            assert response.status_code == 200
            assert response.json['suppliers'][0]['message'] == 'An account already exists for this company'

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_post_duplicate_company(self, custom_auth_header, client, post_init, post_request_json):
        # arrange
        account_repository().company_exists.return_value = True
        _, user, instance, _ = post_init

        with client:
            # act
            response = client.post('/suppliers/invite', json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single.assert_called_once_with(request.user['accountId'])
            instance_settings_repository().get_single_by_filter({'_id': instance['_id']})
            flag_service().validate_domains()
            user_repository().domain_exists(user['username'])
            account_repository().company_exists()
            account_repository().insert.assert_not_called()
            account_approval_repository().insert.assert_not_called()
            auth_service().create_user.assert_not_called()
            assert response.status_code == 200
            assert response.json['suppliers'][0]['message'] == 'An account already exists for this company'

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_post_username_exist(self, custom_auth_header, client, mocker, post_init, post_request_json):
        # arrange
        mocker.patch.object(user_repository(), 'username_exists', return_value=False)
        user_repository().username_exists.return_value = True
        _, user, instance, _ = post_init

        with client:
            # act
            response = client.post('/suppliers/invite', json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single(request.user['accountId'])
            instance_settings_repository().get_single_by_filter({'_id': instance['_id']})
            flag_service().validate_domains()
            user_repository().domain_exists(user['username'])
            account_repository().company_exists()
            account_repository().insert.assert_not_called()
            account_approval_repository().insert.assert_not_called()
            auth_service().create_user.assert_not_called()
            assert response.status_code == 400
            assert response.json['schema_errors']['suppliers']['0']['user']['username'] == ['Username must be unique']

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_put_200(self, custom_auth_header, client):
        # arrange
        data = {"file": (io.BytesIO(b'firstName,Lastname \n user_first,user_last \n user_first2,user_last2'), "test.csv")}

        # act
        response = client.put("/suppliers/invite",  headers=custom_auth_header, data=data, content_type="multipart/form-data")

        # assert
        assert response.status_code == 200
        assert response.json['columns'] == [
            ['firstName', ' user_first', ' user_first2'],
            ['Lastname ', 'user_last ', 'user_last2']]

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_put_403(self, custom_auth_header, client):
        # arrange
        data = {"file": (io.BytesIO(b'firstName,Lastname \n user_first,user_last \n user_first2,user_last2'), "test.csv")}

        # act
        response = client.put("/suppliers/invite",  headers=custom_auth_header, data=data, content_type="multipart/form-data")

        # assert
        assert response.status_code == 403

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_put_400(self, custom_auth_header, client):
        # arrange
        data = {"file": ""}

        # act
        response = client.put("/suppliers/invite",  headers=custom_auth_header, data=data, content_type="multipart/form-data")

        # assert
        assert response.status_code == 400
        assert response.json['message'] == 'No file was provided'

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_put_415_bad_ext(self, custom_auth_header, client):
        # arrange
        data = {"file": (io.BytesIO(b'firstName,Lastname \n user_first,user_last \n user_first2,user_last2'), "test.txt")}

        # act
        response = client.put("/suppliers/invite",  headers=custom_auth_header, data=data, content_type="multipart/form-data")

        # assert
        assert response.status_code == 415
        assert response.json['message'] == 'The server does not support the media type transmitted in the request.'

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_put_415_no_ext(self, custom_auth_header, client):
        # arrange
        data = {"file": (io.BytesIO(b'firstName,Lastname \n user_first,user_last \n user_first2,user_last2'), "test")}

        # act
        response = client.put("/suppliers/invite",  headers=custom_auth_header, data=data, content_type="multipart/form-data")

        # assert
        assert response.status_code == 415
        assert response.json['message'] == 'The server does not support the media type transmitted in the request.'


class TestSupplierByIdResource:
    @pytest.fixture()
    def post_init(self, mocker, fakers, custom_auth_header):
        request_user = get_user_from_header(custom_auth_header)
        procurement_account = fakers.account.generate_single({
            '_id': request_user['accountId'],
            'type': AccountType.PROCUREMENT.value,
        })
        supplier_accounts = fakers.account.generate_many(1, {
            'instance._id': procurement_account['instance']['_id'],
            'type': AccountType.SUPPLIER.value,
        })

        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        mocker.patch.object(account_repository(), 'get_single_by_filter', return_value=supplier_accounts[0])
        mocker.patch.object(account_repository(), 'patch', return_value=supplier_accounts[0])

        user = fakers.user.insert_single({'accountId': supplier_accounts[0]['_id']})
        mocker.patch.object(user_repository(), 'get_single_by_filter', return_value=user)

        return procurement_account, supplier_accounts, user

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, supplier_accounts, user = post_init
        query_params = {'accountId': procurement_account['_id']}

        # act
        response = client.get(f'/suppliers/{ObjectId()}', query_string=query_params, headers=custom_auth_header)
        expected = SupplierResponse().dump({'account': supplier_accounts[0], 'user': user})

        # assert
        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get_403(self, client, custom_auth_header):
        # act
        response = client.get(f'/suppliers/{ObjectId()}', headers=custom_auth_header)

        # act
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get_with_account_id(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, supplier_accounts, user = post_init
        query_params = {'accountId': procurement_account['_id']}

        # act
        response = client.get(f'/suppliers/{ObjectId()}', query_string=query_params, headers=custom_auth_header)
        expected = SupplierResponse().dump({'account': supplier_accounts[0], 'user': user})

        # assert
        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize('custom_auth_header', GIVEWITH_ROLES, indirect=True)
    def test_get_without_account_id_givewith(self, client, post_init, custom_auth_header):
        # arrange
        _, _, _ = post_init

        # act
        response = client.get(f'/suppliers/{ObjectId()}', headers=custom_auth_header)

        # assert
        assert response.status_code == 400
        assert response.json == {'message': 'accountId is required'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_get_without_account_id_org_admin(self, client, post_init, custom_auth_header):
        # arrange
        _, supplier_accounts, user = post_init

        # act
        response = client.get(f'/suppliers/{ObjectId()}', headers=custom_auth_header)
        expected = SupplierResponse().dump({'account': supplier_accounts[0], 'user': user})

        # assert
        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_get_403(self, client, custom_auth_header):
        # act
        response = client.get(f'/suppliers/{ObjectId()}', headers=custom_auth_header)

        # act
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_get_404(self, fakers, mocker, client, givewith_header):
        # arrange
        procurement_account = fakers.account.generate_single({'type': AccountType.PROCUREMENT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        query_params = {'accountId': procurement_account['_id']}

        # act
        response = client.get(f'/suppliers/{ObjectId()}', query_string=query_params, headers=givewith_header)

        # assert
        assert response.status_code == 404

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_patch(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, supplier_accounts, _ = post_init
        query_params = {'accountId': procurement_account['_id']}
        supplier_accounts[0]['status'] = AccountStatus.LOCKED.value
        user = get_user_from_header(custom_auth_header)
        request = {
            'accountId': procurement_account['_id'],
            'status': supplier_accounts[0]['status']
        }
        update = {
            'status': supplier_accounts[0]['status']
        }
        expected = SupplierResponse().dump({'account': supplier_accounts[0], 'user': None})

        # act
        response = client.patch(f'/suppliers/{ObjectId()}', json=request, query_string=query_params, headers=custom_auth_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected
        account_repository().patch.assert_called_once_with(supplier_accounts[0]['_id'], update, user['username'])

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_patch(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, supplier_accounts, _ = post_init
        query_params = {'accountId': procurement_account['_id']}
        supplier_accounts[0]['status'] = AccountStatus.LOCKED.value
        request = {
            'accountId': procurement_account['_id'],
            'status': supplier_accounts[0]['status']
        }

        # act
        response = client.patch(f'/suppliers/{ObjectId()}', json=request, query_string=query_params, headers=custom_auth_header)

        # assert
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}
        account_repository().patch.assert_not_called()

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_delete(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, supplier_accounts, _ = post_init
        query_params = {'accountId': procurement_account['_id']}
        supplier_accounts[0]['status'] = AccountStatus.INACTIVE.value
        user = get_user_from_header(custom_auth_header)
        update = {
            'status': supplier_accounts[0]['status']
        }
        expected = SupplierResponse().dump({'account': supplier_accounts[0], 'user': None})

        # act
        response = client.delete(f'/suppliers/{ObjectId()}', query_string=query_params, headers=custom_auth_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected
        account_repository().patch.assert_called_once_with(supplier_accounts[0]['_id'], update, user['username'])

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_delete_403(self, client, custom_auth_header):
        # act
        response = client.delete(f'/suppliers/{ObjectId()}', headers=custom_auth_header)

        # act
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_delete_404(self, fakers, mocker, client, givewith_header):
        # arrange
        procurement_account = fakers.account.generate_single({'type': AccountType.PROCUREMENT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        query_params = {'accountId': procurement_account['_id']}

        # act
        response = client.delete(f'/suppliers/{ObjectId()}', query_string=query_params, headers=givewith_header)

        # assert
        assert response.status_code == 404


class TestReinviteSupplierById:
    @pytest.fixture()
    def post_init(self, mocker, fakers, custom_auth_header):
        request_user = get_user_from_header(custom_auth_header)
        procurement_account = fakers.account.generate_single({
            '_id': request_user['accountId'],
            'type': AccountType.PROCUREMENT.value
        })
        supplier_accounts = fakers.account.generate_many(1, {
            'instance._id': procurement_account['instance']['_id'],
            'type': AccountType.SUPPLIER.value,
        })

        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        mocker.patch.object(account_repository(), 'get_single_by_filter', return_value=supplier_accounts[0])

        user = fakers.user.generate_single({'accountId': supplier_accounts[0]['_id']})
        mocker.patch.object(user_repository(), 'get_single_by_filter', return_value=user)
        mocker.patch.object(auth_service(), 'resend_user_invite')

        return procurement_account, supplier_accounts, user

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole if r in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_post_200(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, _, _ = post_init
        json = {
            'accountId': procurement_account['_id'],
            'username': 'test@test.com'
        }

        # act
        response = client.post(f'/suppliers/{ObjectId()}/resend-invite', json=json, headers=custom_auth_header)

        # assert
        assert response.status_code == 200

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN]], indirect=True)
    def test_post_403(self, client, custom_auth_header):
        # act
        response = client.post(f'/suppliers/{ObjectId()}/resend-invite', headers=custom_auth_header)

        # act
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_post_404(self, fakers, mocker, client, givewith_header):
        # arrange
        procurement_account = fakers.account.generate_single({'type': AccountType.PROCUREMENT.value})
        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        json = {
            'accountId': procurement_account['_id'],
            'username': 'test@test.com'
        }

        # act
        response = client.post(f'/suppliers/{ObjectId()}/resend-invite', json=json, headers=givewith_header)

        # assert
        assert response.status_code == 404


class TestSupplierAppSettingsByID:
    @pytest.fixture()
    def post_init(self, mocker, fakers, custom_auth_header):
        request_user = get_user_from_header(custom_auth_header)
        procurement_account = fakers.account.generate_single({
            '_id': request_user['accountId'],
            'type': AccountType.PROCUREMENT.value
        })
        supplier_account = fakers.account.generate_single({
            'instance._id': procurement_account['instance']['_id'],
            'type': AccountType.SUPPLIER.value,
        })

        supplier_account['invitedBy'] = {'_id': procurement_account['_id']}

        mocker.patch.object(account_repository(), 'get_single', return_value=procurement_account)
        mocker.patch.object(account_repository(), 'get_single_by_filter', return_value=supplier_account)

        return procurement_account, supplier_account

    @pytest.mark.parametrize('custom_auth_header', [ r for r in UserRole], indirect=True)
    def test_get_200(self, client, post_init, custom_auth_header):
        # arrange
        procurement_account, supplier_account = post_init
        query_params = {
            'accountId': procurement_account['_id'],
            'username': 'test@test.com'
        }

        excepted = {
            'id': str(supplier_account['_id']),
            'giveFields': supplier_account.get('giveFields', {})
        }

        # act
        response = client.get(f'/suppliers/{supplier_account["_id"]}/app-settings',
                              query_string=query_params, headers=custom_auth_header)
        # assert
        assert response.status_code == 200
        assert response.json == excepted
