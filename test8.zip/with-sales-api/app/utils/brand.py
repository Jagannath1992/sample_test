from app.db.utils import get_document

def get_brand_topic_labels_with_industry_fallback(brand, limit=None):
    """Retrives brand topic labels
    Falls backs to brand's industry topics if topics aren't available
    """
    brand_topics = brand.get('topics')
    if not brand_topics:
        topics_by_industry = get_document('topics_per_industry', {'industry_name': brand.get('industry')})
        brand_topics = topics_by_industry['topics'] if topics_by_industry else []

    topics = [topic.get('label', '') for topic in brand_topics if topic.get('score', 0) > 0]
    return topics[:limit]
