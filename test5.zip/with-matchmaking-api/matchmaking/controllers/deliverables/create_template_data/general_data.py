from ....mongodb import get_vocabulary_v2
from .utils import clean
from ....utils import send_loggly, get_descendant_key

def make_general_data(useful_data, master_data):
    make_social(useful_data, master_data)
    make_primary_impact(useful_data, master_data)
    make_program_data(useful_data)
    make_nonprofit_data(useful_data, master_data)


def make_social(useful_data, master_data):
    social_media_data = [
        {
            'type': 'facebook',
            'fieldname': 'NONPROFIT_FACEBOOK_HANDLE',
        },
        {
            'type': 'twitter',
            'fieldname': 'NONPROFIT_TWITTER_HANDLE',
        },
        {
            'type': 'linkedIn',
            'fieldname': 'NONPROFIT_LINKEDIN_HANDLE',
        },
        {
            'type': 'instagram',
            'fieldname': 'NONPROFIT_INSTAGRAM_HANDLE',
        },
    ]

    social_list = list()
    show_social = dict()

    for social in social_media_data:
        if (__extract_social(social['type'], social['fieldname'], social_list, master_data, useful_data)):
            show_social[social['type']] = 1

    useful_data['SHOW_SOCIAL_SECTION'] = show_social
    if len(social_list) > 0:
        useful_data['SOCIAL'] = social_list


def __extract_social(network_name, useful_key, social_list, master_data, useful_data):
    network = get_descendant_key(master_data, 'nonprofit.general.social.' + network_name, '')

    if network != '':
        social_list = __add_social_handle(social_list, network_name.capitalize(), network)
        useful_data[useful_key] = network
        return True
    else:
        useful_data[useful_key] = '**ERROR NO DATA FOR ' + network_name.upper() + ' HANDLE**'
        return False


def __add_social_handle(social_list, social_type, social_url):
    social_url = social_url.strip()
    if len(social_url) > 0:
        social_list.append(social_type + ' ' + social_url)
    return social_list


def make_primary_impact(useful_data, master_data):
    pff_primary_impact = get_descendant_key(master_data, 'pff.ImpactAndScope.primaryImpact.value.selected', None)

    primary_impact = 'n/a'
    primary_impact_document = get_vocabulary_v2(pff_primary_impact[0])

    if not primary_impact_document.empty:
        primary_impact = primary_impact_document['label']

    clean_primary_impact = clean(primary_impact)

    useful_data['PRIMARY_IMPACT'] = clean_primary_impact
    useful_data['PRIMARY_IMPACT_LOWERCASE'] = clean_primary_impact[0].lower() + clean_primary_impact[1:]


def make_program_data(useful_data):
    make_program_description(useful_data)
    make_program_short_description(useful_data)


def make_program_description(useful_data):
    program_description_list = useful_data['PROGRAM_DESCRIPTION'].split('.')
    program_description_list.pop()  # get rid of last (will be empty)

    useful_data['PROGRAM_DESCRIPTION_LIST'] = [program_description.strip() + '.' for program_description in program_description_list]


def make_program_short_description(useful_data):
    try:
        first_period = useful_data['PROGRAM_DESCRIPTION'].index('.')
        useful_data['PROGRAM_DESCRIPTION_SHORT'] = clean(useful_data['PROGRAM_DESCRIPTION'][0:first_period + 1])
    except Exception as e:
        useful_data['PROGRAM_DESCRIPTION_SHORT'] = useful_data['PROGRAM_DESCRIPTION']


def make_nonprofit_data(useful_data, master_data):
    make_nonprofit_description(useful_data)
    make_nonprofit_impacts(useful_data, master_data)
    make_program_impacts(useful_data, master_data)


def make_nonprofit_description(useful_data):
    # do a similar treatment to the nonprofit description
    desc_list = useful_data['NONPROFIT_DESCRIPTION'].split('.')
    desc_list.pop()  # get rid of the last one

    useful_data['NONPROFIT_DESCRIPTION_LIST'] = [d_item.strip() + '.' for d_item in desc_list]


START = 'START'
END = 'END'
def make_nonprofit_impacts(useful_data, master_data):
    npo_impacts = list()
    lifetime_outputs = get_descendant_key(master_data, 'nonprofit.overviewAndMission.lifetimeOutputs', [])

    for output in lifetime_outputs:
        output_quantity = str(output['quantity']).strip()

        (output_quantity, symbol_position, symbol) = __remove_and_store_symbol(output_quantity)
        npo_num = __round_quantity(output_quantity)

        if npo_num > 0:
            npo_message = __create_output_fragment(npo_num, symbol_position, symbol, output)
            npo_impacts.append(npo_message)

    useful_data['NPO_IMPACTS'] = npo_impacts


def __remove_and_store_symbol(output_quantity):
    '''
    Strip quantity of currency symbol of percentage and store for later
    '''
    symbol_position = ''
    symbol = ''

    if output_quantity[0] in ['$', '£', '€']:
        symbol_position = START
        symbol = output_quantity[0]
        output_quantity = float(output_quantity[1:])
    elif output_quantity[-1] == '%':
        symbol_position = END
        symbol = output_quantity[-1]
        output_quantity = float(output_quantity[:-1])
    else:
        output_quantity = float(output_quantity)

    return (output_quantity, symbol_position, symbol)


def __round_quantity(output_quantity):
    '''
    If output_quantity < 0, keep value.
    If output_quantity > 0 and has a decimal value, round to whole number
    '''
    output_quantity = float(output_quantity)

    npo_num_mod = output_quantity % 1.0

    if npo_num_mod > 0 and output_quantity < 1.0:
        npo_num = output_quantity
    else:
        npo_num = round(output_quantity)

    return npo_num


def __create_output_fragment(npo_num, symbol_position, symbol, output):
    npo_value = clean(str(f'{npo_num:,}'))

    if symbol_position == START:
        final_npo_value = symbol + npo_value
    elif symbol_position == END:
        final_npo_value = npo_value + symbol
    else:
        final_npo_value = npo_value

    return final_npo_value + ' ' + output['output']


def make_program_impacts(useful_data, master_data):
    try:
        program_outputs = list()
        program_output = ''

        for (count, impact) in enumerate(master_data['pff']['objects']):
            quantity = int(impact['quantity'])

            if quantity > 0:
                verb = impact.get('verb', '').strip()
                quantity_with_commas = str(format(quantity, ',d'))

                if quantity > 1:
                    output_fragment = '{verb} {quantity} {target}'.format(verb=verb, quantity=quantity_with_commas, target=impact['targetPlural'].rstrip())
                    program_outputs.append(output_fragment)
                else:
                    output_fragment = '{verb} {quantity} {target}'.format(verb=verb, quantity=quantity_with_commas, target=impact['targetSingular'].rstrip())
                    program_outputs.append(output_fragment)

            ending = ''
            if count < len(master_data['pff']['objects']) - 2:
                ending = ', '
            elif count == len(master_data['pff']['objects']) - 2:
                ending = ' and '

            program_output = program_output + output_fragment + ending

        useful_data['PROGRAM_OUTPUTS'] = program_outputs

        clean_program_output = clean(program_output)
        useful_data['PROGRAM_OUTPUTS_SINGLE_LINE'] = clean_program_output
    except Exception as e:
        useful_data['PROGRAM_OUTPUTS'] = ['**ERROR: MISSING PROGRAM OUTPUTS**']
        useful_data['PROGRAM_OUTPUTS_SINGLE_LINE'] = '**ERROR: ' + str(e) + ' MISSING PROGRAM OUTPUTS**'
        send_loggly(e)
