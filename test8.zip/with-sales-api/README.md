# Givewith Sales API (#tigerteam)

This repo contains the API service powering givewith-sales-ui. It uses [Flask-RESTful](https://flask-restful.readthedocs.io/).

## Local setup
- Run `python -m venv venv` to create a [virtual env](https://docs.python.org/3/library/venv.html) (NOTE: Optional? I dunno, this is how I typically run Python apps locally, so you do you.)
- Run `source venv/bin/activate` to activate the virtual env
- Run `pip install` to install necessary dependencies
- Run `./runnit.sh` to run the server at `http://localhost:5010`

🐅🐅🐅
