# pylint: disable-msg=invalid-name,too-many-arguments,too-many-instance-attributes
# pylint: disable-msg=len-as-condition,too-many-nested-blocks,consider-using-get
import json
import statistics
import datetime
import os
import requests
import boto
from boto.s3.key import Key

REPONAME = 'MMAPI'


def upload_to_s3(aws_access_key_id,
                 aws_secret_access_key,
                 file,
                 bucket,
                 key,
                 callback=None,
                 md5=None,
                 reduced_redundancy=False,
                 content_type=None):
    """
    Uploads the given file to the AWS S3
    bucket and key specified.

    callback is a function of the form:

    def callback(complete, total)

    The callback should accept two integer parameters,
    the first representing the number of bytes that
    have been successfully transmitted to S3 and the
    second representing the size of the to be transmitted
    object.

    Returns boolean indicating success/failure of upload.
    """
    try:
        size = os.fstat(file.fileno()).st_size
    except Exception as ex:
        # Not all file objects implement fileno(),
        # so we fall back on this
        file.seek(0, os.SEEK_END)
        size = file.tell()
        print(ex)

    conn = boto.connect_s3(aws_access_key_id, aws_secret_access_key)
    bucket = conn.get_bucket(bucket, validate=True)
    k = Key(bucket)
    k.key = key
    if content_type:
        k.set_metadata('Content-Type', content_type)
    sent = k.set_contents_from_file(file, cb=callback, md5=md5, reduced_redundancy=reduced_redundancy, rewind=True)

    # Rewind for later use
    file.seek(0)

    if sent == size:
        return True
    return False

def send_data(name, value):
    return requests.post('http://logs-01.loggly.com/inputs/9ab7cbe1-4576-422d-8a3d-dd7267c9f80e/tag/http/', json={
        'timestamp': '2017-11-19T20:00:00.00Z',
        name: value,
    })

class FileInfo:
    def __init__(self, path):
        self.path = path
        self.lints = list()
        self.total_error = 0
        self.total_warning = 0
        self.total_convention = 0
        self.total_refactor = 0
        self.total_info = 0
        self.rank = 100
        self.complexity_avg = 0
        self.complexity_median = 0
        self.component = list()
        self.total_pylint_issues = 9

    def add_complexity(self, component_complexity):
        self.component.append(component_complexity)

    def add_pylint(self, message_id):
        self.lints.append(message_id)

    def set_rank(self, rank):
        self.rank = rank

    def total(self):
        self.total_pylint_issues = len(self.lints)
        for x in self.lints:
            c = x[0:1]
            if c == 'E':
                self.total_error += 1
            elif c == 'W':
                self.total_warning += 1
            elif c == 'C':
                self.total_convention += 1
            elif c == 'R':
                self.total_refactor += 1
            elif c == 'I':
                self.total_info += 1
        complexity = list()
        for cc in self.component:
            complexity.append(cc.complexity)
        if len(self.component) > 0:
            self.complexity_avg = statistics.mean(complexity)
            self.complexity_median = statistics.median(complexity)

class ComponentComplexity:
    def __init__(self, name, xtype, rank, complexity):
        self.name = name
        self.type = xtype
        self.rank = rank
        self.complexity = complexity


## PYLINT JSON OUTPUT
def read_pylint_json(file_info):
    pylint_totals = dict()
    with open('pylint.json', 'r') as read_file:
        pylint = json.load(read_file)

    for lint in pylint:
        path = lint['path']
        linttype = lint['type']
        message = lint['message-id']

        if path not in file_info:
            file_info[path] = FileInfo(path)
        file_info[path].add_pylint(message)

        if linttype in pylint_totals:
            pylint_totals[linttype] = pylint_totals[linttype] + 1
        else:
            pylint_totals[linttype] = 1
    return pylint_totals


## PYLINT text output for score
def read_pylint_text():
    score = 0.0
    with open('pylint_score.txt', 'r') as read_file:
        score = read_file.readlines()
    found_it = False
    for s in score:
        try:
            if s.index('Your code has been rated at') > -1:
                s_words = s.split()
                for word in s_words:
                    if not found_it:
                        try:
                            if word.index('/10') > -1:
                                score = float(word[0:word.index('/10')])
                                found_it = True
                        except Exception as exception:
                            print(exception)
        except ValueError as v:
            print(v)
    return score


## RADON OUTPUT
def read_radon_json(file_info):
    with open('radon_mi.json', 'r') as read_file:
        radon_mi = json.load(read_file)

    for a in radon_mi:
        if a not in file_info:
            file_info[a] = FileInfo(a)
        file_info[a].set_rank(radon_mi[a]['mi'])

    with open('radon_cc.json', 'r') as read_file:
        radon_cc = json.load(read_file)

    for c in radon_cc:
        if c not in file_info:
            file_info[c] = FileInfo(c)
        for t in radon_cc[c]:
            name = t['name']
            xtype = t['type']
            rank = t['rank']
            complexity = t['complexity']
            file_info[c].add_complexity(ComponentComplexity(name, xtype, rank, complexity))

    return file_info


def calculate_and_write_results():
    # DATA OUTPUT
    rank_count = 0
    rank_sum = 0
    complexity_count = 0
    complexity_sum = 0

    file_info = dict()
    pylint_totals = read_pylint_json(file_info)
    score = read_pylint_text()
    file_info = read_radon_json(file_info)

    for f in file_info:
        file_info[f].total()  # need to do this to count up the data it gathered
        rank_count += 1
        rank_sum = rank_sum + file_info[f].rank
        complexity_count += 1
        complexity_sum = complexity_sum + file_info[f].complexity_avg

    f = open('/tmp/' + REPONAME + '_parse.txt', 'w')
    now = datetime.datetime.now()
    snow = now.strftime('%Y-%m-%d %H:%M:%S')
    print('\n\n')
    print('REPO-LEVEL METRICS')
    # repo-level scores
    pylint_types = {'error', 'warning', 'convention', 'refactor', 'info'}
    for d in pylint_types:
        total = 0
        if d in pylint_totals:
            total = pylint_totals[d]
        print(snow + '\t' + REPONAME + '.LINT.' + d.upper() + '\t' + str(total))
        send_data(REPONAME + '.LINT.' + d.upper(), total)
        f.write(snow + '\t' + REPONAME + '.LINT.' + d.upper() + '\t' + str(total))
        f.write('\n')
    print(snow + '\t' + REPONAME + '.MAINTAINABILITY\t' + str(round(rank_sum/rank_count, 2)))
    f.write(snow + '\t' + REPONAME + '.MAINTAINABILITY\t' + str(round(rank_sum/rank_count, 2)))
    send_data(REPONAME + '.MAINTAINABILITY', round(rank_sum/rank_count, 2))
    print(snow + '\t' + REPONAME + '.COMPLEXITY\t' + str(round(complexity_sum/complexity_count, 2)))
    f.write(snow + '\t' + REPONAME + '.COMPLEXITY\t' + str(round(complexity_sum/complexity_count, 2)))
    send_data(REPONAME + '.COMPLEXITY', round(complexity_sum/complexity_count, 2))
    print(snow + '\t' + REPONAME + '.LINT.SCORE\t' + str(round(score, 2)))
    f.write(snow + '\t' + REPONAME + '.LINT.SCORE\t' + str(round(score, 2)))
    send_data(REPONAME + '.LINT.SCORE', round(score, 2))
    f.close()

    return snow


def send_to_s3(snow):
    AWS_ACCESS_KEY = os.environ.get('staging_aws_access_key_id', 'NO KEY FOUND')
    AWS_ACCESS_SECRET_KEY = os.environ.get('staging_aws_secret_key', 'NO SECRET KEY FOUND')
    if AWS_ACCESS_KEY == 'NO KEY FOUND' or AWS_ACCESS_SECRET_KEY == 'NO SECRET KEY FOUND':
        print('\n[[no keys to upload to s3]]')
    else:
        file = open('/tmp/' + REPONAME + '_parse.txt', 'r+')
        key = REPONAME + '_' + snow.replace(' ', '_')
        bucket = 'repo-static-analysis-logs'
        if upload_to_s3(AWS_ACCESS_KEY, AWS_ACCESS_SECRET_KEY, file, bucket, key):
            print('Upload worked!')


ts = calculate_and_write_results()
send_to_s3(ts)
