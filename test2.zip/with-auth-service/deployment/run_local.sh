cd /home/ec2-user/deployment
chmod 755 *.sh
./beforeinstall.sh
touch /home/ec2-user/.bashrc
cd /home/ec2-user/
pip3 install -r requirements.txt

FLASK_DEBUG=1 FLASK_ENV=docker FLASK_APP=main.py flask run -p 5000 --host=0.0.0.0
