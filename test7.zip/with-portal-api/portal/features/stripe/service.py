import os
import stripe

from stripe.error import StripeError
from typing import List

from portal.features.stripe.enums import StripeCheckoutSessionMode, StripePaymentMethodType, StripeSetupIntentAction, StripeSubscriptionStatus
from portal.shared.dates import get_utc_date_from_timestamp
from portal.shared.enums import AccountStatus, ErrorLogSourceType, AccountType, InstanceType
from portal.shared.errors import ExternalError, GivewithError, GivewithException


class StripeService:
    def __init__(self, config: dict):
        stripe.api_key = os.environ.get('STRIPE_API_KEY')
        self.webhook_secret = config['webhook_secret']
        self.success_url = config['success_url']
        self.cancel_url = config['cancel_url']

    def get_stripe_setting_type(self, instance_type, account_type):
        stripe_setting = 'prices'
        if instance_type == InstanceType.PROCUREMENT.value and account_type == AccountType.SUPPLIER.value:
            stripe_setting = 'suppliers'
        return stripe_setting

    def create_customer(self, email, name) -> stripe.Customer:
        args = {
            'name': name,
            'email': email,
        }
        try:
            customer = stripe.Customer.create(**args)
            return customer
        except StripeError as err:
            raise GivewithException(
                'Error creating Stripe customer',
                [ExternalError(err.http_status, f"{err.user_message}; {err.code}")],
                ErrorLogSourceType.STRIPE.value)

    def create_subscription(self, instance, customer_id, frequency, account_type):
        stripe_setting = self.get_stripe_setting_type(instance['type'], account_type)
        price_id = instance['settings']['stripe'][stripe_setting][frequency]['id']
        args = {
            'customer': customer_id,
            'items': [{
                'price': price_id,
                'quantity': 1
            }]
        }
        try:
            subscription = stripe.Subscription.create(**args)
            return subscription
        except StripeError as err:
            raise GivewithException(
                "Error creating Stripe subscription",
                [ExternalError(err.http_status, f"{err.user_message}; {err.code}")],
                ErrorLogSourceType.STRIPE.value)

    def update_subscription_frequency(self, instance, subscription_id, current_frequency, new_frequency, account_type):
        stripe_setting = self.get_stripe_setting_type(instance['type'], account_type)
        price_id = instance['settings']['stripe'][stripe_setting][new_frequency]['id']
        subscription = stripe.Subscription.retrieve(subscription_id)
        subscription_status = subscription['status']
        account_update = {'stripe': {'subscription': {}}}
        updated_subscription = None
        if new_frequency == current_frequency:
            if subscription_status == StripeSubscriptionStatus.ACTIVE.value and subscription['cancel_at_period_end'] == True:
                updated_subscription = stripe.Subscription.modify(subscription_id, cancel_at_period_end=False)
                account_update['stripe']['subscription']['newFrequencyAtPeriodEnd'] = None
        elif subscription_status == StripeSubscriptionStatus.TRIALING.value:  # Subscription fee hasn't been charged yet
            updated_subscription = stripe.Subscription.modify(
                subscription_id,
                items=[{
                    'id': subscription['items']['data'][0]['id'],
                    'price': price_id
                }]
            )
            account_update['subscriptionFrequency'] = new_frequency
        # Subscription fee has been charged
        elif subscription_status == StripeSubscriptionStatus.ACTIVE.value:
            updated_subscription = stripe.Subscription.modify(subscription_id, cancel_at_period_end=True)
            account_update['stripe']['subscription']['newFrequencyAtPeriodEnd'] = new_frequency

        if updated_subscription:
            account_update['stripe']['subscription'].update({
                'canceledAt': get_utc_date_from_timestamp(updated_subscription['canceled_at']),
                'cancelAt': get_utc_date_from_timestamp(updated_subscription['cancel_at']),
                'currentPeriodStart': get_utc_date_from_timestamp(updated_subscription['current_period_start']),
                'currentPeriodEnd': get_utc_date_from_timestamp(updated_subscription['current_period_end'])
            })
            return account_update

    def cancel_subscription(self, subscription_id):
        subscription = stripe.Subscription.retrieve(subscription_id)
        account_update = {'stripe': {'subscription': {}}}
        subscription_status = subscription['status']
        if subscription_status == StripeSubscriptionStatus.ACTIVE.value:
            updated_subscription = stripe.Subscription.modify(subscription_id, cancel_at_period_end=True)
            account_update['stripe']['subscription'] = {
                'canceledAt': get_utc_date_from_timestamp(updated_subscription['canceled_at']),
                'cancelAt': get_utc_date_from_timestamp(updated_subscription['cancel_at']),
                'currentPeriodStart': get_utc_date_from_timestamp(updated_subscription['current_period_start']),
                'currentPeriodEnd': get_utc_date_from_timestamp(updated_subscription['current_period_end']),
                'newFrequencyAtPeriodEnd': None
            }
        else:
            stripe.Subscription.delete(subscription_id)
            account_update['status'] = AccountStatus.PENDING_STRIPE.value
        return account_update

    def update_customer(self, stripe_customer_id, givewith_account_id, sage_customer_id):
        customer = stripe.Customer.modify(
            stripe_customer_id,
            metadata={
                'givewithAccountId': str(givewith_account_id),
                'sageCustomerId': sage_customer_id
            })
        return customer

    def create_subscription_checkout_session(
            self, instance, frequency, trial_period_used, account_type, customer_id=None, success_url=None, cancel_url=None):
        stripe_setting = self.get_stripe_setting_type(instance['type'], account_type)
        price_id = instance['settings']['stripe'][stripe_setting][frequency]['id']
        portal_url = instance['settings']['portalUrl']
        args = {
            'success_url': success_url if success_url else f'{portal_url}{self.success_url}',
            'cancel_url': cancel_url if cancel_url else f'{portal_url}{self.cancel_url}',
            'mode': StripeCheckoutSessionMode.SUBSCRIPTION.value,
            'line_items': [{
                'price': price_id,
                'quantity': 1
            }]
        }
        if customer_id:
            args['customer'] = customer_id
        if not trial_period_used:
            trial_days = int(instance['settings']['stripe']['trialPeriodDays'])

            if trial_days > 0:
                args.update({'subscription_data': {
                    'trial_period_days': trial_days
                }
                })
            else:
                args.update({
                    'subscription_data': {}
                })

        session = stripe.checkout.Session.create(**args)
        return session

    def create_setup_checkout_session(self, stripe_customer_id, currency, success_url, cancel_url, action_type):
        payment_method_types = self.get_payment_method_types(currency)
        args = {
            'mode': StripeCheckoutSessionMode.SETUP.value,
            'customer': stripe_customer_id,
            'success_url': success_url,
            'cancel_url': cancel_url,
            'payment_method_types': payment_method_types,
            'setup_intent_data': {
                'metadata': {
                    'action': action_type
                }
            }
        }
        session = stripe.checkout.Session.create(**args)
        return session

    def create_payment_intent(self, instance, stripe_customer_id, payment_method_id, amount, order_id, currency, give_id):
        payment_method_types = self.get_payment_method_types(currency)
        factor = instance['settings']['stripe'].get('currencyFactor', 1)
        amount = int(amount / factor)
        args = {
            'customer': stripe_customer_id,
            'payment_method': payment_method_id,
            'amount': amount,
            'currency': currency.lower(),
            'payment_method_types': payment_method_types,
            'off_session': True,
            'confirm': True,
            'statement_descriptor': f'GIVEWITH* Ref: {give_id}',  # Max length 22 characters
            'metadata': {
                'orderId': order_id
            }
        }
        try:
            return stripe.PaymentIntent.create(**args)
        except StripeError as err:
            raise GivewithException(
                "Error creating Stripe payment intent",
                [ExternalError(err.http_status, f"{err.user_message}; {err.code}")],
                ErrorLogSourceType.STRIPE.value)

    def create_order_setup_checkout_session(self, stripe_customer_id, currency, success_url, cancel_url, order_ids):
        payment_method_types = self.get_payment_method_types(currency)
        args = {
            'mode': StripeCheckoutSessionMode.SETUP.value,
            'customer': stripe_customer_id,
            'success_url': success_url,
            'cancel_url': cancel_url,
            'payment_method_types': payment_method_types,
            'setup_intent_data': {
                'metadata': {
                    'action': StripeSetupIntentAction.COMPLETE_ORDERS.value,
                    'orderIds': ','.join(order_ids)
                }
            }
        }
        session = stripe.checkout.Session.create(**args)
        return session

    def get_checkout_session(self, checkout_session_id):
        try:
            return stripe.checkout.Session.retrieve(checkout_session_id)
        except:
            return None

    def create_customer_portal_session(self, stripe_customer_id):
        session = stripe.billing_portal.Session.create(customer=stripe_customer_id)
        return session

    def get_payment_method_types(self, currency: str) -> List[str]:
        payment_methods_types = [StripePaymentMethodType.CARD.value]

        if currency == 'USD':
            payment_methods_types.append(StripePaymentMethodType.US_BANK_ACCOUNT.value)
        # elif currency == 'GBP':
        #    payment_methods_types.append(StripePaymentMethodType.UK_BANK_DEBIT.value)

        return payment_methods_types

    # Integration Testing / POC

    def _delete_customer(self, stripe_customer_id):
        stripe.Customer.delete(stripe_customer_id)

    def _webhook_received(self, signature, data):
        event = stripe.Webhook.construct_event(payload=data, sig_header=signature, secret=self.webhook_secret)
        data = event.data
        event_type = event['type']
        data_object = data['object']

    def _create_payment_intent(self, amount, currency, customer_id, payment_method):
        payment_method_types = self.get_payment_method_types(currency)

        return stripe.PaymentIntent.create(
            payment_method_types=payment_method_types,
            amount=amount,
            currency=currency,
            confirm=True,
            customer=customer_id,
            off_session=True,
            payment_method=payment_method
        )
