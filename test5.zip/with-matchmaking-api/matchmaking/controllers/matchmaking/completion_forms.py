# -*- coding: utf-8 -*-
from copy import deepcopy
from bson.errors import InvalidId
from flask import jsonify, request, current_app
from pymongo import ReturnDocument
from pymongo.collation import Collation
from datetime import timedelta
from ...controllers import admin_bp
from ...models.models import v, schema_completion_form
from ...models.nonprofit import completion_form_model
from ...mongodb import ObjectId, get_nonprofit, db, get_deal, get_mm_brand, get_program, get_user, get_funding_form, get_completion_form
from ...utils import (set_last_updated, set_created_at, get_locale_string, EntityNotFound, UnsupportedId,
                      UnsupportedPayload, ValidationError, SurveyStatus, generate_random_slug, GivewithError,
                      convert_program_to_survey, get_deep_diff, remove_empty, send_loggly)
from ...permission_decorator import require_admin_permission
from ..commerce.survey import calculate_progress, calculate_percent_complete


ENTITY_NAME = 'completion_form'

##
# Protected Endpoints
##
@admin_bp.route('/completion-forms', methods=['GET'])
@require_admin_permission
def admin_list_completion_forms():
    """
    List all available Completion Forms

    """
    projection = {
        'name' : True,
        '_id': True,
        'status': True,
        'percentComplete': True,
        'program': True,
        'givewithCustomer': True,
        'client': True,
        'nonprofitName': True,
        'fundingForm': True,
        'nonprofit': True,
        'givewithAdmin': True,
    }

    completion_forms = list(db().coll_completion_forms
                         .find(request.filter_params, projection=projection)
                         .skip(request.skip).limit(request.page_size)
                         .collation(Collation(locale=get_locale_string(), numericOrdering=True))
                         .sort(request.sort_params))

    for form in completion_forms:
        add_names_and_currency(form, False, True)

    return jsonify(completion_forms)


@admin_bp.route('/completion-forms/<id>', methods=['GET'])
@require_admin_permission
def get_completion_form_by_id(id):
    """
    Fetch Completion Form data

    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    completion_form = get_completion_form(obj_id)

    if not completion_form:
        raise EntityNotFound(ENTITY_NAME, id)

    completion_form = add_names_and_currency(completion_form, True, False)

    if completion_form['status'] == str(SurveyStatus.SUBMITTED):
        funding_form = db().coll_program_funding_forms.find_one({'_id': completion_form['fundingForm']})

        form_model = completion_form_model(is_normalization=True)
        clean_completion_form = v.normalized(completion_form, form_model)
        clean_funding_form = v.normalized(funding_form, form_model)

        completion_form['diff'] = get_deep_diff(clean_completion_form, clean_funding_form)

    return jsonify(completion_form)

@admin_bp.route('/completion-forms', methods=['POST'])
@require_admin_permission
def insert_completion_form(completion_form=None):
    """
    Create new Completion Form

    """

    if completion_form:
        document = completion_form
    else:
        document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    funding_form_id = document.get('fundingForm')
    funding_form = get_funding_form(ObjectId(funding_form_id))

    # copy values from funding_form to use as foundation for completion_form
    funding_copy = deepcopy(funding_form)

    # pop fields that exist in both PFF and PCF that might not exist in document dict
    for field in ['notes', 'lastUpdated', 'signature']:
        funding_copy.pop(field, None)

    # since there are duplicates between dicts, these params must be in this order
    # so keys in document will override keys in funding_copy
    document = {**funding_copy, **document}

    document.pop('_id', None)

    # overwrite
    if funding_form.get('effectiveDate'):
        document['dueDate'] = funding_form.get('effectiveDate') + timedelta(days=30)

    document['deal'] = funding_form.get('deal')
    document['slug'] = generate_random_slug()
    document['editing'] = True
    document['status'] = str(SurveyStatus.IN_PROGRESS)
    document['percentComplete'] = 0 # to pass validation, to be updated later

    form_model = completion_form_model(is_normalization=True)
    schema = {**schema_completion_form, **form_model}

    v.validate(document, schema_completion_form)
    if v.errors:
        raise ValidationError(v.errors)

    document = v.normalized(document, schema)
    if v.errors:
        raise ValidationError(v.errors)

    progress, incomplete_fields = calculate_progress('PCF', document)
    document['percentComplete'] = calculate_percent_complete(progress)

    inserted_id = db().coll_completion_forms.insert_one(set_created_at(document)).inserted_id
    document['_id'] = inserted_id

    return jsonify(document)


@admin_bp.route('/completion-forms/<id>', methods=['POST'])
@require_admin_permission
def approve_completion_form(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    completion_form = get_completion_form(obj_id)
    if not completion_form:
        raise EntityNotFound(ENTITY_NAME, id)

    status = completion_form.get('status')
    if status != str(SurveyStatus.SUBMITTED):
        raise GivewithError(f'Cannot approve completion form with {status} status', code=400)

    completion_form['status'] = str(SurveyStatus.APPROVED)

    updated_document = db().coll_completion_forms.find_one_and_update(filter={'_id': obj_id},
                                                                      return_document=ReturnDocument.AFTER,
                                                                      update={
                                                                        '$set': set_last_updated(completion_form)
                                                                      })

    if not updated_document:
        updated_document = completion_form
        current_app.logger.warning('Unable to update completion form with id %s', str(obj_id))

    send_loggly(
        f'ADMIN-PCF: FORM WITH ID: {updated_document.get("_id")} APPROVED '
        f'BY USER WITH ID: {request.user.get("_id")}'
    )
    updated_document = add_names_and_currency(updated_document, True, False)

    return jsonify(updated_document)

@admin_bp.route('/completion-forms/<id>', methods=['PUT'])
@require_admin_permission
def update_completion_form(id):

    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    # concat two objects together to validate/normalize
    validation_schema = {**schema_completion_form, **completion_form_model()}
    v.validate(document, validation_schema)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    if document['editing'] and document['status'] != str(SurveyStatus.IN_PROGRESS):
        document['status'] = str(SurveyStatus.IN_PROGRESS)
        send_loggly(
            f'ADMIN-PCF: EDITING TOGGLED "ON" ON FORM WITH ID: {document.get("_id")} '
            f'BY USER WITH ID: {request.user.get("_id")}'
        )

    normalization_schema = {**schema_completion_form, **completion_form_model(is_normalization=True)}
    document = v.normalized(document, normalization_schema)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    remove_empty(document)

    document.pop('lastUpdated', None)
    document.pop('_id', None)

    updated_document = db().coll_completion_forms.find_one_and_update(filter={'_id': obj_id},
                                                                      update={'$set': set_last_updated(document)},
                                                                      return_document=ReturnDocument.AFTER)

    if not updated_document:
        updated_document = document
        current_app.logger.warning('Unable to update completion form with id %s', str(obj_id))

    updated_document['_id'] = obj_id

    updated_document = add_names_and_currency(updated_document, True, False)

    return jsonify(updated_document)

@admin_bp.route('/completion-forms/<id>', methods=['DELETE'])
@require_admin_permission
def delete_completion_form(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_completion_forms.find_one_and_delete({'_id': obj_id})

    send_loggly(
        f'ADMIN-PCF: FORM WITH ID: {deleted_document.get("_id")} DELETED '
        f'BY USER WITH ID: {request.user.get("_id")}'
    )
    return jsonify(deleted_document)


def add_names_and_currency(form, get_currency=True, get_admin=False):

    # funding form
    funding_form = get_funding_form(form.get('fundingForm'), projection={'name': True, 'deal': True})
    if funding_form:
        form['fundingFormName'] = funding_form.get('name')

        # deal name
        deal = get_deal(funding_form.get('deal'), projection={'name': True,
                                                              'reference': True,
                                                              'fundingAmount': True,
                                                              'currency': True})
        if deal and get_currency:
            form['fundingAmount'] = deal.get('fundingAmount')
            form['currency'] = deal.get('currency')

    # program name
    program = get_program(form.get('program'), projection={'name': True,
                                                           'description': True})
    form['programName'] = program.get('name')
    form['programDescription'] = program.get('description')

    # nonprofit name
    nonprofit = get_nonprofit(form.get('nonprofit'), projection={'name': True,
                                                                 'slug': True})
    form['nonprofitName'] = nonprofit.get('name')

    # give with customer name
    customer = form.get('givewithCustomer')
    givewith_customer_brand = get_mm_brand(customer, projection={'name': True, 'nameLabel': True})
    name = givewith_customer_brand.get('nameLabel') or givewith_customer_brand.get('name')
    form['givewithCustomerName'] = name

    # client name
    client_brand = get_mm_brand(form.get('client'), projection={'name': True,
                                                                'nameLabel': True})
    client_name = client_brand.get('nameLabel') or client_brand.get('name')
    form['clientName'] = client_name

    if get_admin:
        givewith_admin_id = form.get('givewithAdmin')
        form['givewithAdminName'] = get_user(givewith_admin_id, projection={'name': True}).get('name')

    return form
