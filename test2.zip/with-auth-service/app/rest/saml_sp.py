import base64
import defusedxml.ElementTree

from flask import redirect, Blueprint, Response, current_app, request
from app.utils.saml_sp import create_sp_metadata, create_saml_request

saml_sp_bp = Blueprint('saml_sp', __name__)
"""
@api {GET} /v1/saml/sp/metadata Get Givewith SAML SP metadata
@apiName GetSPMetadata
@apiGroup Saml
@apiDescription Get SP metadata
"""
@saml_sp_bp.route('/metadata', methods=['GET'])
def sp_metadata():
    return Response(create_sp_metadata(current_app.config, 'givewith'), mimetype='application/xml')


"""
@api {GET} /v1/saml/sp/authnrequest Get AuthnRequest. 
@apiName GetAuthnRequest
@apiGroup Saml
@apiDescription Get an AuthnRequest. AuthnRequest is sent by the Service Provider to the Identity Provider in the SP-SSO 
initiated flow.
"""
@saml_sp_bp.route('/authnrequest', methods=['GET'])
def get_saml_request():
    return Response(create_saml_request(current_app.config, 'givewith'))


"""
@api {POST} /v1/saml/sp/assert SP assertion endpoint 
@apiName Assertion
@apiGroup Saml
@apiDescription This is the endpoint provided by the SP where SAML responses are posted.
@apiParamExample {json} Body example:
{
    "relayState": "insights",
    "SAMLResponse": "PHNhbWxwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1scD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3..."
}
"""
@saml_sp_bp.route('/assert', methods=['POST'])
def sp_assertion():
    saml_response = request.json.get('SAMLResponse')
    decode = base64.b64decode(saml_response).decode("utf-8")

    root = defusedxml.ElementTree.parse(decode)
    attributes = root.attrib
    assertion_url = attributes['AssertionConsumerServiceURL']

    return redirect(assertion_url, 302)



