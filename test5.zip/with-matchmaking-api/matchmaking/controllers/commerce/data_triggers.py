from os import environ
import requests
from requests.exceptions import ConnectTimeout, ReadTimeout
from flask import Response
from datetime import datetime, timezone
from bson.objectid import ObjectId
from ...controllers import admin_bp
from ...mongodb import db
from ...permission_decorator import require_admin_permission
from ...utils import (GivewithError)


RESEARCH_API = environ.get('RESEARCH_API_URL', 'http://localhost:5002')


@admin_bp.route('/data-triggers/csrit', methods=['POST'])
@require_admin_permission
def trigger_csrit():
    uri = f'{RESEARCH_API}/triggers/csrit'
    response = requests.post(uri)

    if response.status_code == 200:
        timestamp = datetime.utcnow().replace(tzinfo=timezone.utc, microsecond=0).isoformat()
        db().coll_settings.update_many({}, {'$set': {'triggers.csritLastUpdated': timestamp}})

    return Response(response.text, response.status_code, content_type='application/json')


def trigger_program_tagging(program_id):
    uri = f'{RESEARCH_API}/tagging/ALL/{program_id}'

    try:
        response = requests.get(uri, timeout=10.0)
    except ConnectTimeout as connectex:
        raise GivewithError(str(connectex), code=502)
    except ReadTimeout as readex:
        raise GivewithError(str(readex), code=502)

    if response.status_code == 200:
        timestamp = datetime.utcnow().replace(tzinfo=timezone.utc, microsecond=0).isoformat()
        db().coll_programs.update_one({'_id': ObjectId(program_id)}, {'$set': {'triggers.taggingLastUpdated': timestamp}})

    return Response(response.content, response.status_code, content_type='application/json')
