from datetime import datetime, timezone
from threading import Lock
from research_api.fetchers.fetchers import fetch
from research_api.jobs.brand_dedup import dedup_brands_handler
from research_api.logger import PipelineLogger
from research_api.mongodb import save_dataset, save_raw_dataset
from research_api.new_brands import new_brand_discovery
from research_api.patch import patch
from research_api.transformers.transformers import transform
from research_api.utils import GivewithError, PipelineError
from research_api.validators import clean
from research_api.loggly import get_logger
from research_api.slack import SimianSlack


# data pipeline
PIPELINE = [
    fetch,                  # Get the data from the source
    save_raw_dataset,       # If needed, saves the raw data
    clean,                  # Validate data and remove bad rows
    transform,              # Make calculations and format data
    patch,                  # Apply manual data patches
    # Check if there are any brands in the data that we are not aware of
    new_brand_discovery,
    save_dataset            # Save the dataset to our DB
]

DATASETS = ['CSRIT', 'CSRHUB', 'MSCI', 'TVL', 'SASB', 'NIELSEN']
LOCKS = {dataset: Lock() for dataset in DATASETS}
slack = SimianSlack()

def start_pipeline(dataset):
    dataset = dataset.upper()
    if dataset not in DATASETS:
        raise GivewithError("Invalid dataset")

    lock = LOCKS[dataset]

    # try to acquire Lock, return error if lock is unavailable
    if not lock.acquire(blocking=False):
        raise GivewithError(
            f'{dataset} is currently running, please try again later', code=400)

    data = []
    try:
        current_stage = ''
        for stage in PIPELINE:
            current_stage = stage.__name__
            
            get_logger().info(
                f'Starting stage {current_stage} for dataset {dataset}')
            slack.send_text(f'Starting stage {current_stage} for dataset {dataset}')
            data = stage(dataset, data)

    except Exception as e:
        exception_str = f'{dataset} failed in stage {current_stage}'
        get_logger().exception(exception_str)
        slack.send_text(exception_str)
        raise PipelineError(exception_str, False)

    finally:
        lock.release()

    PipelineLogger.get_instance(dataset).flush()

def trigger_brand_dedup():
     print(dedup_brands_handler())