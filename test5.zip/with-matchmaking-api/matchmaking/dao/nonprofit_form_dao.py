import copy

from bson.objectid import ObjectId
from . import utils
from matchmaking.models.nonprofit_form import completed_form_schema

form_status_init = 'INITIALIZED'
form_status_in_progress = 'IN_PROGRESS'
form_status_submitted = 'SUBMITTED'
form_status_approved = 'APPROVED'
form_status_rejected = 'REJECTED'


def add_form(form):
    _id = ObjectId()
    form['_id'] = _id
    form['slug'] = str(_id)
    form['editing'] = True
    form['status'] = form_status_init
    form['progress'] = {}
    form['percentComplete'] = 0

    return utils.add_document('nonprofit_form', form)

def get_form(form_id):
    return utils.get_document_by_id('nonprofit_form', form_id)


def list_forms():
    return utils.list_documents('nonprofit_form')


def delete_form(form_id):
    utils.hard_delete_document_by_id('nonprofit_form', form_id)


def update_form(form_id, changes):
    form = utils.get_document_by_id('nonprofit_form', form_id)
    form = utils.merge_diff(form, changes)
    form['status'] = form_status_in_progress

    form['progress'], form['percentComplete'], form['incompleteFields'] = calcProgress(form)
    utils.update_document_by_id('nonprofit_form', form_id, form)
    return form


def replace_form(form_id, new_form):
    new_form['status'] = form_status_in_progress
    new_form['progress'], new_form['percentComplete'], new_form['incompleteFields'] = calcProgress(new_form)
    utils.replace_document('nonprofit_form', form_id, new_form)
    return new_form


def submit_form(form_id):
    utils.update_document_by_id('nonprofit_form', form_id, {'status': form_status_submitted, 'editing': False})


def approve_form(form_id):
    form = utils.get_document_by_id('nonprofit_form', form_id)
    if not form:
        return

    # update naf status to approved
    form['isValid'] = False
    utils.update_document_by_id('nonprofit_form', form_id, {'status': form_status_approved})

    # check if there is a nop already associated
    new_npo = ('nonprofitId' not in form or len(str(form.get('nonprofitId', ''))) == 0)

    if new_npo:
        form.pop('_id')
        form['name'] = form['general']['name']['publicOrganizationName']
        form['nonprofitSubmissionId'] = form_id

        # add nonprofit
        nonprofit = utils.add_document('mm_nonprofits', form)

        # update nonprofit id in naf
        utils.update_document_by_id('nonprofit_form', form_id, {'nonprofitId': nonprofit['_id']})
    else:
        utils.update_document('mm_nonprofits', {'slug': form_id}, form)

def calcProgress(form):
    total = 0
    complete = 0
    progress = {}
    incomplete_fields = {}

    country = form.get('general', {}).get('location', {}).get('generalLocation', '')
    schema = adjust_schema(country)

    calc_keys = ['general', 'overviewAndMission', 'operationalInformation']
    for key in calc_keys:
        t, c, individual_incomplete_fields = calcComplete(form.get(key, {}), schema.get(key, {}), [])

        incomplete_fields[key] = individual_incomplete_fields
        if key == 'operationalInformation':
            t += 1
            financial_statement = form.get('operationalInformation', {}).get('financialStatement', {})
            website = financial_statement.get('website', '')
            file = financial_statement.get('file', {})
            if len(website) > 0 or len(file.get('name', '')) > 0:
                c += 1
            else:
                # add both paths to incomplete_fields if neither are answered
                incomplete_fields['operationalInformation'].append('financialStatement.website')
                incomplete_fields['operationalInformation'].append('financialStatement.file')

        progress[key] = {
            'complete': c,
            'total': t
        }

        total += t
        complete += c

    return progress, round(float(complete/total) * 100), incomplete_fields

# incomplete_fields includes all the paths for which the field is not filled/empty
def calcComplete(form, schema, incomplete_fields, parentKey=False):
    total = 0
    complete = 0

    for k, v in schema.items():

        if isinstance(v, dict):
            t, c, incomplete_fields = calcComplete(form.get(k, {}), schema.get(k), incomplete_fields, k)
            total += t
            complete += c
        else:
            total += 1
            if k in form:
                if isinstance(form.get(k), list):
                    if len(form.get(k)) > 0:
                        complete += 1
                elif len(str(form.get(k))) > 0:
                    complete += 1
                else:
                    empty_field = k
                    if parentKey:
                        empty_field = parentKey + '.' + k
                    incomplete_fields.append(empty_field)
            else:
                empty_field = k
                if parentKey:
                    empty_field = parentKey + '.' + k

                incomplete_fields.append(empty_field)

    return total, complete, incomplete_fields


def adjust_schema(country):
    schema = copy.deepcopy(completed_form_schema)
    location_schema = schema['general']['location']
    if country == 'United States':
        location_schema['w9'] = {
            'url': str,
            'name': str
        }
        location_schema['taxId'] = str
    elif country == 'United Kingdom':
        location_schema['charityNumber'] = str
        location_schema['companyHouseNumber'] = str
    elif country == 'Others':
        location_schema['otherId'] = str

    return schema


def get_vocabulary():
    location = utils.get_document('location_data')
    if location is None:
        location = {}

    causes = utils.get_documents('mm_vocabulary', {'type': 'causes', 'versions': {'$in': [2]}})
    return {
        'location': location.get('locationTree', {}),
        'causes': causes

    }
