

# Givewith Localhost: Welcome Home

![image of a couch](https://github.com/EcoMedia/givewith-localhost/blob/master/resources/couch.png)


Tools and setup to get an easy-to-use self-contained local environment that is functionally as close as possible to staging/production for development and automated testing.

#### Project objectives:

* 1️⃣**Primary Objective: Development.**  Givewith developers need a fully-functioning local environment that enables all integrated services for efficient local development and testing, and also for devlopment isolation and system safety.
* 2️⃣**Secondary Object: Testing.** Having a complete version of our codebase that can be easily stood-up and torn-down will help enables efficient and automated testing.
* Use Docker to replicate same server host as AWS instances (Amazon Linux 2).
* Use AWS Code Deploy scripts to setup environ, with as much script reuse as possible (some settings need to be specific to local dev, i.e. URLS, dev-mode, etc., but minimize local-specific setup code)
* Docker containers must mount/serve your local file system, so that local edits appear on local server immediately (enabling dev-mode for Flask and NPM)
* ☕**Compile before Coffee**: Automate as much of the container and server setup as possible, so that a new developer can have a local running copy by noon on day zero.
* Use AWS ECR (Container Repo) to make sure everyone is using the same container; use repo-specific code-deploy scripts to ensure up-to-date libraries.

### Getting Started:

The following is an approximately sequential series of steps you'll need to take as a new developer to get the Givewith development environment setup fully.  

Welcome Home (that's a localhost joke)! 🛋️ And ask questions! As you learn and note changes or clarifications in this README, please pitch in and help improve this documentation, too!

#### Overview/Pre-Requisites:

These notes assume you are using a Mac, running a recent OS, and I would strongly recommend you have Python 3 installed and set as default.    

* **Docker**. If you haven't yet familiarized yourself with Docker, now is a great time to do so. Here's a [tutorial](https://stackify.com/docker-tutorial/), feel free to add newer/better links or tutorials that you might find.  Make yourself an account at [docker.com](https://docker.com), then [install](https://hub.docker.com/?overlay=onboarding) Docker desktop to your laptop.

* **AWS**. You'll need access to the Givewith AWS account and to [install the AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/install-macos.html) (make sure you install the Python3 version of the CLI).  With the AWS CLI [setup your local config](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-configure.html), and you will need to be able to pull Docker containers from the Development account -- which you should be able confirm by seeing `givewith_amzlinux` and `givewith_mongo` listed on our AWS ECR homepage (click [here](https://console.aws.amazon.com/ecr/repositories?region=us-east-1) to check). 
In your local `.aws` directory, you should have a `credentials` file, which has the info entered during setting up the CLI, and you should also have a `config` file, which has profile information for our multiple environments.  Neither of these files are on Github, tho', so a colleague or your manager will be able to help you (note both files require `chmod 600` permissions).  Your credentials file needs to have account info for AWS Roles.

* **Github**.  You'll need Git installed on your laptop (`brew install git`), and access to the Givewith Github to pull repos (you're viewing this page, so that alone suggests you're already setup).

* **MongoDB**.  Install [MongoDB](https://docs.mongodb.com/manual/tutorial/install-mongodb-on-os-x/) and [Robo3T](https://robomongo.org/) which will allow you to easily view/edit your local instance of the database.  You don't have to run a local MongoDB instance on your laptop -- it will be setup and run in a container -- so just install Mongo so that you have access to the export tools we need to get a local copy of the data from the Mongo Atlas hosted database. 

* Let's make sure the installations have gone according to plan -- in your terminal type the commands below, just to make sure they return a path.  If they don't respond and just return, that means we're not ready to proceed and you'll need to fuss with installation a bit more.  Note that the responses I've noted here may not necessarily be the exact response you get - and that's just fine.
    * `which git` (/usr/bin/git)
	* `which aws` (/Users/jason/.local/bin/aws)
	* `which docker` (/usr/local/bin/docker)
	* `which mongo` (/usr/local/bin/mongo)

### Step By Step:

Let's start at the very beginning:

* Pick a location on your local computer where you will be storing all the git repos.  Shanyan has a folder named `github` in his home directory. Daniel puts his in a folder called `APPDEV` on his `Desktop`; Michael prefers a directory named `workspace`, in a throwback to his youth toiling in fields of Java in Eclipse; Justin puts his repos into his `sites` folder, and Matthew does the same, ostensibly in tribute to Justin; Elizabeth has also followed suit with `sites`, but the disclaimer "I didn't realize it was a whole big thing", suggesting that she might choose otherwise, given the opportunity; Jason has all his repos in a `dev` folder and can't recall why, but has done so for well over a decade by now.  Your choice should be individual and distinctive, as unique as you are -- but it's just a directory so don't over think it either.

* With that critical decision made, next let's add the path you have just chosen for your local repo directory into a local environment variable: in your home directory (typically `/Users/yourname` on a Mac), edit your `.bash_profile` ([create your `.bash_profile`](https://hathaway.cc/2008/06/how-to-edit-your-path-environment-variables-on-mac/), if it doesn't yet exist) to include a line like `export DEVROOT=/Users/michael/workspace/`.  You may need to open a Terminal window, or type `source ~/.bash_profile` to get the variable to "stick".  You can confirm that the variable is accessible to your system by typing `printenv` into the terminal, which lists all the system variables loaded into memory.  (Side note - if all this **command-line kung-fu** is relatively new for you, have no fear - there are [good tutorials online](https://www.learnenough.com/command-line-tutorial/basics), and good people to ask for guidance -- but best to boost your confidence now as there's a lot of `bash` in getting everything running).

* Clone the following repos from github to your local `DEVROOT` directory. Protip - if you have two-factor-auth setup for Github (you should!), then you will need to use a Github issued 2FA key instead of your password, when prompted locally.
    * [givewith-localhost](https://github.com/EcoMedia/givewith-localhost)  (this repo! you'll need to run some code from here, too...)
    * [givewith-local-mongo](https://github.com/EcoMedia/givewith-local-mongo)
    * [givewith-pyadmin-api](https://github.com/EcoMedia/givewith-pyadmin-api)
	* [givewith-admin-ui](https://github.com/EcoMedia/givewith-admin-ui)
	* [givewith-matchmaking-api](https://github.com/EcoMedia/givewith-matchmaking-api)
	* [givewith-matchmaking-ui](https://github.com/EcoMedia/givewith-matchmaking-ui)
	* [givewith-campaign-summary-ui](https://github.com/EcoMedia/givewith-campaign-summary-ui)
	* [givewith-matchmaking-algo](https://github.com/EcoMedia/givewith-matchmaking-algo)
	* (Optional) [givewith-auto-testing](https://github.com/EcoMedia/givewith-auto-testing)

* Now let's get seed data for your local copy of mongo!  Open a terminal and navigate to the `givewith-localhost` directory.  Then run the `./load_database.sh` script, and a few things should happen right away.  One is that we first decrypt some encrypted [AWS KMS](https://aws.amazon.com/kms/) variables that are stored in `development.bin` and moved into your local environment variables, which provides us with the connection to the real staging database up in Mongo Atlas.  Then the script will download data collections as local flat files in the `$DEVROOT/givewith-mongo-local/export` directory.   

* With this complete, 


#### What's Here/What Am I Looking At?:

In the build directory:
`build_docker.sh` builds the base image.  Dockerfile is the generic AWS base we use for all our services, MongoDockerfile is a dockerfile just for Mongo (to stand-in for MongoAtlas locally).

In the top-level directory:
`pull_docker.sh` will fetch the most recent version of the docker containers from AWS ECR.
`docker-compose.yml` is the Docker setup file that will run all the services, via `docker-compose up`

#### Docker settings:

Your mileage may vary - but these seem to give enough power to Docker while still leaving enough for local development.

![image of docker ui](https://github.com/EcoMedia/givewith-localhost/blob/master/resources/docker.png)



