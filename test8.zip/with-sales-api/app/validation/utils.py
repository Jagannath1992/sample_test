import urllib
from bson.objectid import ObjectId
from app.db.database import get_db


def validate_object_id(document_id, collection_name) -> bool:
    if not ObjectId.is_valid(document_id):
        return False

    count = get_db()[collection_name].count_documents({'_id': ObjectId(document_id)})
    return count > 0

def is_uri_valid(url):
    try:
        result = urllib.request.urlparse(url)
        return all([result.scheme, result.netloc, result.path])
    except:
        return False
