from portal.shared.auth.model import UserDepartmentType, get_enum_members

def test_portal_departmentType():
    values = get_enum_members(UserDepartmentType)
    assert "Portal" in values
