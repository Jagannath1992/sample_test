import pytest
from portal.shared.errors import GivewithException
from portal.shared.sage.dates import get_sage_date, get_sage_legacy_date
from portal.shared.sage.enums import SageCustomFieldName, SageObjectType
from portal.shared.sage.models import SageBill, SageBillItem, SageBillItems, SageBillResult, SageBillTaxEntries, SageBillTaxEntry, \
    SageContactListInfo, SageContactListInfoContact, SageCustomField, SageCustomFields, SageCustomer, \
    SageInvoice, SageInvoiceBillResults, SageInvoiceItems, SageInvoiceResult, SageLineItem, SageTaxEntries, SageTaxEntry
from portal.shared.sage.faker import SageFaker
from portal.shared.services import sage_service
from portal.testing.fakers import Fakers


class TestSageService:

    @pytest.fixture
    def sage_bill(self):
        return SageFaker.sage_bill(self)

    @pytest.fixture
    def sage_invoice(self):
        return SageFaker.sage_invoice(self)

    @pytest.fixture
    def test_bill_create_init(self, mocker):
        bill_results = SageBillResult(
            recordNo='5180',
            billNumber='B001'
        )
        mocker.patch.object(sage_service(), 'create_bill', return_value=bill_results)
        return bill_results

    def test_create_give_bill_settings(self, mocker, fakers: Fakers, frozen_utcnow):
        # arrange
        instance = fakers.instance_settings.generate_single()
        transaction = fakers.transaction.generate_single()
        sage_date = get_sage_date(frozen_utcnow)
        vendor_id = 'V-586'
        record_no = transaction['sage']['billRecordNo']
        bill_id = transaction['sage']['billRecordNumber']
        location_id = instance['settings']['sage']['locationId']
        tax_solution_id = instance['settings']['sage'].get('taxSolutionId') or ''
        tax_detail_id = instance['settings']['sage'].get('billTaxDetailId')
        service_fee_factor = instance['settings']['serviceFee']
        service_fee_amount = transaction['amount'] * service_fee_factor
        bill_amount = transaction['amount'] - service_fee_amount

        expected_sage_bill = SageBill(
            WHENCREATED=sage_date,
            WHENPOSTED=sage_date,
            WHENDUE=sage_date,
            VENDORID=vendor_id,
            RECORDID=bill_id,
            DESCRIPTION=transaction['memo'],
            CURRENCY=transaction['currency'],
            BASECURR=transaction['currency'],
            TAXSOLUTIONID=tax_solution_id,
            APBILLITEMS=SageBillItems(
                APBILLITEM=[
                    SageBillItem(
                        ACCOUNTNO=instance['settings']['sage']['accounts']['socialImpactEnablement'],
                        OFFSETGLACCOUNTNO=instance['settings']['sage']['accounts']['socialImpactPayable'],
                        TRX_AMOUNT=bill_amount,
                        LOCATIONID=location_id,
                        DEPARTMENTID=instance['settings']['sage']['departments']['socialImpact'],
                        GIVEWITH_ORDER_ID=transaction['order']['_id'],
                        GIVEWITH_TRANSACTION_ID=transaction['_id'],
                        STRIPE_TRANSACTION_ID=transaction['stripe']['paymentIntentId'],
                        PRODUCT_NAME=instance['settings']['sage']['products']['transaction']
                    )
                ]
            )
        )

        if tax_solution_id and tax_detail_id:
            expected_sage_bill.APBILLITEMS.APBILLITEM[0].TAXENTRIES = SageBillTaxEntries(
                TAXENTRY=[
                    SageBillTaxEntry(DETAILID = tax_detail_id)
                ]
            )

        expected_bill_results = SageBillResult(
            recordNo=record_no,
            billNumber=bill_id
        )

        mocker.patch.object(sage_service(), '_create_bill', return_value=expected_bill_results)

        # act
        results = sage_service()._create_bill_with_settings(instance, transaction, vendor_id, bill_id)

        # assert
        assert results == expected_bill_results
        sage_service()._create_bill.assert_called_once_with(expected_sage_bill, location_id)

    def test_create_subscription_invoice_with_settings(self, mocker, fakers: Fakers, frozen_utcnow):
        # arrange
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        transaction = fakers.transaction.generate_single()
        sage_legacy_date = get_sage_legacy_date(frozen_utcnow)
        frequency = account['subscriptionFrequency']
        product_name = instance['settings']['sage']['products'][f'{frequency}Subscription']
        location_id = instance['settings']['sage']['locationId']
        tax_solution_id = instance['settings']['sage'].get('taxSolutionId') or ''
        tax_detail_id = instance['settings']['sage'].get('invoiceTaxDetailId')
        account_number = '90000'
        department = '300'
        
        expected_sage_invoice = SageInvoice(
            customerid=account['sageCustomerId'],
            datecreated=sage_legacy_date,
            dateposted=sage_legacy_date,
            datedue=sage_legacy_date,
            description=transaction['memo'],
            basecurr=transaction['currency'],
            currency=transaction['currency'],
            exchratedate=sage_legacy_date,
            exchratetype=instance['settings']['sage']['exchangeRate'],
            taxsolutionid=tax_solution_id,
            invoiceitems=SageInvoiceItems(
                lineitem=[
                    SageLineItem(
                        glaccountno=account_number, 
                        amount=transaction['amount'],
                        locationid=location_id,
                        departmentid=department,
                        customfields=SageCustomFields(
                            customfield=[
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.GIVEWITH_ORDER_ID.value,
                                    customfieldvalue=transaction.get('order',{}).get('_id','')
                                ),
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.GIVEWITH_TRANSACTION_ID.value,
                                    customfieldvalue=transaction['_id']
                                ),
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.STRIPE_TRANSACTION_ID.value,
                                    customfieldvalue=transaction['stripe']['paymentIntentId']
                                ),
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.PRODUCT_NAME.value,
                                    customfieldvalue=product_name
                                )
                            ]
                        )
                    )
                ]
            )
        )

        if tax_solution_id and tax_detail_id:
            expected_sage_invoice.invoiceitems.lineitem[0].taxentries = SageTaxEntries(
                taxentry=[
                    SageTaxEntry(detailid = tax_detail_id)
                ]
            )

        expected_results = SageInvoiceResult(
            recordNo='3163',
            invoiceNumber='INV027'
        )

        mocker.patch.object(sage_service(), '_create_invoice', return_value=expected_results)

        # act
        results = sage_service()._create_invoice_with_settings(instance, account, transaction, account_number, department, product_name)

        # assert
        assert results == expected_results
        sage_service()._create_invoice.assert_called_once_with(expected_sage_invoice, location_id)

    def test_create_subscription_invoice(self, mocker, fakers: Fakers):
        # arrange
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        transaction = fakers.transaction.generate_single()
        frequency = account['subscriptionFrequency']

        expected_invoice_results = SageInvoiceResult(
            recordNo='3163',
            invoiceNumber='INV027'
        )

        mocker.patch.object(sage_service(), '_create_invoice_with_settings', return_value=expected_invoice_results)

        # act
        results = sage_service().create_subscription_invoice(instance, account, transaction)

        # assert 
        assert results == expected_invoice_results
        sage_service()._create_invoice_with_settings.assert_called_once_with(
            instance, account, transaction,
            instance['settings']['sage']['accounts']['subscriptionRevenue'],
            instance['settings']['sage']['departments']['sales'],
            instance['settings']['sage']['products'][f'{frequency}Subscription'])

    def test_create_give_invoice_bill(self, mocker, fakers: Fakers):
        # arrange
        expected_invoice_results = SageInvoiceResult(
            recordNo='3163',
            invoiceNumber='INV027'
        )
        expected_bill_results = SageBillResult(
            recordNo='54163',
            billNumber='B027'
        )
        expected_invoice_bill_results = SageInvoiceBillResults(
            invoice=expected_invoice_results,
            bill=expected_bill_results
        )
        mocker.patch.object(sage_service(), '_create_invoice_with_settings', return_value=expected_invoice_results)
        mocker.patch.object(sage_service(), '_create_bill_with_settings', return_value=expected_bill_results)
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        transaction = fakers.transaction.generate_single()
        vendor_id = 'V-586'
        bill_id = expected_bill_results.billNumber

        # act
        results = sage_service().create_give_invoice_and_bill(instance, account, transaction, vendor_id)

        # assert
        assert results == expected_invoice_bill_results
        sage_service()._create_invoice_with_settings.assert_called_once_with(
            instance, account, transaction,
            instance['settings']['sage']['accounts']['transactionRevenue'],
            instance['settings']['sage']['departments']['sales'],
            instance['settings']['sage']['products']['transaction'])
        sage_service()._create_bill_with_settings.assert_called_once_with(instance, transaction, vendor_id, bill_id)

    def test_legacy_dates(self, frozen_utcnow):
        # testing both sage dates return the frozen date
        # arrange
        sage_legacy_date = get_sage_legacy_date(frozen_utcnow)
        expected_sage_date = "{:02d}/{:02d}/{:d}".format(sage_legacy_date.month, sage_legacy_date.day, sage_legacy_date.year)

        # act
        new_legacy_date = get_sage_legacy_date()
        new_date = get_sage_date()

        #assert
        assert sage_legacy_date == new_legacy_date
        assert expected_sage_date == new_date

    def test_create_customer(self):
        pass

    def test_failed_create_invoice(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.customerid = None

        # act
        with pytest.raises(GivewithException) as exc:
            sage_service()._create_invoice(sage_invoice, 100)

        # assert
        assert exc.type is GivewithException

    def test_failed_create_bill(self, sage_bill: SageBill):
        # arrange
        sage_bill.VENDORID = None

        # act
        with pytest.raises(GivewithException) as exc:
            sage_service()._create_bill(sage_bill, 100)

        # assert
        assert exc.type is GivewithException


class TestSageService_Integration:
    pytestmark = pytest.mark.integration

    @pytest.fixture
    def sage_contact(self):
        return SageFaker.sage_contact(self)

    @pytest.fixture
    def sage_customer(self):
        return SageFaker.sage_customer(self)

    @pytest.fixture
    def sage_bill(self):
        return SageFaker.sage_bill(self)

    @pytest.fixture
    def sage_custom_fields(self):
        return SageFaker.sage_custom_fields(self)

    @pytest.fixture
    def sage_invoice(self):
        return SageFaker.sage_invoice(self)

    @pytest.fixture
    def test_init(self, fakers):
        account = fakers.account.generate_single()
        return account

    def test_create_contact(self, test_init, sage_contact):
        # arrange
        account = test_init

        # act
        sage_contact_result = sage_service().create_contact(account, sage_contact)

        # assert
        assert sage_contact_result.contactName is not None
        assert sage_contact_result.recordNo is not None

        # cleanup
        sage_service()._delete_object(SageObjectType.CONTACT, sage_contact_result.recordNo)

    def test_create_customer(self, test_init, sage_customer):
        # arrange
        account = test_init

        # act
        sage_customer_result = sage_service().create_customer(account, sage_customer)

        # assert
        assert sage_customer_result.customerId is not None
        assert sage_customer_result.recordNo is not None

        # cleanup
        sage_service()._delete_object(SageObjectType.CUSTOMER, sage_customer_result.recordNo)

    def test_update_customer(self, test_init, sage_contact, sage_customer):
        # arrange
        account = test_init
        sage_customer_result = sage_service().create_customer(account, sage_customer)

        sage_contact_result = sage_service().create_contact(account, sage_contact)

        customer = SageCustomer(
            CONTACT_LIST_INFO=[
                SageContactListInfo(
                    CATEGORYNAME='Finance',
                    CONTACT=SageContactListInfoContact(
                        NAME=sage_contact_result.contactName
                    )
                )
            ]
        )

        # act
        result = sage_service().update_customer(account, customer, sage_customer_result.recordNo)

        # assert
        assert result.customerId is not None
        assert result.recordNo is not None

        # cleanup
        sage_service()._delete_object(SageObjectType.CUSTOMER, sage_customer_result.recordNo)
        sage_service()._delete_object(SageObjectType.CONTACT, sage_contact_result.recordNo)

    def test_get_invoice(self, test_init, sage_invoice: SageInvoice, sage_customer: SageCustomer):
        # arrange
        account = test_init
        sage_customer_result = sage_service().create_customer(account, sage_customer)
        sage_invoice.customerid = sage_customer_result.customerId
        result = sage_service()._create_invoice(sage_invoice)

        # act
        invoice_number = sage_service()._get_record_id(result.recordNo, SageObjectType.ARINVOICE)

        # assert
        assert result.invoiceNumber == invoice_number

        # cleanup
        sage_service()._delete_object(SageObjectType.ARINVOICE, result.recordNo)
        sage_service()._delete_object(SageObjectType.CUSTOMER, sage_customer_result.recordNo)


    def test_create_bill(self, test_init, sage_bill: SageBill):
        # arrange

        # act
        result = sage_service()._create_bill(sage_bill)

        # assert
        assert result.recordNo is not None

        # cleanup
        sage_service()._delete_object(SageObjectType.APBILL, result.recordNo)

    def test_create_invoice(self, test_init, sage_invoice: SageInvoice, sage_customer: SageCustomer):
        # arrange
        account = test_init
        sage_customer_result = sage_service().create_customer(account, sage_customer)
        sage_invoice.customerid = sage_customer_result.customerId

        # act
        result = sage_service()._create_invoice(sage_invoice)

        # assert
        assert result.recordNo is not None
        assert result.invoiceNumber is not None

        # cleanup
        sage_service()._delete_object(SageObjectType.ARINVOICE, result.recordNo)
        sage_service()._delete_object(SageObjectType.CUSTOMER, sage_customer_result.recordNo)

    def test_create_invoice_2_line_items(self, test_init, sage_invoice: SageInvoice, sage_custom_fields: SageCustomFieldName, sage_customer: SageCustomer):
        # arrange
        account = test_init
        sage_customer_result = sage_service().create_customer(account, sage_customer)
        sage_invoice.customerid = sage_customer_result.customerId

        # test with 2 different accounts and using glaccountno
        sage_invoice.invoiceitems = SageInvoiceItems(
            lineitem=[
                SageLineItem(
                    accountlabel='60400',
                    amount=170.00,
                    locationid=100,
                    departmentid='300',
                    customfields=sage_custom_fields
                ),
                SageLineItem(
                    glaccountno='90000',

                    amount=85.00,
                    locationid=100,
                    departmentid='300',
                    customfields=sage_custom_fields
                )
            ]
        )

        # act
        result = sage_service()._create_invoice(sage_invoice)

        # assert
        assert result.recordNo is not None
        assert result.invoiceNumber is not None

        # cleanup
        sage_service()._delete_object(SageObjectType.ARINVOICE, result.recordNo)
        sage_service()._delete_object(SageObjectType.CUSTOMER, sage_customer_result.recordNo)
