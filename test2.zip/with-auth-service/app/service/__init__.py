import boto3

from app.loggly import send_loggly
from app.service.okta import OktaService
from app.service.datadog import init_datadog

services = {
    'cognito_client': None,
    'cognito_client_id': None,
    'okta': None
}

def init_service(app):
    try:
        init_cognito(app)
    except Exception as e:
        send_loggly("failed to init cognito: " + str(e))

    try:
        init_okta(app)
    except Exception as e:
        send_loggly("failed to to init okta: " + str(e))

    try:
        init_datadog()
    except Exception as e:
        send_loggly("failed to to init datadog: " + str(e))


def init_cognito(app):
    aws_config = app.config['config']['service']['aws']

    global services
    services['cognito_client'] = boto3.client('cognito-idp', aws_config['aws_region'])
    services['cognito_client_id'] = aws_config['cognito_client_id']


def init_okta(app):
    global services
    services['okta'] = OktaService(app)
