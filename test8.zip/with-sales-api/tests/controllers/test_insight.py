import json
import pytest


def test_get_insights_without_token(client, default_header):
    response = client.get('/insight/5c1415685b03bb0008c21b06', headers=default_header)
    assert response.status_code in [401, 403]


@pytest.mark.parametrize('header', [
    pytest.lazy_fixture('client_header'),
    pytest.lazy_fixture('supplier_analysis_report_header')
])
def test_get_insights_with_valid_headers(client, header):
    response = client.get('/insight/5fad58987cae51199d14525b', headers=header)
    assert response.status_code == 200

    insights = json.loads(response.data.decode())

    assert insights['name']
    assert insights['industry']
    assert insights['topics']

    assert 'narrative' in insights
    assert 'msci' in insights
    assert 'reward' in insights
