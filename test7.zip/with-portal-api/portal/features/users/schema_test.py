import pytest
from re import escape, RegexFlag
from bson import ObjectId
from bson.regex import Regex
from marshmallow import ValidationError
from portal.features.users.schema import AccountRegisterRequest, UserRegisterRequest, UserSchema, UserSearchRequest
from portal.shared.email.validator import EmailValidator
from portal.shared.repositories import user_repository
from portal.shared.enums import AccountStatus, UserRole, AccountType


class TestUserSchema():
    @pytest.fixture()
    def schema(self) -> UserSchema:
        return UserSchema()

    def test_invalid_user(self, schema):
        # arrange
        request_data = {
            'username': 'abc123',
            'firstName': 'John',
            'lastName': 'Smith',
        }

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'username': ['Invalid username']}


class TestUserRegisterRequest():
    @pytest.fixture()
    def schema(self) -> UserRegisterRequest:
        return UserRegisterRequest()

    @pytest.fixture()
    def request_data(self):
        return {
            'user': {
                'username': 'Test@example.com',
                'firstName': 'John',
                'lastName': 'Smith',
            },
            'account': {
                'industry': {
                    'displayLabel': 'Make Stuff Industry',
                    'subIndustry': 'Make Stuff'
                },
                'company': {
                    'name': 'Acme Inc',
                }
            }
        }

    def test_post_load(self, mocker, fakers, request_data, schema):
        # arrange
        blocked_domains = {'domains': []}
        account = fakers.account.generate_single()
        mocker.patch.object(user_repository(), 'get_blocked_domains', return_value=blocked_domains)
        mocker.patch.object(user_repository(), 'username_exists', return_value=False)
        lowered_username = request_data['user']['username'].lower()
        expected = {
            'user': {
                'username': lowered_username,
                'first_name': request_data['user']['firstName'],
                'last_name': request_data['user']['lastName'],
                'orgId': '',
                'orgName': '',
                'orgType': 'brand',
                'type': 'client',
                'departmentType': 'Portal',
                'roles': [UserRole.ORG_ADMIN.value]
            },
            'account': {
                'status': AccountStatus.NEW.value,
                'type': AccountType.DEFAULT.value,
                'industry': request_data['account']['industry'],
                'company': {
                    'name': request_data['account']['company']['name']
                },
                'giveFields': {
                    field: settings for field, settings in account['giveFields'].items()
                    if not field.startswith('customField')
                },
            }
        }

        # act
        result = schema.load(request_data)

        # assert
        assert result == expected

    def test_validate_username_invalid_email_address(self, mocker, schema, request_data):
        # arrange
        mocker.patch.object(EmailValidator, 'validate', return_value=None)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'user': {'username': ['Invalid username']}}

    def test_validate_username_blocked_domain(self, mocker, schema, request_data):
        # arrange
        blocked_domains = {'domains': ['example.com']}
        mocker.patch.object(user_repository(), 'get_blocked_domains', return_value=blocked_domains)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'user': {'username': ['Blocked domain']}}

    def test_validate_username_not_unique(self, mocker, schema, request_data):
        # arrange
        blocked_domains = {'domains': []}
        mocker.patch.object(user_repository(), 'get_blocked_domains', return_value=blocked_domains)
        mocker.patch.object(user_repository(), 'username_exists', return_value=True)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'user': {'username': ['Username must be unique']}}


class TestAccountRegisterRequest:
    # TODO Move schema fixture and test_validate to base class with request_data abstract method
    @pytest.fixture()
    def schema(self) -> AccountRegisterRequest:
        return AccountRegisterRequest()

    @pytest.fixture()
    def request_data(self):
        return {
            'account': {
                'company': {
                    'address': {
                        'address1': '123 Main St',
                        'city': 'Anytown',
                        'stateProvince': 'LA',
                        'postalCode': '55555',
                        'country': 'United States',
                    },
                    'phoneNumber': '555-555-5555',
                    'website': 'www.example.com',
                }
            }
        }

    def test_validate(self, schema, request_data):
        # arrange

        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_post_load(self, schema, request_data):
        # arrange
        company = request_data['account']['company']
        address = company['address']
        expected = {
            'account': {
                'status': AccountStatus.PENDING.value,
                'company': {
                    'address': {
                        'address1': address['address1'],
                        'city': address['city'],
                        'stateProvince': address['stateProvince'],
                        'postalCode': address['postalCode'],
                        'country': address['country'],
                    },
                    'phoneNumber': company['phoneNumber'],
                    'website': company['website'],
                },
            }
        }

        # act
        result = schema.load(request_data)

        # assert
        assert result == expected


class TestUserSearchRequest:
    @pytest.fixture()
    def schema(self) -> UserSearchRequest:
        return UserSearchRequest()

    @pytest.fixture()
    def request_data(self):
        return {
            'offset': 0,
            'count': 1,
            'orderBy': 'firstName'
        }

    def test_init(self, schema):
        assert len(type(schema).Meta.contains_fields) == 3

    def test_validate(self, schema, request_data):
        # arrange

        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_post_load(self, schema, request_data):
        # arrange
        request_data.update({
            'orderBy': 'lastName',
            'username': 'john.smith@example.com',
            'accountId': str(ObjectId())
        })
        expected = {
            'offset': request_data['offset'],
            'count': request_data['count'],
            'orderBy': 'lastName',
            'descending': False,
            'username': Regex(escape(request_data['username']), RegexFlag.IGNORECASE),
            'accountId': ObjectId(request_data['accountId'])
        }

        # act
        result = schema.load(request_data)

        # assert
        assert result == expected
