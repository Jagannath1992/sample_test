from bson import ObjectId

from portal.shared.enums import OrderStatus


class TestOrderRepository:

    def test_update_status(self, repositories, fakers):
        order_repo = repositories['order']
        created = fakers.order.insert_single()
        assert created['status'] == 'pending approval'

        update = {
            'status': 'approved'
        }
        updated = order_repo.patch(created['_id'], update)

        assert updated['status'] == 'approved'
        assert order_repo.get_single(created['_id'])['status'] == 'approved'

    def test_get_page_status_filter(self, repositories, fakers):
        fakers.order.insert_single()
        expected = fakers.order.insert_single({'status': 'draft'})
        order_repo = repositories['order']

        request_filters = {
            'count': 10,
            'offset': 0,
            'orderBy': 'id',
            'descending': False,
            'status': 'draft'
        }

        actual = order_repo.get_page(request_filters)

        assert actual == (1, [expected])

    def test_get_page_cause_filter(self, repositories, fakers):
        created = fakers.order.insert_many(3)
        expected = created[2]
        order_repo = repositories['order']

        request_filters = {
            'count': 10,
            'offset': 0,
            'orderBy': 'approver',
            'descending': False,
            'causeArea._id': expected['causeArea']['_id']
        }

        actual = order_repo.get_page(request_filters)

        assert actual == (1, [expected])

    def test_delete(self, repositories, fakers):
        order = fakers.order.insert_single()
        order_repo = repositories['order']
        assert order['status'] == OrderStatus.PENDING_APPROVAL.value

        order_repo.delete(order['_id'])

        updated_order = order_repo.get_single(order['_id'])
        assert updated_order['status'] == OrderStatus.DELETED.value

    def test_has_access(self, repositories, fakers):
        order = fakers.order.insert_single()
        order_repo = repositories['order']

        order_id = order['_id']
        account_id = order['account']['_id']

        assert order_repo.has_access(order_id, account_id)
        assert not order_repo.has_access(order_id, ObjectId())
