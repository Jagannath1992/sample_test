from typing import Dict, Any
from bson import ObjectId
from flask import Request, request
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from werkzeug.exceptions import Forbidden, BadRequest, NotFound, BadGateway, HTTPException

from portal.features.users.schema import (
    AccountSubscriptionActivateRequest, AccountSubscriptionActivateResponse, AccountSubscriptionRequest,
    AccountSubscriptionResponse, BlockedDomainsResponse, UserMyProfileRequest, UserProvisionRequest, UserProvisionResponse, UserResponse,
    UserRegisterRequest, AccountRegisterRequest, UserSearchRequest, UserSearchResponse, UserInviteRequest, UserRequest)
from portal.shared.auth.model import UserDepartmentType
from portal.shared.auth.requests import role_required, token_required
from portal.shared.auth.security import get_validated_account_id, has_role
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.email.validator import EmailValidator
from portal.shared.enums import AccountStatus, InstanceType, UserRole
from portal.shared.repositories import instance_settings_repository, user_repository, account_repository, account_approval_repository
from portal.shared.sage.models import SageContact, SageContactListInfo, SageContactListInfoContact, SageCustomer, SageMailAddress
from portal.shared.services import auth_service, email_service, flag_service, sage_service, stripe_service, registration_service

namespace = Namespace('users', description='User related operations')


@namespace.route('/blocked-domains')
class BlockedDomains(Resource):
    @responds(schema=BlockedDomainsResponse, api=namespace)
    def get(self):
        blocked_domains = user_repository().get_blocked_domains()
        return {'domains': blocked_domains.get('domains', [])}


@namespace.route('/register')
@namespace.response(400, 'Bad Request')
class Registration(Resource):
    @accepts(schema=UserRegisterRequest, api=namespace)
    @responds(schema=UserResponse, api=namespace)
    @namespace.response(404, 'No instance settings configured for this URL')
    @namespace.response(502, 'An error occurred while attempting to create the account')
    def post(self):
        """Registration Step 1"""
        parsed_request = request.parsed_obj
        user = parsed_request['user']
        account = parsed_request['account']
        instance_filters = {
        'settings.locale.name': parsed_request.get('locale', "US"),
        'type': "procurement" if "buyWith" in parsed_request.get("productType") else "default"
    }
        instance = instance_settings_repository().get_single_by_filter(instance_filters)
        if not instance:
            raise NotFound('No instance settings configured for this URL')


        user, account = registration_service().register_user(instance, account, user, user['username'])
        
        return user

    @role_required([UserRole.ORG_ADMIN])
    @accepts(schema=AccountRegisterRequest, api=namespace)
    @responds(schema=UserResponse, api=namespace)
    @namespace.response(404, 'User not found')
    def put(self):
        """Registration Step 2"""
        user = user_repository().get_single(request.user['_id'])
        if not user:
            raise NotFound('User not found')

        account_request = request.parsed_obj['account']
        account = account_repository().get_single(user['accountId'])
        instance = instance_settings_repository().get_single(account['instance']['_id'])
        stripe_setting_type = stripe_service().get_stripe_setting_type(instance['type'], account['type'])

        # If Stripe subscription is not required, create Sage/Stripe customer records and set status to active
        if instance['settings']['stripe'][stripe_setting_type]['required'] == False:
            account_request['status'] = AccountStatus.ACTIVE.value
            stripe_customer = stripe_service().create_customer(user['username'], account['company']['name'])
            _create_customer(account, account_request['company'], user, stripe_customer.get('id'), account_request)

        account_repository().patch(user['accountId'], account_request, user['username'])
        return user


@namespace.route('/subscription')
class Subscription(Resource):
    @role_required(roles=[UserRole.ORG_ADMIN, UserRole.FINANCE])
    @accepts(schema=AccountSubscriptionRequest, api=namespace)
    @responds(schema=AccountSubscriptionResponse, api=namespace)
    @namespace.response(404, 'User not found')
    def put(self):
        """Registration Step 3"""
        data = request.parsed_obj
        user = user_repository().get_single(request.user['_id'])
        if not user:
            raise NotFound('User not found')
        account_update = {'status': AccountStatus.PENDING_FINANCE.value}
        checkout_session = {}
        subscription_options = data.get('subscriptionOptions')
        if subscription_options:  # option 1 or 2
            subscription_frequency = subscription_options['subscriptionFrequency']
            account_update = {
                'status': AccountStatus.PENDING_STRIPE.value,
                'subscriptionFrequency': subscription_frequency
            }
            if data['createSetupSubscriptionCheckoutSession']:
                account = account_repository().get_single(
                    user['accountId'], {'stripe.trialPeriodUsed': 1, 'instance._id': 1})
                instance = instance_settings_repository().get_single(account['instance']['_id'])
                checkout_session = stripe_service().create_subscription_checkout_session(
                    instance, subscription_frequency, account.get('stripe', {}).get('trialPeriodUsed'), account.get('type'))
        account_repository().patch(user['accountId'], account_update, user['username'])
        return checkout_session

    @role_required(roles=[UserRole.ORG_ADMIN, UserRole.FINANCE])
    @accepts(schema=AccountSubscriptionActivateRequest, api=namespace)
    @responds(schema=AccountSubscriptionActivateResponse, api=namespace)
    @namespace.response(404, 'Resource not found')
    def post(self):
        """Registration Step 4"""
        data = request.parsed_obj
        stripe_checkout_session = stripe_service().get_checkout_session(data['checkoutSessionId'])
        if not stripe_checkout_session:
            raise NotFound('Checkout session not found')

        user = user_repository().get_single(request.user['_id'])
        if not user:
            raise NotFound('User not found')

        account = account_repository().get_single(user['accountId'])
        account_update = {
            'status': AccountStatus.ACTIVE.value,
            'stripe': {
                'subscription': {
                    'id': stripe_checkout_session.subscription
                }
            }
        }

        _create_customer(account, account['company'], user, stripe_checkout_session.customer, account_update)
        account = account_repository().patch(user['accountId'], account_update, user['username'])

        instance = instance_settings_repository().get_single(account['instance']['_id'])
        email_service().send_new_account_created_email(instance, user, account)


@namespace.route('')
@namespace.response(400, 'Bad Request')
class Users(Resource):
    @role_required(GIVEWITH_ROLES + [UserRole.ORG_ADMIN, UserRole.USER_ADMIN, UserRole.FINANCE])
    @accepts(query_params_schema=UserSearchRequest, api=namespace)
    @responds(schema=UserSearchResponse, api=namespace)
    def get(self):
        """Search Users"""
        params = request.parsed_query_params
        params['accountId'] = get_validated_account_id(params.get('accountId'), request)
        params['departmentType'] = UserDepartmentType.PORTAL.value
        totalCount, users = user_repository().get_page(params)
        return {'totalCount': totalCount, 'results': users}

    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_FINANCE, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.USER_ADMIN])
    @accepts(schema=UserInviteRequest, api=namespace)
    @responds(schema=UserResponse, api=namespace)
    @namespace.response(502, 'An error occurred while attempting to invite this user')
    def post(self):
        """Invite User"""
        invited_user = request.parsed_obj
        error_message = 'An error occurred while attempting to invite this user'
        accountId = get_validated_account_id(invited_user.pop('accountId', None), request)
        account = account_repository().get_single(accountId)
        instance = instance_settings_repository().get_single(account['instance']['_id'])
        invited_user['app'] = "BuyWith" if  instance['type'] == InstanceType.PROCUREMENT.value else "SellWith"
        user = auth_service().create_user(invited_user, accountId, error_message, request.user['username'])
        return user


@namespace.route('/<string:id>')
@namespace.response(400, 'Bad Request')
@namespace.response(404, 'User not found')
class UserById(Resource):
    @role_required(GIVEWITH_ROLES + [UserRole.ORG_ADMIN, UserRole.USER_ADMIN])
    @responds(schema=UserResponse, api=namespace)
    def get(self, id):
        """Get User by ID"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        self._validate_access(request, id)
        user = user_repository().get_single(id)
        if not user:
            raise NotFound('User not found')
        return user

    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.USER_ADMIN])
    @accepts(schema=UserRequest, api=namespace)
    @responds(schema=UserResponse, api=namespace)
    @namespace.response(502, 'An error occurred while attempting to update this user')
    def put(self, id):
        """Update User"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        self._validate_access(request, id)
        user = user_repository().get_single(id)
        if not user:
            raise NotFound('User not found')

        updated_user = request.parsed_obj

        immutable_fields = ['oktaId', 'username', 'orgType', 'orgId']
        for field in immutable_fields:
            updated_user[field] = user[field]
        response = auth_service().update_user(id, updated_user, request.user['username'])
        if response.status_code != 200:
            raise BadGateway('An error occurred while attempting to update this user')

        new_roles = set(updated_user['roles']) != set(user['roles'])
        if new_roles and any(role in updated_user['roles'] for role in GIVEWITH_ROLES):
            account = account_repository().get_single(request.user['accountId'], {'instance._id': 1})
            instance = instance_settings_repository().get_single(account['instance']['_id'])
            email_service().send_role_update_email(instance, user, updated_user, request.user['username'])

        user = user_repository().get_by_username(updated_user['username'])
        return user

    def _validate_access(self, request: Request, id: ObjectId):
        if not has_role(GIVEWITH_ROLES, request.user) and not user_repository().has_access(id, request.user['accountId']):
            raise Forbidden('You do not have permission to access this resource')


@namespace.route('/salesforce')
class SalesforceUsers(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.USER_ADMIN])
    @accepts(schema=UserProvisionRequest(many=True), api=namespace)
    @responds(schema=UserProvisionResponse(many=True), api=namespace)
    def post(self):
        """Provision Salesforce Users"""
        users = request.parsed_obj
        error_message = 'An error occurred while attempting to invite this user'
        results = []

        for user in users:
            user['app'] = 'Salesforce'
            user['metadata'] = {'skipEmail': True}
            result = {'username': user['username']}
            results.append(result)

            try:
                accountId = get_validated_account_id(user.pop('accountId', None), request)
                user = auth_service().create_user(user, accountId, error_message, request.user['username'])
                result['id'] = user['_id']
            except HTTPException as ex:
                result['error'] = ex.description
            except:
                result['error'] = error_message

        return results


@namespace.route('/profile')
@namespace.response(404, 'User not found')
class UserProfile(Resource):
    @token_required
    @responds(schema=UserResponse, api=namespace)
    def get(self):
        """Get My Profile"""
        user = user_repository().get_single(request.user['_id'])
        if not user:
            raise NotFound('User not found')
        return user

    @token_required
    @accepts(schema=UserMyProfileRequest, api=namespace)
    @responds(schema=UserResponse, api=namespace)
    def put(self):
        """Update My Profile"""
        user = user_repository().get_single(request.user['_id'])
        if not user:
            raise NotFound('User not found')

        user.update(request.parsed_obj)
        user = user_repository().update(user, by=request.user['username'])
        return user


def _create_customer(account, company, user, stripe_customer_id, account_update):
    # Create Sage customer
    sage_customer_primary_contact_name, sage_customer = _create_sage_customer(
        account, company['name'], user, company['address'], stripe_customer_id)
    
    # Set Sage customer reference numbers
    account_update.update({
        'sageCustomerId': sage_customer.customerId,
        'sageRecordNo': sage_customer.recordNo
    })

    # Set Stripe customer reference numbers
    if 'stripe' not in account_update:
        account_update['stripe'] = {}
    account_update['stripe']['customerId'] = stripe_customer_id

    # Update Stripe customer record
    stripe_service().update_customer(stripe_customer_id, account['_id'], sage_customer.customerId)

    # Ensure finance user role
    if not has_role([UserRole.FINANCE], request.user):
        user_repository().patch(user['_id'], {'roles': [UserRole.FINANCE.value]}, user['username'])

    # Update Sage customer record
    _update_sage_customer(account, sage_customer_primary_contact_name, sage_customer.recordNo)


# TODO: Move to sage_service
def _create_sage_customer(account, company_name, user, address, stripe_customer_id):
    sage_customer_request = SageCustomer(
        NAME=company_name,
        DISPLAYCONTACT=SageContact(
            FIRSTNAME=user['first_name'],
            LASTNAME=user['last_name'],
            COMPANYNAME=company_name,
            EMAIL1=user['username'],
            MAILADDRESS=SageMailAddress(
                ADDRESS1=address['address1'],
                ADDRESS2=address['address2'],
                CITY=address['city'],
                STATE=address['stateProvince'],
                ZIP=address['postalCode'],
                COUNTRY=address['country']
            )
        ),
        GIVEWITH_ACCOUNT_ID=user['accountId'],
        STRIPE_CUSTOMER_ID=stripe_customer_id,
    )
    sage_customer = sage_service().create_customer(account, sage_customer_request)
    return sage_customer_request.DISPLAYCONTACT.CONTACTNAME, sage_customer


# TODO: Move to sage_service
def _update_sage_customer(account, sage_contact_name, sage_customer_record_no):
    customer_update = SageCustomer(
        CONTACT_LIST_INFO=[
            SageContactListInfo(
                CATEGORYNAME='Finance',
                CONTACT=SageContactListInfoContact(
                    NAME=sage_contact_name
                )
            )
        ]
    )
    sage_service().update_customer(account, customer_update, sage_customer_record_no)
