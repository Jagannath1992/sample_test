from pymongo.database import Database
from pymongo import MongoClient
from datetime import datetime
from bson.objectid import ObjectId

"""
Migrate the Active brands data into account collections and associtad new account id with brand's user
"""
name = '20230208152600'
dependencies= ['20221208212938']


def upgrade(db: Database):
    now = datetime.utcnow()

    brand_list = ["5c1415685b03bb0008c219f1", "63bc428c9c352f68a6cb8d83"]

    instance_id = db['instance_settings'].insert_one({
                    "name" : "Givewith for Sales Select US",
                    "description" : "Select Application Settings",
                    "settings" : {
                    "locale" : {
		                "_id": ObjectId("62d1bf7540b7c3440dddfc41"),
                        "_type" : "locale",
                        "name" : "US"
                    },
                    "loginUrl" : "https://login.nohardstops.com",
                    "portalUrl" : "http://localhost:8085",
                    "givewithEmail" : "assist@givewith.com"
                    },
                    "createdBy" : "admin@givewith.com",
                    "createdAt" : now,
                    "lastUpdatedBy" : "admin@givewith.com",
                    "lastUpdated" : now,
                    "status" : "active"
     }).inserted_id

    instance = {
        "_id" : ObjectId(instance_id),
        "_type" : "instance_settings",
        "name" : "Givewith for Sales Select US"
    }
    subscription = "sellwith_select"
    termsAccepted = True
    status = "ACTIVE"

    for brand in brand_list :
        brand_details = db["mm_brands"].find_one({"_id" : ObjectId(brand)})
        print(brand_details["name"])

        account_id = db['account'].insert_one({
                        "status": status,
                        "industry": {
                            "displayLabel": brand_details["industry"],
                            "subIndustry":  brand_details["industry"],
                        },
                        "company": {
                            "name": brand_details["name"],
                            "address": {
                                "address1": "",
                                "address2": "",
                                "city": "",
                                "stateProvince": "",
                                "postalCode": "",
                                "country": "",
                            },
                            "phoneNumber": "",
                            "website": "https://www.givewith.com/",
                        },
                        "instance" : instance,
                        "sageCustomerId": "",
                        "createdBy": "admin@givewith.com",
                        "createdAt": now,
                        "lastUpdatedBy": "admin@givewith.com",
                        "lastUpdated": now,
                        "termsAccepted": termsAccepted,
                        "type": "Sales",
                        "subscription" : "sellwith_select",
                        "givePercentageType": brand_details["givePercentageType"],
                        "givePercentageCurrency": brand_details["givePercentageCurrency"],
                    }).inserted_id
        print(account_id)

        user_update = {
        '$set': {
            'accountId': ObjectId(account_id),
            'lastUpdatedBy': 'admin@givewith.com',
            'lastUpdated': now
        }
    }

        db['user'].update_many({"orgId" : ObjectId(brand)}, user_update)


def downgrade(db: Database):
    pass


