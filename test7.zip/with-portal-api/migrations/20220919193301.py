import pymongo

"""
This scripts does the following:
1) update Instance Settings to support instance type
2) update Stripe settings for existing instances
3) convert custom labels to giveFields schema
"""
name = '20220919193301'
dependencies = ['20220902204440']


def upgrade(db: pymongo.database.Database):
    # update instance settings
    db['instance_settings'].update(
        {},
        {'$set': {
            'type': 'default',
            'settings.stripe.prices.required': True,
            'settings.stripe.prices.monthly.enabled': True,
            'settings.stripe.prices.annual.enabled': True,
        }},
        multi=True)

    # update accounts section

    # set up giveField with custom fields
    accounts_cursor = db['account'].find()
    for account in accounts_cursor:
        giveFields = {
            'customerName': {
                'label': 'Sell to Customer Name',
                'defaultValue': '',
                'displayOrder': 0,
                'required': True,
                'custom': False,
            },
            'customerId': {
                'label': 'Sell to Customer #',
                'defaultValue': '',
                'displayOrder': 1,
                'required': False,
                'custom': False,
            },
            'quoteNumber': {
                'label': 'Quote #',
                'defaultValue': '',
                'displayOrder': 2,
                'required': False,
                'custom': False,
            },
            'quoteAmount': {
                'label': 'Total Deal Value',
                'defaultValue': None,
                'displayOrder': 3,
                'required': True,
                'custom': False,
            },
            'description': {
                'label': 'Description',
                'defaultValue': '',
                'displayOrder': 4,
                'required': False,
                'custom': False,
            },
        }

        for i in range(1, 5):
            label = account.get(f'customLabel{i}')
            required = account.get(f'isRequired{i}', False)
            if label:
                giveFields[f'customField{i}'] = {
                    'label': label,
                    'defaultValue': '',
                    'displayOrder': 4 + i,
                    'required': required,
                    'custom': True,
                }

        # Update each account by ID
        db['account'].find_one_and_update(
            {'_id': account['_id']},
            {'$set': {
                'type': 'default',
                'giveFields': giveFields
            }})

    # remove custom fields after giveFields set
    db['account'].update_many(
        {},
        {'$unset': {
            'customLabel1': {},
            'customLabel2': {},
            'customLabel3': {},
            'customLabel4': {},
            'isRequired1': {},
            'isRequired2': {},
            'isRequired3': {},
            'isRequired4': {},
        }})


def downgrade(db: pymongo.database.Database):
    # downgrade instance_settings
    db['instance_settings'].update(
        {},
        {'$unset': {
            'type': 'default',
            'settings.stripe.prices.required': True,
            'settings.stripe.prices.monthly.enabled': True,
            'settings.stripe.prices.annual.enabled': True,
        }},
        multi=True)

    # restor custom fields
    accounts_cursor = db['account'].find()
    for account in accounts_cursor:
        giveFields = account.get('giveFields', {})
        for i in range(1, 5):
            custom = giveFields.get(f'customField{i}')
            if custom:
                custom_field_name = f'customLabel{i}'
                custom_field_value = custom.get('label')
                is_required_name = f'isRequired{i}'
                is_required_value = custom.get('required')

                db['account'].find_one_and_update(
                    {'_id': account['_id']},
                    {'$set': {
                        custom_field_name: custom_field_value,
                        is_required_name: is_required_value
                    }})

    db['account'].update(
        {},
        {'$unset': {
            'type': 'default',
            'giveFields': {},
        }},
        multi=True)
