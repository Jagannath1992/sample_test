import urllib.parse
import bson
from datetime import datetime


def parse_sort_params(args):
    """
    convert sort=key1:desc,key2:asc to [(key1 : -1), (key2 : 1)]
    """
    if not args:
        return [('$natural', 1)]

    sort_params = []
    args = args.split(',')

    for arg in args:
        s = arg.split(' ')
        s = list(filter(lambda a: a != '', s))

        if len(s) != 2:
            raise Exception('invalid sort param, expect: filed_name:order pair.')

        if s[1] != 'asc' and s[1] != 'desc':
            raise Exception('invalid sort order, expect: desc or asc.')

        key = s[0]
        order = 1 if s[1] == 'asc' else -1
        sort_params.append((key, order))

    return sort_params


def parse_pagination_params(page_size, page_num):
    if not page_size or not page_num:
        return 50, 0

    if not page_size.isnumeric() or not page_num.isnumeric():
        return 50, 0

    page_size = int(page_size)
    page_num = int(page_num)

    return page_size, page_size * (page_num - 1)


def parse_filter_params(args):
    """
    parse filter parameters in url.
    """
    if not args:
        return {}

    valid, parentheses_count = validate_parentheses(args)
    if not valid:
        raise Exception('invalid filter parentheses syntax')

    # encode string between single quotes
    scan = 0
    copy = []
    while scan < len(args):
        if args[scan] != '\'':
            copy.append(args[scan])
            scan += 1
        else:
            end = scan + 1
            while end < len(args) and args[end]!= '\'':
               end += 1

            copy.append(urllib.parse.quote(args[scan:end+1]))
            scan = end + 1

    args = ''.join(copy)

    args = args.split(' ')
    args = list(filter(lambda a: a != '', args))
    if len(args) == 0:
        return None

    if parentheses_count == 0:
        return parse_filter_helper(args)

    copy = []
    for arg in args:
        if arg.startswith('(') and len(arg) != 1:
            copy.append('(')
            copy.append(arg[1:len(arg)])
        elif arg.endswith(')') and len(arg) != 1:
            copy.append(arg[0:len(arg)-1])
            copy.append(')')
        else:
            copy.append(arg)

    args = copy
    stack = []
    for arg in args:
        if arg != ')':
            stack.append(arg)
        else:
            sub_params = []
            while len(stack) > 0:
                top = stack.pop()
                if top != '(':
                    sub_params.insert(0, top)
                else:
                    break

            stack.append(parse_filter_helper(sub_params))

    return parse_filter_helper(stack)


def parse_filter_helper(args):
    """
    parse list of filters.
    """
    if 'or' not in args:
        return parse_filter_and_only(args)
    else:
        result = []
        left = 0
        right = left + 1
        while right < len(args):
            if args[right] == 'or':
                result.append(parse_filter_and_only(args[left:right]))
                left = right + 1
                right = left + 1
            else:
                right += 1

        result.append(parse_filter_and_only(args[left:right]))

        return {'$or': result}


def parse_filter_and_only(args):
    """
    parse a list of filters which contains AND operator only
    'a eq b and c lt 3 and d ne true' -> [{a:b}, {c: {'$lt', 3}, {'d': {'$ne': True}}}]
    """
    scan = 0
    result = []
    while scan < len(args):
        if not isinstance(args[scan], str):
            result.append(args[scan])
            scan += 2
        else:
            result.append(parse_filter_pair(args, scan))
            scan += 4

    return {'$and': result}


def parse_filter_pair(params, index):
    """
    parse a simple filter pair to json that mongodb can understand
    'a eq b' -> {'a': 'b'}
    'a ne b' -> {'a': {$ne: 'b'}}
    """
    if index + 2 >= len(params):
        raise Exception('invalid filter syntax')

    name = params[index]
    op = params[index + 1]
    val = urllib.parse.unquote(params[index + 2])

    if val.startswith("'") and val.endswith("'"):
        val = val[1:len(val)-1]
    elif val == 'true':
        val = True
    elif val == 'false':
        val = False
    elif val.isnumeric():
        val = float(val)
    elif is_date(val):
        val = parse_date(val)
    elif bson.objectid.ObjectId.is_valid(val):
        val = bson.objectid.ObjectId(val)

    if op == 'eq':
        return {name: val}
    elif op == 'ne':
        return {name: {'$ne': val}}
    elif op == 'gt':
        return {name: {'$gt': val}}
    elif op == 'ge':
        return {name: {'$gte': val}}
    elif op == 'lt':
        return {name: {'$lt': val}}
    elif op == 'le':
        return {name: {'$lte': val}}

    raise Exception('Invalid filer operator. expect: eq, ne, gt, ge, lt, le, got:', op)


def is_operator(s):
    return s in ['eq', 'ne', 'gt', 'ge', 'lt', 'le', 'and', 'or']


def validate_parentheses(s):
    """
    check parentheses pattern correctness, and count parentheses pair:
    """
    count = 0
    max_count = 0
    for c in s:
        if c == '(':
            count += 1
            max_count += 1
        if c == ')':
            count -= 1
            if count < 0: return False, 0

    return count == 0, max_count


def is_date(s):
    try:
        datetime.strptime(s, '%Y-%m-%dT%H:%M:%S.%fZ')
        return True
    except:
        return False


def parse_date(s):
    return datetime.strptime(s, '%Y-%m-%dT%H:%M:%S.%fZ')