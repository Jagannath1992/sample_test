from matchmaking import db

sasb_vocab = list(db().coll_vocabulary.find({'type': 'sasb'}))

for theme in sasb_vocab:
    if theme['label'] == 'GHG Emissions':
        theme['camelCaseName'] = 'gHGEmissions'

    if theme['label'] == 'Ecological Impacts':
        theme['camelCaseName'] = 'biodiversityImpacts'

    if theme['label'] == 'Human Rights & Community Relations':
        theme['camelCaseName'] = 'humanRightsAndCommunityRelations'

    if theme['label'] == 'Business Ethics':
        theme['camelCaseName'] = 'businessEthicsAndTransparencyOfPayments'

    if theme['label'] == 'Access and Affordability':
        theme['camelCaseName'] = 'accessAndAffordability'
        
    db().coll_vocabulary.replace_one(filter={'_id': theme["_id"]}, replacement=theme)