from portal.shared.email.validator import EmailAddress, EmailValidator


def test_good_address():
    # arrange
    data = 'goodaddress@somedomain.org'

    # act
    address = EmailValidator().validate(data)

    # assert
    assert address
    assert type(address) == EmailAddress
    assert address.username == 'goodaddress'
    assert address.domain == 'somedomain.org'


def test_bad_address():
    # arrange
    data = '@badaddress.org'

    # act
    address = EmailValidator().validate(data)

    # assert
    assert not address
