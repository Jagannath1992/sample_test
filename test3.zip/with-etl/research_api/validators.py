# TODO: turn this into a folder, with a file for each data source
import logging
import pandas as pd

from . import mongodb
from .logger import log_exception, PipelineLogger

from .utils import *
from .models import v, get_schemata, MSCI_TRANSLATE_COLUMNS

from .mongodb import get_vocabulary_industries
from .loggly import get_logger


def clean(dataset, data):
    if dataset == 'CSRIT':
        return _validate_csrit(dataset, data)

    elif dataset == 'MSCI':
        return _validate_msci(dataset, data)

    elif dataset == 'TVL':
        pass
        return data

    elif dataset == 'SASB':
        return _clean_sasb(data)

    elif dataset == 'CSRHUB':
        pass
        return data

    elif dataset == 'NIELSEN':
        pass
        return data

    else:
        raise DatasetNotFound()


def _validate_csrit(dataset, data):
    lookup_data, data, narratives = data
    normalization_schema, validation_schema = get_schemata(dataset, lookup_data[0])

    def clean(raw_data, log_prefix=''):
        cleaned_data = []

        for row in raw_data:
            brand_name = row.get('company name', '')
            try:
                cleaned_row = clean_row(row, normalization_schema, validation_schema)
                cleaned_data.append(cleaned_row)

            except ValidationError as e:
                if 'brandId' in e.args[0]:
                    # no logs if validation fails on brandId
                    pass
                else:
                    PipelineLogger.get_instance('CSRIT').log_exception(f'{log_prefix} - {brand_name} - {e}')
            except Exception as e:
                PipelineLogger.get_instance('CSRIT').log_exception(f'{log_prefix} - {brand_name} - {e}')

        return cleaned_data

    return clean(data, 'CSRIT'), clean(narratives, 'NARRATIVE')


def clean_row(row, normalization_schema, validation_schema):
    normalized_row = _normalize_input(row, normalization_schema)
    valid = _validate_input(normalized_row, validation_schema)
    if valid:
        return normalized_row
    else:
        raise ValidationError('Validation did not pass')


def _validate_input(row, schema):
    valid = v.validate(row, schema)
    if v.errors:
        raise ValidationError(v.errors)
    else:
        return valid


def _normalize_input(row, schema):
    normalized = v.normalized(row, schema)
    if v.errors:
        raise ValidationError(v.errors)
    else:
        return normalized


def _validate_msci(dataset, df_documents):

    get_logger().info(f'Validation start for {dataset}')

    get_logger().info(f'Fetch only industries vocabulary for {dataset}')
    vocabulary_industries = get_vocabulary_industries()
    get_logger().info(f'Total Industries Vocabulary found in database {len(vocabulary_industries)}')

    get_logger().info(f'Removing entries with invalid industry name for {dataset}')
    # Remove entries with invalid industry name
    df_documents = _remove_invalid_entries_msci(df_documents, filter_list=vocabulary_industries)

    get_logger().info(f'Validation finished for {dataset}')
    return df_documents

def _remove_invalid_entries_msci(df_target, filter_list):
    invalid_entries = df_target[~df_target['esg_industry'].isin(filter_list)]
    
    if not invalid_entries.empty:
        df_target = df_target[df_target['esg_industry'].isin(filter_list)]

        invalid_brands = ', '.join(invalid_entries['msciId'].tolist())

        invalid_industries = map(str, invalid_entries['esg_industry'].tolist())
        invalid_industries = ', '.join(set(invalid_industries))

        log_msg = f'Invalid industry in the following brands ticker: {invalid_brands}' \
                + f'\nInvalid industries: {invalid_industries}'
        log_error(log_msg, dataset='MSCI')

    return df_target


def _clean_sasb(data):
    for d in data.values():
        _sasb_remove_note_line(d)

    sasb_brands = data['sasb_mapping']

    # Filter out rows with bad ISINs
    _filter = sasb_brands.index.map(lambda x: len(str(x)) in range(11,14))

    invalid_row_nums = []
    for index in range(0, len(sasb_brands)):
        if not _filter[index]:
            invalid_row_nums.append(index)
    logging.warn(f'Invalid rows: {invalid_row_nums}')

    # Apply filter
    sasb_brands = sasb_brands.loc[_filter]

    return data


def _sasb_remove_note_line(data):
    """ SASB data usually contains a "NOTE" line at the very end of files which must be removed """
    note_str = "NOTE: Use of this file is restricted to organizations that have acquired licensed rights to SASB's IP and copyrighted material"
    last_row = data.iloc[-1]

    if '_name' in last_row.__dict__ and data.iloc[-1]._name == note_str:
        # Drop the last row
        data = data.iloc[:-1]
