# from matchmaking import db

# """
# adding one field called payment type to all the records in mm_brands.
# for old bands records, it should default to ‘payAsYouGo’
# """

# default_payment = 'payAsYouGo'
# brands = list(db().coll_brands.find())

# for brand in brands:
#     brand['paymentType'] = default_payment
#     db().coll_brands.replace_one(filter={'_id': brand["_id"]}, replacement=brand)





# Commenting out because migration 68 changes this to a new field
pass
