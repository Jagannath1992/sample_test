import datetime

import pytest
from pymongo.database import Database

from portal.shared.repository import DocumentRepository, build_update_query


@pytest.fixture
def document_repository(db):
    yield DocumentRepository(db, db['document'])


def get_document():
    return {
        'name': 'Document',
        'description': 'This is a test document'
    }


def test_insert(db: Database, document_repository: DocumentRepository, frozen_utcnow):
    # arrange
    expected = get_document()

    # act
    saved_doc = document_repository.insert(expected)
    expected['createdAt'] = frozen_utcnow
    expected['lastUpdated'] = frozen_utcnow
    actual = db.document.find_one({'_id': saved_doc.get('_id')})

    # assert
    assert saved_doc is not None
    assert actual == expected


def test_insert_many(
        db: Database, document_repository: DocumentRepository, frozen_utcnow):
    # arrange
    expected = [get_document(), get_document()]

    # act
    inserted_ids = document_repository.insert_many(expected)
    for document in expected:
        document['createdAt'] = frozen_utcnow
        document['lastUpdated'] = frozen_utcnow
    actual = list(db.document.find({'_id': {'$in': inserted_ids}}))

    # assert
    assert inserted_ids is not None
    assert actual == expected


def test_get_many_no_condition(db: Database, document_repository: DocumentRepository):
    # arrange
    expected = [get_document(), get_document()]
    db.document.insert_many(expected)

    # act
    actual = document_repository.get_many()

    # assert
    assert actual == expected


def test_get_many_with_conditions(db: Database, document_repository: DocumentRepository):
    # arrange
    other_document = get_document()
    expected_document = get_document()
    db.document.insert_many([other_document, expected_document])

    # act
    actual = document_repository.get_many({'_id': expected_document['_id']})

    # assert
    assert actual[0] == expected_document


def test_get_single(db: Database, document_repository: DocumentRepository):
    # arrange
    other_document = get_document()
    expected_document = get_document()
    db.document.insert_many([other_document, expected_document])

    # act
    actual = document_repository.get_single(expected_document['_id'])

    # assert
    assert actual == expected_document


def test_get_single_by_filter(db: Database, document_repository: DocumentRepository):
    # arrange
    other_document = get_document()
    other_document['name'] = 'The OtherDoc'
    expected_document = get_document()
    db.document.insert_many([other_document, expected_document])

    # act
    actual = document_repository.get_single_by_filter({'name': expected_document['name']})

    # assert
    assert actual == expected_document


def test_get_single_with_projection(db: Database, document_repository: DocumentRepository):
    # arrange
    other_document = get_document()
    expected_document = get_document()
    db.document.insert_many([other_document, expected_document])
    expected = {
        '_id': expected_document['_id'],
        'name': expected_document['name']
    }

    # act
    actual = document_repository.get_single(expected_document['_id'], {'name': 1})

    # assert
    assert actual == expected


def test_update(db: Database, document_repository: DocumentRepository, frozen_utcnow):
    # arrange
    time_change = datetime.timedelta(days=-1)
    one_hour_ago = frozen_utcnow + time_change
    original = get_document()
    original['createdAt'] = one_hour_ago
    original['lastUpdated'] = one_hour_ago
    expected = {
        **original.copy(),
        'name': 'New Document',
        'description': 'This is a new test document'
    }
    expected['_id'] = db.document.insert_one(original).inserted_id

    # act
    response = document_repository.update(expected)
    expected['lastUpdated'] = frozen_utcnow
    actual = db.document.find_one({'_id': expected['_id']})

    # assert
    assert response == expected
    assert actual == expected


def test_update_references(db: Database, document_repository: DocumentRepository, frozen_utcnow):
    main_doc = get_document()
    ref_id = db.document.insert_one(main_doc).inserted_id
    original_settings = {
        'settings_type': {
            '_id': ref_id,
            '_type': 'old type',
            'name': 'old name'
        }
    }
    expected_settings = {
        'settings_type': {
            '_id': ref_id,
            '_type': 'updated_type',
            'name': 'updated_name'
        }
    }
    ref_main_doc = {
        'name': 'Reference Document',
        'description': 'This is a test reference document',
        'settings': original_settings
    }

    db.document.insert_one(ref_main_doc)
    document_repository.update_references('settings.settings_type', ref_id, {'name': 'updated_name', '_type': 'updated_type'})
    actual = db.document.find_one({'settings.settings_type._id': ref_id})
    # assert
    assert actual['settings'] == expected_settings


def test_delete(db: Database, document_repository: DocumentRepository):
    # arrange
    document_id = db.document.insert_one(get_document()).inserted_id
    assert db.document.count_documents({'_id': document_id}) == 1

    # act
    response = document_repository.delete(document_id)

    # assert
    assert response is True
    assert db.document.count_documents({'_id': document_id}) == 0


def test_exists_by_filter(db: Database, document_repository: DocumentRepository):
    doc = get_document()
    db.document.insert_one(doc)

    # act
    response = document_repository.exists_by_filter({'description': doc['description']})

    # assert
    assert response is True
    db.document.delete_many({})
    assert document_repository.exists_by_filter({'name': doc['name']}) is False

def test_exists(db: Database, document_repository: DocumentRepository):
    # arrange
    document_id = db.document.insert_one(get_document()).inserted_id

    # act
    response = document_repository.exists(document_id)

    # assert
    assert response is True
    db.document.delete_many({})
    assert document_repository.exists(document_id) is False


def test_build_update(document_repository: DocumentRepository):
    data = {
        'name': 'tester',
        'nested': {
            'id': 42,
            'type': 'test doc'
        },
        'collection': [
            {
                'thing': 'one'
            },
            {
                'thing': 'two'
            }
        ]
    }

    expected = {
        '$set': {
            'name': 'tester',
            'nested.id': 42,
            'nested.type': 'test doc'
        },
        '$push': {
            'collection': {'$each': [
                {'thing': 'one'}, {'thing': 'two'}
            ]}
        }
    }

    response = build_update_query(data)

    assert response == expected
