# pylint: disable-msg=invalid-name
from bson import ObjectId

admin_token = {
    'sub': '5b38f270-675b-4588-ab14-98076eec1555',
    'event_id': 'da26e90e-2cf0-4732-90b2-50b361824757',
    'token_use': 'access',
    'scope': 'admin',
    'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
    'jti': '6729c94b-e601-4c87-bf2f-cbebd44cc421',
    'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
    'username': '5b38f270-675b-4588-ab14-98076eec1555',
    'resource_ids': [
        '5c1415685b03bb0008c21b06'
    ],
    'version': 1,
    'user_id': '5d1a3962d5b3a53c05437ede',
    'email': 'elizabeth.chan@givewith.com',
    '_id': '5d1a3962d5b3a53c05437ede',
    'active': True,
    'type': 'admin',
    'first_name': 'Elizabeth',
    'last_name': 'Chan',
    'orgId': '5c1415685b03bb0008c21b06',
    'orgType': 'brand',
    'name': 'Elizabeth Chan',
    'uuid': 'cfc92a74-f0b8-477e-a366-11303d10fcb2',
    'cognito-id': '5b38f270-675b-4588-ab14-98076eec1555',
    'departmentType': 'Executive',
    'title': 'test title123',
    'departmentName': 'test department name123',
    'last_login': 'Thu, 13 Aug 2020 17:22:41 GMT'
}

client_token = {
    'sub': '5b38f270-675b-4588-ab14-98076eec1555',
    'event_id': 'da26e90e-2cf0-4732-90b2-50b361824757',
    'token_use': 'access',
    'scope': 'admin',
    'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
    'jti': '6729c94b-e601-4c87-bf2f-cbebd44cc421',
    'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
    'username': '5b38f270-675b-4588-ab14-98076eec1555',
    'resource_ids': [
        '5c1415685b03bb0008c21b06'
    ],
    'version': 1,
    'user_id': '5d1a3962d5b3a53c05437ede',
    'email': 'elizabeth.chan@givewith.com',
    '_id': '5d1a3962d5b3a53c05437ede',
    'active': True,
    'type': 'client',
    'first_name': 'Elizabeth',
    'last_name': 'Chan',
    'orgId': '5c1415685b03bb0008c21b06',
    'orgType': 'brand',
    'name': 'Elizabeth Chan',
    'uuid': 'cfc92a74-f0b8-477e-a366-11303d10fcb2',
    'cognito-id': '5b38f270-675b-4588-ab14-98076eec1555',
    'departmentType': 'Executive',
    'title': 'test title123',
    'departmentName': 'test department name123',
    'last_login': 'Thu, 13 Aug 2020 17:22:41 GMT'
}

user = {
    '_id': '5d1a3962d5b3a53c05437ede',
    'active': True,
    'type': 'admin',
    'first_name': 'Elizabeth',
    'last_name': 'Chan',
    'username': 'elizabeth.chan@givewith.com',
    'orgId': ObjectId('5c1415685b03bb0008c21b06'),
    'orgType': 'brand',
    'name': 'Elizabeth Chan',
    'uuid': 'cfc92a74-f0b8-477e-a366-11303d10fcb2',
    'cognito-id': '5b38f270-675b-4588-ab14-98076eec1555',
    'departmentType': 'Executive',
    'phoneNumber': '(111) 111 1111',
    'businessAddress': 'test business address',
    'title': 'test title123',
    'departmentName': 'test department name123',
    'notes': 'testing',
    'last_login': '2020-08-12T15:06:31.417Z'
}

deals = [
    {
        '_id' : ObjectId('5da63623e3eb8a0b0b1dd9c6'),
        'client' : ObjectId('5c1415685b03bb0008c222da'),
        'deliverables' : {
            'givewithCustomer' : {
                'deliverables' : [
                    {
                        'name' : 'Photos',
                        'url' : ('https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/'
                                 '5da640c88ef36d7aa53fd650/rebuilding_together__1571176901554.jpg'),
                        'display' : True
                    },
                    {
                        'name' : 'LongFormVideo',
                        'url' : ('https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/'
                                 '5da63623e3eb8a0b0b1dd9c6/rebuilding_together__1571174231178.jpg'),
                        'display' : True
                    },
                    {
                        'name' : 'ShortFormVideo',
                        'url' : ('https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/'
                                 '5da640c88ef36d7aa53fd650/rebuilding_together__1571176901554.jpg'),
                        'display' : True
                    }
                ]
            },
            'client' : {
                'deliverables' : [
                    {
                        'name' : 'Photos',
                        'url' : ('https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/'
                                 '5da640c88ef36d7aa53fd650/rebuilding_together__1571176901554.jpg'),
                        'display' : True
                    },
                    {
                        'name' : 'LongFormVideo',
                        'url' : ('https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/'
                                 '5da63623e3eb8a0b0b1dd9c6/rebuilding_together__1571174231178.jpg'),
                        'display' : True
                    },
                    {
                        'name' : 'ShortFormVideo',
                        'url' : ('https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/'
                                 '5da640c88ef36d7aa53fd650/rebuilding_together__1571176901554.jpg'),
                        'display' : True
                    }
                ]
            }
        },
        'fundingAmount' : 3500,
        'givewithCustomer' : ObjectId('5c1415685b03bb0008c21b06'),
        'givewithCustomerRole' : 'buyer',
        'givewithCustomerUser' : '5d1a3962d5b3a53c05437ede',
        'name' : 'test emails content 1015',
        'selectedProgram' : ObjectId('5b918c868553ef0007f76022'),
        'status' : 'COMPLETE',
        'slug': '5da63623e3eb8a0b0b1dd9c6',
        'password': 'D0cm14er6B',
        'totalBudget' : 250000,
        'givewithPortion' : 5000.0,
        'currency' : 'USD'
    },
    {
        '_id' : ObjectId('5da63623e3eb8a0b0b1dd9c7'),
        'client' : ObjectId('5c1415685b03bb0008c222da'),
        'fundingAmount' : 3500,
        'givewithCustomer' : ObjectId('5c1415685b03bb0008c21b06'),
        'givewithCustomerRole' : 'buyer',
        'givewithCustomerUser' : '5da631c8e3eb8a0b0b1dd356',
        'name' : 'test emails content 1015',
        'password' : '1Z7rx46lckm0',
        'selectedProgram' : ObjectId('5c387b71a08c41000a179495'),
        'status' : 'PAYMENT_PENDING',
        'totalBudget' : 250000,
        'givewithPortion' : 5000.0,
        'currency' : 'USD'
    },
    {
        '_id' : ObjectId('5da63623e3eb8a0b0b1dd9c8'),
        'client' : ObjectId('5c1415685b03bb0008c222da'),
        'fundingAmount' : 3500,
        'givewithCustomer' : ObjectId('5c1415685b03bb0008c21b07'),
        'givewithCustomerRole' : 'buyer',
        'givewithCustomerUser' : '5d1a3962d5b3a53c05437ede',
        'name' : 'test emails content 1015',
        'password' : '1Z7rx46lckm0',
        'selectedProgram' : ObjectId('5c387b71a08c41000a179495'),
        'status' : 'COMPLETE',
        'totalBudget' : 250000,
        'givewithPortion' : 5000.0,
        'currency' : 'USD'
    }
]

nonprofits = [
    {
        '_id': ObjectId('5b2c0100e3dde1001ae1771a'),
        'applicationFormName': '',
        'createdAt': '2018-06-21T19:48:16.402000Z',
        'createdBy': '',
        'description': 'Black Girls CODE introduces computer coding lessons to young girls from \
            underrepresented communities through workshops and after school programs. Black Girls CODE is devoted to showing \
            the world that black girls can code, and so much more.',
        'descriptionShort': '',
        'editing': True,
        'givewithAdmin':  '5d767cecd5b3a526195f7300',
        'isValid': True,
        'lastUpdated': '2020-03-23T14:33:10.216Z',
        'name': 'Black Girls CODE',
        'notes': '',
        'slug': 'black-girls-code',
        'status': '',
        'videoFallback': 'https://s3.amazonaws.com/givewith-campaign-assets. \
            production/nonprofits/5b2c0100e3dde1001ae1771a/GW_Black-Girls-Code_NPO_LND_1560x780_1545101479976.jpg',
        'vimeoID': '309525336',
    },
    {
        '_id': ObjectId('5b29101ce3dde10019e17743'),
        'applicationFormName': '',
        'givewithAdmin': ObjectId('5d767cecd5b3a526195f7300'),
        'slug': 'first-book',
        'editing': True,
        'status': '',
        'percentComplete': 0,
        'createdAt': '2018-06-19T14:15:56.561Z',
        'lastUpdated': '2018-12-31T17:40:05.674Z',
        'createdBy': '',
        'notes': '',
        'videoFallback': '',
        'vimeoID': '309557558',
        'description': 'First Book transforms the lives of children in need by improving access to \
            quality education. From books to backpacks, to technology and toothpaste, First Book \
            delivers critical tools for learning and life.',
        'descriptionShort': '',
        'isValid': True,
        'name': 'First Book'
    },
    {
        '_id': ObjectId('5b29101ce3dde10019e1773b'),
        'applicationFormName': '',
        'createdAt': '2018-06-19T14:15:56.506000Z',
        'createdBy': '',
        'description': ('Waterkeeper Alliance strengthens and grows a global network of grassroots leaders protecting'
                        'everyone’s right to clean water. From Alaska to the Himalayas, the Great Lakes to Australia,'
                        'the Waterkeeper movement defends the fundamental human right to drinkable, fishable and '
                        'swimmable waters, and combines firsthand knowledge of local waterways with an unwavering '
                        'commitment to the rights of communities.'),
        'descriptionShort': '',
        'givewithAdmin': '5d767cecd5b3a526195f7300',
        'isValid': True,
        'lastUpdated': '2020-05-19T21:53:40.710Z',
        'name': 'Waterkeeper Alliance',
        'notes': '',
        'slug': 'waterkeeper-alliance',
        'status': '',
        'videoFallback': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/\
            nonprofits/5b29101ce3dde10019e1773b/GW_Waterkeeper_NPO_LND_1560x780_1545178108093_1584563008631.jpg',
        'vimeoID': ''
    },
    {
        '_id': ObjectId('5b29101ce3dde10019e1773c'),
        'applicationFormName': '',
        'createdAt': '2018-06-19T14:15:56.513000Z',
        'createdBy': '',
        'description': 'Since 1896, VOA has supported and empowered America\'s most vulnerable \
            groups, including veterans, at-risk youth, the frail elderly, men and women returning \
            from prison, homeless individuals and families, people with disabilities, and those recovering \
            from addictions.',
        'descriptionShort': 'Volunteers of America short description.',
        'editing': True,
        'givewithAdmin': '5d767cecd5b3a526195f7300',
        'isValid': True,
        'lastUpdated': '2020-07-23T14:05:36.312Z',
        'name': 'Volunteers of America test',
        'notes': '',
        'slug': 'volunteers-of-america',
        'status': '',
        'videoFallback': ('https://s3.amazonaws.com/givewith-campaign-assets.staging/nonprofits/'
                          '5b29101ce3dde10019e1773b/GW_Waterkeeper_NPO_LND_1560x780_1545178108093_1584563008631.jpg'),
        'vimeoID': ''
    }
]

programs = [
    {
        '_id': ObjectId('5c387b71a08c41000a179495'),
        'active': True,
        'budget': 123,
        'cashContributions': 54545,
        'createdAt': '2019-01-11T11:18:09.593Z',
        'dataMeasurementType': ObjectId('5af48f88a64082a02a943c08'),
        'description': '**Testing Program**',
        'evidenceDescription': [
            'N/A'
        ],
        'ignoreThreshold': True,
        'imageLandscape': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/ \
            programs/5c387b71a08c41000a179495/0J3A1193_1547205491763.jpg',
        'imagePortrait': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/ \
            programs/5c387b71a08c41000a179495/0J3A0177_1547205491704.jpg',
        'impactMultipleVisibility': True,
        'inKindContributions': 6565,
        'isValid': True,
        'isValidNonprofit': True,
        'lastUpdated': '2020-06-26T14:07:11.225Z',
        'name': 'Katarina\'s PGRM',
        'nonprofit': ObjectId('5c387a30a08c41000a17947f'),
        'nonprofitPartners': True,
        'notes': 'Test internal notes ',
        'outputs': [
            {
                'description': 'Beneficiaries directly served',
                'quantity': 0,
                'scaleType': ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description': 'test output',
                'quantity': 2344,
                'scaleType': ObjectId('5af4a134a64082a02a943c13')
            }
        ],
        'previewImage': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/ \
            programs/5c387b71a08c41000a179495/5c387b71a08c41000a179495.jpg',
        'slug': 'katarina-s-pgrm',
        'version': 2,
    },
    {
        '_id' : ObjectId('5bf3201e0f36530008cffc46'),
        'active' : True,
        'budget' : 300000,
        'createdAt' : '2018-11-19T20:42:06.234Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c09'),
        'description' : 'Code Clubs are an opportunity for a small group of students between the ages of 10-17 to receive intensive training and mentoring to develop their skills sets in one or more coding technologies.',
        'ignoreThreshold' : True,
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5bf3201e0f36530008cffc46/GW_Black-Girls-Code_NY_PRG_LND_1536x860_1545101609941.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5bf3201e0f36530008cffc46/GW_Black-Girls-Code_NY_PRG_PRT_2880x3840_1545101599065.jpg',
        'impactMultipleVisibility' : False,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-02-27T19:32:28.593Z',
        'name' : 'Teach young women of color key coding and tech skills',
        'nonprofit' : ObjectId('5b2c0100e3dde1001ae1771a'),
        'slug' : 'x-7',
        'notes' : 'this program can take place in several cities across the country',
        'approachDuration' : ObjectId('5d44b3b4d5b3a55e9e513d27'),
        'nonprofitPartners' : False,
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5bf3201e0f36530008cffc46/5bf3201e0f36530008cffc46.jpg',
        'vimeoID' : '356520412'
    },
    {
        '_id' : ObjectId('5b918c868553ef0007f76022'),
        'active' : True,
        'createdAt' : '2018-09-06T20:22:30.273Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c08'),
        'description' : 'Books by and about underrepresented groups are disproportionately absent in children\'s literature – the Stories for All Project™  \
            is First Book\'s market-driven solution to increasing diverse voices, and making the best books representing diverse characters \
            and life circumstances available and affordable to educators supporting kids in need.\n\n\nTo date, the Stories for All Project™ \
            is the largest worldwide collection of curated inclusive content, has launched books previously only available in hardcover in \
            affordable paperback formats, and influenced publisher decisions in making new, bilingual titles available at retail.  In a survey of \
            the First Book Network, respondents reported that access to diverse books has sparked new programming and curriculum activities focused \
            on diverse cultures and facilitated learning about their own or new cultures--often for the first time. ',
        'ignoreThreshold' : True,
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b918c868553ef0007f76022/placeholder-landscape_1544546838498.png',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b918c868553ef0007f76022/placeholder-portrait_1544546834837.png',
        'impactMultipleVisibility' : False,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2019-09-04T14:45:28.374Z',
        'name' : 'Diversify reading materials for children in need',
        'nonprofit' : ObjectId('5b29101ce3dde10019e17743'),
        'notes' : 'Location: This project is a national project, but it can be customized to specific target markets, schools, counties or states, etc. ',
        'slug' : 'sotires',
        'approachDuration' : ObjectId('5d44b3b4d5b3a55e9e513d27'),
        'nonprofitPartners' : True,
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5b918c868553ef0007f76022/5b918c868553ef0007f76022.jpg',
        'vimeoID' : '383165335'
    },
    {
        '_id' : ObjectId('5b71aab81b21cb00106d347f'),
        'active' : True,
        'approachDuration' : ObjectId('5d44b3b4d5b3a55e9e513d27'),
        'budget' : 167308,
        'cashContributions' : 0,
        'createdAt' : '2018-08-13T15:58:48.060Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c09'),
        'description' : 'Trash and plastic pollute our waterways and communities.  This program invites community members to engage in clean-ups, and raises awareness of protecting waterways for healthy habitats and communities.',
        'ignoreThreshold' : True,
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b71aab81b21cb00106d347f/GW_Coastal-Cleanup_Waterkeeper_PRG_LND_1536x860_1545177831492.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b71aab81b21cb00106d347f/GW_Coastal-Cleanup_Waterkeeper_PRG_PRT_2880x3840_1545177823492.jpg',
        'impactMultipleVisibility' : False,
        'inKindContributions' : 10000,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-06-30T14:56:51.130Z',
        'name' : 'Remove trash and plastic pollution from waterways',
        'nonprofit' : ObjectId('5b29101ce3dde10019e1773b'),
        'nonprofitPartners' : True,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5b71aab81b21cb00106d347f/5b71aab81b21cb00106d347f.jpg',
        'slug' : 'waterkeeper-coastal-cleanup',
        'version' : 2,
        'vimeoID' : '357617650',
        'currency' : 'EUR'
    },
    {
        '_id' : ObjectId('5b86badbfa8cf800104c382f'),
        'active' : True,
        'budget' : 135000,
        'createdAt' : '2018-08-29T15:25:15.177Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c09'),
        'description' : 'The Volunteers of America National Veterans Resource Squad engages veterans to lead efforts to reach at-risk veterans through suicide prevention, peer support, and local resource navigation.',
        'ignoreThreshold' : True,
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b86badbfa8cf800104c382f/GW_NVRS_Volunteers-of-America_PRG_LND_1536x860_1545078220361.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b86badbfa8cf800104c382f/GW_NVRS_Volunteers-of-America_PRG_PRT_2880x3840_1545078207695.jpg',
        'impactMultipleVisibility' : False,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-07-23T14:05:36.314Z',
        'name' : 'Reach at-risk veterans through peer support and resource navigation',
        'nonprofit' : ObjectId('5b29101ce3dde10019e1773c'),
        'slug' : 'volunteers-of-america-s-national-veterans-resource-squad-1',
        'approachDuration' : ObjectId('5d44b3b4d5b3a55e9e513d27'),
        'nonprofitPartners' : True,
        'cashContributions' : 0,
        'inKindContributions' : 300,
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5b86badbfa8cf800104c382f/5b86badbfa8cf800104c382f.jpg',
        'vimeoID' : '314367256'
    }
]

media = [
    {
        '_id': ObjectId('5f358618e1fee4c9ac3ed60a'),
        'category': 'Video',
        'credits': {
            'program_name': 'PRG Teach young women of color in New York City key coding skills',
            'npo_name': 'NPO Black Girls CODE',
            'npo_id': '5b2c0100e3dde1001ae1771a',
            'program_id': '5bf57aa20f36530008d076c9'
        },
        'title': 'Black Girls CODE_New York City CODE Club_Short',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/th_1593564866.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/videos/5102video_1591129754.mp4',
        'tags': 'Education,Video,Short,Program Video,Final,US,NPO Overview',
        'md5': '7f587fffaeec4ac42f15c669d94705cb',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/5102video_1591129754.mp4',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/th_1593564866.jpg'
    },
    {
        '_id': ObjectId('5f3c3819e1fee4c9ac3a514c'),
        'category': 'Hero/Fallback Image',
        'credits': {
            'program_name': 'PRG Provide fresh nutritious produce to people experiencing hunger',
            'npo_name': 'NPO Second Harvest Heartland',
            'npo_id': '5bae3a6d2c63670007fe3afe',
            'program_id': '5c387b71a08c41000a179495',
        },
        'title': 'Second Harvest Heartland_Hero Image_Provide Fresh Food_2880x3840',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/\
            th_GW-Hunger-Second-Harvest-PRG-PRT-2880x3840.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/images/\
            GW-Hunger-Second-Harvest-PRG-PRT-2880x3840.jpg',
        'tags': 'Hero,Vertical,,Photo,,Final,',
        'md5': '491bc16f59b6938c0f4b035c7659a983',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/GW-Hunger-Second-Harvest-PRG-PRT-2880x3840.jpg',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/ \
            thumbnail_th_GW-Hunger-Second-Harvest-PRG-PRT-2880x3840.jpg'
    },
    {
        '_id': ObjectId('5f3c3813e1fee4c9ac3a50ee'),
        'category': 'Hero/Fallback Image',
        'credits': {
            'program_name': 'PRG Connect children experiencing hunger to summer meals',
            'npo_name': 'NPO Second Harvest Heartland',
            'npo_id': '5bae3a6d2c63670007fe3afe',
            'program_id': '5c387b71a08c41000a179495',
        },
        'title': 'Second Harvest Heartland_Fallback Image_Connect Children_1536x860',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/ \
            th_GW-Children-Second-Harvest-PRG-LND-1536x860.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/images/ \
            GW-Children-Second-Harvest-PRG-LND-1536x860.jpg',
        'tags': 'Fallback,Horizontal,,Photo,,Photo,Final,Hero',
        'md5': '855323077e44e79f1264e026c237df7a',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/GW-Children-Second-Harvest-PRG-LND-1536x860.jpg',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/ \
            thumbnail_th_GW-Children-Second-Harvest-PRG-LND-1536x860.jpg'
    },
    {
        '_id': ObjectId('5f358a11e1fee4c9ac3f1614'),
        'category': 'Video',
        'credits': {
            'program_name': 'PRG Diversify reading materials for children in need',
            'npo_name': 'NPO First Book',
            'npo_id': '5b29101ce3dde10019e17743',
            'program_id': '5b918c868553ef0007f76022'
        },
        'file_type': 'video',
        'playtime_string': '1:00',
        'title': 'First Book_Stories for All_Short',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/th_1593725079.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/videos/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'tags': 'Video,Education,Final,Program Video,Short,US,:30,NPO Montage',
        'md5': 'b7127cd5145ec29bd3e0e77a35b91092',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/th_1593725079.jpg'
    },
    {
        '_id': ObjectId('5f358a11e1fee4c9ac3f1611'),
        'category': 'Video',
        'credits': {
            'program_name': 'PRG Diversify reading materials for children in need',
            'npo_name': 'NPO Waterkeeper Alliance',
            'npo_id': '5b29101ce3dde10019e1773b',
        },
        'title': 'First Book_Stories for All_Short',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/th_1593725079.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/videos/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'tags': 'Video,Education,Final,Program Video,Short,US,',
        'md5': 'b7127cd5145ec29bd3e0e77a35b91092',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/th_1593725079.jpg'
    },
    {
        '_id': ObjectId('5f358a11e1fee4c9ac3f1610'),
        'category': 'Photo',
        'credits': {
            'program_name': 'PRG Diversify reading materials for children in need',
            'npo_name': 'NPO Waterkeeper Alliance',
            'npo_id': '5b29101ce3dde10019e1773b',
        },
        'title': 'First Book_Stories for All_Short',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/th_1593725079.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/videos/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'tags': 'Photo,Education,Final,NPO Generic,Short,US,',
        'md5': 'b7127cd5145ec29bd3e0e77a35b91092',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/th_1593725079.jpg'
    },
    {
        '_id': ObjectId('5f358a11e1fee4c9ac3f1620'),
        'category': 'Photo',
        'credits': {
            'program_name': 'PRG Diversify reading materials for children in need',
            'npo_name': 'Volunteers of America test',
            'npo_id': '5b29101ce3dde10019e1773c',
        },
        'title': 'First Book_Stories for All_Short',
        'thumbnail': 'https://givewith.gosimian.com/assets/thumbs/th_1593725079.jpg',
        'media_file': 'https://givewith.gosimian.com/assets/videos/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'tags': 'Education,Final,Short,US,Photo',
        'md5': 'b7127cd5145ec29bd3e0e77a35b91092',
        'media_s3': 'https://staging-simian-media.s3.amazonaws.com/GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4',
        'thumbnail_s3': 'https://staging-simian-media.s3.amazonaws.com/th_1593725079.jpg'
    },
    {
        '_id': ObjectId('5f358a11e1fee4c9ac3f1619'),
        'file_type': 'image',
        'category': 'Photo',
        'credits': {
            'program_name': 'PRG Diversify reading materials for children in need',
            'program_id': '5b918c868553ef0007f76022'
        },
        'title': 'First Book_Stories Photo',
        'tags': 'Education,Beneficiary Profile,Final,US,NPO Generic,Photo',
        'md5': 'b7127cd5145ec29bd3e0e77a35b91092',
        'media_s3' : 'https://staging-simian-media.s3.amazonaws.com/4165image_1592342618.jpg',
        'thumbnail_s3' : 'https://staging-simian-media.s3.amazonaws.com/thumbnail_th_4165image_1592342618.jpg'
    },
    {
        "_id" : ObjectId("5f3d526be1fee4c9ac747437"),
        "category" : "Video",
        "credits" : {
            "npo_name" : "NPO Black Girls CODE",
            "npo_id" : "5b2c0100e3dde1001ae1771a"
        },
        "title" : "Black Girls CODE_Montage_30",
        "thumbnail" : "https://givewith.gosimian.com/assets/thumbs/th_5113video_1591129778.jpg",
        "media_file" : "https://givewith.gosimian.com/assets/videos/5113video_1591129778.mp4",
        "tags" : "Education,Video,Final,:30,NPO Montage,US,NPO Generic,",
        "media_s3" : "https://staging-simian-media.s3.amazonaws.com/5113video_1591129778.mp4",
        "thumbnail_s3" : "https://staging-simian-media.s3.amazonaws.com/thumbnail_th_5113video_1591129778.jpg"
    }
]

share_actions = [
    {
        "_id" : ObjectId("5da63623e3eb8a0b0b1dd9c6"),
        "socialMedia" : {
            "facebook" : [],
            "linkedin" : [],
            "twitter" : [],
            "instagram" : []
        },
        "status" : "in_progress",
        "images" : [],
        "videos" : [],
        "actionType" : "hr_engagement_survey",
        "deal_id" : ObjectId("5f4d2e3fb29a285691023f6f"),
        "name" : "Killer Beans Summary",
        "userId" : ObjectId("5d1a3962d5b3a53c05437ede"),
        "description" : "Thanks to our deal with JACK HENRY & ASSOCIATES, INC., we allocated funding to American",
        "content" : {
            "default" : "https://share-actions-staging.s3.amazonaws.com/templates/hr-engagement-survey.docx",
            "custom" : ""
        },
        "createdDate" : "2020-08-31T22:09:45.459Z",
        "lastStatusUpdate" : "1598911813123",
        "lastUpdated" : "1598911813123",
        "__v" : 0
    }
]
