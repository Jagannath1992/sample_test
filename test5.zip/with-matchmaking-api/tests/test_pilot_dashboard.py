from unittest import mock
from io import BytesIO

import pytest
from flask import send_file


class TestSummaryDocument():
    def get_sample_file(self):
        return BytesIO(b'test file')

    def download_file_side_effect(self, _, _fd):
        _fd.write(self.get_sample_file().read())
        _fd.seek(0)

    @pytest.fixture
    def mock_send_file(self, monkeypatch):
        mock_send_file = mock.Mock(wraps=send_file)
        monkeypatch.setattr('matchmaking.controllers.dashboard.pilot_dashboard.send_file', mock_send_file)

        return mock_send_file

    def test_get_summary_doc_custom(self, client, client_header, monkeypatch, mock_send_file):
        mock_file_data = {
            'name': 'Screen_Shot_2021-02-18_at_11.15.56_AM_1613669742086.png',
            'url': 'brand/5c1415685b03bb0008c21b06/Screen_Shot_2021-02-18_at_11.15.56_AM_1613669742086.png'
        }
        mock_get_document_by_id = mock.Mock(return_value={'customWrittenSummary': mock_file_data})
        monkeypatch.setattr('matchmaking.controllers.dashboard.pilot_dashboard.get_document_by_id',
                            mock_get_document_by_id)

        mock_download_file = mock.Mock(side_effect=self.download_file_side_effect)
        monkeypatch.setattr('matchmaking.controllers.dashboard.pilot_dashboard.download_file', mock_download_file)

        response = client.get('dashboard/pilot/summary_doc', headers=client_header)

        assert response.status_code == 200
        assert response.data == self.get_sample_file().read()
        mock_download_file.assert_called_with(mock_file_data['url'], mock.ANY)
        assert mock_send_file.call_args[1]['attachment_filename'] == mock_file_data['name']


    def test_get_summary_doc_generic(self, client, client_header, monkeypatch, mock_send_file):
        mock_get_document_by_id = mock.Mock(return_value={})
        monkeypatch.setattr('matchmaking.controllers.dashboard.pilot_dashboard.get_document_by_id',
                            mock_get_document_by_id)

        mock_download_file = mock.Mock(side_effect=self.download_file_side_effect)
        monkeypatch.setattr('matchmaking.controllers.dashboard.pilot_dashboard.download_file', mock_download_file)

        response = client.get('dashboard/pilot/summary_doc', headers=client_header)

        assert response.status_code == 200
        assert response.data == self.get_sample_file().read()
        mock_download_file.assert_called_with('globals/Sourcing_Written_Summary.docx', mock.ANY)
        assert mock_send_file.call_args[1]['attachment_filename'] == 'Sourcing_Written_Summary.docx'


def test_get_dashboard_home(client, client_header):
    response = client.get('dashboard/pilot/home', headers=client_header)
    assert response.status_code == 200
