from bson import ObjectId

from research_api.mongodb import db, get_theme_id
from research_api.logger import log_exception, log_info
from research_api.utils import GivewithError


# ------------------------------------------------------------------------------
# CONFIG
# ------------------------------------------------------------------------------
SURVEY_ID = 2
TOTAL_NUM_BRANDS = 321

# We need the object ids for each theme, but these IDs are different
# across environments, so we grab them by their label
# NOTE: if labels change, this will break when ran, but we still use ObjectIds so
#       that nielsen functions will still work until then
# NOTE: This is ordered (matches the order of themes in the sheet)
# ObjectIds pulled from vocab v2
THEME_LABELS = [
    'Aging populations',
    'Animal welfare',
    'Arts and culture',
    'Criminal justice',
    'Disaster response, relief and recovery',
    'Diversity and inclusion',
    'Economic empowerment',
    'Education',
    'Environment',
    'Food and hunger',
    'Health and wellness',
    'Housing and homelessness',
    'Human rights and civic engagement',
    'Immigrants',
    'Indigenous peoples',
    'LGBTQQIA+',
    'People of color',
    'People with disabilities/disabled persons',
    'Poverty alleviation',
    'Refugees',
    'Veterans',
    'Women and girls',
    'Youth development',
]
NUM_THEMES = len(THEME_LABELS)

NIELSEN_INFO_LABELS = [
    'household_income',
    'household_size_index',
    'ageoffemale_head_index',
    'age_presence_of_children_index',
    'employment_of_female_head_index',
    'education_of_female_head_index',
    'race_ethnicity_index',
    'hispanic_index',
    'nielsen_county_size_index',
    'census_division_index',
    'spectra_lifestyle_index',
    'spectra_behavior_stage_index',
    'occupation_of_household_head_index',
    'zip_code',
    'census_region'
]

# ------------------------------------------------------------------------------
# 0-based indecies for the start/end column of Q1
# ------------------------------------------------------------------------------
PANELIST_ID_INDEX = 0
BRAND_NUM_INDEX = 3
COMPANY_INDEX = 5
INDUSTRY_INDEX = 6
RESPONDENT_AGE = 7

Q1_START = 8
Q1_END = 328

Q2_START = 330
Q2_END = 650

Q3_INDEX = 652

Q4_INDEX = 653

Q5_START = 654
Q6_START = 678
Q7_START = 701

Q8_INDEX = 724
Q8_A_INDEX = 725

Q9_START = 726
Q9_END = 729

Q10_START = 730
Q11_START = 753
Q12_START = 776
Q13_START = 799

Q14_INDEX = 822

Q15_INDEX = 823

NIELSEN_INFO_START = 824
# ------------------------------------------------------------------------------

theme_reference = {}
THEME_IDS = []



# TODO: delete this?
# Q5 - panelist/theme reference table
def add_panelist_to_theme_reference(theme_label, panelist_id):
    # If the theme_label isn't added yet, add and initialize the set with the panelist
    if theme_label not in theme_reference:
        theme_reference[theme_label] = set([panelist_id])

    # Add panelist
    theme_reference[theme_label].add(panelist_id)


def _set_theme_ids():
    """ Sets theme ids if they're not already set """
    global THEME_IDS
    if not THEME_IDS:
        THEME_IDS = [get_theme_id(x) for x in THEME_LABELS]


def transform_nielsen(data):
    data = data.fillna(0)

    panelists = {}
    base_responses = []
    responses = []

    for _tuple in data.itertuples():
        row = _tuple[1:]
        transform_nielsen_row(row, panelists, base_responses, responses)

    data = (panelists, responses, base_responses)
    return data


def transform_nielsen_row(row, panelists, base_responses, responses):
    panelist = {}

    _set_theme_ids()

    panelist_id = row[PANELIST_ID_INDEX]
    brand_id = int(row[BRAND_NUM_INDEX])
    company = row[COMPANY_INDEX]
    industry = row[INDUSTRY_INDEX]

    # Panelists: Q1, Q2, Q
    # Not unique
    if panelist_id not in panelists:
        employment_status, org_size = get_Q8(row)
        highest_education_level = get_Q15(row)
        employed = employment_status in ['1', '2']

        panelist = {
            'respondent_id': panelist_id,
            'brand_awareness': get_Q1(row),
            'brand_consideration': get_Q2(row),
            'gender': 'M' if get_Q14(row) == '1' else 'F',
            'employment_status': employment_status,
            'org_size': org_size,
            'highest_education_level': highest_education_level,
            'age': row[RESPONDENT_AGE]
        }

        # Add in extra info for a panelist
        panelist.update(get_nielsen_info(row))
        if employed:
            panelist['base_hr_responses'] = get_Q9(row)
            panelist['hr_responses'] = get_Q10_to_Q13(row)

        panelists[panelist['respondent_id']] = panelist

    # Q3, Q4
    # Unique
    if company:
        base_responses.append({
            'respondent_id': panelist_id,
            'brand_id': int(brand_id),
            'company': company,
            'likelihood_to_purchase': get_Q3(row),
            'likelihood_to_recommend': get_Q4(row),
            'industry': industry
        })

        responses.extend(get_Q5_to_Q7(row, panelist_id, brand_id, company, industry))

    return


def extract_brands(data):
    if len(data) != TOTAL_NUM_BRANDS:
        raise GivewithError(f'Wrong total num brands:\nlen(data)={len(data)}\nTOTAL_NUM_BRANDS={TOTAL_NUM_BRANDS}')
    else:
        brands = []
        for index, cell in enumerate(data):
            if cell == '1':
                brand_num = index + 1  # Append brand_id (not 0-based, so add 1)
                brands.append(int(brand_num))

        return brands


def get_Q1(row):
    q1_data = row[Q1_START : Q1_END + 1]
    return extract_brands(q1_data)


def get_Q2(row):
    q2_data = row[Q2_START : Q2_END + 1]
    return extract_brands(q2_data)


def get_Q3(row):
    return row[Q3_INDEX]


def get_Q4(row):
    return row[Q4_INDEX]


def get_Q5_to_Q7(row, panelist_id, brand_id, company, industry):
    responses = []
    for i in range(0, NUM_THEMES):
        is_personally_important = True if row[Q5_START + i] == 1 else False  # Q5

        if is_personally_important:
            theme_id = THEME_IDS[i]
            add_panelist_to_theme_reference(theme_id, panelist_id)

            responses.append({
                'respondent_id': panelist_id,
                'brand_id': brand_id,
                'industry': industry,
                'company': company,
                'theme_id': theme_id,
                'likelihood_to_purchase': row[Q6_START + i],  # Q6
                'likelihood_to_recommend': row[Q7_START + i]  # Q7
            })

    return responses


def get_Q8(row):
    return row[Q8_INDEX], row[Q8_A_INDEX]


def get_Q9(row):
    return {
        'employee_proudness': row[Q9_START],
        'employee_motivation': row[Q9_START + 1],
        'employee_recommendation': row[Q9_START + 2],
        'employee_retention': row[Q9_START + 3],
    }


def get_Q10_to_Q13(row):
    hr_responses = []

    for i in range(0, NUM_THEMES):
        is_personally_important = True if row[Q5_START + i] == '1' else False

        if is_personally_important:
            theme_label = THEME_IDS[i]

            hr_responses.append({
                'theme_label': theme_label,
                'employee_proudness': row[Q10_START + i],
                'employee_motivation': row[Q11_START + i],
                'employee_recommendation': row[Q12_START + i],
                'employee_retention': row[Q13_START + i],
            })

    return hr_responses


def get_Q14(row):
    return str(row[Q14_INDEX])


def get_Q15(row):
    return str(row[Q15_INDEX])


def get_nielsen_info(row):
    info = {}
    for i in range(0, len(NIELSEN_INFO_LABELS)):
        label = NIELSEN_INFO_LABELS[i]
        value = row[NIELSEN_INFO_START + i]
        info[label] = int(value)

    return info
