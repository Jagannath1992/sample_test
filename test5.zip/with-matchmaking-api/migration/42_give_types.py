from matchmaking import db

db().coll_brands.update_many(filter={}, update={'$set': {'givePercentageType': 'default'}})


db().coll_brands.update_many(filter={}, update={'$unset': {'givePercent': ''}})
