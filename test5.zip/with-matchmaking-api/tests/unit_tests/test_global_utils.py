from datetime import datetime
import pytest
from matchmaking import utils

@pytest.mark.parametrize('sample, projection, expected', [
    ({'keyA': 2, 'keyB': 4, 'keyC': 5}, {'keyA', 'keyB'}, {'keyA': 2, 'keyB': 4}),
    ({'keyA': 2, 'keyB': 4, 'keyC': 5}, {}, {}),
    ({'keyA': 2, 'keyB': 4, 'keyC': 5}, {'keyA', 'keyB', 'keyQ'}, {'keyA': 2, 'keyB': 4}),
    ({}, {'keyB', 'keyC'}, {})
])
def test_project_dict(sample, projection, expected):
    assert utils.project_dict(sample, projection) == expected
