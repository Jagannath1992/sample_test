import json
import requests

from os import environ
from bson import json_util
from matchmaking.mongodb import db
from matchmaking.utils import send_loggly

default_program_manager = 'Melissa Gordon'

EMAIL_SERVICE_URL = environ.get('EMAIL_SERVICE_URL', 'http://emailloadbalancer-1769123919.us-east-1.elb.amazonaws.com/email')
IMPACT_URL = environ.get('IMPACT_URL', 'https://impact.nohardstops.com')
ADMIN_URL = environ.get('ADMIN_URL', 'https://admin.nohardstops.com')
REAL_ESTATE_URL = environ.get('REAL_ESTATE_URL', 'https://realestate.nohardstops.com')

ENV = environ.get('ENV', 'local')
STAGING = True if ENV == 'staging' else False
SANDBOX = True if ENV == 'sandbox' else False
PROD = True if (ENV == 'production' or ENV == 'prod') else False

default_email = 'customer-success-staging@givewith.com'
if SANDBOX:
    default_email = 'customer-success-sandbox@givewith.com'
elif PROD:
    default_email = 'customer-success@givewith.com'


support_roles = ['client', 'manager', 'customer']
default_brand_projection = {'name': True, 'nameLabel': True, 'givewithManager': True}

class NotificationEmail:
    def __init__(self, roles=[], data=None, objective='', cc=[]):
        self.roles = roles
        for r in roles:
            if r not in support_roles:
                raise Exception('invalid roles: ' + r)

        self.data = data
        self.objective = objective
        self.recipients = [*cc]
        self.url = EMAIL_SERVICE_URL
        self.email_service_api = self.url

        if self.objective not in requests_map:
            send_loggly('invalid email objective: ' + self.objective)

        try:
            self.email_requests = requests_map.get(objective)(self)
        except Exception as e:
            send_loggly('error creating notification: ' + str(e))


    def send(self):
        responses = []
        for req in self.email_requests:
            send_loggly('sending emails request: ' + json_util.dumps(req))
            response = requests.post(self.email_service_api, json=json.loads(json_util.dumps(req)), timeout=3)
            responses.append(response)
            send_loggly('get email response: ' + str(response.content))

        return responses


def prepare_new_deal_request(message):
    """ when a deal is made on dashboard, send email to customer brand manager."""
    deal = message.data
    recipients = message.recipients
    recipients.append(default_email)

    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)
    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)
    recipients.extend(get_manager_email(customer_brand))

    return [{
        'tos': list(dict.fromkeys(recipients)),
        'template': {
            'id': 'd-6095cc86c11a47d792200892dfaa8e36',
            'data': {
                'deal': deal,
                'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'proposalRecordLink': ADMIN_URL + '/#/deals/' + str(deal.get('_id')),
                'staging': STAGING,
                'sandbox': SANDBOX,
            }
        }
    }]


def prepare_program_selection_pending_request(message):
    deal = message.data
    if deal.get('type') == 'covid':
        return []

    recipients = [*message.recipients, *deal.get('givewithCustomerEmails', [])]

    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)

    return [{
        'tos': list(dict.fromkeys(recipients)),
        'template': {
            'id': 'd-10b730a390884ee2a133d2d0f688a46f',
            'data': {
                'proposalName': deal.get('name'),
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'proposalSummaryLink': IMPACT_URL + '/dashboard/proposals/' + str(deal.get('_id')),
            }
        }
    }]


def prepare_program_selected_request(message):
    """ when a program is selected on proposal link, send email to customer/client/customer brand manager. """
    deal = message.data
    roles = message.roles
    recipients = message.recipients
    email_requests = []

    if deal.get('type') == 'covid':
        return email_requests

    program = db().coll_programs.find_one({'_id': deal.get('selectedProgram')})
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit')})
    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)
    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)

    if 'customer' in roles:
        customer_emails = [*deal.get('givewithCustomerEmails', []), *recipients]

        email_requests.append({
            'tos': list(dict.fromkeys(customer_emails)),
            'template': {
                'id': 'd-61d4af68d16c4cbab0d7791672f9f5a1',
                'data': {
                    'proposalName': deal.get('name'),
                    'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                    'proposalSummaryLink': IMPACT_URL + '/dashboard/proposals/' + str(deal.get('_id')),

                    'selectedProgram': {
                        'nonprofitName': nonprofit.get('name'),
                        'programImage': program.get('imagePortrait'),
                        'programName': program.get('name'),
                    }
                }
            }
        })

    if 'client' in roles:
        client_emails = [*deal.get('clientEmails', []), *recipients]

        email_requests.append({
            'tos': list(dict.fromkeys(client_emails)),
            'template': {
                'id': 'd-6293b2f0898c4bf4b7af7964fa952e1e',
                'data': {
                    'customerBrandName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'proposalName': deal.get('name'),
                    'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                    'proposalSummaryLink': IMPACT_URL + '/deal/' + deal.get('slug'),
                    'password': deal.get('password'),
                    'selectedProgram': {
                        'nonprofitName': nonprofit.get('name'),
                        'programImage': program.get('imagePortrait'),
                        'programName': program.get('name'),
                    }
                }
            }
        })

    if 'manager' in roles:
        recipients.extend(get_manager_email(customer_brand))
        recipients.append(default_email) # cc csm

        email_requests.append({
            'tos': list(dict.fromkeys(recipients)),
            'template': {
                'id': 'd-b63a08df1c304778b3d42f3858ee5486',
                'data': {
                    'deal': deal,
                    'program': set_default_program_manager(program),
                    'nonprofit': nonprofit,
                    'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                    'proposalRecordLink': ADMIN_URL + '/#/deals/' + str(deal.get('_id')),
                    'staging': STAGING,
                    'sandbox': SANDBOX,
                }
            }
        })


    return email_requests


def prepare_partially_confirmed_transaction_request(message):
    """ partially-confirmed email. Only when a buyer initiates, when the buyer confirms the deal info on the dashboard,
        the givewith customer brand manager should get an email saying the deal is partially confirmed.
        the client/supplier should get an email saying they need to confirm
    """
    email_requests = []
    recipients = message.recipients
    roles = message.roles
    deal = message.data
    if deal.get('type') == 'covid':
        return email_requests

    program = db().coll_programs.find_one({'_id': deal.get('selectedProgram')})
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit')})
    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)
    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)

    if 'manager' in roles:
        recipients.append(default_email)
        email_requests.append({
            'tos': list(dict.fromkeys(get_manager_email(customer_brand) + recipients)),
            'template': {
                'id': 'd-c2bf19264d1c4f619cfaff660000dcc4',
                'data': {
                    'deal': deal,
                    'program': set_default_program_manager(program),
                    'nonprofit': nonprofit,
                    'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                    'proposalRecordLink': ADMIN_URL + '/#/deals/' + str(deal.get('_id')),
                    'staging': STAGING,
                    'sandbox': SANDBOX,
                }
            }
        })

    return email_requests


def prepare_completely_confirmed_request(message):
    email_requests = []
    recipients = message.recipients
    deal = message.data

    if deal.get('type') == 'covid':
        return email_requests

    program = db().coll_programs.find_one({'_id': deal.get('selectedProgram')})
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit')})
    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)

    return [
        {
            'tos': list(dict.fromkeys(recipients)),
            'template': {
                'id': 'd-0cb8f07b8e3949a9906050e7c81a402c',
                'data': {
                    'deal': deal,
                    'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'program': set_default_program_manager(program),
                    'nonprofit': nonprofit,
                    'proposalSummaryLink': IMPACT_URL + '/deal/' + str(deal.get('slug')),
                }
            }
        }
    ]


def prepare_payment_pending_request(message):
    recipients = message.recipients
    recipients.append(default_email) # cc csm

    email_requests = []
    deal = message.data

    if deal.get('type') == 'covid':
        return email_requests

    program = db().coll_programs.find_one({'_id': deal.get('selectedProgram')})
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit')})
    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)
    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)

    recipients.extend(get_manager_email(customer_brand))

    email_requests.append({
        'tos': list(dict.fromkeys(recipients)),
        'template': {
            'id': 'd-b70c443ea6a640d791a496f83b9bb1ea',
            'data': {
                'deal': deal,
                'program': set_default_program_manager(program),
                'nonprofit': nonprofit,
                'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'proposalRecordLink': ADMIN_URL + '/#/deals/' + str(deal.get('_id')),
                'staging': STAGING,
                'sandbox': SANDBOX,
            }
        }
    })

    return email_requests


def prepare_completed_request(message):
    recipients = message.recipients
    deal = message.data
    roles = message.roles
    email_requests = []

    if deal.get('type') == 'covid':
        return email_requests

    program = db().coll_programs.find_one({'_id': deal.get('selectedProgram')})
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit')})
    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)
    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)

    if 'customer' in roles:
        confirmed_user_id = deal.get('confirmation', {}).get('confirmedBy', None)
        if confirmed_user_id is not None:
            confirmed_user_email = db().coll_user.find_one({'_id': confirmed_user_id}).get('username')
            customer_emails = [*deal.get('givewithCustomerEmails', []), *recipients, confirmed_user_email]
            email_requests.append({
                'tos': list(dict.fromkeys(customer_emails)),
                'template': {
                    'id': 'd-932523143d4240cc8d749a00eddd2a23',
                    'data': {
                        'proposalName': deal.get('name'),
                        'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                        'programAssetsLink': IMPACT_URL + '/dashboard/proposals/' + str(deal.get('_id')),
                        'selectedProgram': {
                            'nonprofitName': nonprofit.get('name'),
                            'programImage': program.get('imagePortrait'),
                            'programName': program.get('name'),
                        }
                    }
                }
            })

    if 'client' in roles:
        client_emails = [*deal.get('clientEmails', []), *recipients]

        if 'expectedClientToConfirm' in deal and 'email' in deal.get('expectedClientToConfirm')\
            and deal.get('expectedClientToConfirm').get('email').strip() != '':
            client_emails.append(deal.get('expectedClientToConfirm').get('email'))

        if 'clientConfirmation' in deal and 'email' in deal.get('clientConfirmation') \
            and deal.get('clientConfirmation').get('email').strip() != '':
            client_emails.append(deal.get('clientConfirmation').get('email'))

        # regular assets ready email template
        email_template_id = 'd-dcaf5317fd3345baa4398b423b3aa9b8'
        if deal.get('type') == 'sales':
            # sales assets ready email template
            email_template_id = 'd-9fc7db94ea5e48278f6ab95dbd602974'

        email_requests.append({
            'tos': list(dict.fromkeys(client_emails)),
            'template': {
                'id': email_template_id,
                'data': {
                    'customerBrandName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'proposalName': deal.get('name'),
                    'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                    'programAssetsLink': IMPACT_URL + '/deal/' + deal.get('slug'),
                    'password': deal.get('password'),
                    'selectedProgram': {
                        'nonprofitName': nonprofit.get('name'),
                        'programImage': program.get('imagePortrait'),
                        'programName': program.get('name'),
                    }
                }
            }
        })

    return email_requests


def prepare_client_accounts_payable_request(message):
    email_requests = []
    recipients = message.recipients
    deal = message.data

    client_confirmation_data = deal.get('clientConfirmation', {})
    accounts_payable_data = client_confirmation_data.get('accountsPayable', {})
    recipients.append(accounts_payable_data.get('email', ''))

    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)

    return [{
        'tos': list(dict.fromkeys(recipients)),
        'template': {
            'id': 'd-6db19f0607f849e59c309127af27a232',
            'data': {
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'contactName': client_confirmation_data.get('name', ''),
                'staging': STAGING,
                'sandbox': SANDBOX,
            }
        }
    }]


def prepare_covid_completed_request(message):
    recipients = message.recipients
    deal = message.data
    roles = message.roles
    email_requests = []

    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)
    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)

    assetsLink = IMPACT_URL + '/covid-response-initiative/assets'
    password = '6hKLHQR077uF' #nosec

    if 'customer' in roles:
        customer_emails = [*deal.get('givewithCustomerEmails', []), *recipients]
        email_requests.append({
            'tos': list(dict.fromkeys(customer_emails)),
            'template': {
                'id': 'd-8a61e68ef7654221a66e9578c58358b5',
                'data': {
                    'brandName': client_brand.get('nameLabel') or client_brand.get('name'),
                    'assetsLink': assetsLink,
                    'password': password,
                }
            }
        })

    if 'client' in roles:
        client_emails = [*deal.get('clientEmails', []), *recipients]

        if 'clientConfirmation' in deal and 'email' in deal.get('clientConfirmation') \
            and deal.get('clientConfirmation').get('email').strip() != '':
            client_emails.append(deal.get('clientConfirmation').get('email'))

        email_requests.append({
            'tos': list(dict.fromkeys(client_emails)),
            'template': {
                'id': 'd-8a61e68ef7654221a66e9578c58358b5',
                'data': {
                    'brandName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'assetsLink': assetsLink,
                    'password': password,
                }
            }
        })

    return email_requests


def covid_client_confirm_request(message):
    """ Upon hitting submit on a proposal flyout, the "Please confirm details" email is sent to the client email.
        Logic for sending this email: Email should be sent if they select to split the payment;
        or if the customer role is buyer and they select 'supplier pays' (regular logic).
    """
    email_requests = []
    recipients = message.recipients
    roles = message.roles
    deal = message.data

    recipients.extend(deal.get('clientEmails', []))

    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)

    if 'client' in roles:
        email_requests.append({
            'tos': list(dict.fromkeys(recipients)),
            'template': {
                'id': 'd-1e55e46569244d56801350f9f614366d',
                'data': {
                    'deal': deal,
                    'customerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                    'dealLink': IMPACT_URL + '/covid-deal/' + str(deal.get('slug')) + '/confirm-details',
                    'password': deal.get('password'),
                }
            }
        })

    return email_requests


def prepare_real_estate_completed_request(message):
    deal = message.data
    roles = message.roles
    email_requests = []

    customer_brand = db().coll_brands.find_one(
        {'_id': deal.get('givewithCustomer')}, default_brand_projection)


    if 'customer' in roles:
        confirmed_user_id = deal.get('confirmation', {}).get('confirmedBy', None)
        if confirmed_user_id is not None:
            confirmed_user_email = db().coll_user.find_one({'_id': confirmed_user_id}).get('username')
            confirmed_user_first = db().coll_user.find_one({'_id': confirmed_user_id}).get('first_name')
            customer_emails = [confirmed_user_email]

            email_requests.append({
                'tos': list(dict.fromkeys(customer_emails)),
                'template': {
                    'id': 'd-7fdd00a06391483c8ff9b2e5323c3463',
                    'data': {
                        'realEstateUrl': REAL_ESTATE_URL,
                        'companyName': customer_brand.get('name'),
                        'userFirstName': confirmed_user_first
                    }
                }
            })

    return email_requests


def prepare_sales_complete_request(message):
    """
    Send to the CLIENT email addresses when the proposal is moved to Complete in the admin.
    """
    deal = message.data
    recipients = message.recipients
    recipients.append(default_email)

    customer_brand = db().coll_brands.find_one({'_id': deal.get('givewithCustomer')}, default_brand_projection)
    client_brand = db().coll_brands.find_one({'_id': deal.get('client')}, default_brand_projection)
    recipients.extend(get_manager_email(customer_brand))
    program = db().coll_programs.find_one({'_id': deal.get('selectedProgram')})
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit')})

    return [{
        'tos': list(dict.fromkeys(recipients)),
        'template': {
            'id': 'd-dcaf5317fd3345baa4398b423b3aa9b8',
            'data': {
                'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                'customerBrandName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                'proposalName': deal.get('name'),
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'programAssetsLink': IMPACT_URL + '/deal/' + deal.get('slug'),
                'password': deal.get('password'),
                'selectedProgram': {
                    'nonprofitName': nonprofit.get('name'),
                    'programImage': program.get('imagePortrait'),
                    'programName': program.get('name'),
                }
            }
        }
    }]

requests_map = {
    'new_deal': prepare_new_deal_request,
    'program_selection_pending': prepare_program_selection_pending_request,
    'program_selected': prepare_program_selected_request,
    'partially_confirmed': prepare_partially_confirmed_transaction_request,
    'confirm_transaction': prepare_completely_confirmed_request,
    'payment_pending': prepare_payment_pending_request,
    'completed': prepare_completed_request,
    'covid_completed': prepare_covid_completed_request,
    'real_estate_completed': prepare_real_estate_completed_request,
    'client_accounts_payable': prepare_client_accounts_payable_request,
    'covid_client_confirm': covid_client_confirm_request,
}


def get_manager_email(brand):
    default_emails = [default_email]
    if 'givewithManager' in brand:
        manager = db().coll_user.find_one({'_id': brand.get('givewithManager')}, {'username': True})
        if manager is not None:
            default_emails.append(manager.get('username'))

    return default_emails

def set_default_program_manager(program):
    p = program.copy()
    if 'givewithAdmin' not in p:
        p['givewithAdmin'] = default_program_manager
    else:
        admin_id = p.get('givewithAdmin')
        user = db().coll_user.find_one({'_id': admin_id}, {'first_name': True, 'last_name': True})
        p['givewithAdmin'] = user.get('first_name', '') + ' ' + user.get('last_name', '')

    return p
