from typing import List, Union, Tuple

from bson import ObjectId
from flask import abort, jsonify, request

from app.constants import PHOTO_TAGS_BY_DEPT, VIDEO_TAGS_BY_DEPT, default_media_projection
from app.controllers import deal_bp
from app.db.utils import get_document, get_document_by_id, get_documents, aggregate_on
from app.utils.auth import authenticate, authenticate_deal
from app.utils.deal import is_brand_eligible_for_nonprofit_premium_assets
from app.utils.utils import get_assets, has_tags
from app.validation.utils import validate_object_id_with_collection


@deal_bp.route('/<string:deal_id>/assets:customer', methods=['GET'])
@authenticate
def get_customer_deal_assets(deal_id):
    '''
    Get media assets (images and videos) associated with a complete deal for customer
    '''
    if not validate_object_id_with_collection(deal_id, 'deals'):
        abort(404, description=f'Deal not found {deal_id}')

    deal = get_document_by_id('deals', ObjectId(deal_id), projection={
        'status': True, 'givewithCustomer': True, 'selectedProgram': True
    })

    status = deal.get('status')
    if status != 'COMPLETE':
        abort(403, description=f'Deliverables not available at {status} status')

    user_brand_id = ObjectId(request.user.get('orgId'))
    if deal.get('givewithCustomer') != user_brand_id:
        abort(403, description=f'User id: {user_brand_id} doesn\'t match deal\'s customer id')

    program = get_document_by_id('mm_programs', deal.get('selectedProgram'), projection={
        'nonprofit': True
    })

    if not program:
        abort(404, description=f'Program: {deal.get("selectedProgram")} no longer exists')

    # allow requesting only photos or videos, omission means both will be returned
    asset_type = request.args.get('type', '').lower() if request.args else ''
    search_tags = 'Photo Video Poster' # Photo or Video or Poster (Digital Poster)
    if asset_type == 'photo':
        search_tags = 'Photo Poster'
    elif asset_type == 'video':
        search_tags = 'Video'

    if not is_brand_eligible_for_nonprofit_premium_assets(user_brand_id, program.get('nonprofit')):
        search_tags = search_tags + ' -"Premium"'

    photos, videos = get_program_assets_for_customer(program.get('_id'), program.get('nonprofit'),
                                                     request.user.get('departmentType'), search_tags)

    return jsonify({'photo': photos, 'video': videos})


@deal_bp.route('/<string:slug>/assets:client', methods=['GET'])
@authenticate_deal
def get_client_deal_assets(slug):
    '''
    Get media assets (images and videos) associated with a complete deal for client
    '''
    deal = get_document('deals', {'slug': slug}, projection={
        'status': True, 'selectedProgram': True, 'type': True
    })

    status = deal.get('status')
    if status != 'COMPLETE':
        abort(403, description=f'Deliverables not available at {status} status')

    program = get_document_by_id('mm_programs', deal.get('selectedProgram'), projection={
        'nonprofit': True
    })

    if not program:
        abort(404, description=f'Program: {deal.get("selectedProgram")} no longer exists')

    video_tags, photo_tags = get_asset_tags_for_deal_client(deal.get('type') or 'enterprise')

    video_query = {
        '$or': [
            {'credits.program_id': str(program.get('_id'))},
            {'credits.npo_id': str(program.get('nonprofit'))}
        ],
        # all search fields quoted executes an AND query of all tags
        '$text': {'$search': '"{0}"'.format('", "'.join(video_tags))}
    }
    video = get_document('simian_media', query=video_query, projection={
        **default_media_projection, 'playtime_string': True
    })

    photo_query = {
        '$or': [
            {'credits.program_id': str(program.get('_id'))},
            {'credits.npo_id': str(program.get('nonprofit'))}
        ],
        # all search fields quoted executes an AND query of all tags
        '$text': {'$search': '"{0}"'.format('", "'.join(photo_tags))}
    }
    photo = get_document('simian_media', query=photo_query, projection={
        **default_media_projection,
    })


    assets = {
        'photo': photo and get_assets(photo),
        'video': video and {**get_assets(video), 'playtime': video.get('playtime_string')}
    }

    return jsonify(assets)


@deal_bp.route('/all-customer-media-assets', methods=['GET'])
@authenticate
def get_all_completed_deal_media_assets():
    aggregation_pipeline = [
        {
            '$match': {
                'status': 'COMPLETE',
                'givewithCustomerUser': str(request.user['_id'])
            },
        },
        {
            '$lookup': {
                'from': 'mm_programs',
                'localField': 'selectedProgram',
                'foreignField': '_id',
                'as': 'selectedProgram'
            }
        },
        {
            '$unwind': {'path': '$selectedProgram'}
        },
        {
            '$project': {
                'programId': '$selectedProgram._id',
                'nonprofitId': '$selectedProgram.nonprofit',
            }
        }
    ]

    # is_eligible_for_nonprofit_premium_assets is a possible bottle neck due to the db calls and
    # calculations involved. This is a slight optimization to cache nonprofits that have already been seen
    premium_assets_eligibility_cache = {}
    assets = {}
    for deal in aggregate_on('deals', aggregation_pipeline):
        user_brand_id = ObjectId(request.user.get('orgId'))

        nonprofit_id_str = str(deal.get('nonprofitId'))
        if premium_assets_eligibility_cache.get(nonprofit_id_str) is not None:
            eligible_for_premium_assets = premium_assets_eligibility_cache.get(nonprofit_id_str)
        else:
            eligible_for_premium_assets = is_brand_eligible_for_nonprofit_premium_assets(user_brand_id,
                                                                                         deal.get('nonprofitId'))
            premium_assets_eligibility_cache[nonprofit_id_str] = eligible_for_premium_assets

        search_tags = 'Photo Video Poster' # Photo or Video or Poster (Digital Poster)
        if not eligible_for_premium_assets:
            search_tags = search_tags + ' -"Premium"'

        photos, videos = get_program_assets_for_customer(deal.get('programId'), deal.get('nonprofitId'),
                                                         request.user.get('departmentType'), search_tags)
        assets[str(deal.get('_id'))] = {'photo': photos, 'video': videos}

    return jsonify(assets)


def get_program_assets_for_customer(
        program_id: Union[ObjectId, str],
        nonprofit_id: Union[ObjectId, str],
        user_dept: str,
        search_tags: str
    ) -> Tuple[list, list]:
    query = {
        '$or': [
            {'credits.program_id': str(program_id)},
            {'credits.npo_id': str(nonprofit_id)}
        ],
        # has any of search_tags without "NPO Overview" (NPO Overview Video)
        '$text': {'$search': f'{ search_tags } -"NPO Overview"'}
    }

    assets = get_documents('simian_media', query, projection={
        **default_media_projection, 'file_type': True, 'playtime_string': True
    })

    return parse_customer_assets(assets, user_dept)


def parse_customer_assets(assets, user_dept):
    '''
    Split assets to videos and photos and add `recommend` tags based on user's department
    '''
    photos = []
    videos = []

    rec_video_tags = VIDEO_TAGS_BY_DEPT.get(user_dept, [])
    rec_photo_tags = PHOTO_TAGS_BY_DEPT.get(user_dept, [])

    has_rec_video = has_rec_photo = False
    for item in assets:
        if item.get('file_type') == 'video':
            data = get_assets(item)
            data['playtime'] = item.get('playtime_string', '')

            if not has_rec_video and has_tags(item, *rec_video_tags):
                has_rec_video = True
                data['recommended'] = True

            videos.append(data)

        elif item.get('file_type') == 'image':
            data = get_assets(item)
            if not has_rec_photo and has_tags(item, *rec_photo_tags):
                has_rec_photo = True
                data['recommended'] = True

            photos.append(data)

    return photos, videos


def get_asset_tags_for_deal_client(deal_type: str) -> List[str]:
    video_tags = {
        'enterprise': VIDEO_TAGS_BY_DEPT['Sales'],
        'sales': VIDEO_TAGS_BY_DEPT['Procurement']
    }.get(deal_type, [])

    photo_tags = {
        'enterprise': PHOTO_TAGS_BY_DEPT['Sales'],
        'sales': PHOTO_TAGS_BY_DEPT['Procurement']
    }.get(deal_type, [])

    return video_tags, photo_tags
