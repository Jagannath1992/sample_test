import re

from bson import ObjectId
from typing import Dict

from portal.shared.repository import DocumentRepository

class CorporateEntityRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['mm_brands_copy'])
