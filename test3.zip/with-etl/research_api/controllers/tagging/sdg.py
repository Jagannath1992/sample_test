# pylint: disable=line-too-long, missing-docstring, invalid-name, wildcard-import, unused-wildcard-import
# pylint: disable=too-many-branches, too-many-statements, unused-import, too-many-boolean-expressions
from .utils import check_term, add_feature, save_program_document, SELECTED_VOCABULARY_VERSION, critical_alert, init_tagging
from .constants import *

def tag_sdg(document, vocabulary):
    # here is where we're modifying data on records
    # what's our general approach?  well - let's load up the mm_vocabulary object into this hash named vocabulary
    # then we pass that and the given document (program record) together to output a stringified - meaning: readable
    # version of the document.

    log = list()
    _MY_SOURCE = VOCAB_SDGS

    try:

        tag_data = init_tagging(document, vocabulary, log, _MY_SOURCE)

        # NOW START TURNING THE RULES INTO CODE

        # Rule 1: End Poverty
        log.append("  rule 1")
        if check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) and \
                (check_term(REDUCE_CRIMINAL_ACTIVITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CRIMINAL_RECIDIVISM, VOCAB_IMPACTS, tag_data) or \
                 check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                 check_term(ENSURE_21ST_CENTURY_SKILLS_PROFICIENCY, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_HOMELESSNESS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_AMOUNT_AND_ACCESS_TO_QUALITY_AFFORDABLE_HOUSING, VOCAB_IMPACTS, tag_data) or \
                 check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data)) and \
                (check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(DEVELOP_FINANCIAL_LITERACY_AND_FINANCIAL_RESILIENCE, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_BUSINESS_AND_ENTERPRISE_DEVELOPMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_JOB_CREATION, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_JOB_PLACEMENT_RETENTION_SERVICES, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_ENTREPRENEURSHIP_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_AFFORDABLE_HOUSING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TEMPORARY_HOUSING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TRANSITIONAL_PROGRAMS_AND_SERVICES, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_AND_CONNECTIVITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(CREATE_ACCESS_TO_RESOURCES_AND_OR_PUBLIC_BENEFITS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_SKILLS_FOR_SELF_SUFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_CASE_MANAGEMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_LITERACY_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or \
                 check_term(CREATE_POLICY_CHANGE, VOCAB_APPROACHES, tag_data) or \
                 check_term(PASS_LEGISLATION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, NO_POVERTY, tag_data)

        log.append("----")


        # Rule 2: Zero Hunger
        log.append("  rule 2")
        if check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) and \
                (check_term(FOOD_AND_HUNGER, VOCAB_CAUSES, tag_data) or \
                 check_term(HOUSING_AND_HOMELESSNESS, VOCAB_CAUSES, tag_data) or \
                 check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data)) and \
                (check_term(REDUCE_HUNGER_AND_MALNUTRITION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_NUTRITIOUS_FOOD, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)) and \
                (check_term(PROVIDE_HEALTHY_EATING_BEHAVIOR_AND_NUTRITION_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_POTABLE_WATER, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUFFICIENT__AFFORDABLE_AND_NUTRITIOUS_FOODS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, ZERO_HUNGER, tag_data)

        log.append("----")


        # Rule 3: Good Health and Well being
        log.append("  rule 3")
        if check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data) and \
                (check_term(REDUCE_DISEASE_IMPROVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY__AFFORDABLE_HEALTHCARE_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_REPRODUCTIVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_RISKY_AND_ADDICTIVE_BEHAVIORS, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_TRAUMA, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, GOOD_HEALTH_AND_WELL_BEING, tag_data)

        log.append("----")


        # Rule 4: Quality Education
        log.append("  rule 4")
        if (check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
            check_term(EDUCATION, VOCAB_CAUSES, tag_data)) and \
                (check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                 check_term(ENSURE_21ST_CENTURY_SKILLS_PROFICIENCY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY_EDUCATION_PROGRAMS_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_ACADEMIC_ACHIEVEMENT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PEACE_THROUGH_CONFLICT_RESOLUTION, VOCAB_IMPACTS, tag_data)) and \
                (check_term(DEVELOP_FINANCIAL_LITERACY_AND_FINANCIAL_RESILIENCE, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_ENTREPRENEURSHIP_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(CREATE_ACCESS_TO_RESOURCES_AND_OR_PUBLIC_BENEFITS, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_SKILLS_FOR_SELF_SUFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_CASE_MANAGEMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPROVE_ACADEMIC_ENVIRONMENTS, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_SCHOOL_READINESS_SKILLS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_HIGH_SCHOOL_COMPLETION_SUPPORT, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_COLLEGE_READINESS__ACCESS__PERSISTENCE_AND_COMPLETION, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_LITERACY_AND_NUMERACY_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_LITERACY_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_STEM_INTEREST__PROFICIENCY_AND_PERSISTENCE_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TEACHER_EFFECTIVENESS_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_SOCIAL_AND_EMOTIONAL_LEARNING_AND_SKILLS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, QUALITY_EDUCATION, tag_data)

        log.append("----")


        # Rule 5: Gender Equality
        log.append("  rule 5")
        if check_term(WOMEN_AND_GIRLS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, GENDER_EQUALITY, tag_data)

        log.append("----")


        # Rule 6: Clean Water and Sanitation
        log.append("  rule 6")
        if (check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)) and \
                (check_term(PROVIDE_POTABLE_WATER, VOCAB_APPROACHES, tag_data) or \
                 check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or\
                 check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, CLEAN_WATER_AND_SANITATION, tag_data)

        log.append("----")


        # Rule 7: Affordable and Clean Energy
        log.append("  rule 7")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, AFFORDABLE_AND_CLEAN_ENERGY, tag_data)

        log.append("----")

        # Rule 8: Decent work and economic growth
        log.append("  rule 8")
        if (check_term(CRIMINAL_JUSTICE, VOCAB_CAUSES, tag_data) or \
            check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
            check_term(EDUCATION, VOCAB_CAUSES, tag_data) or \
            check_term(HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, VOCAB_CAUSES, tag_data)) and \
                (check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY_EDUCATION_PROGRAMS_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                 check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                     check_term(DEVELOP_FINANCIAL_LITERACY_AND_FINANCIAL_RESILIENCE, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROMOTE_JOB_CREATION, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_JOB_PLACEMENT_RETENTION_SERVICES, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_ENTREPRENEURSHIP_TRAINING, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_SKILLS_FOR_SELF_SUFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_TECHNOLOGY_LITERACY_TRAINING, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_LEGAL_PROTECTIONS, VOCAB_APPROACHES, tag_data) or \
                     check_term(CREATE_POLICY_CHANGE, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, DECENT_WORK_AND_ECONOMIC_GROWTH, tag_data)

        log.append("----")

        # Rule 9: Industry, innovation and infrastructure
        log.append("  rule 9")
        if (check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
            check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) or \
            check_term(HOUSING_AND_HOMELESSNESS, VOCAB_CAUSES, tag_data)) and \
                (check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(PROMOTE_BUSINESS_AND_ENTERPRISE_DEVELOPMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_COMMUNITY_ENVIRONMENTS_OR_SPACES, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, INDUSTRY__INNOVATION_AND_INFRASTRUCTURE, tag_data)

        log.append("-----")

        # Rule 10 Reduced Inequalities
        log.append("  rule 10")
        if (check_term(CRIMINAL_JUSTICE, VOCAB_CAUSES, tag_data) or \
            check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
            check_term(EDUCATION, VOCAB_CAUSES, tag_data) or \
            check_term(FOOD_AND_HUNGER, VOCAB_CAUSES, tag_data) or \
            check_term(HOUSING_AND_HOMELESSNESS, VOCAB_CAUSES, tag_data) or \
            check_term(HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, VOCAB_CAUSES, tag_data) or \
            check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data)) and \
                (check_term(WOMEN_AND_GIRLS, VOCAB_AUDIENCES, tag_data) or \
                 check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) or \
                 check_term(PEOPLE_OF_COLOR, VOCAB_AUDIENCES, tag_data) or \
                 check_term(PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
                 check_term(PEOPLE_WITH_SPECIAL_NEEDS, VOCAB_AUDIENCES, tag_data) or \
                 check_term(LGBTQQIA_, VOCAB_AUDIENCES, tag_data) or \
                 check_term(IMMIGRANTS, VOCAB_AUDIENCES, tag_data) or \
                 check_term(REFUGEES_DISPLACED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
                 check_term(INDIGENOUS_PEOPLES, VOCAB_AUDIENCES, tag_data)) and \
                    (check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
                     check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
                     check_term(ENSURE_21ST_CENTURY_SKILLS_PROFICIENCY, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_ACCESS_TO_QUALITY_EDUCATION_PROGRAMS_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                     check_term(IMPROVE_ACADEMIC_ACHIEVEMENT, VOCAB_IMPACTS, tag_data) or \
                     check_term(REDUCE_HOMELESSNESS, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_AMOUNT_AND_ACCESS_TO_QUALITY_AFFORDABLE_HOUSING, VOCAB_IMPACTS, tag_data) or \
                     check_term(REDUCE_HUNGER_AND_MALNUTRITION, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_ACCESS_TO_NUTRITIOUS_FOOD, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                     check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_CIVIC_PARTICIPATION, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_PEACE_THROUGH_CONFLICT_RESOLUTION, VOCAB_IMPACTS, tag_data) or \
                     check_term(REDUCE_DISEASE_IMPROVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                     check_term(INCREASE_ACCESS_TO_QUALITY__AFFORDABLE_HEALTHCARE_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                     check_term(IMPROVE_REPRODUCTIVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                     check_term(REDUCE_RISKY_AND_ADDICTIVE_BEHAVIORS, VOCAB_IMPACTS, tag_data) or \
                     check_term(REDUCE_TRAUMA, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, REDUCE_INEQUALITIES, tag_data)

        log.append("----")

        # Rule 11 Sustainable cities and communities
        log.append("    rule 11")
        if (check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
            check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) or \
            check_term(HOUSING_AND_HOMELESSNESS, VOCAB_CAUSES, tag_data)) and \
                (check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_HOMELESSNESS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_AMOUNT_AND_ACCESS_TO_QUALITY_AFFORDABLE_HOUSING, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                     check_term(DEVELOP_FINANCIAL_LITERACY_AND_FINANCIAL_RESILIENCE, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_AFFORDABLE_HOUSING, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_TEMPORARY_HOUSING, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_TRANSITIONAL_PROGRAMS_AND_SERVICES, VOCAB_APPROACHES, tag_data) or \
                     check_term(CREATE_ACCESS_TO_RESOURCES_AND_OR_PUBLIC_BENEFITS, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_SKILLS_FOR_SELF_SUFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(PROVIDE_CASE_MANAGEMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_COMMUNITY_ENVIRONMENTS_OR_SPACES, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or \
                     check_term(PRESERVE_TRADITIONAL_CULTURAL_PRACTICES, VOCAB_APPROACHES, tag_data) or \
                     check_term(PASS_LEGISLATION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, SUSTAINABLE_CITIES_AND_COMMUNITIES, tag_data)

        log.append("----")

        # Rule 12 Responsible Consumption and Production
        log.append("    rule 12")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
            (check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
             check_term(REDUCE_HOMELESSNESS, VOCAB_IMPACTS, tag_data) or \
             check_term(INCREASE_AMOUNT_AND_ACCESS_TO_QUALITY_AFFORDABLE_HOUSING, VOCAB_IMPACTS, tag_data)) and \
                (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, RESPONSIBLE_CONSUMPTION_AND_PRODUCTION, tag_data)

        log.append("-----")

        # Rule 13 Climate Action
        log.append("    rule 13")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
            (check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or
             check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, CLIMATE_ACTION, tag_data)

        log.append("-----")

        # Rule 14 Life Below Water
        log.append("    rule 14")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
            (check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
             check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
             check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
             check_term(PROTECT_ANIMAL_WELFARE, VOCAB_IMPACTS, tag_data) or \
             check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data)) and \
                (check_term(WATER, VOCAB_ANIMALHABITATS, tag_data) or \
                 check_term(BOTH_LAND_AND_WATER, VOCAB_ANIMALHABITATS, tag_data)):
            add_feature(_MY_SOURCE, LIFE_BELOW_WATER, tag_data)

        log.append("-----")

        # Rule 15 Life on Land
        log.append("     rule 15")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
            (check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
             check_term(PROTECT_ANIMAL_WELFARE, VOCAB_IMPACTS, tag_data) or \
             check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data)) and \
                (check_term(LAND, VOCAB_ANIMALHABITATS, tag_data) or \
                 check_term(BOTH_LAND_AND_WATER, VOCAB_ANIMALHABITATS, tag_data)):
            add_feature(_MY_SOURCE, LIFE_ON_LAND, tag_data)

        log.append("-----")

        # Rule 16 Promote just, peaceful and inclusive societies
        log.append("     rule 16")
        if (check_term(CRIMINAL_JUSTICE, VOCAB_CAUSES, tag_data) or \
            check_term(HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, VOCAB_CAUSES, tag_data)) and \
                (check_term(REDUCE_CRIMINAL_ACTIVITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CRIMINAL_RECIDIVISM, VOCAB_IMPACTS, tag_data) or \
                 check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PEACE_THROUGH_CONFLICT_RESOLUTION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_CIVIC_PARTICIPATION, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, PEACE__JUSTICE_AND_STRONG_INSTITUTIONS, tag_data)



        log.append("  Summary: " + ', '.join(document[_MY_SOURCE]["strings"]))

        # now put the version number into the same object
        document[_MY_SOURCE]["tagging-version"] = SELECTED_VOCABULARY_VERSION

        # cool!  save that object back and go!
        save_program_document(document)

    except Exception as eee:
        critical_alert(eee, log, "vocab_error_in_tagging")
        raise eee

    return log
