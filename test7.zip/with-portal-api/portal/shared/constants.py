from portal.shared.enums import UserRole

GIVEWITH_ROLES = [
    UserRole.SUPER_ADMIN,
    UserRole.GW_CSM,
    UserRole.GW_FINANCE,
    UserRole.GW_OPERATIONS
]

CUSTOMER_ROLES = [
    UserRole.ORG_ADMIN,
    UserRole.USER_ADMIN,
    UserRole.FINANCE,
    UserRole.APPROVER,
    UserRole.SALES,
    UserRole.TRANSACTOR,
    UserRole.EXECUTIVE
]

ROLES_TO_STRING = {
    UserRole.SUPER_ADMIN:   'Givewith Super Admin',
    UserRole.GW_CSM:        'Givewith CSM',
    UserRole.GW_FINANCE:    'Givewith Finance',
    UserRole.GW_OPERATIONS: 'Givewith Operations',
    UserRole.APPROVER:      'Approver',
    UserRole.EXECUTIVE:     'Executive',
    UserRole.FINANCE:       'Finance User',
    UserRole.ORG_ADMIN:     'Org Admin',
    UserRole.SALES:         'Sales User',
    UserRole.TRANSACTOR:    'Transactor',
}

MONTH_END_TABLE = {
    'Date': {},
    'Givewith-Order-ID': {},
    'Client-ID': {},
    'Client-Name': {},
    'Client-Account-Name': {},
    'Customer-Name': {},
    'Subscription-Term': {},
    'Autopay': {},
    'Stripe-Subscription-ID': {},
    'Stripe-Payment-Intent-ID': {},
    'Stripe-Customer-ID': {},
    'Stripe-Period-Start': {},
    'Stripe-Period-End': {},
    'Transaction-ID': {},
    'Sage-Bill-Record-Number': {},
    'Sage-Bill-Record-No': {},
    'Sage-Invoice-ID': {},
    'Sage-Customer-ID': {},
    'Sage-Invoice-Record-No': {},
    'Transaction-ID': {},
    'Status': {},
    'Transaction-Amount': {},
    'Give-Amount': {},
    'Social-Cause': {},
    'User-Email': {},
}
