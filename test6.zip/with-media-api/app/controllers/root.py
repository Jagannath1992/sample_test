from os import environ
from app import root_bp

@root_bp.route('/', methods=['GET'])
def root():
    return 'Givewith-media-api running on ' + str(environ.get('ENV', 'local'))
