from typing import Dict, Any


class FlagService:
    def __init__(self, config: Dict[str, Any]):
        self._domain_validation = config['domain_validation']

    def validate_domains(self) -> bool:
        return self._domain_validation
