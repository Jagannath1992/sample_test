from bson.objectid import ObjectId

from app.db.utils import aggregate_on

def translate_to_topic(vocab_id):
    pipeline = [
        {'$match': {'_id': ObjectId(vocab_id)}},
        {'$lookup': {'from': 'mm_vocabulary', 'localField': 'topic', 'foreignField': '_id', 'as': 'topic'}},
        {'$unwind': '$topic'},
        {'$project': {'_id': '$topic._id', 'label': '$topic.label'}}
    ]

    return next(aggregate_on('mm_vocabulary', pipeline), {})
