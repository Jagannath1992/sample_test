from matchmaking.dao.nonprofit_form_dao import calcProgress
from matchmaking.controllers.matchmaking.mpa import set_progress


def test_mpa_progress():
    # test full mpa
    mpa = {
        "info": {
            "orgDescription": "organizational description",
            "name": "name",
            "title": "title",
            "email": "test@email.com",
            "phone": "(555) 555-1234",
            "address": "first line address",
            "city": "New York",
            "state": "NY",
            "zip": "10001",
        },
        "review": {
            "name": "reviewer",
            "email": "e@mail.com",
        },
        "status": "SIGNATURE_PENDING",
        "effectiveDate": '',
        "expirationDate": '',
        "addendum": {
            "file": "addendum_file.pdf",
            "url": "https://s3.amazonaws.com",
        },
        "legalNotes": "legal notes",
        "progress": {
            "info": {
                "complete": 10,
                "total": 10,
            }
        },
        "percentComplete": 100,
    }

    set_progress(mpa)
    assert mpa['percentComplete'] == 100

    # test remove optional fields
    mpa = {
        "info": {
            "orgDescription": "organizational description",
            "name": "name",
            # "title": "title",
            "email": "test@email.com",
            # "phone": "(555) 555-1234",
            "address": "first line address",
            "city": "New York",
            "state": "NY",
            "zip": "10001",
        },
        "review": {
            "name": "reviewer",
            "email": "e@mail.com",
        },
        "status": "SIGNATURE_PENDING",
        "effectiveDate": '',
        "expirationDate": '',
        "addendum": {
            "file": "addendum_file.pdf",
            "url": "https://s3.amazonaws.com",
        },
        "legalNotes": "legal notes",
        "progress": {
            "info": {
                "complete": 10,
                "total": 10,
            }
        },
        "percentComplete": 100,
    }

    set_progress(mpa)
    assert mpa['percentComplete'] == 100

    # test remove required fields
    mpa = {
        "info": {
            "orgDescription": "organizational description",
            "name": "name",
            # "title": "title",
            # "email": "test@email.com",
            # "phone": "(555) 555-1234",
            "address": "first line address",
            "city": "New York",
            "state": "NY",
            "zip": "10001",
        },
        "review": {
            "name": "reviewer",
            "email": "e@mail.com",
        },
        "status": "SIGNATURE_PENDING",
        "effectiveDate": '',
        "expirationDate": '',
        "addendum": {
            "file": "addendum_file.pdf",
            "url": "https://s3.amazonaws.com",
        },
        "legalNotes": "legal notes",
        "progress": {
            "info": {
                "complete": 10,
                "total": 10,
            }
        },
        "percentComplete": 100,
    }

    set_progress(mpa)
    assert mpa['percentComplete'] < 100
    assert int(mpa['progress']['info']['complete']) < int(mpa['progress']['info']['total'])


def test_naf_cal_progress():
    # US
    form = {
        "general" : {
            "name" : {
                "legalOrganizationName" : "legal",
                "publicOrganizationName" : "public"
            },
            "social" : {
                "websiteURL" : "website",
                "facebook" : "facebook",
                "instagram" : "instagram",
                "linkedIn" : "linkedin",
                "twitter" : "twitter"
            },
            "contact" : {
                "email" : "mattszekalski@icloud.com",
                "name" : "Matthew Szekalski",
                "phone" : "6317427433",
                "professionalTitle" : "Not-employed"
            },
            "location" : {
                "generalLocation" : "United States",
                "specificLocation" : "Alaska",
                "w9" : {
                    "name" : "Givewith.pdf",
                    "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833717126.pdf"
                },
                "taxId" : "21-3213213"
            },
            "missionAgreement" : True
        },
        "overviewAndMission" : {
            "historyDescription" : "dfdsafdsa",
            "problemDescription" : "fdsfaasdfdsa",
            "causeAreas" : {
                "selected" : [
                    "5d44b3b4d5b3a55e9e513cc9",
                    "5d44b3b4d5b3a55e9e513cca"
                ]
            },
            "initiativesDescription" : "fdsadsafsd",
            "programLocations" : "fdsfadsfsa",
            "researchAndEvaluation" : "fsdafdsafads",
            "researchAndEvaluationFile" : {
                "name" : "Givewith.pdf",
                "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833759566.pdf"
            },
            "lifetimeOutputs" : [
                {
                    "quantity" : "23",
                    "output" : "fsadf"
                },
                {
                    "quantity" : "213",
                    "output" : "fsda"
                },
                {
                    "quantity" : "32",
                    "output" : "fdsafd"
                }
            ]
        },
        "operationalInformation" : {
            "staff" : {
                "fullTime" : "12",
                "partTime" : "12",
                "volunteers" : "12"
            },
            "partnershipsDescription" : "fdsafdsa",
            "yearlyBudget" : "21312",
            "yearlyBudgetCurrency": "USD",
            "financialStatement" : {
                'website': '1',
                'file': {
                    'name': 'Givewith.pdf',
                    "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833791243.pdf"
                }
            },
            "supportersAndPartners" : "fdsafsdasda"
        },
    }
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage == 100

    # UK
    form = {
        "general": {
            "name": {
                "legalOrganizationName": "legal",
                "publicOrganizationName": "public"
            },
            "social": {
                "websiteURL": "website",
                "facebook": "facebook",
                "instagram": "instagram",
                "linkedIn": "linkedin",
                "twitter": "twitter"
            },
            "contact": {
                "email": "mattszekalski@icloud.com",
                "name": "Matthew Szekalski",
                "phone": "6317427433",
                "professionalTitle": "Not-employed"
            },
            "location": {
                "generalLocation": "United Kingdom",
                "specificLocation": "England",
                "charityNumber": "2134321",
                "companyHouseNumber": "3123123123"
            },
            "missionAgreement": True
        },
        "overviewAndMission": {
            "historyDescription": "dfdsafdsa",
            "problemDescription": "fdsfaasdfdsa",
            "causeAreas": {
                "selected": [
                    "5d44b3b4d5b3a55e9e513cc9",
                    "5d44b3b4d5b3a55e9e513cca"
                ]
            },
            "initiativesDescription": "fdsadsafsd",
            "programLocations": "fdsfadsfsa",
            "researchAndEvaluation": "fsdafdsafads",
            "researchAndEvaluationFile": {
                "name": "Givewith.pdf",
                "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833759566.pdf"
            },
            "lifetimeOutputs": [
                {
                    "quantity": "23",
                    "output": "fsadf"
                },
                {
                    "quantity": "213",
                    "output": "fsda"
                },
                {
                    "quantity": "32",
                    "output": "fdsafd"
                }
            ]
        },
        "operationalInformation": {
            "staff": {
                "fullTime": "12",
                "partTime": "12",
                "volunteers": "12"
            },
            "partnershipsDescription": "fdsafdsa",
            "yearlyBudget": "21312",
            "yearlyBudgetCurrency": "USD",
            "financialStatement": {
                'website': '1',
                'file': {
                    'name': 'Givewith.pdf',
                    "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833791243.pdf"
                }
            },
            "supportersAndPartners": "fdsafsdasda"
        },
    }
    progress, percentage, incomplete_fields = calcProgress(form)

    assert percentage == 100

    # OTHERS
    form = {
        "general": {
            "name": {
                "legalOrganizationName": "legal",
                "publicOrganizationName": "public"
            },
            "social": {
                "websiteURL": "website",
                "facebook": "facebook",
                "instagram": "instagram",
                "linkedIn": "linkedin",
                "twitter": "twitter"
            },
            "contact": {
                "email": "mattszekalski@icloud.com",
                "name": "Matthew Szekalski",
                "phone": "6317427433",
                "professionalTitle": "Not-employed"
            },
            "location" : {
                "generalLocation" : "Other",
                "specificLocation" : "Algeria",
                "otherId" : "23424232"
            },
            "missionAgreement": True
        },
        "overviewAndMission": {
            "historyDescription": "dfdsafdsa",
            "problemDescription": "fdsfaasdfdsa",
            "causeAreas": {
                "selected": [
                    "5d44b3b4d5b3a55e9e513cc9",
                    "5d44b3b4d5b3a55e9e513cca"
                ]
            },
            "initiativesDescription": "fdsadsafsd",
            "programLocations": "fdsfadsfsa",
            "researchAndEvaluation": "fsdafdsafads",
            "researchAndEvaluationFile": {
                "name": "Givewith.pdf",
                "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833759566.pdf"
            },
            "lifetimeOutputs": [
                {
                    "quantity": "23",
                    "output": "fsadf"
                },
                {
                    "quantity": "213",
                    "output": "fsda"
                },
                {
                    "quantity": "32",
                    "output": "fdsafd"
                }
            ]
        },
        "operationalInformation": {
            "staff": {
                "fullTime": "12",
                "partTime": "12",
                "volunteers": "12"
            },
            "partnershipsDescription": "fdsafdsa",
            "yearlyBudget": "21312",
            "yearlyBudgetCurrency": "USD",
            "financialStatement": {
                'website': '1',
                'file': {
                    'name': 'Givewith.pdf',
                    "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833791243.pdf"
                }
            },
            "supportersAndPartners": "fdsafsdasda"
        },
    }
    progress, percentage, incomplete_fields = calcProgress(form)

    assert percentage == 100

    # financial statement with website only
    form = {
        "general" : {
            "name" : {
                "legalOrganizationName" : "legal",
                "publicOrganizationName" : "public"
            },
            "social" : {
                "websiteURL" : "website",
                "facebook" : "facebook",
                "instagram" : "instagram",
                "linkedIn" : "linkedin",
                "twitter" : "twitter"
            },
            "contact" : {
                "email" : "mattszekalski@icloud.com",
                "name" : "Matthew Szekalski",
                "phone" : "6317427433",
                "professionalTitle" : "Not-employed"
            },
            "location" : {
                "generalLocation" : "United States",
                "specificLocation" : "Alaska",
                "w9" : {
                    "name" : "Givewith.pdf",
                    "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833717126.pdf"
                },
                "taxId" : "21-3213213"
            },
            "missionAgreement" : True
        },
        "overviewAndMission" : {
            "historyDescription" : "dfdsafdsa",
            "problemDescription" : "fdsfaasdfdsa",
            "causeAreas" : {
                "selected" : [
                    "5d44b3b4d5b3a55e9e513cc9",
                    "5d44b3b4d5b3a55e9e513cca"
                ]
            },
            "initiativesDescription" : "fdsadsafsd",
            "programLocations" : "fdsfadsfsa",
            "researchAndEvaluation" : "fsdafdsafads",
            "researchAndEvaluationFile" : {
                "name" : "Givewith.pdf",
                "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833759566.pdf"
            },
            "lifetimeOutputs" : [
                {
                    "quantity" : "23",
                    "output" : "fsadf"
                },
                {
                    "quantity" : "213",
                    "output" : "fsda"
                },
                {
                    "quantity" : "32",
                    "output" : "fdsafd"
                }
            ]
        },
        "operationalInformation" : {
            "staff" : {
                "fullTime" : "12",
                "partTime" : "12",
                "volunteers" : "12"
            },
            "partnershipsDescription" : "fdsafdsa",
            "yearlyBudget" : "21312",
            "yearlyBudgetCurrency": "USD",
            "financialStatement" : {
                'website': '1',
            },
            "supportersAndPartners" : "fdsafsdasda"
        },
    }
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage == 100

    # financial statement with file only
    form = {
        "_id": "5e58449b690a25240e360e51",
        "applicationFormName": "fdsadfsa",
        "givewithAdmin": "5a611261d57e4529cd3a24ea",
        "slug": "5e58449b690a25240e360e51",
        "editing": True,
        "status": "IN_PROGRESS",
        "percentComplete": 29,
        "createdAt": "2020-02-27T22:37:15.958Z",
        "lastUpdated": "2020-02-27T22:50:37.046Z",
        "createdBy": "5c93a8742268f180706a0da0",
        "operationalInformation": {
            "staff": {
                "fullTime": "12",
                "partTime": "21",
                "volunteers": "12"
            },
            "partnershipsDescription": "dsfsdasda",
            "yearlyBudget": "213",
            "yearlyBudgetCurrency": "USD",
            "supportersAndPartners": "fdsfdsafds",
            "financialStatement": {
                'website': '',
                "file": {
                    "name": "chandler.gif",
                    "url": "nonprofit_form/5e58449b690a25240e360e51/chandler_1582843836488.gif"
                }
            }
        }
    }
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage < 100
    assert progress['operationalInformation']['complete'] == progress['operationalInformation']['total']

    # financial statement with none
    form = {
        "general" : {
            "name" : {
                "legalOrganizationName" : "legal",
                "publicOrganizationName" : "public"
            },
            "social" : {
                "websiteURL" : "website",
                "facebook" : "facebook",
                "instagram" : "instagram",
                "linkedIn" : "linkedin",
                "twitter" : "twitter"
            },
            "contact" : {
                "email" : "mattszekalski@icloud.com",
                "name" : "Matthew Szekalski",
                "phone" : "6317427433",
                "professionalTitle" : "Not-employed"
            },
            "location" : {
                "generalLocation" : "United States",
                "specificLocation" : "Alaska",
                "w9" : {
                    "name" : "Givewith.pdf",
                    "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833717126.pdf"
                },
                "taxId" : "21-3213213"
            },
            "missionAgreement" : True
        },
        "overviewAndMission" : {
            "historyDescription" : "dfdsafdsa",
            "problemDescription" : "fdsfaasdfdsa",
            "causeAreas" : {
                "selected" : [
                    "5d44b3b4d5b3a55e9e513cc9",
                    "5d44b3b4d5b3a55e9e513cca"
                ]
            },
            "initiativesDescription" : "fdsadsafsd",
            "programLocations" : "fdsfadsfsa",
            "researchAndEvaluation" : "fsdafdsafads",
            "researchAndEvaluationFile" : {
                "name" : "Givewith.pdf",
                "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833759566.pdf"
            },
            "lifetimeOutputs" : [
                {
                    "quantity" : "23",
                    "output" : "fsadf"
                },
                {
                    "quantity" : "213",
                    "output" : "fsda"
                },
                {
                    "quantity" : "32",
                    "output" : "fdsafd"
                }
            ]
        },
        "operationalInformation" : {
            "staff" : {
                "fullTime" : "12",
                "partTime" : "12",
                "volunteers" : "12"
            },
            "partnershipsDescription" : "fdsafdsa",
            "yearlyBudget" : "21312",
            "yearlyBudgetCurrency": "USD",
            "supportersAndPartners" : "fdsafsdasda"
        },
    }
    progress, percentage, incomplete_fields = calcProgress(form)

    assert percentage < 100


def test_empty_field():
    form = {
        "general": {
            "name": {
                "legalOrganizationName": "legal",
                "publicOrganizationName": "public"
            },
            "social": {
                "websiteURL": "website",
                "facebook": "facebook",
                "instagram": "instagram",
                "linkedIn": "linkedin",
                "twitter": "twitter"
            },
            "contact": {
                "email": "mattszekalski@icloud.com",
                "name": "Matthew Szekalski",
                "phone": "6317427433",
                "professionalTitle": "Not-employed"
            },
            "location": {
                "generalLocation": "United Kingdom",
                "specificLocation": "England",
                "charityNumber": "2134321",
                "companyHouseNumber": "3123123123"
            },
            "missionAgreement": True
        },
        "overviewAndMission": {
            "historyDescription": "dfdsafdsa",
            "problemDescription": "fdsfaasdfdsa",
            "causeAreas": {
                "selected": [
                    "5d44b3b4d5b3a55e9e513cc9",
                    "5d44b3b4d5b3a55e9e513cca"
                ]
            },
            "initiativesDescription": "fdsadsafsd",
            "programLocations": "fdsfadsfsa",
            "researchAndEvaluation": "fsdafdsafads",
            "researchAndEvaluationFile": {
                "name": "Givewith.pdf",
                "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833759566.pdf"
            },
            "lifetimeOutputs": [
                {
                    "quantity": "23",
                    "output": "fsadf"
                },
                {
                    "quantity": "213",
                    "output": "fsda"
                },
                {
                    "quantity": "32",
                    "output": "fdsafd"
                }
            ]
        },
        "operationalInformation": {
            "staff": {
                "fullTime": "12",
                "partTime": "12",
                "volunteers": "12"
            },
            "partnershipsDescription": "fdsafdsa",
            "yearlyBudget": "21312",
            "yearlyBudgetCurrency": "USD",
            "financialStatement": {
                'website': '1',
                'file': {
                    'name': 'Givewith.pdf',
                    "url": "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e399b85cc746d3718a0ead8/Givewith_1580833791243.pdf"
                }
            },
            "supportersAndPartners": "fdsafsdasda"
        },
    }
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage == 100

    # set required filed to empty string
    form['general']['name']['legalOrganizationName'] = ''
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage < 100

    # restore
    form['general']['name']['legalOrganizationName'] = 'name'
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage == 100

    # set list to empty list
    form['overviewAndMission']['lifetimeOutputs'] = []
    progress, percentage, incomplete_fields = calcProgress(form)
    assert percentage < 100
