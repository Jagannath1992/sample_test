import pytest
from portal.features.cause_areas.validators import CauseAreaValidator
from werkzeug.exceptions import NotFound, BadRequest
from portal.shared.repositories import cause_area_repository, instance_settings_repository


class TestCauseAreaValidator:
    def test_ca_name_not_exist(self, mocker, fakers):
        cause_area = fakers.cause_area.generate_single()
        mocker.patch.object(cause_area_repository(), 'exists_by_filter', return_value=False)
        validator = CauseAreaValidator(cause_area)
        assert validator.validate_cause_area_name() == None

    def test_ca_name_exist(self, mocker, fakers):
        cause_area = fakers.cause_area.generate_single()
        mocker.patch.object(cause_area_repository(), 'exists_by_filter', return_value=True)
        validator = CauseAreaValidator(cause_area)
        with pytest.raises(BadRequest):
            validator.validate_cause_area_name()

    def test_ca_instance_exist(self, mocker, fakers):
        cause_area = fakers.cause_area.generate_single()
        update = fakers.cause_area.generate_single()
        validator = CauseAreaValidator(update, cause_area)
        cause_area['instanceCount'] = 1
        update['active'] = False
        mocker.patch.object(instance_settings_repository(), 'populate_cause_area_instance_counts', return_value=cause_area)
        with pytest.raises(BadRequest):
            validator.validate_cause_area_status()

    def test_ca_instance_not_exist(self, mocker, fakers):
        cause_area = fakers.cause_area.generate_single()
        update = fakers.cause_area.generate_single()
        validator = CauseAreaValidator(update, cause_area)
        cause_area['instanceCount'] = 0
        update['active'] = False
        mocker.patch.object(instance_settings_repository(), 'populate_cause_area_instance_counts', return_value=cause_area)
        assert validator.validate_cause_area_status() == None
