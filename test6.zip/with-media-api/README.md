# givewith-media-api
<sub><sup><sup>aka give me a pi<sup/></sup></sub>

## Setup

Install dependencies with pip:

`pip install -r requirements.txt`

and export environment variables

`export AWS_ACCESS_KEY_ID=<some-key>`

`export AWS_SECRET_ACCESS_KEY=<some-key>`

run `db.getCollection('simian_media').createIndex({tags : "text"}, {default_language: "none"})` to enable proper searching used in the endpoint queries

### Start

Run `./runnit.sh` to start application.


### Testing

Run `pytest` to run all tests


## About

### What is Media API used for?

#### Short version
This repo is used to surface media content hosted on [Simian](https://www.gosimian.com/) to all of our front end repos (as of 10/1/2010, that includes: Matchmaking ui, Share ui, Sales ui). All of this content is created by the Givewith studio team and includes photos and videos of nonprofits and programs. Whenever a program or a nonprofit is displayed to our customer (think during the program selection process, a brand's preferred programs or receieving deliverables after a deal is closed), these assets are used to help tell the nonprofit's/program's story. 

#### Long verison

Media API is just one part of the Simian workflow. This work primarily contains three parts:
1) Injest Simian data 
2) Hit Media API endpoints
3) Surface and display media

As some context, each piece of media on Simian has a set of particular fields. The most important field, other than the media URLs themselves, is the `tags` field. These tags indicate the type of media, what nonprofit or program it’s associated with and where to display such content. You can find our Simian media library [here](https://givewith.gosimian.com/). 

Below is an part of a Simian document with the most important fields:

```
{
    "_id" : ObjectId("5f3d5318e1fee4c9ac74c7a5"),
    "id" : "124",
    "category" : "Digital Poster",
    "credits" : {
        "npo_name" : "NPO Black Girls Code"
    },
    "title" : "Black Girls CODE_Dig Poster_07_Horiz",
    "thumbnail" : "https://givewith.gosimian.com/assets/thumbs/th_BLACK-GIRLS-CODE_POSTER_BEN-KAI_01_HORIZ.jpg",
    "media_file" : "https://givewith.gosimian.com/assets/images/BLACK-GIRLS-CODE_POSTER_BEN-KAI_01_HORIZ.jpg",
    "description" : "Meet Kai. Black Girls CODE empowered her to see herself as a creator and leader of the digital space. As a volunteer, she continues to share the power of diversity in tech with young girls nationwide. [+KPI- specific call to action]",
    "tags" : "Digital Poster,Education,Final,Horizontal,Beneficiary Profile,US,NPO Generic,",
    "media_s3" : "https://staging-simian-media.s3.amazonaws.com/BLACK-GIRLS-CODE_POSTER_BEN-KAI_01_HORIZ.jpg",
    "thumbnail_s3" : "https://staging-simian-media.s3.amazonaws.com/thumbnail_th_BLACK-GIRLS-CODE_POSTER_BEN-KAI_01_HORIZ.jpg"
}
````

##### Ingest Simian data

For every hour after [Research API](https://github.com/EcoMedia/research-api/blob/develop/research_api/cron/job_handler.py) starts, Simian data will be parsed and added to our database collection `simian_media`; only items that include the `Final` string in the `tags` field are added. This cron job will associate the `npo_name` with a nonprofit id in our database and `program_name` with a program id. It will also add the URLs for each item will be uploaded to our s3 bucket `<ENV>-simian-media` (`media_file` field is uploaded to s3 -> `media_s3` field; same with `thumbnail` -> `thumbnail_s3`)

##### Hit Media API endpoints
The following are a list of Media API's controllers and what is included in each. 

These controllers handle surfacing particular assets depending on what strings are found in the `tags` field. You can find information on the exact logic in either the comments with each endpoint or in the [Simian requirements doc](https://docs.google.com/document/d/1NuyGLJZRzpVX0qr3CEkziLwVzcIhOw3WamUXbH0yEFQ/edit#).

- *Asset*
    - download any asset
    - tokenize a list of urls from a private bucket
    - select an asset from the asset selection modal and saving that selection on either a deal or a share action (this modal allows customers/clients to choose one out of a list of assets to download)
- *Deals controller*
    - get customer assets for the asset selection modal
    - get client assets for the asset selection modal
- *Nonprofit*
    - get nonprofit overview video used on PDPs
- *Preview Assets*
    - get assets that are seen on deliverable modals (for example the one on a PDP). On the preferred programs flow, show all photos/videos associated with the program. For all other instances, only show 1 photo and 1 video to customer/client.
- *Program*
    - get program hero images, aka the landscape and portrait images used on PDPs, program cards and anywhere else a program appears

##### Surfacing assets on our UI

There are many, many places these assets appear on the UI. To see more details on all the locations, please refer to the [Simian requirements doc](https://docs.google.com/document/d/1NuyGLJZRzpVX0qr3CEkziLwVzcIhOw3WamUXbH0yEFQ/edit#), but the two most prominent places Simian data shows up is any reference to a program (like a selected program in deal or a PDP) and when selecting a photo/video to download on a completed deal. 

