# -*- coding: utf-8 -*-
import re

from bson import ObjectId

from .mongodb import db

strength_map = {
    'researchType': {
        'research validated': 1,
        'evidence based': 1
    },
    'dataMeasurement': {
        'quantitatively': 1
    },
    'programApproach': {
        'changing behavior (train; mentor)': 1,
        'building capacity (strengthen institutions, programs or systems)': 1,
        'increasing awareness (advocate; lobby)': 1,
        'research': 1,
    }
}


def get_score_map_key(value):
    if type(value) == ObjectId:
        value = db().map_id_to_label[value].lower()
    elif re.match(r'^(?=[a-f\d]{24}$)(\d+[a-f]|[a-f]+\d)', value):
        value = db().map_id_to_label[ObjectId(value)].lower()
    return value


def rule_secondary_impacts(program, *args, **kw):
    strength = (0, None)
    if program.get('secondaryImpacts', []):
        strength = (1, 'secondaryImpacts')
    return strength


def rule_one_or_more_partner_organizations(program, *args, **kw):
    strength = (0, None)
    if program.get('oneOrMorePartnerOrganizations', False):
        strength = (1, 'oneOrMorePartnerOrganizations')
    return strength


def rule_audience_attributes(program, *args, **kw):
    strength = (0, None)
    if program.get('audienceAttribute', []):
        strength = (1, 'audienceAttribute')
    return strength


def rule_primary_outcome_effectiveness(program, *args, **kw):
    strength = (0, None)
    value = program.get('primaryOutcomeEffectiveness')
    if value:
        strength = strength_map['researchType'].get(get_score_map_key(value), 0)
        if strength is not 0:
            strength = (strength, 'primaryOutcomeEffectiveness')
        else:
            strength = (0, None)
    return strength


def rule_data_measurement_type(program, *args, **kw):
    strength = (0, None)
    value = program.get('dataMeasurementType')
    if value:
        strength = strength_map['dataMeasurement'].get(get_score_map_key(value), 0)
        if strength is not 0:
            strength = (strength, 'dataMeasurementType')
        else:
            strength = (0, None)
    return strength


def rule_effectiveness_rating(program, *args, **kw):
    strength = (0, None)

    settings = kw.get('settings', None)
    if not settings:
        settings = db().coll_settings.find_one()

    effectiveness_rating = float(program.get('effectivenessRating', 0))
    if effectiveness_rating >= settings['scoringSettings']['minimumHigh']:
        strength = (1, 'effectivenessRating')
    return strength


def rule_program_approach(program, *args, **kw):
    strength = (0, None)
    values = program.get('programApproach')
    if values:
        if type(values) != list:
            values = [values]
        strength = max(strength_map['programApproach'].get(get_score_map_key(v), 0) for v in values)
        if strength is not 0:
            strength = (strength, 'programApproach')
        else:
            strength = (0, None)
    return strength
