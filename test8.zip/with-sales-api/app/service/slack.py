import os
import requests

from flask import current_app
from json import dumps
from app.utils.token import get_user_from_token


def send_new_deal_message(deal):
    env = os.environ.get('ENV').lower()
    if not env.startswith('prod'):
        return

    data = {
        "text": "[SALES] new sales deal has been created",
        "blocks":
            [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        'text': create_deal_slack_msg(deal, env)
                    },
                },
            ]
    }

    return requests.post(
        current_app.config['SLACK_WEB_HOOK'],
        data=dumps(data),
        headers={'Content-Type': 'application/json'}
    )


def create_deal_slack_msg(deal, env):
    user = get_user_from_token()

    msg = '{0} a *{1}* deal <{2}|{3}> created by *{4}* in *{5}*'
    at_here = '<!here>' if env.startswith('prod') else ''

    return msg.format(
        at_here,
        deal.get('type'),
        current_app.config['MATCHMAKING_API_ENDPOINT'] + '/#/deals/' + str(deal.get('_id')),
        deal.get('name'),
        user.get('name'),
        env
    )
