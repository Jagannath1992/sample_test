import re
from typing import Dict, Any
import urllib
from bson import ObjectId
from ..utils import EntityNotFound, UnsupportedId
from ..mongodb import raw_db


"""
validate document against schema
"""
def validate_schema(schema, document):
    errors = []
    for key in schema:
        if key not in document:
            errors.append('%s is required' % key)
            continue

        typ = schema.get(key)
        if not isinstance(typ, type):
            typ = type(typ)

        if not isinstance(document.get(key), typ):
            errors.append('%s has invalid type. expect %s, got %s' % (key, typ.__name__, type(document.get(key)).__name__))
            continue

        if typ in [list, tuple]:
            errors += validate_list(schema.get(key), document.get(key))

        if typ == dict:
            errors += validate_schema(schema.get(key), document.get(key))

        if len(str(document.get(key))) == 0:
            errors.append('%s has empty value' % key)

    return errors


def validate_list(schema, documents):
    errors = []
    typ = schema[0]
    if not isinstance(typ, type):
        typ = type(typ)

    if typ in [list, tuple]:
        for doc in documents:
            errors += validate_list(schema[0], doc)
            return errors

    if schema is dict:
        for doc in documents:
            errors += validate_schema(schema[0], doc)
            return errors

    for doc in documents:
        if not isinstance(doc, typ):
            errors.append('%s has invalid type. expect %s, got %s' % (doc, typ.__name__, type(doc).__name__))

    return errors


""" 
1. validate if object_id is a valid mongodb key
2. validate if object_id exist in the collection
"""
def validate_object_id(object_id, collection_name) -> bool:
    if not ObjectId.is_valid(object_id):
        raise UnsupportedId(object_id)

    count = raw_db()[collection_name].count_documents({'_id': ObjectId(object_id)})
    if count == 0:
        raise EntityNotFound(collection_name, object_id)


""" 
validate if value exist in the collection
"""
def validate_existence(key, value, collection_name):
    count = raw_db()[collection_name].count_documents({key: value})
    return count > 0


'''
validate if document with key-value pairs exist in the collection
'''
def validate_existences(key_value_pairs: Dict[str, Any], collection_name: str) -> bool:
    count = raw_db()[collection_name].count_documents(key_value_pairs)
    return count > 0


"""
valid formats include 1234567890, 123-456-7890, 123.456.7890.
"""
def is_valid_phone_number(field, value, error):
    valid = re.match(r"^\(?([0-9]{3})\)?[-.●]?([0-9]{3})[-.●]?([0-9]{4})$", value) is not None
    if not valid:
        error(field, 'invalid phone number')


def is_uri_valid(url):
    try:
        result = urllib.request.urlparse(url)
        return all([result.scheme, result.netloc, result.path])
    except:
        return False
