from bson.objectid import ObjectId

reports = [
    {
        'brandId' : ObjectId('5fad58987cae51199d14525b'),
        'customerStatus' : False,
        'slug' : '53unQ4X2RVikiVq',
        'password' : 'k3EI98xeHl5f',
        'name' : 'another greate name',
        'createdAt' : '2020-11-06T19:07:56.096Z',
        'lastUpdated' : '2020-11-13T13:39:46.656Z',
        'createdBy' : '5cb0a76b28386f7c5d65c9de',
        'category' : 'updated the category too',
        'suppliers' : [
            ObjectId('5fad58987cae51199d14525b')
        ]
    }
]
