from datetime import datetime
from matchmaking.controllers.dashboard.pilot_reporting import organize_funding_items_by_quarter, QUARTERS


def test_quarterly_date_full():
    deals = [{
        '_id': '1',
        'fundingAmount': 140000,
        'statusUpdatedAt': datetime(2020, 7, 13, 16, 29, 44, 87000),
        'totalBudget': 10000000
    }, {
        '_id': '2',
        'fundingAmount': 140000,
        'statusUpdatedAt': datetime(2020, 4, 13, 16, 29, 44, 87000),
        'totalBudget': 10000000
    }, {
        '_id': '3',
        'fundingAmount': 500,
        'statusUpdatedAt': datetime(2020, 2, 24, 16, 2, 48, 419000),
        'totalBudget': 1234134444
    }, {
        '_id': '4',
        'fundingAmount': 70000,
        'statusUpdatedAt': datetime(2020, 1, 27, 20, 51, 59, 855000),
        'totalBudget': 5000000
    }, {
        '_id': '5',
        'fundingAmount': 0.03,
        'statusUpdatedAt': datetime(2019, 11, 11, 18, 6, 16, 50000),
        'totalBudget': 1
    }, {
        '_id': '6',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 10, 10, 20, 0, 9, 920000),
        'totalBudget': 1
    }, {
        '_id': '7',
        'fundingAmount': 10000,
        'statusUpdatedAt': datetime(2019, 9, 27, 17, 50, 45, 315000),
        'totalBudget': 250000
    }, {
        '_id': '8',
        'fundingAmount': 100000,
        'statusUpdatedAt': datetime(2019, 9, 23, 17, 40, 50, 767000),
        'totalBudget': 250000
    }, {
        '_id': '9',
        'fundingAmount': 123,
        'statusUpdatedAt': datetime(2019, 8, 13, 17, 16, 47, 538000),
        'totalBudget': 1233,
    }, {
        '_id': '10',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 6, 11, 22, 11, 13, 414000),
        'totalBudget': 1,
    }, {
        '_id': '11',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 3, 8, 22, 11, 13, 414000),
        'totalBudget': 1,
    }, {
        '_id': '12',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 1, 2, 22, 11, 13, 414000),
        'totalBudget': 1,
    }]

    organized_deals = organize_funding_items_by_quarter(deals, 'statusUpdatedAt')

    assert len(organized_deals.get(2021)['Q4']) == 0
    assert len(organized_deals.get(2021)['Q3']) == 0
    assert len(organized_deals.get(2021)['Q3']) == 0
    assert len(organized_deals.get(2021)['Q1']) == 0

    assert len(organized_deals.get(2020)['Q4']) == 0
    assert len(organized_deals.get(2020)['Q3']) == 1
    assert len(organized_deals.get(2020)['Q2']) == 1
    assert len(organized_deals.get(2020)['Q1']) == 2

    assert len(organized_deals.get(2019)['Q4']) == 2
    assert len(organized_deals.get(2019)['Q3']) == 3
    assert len(organized_deals.get(2019)['Q2']) == 1
    assert len(organized_deals.get(2019)['Q1']) == 2


def test_quarterly_date_missing_data():
    deals = [{
        '_id': '1',
        'fundingAmount': 0.03,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 11, 11, 18, 6, 16, 50000),
        'totalBudget': 1
    }, {
        '_id': '2',
        'fundingAmount': 1,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 10, 10, 20, 0, 9, 920000),
        'totalBudget': 1
    }, {
        '_id': '3',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 3, 8, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '4',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 1, 2, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '4',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2017, 9, 9, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }]

    organized_deals = organize_funding_items_by_quarter(deals, 'statusUpdatedAt')

    assert list(organized_deals.get(2021).keys()) == QUARTERS
    assert len(organized_deals.get(2021)['Q4']) == 0
    assert len(organized_deals.get(2021)['Q3']) == 0
    assert len(organized_deals.get(2021)['Q3']) == 0
    assert len(organized_deals.get(2021)['Q1']) == 0

    assert list(organized_deals.get(2020).keys()) == QUARTERS
    assert len(organized_deals.get(2020)['Q4']) == 0
    assert len(organized_deals.get(2020)['Q3']) == 0
    assert len(organized_deals.get(2020)['Q2']) == 0
    assert len(organized_deals.get(2020)['Q1']) == 0

    assert list(organized_deals.get(2019).keys()) == QUARTERS
    assert len(organized_deals.get(2019)['Q4']) == 2
    assert len(organized_deals.get(2019)['Q3']) == 0
    assert len(organized_deals.get(2019)['Q2']) == 0
    assert len(organized_deals.get(2019)['Q1']) == 2

    assert list(organized_deals.get(2018).keys()) == QUARTERS
    assert len(organized_deals.get(2018)['Q4']) == 0
    assert len(organized_deals.get(2018)['Q3']) == 0
    assert len(organized_deals.get(2018)['Q2']) == 0
    assert len(organized_deals.get(2018)['Q1']) == 0

    assert list(organized_deals.get(2017).keys()) == QUARTERS
    assert len(organized_deals.get(2017)['Q4']) == 0
    assert len(organized_deals.get(2017)['Q3']) == 1
    assert len(organized_deals.get(2017)['Q2']) == 0
    assert len(organized_deals.get(2017)['Q1']) == 0
