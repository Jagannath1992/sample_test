import pytest
from os import environ
from app import create_app
from pymongo import MongoClient
from bson.objectid import ObjectId


@pytest.fixture(scope='session')
def client(db):
    app = create_app(db)
    client = app.test_client()

    ctx = app.app_context()
    ctx.push()

    yield client
    ctx.pop()


@pytest.fixture(scope='session')
def db():
    test_db_url = environ.get('TEST_DB_URL', 'mongodb://localhost:27017/')
    db_client = MongoClient(test_db_url)
    db = db_client['test_db']

    load_test_data(db)

    yield db
    db_client.drop_database('test_db')


@pytest.fixture()
def header():
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    }


@pytest.fixture()
def private_key():
    return 'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl' \
           '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9'


def load_test_data(db):
    result = db.mm_brands.insert_one({
        "name": "SPARTON CORPORATION",
        "iname": "sparton corporation",
        "slug": "spa-sparton-corporation",
        "source": "MSCI",
        "industry": "Aerospace & Defense",
        "msci": {
            "msciId": "SPA",
            "issuerName": "SPARTON CORPORATION",
            "industry": "Aerospace & Defense",
            "weights": {
                "accessToCommunications" : 0.0,
                "accessToFinance" : 0.0,
                "carbonEmissions" : 0.0,
                "climateChangeVulnerability": 0.0,
                "humanCapitalDevelopment": 0.0,
                "responsibleInvestment": 0.0
            },
            "quartile": {
                "accessToCommunications": 0.0,
                "accessToFinance": 0.0,
                "carbonEmissions": 0.0,
                "climateChangeVulnerability": 0.0,
                "humanCapitalDevelopment": 0.0,
                "responsibleInvestment": 0.0
            },
            "score": {
                "accessToCommunications": 0.0,
                "accessToFinance": 0.0,
                "carbonEmissions": 0.0,
                "climateChangeVulnerability": 0.0,
                "humanCapitalDevelopment": 0.0,
                "responsibleInvestment": 0.0
            }
        },
        "preferredPrograms" : {
            "editing": False,
            "cart": [],
            "selected": [],
            "additional": []
        },
        'subdomain': 'met.givewith.com'
    })

    brand_id = result.inserted_id
    db.user.insert_one({
        "active": True,
        "type": "client",
        "first_name": "s",
        "last_name": "j",
        "username": "shanyan.jiang+delta@givewith.com",
        "phoneNumber": "(231) 455 5555",
        "businessAddress": "1",
        "title": "1",
        "departmentName": "1",
        "departmentType": "Marketing",
        "notes": "1",
        "orgId": brand_id,
        "orgType": "brand",
        "name": "s j",
        "uuid": "6045c4c5-1644-44ec-a9d5-3223b613a261",
        "cognito-id": "e372e0e2-cc43-43d2-8835-e0cb270038a8",
    })

    db.user.insert_one({
        "active": True,
        "type": "admin",
        "first_name": "s",
        "last_name": "j",
        "username": "shanyan.jiang+20@givewith.com",
        "phoneNumber": "(231) 455 5555",
        "businessAddress": "1",
        "title": "1",
        "departmentName": "1",
        "departmentType": "Marketing",
        "notes": "1",
        "orgId": brand_id,
        "orgType": "brand",
        "name": "s j",
        "uuid": "6045c4c5-1644-44ec-a9d5-3223b613a261",
        "cognito-id": "e372e0e2-cc43-43d2-8835-e0cb270038a8",
    })

    db.user.insert_one({
        "active": True,
        "type": "admin",
        "first_name": "jagannath",
        "last_name": "sahu",
        "username": "jagannath.sahu@xoriant.com",
        "phoneNumber": "(231) 455 5555",
        "businessAddress": "1",
        "title": "1",
        "departmentName": "1",
        "departmentType": "Sales",
        "notes": "1",
        "orgId": brand_id,
        "orgType": "brand",
        "name": "Jagannath sahu",
        "oktaId": "00u86dkbvjkY6XrDD5d7",
        "accountId":ObjectId("62268b07fd7ae0a0b26aefc3"),
        "uuid": "6045c4c5-1644-44ec-a9d5-3223b613a261",
        "cognito-id": "e372e0e2-cc43-43d2-8835-e0cb270038a8",
    })