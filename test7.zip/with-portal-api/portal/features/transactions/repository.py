from portal.shared.repository import DocumentRepository


class TransactionRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['transaction'])
