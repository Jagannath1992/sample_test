# -*- coding: utf-8 -*-
import uuid
import requests
from bson import ObjectId
from bson.errors import InvalidId
from bson.json_util import dumps
from flask import jsonify, request, current_app
from jsondiff import diff
from os import environ
from datetime import datetime

from matchmaking.models.models import schema_user, schema_user_api, v, OrgType, UserType
from matchmaking.controllers import admin_bp
from ..mongodb import db, get_user
from ..utils import (EntityNotFound, UnsupportedId, UnsupportedPayload, InvalidPayload,
                     GivewithError, ValidationError, send_loggly)
from ..permission_decorator import require_admin_permission
from ..util import cognito, audit_logger
from ..validation.utils import validate_object_id
from ..dao.utils import get_documents, update_document_by_id


# from flasgger.utils import swag_from

AUTH_SERVICE_URL = environ.get('AUTH_SERVICE_URL', '')


@admin_bp.route('/users', methods=['GET'])
@require_admin_permission
# @swag_from("user.yml")
def admin_list_users():
    """ List all available Users
    ---
    tags: ['User Admin']

    security:
      - GivewithAuth: []

    responses:
      201:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                type: object
                properties:
                  _id:
                    type: string
                  name:
                    type: string
                  username:
                    type: string

      default:
        content:
          application/json:
            schema:
              $ref: 'user1.yml'
    """
    users = list(db().coll_user.find(projection={'password': False, 'uuid': False}))

    if not users:
        raise EntityNotFound('user')

    return jsonify(users)


@admin_bp.route('/users/<id>', methods=['GET'])
@require_admin_permission
def admin_get_user_by_id(id):
    """ Fetch User data
    ---
    tags: ['User Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/User'

      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    user = db().coll_user.find_one(filter={'_id': obj_id}, projection={'password': False, 'uuid': False})

    if not user:
        raise EntityNotFound('user', id)

    return jsonify(user)


@admin_bp.route('/users', methods=['POST'])
@require_admin_permission
def insert_user():
    """ Create a new user
    ---
    tags: ['User Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/User'

      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    v.validate(document, schema_user_api)
    if v.errors:
        current_app.logger.error('User validation error: {0}'.format(v.errors))
        raise InvalidPayload(v.errors)

    document = v.normalized(document, schema_user)
    if v.errors:
        raise ValidationError(v.errors)

    username_exists = db().coll_user.find_one({'username': document['username']})
    if username_exists:
        raise GivewithError('Username already taken.', code=400)

    if document['orgType'] == str(OrgType.NONPROFIT) and document['type'] == str(UserType.ADMIN):
        raise GivewithError('Nonprofit user cannot be admin', code=400)

    if 'name' not in document:
        document['name'] = document['first_name'] + ' ' + document['last_name']

    if 'active' not in document:
        document['active'] = True

    # Create cognito user
    user = cognito.create_user(document['username'], document['first_name'], document['last_name'],
                               document['type'], document['orgType'])

    if user and user.get('Username'):
        cognito_id = user.get('Username')

        # create once
        document['uuid'] = str(uuid.uuid4())
        document['cognito-id'] = cognito_id
        document['createdAt'] = datetime.utcnow()
        document['_id'] = db().coll_user.insert_one(document).inserted_id

        send_loggly('USER INFO: NEW USER CREATED BY: ' + str(request.user['_id']) + ': ' + dumps(document))
        audit_logger.log('matchmaking-api', str(request.user['_id']), 'user', str(document['_id']), 'create', '', '')
        return jsonify(document)
    else:
        raise GivewithError('Error creating user', code=400)


@admin_bp.route('/users/<id>', methods=['PUT'])
@require_admin_permission
def update_user(id):
    """ Update user Details
    ---
    tags: ['User Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/User'

      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    v.validate(document, schema_user_api)
    if v.errors:
        current_app.logger.error('User validation error: {0}'.format(v.errors))
        raise InvalidPayload(v.errors)

    document = v.normalized(document, schema_user)
    if v.errors:
        raise ValidationError(v.errors)

    username = document['username']

    # Username is read-only
    db_document = db().coll_user.find_one({'_id': obj_id})
    if not db_document:
        raise EntityNotFound('User', obj_id)

    immutable_fields = ('username', 'orgType', 'orgId')
    for field in immutable_fields:
        if str(document.get(field)) != str(db_document.get(field)):
            raise GivewithError(f'{field} is immutable')

    if document['orgType'] == str(OrgType.NONPROFIT) and document['type'] == str(UserType.ADMIN):
        raise GivewithError('Nonprofit user cannot be admin', code=400)

    document['name'] = document['first_name'] + ' ' + document['last_name']

    # if db_document is active but document isn't active, disable user
    if db_document['active'] and not document.get('active'):
        cognito.disable_user(db_document['username'])
        requests.post(AUTH_SERVICE_URL + '/v1/revoke/user/' + db_document['username'])
    elif db_document['active'] is False and document.get('active') is True:
        cognito.enable_user(db_document['username'])

    update_diff = diff(document, db_document, syntax='symmetric')

    db_document.update(document)
    db_document = v.normalized(db_document, schema_user)

    # update cognito username and name
    cognito.update_user(username, document['first_name'], document['last_name'], document['type'])

    db().coll_user.replace_one(filter={'_id': obj_id}, replacement=db_document)

    send_loggly('USER INFO: MODIFY USER BY PUT USER_ID:' + id + ' edited by ' + str(request.user['_id']) +
                ': diff: ' + str(update_diff))
    audit_logger.log('matchmaking-api', str(request.user['_id']), 'user', str(db_document['_id']), 'update', 'PUT', '')
    return jsonify(db_document)


@admin_bp.route('/users/<_id>/deletion-side-effects', methods=['GET'])
@require_admin_permission
def admin_get_user_deletion_side_effects(_id):
    validate_object_id(_id, 'user')

    customer_email = 'givewithCustomerEmails'
    client_email = 'clientEmails'

    user = get_user(ObjectId(_id), projection={'username': True})
    username = user.get('username', '')

    deals = get_user_emails_in_deals(username, customer_email, client_email)

    deletion_info = [
        {
            'data': deals,
            'fieldsAffected': [customer_email, client_email],
            'valueDeleted': 'Your email',
            'heading': 'By deleting this user, these deals will be affected in the following ways:',
            'collection': 'deals',
        }
    ]

    return jsonify(deletion_info)


@admin_bp.route('/users/<id>', methods=['DELETE'])
@require_admin_permission
def delete_user(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    user = db().coll_user.find_one_and_delete({'_id': obj_id})

    if user is not None:
        # delete user emails from proposals
        customer_email = 'givewithCustomerEmails'
        client_email = 'clientEmails'
        username = user.get('username')

        deals = get_user_emails_in_deals(username, customer_email, client_email)
        if deals:
            remove_user_emails_in_deals(deals, username, customer_email, client_email)

        try:
            cognito.delete_user(user['cognito-id'])
        except Exception as e:
            current_app.logger.warning(e)

        try:
            requests.post(AUTH_SERVICE_URL + '/v1/revoke/user/' + user['username'], timeout=3)
        except requests.Timeout as e:
            current_app.logger.warning(e)

        send_loggly('USER INFO: DELETE USER ' + id + ' DELETED BY ' + str(request.user['_id']))
        audit_logger.log('matchmaking-api', str(request.user['_id']), 'user', str(id), 'delete', '', '')
        return jsonify(user)
    else:
        raise EntityNotFound('user', id)


@admin_bp.route('/users/<user_id>/resend', methods=['POST'])
@require_admin_permission
def resend_confirmation_email(user_id):
    try:
        obj_id = ObjectId(user_id)
    except InvalidId:
        raise UnsupportedId(user_id)

    user_doc = db().coll_user.find_one(filter={'_id': obj_id}, projection={'password': False, 'uuid': False})

    if not user_doc:
        raise EntityNotFound('user', id)

    res = cognito.resend_conf_code(user_doc['username'], user_doc['first_name'], user_doc['last_name'],
                                   user_doc['type'], user_doc['orgType'])
    return res


def get_user_emails_in_deals(username, customer_email, client_email):
    projection = {'name': True, customer_email: True, client_email: True}
    query = {'$or': [{customer_email: {'$in': [username]}}, {client_email: {'$in': [username]}}]}
    deals = get_documents('deals', query, projection=projection)
    return deals


def remove_user_emails_in_deals(deals, username, customer_email, client_email):
    for deal in deals:
        changes = {}
        if username in deal.get(customer_email, []):
            new_customer_emails = deal.get(customer_email)
            new_customer_emails.remove(username)
            changes[customer_email] = new_customer_emails

        if username in deal.get(client_email, []):
            new_client_emails = deal.get(client_email)
            new_client_emails.remove(username)
            changes[client_email] = new_client_emails

        if changes:
            update_document_by_id('deals', deal.get('_id'), changes)
