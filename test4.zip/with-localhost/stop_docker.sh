docker kill gw_matchmaking_api
docker kill gw_campaign_summary_ui
docker kill gw_matchmaking_ui
docker kill gw_pyadmin_api
docker kill gw_admin_ui
docker kill gw_mongo_local
docker kill gw_research_api
docker kill gw_matchmaking_algo
docker kill gw_auth
docker kill gw_cypress

if [ -z "$1" ]
  then
    echo "No args applied - skipping more aggressive clean up steps"
else
  docker rm gw_matchmaking_api
  docker rm gw_campaign_summary_ui
  docker rm gw_matchmaking_ui
  docker rm gw_pyadmin_api
  docker rm gw_admin_ui
  docker rm gw_mongo_local
  docker rm gw_research_api
  docker rm gw_matchmaking_algo
  docker rm gw_auth
  docker rm gw_cypress

  # you may want to prune if you see Docker complain about having enough disk space
  # (docker has a cap on how much space it will use)
  docker system prune

  # or more aggressively clean up old volumes (good for 'out of space')
  docker volume rm $(docker volume ls -qf dangling=true)

fi
