def test_cors(client, admin_token):
    # positive test - localhost should pass
    origin = 'http://localhost.com'
    response = send_request(client, origin, admin_token)

    assert response.status_code == 200
    assert response.headers.get('Access-Control-Allow-Origin') == origin

    # positive test - nohardstop should pass
    origin = 'https://impact.nohardstops.com'
    response = send_request(client, origin, admin_token)

    assert response.status_code == 200
    assert response.headers.get('Access-Control-Allow-Origin') == origin

    # positive test - givewith should pass
    origin = 'https://admin.givewith.com'
    response = send_request(client, origin, admin_token)

    assert response.status_code == 200
    assert response.headers.get('Access-Control-Allow-Origin') == origin

    # negative test - google should fail
    origin = 'https://test.google.com'
    response = send_request(client, origin, admin_token)
    
    assert response.status_code == 200
    assert 'Access-Control-Allow-Origin' not in response.headers


def send_request(client, origin, admin_token):
    header = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': admin_token,
        'Origin': origin,
    }

    return client.get('/admin/users', headers=header)
