from matchmaking import db

db().coll_deals.update_many({'givewithCustomerRole': 'seller'}, {'$set': {'givewithCustomerRole': 'supplier'}})
