import pytest
from bson import ObjectId
from portal.features.cause_areas.schema import CauseAreaRequest, CauseAreaSchema, CauseAreaSearchResponse, CauseAreaResponse
from portal.shared.repositories import account_repository, cause_area_repository, instance_settings_repository, locale_repository, order_repository, sku_repository, order_repository
from portal.shared.dates import get_formatted_utc_string
from portal.shared.dates import get_utcnow
from portal.shared.enums import OrderStatus


class TestCauseAreas:

    def test_create(self, client, givewith_header, fakers):
        cause_area = CauseAreaRequest().dump(fakers.cause_area.generate_new())
        assert cause_area_repository().collection.count_documents({}) == 0

        response = client.post('/cause-areas', json=cause_area, headers=givewith_header)

        assert response.status_code == 200
        assert cause_area_repository().collection.count_documents({}) == 1

    def test_create_detail_image_name_blank(self, client, givewith_header, fakers):
        source_obj = fakers.cause_area.generate_new()
        source_obj['detailImageName'] = ''
        cause_area = CauseAreaRequest().dump(source_obj)

        assert cause_area_repository().collection.count_documents({}) == 0

        response = client.post('/cause-areas', json=cause_area, headers=givewith_header)

        assert response.status_code == 200
        assert response.json['detailImageName'] == response.json['listImageName']
        assert cause_area_repository().collection.count_documents({}) == 1

    def test_create_detail_image_name_none(self, client, givewith_header, fakers):
        source_obj = fakers.cause_area.generate_new()
        source_obj.pop('detailImageName')
        cause_area = CauseAreaRequest().dump(source_obj)

        assert cause_area_repository().collection.count_documents({}) == 0

        response = client.post('/cause-areas', json=cause_area, headers=givewith_header)

        assert response.status_code == 200
        assert response.json['detailImageName'] == response.json['listImageName']
        assert cause_area_repository().collection.count_documents({}) == 1

    def test_create_detail_image_name_default(self, client, givewith_header, fakers):
        source_obj = fakers.cause_area.generate_new()
        detail_image = source_obj['detailImageName']
        cause_area = CauseAreaRequest().dump(source_obj)

        assert cause_area_repository().collection.count_documents({}) == 0

        response = client.post('/cause-areas', json=cause_area, headers=givewith_header)

        assert response.status_code == 200
        assert response.json['detailImageName'] == detail_image
        assert cause_area_repository().collection.count_documents({}) == 1

    def test_create_duplicate_400(self, mocker, client, givewith_header, fakers):
        name = 'cause area 1'
        fakers.cause_area.insert_single({'name': name})
        source_obj = fakers.cause_area.generate_new()
        source_obj['name'] = name
        cause_area = CauseAreaRequest().dump(source_obj)

        response = client.post('/cause-areas', json=cause_area, headers=givewith_header)

        assert response.status_code == 400
        assert response.json == {'message': f'A cause area named {name} already exists'}


class TestCauseAreaSearch:
    def test_search(self, client, givewith_header, mocker, fakers):
        # arrange
        account = fakers.account.generate_single()
        instance = fakers.instance_settings.generate_single()
        cause_areas = fakers.cause_area.generate_many(3)

        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(cause_area_repository(), 'get_page', return_value=(3, cause_areas))

        expected = CauseAreaSearchResponse().dump({
            'totalCount': 3,
            'results': cause_areas
        })

        query_params = {
            'orderBy': 'name',
            'offset': 0,
            'count': 10
        }

        # act / execute
        response = client.get('/cause-areas', query_string=query_params, headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected


class TestCauseAreaById:
    def test_get(self, client, givewith_header, mocker, fakers):
        # arrange
        cause_area = fakers.cause_area.generate_single()
        mocker.patch.object(cause_area_repository(), 'get_single', return_value=cause_area)
        expected = CauseAreaSchema().dump(cause_area)

        # act
        response = client.get(f'/cause-areas/{cause_area["_id"]}', headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected

    def test_put(self, client, givewith_header, fakers, mocker):
        cause_area = fakers.cause_area.insert_single()
        request_json = CauseAreaRequest().dump(cause_area)
        updated_name = 'new cause area name'
        request_json['name'] = updated_name
        response = client.put(f'/cause-areas/{cause_area["_id"]}', json=request_json, headers=givewith_header)
        assert response.status_code == 200
        assert response.json["name"] == updated_name

    def test_patch(self, mocker, fakers, client, givewith_header):
        cause_area = fakers.cause_area.generate_single()
        mocker.patch.object(cause_area_repository(), 'get_single', return_value=cause_area)
        request_json = {'description': 'new cause area description'}
        parsed_obj = CauseAreaRequest(partial=True).dump(request_json)
        expected_update = {**cause_area, **parsed_obj}
        mocker.patch.object(cause_area_repository(), 'patch', return_value=expected_update)
        expected_response = CauseAreaResponse().dump(expected_update)
        response = client.patch(f'/cause-areas/{cause_area["_id"]}', json=request_json, headers=givewith_header)
        assert response.status_code == 200
        assert response.json == expected_response

    def test_delete(self, client, fakers, givewith_header, mocker):
        cause_area = fakers.cause_area.insert_single()
        mocker.patch.object(cause_area_repository(), 'get_single', return_value=cause_area)
        cause_area['active'] = False
        mocker.patch.object(cause_area_repository(), 'patch', return_value=cause_area)

        # Act
        response = client.delete(f'/cause-areas/{cause_area["_id"]}', headers=givewith_header)

        # Assert
        assert response.status_code == 200
        assert response.json['active'] == False


class TestCauseAreaByIdSkus:
    def test_get(self, fakers, mocker, client, givewith_header):
        # arrange
        locale = fakers.locale.generate_single()
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        cause_area = fakers.cause_area.generate_single()

        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        mocker.patch.object(cause_area_repository(), 'get_single', return_value=cause_area)

        currency = locale['settings']['currency']
        symbol = locale['settings']['symbol']
        prefix = cause_area['skuPrefix']
        skus = instance.get('skus', [])

        expected = [
            {
                'id': f'{cause_area["_id"]}-{sku:.0f}',
                'name': f'{prefix}-{sku:05.0f}',
                'description': f'{symbol}{sku:,.0f}',
                'unitCost': sku,
                'currency': currency
            } for sku in skus
        ]

        # act
        response = client.get(f'/cause-areas/{cause_area["_id"]}/skus/{account["_id"]}', headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected

        locale_repository().get_single.assert_called_once_with(instance['settings']['locale']['_id'])
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        account_repository().get_single.assert_called_once_with(account["_id"], {'instance._id': 1})
        cause_area_repository().get_single.assert_called_once_with(str(cause_area["_id"]))


class TestCauseAreaByIdInstance:
    def test_get(self, repositories, fakers, mocker, client, givewith_header):
        # generate cause area
        cause_area = fakers.cause_area.generate_single()
        instance = fakers.instance_settings.generate_single()
        instance['causeAreas'][0]['causeArea']['_id'] = cause_area['_id']
        data = {
            'ID': {0: ObjectId(instance['_id'])},
            'Instance': {0: 'Instance 0'},
            'Cause Area': {0: 'causeArea name 0'},
            'Assigned Date': {0:get_formatted_utc_string(instance['causeAreas'][0]['assignedDate'])}
        }
        mocker.patch.object(instance_settings_repository(), 'get_associated', return_value=data)
        # act
        response = client.get(f'/cause-areas/{cause_area["_id"]}/instances', headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.content_type == 'text/csv; charset=utf-8'


class TestCauseAreaMetricsOverview:
    def test_post_overview_200(self, client, givewith_header, mocker, fakers):
        '''
        This test is for controller /cause-areas/metrics/overview endpoint
        '''
        result = [
            {'_id': {'currency': 'USD', 'currencySymbol': '$'}, 
            'avgGiveAmount': 10, 
            'avgDealAmount': 10, 
            'avgGivePercent': 10
            }]
        mocker.patch.object(order_repository(), 'get_metrics',  return_value=result)
        result[0]['details'] = [{'count': 1, 'totalDealAmount': 10, 'totalGiveAmount': 10, 'status': OrderStatus.APPROVED.value, 'mostGives': 'test@givewith.com'}]
        mocker.patch('portal.features.orders.service._populate_result_details', return_value=result)

        mocker.patch.object(order_repository(), 'get_win_rate', return_value=[{}])
        result[0]['winRate'] = 22
        mocker.patch('portal.features.orders.service._calculate_win_rate', return_value=result)

        mocker.patch.object(order_repository(), 'get_most_gives', return_value=[{}])
        result[0]['mostGives'] = 'test@givewith.com'
        mocker.patch('portal.features.orders.service._populate_most_gives', return_value=result)

        response = client.post(f'/cause-areas/metrics/overview', json={}, headers=givewith_header)
        assert response.status_code == 200

class TestCauseAreaMetricsDetail:
    def test_post_detail_200(self, client, givewith_header, mocker, fakers):
        '''
        This test is for controller /cause-areas/metrics/detail endpoint
        '''
        result = [
            {'_id': {'causeArea': 'Cause Area 1', 'currency': 'USD', 'currencySymbol': '$'}, 
            'avgGiveAmount': 10, 
            'avgDealAmount': 10, 
            'avgGivePercent': 10
            }]
        mocker.patch.object(order_repository(), 'get_metrics',  return_value=result)
        result[0]['details'] = [{'count': 1, 'totalDealAmount': 10, 'totalGiveAmount': 10, 'status': OrderStatus.APPROVED.value}]
        mocker.patch('portal.features.orders.service._populate_result_details', return_value=result)

        mocker.patch.object(order_repository(), 'get_win_rate', return_value=[{}])
        result[0]['winRate'] = 22
        mocker.patch('portal.features.orders.service._calculate_win_rate', return_value=result)

        mocker.patch.object(order_repository(), 'get_most_gives', return_value=[{}])
        result[0]['details'][0]['mostGives']= 'test@givewith.com'
        mocker.patch('portal.features.orders.service._populate_most_gives', return_value=result)

        response = client.post(f'/cause-areas/metrics/detail', json={}, headers=givewith_header)
        assert response.status_code == 200
        assert response.json['results'][0]['key']['causeArea'] == 'Cause Area 1'
    
    def test_post_detail_multi_currency(self, client, givewith_header, mocker, fakers):
        '''
        This test is for controller /cause-areas/metrics/detail endpoint
        '''
        result = [
            {'_id': {'causeArea': 'Cause Area 1', 'currency': 'USD', 'currencySymbol': '$'}, 
            'avgGiveAmount': 10, 
            'avgDealAmount': 10, 
            'avgGivePercent': 10
            },
            {'_id': {'causeArea': 'Cause Area 2', 'currency': 'GBP', 'currencySymbol': '£'}, 
            'avgGiveAmount': 50, 
            'avgDealAmount': 50, 
            'avgGivePercent': 50
            }]
        mocker.patch.object(order_repository(), 'get_metrics',  return_value=result)
        result[0]['details'] = [{'count': 1, 'totalDealAmount': 10, 'totalGiveAmount': 10, 'status': OrderStatus.APPROVED.value}]
        result[1]['details'] = [{'count': 10, 'totalDealAmount': 100, 'totalGiveAmount': 100, 'status': OrderStatus.PENDING_APPROVAL.value}]
        mocker.patch('portal.features.orders.service._populate_result_details', return_value=result)

        mocker.patch.object(order_repository(), 'get_win_rate', return_value=[{}])
        result[0]['winRate'] = 22
        result[1]['winRate'] = 50.55
        mocker.patch('portal.features.orders.service._calculate_win_rate', return_value=result)

        mocker.patch.object(order_repository(), 'get_most_gives', return_value=[{}])
        result[0]['details'][0]['mostGives']= 'test@givewith.com'
        result[1]['details'][0]['mostGives']= 'admin@givewith.com'
        mocker.patch('portal.features.orders.service._populate_most_gives', return_value=result)

        response = client.post(f'/cause-areas/metrics/detail', json={}, headers=givewith_header)
        assert response.status_code == 200
        assert response.json['currencies'] == [{'currency': 'GBP', 'symbol': '£'}, {'currency': 'USD', 'symbol': '$'}]

    
    
