from bson import objectid
from datetime import timezone
from flask import jsonify, request, send_file
from tempfile import TemporaryFile
from werkzeug.utils import secure_filename

from matchmaking.controllers import admin_bp
from matchmaking.utils import generate_secure_password, generate_random_slug, replace_object_ids, GivewithError, ValidationError
from matchmaking.dao.utils import add_document, get_documents, get_document_by_id, update_document_by_id, list_documents
from matchmaking.permission_decorator import require_admin_permission
from matchmaking.models.models import v, actualization_schema, to_bool
from matchmaking.s3 import save_custom_deliverable_to_s3, download_file, delete_file
from matchmaking.validation.event import validate_create_event_request, validate_pilot_deal_progress
from matchmaking.controllers.dashboard.pilot_deal import calc_funding_amount

"""
@api {get} /dashboard/event List Event
@apiName List Event
@apiGroup Event
@apiDescription List all events

@apiSuccessExample {json} Success list event example:
[
    {
        "name": "event name",
        'customer': '5c1415685b03bb0008c21adf',
        "category": "event category",
        "type": "event type",
        "tcv": "event tct",
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z'
        'deals': []
    }
]
"""
@admin_bp.route('/event', methods=['GET'])
@require_admin_permission
def list_event():
    events = list_documents('event')

    active_events = []
    for e in events:
        if not e['deleted']:
            join_event(e)
            active_events.append(e)

    return jsonify(active_events)


"""
@api {post} /admin/event Create Event
@apiName Create Event
@apiGroup Event
@apiDescription Create a new event

@apiParamExample {json} Create event example:
{
    "name": "event name",
    'customer': '5c1415685b03bb0008c21adf',
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
}

@apiSuccessExample {json} Success created event example:
{
    "name": "event name",
    'customer': '5c1415685b03bb0008c21adf',
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z'
}
"""
@admin_bp.route('/event', methods=['POST'])
@require_admin_permission
def create_event():
    payload = request.get_json()
    valid, errors = validate_create_event_request(payload)

    if not valid:
        return jsonify(errors), 400

    payload = replace_object_ids(payload)
    event = {
        'name': payload['name'],
        'customer': payload['customer'],
        'category': payload.get('category', ''),
        'type': payload.get('type', ''),
        'totalContractValue': float(payload.get('totalContractValue') or 0),
        'currency': payload.get('currency', ''),
        'status': 'OPEN',
        'deleted': False,
    }

    event = add_document('event', event)
    return jsonify(join_event(event))


"""
@api {get} /admin/event/brand/:brandId List Events By Brand ID
@apiName List Events
@apiGroup Event
@apiDescription Return list of events that belong to the requesting user's company

@apiParamExample {json} Create event example:
{}

@apiSuccessExample {json} Success created event example:
[
    {
        "name": "event name 1",
        "category": "event category",
        "type": "event type",
        "tcv": "event tct",
        'customer': '5c1415685b03bb0008c21adf',
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z'
    },
    {
        "name": "event name 2",
        "category": "event category",
        "type": "event type",
        "tcv": "event tct",
        'customer': '5c1415685b03bb0008c21adf',
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z'
    }
}
"""
@admin_bp.route('/event/brand/<brand_id>', methods=['GET'])
@require_admin_permission
def list_event_by_brand(brand_id):
    if not objectid.ObjectId.is_valid(brand_id):
        return 'invalid brand id', 400

    events = get_documents('event', {'customer': objectid.ObjectId(brand_id), 'deleted': False})
    for event in events:
        join_event(event)

    return jsonify(events)


"""
@api {put} /admin/event/:event_id Update Event
@apiName Update Event
@apiGroup Event
@apiDescription Update an event by ID

@apiParamExample {json} Update event example:
{
    "name": "event name",
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
}

@apiSuccessExample {json} Success created event example:
{
    "name": "event name",
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
    'customer': '5c1415685b03bb0008c21adf',
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z'
}
"""
@admin_bp.route('/event/<event_id>', methods=['PUT'])
@require_admin_permission
def update_event(event_id):
    if not objectid.ObjectId.is_valid(event_id):
        return 'invalid event id', 400

    event = get_document_by_id('event', event_id)
    if event is None or event['deleted']:
        return 'event not found', 404

    payload = request.get_json()
    payload = replace_object_ids(payload)

    event = {
        'name': payload['name'],
        'customer': payload['customer'],
        'category': payload.get('category', ''),
        'type': payload.get('type', ''),
        'totalContractValue': float(payload.get('totalContractValue') or 0),
        'currency': payload.get('currency', ''),
    }

    updated_event = update_document_by_id('event', event_id, event)
    return jsonify(join_event(updated_event))


"""
@api {put} /admin/event/:event_id Get Event
@apiName Get Event
@apiGroup Event
@apiDescription Get an event by ID

@apiSuccessExample {json} Success created event example:
{
    "name": "event name",
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
    'customer': '5c1415685b03bb0008c21adf',
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z'
}
"""
@admin_bp.route('/event/<event_id>', methods=['GET'])
@require_admin_permission
def get_event(event_id):
    if not objectid.ObjectId.is_valid(event_id):
        return 'invalid event id', 400

    event = get_document_by_id('event', event_id)
    if event is None or event['deleted']:
        return 'event not found', 404

    return jsonify(join_event(event))


"""
@api {put} /admin/event/:event_id DELETE Event
@apiName DELETE Event
@apiGroup Event
@apiDescription DELETE an event by ID
"""
@admin_bp.route('/event/<event_id>', methods=['DELETE'])
@require_admin_permission
def delete_event(event_id):
    if not objectid.ObjectId.is_valid(event_id):
        return 400, 'invalid event id'

    event = get_document_by_id('event', event_id)
    if event is None:
        return 404, 'event not found'

    event['deleted'] = True
    update_document_by_id('event', event_id, event)

    # delete associated deals
    deals = get_documents('pilot_deal', {'eventId': objectid.ObjectId(event_id)})
    for deal in deals:
        deal['deleted'] = True
        update_document_by_id('pilot_deal', deal['_id'], deal)

    return jsonify(success=True)


"""
@api {post} /admin/event/:event_id/deal Add deal to event
@apiName Add Deal
@apiGroup Event
@apiDescription Add deal to an event

@apiParamExample {json} Add deal example:
{
    'type': 'pilot-procurement',
    'customer': '5c1415685b03bb0008c21adf',
    'customerUser': '5c129041228ea85cfd418dec',
    'estimatedContractValue': 0,
    'allocation': 0,
    'portion': 1000,
    'feePercentage': 15,
    'fundingAmount': 1000,
    'supplierName': 'supplier name',
    'contact': 'contact@customer.com',
    'fundingStatus': 'string field',
    'invoicingTerms': 'string field',
    'totalInvoicingAmount': 200,
    'selectedProgram': [{
        'programId': '5c129041228ea85cfd418auf',
        'funding': 1000,
        'fundingPeriod': 'string field',
        'progress': 20
    }]
}

@apiSuccessExample {json} Success added deal example:
{
    'type': 'pilot-procurement',
    'customer': '5c1415685b03bb0008c21adf',
    'customerUser': '5c129041228ea85cfd418dec',
    'estimatedContractValue': 0,
    'allocation': 0,
    'portion': 1000,
    'feePercentage': 15,
    'fundingAmount': 1000,
    'supplierName': 'supplier name',
    'contact': 'contact@customer.com',
    'fundingStatus': 'string field',
    'invoicingTerms': 'string field',
    'totalInvoicingAmount': 200,
    'selectedProgram': [{
        'programId': '5c129041228ea85cfd418auf',
        'funding': 1000,
        'fundingPeriod': 'string field',
        'progress': 20
    }]
}
"""
@admin_bp.route('/event/<event_id>/deal', methods=['POST'])
@require_admin_permission
def add_deal_to_event(event_id):
    payload = request.get_json()
    payload = replace_object_ids(payload)

    deal = {
        'eventId': objectid.ObjectId(event_id),
        'status': 'OPEN',
        'supplier': payload['supplier'],
        'supplierEmail': payload.get('supplierEmail'),
        'accountsPayableEmail': payload.get('accountsPayableEmail'),
        'totalBudget': float(payload.get('totalBudget') or 0),
        'givePercent': float(payload.get('givePercent') or 0),
        'currency': payload.get('currency'),
        'paymentOption': payload.get('paymentOption'),
        'givewithPortion': float(payload.get('givewithPortion') or 0),
        'invoicingTerms': payload.get('invoicingTerms'),
        'customFields': payload.get('customFields', {}),
        'givewithFeePercentage': float(payload.get('givewithFeePercentage') or 30),
        'selectedPrograms': payload.get('selectedPrograms', []),
        'password': generate_secure_password(),
        'slug': generate_random_slug(),
        'invoiceOption': payload.get('invoiceOption'),
        'deleted': False
    }

    deal = add_document('pilot_deal', deal)
    add_program_slugs(deal)

    return jsonify(deal)


"""
@api {post} /admin/pilot_deal/:pilot_deal_id Delete Pilot Deal
@apiName Delete Pilot Deal
@apiGroup PilotDeal
@apiDescription Soft delete a pilot deal
"""
@admin_bp.route('/pilot_deal/<pilot_deal_id>', methods=['DELETE'])
@require_admin_permission
def delete_pilot_deal(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    deal['deleted'] = True
    update_document_by_id('pilot_deal', pilot_deal_id, deal)

    return jsonify(success=True)


"""
@api {post} /admin/pilot_deal Update Pilot Deal
@apiName Delete Pilot Deal
@apiGroup PilotDeal
@apiDescription Update a pilot deal by id
"""
@admin_bp.route('/pilot_deal/<pilot_deal_id>', methods=['PUT'])
@require_admin_permission
def update_pilot_deal(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    payload = replace_object_ids(request.get_json())
    updated_deal = {
        'supplierEmail': payload.get('supplierEmail'),
        'accountsPayableEmail': payload.get('accountsPayableEmail'),
        'totalBudget': float(payload.get('totalBudget') or 0),
        'givePercent': float(payload.get('givePercent') or 0),
        'currency': payload.get('currency'),
        'paymentOption': payload.get('paymentOption'),
        'givewithPortion': float(payload.get('givewithPortion') or 0),
        'invoicingTerms': payload.get('invoicingTerms'),
        'customFields': payload.get('customFields', {}),
        'givewithFeePercentage': float(payload.get('givewithFeePercentage') or 30),
        'selectedPrograms': payload.get('selectedPrograms', []),
        'actualizations': validate_actualizations(payload.get('actualizations', [])),
        'deleted': False,
        'invoiceOption': payload.get('invoiceOption'),
    }

    updated_deal['eventId'] = deal['eventId']

    if deal.get('givewithFeePercentage', 30) != updated_deal.get('givewithFeePercentage', 30):
        updated_deal = calc_funding_amount(updated_deal)

    updated_deal = update_document_by_id('pilot_deal', pilot_deal_id, updated_deal)

    supplier_id = deal['supplier']
    supplier = get_document_by_id('mm_brands', supplier_id, projection=['name'])
    updated_deal['supplier_name'] = supplier['name']

    add_program_slugs(updated_deal)

    return jsonify(updated_deal)


def validate_actualizations(actualizations):
    """
    Validates actualizations and returns them normalized
    """
    if not actualizations:
        return []

    # Normalized here because pilot deals do not have a model nor are normalized at the moment
    actualizations = v.normalized({'actualizations': actualizations}, actualization_schema).get('actualizations')
    if v.errors:
        raise ValidationError(v.errors)

    prev_actualization = {}
    for actualization in actualizations:
        current_start_date = actualization['date']['startDate'].replace(tzinfo=timezone.utc)
        current_end_date = actualization['date']['endDate'].replace(tzinfo=timezone.utc)

        if current_start_date > current_end_date:
            raise GivewithError('startDate must be after the endDate')

        if prev_actualization:
            prev_end_date = prev_actualization['date']['endDate'].replace(tzinfo=timezone.utc)

            if  prev_end_date > current_start_date:
                raise GivewithError('startDate must be after the previous endDate')

        prev_actualization = actualization

    return actualizations


"""
@api {get} admin/pilot_deal/:pilot_deal_id Get Pilot Deal
@apiName Get Deal
@apiGroup Pilot Deal
@apiDescription Get a pilot deal by ID

"""
@admin_bp.route('/pilot_deal/<pilot_deal_id>', methods=['GET'])
@require_admin_permission
def get_deal(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid pilot deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    supplier = get_document_by_id('mm_brands', deal['supplier'], projection=['name'])
    deal['supplier_name'] = supplier['name']

    add_program_slugs(deal)

    return jsonify(deal)

"""
@api {put} admin/pilot_deal/status/:pilot_deal_id Update pilot deal status
@apiName Update Deal Status
@apiGroup Pilot Deal
@apiDescription Update deal status by id. Update parent event status to FUNDING_IN_PROGRESS, if all deals status
under parent event are FUNDING_IN_PROGRESS. Update parent event status to COMPLETE, if all deals status are COMPLETE.

@apiParamExample {json} Add deal example:
{
    'status': 'FUNDING_IN_PROGRESS'
}
"""
@admin_bp.route('/pilot_deal/status/<pilot_deal_id>', methods=['PUT'])
@require_admin_permission
def update_deal_status(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid pilot deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    payload = request.get_json()

    # validate status
    if payload['status'] not in ['COMPLETE', 'FUNDING_IN_PROGRESS']:
        return 'Invalid status', 400

    # validate deal.config
    valid, details = validate_pilot_deal_progress(deal)
    if not valid:
        return jsonify(details), 400

    # update deal status
    deal['status'] = payload['status']
    update_document_by_id('pilot_deal', pilot_deal_id, payload)

    # update deal status
    event_id = deal['eventId']
    event = get_document_by_id('event', event_id)
    sibling_deals = get_documents('pilot_deal', {'eventId': event_id})

    is_funding_in_progress = True
    is_complete = True

    for d in sibling_deals:
        if d['status'] != 'FUNDING_IN_PROGRESS':
            is_funding_in_progress = False
        if d['status'] != 'COMPLETE':
            is_complete = False

    if is_funding_in_progress:
        event['status'] = 'FUNDING_IN_PROGRESS'
        event = update_document_by_id('event', event_id, event)

    if is_complete:
        event['status'] = 'COMPLETE'
        event = update_document_by_id('event', event_id, event)

    supplier_id = deal['supplier']
    supplier = get_document_by_id('mm_brands', supplier_id)
    deal['supplier_name'] = supplier['name']

    return jsonify(deal)


"""
@api {post} admin/pilot_deal/:pilot_deal_id/deliverable Upload deliverables
@apiName Upload deliverables
@apiGroup Pilot Deal
@apiDescription Upload deliverables to a pilot deal.

@apiParamExample {json} Upload deliverables example:
{
    name: "DeliverableName",
    icon: "CSR",
    display: True
},
"""
@admin_bp.route('/pilot_deal/<pilot_deal_id>/deliverable', methods=['POST'])
@require_admin_permission
def upload_deliverables(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'deal not found', 404

    if 'file' not in request.files:
        return 'file not found', 400
    file = request.files['file']
    if file.filename == '':
        return 'invalid file name', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    file = request.files['file']
    url = save_custom_deliverable_to_s3(file, 'events/deliverables/%s/%s' % (pilot_deal_id, secure_filename(file.filename)))

    payload = request.form

    program_id = payload.get('programId', '')

    selectedPrograms = deal.get('selectedPrograms', [])
    for program in selectedPrograms:
        if program['programId'] == objectid.ObjectId(program_id):
            new_deliverable = {
                'display': to_bool(payload.get('display')) if payload.get('display') else False,
                'name': payload.get('name', ''),
                'icon': payload.get('icon', ''),
                'url': url,
                'key': payload.get('key', ''),
            }

            if program.get('deliverables'):
                program['deliverables'].append(new_deliverable)
            else:
                program['deliverables'] = [new_deliverable]

            break

    updated_deal = update_document_by_id('pilot_deal', pilot_deal_id, deal)
    return jsonify(updated_deal)


"""
@api {put} admin/pilot_deal/:pilot_deal_id/deliverable Update deliverables
@apiName Update deliverables
@apiGroup Pilot Deal
@apiDescription Update a pilot deal deliverable.

@apiParamExample {json} Update deliverables example:
{
    key: "",
    name: "DeliverableName",
    icon: "CSR",
    display: True
},
"""
@admin_bp.route('/pilot_deal/<pilot_deal_id>/deliverable', methods=['PUT'])
@require_admin_permission
def update_deliverables(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'deal not found', 404

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    updated_url = ''
    if 'file' in request.files:
        file = request.files['file']
        if file.filename == '':
            return 'invalid file name', 400

        file = request.files['file']
        updated_url = save_custom_deliverable_to_s3(file, 'events/deliverables/%s/%s' % (pilot_deal_id, secure_filename(file.filename)))

    payload = request.form

    program_id = payload.get('programId', '')
    key = payload.get('key', '')

    selectedPrograms = deal.get('selectedPrograms', [])
    for program in selectedPrograms:
        if program['programId'] == objectid.ObjectId(program_id):
            deliverables = program.get('deliverables', [])
            for d in deliverables:
                if d['key'] == key:
                    d['name'] = payload.get('name', '')
                    d['icon'] = payload.get('icon', '')
                    d['display'] = to_bool(payload.get('display')) if payload.get('display') else False
                    if updated_url != '':
                        d['url'] = updated_url

                    break

            program['deliverables'] = deliverables
            break

    updated_deal = update_document_by_id('pilot_deal', pilot_deal_id, deal)
    return jsonify(updated_deal)


"""
@api {get} admin/pilot_deal/:pilot_deal_id/deliverable/:key Download Deliverables
@apiName Download Deliverables
@apiGroup Pilot Deal
@apiDescription Download Deliverables
"""
@admin_bp.route('/pilot_deal/<pilot_deal_id>/selectedPrograms/<program_id>/deliverable/<key>', methods=['GET'])
@require_admin_permission
def download_deliverables(pilot_deal_id, program_id, key):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'deal not found', 404

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    file = TemporaryFile()

    selectedPrograms = deal.get('selectedPrograms', [])

    for program in selectedPrograms:
        if program['programId'] == objectid.ObjectId(program_id):
            deliverables = program.get('deliverables', [])
            for d in deliverables:
                if d['key'] == key:
                    url = d['url']
                    download_file(url, file, is_public=False)

                    attachment_filename = url.rsplit('/', 1)[-1]
                    response = send_file(file, as_attachment=True, attachment_filename=attachment_filename, cache_timeout=0)
                    return response

    return 'key not found', 400


"""
join event and pilot deals associated to it by event ID.
"""
def join_event_by_id(event_id):
    event = get_document_by_id('event', event_id)
    return join_event(event)


"""
join event and pilot deals associated to it.
"""
def join_event(event):
    # add supplier name
    customer_id = event['customer']
    brand = get_document_by_id('mm_brands', customer_id)
    event['customer_name'] = brand['name']
    event['customer_iname'] = brand['iname']

    # join deals
    event['deals'] = []
    deals = get_documents('pilot_deal', {'eventId': event['_id']})

    for deal in deals:
        if deal['deleted']:
            continue

        # set progress
        _, progress = validate_pilot_deal_progress(deal)
        deal['progress'] = progress

        # set names
        deal_supplier_id = deal['supplier']
        brand = get_document_by_id('mm_brands', deal_supplier_id)
        deal['supplier_name'] = brand['name']
        deal['supplier_iname'] = brand['iname']

        for p in deal.get('selectedPrograms', []):
            program = get_document_by_id('mm_programs', p['programId'], projection=['name', 'slug', 'nonprofit'])
            p['name'] = program['name']
            p['slug'] = program['slug']

            nonprofit = get_document_by_id('mm_nonprofits', program['nonprofit'])
            p['nonprofit_name'] = nonprofit['name']

        event['deals'].append(deal)

    return event


def add_program_slugs(deal):
    for program in deal.get('selectedPrograms', []):
        full_program = get_document_by_id('mm_programs', program['programId'], projection=['slug'])
        program['slug'] = full_program['slug']
