from matchmaking import db
from matchmaking.controllers.commerce.utils import get_user_by_id

deal_data = list(db().coll_deals.find())
for deal in deal_data:
    deal_id = deal['_id']
    clientEmails = []
    customerEmails = []
    clientUser = get_user_by_id(deal.get('clientUser'))
    customerUser = get_user_by_id(deal.get('givewithCustomerUser'))
    if customerUser:
        customerEmails.append(customerUser['username'])
    if clientUser:
        clientEmails.append(clientUser['username'])
    if deal.get('contact'):
        clientEmails.append(deal.get('contact')['email'])

    db().coll_deals.update_one({'_id' : deal_id}, {'$set': {'clientEmails': clientEmails}})
    db().coll_deals.update_one({'_id': deal_id}, {'$set': {'givewithCustomerEmails': customerEmails}})
