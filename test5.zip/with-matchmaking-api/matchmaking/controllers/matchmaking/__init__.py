from flask import Blueprint

public_mm_bp = Blueprint('matchmaking', __name__)
