import jwt
from os import environ


from flask import request
from app.db.utils import get_document

TOKEN_PRIVATE_KEY = environ.get('TOKEN_PRIVATE_KEY', '') # CodeBuild tests need this setup on AWS Console to pass



def get_token_claims():
    token = request.headers['authorization']
    claims = jwt.decode(token, TOKEN_PRIVATE_KEY, algorithms='HS256')
    return claims


def get_user_from_token():
    claims = get_token_claims()
    return get_document('user', {'username': claims['email']})


def get_role_by_department(department):
    role_map = {
        'Procurement': 'buyer',
        'Sales': 'supplier',
        'CSR': 'supplier',
        'Marketing': 'supplier',
        'Other': 'supplier'
    }

    return role_map.get(department)