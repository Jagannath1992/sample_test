from typing import List

from portal.shared.repositories import order_repository
from portal.shared.enums import OrderStatus


GROUP_BY_CREATED_BY = {'createdBy': '$createdBy', 'status': '$comments.newStatus', 'currency': '$currency'}
GROUP_BY_CAUSE_AREA = {'causeArea': '$causeArea.name', 'createdBy': '$createdBy','status': '$comments.newStatus', 'currency': '$currency'}
GROUP_BY_STATUS = {'status': '$_id.status', 'currency': '$_id.currency'}
GROUP_BY_CAUSE_AREA_STATUS = {'causeArea': '$_id.causeArea', 'status': '$_id.status', 'currency': '$_id.currency'}


class TestOrderRepositoryMostGive:

    def test_most_gives_for_overview(self, init_test_data):
        # arrange
        us, _ = init_test_data
        group_by = [GROUP_BY_CREATED_BY, GROUP_BY_STATUS]
        result_key = {'status': OrderStatus.PENDING_APPROVAL.value, 'currency': 'GBP'}
        expected_result = {'createdBy': 'createdBy0@example.com', 'count': 12}
        # act
        results = order_repository().get_most_gives({}, group_by, False)
        actual_result = _get_result(results, **result_key)
        # assert
        assert actual_result == expected_result

    def test_most_gives_for_details(self, init_test_data):
        # arrange
        us, _ = init_test_data
        group_by = [GROUP_BY_CAUSE_AREA, GROUP_BY_CAUSE_AREA_STATUS]
        result_key = {'causeArea': 'Cause area 1', 'status': OrderStatus.COMPLETED.value, 'currency': 'GBP'}
        expected_result = {'createdBy': 'createdBy0@example.com', 'count': 2}
        # act
        results = order_repository().get_most_gives({}, group_by, False)
        actual_result = _get_result(results, **result_key)
        # assert
        assert actual_result == expected_result

    def test_most_gives_for_overview_using_filter(self, init_test_data):
        # arrange
        us, _ = init_test_data
        group_by = [GROUP_BY_CREATED_BY, GROUP_BY_STATUS]
        filters = {
            'causeArea._id': {'$in': [us['instance']['causeAreas'][1]['causeArea']['_id']]},
            'loc._id': {'$in': [us['locale']['_id']]}
        }
        result_key = {'status': OrderStatus.PENDING_APPROVAL.value, 'currency': 'USD'}
        expected_result = {'createdBy': 'createdBy0@example.com', 'count': 6}
        # act
        results = order_repository().get_most_gives(filters, group_by, False)
        actual_result = _get_result(results, **result_key)
        # assert
        assert actual_result == expected_result


def _get_result(results: List[dict], causeArea: str = None, status: str = None, currency: str = 'USD') -> dict:
    for result in results:
        if result['_id']['currency'] == currency:
            if not causeArea or result['_id']['causeArea'] == causeArea:
                if result['_id']['status'] == status:
                    return result['counts']
