import pymongo
from datetime import datetime
"""
Create an entry in locale collection
"""
name = '20220619193209'
dependencies = ['20220606165805']


def upgrade(db: "pymongo.database.Database"):
    now = datetime.utcnow()
    locale_name = 'US'
    locale_id = db['locale'].insert_one({
        "name": locale_name,
        "description": "United States",
        "settings": {
            "currency": "USD",
            "symbol": "$",
            "regionLabel": "State",
            "regions": ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware",
                        "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
                        "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska",
                        "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
                        "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas",
                        "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"],
        },
        "active": True,
        "createdBy": "admin@givewith.com",
        "createdAt": now,
        "lastUpdatedBy": "admin@givewith.com",
        "lastUpdated": now
    }).inserted_id

    instance_name = "Givewith for Sales"

    db['instance_settings'].find_one_and_update(
        {"name": instance_name},
        {"$set": {
            "settings.locale": {
                "_id": locale_id,
                "_type": "locale",
                "name": locale_name
            }

        }
        }
    )


def downgrade(db: "pymongo.database.Database"):
    db['locale'].drop()
