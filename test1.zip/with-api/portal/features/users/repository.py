import re
from typing import Dict, List
from bson import ObjectId
from portal.shared.enums import UserRole
from portal.shared.repository import DocumentRepository


class UserRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['user'])

    def get_by_username(self, username):
        return self.collection.find_one({'username': username})

    def username_exists(self, username):
        return self.collection.count_documents({'username': re.compile(re.escape(username), re.IGNORECASE)}) != 0

    def domain_exists(self, email: str) -> bool:
        domain = email[email.index('@'):]
        return self.collection.count_documents({'username': re.compile(re.escape(domain), re.IGNORECASE)}) != 0

    def get_blocked_domains(self):
        return self.db['blocked_domains'].find_one()

    def has_access(self, user_id: str, account_id: ObjectId) -> bool:
        return self.collection.count_documents({'_id': ObjectId(user_id), 'accountId': ObjectId(account_id)}) != 0

    def get_by_role(self, account_id: ObjectId, roles: List[UserRole], projection: Dict[str, bool] = None):
        users = list(self.collection.find(
            {'accountId': ObjectId(account_id), 'roles': {'$in': [role.value for role in roles]}, 'active': True},
            projection))
        return users

    def get_usernames_by_role(self, account_id: ObjectId, roles: List[UserRole]):
        users = self.get_by_role(account_id, roles, {'_id': 0, 'username': 1})
        return [user['username'] for user in users]

    def get_invited_users(self, invited_by_id : ObjectId):
        users = self.collection.aggregate([
            {'$lookup': {'from': 'account',  'localField': "accountId",  'foreignField': "_id",  'as': 'account'}},
            {'$unwind': '$account'},
            {'$match': {'account.invitedBy._id': ObjectId(invited_by_id )}}
            
        ])
        return list(users)
