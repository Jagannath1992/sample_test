from bson import ObjectId
from flask import jsonify, request
import jwt
import pymongo
from datetime import datetime
from pymongo import DESCENDING
from ...permission_decorator import require_client_permission
from ...mongodb import db, get_program, get_nonprofit, translate_to_topic
from ...utils import DealStatus, get_descendant_key
from ...dao.utils import get_document
from matchmaking.controllers import dash_bp

YEARLY_QUARTERS = {
  1: 'Q1',
  2: 'Q1',
  3: 'Q1',
  4: 'Q2',
  5: 'Q2',
  6: 'Q2',
  7: 'Q3',
  8: 'Q3',
  9: 'Q3',
  10: 'Q4',
  11: 'Q4',
  12: 'Q4',
}

QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4']

@dash_bp.route('/pilot/reporting', methods=['GET'])
@require_client_permission
def get_pilot_reporting():
    user = request.user
    org_id = user.get('orgId', '')

    projection = [
        'givewithCustomerRole',
        'totalBudget',
        'fundingAmount',
        'client',
        'selectedProgram',
        'statusUpdatedAt',
        'category',
        'sourcingEventType',
        'department',
        'givewithCustomerUser',
    ]

    deal_query = {
        'givewithCustomerRole': 'buyer',
        'givewithCustomer': ObjectId(org_id),
        'status': str(DealStatus.COMPLETE),
        'type': {'$nin': ['covid']}
    }

    if user['type'] != 'admin':
        deal_query['isTest'] = False

    deals = list(db().coll_deals.find(deal_query, projection=projection).sort('statusUpdatedAt', DESCENDING))
    return jsonify(get_data(deals))

# fill in list with all years between current year and last year on list
def _fill_in_missing_numbers_in_list(list):
    current_year = datetime.now().year

    smallest_value = min(list)
    largest_value = current_year

    result = list.copy()
    while smallest_value <= largest_value:
        if smallest_value not in result:
            result.append(smallest_value)

        smallest_value += 1

    result.sort()

    return result

def organize_funding_items_by_quarter(deals, compareBy='statusUpdatedAt'):
    funding_items_data = {}

    if deals:
        for deal in deals:
            status_date = deal.get(compareBy)

            if status_date.year not in funding_items_data:
                funding_items_data[status_date.year] = {}

            quarter = YEARLY_QUARTERS[status_date.month]
            if quarter not in funding_items_data[status_date.year]:
                funding_items_data[status_date.year][quarter] = []
            
            funding_items_data[status_date.year][quarter].append(deal)

            if ('actualizations' in deal):
                for a in deal['actualizations']:
                    actualization_start_date = a['date']['startDate']

                    if actualization_start_date.year not in funding_items_data:
                        funding_items_data[actualization_start_date.year] = {}

                    quarter = YEARLY_QUARTERS[actualization_start_date.month]
                    if quarter not in funding_items_data[actualization_start_date.year]:
                        funding_items_data[actualization_start_date.year][quarter] = []
                    
                    funding_items_data[actualization_start_date.year][quarter].append(a)

        # fill in missing years
        all_years = _fill_in_missing_numbers_in_list(list(funding_items_data.keys()))

        # fill in empty years
        for year in all_years:
            if year not in funding_items_data:
                funding_items_data[year] = {}

        # fill in empty quarters
        for year in funding_items_data:
            deal_quarters = list(funding_items_data[year].keys())
            new_year_data = {}
            for quarter in QUARTERS:
                if quarter not in deal_quarters:
                    new_year_data[quarter] = []
                else:
                    new_year_data[quarter] = funding_items_data[year][quarter]

            funding_items_data[year] = new_year_data


    return funding_items_data

def get_data(deals):
    organized_deals = organize_funding_items_by_quarter(deals)

    social_impact = 0
    funding_generated = 0
    clients = []
    programs = []
    topics = []
    for deal in deals:
        social_impact += deal.get('totalBudget', 0)
        funding_generated += deal.get('fundingAmount', 0)

        if deal.get('client') not in clients:
            clients.append(deal.get('client'))

        program_document = get_program(deal['selectedProgram'], projection=[ 'imageLandscape', 'imagePortrait', 'name', 'nonprofit', 'themes' ])

        program_topics = list({translate_to_topic(_id=_id) for _id in program_document.get('themes', {}).get('data', [])})
        topics.extend(program_topics)

        nonprofit_document = get_nonprofit(program_document['nonprofit'], projection=[ 'name' ])
        program = {
            **program_document,
            'nonprofit': nonprofit_document,
            'fundingAmount': deal.get('fundingAmount'),
        }

        funding_form = get_document(
            'program_funding_forms',
            query={'deal': ObjectId(deal['_id']), 'status': {'$in': ['APPROVED', 'EXECUTED']}},
            sort=[('lastUpdated', pymongo.DESCENDING)],
            projection=['objects']
        )

        if funding_form:
            program['outputs'] = funding_form.get('objects', [])

        programs.append(program)

    return {
        'quarterlyProposals': organized_deals,
        'proposals': deals,
        'numberOfProposals': len(deals),
        'socialImpact': social_impact,
        'fundingGenerated': funding_generated,
        'numberOfClients': len(clients),
        'programs': programs,
        'topics': list(set(topics)),
    }
