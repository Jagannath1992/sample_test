from matchmaking import db


result = db().coll_snapshot.update_many(
    {
        "type": "qualtrics",
        "qualtrics.surveys.response-data": {'$exists': True, '$ne': []}
    },
    {'$unset': {
        "qualtrics.surveys.$[].response-data.responses.$[].IPAddress": "",
        "qualtrics.surveys.$[].response-data.responses.$[].RecipientLastName": "",
        "qualtrics.surveys.$[].response-data.responses.$[].RecipientFirstName": "",
        "qualtrics.surveys.$[].response-data.responses.$[].RecipientEmail": "",
        "qualtrics.surveys.$[].response-data.responses.$[].Location": "",
        "qualtrics.surveys.$[].response-data.responses.$[].LocationLatitude": "",
        "qualtrics.surveys.$[].response-data.responses.$[].LocationLongitude": "",
        "qualtrics.surveys.$[].response-data.responses.$[].LocationAccuracy": ""
    }}
)
