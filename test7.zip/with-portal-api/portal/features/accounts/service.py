import csv
from datetime import datetime
import stripe
from stripe.error import InvalidRequestError
from portal.features.stripe.service import StripeService
from portal.shared.enums import UserRole
from portal.shared.errors import ExternalError
from portal.shared.repositories import account_repository, user_repository
from portal.shared.sage.enums import SageObjectType
from portal.shared.sage.models import SageContact, SageContactListInfo, SageContactListInfoContact, SageCustomer, SageMailAddress
from portal.shared.sage.service import SageService


class AccountService:
    def __init__(self, sage_service: SageService, stripe_service: StripeService):
        self.sage_service = sage_service
        self.stripe_service = stripe_service

    def create_missing_sage_and_stripe_customer_records(self):
        accounts = account_repository().get_many({
            'status': {'$ne':'new'},
            '$or': [{'stripe.customerId': {'$exists': 0}},
                    {'stripe.customerId': None},
                    {'sageCustomerId': {'$exists': 0}},
                    {'sageCustomerId': None},
                    {'sageRecordNo': {'$exists': 0}},
                    {'sageRecordNo': None}]})
        updated_accounts = []
        for account in accounts:
            updated_account, account_update = self.create_missing_sage_and_stripe_customer_record(account)
            if account_update:
                account_repository().patch(account['_id'], account_update, by='admin@givewith.com')
            updated_accounts.append(updated_account)
        if len(updated_accounts):
            self.write_csv(updated_accounts)
        return updated_accounts

    def create_missing_sage_and_stripe_customer_record(self, account):
        company = account.get('company', {})
        company_name = company.get('name', account['_id'])
        address = company.get('address', {})

        updated_account = {
            'account_id': account['_id'],
            'company_name': company_name,
            'org_admin_email': None,
            'org_admin_name': None,
            'finance_user_email': None,
            'finance_user_name': None,
            'stripe_message': None,
            'stripe_customer_id': None,
            'sage_message': None,
            'sage_customer_id': None,
            'sage_record_no': None

        }
        account_update = {}

        address = account.get('company', {}).get('address', {})

        finance_user = next(
            iter(
                user_repository().get_by_role(
                    account['_id'],
                    [UserRole.FINANCE],
                    {'username': 1, 'first_name': 1, 'last_name': 1, 'accountId': 1}) or []),
            {})
        org_admin_user = next(
            iter(
                user_repository().get_by_role(
                    account['_id'],
                    [UserRole.ORG_ADMIN],
                    {'username': 1, 'first_name': 1, 'last_name': 1, 'accountId': 1}) or []),
            {})

        user = finance_user
        if not user:
            user = org_admin_user
        if not user:
            user = {
                'username': 'user_not_found@example.com',
                'first_name': 'Not',
                'last_name': 'Found',
                'accountId': account['_id']
            }

        updated_account.update({
            'org_admin_email': org_admin_user.get('username'),
            'org_admin_name': f"{org_admin_user.get('first_name')} {org_admin_user.get('last_name')}" if org_admin_user else None,
            'finance_user_email': finance_user.get('username'),
            'finance_user_name': f"{finance_user.get('first_name')} {finance_user.get('last_name')}" if finance_user else None
        })

        stripe_customer_id = account.get('stripe', {}).get('customerId')
        has_invalid_stripe_customer = False
        if stripe_customer_id:
            try:
                stripe.Customer.retrieve(stripe_customer_id)
            except InvalidRequestError as e:
                has_invalid_stripe_customer = True
        if not stripe_customer_id or has_invalid_stripe_customer:
            try:
                stripe_customer = stripe.Customer.create(
                    address={'postal_code': address.get('postalCode')},
                    email=user.get('username'),
                    name=company_name  # Should this be a user's name?
                )
                updated_account['stripe_message'] = 'Stripe customer created'
                stripe_customer_id = stripe_customer.id
                account_update['stripe'] = {'customerId': stripe_customer_id}
            except Exception as e:
                updated_account['stripe_message'] = 'Unable to create stripe customer'
                return updated_account, account_update
        else:
            updated_account['stripe_message'] = 'Existing stripe customer used'
        updated_account['stripe_customer_id'] = stripe_customer_id

        sage_customer_id = account.get('sageCustomerId')
        sage_record_no = account.get('sageRecordNo')
        has_invalid_sage_customer = False
        if sage_customer_id and sage_record_no:
            try:
                self.sage_service._get_object(SageObjectType.CUSTOMER, sage_record_no, None)
            except ExternalError as e:
                has_invalid_sage_customer = True
        if not (sage_customer_id and sage_record_no) or has_invalid_sage_customer:
            result = self.create_sage_customer(account, company_name, user, address, stripe_customer_id)
            if result:
                sage_customer_primary_contact_name, sage_customer = result
                self.update_sage_customer(account, sage_customer_primary_contact_name, sage_customer.recordNo)
                updated_account['sage_message'] = 'Sage customer created'
                sage_customer_id = sage_customer.customerId
                sage_record_no = sage_customer.recordNo
                account_update.update({
                    'sageCustomerId': sage_customer.customerId,
                    'sageRecordNo': sage_customer.recordNo
                })
            else:
                updated_account['sage_message'] = 'Unable to create sage customer'
                return updated_account, account_update
        updated_account['sage_customer_id'] = sage_customer_id
        updated_account['sage_record_no'] = sage_record_no
        self.stripe_service.update_customer(stripe_customer_id, account['_id'], sage_customer_id)
        return updated_account, account_update

    # TODO: Use sage_service.create_sage_customer
    def create_sage_customer(self, account, company_name, user, address, stripe_customer_id):
        sage_customer_request = SageCustomer(
            NAME=company_name,
            DISPLAYCONTACT=SageContact(
                FIRSTNAME=user['first_name'],
                LASTNAME=user['last_name'],
                COMPANYNAME=company_name,
                EMAIL1=user['username'],
                MAILADDRESS=SageMailAddress(
                    ADDRESS1=address.get('address1'),
                    ADDRESS2=address.get('address2'),
                    CITY=address.get('city'),
                    STATE=address.get('stateProvince'),
                    ZIP=address.get('postalCode'),
                    COUNTRY=address.get('country')
                )
            ),
            GIVEWITH_ACCOUNT_ID=user['accountId'],
            STRIPE_CUSTOMER_ID=stripe_customer_id,
        )
        sage_customer = self.sage_service.create_customer(account, sage_customer_request)
        if sage_customer:
            return sage_customer_request.DISPLAYCONTACT.CONTACTNAME, sage_customer
        return None

    # TODO: Use sage_service.update_sage_customer
    def update_sage_customer(self, account, sage_contact_name, sage_customer_record_no):
        customer_update = SageCustomer(
            CONTACT_LIST_INFO=[
                SageContactListInfo(
                    CATEGORYNAME='Finance',
                    CONTACT=SageContactListInfoContact(
                        NAME=sage_contact_name
                    )
                )
            ]
        )
        self.sage_service.update_customer(account, customer_update, sage_customer_record_no)

    def write_csv(self, rows):
        with open(f'updated_accounts_{datetime.now().strftime("%Y_%m_%d-%I_%M_%S_%p")}.csv', 'w') as f:
            w = csv.DictWriter(f, rows[0].keys())
            w.writeheader()
            w.writerows(rows)
