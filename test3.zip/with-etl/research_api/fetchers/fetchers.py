import json
import pandas as pd
import paramiko
import pysftp
import requests
import zipfile
import os
import concurrent.futures

import boto3
import io
from base64 import decodebytes
from datetime import datetime, timedelta
from os import environ
from typing import Tuple, List, Dict, Any
from research_api.loggly import get_logger

from research_api.mongodb import db
from research_api.utils import GivewithError, DatasetNotFound, is_volume_score_type
from research_api.models import MSCI_TRANSLATE_COLUMNS
from research_api.logger import log_exception, PipelineLogger
from research_api.fetchers.utils import get_google_sheet, GoogleSheetDimension, transform_csrhub, _get_id_to_csrhub_category


TVL_URL = environ.get('TVL_URL')
TVL_USERNAME = environ.get('TVL_USERNAME')
TVL_PASSWORD = environ.get('TVL_PASSWORD')
TVL_HOST_KEY = bytes(environ.get('TVL_HOST_KEY'), 'utf-8')
TVL_HOST_KEY_TYPE = environ.get('TVL_HOST_KEY_TYPE')

RESEARCH_API_BUCKET = environ.get('RESEARCH_API_BUCKET')

SASB_URL_BASE = environ.get('SASB_URL_BASE')
SASB_KEY = environ.get('SASB_KEY')
SASB_API_ENDPOINTS = ['PL-SIC',"PL-LV1"]

CSRHUB_S3_KEY = environ.get('CSRHUB_S3_KEY')
CSRHUB_BASE_URL = environ.get('CSRHUB_BASE_URL')
CSRHUB_USERNAME = environ.get('CSRHUB_USERNAME')
CSRHUB_PASSWORD = environ.get('CSRHUB_PASSWORD')
NIELSEN_S3_KEY = environ.get('NIELSEN_S3_KEY')

MSCI_API_KEY = environ.get('MSCI_API_KEY')
MSCI_API_SECRET = environ.get('MSCI_API_SECRET')
MSCI_API_ESG_ENDPOINT = environ.get('MSCI_API_ESG_ENDPOINT')

AWS_ACCESS_KEY_ID = environ.get('AWS_ACCESS_KEY_ID')
AWS_SECRET_ACCESS_KEY = environ.get('AWS_SECRET_ACCESS_KEY')


s3_client = boto3.client('s3',
                        aws_access_key_id=AWS_ACCESS_KEY_ID,
                        aws_secret_access_key=AWS_SECRET_ACCESS_KEY)


def fetch(dataset:str, *args) -> Any:
    # allows passing of args to match other pipeline steps
    if dataset == 'CSRIT':
        return _fetch_csrit_data()

    elif dataset == 'MSCI':
        return _fetch_msci_data()

    elif dataset == 'TVL':
        return _fetch_tvl_data()

    elif dataset == 'SASB':
        return _fetch_sasb_data()

    elif dataset == 'CSRHUB':
        return _fetch_csrhub_data()

    elif dataset == 'NIELSEN':
        return _fetch_s3_intake_file(NIELSEN_S3_KEY, encoding='ISO-8859-1')

    else:
        raise DatasetNotFound()


def _fetch_csrit_data() -> Tuple[List[Dict[str, str]], List[Dict[str, str]], List[Dict[str, str]]]:
    """Fetch CSRIT data and list data

    Returns:
        [([dict], [dict])] -- tuple of array of dictionaries containing the csrit_lookup and csrit_data
    """
    csrit_sheet_id = environ.get('CSRIT_SHEET_ID')
    csrit_sheet_name = 'Company-NPO Match'
    csrit_narratives_sheet_name = 'Narratives'
    csrit_lookup_sheet_name = 'Lists'

    content = [
        (csrit_lookup_sheet_name, GoogleSheetDimension.COLUMNS),
        (csrit_sheet_name, GoogleSheetDimension.ROWS),
        (csrit_narratives_sheet_name, GoogleSheetDimension.ROWS)
    ]

    try:
        return tuple(get_google_sheet(csrit_sheet_id, name, dimension) for name, dimension in content)
    except Exception as exz:
        PipelineLogger.get_instance('CSRIT').log_exception(f'Exception occurred while fetching csrit data: {str(exz)}')
        raise GivewithError(str(exz), code=500)


def _fetch_msci_data():
    headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    }

    payload = {
        "coverage": "esg_ratings",
        "category_path_list": [
            "ESG Ratings:Company Summary",
            "ESG Ratings:Environmental:Scores",
            "ESG Ratings:Social:Scores",
            "ESG Ratings:Governance:Corporate Governance:Scores and Rankings",
        ],
        "factor_name_list": [
            "ISSUER_CUSIP",
            "ISSUER_SEDOL"
        ],
        "format": "json",
        "limit": 100,
        "offset": 0
    }

    data = pd.DataFrame()
    while (True):

        get_logger().info(f'Running endpoint {MSCI_API_ESG_ENDPOINT} and total records fetched so far {len(data.index)}')

        response = requests.post(MSCI_API_ESG_ENDPOINT,
                                 data=json.dumps(payload),
                                 headers=headers,
                                 auth=(MSCI_API_KEY, MSCI_API_SECRET)
                                )

        if response.status_code != 200:
            raise GivewithError(f"Could not fetch MSCI.\nResponse: {response.text}")

        if data.empty:
            data = pd.DataFrame(response.json()['result']['issuers'])
        else:
            res = pd.DataFrame(response.json()['result']['issuers'])
            data = pd.concat([data, res], ignore_index=True)

        total_count = response.json()['paging']['total_count']
        payload['offset'] = payload['offset'] + payload['limit']
        if payload['offset'] >= total_count:
            break

    data.fillna(0, inplace=True)
    data.rename(columns=MSCI_TRANSLATE_COLUMNS, inplace=True)

    return data


def _fetch_tvl_data():
    """ Fetches TVL data
    TVL data lives on an SFTP server as 5 different CSVs
    This method fetches the CSVs and imports them as pandas dataframes
    """
    dataframes = []

    date = datetime.now()
    retried = False

    score_types = ['pulse', 'insight', 'momentum', 'volume_daily', 'volume_ttmdaily']

    # Adds TVL url as a host on the server
    # from: - https://stackoverflow.com/questions/38939454/verify-host-key-with-pysftp
    #	    - https://docs.paramiko.org/en/2.6/api/keys.html#module-paramiko.ecdsakey
    cnopts = pysftp.CnOpts()
    key = paramiko.ecdsakey.ECDSAKey(data=decodebytes(TVL_HOST_KEY))
    cnopts.hostkeys.add(TVL_URL, TVL_HOST_KEY_TYPE, key)

    with pysftp.Connection(TVL_URL, username=TVL_USERNAME, password=TVL_PASSWORD, cnopts=cnopts) as sftp:
        # Get scores
        for score_type in score_types:
            try:
                filepath = _get_tvl_filepath(date, score_type)
                data = pd.read_csv(sftp.open(filepath))
                dataframes.append((score_type, data))

            except IOError as e:
                # TVL doesn't update until 9:00pm so it is likely that we will want yesterday's date
                # If we get an IOError try again with yesterday's date, but fail if that doesn't work too
                if retried:
                    raise GivewithError(f'Could not find TVL file: {filepath}')

                retried = True
                date = date - timedelta(days=1)
                score_types.append(score_type)

        # Get industries
        try:
            filepath = 'insight360/allcompanies/sasb/SASB Mapping/SICS Mapping.csv'
            
            data = pd.read_csv(sftp.open(filepath))
            dataframes.append(('industries', data))

        except IOError as e:
            if retried:
                raise GivewithError(f'Could not find TVL file: {filepath}')

    return dataframes


def _get_tvl_filepath(date, score_type):
    day = date.strftime('%d')
    month = date.strftime('%m')
    year = date.strftime('%Y')

    is_volume = is_volume_score_type(score_type)
    if is_volume:
        path = f'insight360/allcompanies/sasb/volume/{is_volume}/{year}'
        file_name = f'insight360_allcompanies_sasb_{score_type}_{year}{month}{day}.csv'
    else:
        path = f'insight360/allcompanies/sasb/allcategories/{score_type}/daily/{year}'
        file_name = f'insight360_allcompanies_sasb_allcategories_{score_type}_daily_{year}{month}{day}.csv'

    return f'{path}/{file_name}'


def _fetch_sasb_data():
    for endpoint in SASB_API_ENDPOINTS:
        response = requests.post(SASB_URL_BASE+endpoint , headers={'Authorization': SASB_KEY})

        with open(f'{endpoint}.zip', "wb") as f:
            f.write(response.content)

        with zipfile.ZipFile(f'{endpoint}.zip', "r") as z:
            # z.read()
            for file in z.namelist():
                if file.endswith('.csv'):
                    z.extract(file, path='research_api/fetchers/datafiles/')

    data = {}
    
    data['sasb_mapping'] = pd.read_csv('research_api/fetchers/datafiles/SICS_Mapping_Master_221231_final.csv',delimiter=',', header=1, encoding='cp1252' )


    data['sasb_topics_materiality_map'] = pd.read_csv('research_api/fetchers/datafiles/SASB_Codified_Standards_Level_I/CSV Formats/SASB_Codified_Standards_Topics_MM_220512.csv', delimiter=',', header=1, encoding='cp1252')


    data['sasb_topics'] = pd.read_csv("research_api/fetchers/datafiles/SASB_Codified_Standards_Level_I/CSV Formats/SASB_Codified_Standards_Topics_220512.csv", delimiter=',', header=1, encoding='cp1252')

# Clean up zipfiles 
    if os.path.exists("PL-LV1.zip"):
        os.remove("PL-LV1.zip")
    else:
        print("PL-LV1.zip does not exist")

    if os.path.exists("PL-SIC.zip"):
        os.remove("PL-SIC.zip")
    else:
        print("PL-SIC.zip does not exist")

    return data


def _fetch_s3_intake_file(key, sep=',', header=0, encoding='utf-8'):
    s3_obj = s3_client.get_object(Bucket=RESEARCH_API_BUCKET, Key=key)
    data = pd.read_csv(s3_obj['Body']._raw_stream, sep=sep, header=header, encoding=encoding)
    return data

def _fetch_csrhub_brands_by_ids(brands, session_token, mapping):
        ids = ','.join(brands)
        response = requests.get(CSRHUB_BASE_URL+'company/only:'+ids+'?session_id='+session_token)
        brand_list = response.json()
        brand_list = transform_csrhub(brand_list, mapping)
        return brand_list

def _fetch_csrhub_data():
    # Step Zero Get vocab mapping needed for transformation stage
    mapping = _get_id_to_csrhub_category()
    #Step One Authenticate
    response = requests.post(CSRHUB_BASE_URL+'session' , data={'name': CSRHUB_USERNAME, 'password': CSRHUB_PASSWORD})
    if response.status_code != 200:
            raise GivewithError(f"Could not fetch CSRHUB.\nResponse: {response.text}")
    session_token = response.json()['session_id']
    #Step Two Get all companies
    response = requests.post(CSRHUB_BASE_URL+'company?session_id='+session_token)
    if response.status_code != 200:
            raise GivewithError(f"Could not fetch CSRHUB.\nResponse: {response.text}")
    companies = response.json()
    companies_ids = [company['id'] for company in companies if company['name'] != 'NA']
    chunked_ids = [companies_ids[x:x+100] for x in range(0, len(companies_ids), 100)]
    #Step Three Fetch data for all brands from the company ids
    consolidated_brand_list = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        results = [executor.submit(_fetch_csrhub_brands_by_ids, chunk, session_token, mapping) for chunk in chunked_ids]
        for f in concurrent.futures.as_completed(results):
            consolidated_brand_list.extend(f.result())
        
    data = consolidated_brand_list
    return data

