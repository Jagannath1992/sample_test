import os
from flask import Blueprint


health_check_bp = Blueprint('health_check', __name__)
@health_check_bp.route('/', methods=['GET'])
def health_check():
    return {
        'status': 'pass',
        'version': '1.0',
        'description': 'health of givewith auth service',
        'env': os.environ.get('FLASK_ENV', 'local')
    }
