from typing import Dict, Iterable, Tuple

from matchmaking.models.models import UserRole as u, RBACGroup as g
from matchmaking.permissioning.constants import Action as a


def convert_groupings_to_role_defs(groupings: Dict[str, Iterable[g]]) -> Tuple[Tuple]:
    """Convert groupings of type: {'group_name': [role_a, role_b] }
    to role definitions consumable by casbin of type:
    (('g', 'role_a', 'group_name), ('g', 'role_b', 'group_name))
    """
    return tuple(
        ('g', group_name, str(policy_group))
        for group_name, policy_groups in groupings.items()
        for policy_group in policy_groups
    )


POLICY_DEFINITIONS = (
    # format: ('p', 'sub_rule', 'subject', 'obj_type', 'action') - refer to casbin_model_str in ./config.py
    # sub_rule: custom matcher (eg. sub_rule = r.sub == 'Jake', where r = request) - empty string to disable for now
    ('p', '', str(g.READER), '*', str(a.READ)),
    ('p', '', str(g.CREATOR), '*', str(a.CREATE)),
    ('p', '', str(g.UPDATER), '*', str(a.UPDATE)),
    ('p', '', str(g.DELETER), '*', str(a.DELETE)),
)

ROLE_DEFINITIONS = convert_groupings_to_role_defs({
    u.IC.value: (g.READER, ),
    u.MANAGER.value: (g.READER, g.CREATOR, g.UPDATER),
    u.ADMIN.value: (g.READER, g.CREATOR, g.UPDATER, g.DELETER),
})
