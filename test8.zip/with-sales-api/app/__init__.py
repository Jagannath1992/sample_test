import sys
import traceback

from flask import Flask
from flask_restful import Api
from flask_cors import CORS

from config import init_config, init_logger, send_loggly
from app.db.database import init_db
from app.rest.health_checks import HealthCheck
from app.rest.brand import Brand, Brands, BrandSearch
from app.rest.deal import Deal, DealProgramInfo, DealList, ConfirmationPendingDeal, PaymentPendingDeal, PotentialDeal, SelectDealAsset
from app.rest.industry import IndustryList
from app.rest.asset import Asset
from app.rest.insight import Insight
from app.rest.request_pitch_materials import RequestPitchMaterials

from app.utils.JSONEncoder import CustomJSONEncoder


def create_app(test_db=None):
    app = Flask(__name__)
    api = Api(app)

    # load config
    init_config(app)

    # init db
    init_db(app, test_db)

    app.register_error_handler(400, bad_request_handler)
    app.register_error_handler(500, internal_server_error_handler)

    CORS(app)

    # register route
    register_routes(api)

    app.config['RESTFUL_JSON'] = {'cls': CustomJSONEncoder}
    app.json_encoder = CustomJSONEncoder

    if not test_db:
        init_logger(app)

    return app


def register_routes(api):
    api.add_resource(HealthCheck, '/')

    api.add_resource(Brands, '/brand')
    api.add_resource(Brand, '/brand/<string:brand_id>')
    api.add_resource(BrandSearch, '/brand/search')

    api.add_resource(DealList, '/deal')
    api.add_resource(Deal, '/deal/<string:deal_id>')
    api.add_resource(DealProgramInfo, '/deal:program/<string:brand_id>/<string:program_id>/<string:deal_id>')
    api.add_resource(ConfirmationPendingDeal, '/deal:confirmation-pending/<string:deal_id>')
    api.add_resource(PaymentPendingDeal, '/deal:payment-pending/<string:deal_id>')
    api.add_resource(PotentialDeal, '/deal/potential/<string:client_id>')
    api.add_resource(SelectDealAsset, '/deal/<string:deal_id>/select-asset')

    api.add_resource(IndustryList, '/industry')

    api.add_resource(Asset, '/asset')

    api.add_resource(RequestPitchMaterials, '/pm')

    api.add_resource(Insight, '/insight/<string:brand_id>')


def bad_request_handler(e):
    return 'Invalid JSON!', 400


def internal_server_error_handler(e):
    exc_type, exc_value, exc_traceback = sys.exc_info()
    exception_details = {
        'extract_traceback': repr(traceback.extract_tb(exc_traceback)),
        'format_traceback': repr(traceback.format_tb(exc_traceback)),
        'exception': repr(traceback.format_exception(exc_type, exc_value, exc_traceback)),
        'formatted_lines': str(traceback.format_exc().splitlines()),
        'line_no': exc_traceback.tb_lineno,
    }
    send_loggly(str(exception_details))
    return 'Internal Server Error!', 500

