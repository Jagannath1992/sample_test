import json

### GET PREVIEW ASSETS ###
def test_preview_assets_wrong_slug(client, client_header):
    # invalid slug
    response = client.get('/preview-assets/wrong-slug', headers=client_header)
    assert response.status_code == 404

def test_preview_assets_fallback_values(client, client_header, admin_header):
    response = client.get('/preview-assets/katarina-s-pgrm', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/preview-assets/katarina-s-pgrm', headers=client_header)
    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert 'photo' in data
    assert 'previewImage' in data.get('photo')
    assert 'video' in data
    assert bool(data.get('videos')) == False

def test_preview_assets_success(client, client_header, admin_header):
    response = client.get('/preview-assets/x-7', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/preview-assets/x-7', headers=client_header)
    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert 'video' in data
    assert 'photo' in data

### GET ALL PREVIEW ASSETS ###
def test_preview_assets_all_wrong_slug(client, client_header):
    # invalid slug
    response = client.get('/preview-assets/wrong-slug/all', headers=client_header)
    assert response.status_code == 404

def test_preview_assets_all_fallback(client, admin_header, client_header):
    response = client.get('/preview-assets/katarina-s-pgrm/all', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/preview-assets/katarina-s-pgrm/all', headers=client_header)
    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert 'photos' in data
    assert 'previewImage' in data.get('photos')
    assert 'videos' in data
    assert bool(data.get('videos')) == False

def test_preview_assets_all_success(client, admin_header, client_header):
    response = client.get('/preview-assets/x-7/all', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/preview-assets/x-7/all', headers=client_header)
    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert 'photos' in data
    assert 'videos' in data
