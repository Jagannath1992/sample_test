from portal.features.accounts.service import AccountService
from portal.features.orders.service import OrderService
from portal.features.stripe.service import StripeService
from portal.features.users.service import AuthService, RegistrationService
from portal.features.error_logs.service import ErrorLogService
from portal.shared.email.service import EmailService
from portal.shared.flags.service import FlagService
from portal.shared.sage.service import SageService
from portal.features.transactions.service import TransactionService


all_services = {}


def init_services(config: dict):
    all_services['error_log'] = error_log_service = ErrorLogService()
    all_services["email"] = email_service = EmailService(config["email"])
    all_services['sage'] = sage_service = SageService(config['sage'], error_log_service)
    all_services['stripe'] = stripe_service = StripeService(config['stripe'])
    all_services['flags'] = flag_service = FlagService(config['flags'])
    all_services["auth"] = auth_service = AuthService(config["auth"])

    all_services['account'] = AccountService(sage_service, stripe_service)
    all_services["registration"] = RegistrationService(flag_service, auth_service)
    all_services['order'] = OrderService(email_service)
    all_services['transaction'] = TransactionService()


def account_service() -> AccountService:
    return all_services['account']


def auth_service() -> AuthService:
    return all_services['auth']


def email_service() -> EmailService:
    return all_services['email']


def error_log_service() -> ErrorLogService:
    return all_services['error_log']


def flag_service() -> FlagService:
    return all_services['flags']


def order_service() -> OrderService:
    return all_services['order']


def sage_service() -> SageService:
    return all_services['sage']


def stripe_service() -> StripeService:
    return all_services['stripe']


def registration_service() -> RegistrationService:
    return all_services['registration']


def transaction_service() -> TransactionService:
    return all_services['transaction']
