from matchmaking import db
from matchmaking.models.models import schema_nonprofit_v1, schema_nonprofit_v2, v
from bson import ObjectId

nonprofits = list(db().coll_nonprofits.find({}))

for nonprofit in nonprofits:
    naf_id = nonprofit.get('nonprofitSubmissionId', '')
    if isinstance(naf_id, ObjectId):
        naf_id = str(naf_id)

    if len(naf_id) > 0:
        schema_nonprofit = schema_nonprofit_v2
    else:
        schema_nonprofit = schema_nonprofit_v1

    nonprofit['isValid'] = v.validate(nonprofit, schema_nonprofit)
    db().coll_nonprofit_form.find_one_and_replace({'_id': nonprofit['_id']}, nonprofit)

