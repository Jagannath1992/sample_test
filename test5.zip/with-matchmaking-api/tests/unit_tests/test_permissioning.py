from unittest import mock

import pytest
import casbin

from matchmaking import utils
from matchmaking.permissioning.config import can, ArrayAdapter
from matchmaking.permissioning.constants import Action
from matchmaking.models.models import RBACGroup as g


@pytest.fixture(scope='function', autouse=True)
def patch_loggly(monkeypatch):
    monkeypatch.setattr('matchmaking.permissioning.config.send_loggly', mock.MagicMock())


def test_array_adapter_loads_policy_as_string_into_casbin():
    sample_policy = [
        ('p', 'sub=superuser', 'data', 'read'),
        ('p', 'sub=superuser', 'data', 'write')
    ]
    mock_casbin_persist = mock.MagicMock(spec=casbin.persist)

    with mock.patch('matchmaking.permissioning.config.casbin.persist', mock_casbin_persist):
        adapter = ArrayAdapter(sample_policy)
        adapter.load_policy(None)

        expected_calls = [
            mock.call('p, sub=superuser, data, read', mock.ANY),
            mock.call('p, sub=superuser, data, write', mock.ANY)
        ]

        mock_casbin_persist.load_policy_line.assert_has_calls(expected_calls)


class TestEnforceParams:
    mock_enforcer = mock.MagicMock()

    mock_brand = mock.MagicMock(return_value={})
    mock_brand_data_options = {
        'supportsRbac': {'featureFlags': {'rbac': True}},
        'noRbac': {'featureFlags': {'rbac': False}},
        'missingRbac': {'featureFlags': {}},
        'missingFeatureFlags': {},
    }

    mock_request = mock.MagicMock()
    mock_request.user = {'username': 'John', 'orgId': 'fake', 'roles': [str(g.READER)]}

    mock_request.headers = {}
    mock_origin_header = {'Origin': 'https://testing.givewith.com'}
    mock_enforce_header = {'X-EnforcePermissions': 'true'}

    mock_enforce_subdomains = ('testing', )


    @pytest.fixture(autouse=True)
    def setup_patches(self, monkeypatch):
        monkeypatch.setattr('matchmaking.permissioning.config.CASBIN_ENFORCER', self.mock_enforcer)
        monkeypatch.setattr('matchmaking.permissioning.config.get_document_by_id', self.mock_brand)
        monkeypatch.setattr('matchmaking.permissioning.config.request', self.mock_request)
        monkeypatch.setattr('matchmaking.permissioning.config.ENFORCE_ON_SUBDOMAINS', self.mock_enforce_subdomains)


    def is_enforcer_called(self):
        # used only in tests where the exact return value of enforce isn't too important
        try:
            can(Action.READ)(lambda: None)()
        except Exception:
            pass

        was_called = self.mock_enforcer.enforce.called
        self.mock_enforcer.reset_mock()

        return was_called


    @pytest.mark.parametrize('brand', [
        mock_brand_data_options['noRbac'],
        mock_brand_data_options['missingRbac'],
        mock_brand_data_options['missingFeatureFlags'],
    ])
    def test_no_enforce_if_no_feature_flag_or_header(self, brand):
        self.mock_request.headers = {}
        self.mock_brand.return_value = brand

        assert not self.is_enforcer_called()


    def test_no_enforce_if_feature_flag_but_no_header(self):
        self.mock_brand.return_value = self.mock_brand_data_options['supportsRbac']
        self.mock_request.headers = {}

        assert not self.is_enforcer_called()


    @pytest.mark.parametrize('headers', [
        mock_origin_header,
        mock_enforce_header,
        {**mock_enforce_header, **mock_origin_header}
    ])
    def test_no_enforce_if_no_feature_flag_but_header(self, headers):
        self.mock_brand.return_value = {}
        self.mock_request.headers = headers

        assert not self.is_enforcer_called()


    def test_no_enforce_if_subdomain_not_in_enforceable_list(self):
        self.mock_brand.return_value = self.mock_brand_data_options['supportsRbac']
        self.mock_request.headers = {'Origin': 'https://another-site.givewith.com'}

        assert not self.is_enforcer_called()


    @pytest.mark.parametrize('headers', [
        mock_origin_header,
        mock_enforce_header,
        {**mock_enforce_header, **mock_origin_header}
    ])
    def test_enforce_if_feature_flag_and_header(self, headers):
        self.mock_brand.return_value = self.mock_brand_data_options['supportsRbac']
        self.mock_request.headers = headers

        assert self.is_enforcer_called()


    def test_allow_if_user_is_allowed_by_casbin(self):
        self.mock_enforcer.enforce.return_value = True
        self.mock_brand.return_value = self.mock_brand_data_options['supportsRbac']
        self.mock_request.headers = self.mock_enforce_header

        sample_data = can(Action.READ)(lambda: 'mock_view_data')()
        assert sample_data == 'mock_view_data'


    def test_deny_if_user_is_denied_by_casbin(self):
        self.mock_enforcer.enforce.return_value = False
        self.mock_brand.return_value = self.mock_brand_data_options['supportsRbac']
        self.mock_request.headers = self.mock_enforce_header

        with pytest.raises(utils.GivewithError):
            can(Action.READ)(lambda: 'mock_view_data')()
