import json
import jwt
import sys
import traceback

from flask import jsonify
from app.response import error_response
from app.validation.authorize import validate_login
from app.db.database import get_db
from app.service.cognito import authenticate_refresh_token, authenticate_user
from app.loggly import send_loggly
from app.utils import audit_logger, JSONEncoder
from flask import Blueprint, request
from datetime import datetime
from os import environ

auth_bp = Blueprint('authorize', __name__)
version = 1.0
PRIVATE_KEY = environ.get('PRIVATE_KEY', 'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl'
                                         '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')
real_estate_user_types = ['re-owner', 're-manager', 're-marquee-tenant', 're-tenant', 're-vendor']


"""
@api {post} /authorize Authorize User
@apiName Authorize
@apiGroup Authorize
@apiDescription Authorize a user or refresh token

@apiError 403 Insufficient permissions
@apiError 401 Incorrect username or password
@apiError 400 Bad request

@apiParam {String="password, refresh_token"} grantType the authorize grant type
@apiParam {String} username the user's name
@apiParam {String} password the user's password
@apiParam {String="admin, impact, psf"} scope the scope attempt to authorize
@apiParam {String} refresh_token the refresh token to authorize

@apiParamExample {json} Authenticate user example:
{
    "grantType": "password",
    "username": "user@givewith.com",
    "password": "test_password",
    "scope": "admin"
}

@apiParamExample {json} Authenticate refresh token example:
{
    "grantType": "refresh_token",
    "refresh_token": "eyJjdHkiOiJKV1QiLCJlbm....",

}

@apiSuccessExample {json} Success authorize user response example:
{
    "expires": 3600,
    "refresh_token": "eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUl...",
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZGE3NTdkMi1m...",
    "token_type": "Bearer"
}

@apiSuccessExample {json} Success authorize refresh token response example:
{
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZGE3NTdk...",
    "expires": 3600,
    "token_type": "Bearer"
}
"""
@auth_bp.route('/', methods=['POST'])
def authorize():
    # validate request
    err = validate_login()
    if len(err) > 0:
        return error_response(400, 'bad request', err)

    grant_type = request.json.get('grantType')
    if grant_type == 'password':
        return authorize_user()

    if grant_type == 'refresh_token':
        return authorize_refresh_token()


def authorize_refresh_token():
    # load refresh token from db
    from app.rest.okta_auth import get_sub_domain
    refresh_token = request.json.get('refresh_token')
    token_info = get_db().refresh_token_scope.find_one({'refresh_token': refresh_token})

    if token_info is None:
        return error_response(401, 'Invalid refresh token')

    user = get_db().user.find_one({'username': token_info['username']})
    if user is None:
        return error_response(401, 'username %s not found' % token_info['username'])

    try:
        # authenticate
        response = authenticate_refresh_token(refresh_token)

        access_token = response['AuthenticationResult']['AccessToken']
        scope = token_info.get('scope', '')
        resource_ids = token_info.get('resource_ids', [])

        payload = jwt.decode(access_token, verify=False)
        payload['scope'] = scope
        payload['resource_ids'] = resource_ids
        payload['version'] = version
        payload['user_id'] = str(user['_id'])
        payload['email'] = str(user['username'])
        payload['subdomain'] = get_sub_domain(user)

        user.pop('username', None)
        payload.update(user)
        payload.pop('phoneNumber', None)
        payload.pop('notes', None)
        payload.pop('businessAddress', None)
        payload.pop('password', None)

        access_token = jwt.encode(payload, PRIVATE_KEY, algorithm='HS256', json_encoder=JSONEncoder.CustomJSONEncoder)
        send_loggly("authorize_refresh_token " + payload['email'] + " SUCCESS")
        audit_logger.log('auth', str(user['_id']), 'user', str(user['_id']), 'authorize refresh token', '', '')

        return jsonify({
            'access_token': access_token.decode(),
            'token_type': 'Bearer',
            'expires': '3600'
        })
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        error_details = {
            'extract_traceback': repr(traceback.extract_tb(exc_traceback)),
            'format_traceback': repr(traceback.format_tb(exc_traceback)),
            'exception': repr(traceback.format_exception(exc_type, exc_value, exc_traceback)),
            'formatted_lines': str(traceback.format_exc().splitlines()),
            'line_no': exc_traceback.tb_lineno,
        }
        send_loggly("authorize refresh token: " + refresh_token + " FAIL " + 'details: ' + str(error_details))
        delete_refresh_token_scope(refresh_token)
        return error_response(401, str(e))


def authorize_user():
    from app.rest.okta_auth import get_sub_domain
    username = request.json.get('username')
    password = request.json.get('password')
    scope = request.json.get('scope')

    send_loggly("authorize_user: " + username + " INIT")

    # load user from dbs
    user = get_db().user.find_one({'username': username})
    
    if user is None:
        return error_response(401, 'username %s not found' % username)
    
    if not user.get('active', False):
        return error_response(401, 'user %s is not active' % username)

    if user.get('cognito-id', '') == '':
        return error_response(401, 'user cognito-id not found')

    # validate scope
    if not validate_request_scope(user, scope):
        send_loggly("authorize_user: " + username + " VALIDATE_REQUEST_USER_SCOPE failed with scope " + scope)
        return error_response(403, 'insufficient permissions')

    max_scope = get_max_scope(user, scope)

    try:
        # authenticate
        response = authenticate_user(user["cognito-id"], password)

        if 'ChallengeName' in response:
            if response["ChallengeName"] == "NEW_PASSWORD_REQUIRED":
                send_loggly("authorize_user: " + username + " NEW_PASSWORD_REQUIRED")
                return prepare_reset_password_response(response, username)
            else:
                send_loggly("authorize_user: " + username + " CHALLENGE_NAME")
                raise Exception(response["ChallengeName"])

        access_token = response['AuthenticationResult']['AccessToken']
        refresh_token = response['AuthenticationResult']['RefreshToken']

        payload = jwt.decode(access_token, verify=False)
        payload['scope'] = max_scope
        payload['resource_ids'] = [str(user['orgId'])]
        payload['version'] = version
        payload['user_id'] = str(user['_id'])
        payload['email'] = str(user['username'])
        payload['subdomain'] = get_sub_domain(user)

        user.pop('username', None)
        payload.update(user)
        payload.pop('phoneNumber', None)
        payload.pop('notes', None)
        payload.pop('businessAddress', None)
        payload.pop('password', None)

        access_token = jwt.encode(payload, PRIVATE_KEY, algorithm='HS256', json_encoder=JSONEncoder.CustomJSONEncoder)

        save_refresh_token(user, refresh_token, max_scope, username)
        update_user_last_login(username)
        send_loggly("authorize_user: " + username + " SUCCESS")
        audit_logger.log('auth', str(user['_id']), 'user', str(user['_id']), 'authorize user', '', '')

        return jsonify({
            'token': access_token.decode(),
            'refresh_token': refresh_token,
            'token_type': 'Bearer',
            'ExpiresIn': 3600
        })
    except Exception as e:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        error_details = {
            'extract_traceback': repr(traceback.extract_tb(exc_traceback)),
            'format_traceback': repr(traceback.format_tb(exc_traceback)),
            'exception':  repr(traceback.format_exception(exc_type, exc_value, exc_traceback)),
            'formatted_lines':  str(traceback.format_exc().splitlines()),
            'line_no': exc_traceback.tb_lineno,
        }
        send_loggly("authorize_user: " + username + " FAIL " + 'details: ' + str(error_details))
        return error_response(401, str(e))


def validate_request_scope(user, scope):
    user_type = user.get('type', '')
    user_org_type = user.get('orgType', '')
    department_type = user.get('departmentType', '')

    if scope is None:
        return True

    if user_type == 'admin':
        return True

    if scope == 'admin':
        return False

    # prevent nonprofit user access impact platform
    if scope == 'impact' and (user_org_type != 'brand' and user_org_type != 'nonprofit'):
        return False

    if scope == 'psf' and user_org_type != 'nonprofit':
        return False

    if scope == 'sales' and department_type != 'Sales':
        return False

    return True


def save_refresh_token(user, refresh_token, scope, username):
    get_db().refresh_token_scope.insert_one({'username': username, 'refresh_token': refresh_token,
                                             'scope': scope, 'resource_ids': [str(user['orgId'])],
                                             'created_at': datetime.now()})


def update_user_last_login(username):
    get_db().user.update_one({'username': username}, {'$set': {'last_login': datetime.now()}})


def delete_refresh_token_scope(refresh_token):
    get_db().refresh_token_scope.delete_one({'refresh_token': refresh_token})


def prepare_reset_password_response(response, name):
    user_attributes = json.loads(response["ChallengeParameters"]["userAttributes"])
    challenge_response = {
        'message': 'Please Set Up A New Password',
        'session': response["Session"],
        'challenge_name': response["ChallengeName"],
        'name': name,
        'email': user_attributes['email'],
        'given_name': user_attributes['given_name'],
        'family_name': user_attributes['family_name']
    }

    send_loggly("prepare_reset_password_response for user: " + name)
    return challenge_response


def get_max_scope(user, requested_scope):
    """Return token scope based on user role and organization type

    Scope definition:
    admin: Grants access to all platforms.
    impact: Grants access to impact platform only.
    psf: Grants access to proposal submission form product only.

    """
    if user['type'] == 'admin':
        return 'admin'

    if user['type'] == 'client' or user['type'] in real_estate_user_types:
        if user['orgType'] == 'brand':
            return 'impact'

        if user['orgType'] == 'nonprofit':
            if requested_scope == 'impact':
                return 'impact'
            else:
                return 'psf'

    return ''
