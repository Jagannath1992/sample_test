import json


def test_filter_string(client, admin_header):
    response = client.get('/admin/deals', headers=admin_header)
    deals = json.loads(response.data.decode())
    assert response.status_code == 200

    slug = deals[0].get('slug')
    _id = deals[0].get('_id')

    response = client.get('/admin/deals?filter=slug eq ' + slug, headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert str(deals[0].get('_id')) == _id


def test_filter_date(client, admin_header):
    response = client.get('/admin/deals', headers=admin_header)
    deals = json.loads(response.data.decode())
    assert response.status_code == 200

    statusUpdatedAt = deals[0].get('statusUpdatedAt')
    _id = deals[0].get('_id')

    response = client.get('/admin/deals?filter=statusUpdatedAt eq ' + str(statusUpdatedAt), headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert str(deals[0].get('_id')) == _id


def test_filter_object_id(client, admin_header):
    response = client.get('/admin/deals', headers=admin_header)
    deals = json.loads(response.data.decode())
    assert response.status_code == 200

    _id = deals[0].get('_id')

    response = client.get('/admin/deals?filter=_id eq ' + _id, headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert str(deals[0].get('_id')) == _id


def test_filter_extra_spaces(client, admin_header):
    response = client.get('/admin/deals', headers=admin_header)
    deals = json.loads(response.data.decode())
    assert response.status_code == 200

    slug = deals[0].get('slug')

    response = client.get('/admin/deals?filter=slug eq     ' + slug + '    and slug eq   \'    a  b  c   d   \'    ', headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert len(deals) == 0
