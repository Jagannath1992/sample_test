from matchmaking import db

deals = list(db().coll_deals.find())
for deal in deals:
    deliverables = deal.get('deliverables')
    if deliverables:
        customer_deliv = deliverables['givewithCustomer']['deliverables']
        client_deliv = deliverables['client']['deliverables']

        for deliverable in customer_deliv:
            if deliverable['name'] == 'ESGReportingGuide':
                deliverable['name'] = 'ESGReportingGuide_CUSTOMER'

        for (index, deliverable) in enumerate(client_deliv):
            if deliverable['name'] == 'ESGReportingGuide':
                deliverable['name'] = 'ESGReportingGuide_CLIENT'
                deliverable['display'] = False
                deliverable.pop('url', None)

        db().coll_deals.update_one({'_id' : deal.get('_id')}, {'$set': {'deliverables.givewithCustomer.deliverables': customer_deliv,
                                                                    'deliverables.client.deliverables': client_deliv}})

