import datetime

from bson import ObjectId
from typing import List, Any, Dict, Tuple

from portal.shared.enums import OrderStatus
from portal.shared.repository import DocumentRepository


class OrderRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['order'])

    def delete(self, document_id: ObjectId, by: str = None) -> bool:
        changes = {
            'status': OrderStatus.DELETED.value
        }
        updated = self.patch(document_id, changes, by=by)
        return updated is not None

    def has_access(self, order_id: str, account_id: ObjectId) -> bool:
        return self.collection.count_documents({
            '_id': ObjectId(order_id),
            'account._id': ObjectId(account_id)
        }) != 0

    def get_totals_by_status(self, account_id: ObjectId) -> list:
        result = self.collection.aggregate([
            { '$match':{ 'account._id':ObjectId(account_id), "status":"approved" } },
            { '$group':{ '_id':'$status', 'total':{ '$sum':'$grandTotal' }, 'count':{ '$sum':1 } } }
        ])
        return list(result)

    def get_totals_by_month(self, account_id: ObjectId, year: int) -> list:
        first_of_year = datetime.datetime(year, 1, 1)
        result = self.collection.aggregate([
            { '$match':{ 'account._id':ObjectId(account_id), "comments.newStatus":"completed", "comments.timestamp":{ "$gte":first_of_year } } },
            { '$group':{ '_id':{ '$month':'$lastUpdated' }, 'total':{ '$sum':'$grandTotal' } } }
        ])
        return list(result)

    def get_page(self, filters: Dict[str, Any], add_fields: dict={}) -> Tuple[int, List[Any]]:
        """ Overides the default get_page method to add a calculated field for giveIdString """
        if 'giveId' in filters:
            filters['giveIdString'] = filters.pop('giveId')
            add_fields = {
                'giveIdString': {'$toString': '$giveId'}
            }
        return DocumentRepository.get_page(self, filters, add_fields)

    def get_metrics(self, filters: dict, group_by: dict, completed_only: bool) -> list:
        statuses = [OrderStatus.APPROVED.value, OrderStatus.COMPLETED.value, OrderStatus.FINANCIAL_HOLD.value]
        if completed_only:
            statuses = [OrderStatus.COMPLETED.value]

        filters = {
            'status' : {'$in': statuses},
            **filters
        }

        pipeline = self._get_metrics_lookups()
        pipeline += [
            {'$match': filters},
            {'$addFields': {
                'percentOfDeal': {'$multiply': [{'$divide': ['$grandTotal', '$quoteAmount']}, 100]}
            }},
            {'$group': {
                '_id': group_by,
                'totalGiveAmount': {'$sum': '$grandTotal'},
                'avgGivePercent': {'$avg': '$percentOfDeal'},
            }},
            {"$set": {"avgGivePercent": {"$round": [ "$avgGivePercent",2]}}}
        ]

        result = self.collection.aggregate(pipeline)
        return list(result)

    def get_metrics_by_status(self, filters: dict, group_by: dict, completed_only: bool) -> list:
        if completed_only:
            filters = {
                'comments.newStatus': {'$in': [OrderStatus.COMPLETED.value]},
                **filters
            }

        pipeline = self._get_metrics_lookups()
        pipeline += [
            {'$match': filters},
            {'$group': {
                '_id': group_by,
                'count': {'$sum': 1},
                'totalGiveAmount': {'$sum': '$grandTotal'},
                'totalDealAmount': {'$sum': '$quoteAmount'},
            }}
        ]

        result = self.collection.aggregate(pipeline)
        return list(result)


    def get_metrics_by_cause_area(self, filters: dict, group_by: dict, completed_only: bool) -> list:
        statuses = [OrderStatus.APPROVED.value, OrderStatus.COMPLETED.value, OrderStatus.FINANCIAL_HOLD.value]
        if completed_only:
            statuses = [OrderStatus.COMPLETED.value]

        filters = {
            'status' : {'$in': statuses},
            **filters
        }
        

        pipeline = self._get_metrics_lookups()
        pipeline += [
            {'$match': filters},
            {'$group': {
                '_id': group_by,
                'totalGiveAmount': {'$sum': '$grandTotal'},
                'completedGiveCount': {'$sum' : 1 },
                'impact': {'$sum': '$causeArea.impact.totalValue'},
                'causeAreaUrl' : {'$first':"$ca.detailLinkUrl"},
                'instanceId': {'$first':"$acct.instance._id"}

                
            }}
        ]
        result = self.collection.aggregate(pipeline)
        return list(result)

    def get_metrics_by_status(self, filters: dict, group_by: dict, completed_only: bool) -> list:
        if completed_only:
            filters = {
                'comments.newStatus': {'$in': [OrderStatus.COMPLETED.value]},
                **filters
            }

        pipeline = self._get_metrics_lookups()
        pipeline += [
            {'$match': filters},
            {'$group': {
                '_id': group_by,
                'count': {'$sum': 1},
                'totalGiveAmount': {'$sum': '$grandTotal'},
                'totalDealAmount': {'$sum': '$quoteAmount'},
            }}
        ]

        result = self.collection.aggregate(pipeline)
        return list(result)

    def get_win_rate(self, filters: dict, group_by: List[dict], completed_only: bool) -> list:
        statuses = [OrderStatus.APPROVED.value, OrderStatus.COMPLETED.value, OrderStatus.FINANCIAL_HOLD.value]
        if completed_only:
            statuses = [OrderStatus.COMPLETED.value]

        filters = {
            'comments.newStatus': {'$in': statuses},
            **filters
        }

        pipeline = self._get_metrics_lookups()
        pipeline += [
            {'$match': filters},
            {'$unwind': '$comments'},
            {'$group': {
                '_id': group_by[0],
                'count': {'$sum': 1}
            }},
            {'$group': {
                '_id': group_by[1],
                'counts': {'$push': {'status': '$_id.status', 'count': '$count'}}
            }}
        ]

        result = self.collection.aggregate(pipeline)
        return list(result)

    def get_most_gives(self, filters: dict, group_by: List[dict], completed_only: bool):
        statuses = [OrderStatus.PENDING_APPROVAL.value, OrderStatus.COMPLETED.value]
        if completed_only:
            statuses = [OrderStatus.COMPLETED.value]

        filters = {
            'comments.newStatus': {'$in': statuses},
            **filters
        }

        pipeline = self._get_metrics_lookups()
        pipeline += [
            {'$match': filters},
            {'$unwind': '$comments'},
            {'$group': {
                '_id': group_by[0],
                'count': {'$sum': 1}
            }},
            {'$sort': {
                '_id.causeArea': 1,
                '_id.status': 1,
                'count': -1
            }},
            {'$group': {
                '_id': group_by[1],
                'counts': {'$first': {'createdBy': '$_id.createdBy', 'count': '$count'}}
            }}
        ]

        result = self.collection.aggregate(pipeline)
        return list(result)

    def _get_metrics_lookups(self):
        pipeline = [
            {'$lookup': {
                'from': 'account',
                'localField': 'account._id',
                'foreignField': '_id',
                'as': 'acct'
            }},
            {'$unwind': '$acct'},

            {'$lookup': {
                'from': 'instance_settings',
                'localField': 'acct.instance._id',
                'foreignField': '_id',
                "as": 'inst'
            }},
            {'$unwind': '$inst'},

            {'$lookup': {
                'from': 'locale',
                'localField': 'inst.settings.locale._id',
                'foreignField': '_id',
                'as': 'loc'
            }},
            {'$unwind': '$loc'},

            {'$lookup': {
                'from': 'cause_area',
                'localField': 'causeArea._id',
                'foreignField': '_id',
                'as': 'ca'
            }},
            {'$unwind': '$ca'}
        ]
        return pipeline
