import pytest
import types

from bson import ObjectId
from datetime import datetime
from flask import request
from unittest.mock import call

from portal.conftest import AuthHeaderUsername
from portal.features.orders.validators import StatusValidator
from portal.features.stripe.enums import StripeSetupIntentAction
from portal.features.stripe.schema import CancelSubscriptionRequest, CreateOrderSetupCheckoutSessionRequest, CreateSetupCheckoutSessionRequest, CreateSetupCheckoutSessionResponse, CreateSubscriptionCheckoutSessionRequest, UpdateSubscriptionFrequencyRequest
from portal.shared.enums import OrderStatus, SubscriptionFrequency, UserRole
from portal.shared.repositories import account_repository, instance_settings_repository, locale_repository, order_repository
from portal.shared.services import order_service, stripe_service


class TestSetupCheckoutSession:
    @pytest.fixture
    def test_post_init(self, fakers, mocker):
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)

        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)

        account = {
            '_id': ObjectId(),
            'instance': {'_id': ObjectId()},
            'stripe': {'customerId': 'cus_123'}
        }
        get_validated_account_id_mock = mocker.patch(
            'portal.features.stripe.controller.get_validated_account_id', return_value=account['_id'])
        mocker.patch.object(account_repository(), 'get_single', return_value=account)

        checkout_session = types.SimpleNamespace(url='http://example.com/stripe')
        mocker.patch.object(stripe_service(), 'create_setup_checkout_session', return_value=checkout_session)

        return account, locale, get_validated_account_id_mock, checkout_session

    @pytest.fixture(params=[sat.value for sat in StripeSetupIntentAction])
    def test_post_request_json(self, request):
        return CreateSetupCheckoutSessionRequest().dump({
            'success_url': 'http://example.com/success',
            'cancel_url': 'http://example.com/cancel',
            'action_type': request.param
        })

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post(self, client, test_post_init, test_post_request_json,  custom_auth_header):
        # arrange
        account, locale, get_validated_account_id_mock, checkout_session = test_post_init
        currency = locale['settings']['currency']

        with client:
            # act
            response = client.post('/stripe/setup-checkout-session',
                                   json=test_post_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            stripe_service().create_setup_checkout_session.assert_called_once_with(
                account['stripe']['customerId'], currency, **request.parsed_obj)
            assert response.status_code == 200
            assert response.json == CreateSetupCheckoutSessionResponse().dump(checkout_session)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_404(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account_repository().get_single.return_value = None
        account, _, get_validated_account_id_mock, checkout_session = test_post_init

        with client:
            # act
            response = client.post('/stripe/setup-checkout-session',
                                   json=test_post_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            stripe_service().create_setup_checkout_session.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'Account not found'}


class TestOrderSetupCheckoutSession:
    @pytest.fixture
    def test_post_init(self, fakers, mocker):
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)

        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)

        account = {
            '_id': ObjectId(),
            'instance': {'_id': ObjectId()},
            'stripe': {'customerId': 'cus_123', 'autopay': {'paymentMethodId': None}}
        }
        mocker.patch.object(account_repository(), 'get_single', return_value=account)

        mocker.patch.object(order_repository(), 'exists', return_value=True)
        mocker.patch.object(order_repository(), 'has_access', return_value=True)
        mocker.patch.object(order_repository(), 'patch')

        get_validated_account_id_mock = mocker.patch(
            'portal.features.stripe.controller.get_validated_account_id', return_value=account['_id'])
        has_role_mock = mocker.patch('portal.features.stripe.controller.has_role', return_value=True)

        mocker.patch.object(StatusValidator, 'is_authorized', return_value=True)
        mocker.patch.object(StatusValidator, 'is_valid', return_value=True)

        checkout_session = types.SimpleNamespace(url='http://example.com/stripe')
        mocker.patch.object(stripe_service(), 'create_order_setup_checkout_session', return_value=checkout_session)

        expected_update = {
            'status': OrderStatus.PENDING_PAYMENT.value,
            'comments': [
                {'comment': 'Pending payment processing'}
            ]
        }
        mocker.patch.object(order_service(), 'timestamp_comments', return_value=expected_update)

        return account, locale, get_validated_account_id_mock, has_role_mock, checkout_session, expected_update

    @pytest.fixture()
    def test_post_request_json(self):
        order_ids = [ObjectId(), ObjectId()]
        request_json = CreateOrderSetupCheckoutSessionRequest().dump({
            'success_url': 'http://example.com/success',
            'cancel_url': 'http://example.com/cancel',
            'order_ids': order_ids
        })
        return order_ids, request_json

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post(self, client, test_post_init, test_post_request_json,  custom_auth_header):
        # arrange
        account, locale, get_validated_account_id_mock, has_role_mock, checkout_session, expected_update = test_post_init
        order_ids, request_json = test_post_request_json
        currency = locale['settings']['currency']

        with client:
            # act
            response = client.post('/stripe/order-setup-checkout-session',
                                   json=request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            has_role_mock.assert_has_calls([
                call(UserRole.SUPER_ADMIN, request.user),
                call(UserRole.SUPER_ADMIN, request.user)
            ])
            order_repository().has_access.assert_not_called()
            StatusValidator.is_authorized.assert_called()
            StatusValidator.is_valid.assert_called()
            stripe_service().create_order_setup_checkout_session.assert_called_once_with(
                account['stripe']['customerId'], currency, **request.parsed_obj)
            order_repository().patch.assert_has_calls([
                call(str(order_ids[0]), expected_update, AuthHeaderUsername.GIVEWITH.value),
                call(str(order_ids[1]), expected_update, AuthHeaderUsername.GIVEWITH.value)
            ])
            assert response.status_code == 200
            assert response.json == CreateSetupCheckoutSessionResponse().dump(checkout_session)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_not_found(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, _, get_validated_account_id_mock, has_role_mock, _, _ = test_post_init
        _, request_json = test_post_request_json
        account_repository().get_single.return_value = None

        with client:
            # act
            response = client.post('/stripe/order-setup-checkout-session',
                                   json=request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            has_role_mock.assert_not_called
            order_repository().has_access.assert_not_called()
            StatusValidator.is_authorized.assert_not_called()
            StatusValidator.is_valid.assert_not_called()
            stripe_service().create_order_setup_checkout_session.assert_not_called()
            order_repository().patch.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'Account not found'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_forbidden_autopay_enabled(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, _, get_validated_account_id_mock, has_role_mock, _, _ = test_post_init
        order_ids, request_json = test_post_request_json
        account['stripe']['autopay']['paymentMethodId'] = 'pm_123'

        with client:
            # act
            response = client.post('/stripe/order-setup-checkout-session',
                                   json=request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            has_role_mock.assert_not_called()
            order_repository().has_access.assert_not_called()
            StatusValidator.is_authorized.assert_not_called()
            StatusValidator.is_valid.assert_not_called()
            stripe_service().create_order_setup_checkout_session.assert_not_called()
            order_repository().patch.assert_not_called()
            assert response.status_code == 403
            assert response.json == {'message': 'Cannot use pay as you go when autopay is enabled'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_forbidden_no_access(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, _, get_validated_account_id_mock, has_role_mock, _, _ = test_post_init
        order_ids, request_json = test_post_request_json
        has_role_mock.return_value = False
        order_repository().has_access.return_value = False

        with client:
            # act
            response = client.post('/stripe/order-setup-checkout-session',
                                   json=request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            has_role_mock.assert_called_once_with(UserRole.SUPER_ADMIN, request.user)
            order_repository().has_access.assert_called_once_with(str(order_ids[0]), request.user['accountId'])
            StatusValidator.is_authorized.assert_not_called()
            StatusValidator.is_valid.assert_not_called()
            stripe_service().create_order_setup_checkout_session.assert_not_called()
            order_repository().patch.assert_not_called()
            assert response.status_code == 403
            assert response.json == {'message': 'You do not have permission to access one or more Gives'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_forbidden_not_authorized(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, _, get_validated_account_id_mock, has_role_mock, _, _ = test_post_init
        _, request_json = test_post_request_json
        StatusValidator.is_authorized.return_value = False

        with client:
            # act
            response = client.post('/stripe/order-setup-checkout-session',
                                   json=request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            has_role_mock.assert_called_once_with(UserRole.SUPER_ADMIN, request.user)
            order_repository().has_access.assert_not_called()
            StatusValidator.is_authorized.assert_called()
            StatusValidator.is_valid.assert_not_called()
            stripe_service().create_order_setup_checkout_session.assert_not_called()
            order_repository().patch.assert_not_called()
            assert response.status_code == 403
            assert response.json == {'message': 'Not authorized to update Give status'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_forbidden_invalid_status(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, _, get_validated_account_id_mock, has_role_mock, _, _ = test_post_init
        _, request_json = test_post_request_json
        StatusValidator.is_valid.return_value = False

        with client:
            # act
            response = client.post('/stripe/order-setup-checkout-session',
                                   json=request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'instance._id': 1})
            has_role_mock.assert_called_once_with(UserRole.SUPER_ADMIN, request.user)
            order_repository().has_access.assert_not_called()
            StatusValidator.is_authorized.assert_called()
            StatusValidator.is_valid.assert_called()
            stripe_service().create_order_setup_checkout_session.assert_not_called()
            order_repository().patch.assert_not_called()
            assert response.status_code == 403
            assert response.json == {'message': 'Invalid Give status'}


class TestSubscriptionCheckoutSession:
    @pytest.fixture
    def test_post_init(self, fakers, mocker):
        account = fakers.account.generate_single()
        get_validated_account_id_mock = mocker.patch(
            'portal.features.stripe.controller.get_validated_account_id', return_value=account['_id'])
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        checkout_session = {'url': 'http://example.com/checkout'}
        mocker.patch.object(stripe_service(), 'create_subscription_checkout_session', return_value=checkout_session)
        return account, get_validated_account_id_mock, instance, checkout_session

    @pytest.fixture
    def test_post_request_json(self, test_post_init):
        account, _, _, _ = test_post_init
        request = {
            'accountId': account['_id'],
            'frequency': SubscriptionFrequency.ANNUAL.value,
            'success_url': 'http://example.com/success',
            'cancel_url': 'http://example.com/cancel'
        }
        return CreateSubscriptionCheckoutSessionRequest().dump(request)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, get_validated_account_id_mock, instance, checkout_session = test_post_init

        with client:
            # act
            response = client.post('/stripe/subscription-checkout-session',
                                   json=test_post_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'stripe.trialPeriodUsed': 1, 'instance._id': 1})
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            data = request.parsed_obj
            stripe_service().create_subscription_checkout_session.assert_called_once_with(
                instance, data['frequency'],
                account['stripe']['trialPeriodUsed'],
                account['stripe']['customerId'],
                data['success_url'],
                data['cancel_url'],
                account['type'])
            assert response.status_code == 200
            assert response.json == checkout_session

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_account_not_found(self, client, test_post_init, test_post_request_json, custom_auth_header):
        # arrange
        account, get_validated_account_id_mock, instance, checkout_session = test_post_init
        account_repository().get_single.return_value = None

        with client:
            # act
            response = client.post('/stripe/subscription-checkout-session',
                                   json=test_post_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(
                account['_id'], {'stripe.customerId': 1, 'stripe.trialPeriodUsed': 1, 'instance._id': 1})
            instance_settings_repository().get_single.assert_not_called()
            stripe_service().create_subscription_checkout_session.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'Account not found'}


class TestAutoPay:
    @pytest.fixture
    def test_delete_init(self, mocker):
        account = {'_id': ObjectId(), 'stripe': {'customerId': 'cus_123'}}
        get_validated_account_id_mock = mocker.patch(
            'portal.features.stripe.controller.get_validated_account_id', return_value=account['_id'])
        mocker.patch.object(account_repository(), 'patch', return_value=account)
        return account, get_validated_account_id_mock

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete(self, client, test_delete_init, custom_auth_header):
        # arrange
        account, get_validated_account_id_mock = test_delete_init
        expected_update = {'stripe': {'autopay': {'paymentMethodId': None, 'enabledDate': None}}}

        with client:
            # act
            response = client.delete('/stripe/autopay', json={}, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().patch.assert_called_once_with(
                account['_id'], expected_update, AuthHeaderUsername.GIVEWITH.value)
            assert response.status_code == 200

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete_400(self, client, test_delete_init, custom_auth_header):
        # arrange
        account_repository().patch.return_value = None
        account, get_validated_account_id_mock = test_delete_init
        expected_update = {'stripe': {'autopay': {'paymentMethodId': None, 'enabledDate': None}}}

        with client:
            # act
            response = client.delete('/stripe/autopay', json={}, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().patch.assert_called_once_with(
                account['_id'], expected_update, AuthHeaderUsername.GIVEWITH.value)
            assert response.status_code == 404


class TestAutoPay_integration:
    pytestmark = pytest.mark.integration

    def test_delete(self, client, fakers, givewith_header):
        # arrange
        account = fakers.account.insert_single(
            {'stripe': {'autopay': {'paymentMethodId': 'test_123', 'enabledDate': datetime.now()}}})
        assert account['stripe']['autopay']['paymentMethodId']
        assert account['stripe']['autopay']['enabledDate']

        # act
        response = client.delete('/stripe/autopay', json={'accountId': account['_id']}, headers=givewith_header)
        updated_account = account_repository().get_single(account['_id'])

        # assert
        assert updated_account['stripe']['autopay']['paymentMethodId'] == None
        assert updated_account['stripe']['autopay']['enabledDate'] == None
        assert response.status_code == 200


class TestSubscription:
    @pytest.fixture
    def test_patch_init(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        account['instance']['_id'] = instance['_id']
        account['instance']['name'] = instance['name']
        get_validated_account_id_mock = mocker.patch(
            'portal.features.stripe.controller.get_validated_account_id', return_value=account['_id'])
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        account_update = {'account': 'update'}
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(stripe_service(), 'update_subscription_frequency', return_value=account_update)
        mocker.patch.object(account_repository(), 'patch')
        return get_validated_account_id_mock, account, account_update, instance

    @pytest.fixture
    def test_patch_request_json(self, test_patch_init):
        _, account, _, _ = test_patch_init
        return UpdateSubscriptionFrequencyRequest().dump({
            'accountId': account['_id'],
            'subscriptionFrequency': SubscriptionFrequency.ANNUAL.value
        })

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch(self, client, test_patch_init, test_patch_request_json, custom_auth_header):
        # arrange
        get_validated_account_id_mock, account, account_update, instance = test_patch_init

        with client:
            # act
            response = client.patch('/stripe/subscription', json=test_patch_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(account['_id'])
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            stripe_service().update_subscription_frequency.assert_called_once_with(
                instance,
                account['stripe']['subscription']['id'],
                account['subscriptionFrequency'],
                request.parsed_obj['subscriptionFrequency'],
                account['type'])
            account_repository().patch.assert_called_once_with(
                account['_id'], account_update, AuthHeaderUsername.GIVEWITH.value)
            assert response.status_code == 200

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch_404(self, client, test_patch_init, test_patch_request_json, custom_auth_header):
        # arrange
        account_repository().get_single.return_value = None
        get_validated_account_id_mock, account, _, _ = test_patch_init

        with client:
            # act
            response = client.patch('/stripe/subscription', json=test_patch_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(account['_id'])
            instance_settings_repository().get_single.assert_not_called()
            stripe_service().update_subscription_frequency.assert_not_called()
            account_repository().patch.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'Account not found'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch_no_account_update(self, client, test_patch_init, test_patch_request_json, custom_auth_header):
        # arrange
        get_validated_account_id_mock, account, _, instance = test_patch_init
        stripe_service().update_subscription_frequency.return_value = None

        with client:
            # act
            response = client.patch('/stripe/subscription', json=test_patch_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(account['_id'])
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            stripe_service().update_subscription_frequency.assert_called_once_with(
                instance,
                account['stripe']['subscription']['id'],
                account['subscriptionFrequency'],
                request.parsed_obj['subscriptionFrequency'],
                account['type'])
            account_repository().patch.assert_not_called()
            assert response.status_code == 200

    @pytest.fixture
    def test_delete_init(self, fakers, mocker):
        account = fakers.account.generate_single()
        get_validated_account_id_mock = mocker.patch(
            'portal.features.stripe.controller.get_validated_account_id', return_value=account['_id'])
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        account_update = {'account': 'update'}
        mocker.patch.object(stripe_service(), 'cancel_subscription', return_value=account_update)
        mocker.patch.object(account_repository(), 'patch')
        return account, get_validated_account_id_mock, account_update

    @pytest.fixture
    def test_delete_request_json(self, test_delete_init):
        account, _, _ = test_delete_init
        return CancelSubscriptionRequest().dump({'accountId': account['_id']})

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete(self, client, test_delete_init, test_delete_request_json, custom_auth_header):
        # arrange
        account, get_validated_account_id_mock, account_update = test_delete_init

        with client:
            # act
            response = client.delete('/stripe/subscription', json=test_delete_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(account['_id'], {'stripe.subscription.id': 1})
            stripe_service().cancel_subscription.asset_called_once_with(account['stripe']['subscription']['id'])
            account_repository().patch.assert_called_once_with(
                account['_id'], account_update, AuthHeaderUsername.GIVEWITH.value)
            assert response.status_code == 200
            assert not response.json

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete_no_account_id_in_request(self, client, test_delete_init, custom_auth_header):
        # arrange
        account, get_validated_account_id_mock, account_update = test_delete_init

        with client:
            # act
            response = client.delete('/stripe/subscription', json={}, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(None, request)
            account_repository().get_single.assert_called_once_with(account['_id'], {'stripe.subscription.id': 1})
            stripe_service().cancel_subscription.asset_called_once_with(account['stripe']['subscription']['id'])
            account_repository().patch.assert_called_once_with(
                account['_id'], account_update, AuthHeaderUsername.GIVEWITH.value)
            assert response.status_code == 200
            assert not response.json

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete_404(self, client, test_delete_init, test_delete_request_json, custom_auth_header):
        # arrange
        account_repository().get_single.return_value = None
        account, get_validated_account_id_mock, account_update = test_delete_init

        with client:
            # act
            response = client.delete('/stripe/subscription', json=test_delete_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(account['_id'], request)
            account_repository().get_single.assert_called_once_with(account['_id'], {'stripe.subscription.id': 1})
            stripe_service().cancel_subscription.assert_not_called()
            account_repository().patch.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'Account not found'}
