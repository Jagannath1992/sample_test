import pandas as pd

from typing import Dict, List, Tuple

from portal.shared import dates
from portal.shared.enums import OrderStatus
from portal.shared.repositories import account_repository, cause_area_repository, instance_settings_repository, order_repository, user_repository
from portal.shared.email.service import EmailService


class OrderService:

    def __init__(self, email_service: EmailService):
        self.email_service = email_service

    def timestamp_comments(self, order: Dict, username: str, order_id: str):
        old_status = order_repository().get_single(order_id).get('status')
        new_status = order.get('status')
        if not order.get('comments'):
            order['comments'] = [{'comment': f'Save as {new_status}'}]
        timestamp = dates.get_utcnow()
        for comment in order['comments']:
            comment['timestamp'] = timestamp
            comment['user'] = username
            comment['oldStatus'] = old_status
            comment['newStatus'] = new_status
        return order

    def send_notifications(self, order):
        account = account_repository().get_single(order['account']['_id'], {'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance = instance_settings_repository().get_single(account['instance']['_id'])
        status = order['status']
        if status == OrderStatus.PENDING_APPROVAL.value:
            self.email_service.send_give_submitted_for_approval_email(instance, order)
        elif status == OrderStatus.APPROVED.value:
            cause_area = cause_area_repository().get_single(order['causeArea']['_id'], {'tooltip': 1})
            self.email_service.send_give_approved_email(instance, order, account, cause_area)
        elif status == OrderStatus.DENIED.value:
            self.email_service.send_give_denied_email(instance, order)
        elif status == OrderStatus.FINANCIAL_HOLD.value:
            self.email_service.send_give_financial_hold_email(instance, order, account)
        elif status == OrderStatus.COMPLETED.value:
            cause_area = cause_area_repository().get_single(order['causeArea']['_id'], {'tooltip': 1, 'detailImageName': 1})
            self.email_service.send_give_completed_won_email(instance, order, account, cause_area)
        elif status == OrderStatus.ABANDONED.value:
            self.email_service.send_give_abandoned_lost_email(instance, order)

    def get_filename(self, filters: dict, filename: str) -> str:
        last_updated = filters.get('lastUpdated', {})

        date_from = last_updated.get('$gte')
        if date_from:
            filename += f"_{date_from.date()}"

        date_to = last_updated.get('$lte')
        if date_to:
            filename += f"_{date_to.date()}"

        return f'{filename}.csv'

    def flatten_metrics(self, results: List[dict]):
        # flatten key
        data = [{**r.pop('_id'), **r} for r in results]
        # flatten counts
        data = [{**r, **d} for r in data for d in r.pop('details', [{}])]

        dataFrame = pd.DataFrame(data)
        return dataFrame

    def get_metrics(self, filters: dict, overview: bool, account: bool, completed_only: bool = False) -> Tuple[List[dict], List[dict]]:
        # get metrics grouped by account, cause area, or fully aggregated for overview
        group_by = self._get_metrics_group_by(False, overview, account)
        if account:
            results = order_repository().get_metrics(filters, group_by, completed_only)
        elif not overview:
            results = order_repository().get_metrics_by_cause_area(filters, group_by, completed_only)

        if account:
            # calculate overall participation (registered/invited)
            invites = user_repository().get_invited_users(filters['sharedWith._id'])
            _calculate_overall_participation(results, invites)

        # retrieve unique list of currencies found in results
        currencies = self._get_currency_list(results)

        return results, currencies

    def get_summary(self, results: list, details=False):
        total_count = len(results)
        total_give_amount = 0
        avg_give_percent = 0
        participation = 0
        for result in results:
            total_give_amount += result['totalGiveAmount']
            avg_give_percent += result['avgGivePercent'] / total_count
            participation += result['participation'] / total_count

        summary = {
            "totalGiveAmount": round(total_give_amount, 2),
            "avgGivePercent": round(avg_give_percent, 2),
            "participation": round(participation, 2)
        }

        return summary

    def _get_metrics_group_by(self, status: bool, overview: bool, account: bool) -> dict:
        group_by = {}

        if account:
            group_by.update({'account': '$account.name'})

        elif not overview:
            group_by.update({'causeArea': '$causeArea.name'})

        if status:
            group_by.update({'status': '$status'})

        # always group by currency
        group_by.update({'currency': '$currency', 'currencySymbol': '$loc.settings.symbol'})

        return group_by

    def _get_win_rate_group_by(self, overview: bool, account: bool):
        group_by_status = {}
        group_by_currency = {}

        if account:
            group_by_status.update({'account': '$account.name'})
            group_by_currency.update({'account': '$_id.account'})

        elif not overview:
            group_by_status.update({'causeArea': '$causeArea.name'})
            group_by_currency.update({'causeArea': '$_id.causeArea'})

        group_by_status.update({'status': '$comments.newStatus', 'currency': '$currency'})
        group_by_currency.update({'currency': '$_id.currency'})

        return [group_by_status, group_by_currency]

    def _get_most_gives_group_by(self, overview: bool, account: bool):
        group_by_user = {}
        group_by_status = {}

        if account:
            group_by_user.update({'account': '$account.name'})
            group_by_status.update({'account': '$_id.account'})

        elif not overview:
            group_by_user.update({'causeArea': '$causeArea.name'})
            group_by_status.update({'causeArea': '$_id.causeArea'})

        group_by_user.update({'createdBy': '$createdBy', 'status': '$comments.newStatus', 'currency': '$currency'})
        group_by_status.update({'status': '$_id.status', 'currency': '$_id.currency'})

        return [group_by_user, group_by_status]

    def _get_currency_list(self, results: dict) -> List[dict]:
        currencies = []
        currency_names = []

        for result in results:
            currency = result['_id']['currency']
            symbol = result['_id']['currencySymbol']

            if currency not in currency_names:
                currency_names.append(currency)
                currencies.append({
                    'currency': currency,
                    'symbol': symbol
                })

        currencies.sort(key=lambda c: c['currency'])
        return currencies


def _populate_result_details(results: list, results_by_status: list, overview: bool, account: bool):
    detail_fields = ['count', 'totalDealAmount', 'totalGiveAmount']
    exclude_overview_fields = ['impact', 'impactMeasurement']
    round_fields = ['totalDealAmount', 'avgDealAmount', 'totalGiveAmount', 'avgGiveAmount', 'avgGivePercent', 'participation']

    # ensure all cause areas are present in results
    if not overview:
        for status in results_by_status:
            found = False
            for result in results:
                if _is_match(result, status, overview, account):
                    found = True
                    break
            if not found:
                results.append({'_id': status['_id']})

    # loop thru metrics results, overview will only contain single element (per currency)
    for result in results:
        details = list()
        result['details'] = details

        # loop thru metrics grouped by status
        for status in results_by_status:
            # ensure result and details always match on currency
            if _is_match(result, status, overview, account):
                # map status metrics into detail model
                detail = {field: status[field] for field in detail_fields}
                detail['status'] = status['_id']['status']
                # round values to 2 decimal places
                _round(detail, round_fields)
                details.append(detail)

        # remove fields aggregated by status
        for field in detail_fields:
            if field in result:
                result.pop(field)
        # remove fields not needed for overview
        if overview:
            for field in exclude_overview_fields:
                if field in result:
                    result.pop(field)

        # round values to 2 decimal places
        _round(result, round_fields)


def _calculate_win_rate(results: list, results_by_status: list, overview: bool, account: bool):
    # result is for each cause area and holds a list counts for each status
    for status in results_by_status:
        approved = 0
        completed = 0
        financial_hold = 0
        for count in status['counts']:
            # get approved and completed count for a cause area
            if count['status'] == OrderStatus.APPROVED.value:
                approved = count['count']
            if count['status'] == OrderStatus.COMPLETED.value:
                completed = count['count']
            if count['status'] == OrderStatus.FINANCIAL_HOLD.value:
                financial_hold = count['count']
        if approved and (completed or financial_hold):
            for result in results:
                if _is_match(result, status, overview, account):
                    # set the win rate for the cause area
                    result['winRate'] = round(((completed+financial_hold)/approved)*100, 2)


def _populate_most_gives(results: list, results_by_status: list, overview: bool, account: bool):
    for status in results_by_status:
        for result in results:
            if _is_match(result, status, overview, account):
                for detail in result['details']:
                    if detail['status'] == status['_id']['status']:
                        detail['mostGives'] = status['counts']['createdBy']


def _calculate_total_give_percent_by_status(results: list):
    totals = {}
    for result in results:
        for details in result['details']:
            details['totalGivePercent'] = 0
            totals .update({details['status']: totals.get(
                details['status'], 0) + details['totalGiveAmount']})

    for result in results:
        for details in result['details']:
            details['totalGivePercent'] = round(details['totalGiveAmount'] / totals[details['status']] * 100, 2)


def _calculate_overall_participation(results: list, invites: list):
    for result in results:
        name = result['_id']['account']
        result['participation'] = 0
        invited = 0
        active = 0

        for invite in invites:
            if invite['account']['company']['name'] == name:
                invited = invited + 1
                if invite['active']:
                    active = active + 1

        if invited and active:
            result['participation'] = round(((active/invited) * 100),2)


def _is_match(result: dict, status: dict, overview: bool, account: bool) -> bool:
    '''
    If the request is for overview, then match on currency.
    If the request is for detail, then make sure both currency and cause area match.
    If the request is for account, then make sure both currency and account match.
    '''
    if result['_id']['currency'] != status['_id']['currency']:
        return False

    if account:
        return result['_id']['account'] == status['_id']['account']

    elif not overview:
        return result['_id']['causeArea'] == status['_id']['causeArea']

    return True


def _round(result: dict, fields: List[str]):
    for field in fields:
        if field in result:
            result[field] = round(result[field], 2)
