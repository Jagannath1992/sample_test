# pylint: disable=redefined-outer-name
import pytest
import jwt
from os import environ
from matchmaking import create_app, auth, utils
from pymongo import MongoClient
from datetime import datetime, timedelta
from bson import ObjectId

TOKEN_PRIVATE_KEY='Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl' \
                  '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9'

@pytest.fixture(scope='session')
def client(test_db):
    app = create_app(test_db)
    client = app.test_client()

    load_test_data(test_db)

    ctx = app.app_context()
    ctx.push()

    yield client
    ctx.pop()


@pytest.fixture(scope='session')
def test_db():
    test_db_url = environ.get('TEST_DB_URL', 'mongodb://localhost:27017/')
    db_client = MongoClient(test_db_url)

    db = db_client['test_db']
    load_init_data(db)

    yield db
    db_client.drop_database('test_db')


@pytest.fixture(scope='session')
def admin_token():
    now = datetime.now().timestamp()
    hour_later = (datetime.now() + timedelta(hours=1)).timestamp()

    claims = {
        'sub': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017',
        'event_id': '6e27b2d2-9b8d-425d-9c63-a060f512db5d',
        'token_use': 'access',
        'scope': 'admin',
        'auth_time': now,
        'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
        'exp': hour_later,
        'jti': 'b81e150e-4303-4663-ad46-c87adab94d63',
        'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
        'username': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017', # must match with user cognito id
        'resource_ids': [
            '5c1415685b03bb0008c21b06'
        ],
        'version': 1,
        'user_id': '5d1a713205944281edb3eec5',
        'email': 'shanyan.jiang@givewith.com',
        '_id': '5d1a713205944281edb3eec5',
        'name': 'Shanyan Jiang',
        'uuid': '6e7223d4-65d4-45a2-a5de-742d77c08e2b',
        'cognito-id': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017',
        'firstname': 'Shanyan',
        'lastname': 'Jiang',
        'active': True,
        'type': 'admin',
        'orgType': 'brand',
        'orgId': '5c1415685b03bb0008c21adf',
        'last_login': 'Mon, 18 May 2020 17:14:22 GMT',
        'first_name': 'Shanyan',
        'last_name': 'Jiang',
        'title': 'Dev',
        'departmentName': 'Department of motor vehicle',
        'departmentType': 'Other'
    }
    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture(scope='session')
def client_token():
    now = datetime.now().timestamp()
    hour_later = (datetime.now() + timedelta(hours=1)).timestamp()

    claims = {
        'email': 'shanyan.jiang@givewith.com',
        'sub': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017',
        'event_id': '6e27b2d2-9b8d-425d-9c63-a060f512db5d',
        'token_use': 'access',
        'scope': 'impact',
        'auth_time': now,
        'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
        'exp': hour_later,
        'jti': 'b81e150e-4303-4663-ad46-c87adab94d63',
        'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
        'username': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017', # must match with user cognito id
        'orgId': '5c1415685b03bb0008c21adf',
        'resource_ids': [
            '5c1415685b03bb0008c21b06'
        ]
    }
    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')

@pytest.fixture(scope='session')
def executive_client_token():
    now = datetime.now().timestamp()
    hour_later = (datetime.now() + timedelta(hours=1)).timestamp()

    claims = {
        'email': 'shanyan.jiang@givewith.com',
        'sub': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017',
        'event_id': '6e27b2d2-9b8d-425d-9c63-a060f512db5d',
        'token_use': 'access',
        'scope': 'impact',
        'auth_time': now,
        'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
        'exp': hour_later,
        'jti': 'b81e150e-4303-4663-ad46-c87adab94d63',
        'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
        'username': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017', # must match with user cognito id
        'resource_ids': [
            '5c1415685b03bb0008c21b06'
        ],
        'departmentType': 'Executive',
        'user_id': '5d1a713205944281edb3eec5',
        'orgType': 'brand',
        'orgId': '5c1415685b03bb0008c21adf',
    }
    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture(scope='session')
def nonprofit_token():
    now = datetime.now().timestamp()
    hour_later = (datetime.now() + timedelta(hours=1)).timestamp()

    claims = {
        'email': 'shanyan.jiang@givewith.com',
        'sub': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017',
        'event_id': '6e27b2d2-9b8d-425d-9c63-a060f512db5d',
        'token_use': 'access',
        'scope': 'psf',
        'auth_time': now,
        'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
        'exp': hour_later,
        'jti': 'b81e150e-4303-4663-ad46-c87adab94d63',
        'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
        'username': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017', # must match with user cognito id
        'orgId': '5c1415685b03bb0008c21adf',
        'resource_ids': [
            '5c1415685b03bb0008c21b06'
        ]
    }
    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture(scope='session')
def supplier_analysis_report_token(test_db):
    hour_later = (datetime.utcnow() + timedelta(hours=1)).strftime(utils.DATETIME_FORMAT)

    sample_report = test_db.supplier_analysis_reports.find_one({})
    password, slug = sample_report['password'], sample_report['slug']
    token = auth.create_token(f'{password}/password', slug, hour_later)

    return token


@pytest.fixture()
def admin_header(admin_token):
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': admin_token,
    }


@pytest.fixture()
def client_header(client_token):
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': client_token,
    }

@pytest.fixture()
def executive_client_header(executive_client_token):
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': executive_client_token,
    }

@pytest.fixture()
def nonprofit_header(nonprofit_token):
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': nonprofit_token,
    }


@pytest.fixture()
def invalid_header():
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'aaa.bbb.ccc',
    }


@pytest.fixture(scope='session')
def default_header():
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    }

@pytest.fixture()
def supplier_analysis_report_header(default_header, supplier_analysis_report_token):
    return {
        **default_header,
        'Authorization': supplier_analysis_report_token
    }


@pytest.fixture()
def supplier_analysis_report_header(default_header, supplier_analysis_report_token):
    return {
        **default_header,
        'Authorization': supplier_analysis_report_token
    }


@pytest.fixture(scope='function')
def user_id(test_db):
    return test_db.user.find_one({}).get('_id')


@pytest.fixture(scope='function')
def brand_id(test_db):
    return test_db.mm_brands.find_one({}).get('_id')


@pytest.fixture(scope='function')
def program_id(test_db):
    return test_db.mm_programs.find_one({}).get('_id')


@pytest.fixture(scope='function')
def nonprofit_id(test_db):
    return test_db.mm_nonprofits.find_one({}).get('_id')


@pytest.fixture(scope='function')
def test_deal(program_id, user_id, test_db, brand_id):
    return {
        '_id': '5dcdb2b6b0ef22fbd86d27b8',
        'name': 'program test',
        'givewithCustomer': brand_id,
        'client': brand_id,
        'totalBudget': 550000.0,
        'fundingAmount': 19250.0,
        'givewithPortion': 27500.0,
        'givewithCustomerUser': '5d9babeba70b4d08e4081d4d',
        'givewithCustomerEmails': [
            'test-customer@givewith.com'
        ],
        'createdAt': '2019-11-06T20:45:30.364Z',
        'lastUpdated': '2019-11-06T20:46:40.334Z',
        'reference': 1463.0,
        'slug': 'bn2dhUipq0lJ93c',
        'password': 'xq6zqWn5h0fj',
        'status': 'PAYMENT_PENDING',
        'givewithCustomerRole': 'buyer',
        'isValid': True,
        'selectedRecommendedPrograms': [
            {
                '_id': '5c387b71a08c41000a179495',
                'name': 'PGRM',
                'nonprofit': '5c387a30a08c41000a17947f',
                'match': 100,
                'matchType': 'MATCH',
                'customerPreferred': False,
                'nonprofitName': 'Girls Who Code Inc'
            },
        ],
        'selectedProgram': program_id,
        'selectedProgramMeta': {
            'selectedAt': '2019-11-06T20:46:20.463Z'
        },
        'programName': 'Advance education for girls in Pakistan',
        'contact': {
            'name': 'CARLA',
            'role': 'TEST',
            'email': 'test-contact@givewith.com',
            'phoneNumber': ''
        },
        'statusUpdatedAt': '2019-11-06T20:46:40.334Z',
        'clientEmails': [
            'test-client@givewith.com'
        ],
        'altLicensingClient': 'some sample termsaDasd tes',
        'altLicensingGivewithCustomer': 'some sample termsaDasd tes',
        'confirmation': {
            'confirmedAt': '2019-11-06T20:46:40.334Z',
            'confirmedBy': user_id
        },
        'deliverables': {
            'client': {
                'longVideo': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/client/duck_1557781030992.png',
                'photoGallery': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/client/heber-galindo-1567018-unsplash-min_1557775084753.jpg',
                'investorCommunications': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/client/GW_PLATFORM_HEADER_01_1558105863242.jpg',
                'pressRelease': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/client/Image_from_iOS_1558105899804.jpg'
            },
            'givewithCustomer': {
                'longVideo': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/givewithcustomer/duck_1557781030992.png',
                'photoGallery': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/givewithcustomer/heber-galindo-1567018-unsplash-min_1557775084753.jpg',
                'investorCommunications': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/givewithcustomer/GW_PLATFORM_HEADER_01_1558105863242.jpg',
                'pressRelease': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/deals/5dc330ebbbce2052093b167a/givewithcustomer/Image_from_iOS_1558105899804.jpg'
            }
        },
        'expectedClientToConfirm': {
            'email': 'test-confirm@givewith.com'
        }
    }


def load_init_data(db):
    """
    add data required for migration
    """
    db.mm_vocabulary.insert_one({
        "type": "approach",
        "label": "Enhance land management and/or protection",
        "versions": [
            2
        ],
        "category": "environmental",
        "value": 0
    })

    db.mm_vocabulary.insert_many([
        {
            'type': 'industry',
            'code': '30202030',
            'label': 'Packaged Foods & Meats',
            'description': ('Producers of packaged foods including dairy products, fruit juices, '
                            'meats, poultry, fish and pet foods.'),
            'versions': [1, 2]
        },
        {
            'type' : 'industry',
            'code' : '20101010',
            'label' : 'Aerospace & Defense',
            'description' : ('Manufacturers of civil or military aerospace and defense equipment,'
                             'parts or products. Includes defense electronics and space equipment.'),
            'versions' : [1, 2]
        }
    ])

    db.gics_weights.insert_one({
        'dataframe' : '{\"Aging populations\":{\"Aerospace & Defense\":0}}',
        'type' : 'raw',
    })

    db.forex.insert_one({
        'base': 'USD',
        'rates': {
            'GBP': 0.8145572554,
            'EUR': 0.9272137228,
            'USD': 1.0
        },
        'date': '2023-04-24',
        'desc': 'desc'
    })

    nonprofit = {
        'description': 'test description',
        'impacts': [
            {
                'label': 'polio vaccines',
                'value': 23000000.0
            },
            {
                'label': 'measles vaccines',
                'value': 33000000.0
            },
            {
                'label': 'pneumonia vaccines',
                'value': 127000.0
            }
        ],
        'isValid': True,
        'lastUpdated': '2018-12-20T15:56:15.150Z',
        'name': 'Testt@Life@init',
        'slug': 'shot-slug-init',
        'url': 'http://shotatlife.org',
        'tax_id': '58-2368165',
        'createdAt': '2018-08-29T01:59:17.098Z',
        'registeredCountry': 'Test Country',
        'isValid': False,
    }
    db.mm_nonprofits.insert_one(nonprofit)


def load_test_data(db):
    """
    add data required for tests
    """
    topic = db.mm_vocabulary.insert_one({
        'type': 'audience',
        'label': 'Education-1',
        'versions': [2]
    })

    topic_id = topic.inserted_id
    result = db.mm_brands.insert_one({
        'name': 'SPARTON CORPORATION',
        'iname': 'sparton corporation',
        'searchString': 'spartan corporation',
        'slug': 'spa-sparton-corporation',
        'source': 'MSCI',
        'industry': 'Aerospace & Defense',
        "givePercentageType" : "default",
        'msci': {
            'msciId': 'SPA',
            'issuerName': 'SPARTON CORPORATION',
            'industry': 'Aerospace & Defense',
            'weights': {
                'accessToCommunications': 0.0,
                'accessToFinance': 0.0,
                'carbonEmissions': 0.0,
                'climateChangeVulnerability': 0.0,
                'humanCapitalDevelopment': 0.0,
                'responsibleInvestment': 0.0
            },
            'quartile': {
                'accessToCommunications': 0.0,
                'accessToFinance': 0.0,
                'carbonEmissions': 0.0,
                'climateChangeVulnerability': 0.0,
                'humanCapitalDevelopment': 0.0,
                'responsibleInvestment': 0.0
            },
            'score': {
                'accessToCommunications': 0.0,
                'accessToFinance': 0.0,
                'carbonEmissions': 0.0,
                'climateChangeVulnerability': 0.0,
                'humanCapitalDevelopment': 0.0,
                'responsibleInvestment': 0.0
            }
        },
        'topics': [
            {'label' : 'Education', 'score' : 25, 'topic' : topic_id}
        ],
        'preferredPrograms': {
            'editing': False,
            'password': 'password',
            'cart': [],
            'selected': [],
            'additional': []
        }
    })

    brand_id = result.inserted_id
    result = db.user.insert_one({
        'name': 'Shanyan Jiang',
        'uuid': '6e7223d4-65d4-45a2-a5de-742d77c08e2b',
        'username': 'shanyan.jiang@givewith.com',
        'cognito-id': 'ada757d2-f4c9-416f-9c2b-ccbd94ef3017',
        'password': '654a85208fc81a94be07e12ca980d8b1071fa9fed3d6525957d3bd5a896cc7aa',
        'firstname': 'Shanyan',
        'lastname': 'Jiang',
        'active': True,
        'type': 'admin',
        'orgType': 'brand',
        'orgId': brand_id,
        'first_name': 'Shanyan',
        'last_name': 'Jiang',
        'title': 'Dev',
        'departmentName': 'Department of motor vehicle',
        'departmentType': 'Other'
    })

    user_id = result.inserted_id
    db.deals.insert_one({
        'fundingAmount' : 7000,
        'givewithCustomerUser' : '5cb0a76b28386f7c5d65c9de',
        'name' : 'deal name',
        'password' : 'OhAL94Eh0T3E',
        'slug' : 'Sp10m84lSU93ZgU',
        'status' : 'PROGRAM_SELECTION_PENDING',
        'totalBudget' : 500000,
        'reference' : 364.0,
        'givewithCustomerRole' : 'supplier',
        'managerName' : 'Elizabeth Chan',
        'currency': 'USD',
        'manager' : user_id,
        'selectedRecommendedPrograms' : [
            {
                'registeredCountry': ''
            }
        ],
        'isValid' : True,
        'clientEmails' : [],
        'givewithCustomerEmails' : [
            'test-customer@givewith.com'
        ],
        'givewithCustomer': brand_id,
        'client': brand_id,
        'archived': True,
        'givewithPortion': 10000.0,
        'statusUpdatedAt': datetime.strptime('2019-09-13 19:33:56.636Z', '%Y-%m-%d %H:%M:%S.%fZ')
    })

    nonprofit ={
        'name': 'Metropolitan Museum of Art',
        'slug': 'Metropolitan Museum of Art',
        "general": {
            "name": {
                "legalOrganizationName": "Metropolitan Museum of Art",
                "publicOrganizationName": "Metropolitan Museum of Art",
            },
            "social": {
                "websiteURL": "https://www.planusa.org",
                "facebook": "https://www.facebook.com/planusa",
                "instagram": "https://www.instagram.com/plan_usa/",
                "twitter": "https://twitter.com/PlanUSA",
                "linkedIn": "https://www.linkedin.com/company/plan-usa",
            },
            "contact": {
                "name": "alice",
                "professionalTitle": "manager",
                "email": "alice@email.com",
                "phone": "111-222-333",
            },
            "location": {
                "generalLocation": "United States",
                "specificLocation": "Plan International USA, 155 Plan Way, Warwick, RI 02886",
                "taxId": "111-11-111",
                "w9": {
                    'name': '',
                    'url': ''
                },
                "charityNumber": "TODO",
                "companyHouseNumber": "155",
                "otherId": "",
            },
            "missionAgreement": False,
        },
        "overviewAndMission": {
            "historyDescription": "Plan International USA was originally incorporated as Foster Parents Plan, Inc.",
            "problemDescription": "Returning from a recent congressional delegation to El Salvador.",
            "causeAreas": ["TODO", "TODD"],
            "initiativesDescription": "TODO",
            "programLocations": "Warwick",
            "researchAndEvaluation": "TODO",
            "researchAndEvaluationFile": {
                'name': '',
                'url': ''
            },
            "lifetimeOutputs": [
                {
                    "output": "TODO",
                    "outputNumber": 1,
                }
            ],
        },
        "operationalInformation": {
            "staff": {
                "fullTime": 10,
                "partTime": 15,
                "volunteers": 20,
            },
            "partnershipsDescription": "description",
            "yearlyBudget": 1,
            "financialStatement": {
                'website': '',
                'file' :{
                    "url": "https://www.planusa.org/financial",
                    "name": "s3:link/plan-usa",
                }
            },
            "supportersAndPartners": "TODO",
        },
        "review": {
            "name": "alice",
            "email": "alice@planusa.com",
            "agreement": True,
        },
        'isValid': True,
    }

    result = db.mm_nonprofits.insert_one(nonprofit)
    nonprofit_id = result.inserted_id

    db.mm_vocabulary.insert_one({
        'type': 'approach',
        'label': 'Develop skills to secure employment, housing and financial stability',
        'category': 'participant',
        'value': 900,
        'versions': [
            1
        ]
    })

    db.mm_vocabulary.insert_one({
        'type': 'approach',
        'label': 'Preserve wildlife',
        'category': 'environmental',
        'value': 0,
        'versions': [
            1
        ]
    })

    db.survey_data.insert_one({
        "vocabularyExtensions" : {
            "impact" : {
                "5d44b3b4d5b3a55e9e513ce5" : {
                    "label" : "Enhance physical community infrastructure",
                    "tooltip" : "This program enhances infrastructure, such as bridges, roads, community centers, and schools.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5a99921742073d0946344036" : {
                    "label" : "Reduce hunger and malnutrition",
                    "tooltip" : "This program directly provides food to people for survival.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5a99921742073d0946344037" : {
                    "label" : "Increase access to nutritious food",
                    "tooltip" : "This program provides accessibility that leads to improved nutrition and health.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5a99921742073d0946344038" : {
                    "label" : "Increase sustainable food systems",
                    "tooltip" : "This program enhances the food system to increase accessibility, affordability, and sustainability.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5aec61bff581061865110cb2" : {
                    "label" : "Increase sustainable water systems",
                    "tooltip" : "This program enhances the water system to increase accessibility, affordability, and sustainability.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5a99921742073d094634403b" : {
                    "label" : "Achieve equality/eliminate discrimination",
                    "tooltip" : "This program increases opportunities for marginalized populations, advances human rights, or provides sensitivity training.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5a99921742073d0946344028" : {
                    "label" : "Increase appreciation and support for the arts",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cc9")
                },
                "5a99921742073d094634402a" : {
                    "label" : "Reduce criminal recidivism",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cca")
                },
                "5a99921742073d0946344029" : {
                    "label" : "Reduce criminal activity",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cca")
                },
                "5a99921742073d094634402c" : {
                    "label" : "Increase access to and acquire employment",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5a99921742073d094634402b" : {
                    "label" : "Achieve financial stability",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5a99921742073d094634402d" : {
                    "label" : "Promote economic growth",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5a99921742073d094634402f" : {
                    "label" : "Ensure 21st Century skills proficiency",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5aec61bff581061865110ca6" : {
                    "label" : "Improve academic achievement",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5a99921742073d0946344030" : {
                    "label" : "Increase access to quality education programs and services",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513ced" : {
                    "label" : "Increase recycling and/or reduce waste",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5a99921742073d0946344033" : {
                    "label" : "Increase understanding of and commitment to reducing climate change",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513ce9" : {
                    "label" : "Increase protection of public lands",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513ce6" : {
                    "label" : "Reduce carbon and greenhouse gas impact",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513cea" : {
                    "label" : "Increase protection of public waters",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5aec61bff581061865110ca7" : {
                    "label" : "Improve air quality",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5aec61bff581061865110cb6" : {
                    "label" : "Protect animal welfare",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513ceb" : {
                    "label" : "Protect endangered, vulnerable, or threatened species",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513ce8" : {
                    "label" : "Increase access to potable water",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5a99921742073d0946344039" : {
                    "label" : "Reduce homelessness",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccd")
                },
                "5a99921742073d094634403a" : {
                    "label" : "Increase amount and access to quality affordable housing",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccd")
                },
                "5a99921742073d094634403d" : {
                    "label" : "Increase peace through conflict resolution",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5d44b3b4d5b3a55e9e513ce7" : {
                    "label" : "Increase civic participation",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5a99921742073d0946344040" : {
                    "label" : "Improve reproductive health",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5a99921742073d094634403f" : {
                    "label" : "Increase access to quality, affordable healthcare and services",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5a99921742073d0946344042" : {
                    "label" : "Reduce trauma",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5a99921742073d094634403e" : {
                    "label" : "Reduce disease/improve health",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5a99921742073d0946344041" : {
                    "label" : "Reduce risky and addictive behaviors",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513cec" : {
                    "label" : "Improve conditions after natural disasters and crises",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cd0")
                }
            },
            "programApproach" : {
                "5af49c75a64082a02a943c0a" : {
                    "label" : "Transactional (purchase a product; pay for a service)",
                    "tooltip" : "Examples include providing a product or service, or distributing goods."
                },
                "5af49c75a64082a02a943c0b" : {
                    "label" : "Increasing awareness (advocate; lobby)",
                    "tooltip" : "Examples include advocacy work, lobbying, and awareness campaigns."
                },
                "5af49c75a64082a02a943c0c" : {
                    "label" : "Building capacity (strengthen institutions, programs or systems)",
                    "tooltip" : "Examples include training or mentoring."
                },
                "5af49c75a64082a02a943c0d" : {
                    "label" : "Changing behavior (train; mentor)",
                    "tooltip" : "Examples include strengthening institutions, programs or systems to ensure long-term sustainability."
                },
                "5af49c75a64082a02a943c0e" : {
                    "label" : "Research",
                    "tooltip" : "Examples include conducting or funding research."
                }
            },
            "approach" : {
                "5d44b3b4d5b3a55e9e513d0f" : {
                    "label" : "Promote business and enterprise development",
                    "tooltip" : "This program provides increased access to capital for those looking to create small businesses.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513d10" : {
                    "label" : "Promote job creation",
                    "tooltip" : "This program provides economic development opportunities.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513d04" : {
                    "label" : "Enhance water management and/or protection",
                    "tooltip" : "This program improves water quality for drinking OR protects waterways from pollution",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513cfd" : {
                    "label" : "Enhance land management and/or protection",
                    "tooltip" : "This program protects land through sustainable land management practices.",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513cf4" : {
                    "label" : "Provide potable water",
                    "tooltip" : "This program provides drinkable water or access to drinkable water.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5d44b3b4d5b3a55e9e513cf2" : {
                    "label" : "Provide affordable housing",
                    "tooltip" : "This program provides access to affordable housing for low-income populations through financial assistance or long-term low-cost housing.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccd")
                },
                "5d44b3b4d5b3a55e9e513cf7" : {
                    "label" : "Provide temporary housing",
                    "tooltip" : "This program provides temporary housing to beneficiaries in emergencies.",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccd")
                },
                "5d44b3b4d5b3a55e9e513d02" : {
                    "label" : "Enhance support for and/or access to the arts",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cc9")
                },
                "5d44b3b4d5b3a55e9e513cf3" : {
                    "label" : "Provide arts education",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cc9")
                },
                "5d44b3b4d5b3a55e9e513cf8" : {
                    "label" : "Provide transitional programs and services",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cca")
                },
                "5d44b3b4d5b3a55e9e513d00" : {
                    "label" : "Enhance skills for self sufficiency",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513d1c" : {
                    "label" : "Provide support programs to maintain employment, housing, financial stability, and physical and mental health",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513d16" : {
                    "label" : "Provide job/career readiness training",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513cf6" : {
                    "label" : "Provide technology and connectivity",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513cf9" : {
                    "label" : "Develop financial literacy and financial resilience",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513cfc" : {
                    "label" : "Develop skills to secure employment, housing and financial stability",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513d12" : {
                    "label" : "Provide entrepreneurship training",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513d0c" : {
                    "label" : "Increase job placement/retention services",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccb")
                },
                "5d44b3b4d5b3a55e9e513cff" : {
                    "label" : "Enhance school readiness skills",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d01" : {
                    "label" : "Enhance social and emotional learning and skills",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d07" : {
                    "label" : "Increase access to literacy and numeracy programs",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d1e" : {
                    "label" : "Provide technology literacy training",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d1a" : {
                    "label" : "Provide STEM interest, proficiency and persistence programs",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d15" : {
                    "label" : "Provide high school completion support",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513cee" : {
                    "label" : "Improve academic environments",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d09" : {
                    "label" : "Increase college readiness, access, persistence and completion",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d1d" : {
                    "label" : "Provide teacher effectiveness programs",
                    "causeId" : ObjectId("5a99921742073d0946343fb2")
                },
                "5d44b3b4d5b3a55e9e513d1f" : {
                    "label" : "Reduce greenhouse gases",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d06" : {
                    "label" : "Improve energy efficiency",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513cef" : {
                    "label" : "Improve community environments or spaces",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d0d" : {
                    "label" : "Increase use of renewable energy",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d05" : {
                    "label" : "Implement infrastructure and transportation projects",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d03" : {
                    "label" : "Enhance sustainable agriculture practices and programs",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d08" : {
                    "label" : "Increase animal safety and wellness",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d0e" : {
                    "label" : "Preserve wildlife",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d20" : {
                    "label" : "Reduce pollution/clean or rehabilitate the environment",
                    "causeId" : ObjectId("5a99921742073d0946343fb3")
                },
                "5d44b3b4d5b3a55e9e513d14" : {
                    "label" : "Provide healthy eating behavior and nutrition training",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5d44b3b4d5b3a55e9e513cf5" : {
                    "label" : "Provide sufficient, affordable and nutritious foods",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccc")
                },
                "5d44b3b4d5b3a55e9e513cf0" : {
                    "label" : "Pass legislation",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5d44b3b4d5b3a55e9e513cfb" : {
                    "label" : "Create policy change",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5d44b3b4d5b3a55e9e513cf1" : {
                    "label" : "Preserve traditional cultural practices",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5d44b3b4d5b3a55e9e513cfe" : {
                    "label" : "Enhance legal protections",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513cce")
                },
                "5d44b3b4d5b3a55e9e513d13" : {
                    "label" : "Provide fitness programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d22" : {
                    "label" : "Run patient and family support programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d21" : {
                    "label" : "Run infant health programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513cfa" : {
                    "label" : "Create access to resources and/or public benefits",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d0a" : {
                    "label" : "Increase disease awareness",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d18" : {
                    "label" : "Provide mental health programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d19" : {
                    "label" : "Provide sexual health training and programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d23" : {
                    "label" : "Run patient quality of life programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d1b" : {
                    "label" : "Provide support for substance abuse and addictive behaviors",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d11" : {
                    "label" : "Provide case management",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d0b" : {
                    "label" : "Increase disease research",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                },
                "5d44b3b4d5b3a55e9e513d17" : {
                    "label" : "Provide maternal health programs",
                    "causeId" : ObjectId("5d44b3b4d5b3a55e9e513ccf")
                }
            },
            "approachDuration" : {
                "5d44b3b4d5b3a55e9e513d28" : {
                    "label" : "One-time",
                    "tooltip" : "Examples include events, one day workshops, or one-time engagement."
                },
                "5d44b3b4d5b3a55e9e513d27" : {
                    "label" : "Ongoing",
                    "tooltip" : "Examples include multiple training sessions, year-long mentoring, or weekly after-school programming."
                }
            }
        },
        "questionDependencies" : {
            "protectAndEnhanceForest" : {
                "operation" : "in",
                "path" : "ImpactAndScope.protectAndEnhanceForest.value",
                "keys" : [
                    {
                        "key" : "ImpactAndScope.primaryImpact.value",
                        "operator" : "in",
                        "descriptionSuffix" : "this program's primary targeted impact"
                    },
                    {
                        "key" : "ImpactAndScope.secondaryImpact.value",
                        "operator" : "in",
                        "descriptionSuffix" : "a secondary impact of this program"
                    }
                ],
                "values" : {
                    "5d44b3b4d5b3a55e9e513ce9" : "Increase protection of public lands"
                }
            },
            "animalHabitat" : {
                "operation" : "in",
                "path" : "ImpactAndScope.animalHabitat.value",
                "keys" : [
                    {
                        "key" : "ImpactAndScope.primaryImpact.value",
                        "descriptionSuffix" : "this program's primary targeted impact"
                    },
                    {
                        "key" : "ImpactAndScope.secondaryImpact.value",
                        "descriptionSuffix" : "a secondary impact of this program"
                    }
                ],
                "values" : {
                    "5aec61bff581061865110cb6" : "Protect animal welfare",
                    "5d44b3b4d5b3a55e9e513ceb" : "Protect endangered, vulnerable, or threatened species"
                }
            },
            "countries" : {
                "operation" : "nin",
                "path" : "ImpactAndScope.countries.value",
                "keys" : [
                    {
                        "key" : "ImpactAndScope.regions.value"
                    }
                ],
                "values" : {
                    "N/A" : "N/A"
                }
            },
            "states" : {
                "operation" : "in",
                "path" : "ImpactAndScope.states.value",
                "keys" : [
                    {
                        "key" : "ImpactAndScope.countries.value",
                        "descriptionSuffix" : "a country this program operates from. Please select all that apply"
                    }
                ],
                "values" : {
                    "North America;United States" : "North America;United States",
                    "North America;Canada" : "North America;Canada"
                }
            },
            "cities" : {
                "operation" : "nin",
                "path" : "ImpactAndScope.cities.value",
                "keys" : [
                    {
                        "key" : "ImpactAndScope.countries.value"
                    }
                ],
                "values" : {
                    "N/A" : "N/A"
                }
            },
            "studyDescription" : {
                "operation" : "nin",
                "path" : "ResearchAndEvaluation.studyDescription.value",
                "keys" : [
                    {
                        "key" : "ResearchAndEvaluation.evidenceDescription.value",
                        "descriptionSuffix" : "the description of this program's evidence or data"
                    }
                ],
                "values" : {
                    "N/A" : "N/A"
                }
            },
            "dataDescription" : {
                "operation" : "nin",
                "path" : "ResearchAndEvaluation.dataDescription.value",
                "keys" : [
                    {
                        "key" : "ResearchAndEvaluation.evidenceDescription.value",
                        "descriptionSuffix" : "the description of this program's evidence or data"
                    }
                ],
                "values" : {
                    "N/A" : "N/A"
                }
            },
            "outcomeDescription" : {
                "operation" : "nin",
                "path" : "ResearchAndEvaluation.outcomeDescription.value",
                "keys" : [
                    {
                        "key" : "ResearchAndEvaluation.evidenceDescription.value",
                        "descriptionSuffix" : "the description of this program's evidence or data"
                    }
                ],
                "values" : {
                    "N/A" : "N/A"
                }
            },
            "strength" : {
                "operation" : "nin",
                "path" : "ResearchAndEvaluation.strength.value",
                "keys" : [
                    {
                        "key" : "ResearchAndEvaluation.evidenceDescription.value",
                        "descriptionSuffix" : "the description of this program's evidence or data"
                    }
                ],
                "values" : {
                    "N/A" : "N/A"
                }
            },
            "environmentalOutputs" : {
                "operation" : "in",
                "path" : "ResearchAndEvaluation.environmentalOutputs.value",
                "keys" : [
                    {
                        "key" : "ResearchAndEvaluation.researchApproaches.value"
                    }
                ],
                "values" : {
                    "5d44b3b4d5b3a55e9e513d03" : "Enhance sustainable agriculture practices and programs",
                    "5d44b3b4d5b3a55e9e513d04" : "Enhance water management and/or protection",
                    "5d44b3b4d5b3a55e9e513d06" : "Improve energy efficiency",
                    "5d44b3b4d5b3a55e9e513d0d" : "Increase use of renewable energy",
                    "5d44b3b4d5b3a55e9e513d0e" : "Preserve wildlife",
                    "5d44b3b4d5b3a55e9e513d1f" : "Reduce greenhouse gases",
                    "5d44b3b4d5b3a55e9e513d20" : "Reduce pollution/clean or rehabilitate the environment"
                }
            }
        }
    })

    sa1 = db.mm_vocabulary.find_one({'type': 'approach', 'category': 'participant'})
    sa2 = db.mm_vocabulary.find_one({'type': 'approach', 'category': 'environmental'})
    conversion = db.program_scc_conversion.find_one({})

    program = {
        'active': True,
        'audienceAge': [
            '5a99921742073d0946343f9d',
            '5a99921742073d0946343f9e',
            '5a99921742073d0946343f9f',
            '5a99921742073d0946343fa0',
            '5a99921742073d0946343fa1',
            '5a99921742073d0946343fa2',
        ],
        'audienceAttribute': [
            '5d44b3b4d5b3a55e9e513cd3',
            '5a99921742073d0946343fa9'
        ],
        'budget': 36636.8,
        'causes': [
            '5d44b3b4d5b3a55e9e513cce'
        ],
        'createdAt': '2018-08-29T01:59:17.098Z',
        'dataMeasurementType': '5af48f88a64082a02a943c09',
        'description': 'Parks for Inclusion will remove barriers, both physical and theoretical, so that all people can access and experience the benefits of parks and recreation in their local community.',
        'ignoreThreshold': True,
        'imageLandscape': 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b85fdf5fa8cf800104c3828/fullsizeoutput_a9_1545161929609.jpeg',
        'imagePortrait': 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b85fdf5fa8cf800104c3828/fullsizeoutput_aa_1545161920905.jpeg',
        'impactMultipleVisibility': False,
        'isValid': True,
        'isValidNonprofit': True,
        'lastUpdated': '2019-09-04T14:45:28.236Z',
        'name': 'Remove physical and social barriers to parks and recreation',
        'nonprofit': nonprofit_id,
        'outputs': [
            {
                'quantity': 500,
                'description': 'Hours of inclusive programming provided',
                'scaleType': '5af4a134a64082a02a943c13'
            },
            {
                'quantity': 10,
                'description': 'Park improvement projects completed',
                'scaleType': '5af4a134a64082a02a943c13'
            },
            {
                'quantity': 1000,
                'description': 'Square footage of space improved',
                'scaleType': '5af4a134a64082a02a943c13'
            },
            {
                'quantity': 500,
                'description': 'People served',
                'scaleType': '5af4a134a64082a02a943c13'
            }
        ],
        'primaryImpact': [
            '5a99921742073d094634403b'
        ],
        'programApproach': [
            '5af49c75a64082a02a943c0c'
        ],
        'secondaryImpacts': [
            '5d44b3b4d5b3a55e9e513ce7'
        ],
        'slug': 'parks-for-inclusion-1',
        'cdp': {
            'isCustom': False
        },
        'ImpactAndScope': {
            'protectAndEnhanceForest': {
                'value': False
            }
        },
        'approachDuration': '5d44b3b4d5b3a55e9e513d27',
        'nonprofitPartners': False,
        'approach': [
            {
                '_id': sa1['_id'],
                'evidenceScore': 0.1,
            },
            {
                '_id': sa2['_id'],
                'conversionRateId': conversion['_id'],
                'echoOutput': 0.3593,
            }
        ],
        'participants': 1290,
        'cashContributions': 0,
        'inKindContributions': 0,
        'evidenceDescription': [
            'N/A'
        ],
        'version': 2,
        'csrhub': {
            'strings': [
                'Community Development and Philanthropy',
                'Leadership Ethics'
            ],
            'data': [
                '5cddf7f1f231fc514d9ea7f1',
                '5cddf7f1f231fc514d9ea7f5'
            ],
            'tagging-version': 2
        },
        'sasb': {
            'strings': [
                'Human Rights & Community Relations',
                'Business Ethics'
            ],
            'data': [
                '5ced8752f231fc16de6d16a6',
                '5ced8752f231fc16de6d16a8'
            ],
            'tagging-version': 2
        },
        'themes': {
            'strings': [
                'Diversity and inclusion',
                'Human rights and civic engagement',
                'People with disabilities/disabled persons'
            ],
            'data': [
                '5d44b3b4d5b3a55e9e513cd2',
                '5d44b3b4d5b3a55e9e513ce0',
                '5d44b3b4d5b3a55e9e513cd3'
            ],
            'tagging-version': 2
        },
        'sdg': {
            'strings': [
                'Reduce inequalities',
                'Peace, justice and strong institutions'
            ],
            'data': [
                '5a99921742073d09463440bc',
                '5a99921742073d09463440c2'
            ],
            'tagging-version': 2
        },
        'gri': {
            'strings': [
                'Economic Performance',
                'Infrastructure Investment',
                'Local Community Engagement'
            ],
            'data': [
                '5a99921742073d0946343ffa',
                '5aec6b72344200d826997488',
                '5aec6b72344200d82699748d'
            ],
            'tagging-version': 2
        },
        'esg': {
            'strings': [
                'Responsible Investment'
            ],
            'data': [
                {
                    'issue': '5a99921742073d0946343ff4'
                }
            ],
            'tagging-version': 2
        },
        'givewithAdmin': user_id
    }

    db.mm_programs.insert_one(program)

    db.coll_location_data.insert_one(
        {
        "location_type" : [
            "Global Headquarters",
            "Regional Headquarters",
            "Factory or Industrial Facility",
            "General Operations"
        ],
        "continental_region" : [
            "Europe",
            "Asia",
            "Australia",
            "Africa",
            "North America",
            "South America",
        ],
        "country" : {
            "AD" : "Andorra",
            "AE" : "United Arab Emirates",
            "ZM" : "Zambia",
            "ZW" : "Zimbabwe"
        },
        "regional_territory" : {
            "US" : [
                "Pacific Northwest",
                "Midwest",
                "Northeast",
                "South/Southeast",
                "Southwest",
            ]
        },
        "state" : {
            "US" : [
                "Alabama",
                "Alaska",
                "Arizona",
            ],
            "CA" : [
                "Ontario",
                "British Columbia",
                "Alberta",
                "Nova Scotia"
            ]
        },
        "locationTree" : {
            "continents" : [
                {
                    "name" : "Africa"
                }
            ],
        }
    })

    db.supplier_analysis_reports.insert_one(
        {
            'name': 'Test Report',
            'category': 'non IT',
            'brandId': brand_id,
            'suppliers': [
                brand_id,
                brand_id
            ],
            'slug': 'bWBqn6Pt6HGNc5W',
            'password': '1VcfrOab09vp'
        }
    )
