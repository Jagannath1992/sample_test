import pytest
from bson import ObjectId

from portal.conftest import AuthHeaderUsername
from portal.features.instances.schema import InstanceSettingsRequest, InstanceSettingsResponse, InstanceSettingsSearchResponse
from portal.shared.enums import InstanceStatus, UserRole
from portal.shared.repositories import instance_settings_repository, locale_repository, cause_area_repository, account_repository


class TestInstanceSettingsResource:
    def test_get_all(self, client, givewith_header, mocker, fakers):
        # arrange
        instances = fakers.instance_settings.generate_many(3)
        mocker.patch.object(instance_settings_repository(), 'get_page', return_value=(3, instances))
        expected = InstanceSettingsSearchResponse().dump({
            'totalCount': 3,
            'results': instances
        })
        query_params = {
            'orderBy': 'name',
            'offset': 0,
            'count': 10
        }
        # act
        response = client.get('/instance-settings', query_string=query_params, headers=givewith_header)
        # assert
        assert response.status_code == 200
        assert response.json == expected


class TestInstanceSettingsById:
    @pytest.fixture
    def get_init(self, mocker, fakers):
        settings = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=settings)
        return settings

    def test_get_200_givewith(self, client, givewith_header, get_init):
        # arrange
        settings = get_init

        with client:
            # act
            response = client.get(f'/instance-settings/{settings["_id"]}', headers=givewith_header)
            # assert
            instance_settings_repository().get_single.assert_called_once_with(str(settings['_id']))
            assert response.status_code == 200
            assert response.json == InstanceSettingsResponse().dump(settings)

    def test_patch(self, mocker, fakers, client, givewith_header):
        # arrange
        settings = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=settings)
        request_json = {'settings': {'serviceFee': 0.25}}
        parsed_obj = InstanceSettingsRequest(partial=True).dump(request_json)
        expected_update = {**settings, **parsed_obj}
        mocker.patch.object(instance_settings_repository(), 'patch', return_value=expected_update)
        expected_response = InstanceSettingsResponse().dump(expected_update)

        with client:
            # act
            response = client.patch(f'/instance-settings/{settings["_id"]}', json=request_json, headers=givewith_header)
            # assert
            instance_settings_repository().get_single.assert_called_once_with(str(settings['_id']))
            instance_settings_repository().patch.assert_called_once_with(
                str(settings['_id']), request_json, AuthHeaderUsername.GIVEWITH, set_arrays=True)
            assert response.status_code == 200
            assert response.json == expected_response

    def test_patch_blank_ca_active(self, mocker, fakers, client, givewith_header):
        # arrange
        settings = fakers.instance_settings.generate_single()
        settings['status'] = 'inactive'
        settings.pop('causeAreas')
        mocker.patch.object(instance_settings_repository(), 'exists', return_value=True)
        request_json = {'status': 'active', 'causeAreas': []}
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=settings)
        with client:
            # act
            response = client.patch(f'/instance-settings/{settings["_id"]}', json=request_json, headers=givewith_header)
            # assert
            assert response.json["message"] == 'At least one cause area is required'

    def test_patch_blank_skus_inactive(self, mocker, fakers, client, givewith_header):
        # arrange
        settings = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'exists', return_value=True)
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=settings)
        request_json = {'status': 'inactive', 'skus': []}
        parsed_obj = InstanceSettingsRequest(partial=True).dump(request_json)
        expected_update = {**settings, **parsed_obj}
        mocker.patch.object(instance_settings_repository(), 'patch', return_value=expected_update)
        with client:
            # act
            response = client.patch(f'/instance-settings/{settings["_id"]}', json=request_json, headers=givewith_header)
            # assert
            assert response.status_code == 200
            assert response.json['status'] == 'inactive'

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN], indirect=True)
    def test_patch_permissions_match_account_bad_update(self, mocker, fakers, client, custom_auth_header):
        # arrange
        settings = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=settings)
        account = fakers.account.generate_single({'instance': {
            '_id': ObjectId(settings['_id']),
            '_type': 'instance_settings',
            'name': 'Givewith for Sales',
        }})
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        request_json = {'description': 'hello world', 'restrictedDomains': ['givewith.com']}
        # act
        response = client.patch(f'/instance-settings/{settings["_id"]}', json=request_json, headers=custom_auth_header)
        # assert
        assert response.status_code == 403
        assert response.json['message'] == 'You do not have permission to update this resource'

    def test_put(self, client, givewith_header, fakers, mocker):
        # arrange
        instance = fakers.instance_settings.insert_single()
        request_json = InstanceSettingsRequest().dump(instance)
        updated_name = "new instance name"
        request_json["name"] = updated_name
        mocker.patch.object(locale_repository(), 'exists', return_value=True)
        mocker.patch.object(cause_area_repository(), 'exists', return_value=True)
        # act
        response = client.put(f'/instance-settings/{instance["_id"]}', json=request_json, headers=givewith_header)
        # assert
        assert response.status_code == 200
        assert response.json["name"] == updated_name

    def test_delete(self, client, fakers, givewith_header, mocker):
        # arrange
        instance = fakers.instance_settings.insert_single()
        instance['status'] = InstanceStatus.INACTIVE.value
        mocker.patch.object(instance_settings_repository(), 'exists', return_value=True)
        mocker.patch.object(instance_settings_repository(), 'patch', return_value=instance)
        expected_update = {'status': InstanceStatus.INACTIVE.value}
        # act
        response = client.delete(f'/instance-settings/{instance["_id"]}', headers=givewith_header)
        # assert
        instance_settings_repository().patch.assert_called_once_with(
            str(instance['_id']), expected_update, AuthHeaderUsername.GIVEWITH.value)
        assert response.status_code == 200
        assert response.json['status'] == InstanceStatus.INACTIVE.value
