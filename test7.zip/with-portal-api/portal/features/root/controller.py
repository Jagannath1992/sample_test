from flask import Blueprint, jsonify
from flask_restx import Namespace, Resource, fields

api_bp = Blueprint('api', __name__)
namespace = Namespace('root', description='Root operations')


status_response = namespace.model('StatusResponse', {
    'status': fields.String
})


@namespace.route('')
class Root(Resource):
    @namespace.marshal_with(status_response)
    def get(self):
        return {"status":"ok"}
