from matchmaking import db
from matchmaking.utils import DealStatus

for deal in db().coll_deals.find({'status': 'REQUEST_PENDING'}):
    deal['status'] = str(DealStatus.PROGRAM_SELECTION_PENDING)
    deal['archived'] = True

    db().coll_deals.find_one_and_replace({'_id': deal['_id']}, deal)
