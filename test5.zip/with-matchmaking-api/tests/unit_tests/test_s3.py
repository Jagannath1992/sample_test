from unittest import mock
from matchmaking.s3 import delete_file

def test_delete_file(monkeypatch):
    mock_delete_object = mock.MagicMock()
    mock_delete_object.return_value = {'ResponseMetadata': {'HTTPStatusCode': 204}}
    monkeypatch.setattr('matchmaking.s3.s3.delete_object', mock_delete_object)
    monkeypatch.setattr('matchmaking.s3.PRIVATE_BUCKET_NAME', 'private_bucket')

    assert delete_file('test_entity', '_id', 'normal_filename')
    mock_delete_object.assert_called_with(Bucket='private_bucket', Key='test_entity/_id/normal_filename')

    assert delete_file('test_entity', '_id', 'insecure/filename')
    mock_delete_object.assert_called_with(Bucket='private_bucket', Key='test_entity/_id/insecure_filename')
