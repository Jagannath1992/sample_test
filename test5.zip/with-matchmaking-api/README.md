# Givewith Matchmaking/Commerce API


Build Status on Master:
![Build Status](https://codebuild.us-east-1.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiR1NOblh6bzFXdFI2RHU1SUttTllmUkVRMDRFZTVQRzlrUTArYzJGS2dYRDJVTlF2Z21raG9OSW4zTUhlRzUya2hrdVF5MFM3cmhrbHhFZFg1TFN2S0FBPSIsIml2UGFyYW1ldGVyU3BlYyI6ImVGQnhwMEtwR21mOXo1TDIiLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=master)

Now built and deployed via AWS Developer Tools.  Builds occur after every commit (on any branch), and Build/Deploy to staging occurs on commits to the master branch.  Production deploys are available via AWS/CodeDeploy, but not as yet automatic.


### Developing On Staging
> Logs (including python calls to `print`) on staging visible (when ssh'd to the server) via `tail -f /var/log/gunicorn`

> You can also browse/search the logs via [Cloudwatch Logs](https://console.aws.amazon.com/cloudwatch/home?region=us-east-1#logEventViewer:group=gunicorn;stream=mm-api) (staging only)


# Environment Setup for Virtual Environment

1. Install Python3
2. Create a virtualenv and install dependencies:
	python3 -m venv ../matchmaking-venv
	source ../matchmaking-venv/bin/activate
	pip install -r requirements.txt

3. Configure PyCharm to use the virtualenv

# Local Setup and Run

Prerequisites:
Run mongodb with a copy of the givewith_staging collection

1. Install Python3
2. Install Flask
    pip3 install -U Flask
3. Install dependencies
    pip3 install -r requirements.txt
4. Create certificate
    /Applications/Python\ 3.8/Install\ Certificates.command
5. Run with Flask
    FLASK_ENV=development ENV=development FLASK_APP=main.py MONGO_URL=localhost MONGO_DATABASE=givewith_staging flask run -p5051

# Linting

Pylint is configured using a .pylintrc file in the root directory.
To lint, run:
```
pylint matchmaking
```

[Git-lint](https://github.com/sk-/git-lint) is configured in the repo to run pylint on modified lines
only. To lint additions to the codebase only, run:
```
git lint
```

# Linting Git hooks
Linting pre-commit hook is not enabled by default. It will prevent the commit if lint task fails, it is highly recommended that you add it manually by running:
```
ln -s `which pre-commit.git-lint.sh` $PATH_TO_YOUR_REPO/.git/hooks/pre-commit
```

To remove it, run this task:
```
rm $PATH_TO_YOUR_REPO/.git/hooks/pre-commit
```

**NOTE:** There is currently a bug in the pre-commit file which causes it to error out on OSX, please modify the file at
`$PATH_TO_YOUR_REPO/.git/hooks/pre-commit` to look like so (note line 18, + indicates additions and - indicates deletions).

```
 17 git diff-index -z --cached HEAD --name-only --diff-filter=ACMRTUXB |
 18 -xargs --null --no-run-if-empty git lint;
 18 +xargs -0 -L 1 git lint;
 19
 20 if [ "$?" != "0" ]; then
 21   echo "There are some problems with the modified files.";
 22   echo "Fix them before committing or suggest a change to the rules defined in REPO_HOME/.pylintrc";
 23   echo "If it is not possible to fix them all commit with the option --no-verify.";
 24
 25   exit 1;
 26 fi
```

**TROUBLESHOOTING:** In some rare instances, git lint may not be reading the .pylintrc file correctly. In which case, run this command to clear your git lint cache
```
rm -r ~/.git-lint/cache
```

# Install

In order to run this locally install Anaconda Python3 or use "docker-compose up"

# Testing

In the test directory run *pytest*

# API Documentation

## Generating api docs:
```
npm i apidoc
npx apidoc -i matchmaking/ -o apidoc
```

Alternatively, `apidoc` can be install globally (not recommended)
```
npm i -g apidoc
apidoc -i matchmaking -o apidoc
```

Docs are available at apidoc/index.html

# Cryptography

```
mkdir keys
keyczart create --location=keys --purpose=crypt
keyczart addkey --location=keys --status=primary
```

# Email templates

Responsive email templates are done using [MJML](https://mjml.io/documentation/) framework.
Source files are available in `mjml-email-templates/source` directory.
MJML provides Atom and Sublime Text plugins.

You can try it live [here](https://mjml.io/try-it-live/)

## Building email templates

```sh
cd mjml-email-templates
npm install # you need to run this line only for the first time
npm start
```

To update output directory change
`var outputDir = './output'`
in `mjml-email-templates/source/index.js`

# Migrations

1. Write your migration in `/migration`
2. Make sure to name your migration starting with the next sequential number followed by
   underscores. i.e 7_matts_migration.
3. In the `schema_version` collection, make sure there is a single document formatted
   as the following.
   ```
   "_id" : ObjectId("5d0c0c577e31c10036a78c57"),
    "version" : 6,
    "dirty" : false,
    "created_at" : ISODate("2019-06-20T22:44:39.604Z")
   ```
   `version` must be one less than the number in your migration's name.
   `dirty` must be set to false.
4. Restart givewith-matchmaking-api and the migration will run.

**NOTE**: Migrations are run using exec, therefore when importing modules and using them inside a function, the module should be decalred as a global since exec default to using locals, see snippet below
```
from built_in_module import module

def my_function():
    global module
    module.execute()
```

# Access Control (RBAC)
Please see [Confluence wiki entry](https://givewith.atlassian.net/wiki/spaces/GWT/pages/2687467521/Role-Based+Access+Control+RBAC)

# Sorting
example
```
/admin/deals?sort=status asc,slug desc
```
1. there is no default order. asc or desc are required.
2. multiple level of sort should seperate by comma.

# pagination
example
```
/admin/deals?page_num=2&page_size=20
```
1. default page size is 50, default page number is 1.
2. set age_num=0&page_size=0 to retrieve all data.

# filtering
comparison operators:
```
eq	Equal			city eq 'Redmond'
ne	Not equal		city ne 'London'
gt	Greater than		price gt 20
ge	Greater than or equal	price ge 10
lt	Less than		price lt 20
le	Less than or equal	price le 100
```

logical operators:
```
and	Logical and	price le 200 and price gt 3.5
or	Logical or	price le 3.5 or price gt 200
```
Grouping Operators:	
```
( )	Precedence grouping	(priority eq 1 or city eq 'Redmond') and price gt 100
```

Value types supported:
```
number		price le 200
string  	city ne London
date    	date gt 2019-10-27T15:30:10.570000Z
objectId	_id eq 5c3880e2ecacf2000ba6cc93
boolean		valid eq true


note:
single quote will force a string comparison. 
for example:
valid eq 'true' will check if valid == 'true', rather than if valid == True
similarlym, plate-no eq '111' will check if plate-no == '111', rather than plate-no eq 111

```

full example
```
/admin/deals?filter=(status eq PROGRAM_SELECTION_PENDING or status eq PAYMENT_PENDING) and statusUpdatedAt gt 2019-12-12T14:40:14.245000Z&sort=status asc,slug asc&page_num=0&page_size=0
```

# Proxy
endpoints are being proxied:
1. {GET} /admin/brands/search is called by sales-api
2. {POST} /admin/brands is called by sales-api

# More
see docs/
