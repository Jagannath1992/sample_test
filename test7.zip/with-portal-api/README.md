# Givewith Portal API

## Poetry Setup

We are using poetry package management tool for this project. [Full Documentation](https://python-poetry.org/docs/)

To install, run the following cURL command (for MacOS, Linux, or WSL):

```bash
curl -sSL https://raw.githubusercontent.com/python-poetry/poetry/master/get-poetry.py | python
```

You will also need to add poetry to your PATH. Where poetry is installed will depend on your operating system. On Unix it is located at `$HOME/.poetry/bin` and on Windows at `%USERPROFILE%\.local\bin`.

```bash
export PATH="$HOME/.poetry/bin:$PATH"
```

You will probably also want to add this to your .bashrc file (or whatever terminal config you are using) to ensure it is always on the path for new terminal sessions.

### Using Poetry

Poetry is a package management tool for Python. The dependencies for this project are listed in the `pyproject.toml` file and can be installed via the command `poetry install`. Using the `poetry add <package>` command rather than pip will add the new dependency to the toml file, as well as the `poetry.lock` file. Additionally, poetry dependencies will not be added to the global python env.

## Configuration

Configuration is added here to `config/development.yml` and `config/testing.yml` that provides path arguments to the loggers and indicates whether logging should be initialized.

## Database Migrations

This project uses [pymongo-migrate](https://github.com/stxnext/pymongo-migrate) to create and apply database migration scripts for each release.

### Generating a new migration script

Run the following command to generate a new, empty migration script:

```bash
poetry run pymongo-migrate generate -u mongodb://localhost:27017/givewith_dev -m migrations
```

### Executing a migration (also creates local database from scratch)

Run the following command to execute all migration scripts since the last migration, if any:

```bash
poetry run pymongo-migrate migrate -u mongodb://localhost:27017/givewith_dev -m migrations
```

### Rolling back

Run the following command to rollback all migrations:

```bash
poetry run pymongo-migrate downgrade -u mongodb://localhost:27017/givewith_dev -m migrations
```

## Logging

Following givewith-auth-service, initialization code for two loggers is provided in `portal/loggly.py`. This `init_logging` function is invoked from `create_app` in `portal.__init__.py`. One logger is attached to the Flask app, the other is attached to python's logging module as 'PORTAL'. The `send_loggly` function defined in `loggly.py` simply retrieves the 'PORTAL' logger and sends the passed message through it. 'PORTAL' is configured as a `SysLogHandler` that sends the message to a syslog server. In our development environment, starting rsyslog with `sudo service rsyslog start` is sufficient for the socket path defined and used in givewith-auth-service (/dev/log) to also work in our case. The logged messages then appear in `/var/log/syslog`.

## Exception Handling

Again following givewith-auth-service, exception handling is demonstrated in `portal/__init__.py` in create_app. The approach here relies on Flask's capability to register error handlers with the app. Error handlers are indexed by error code. In the example provided, a handler for 404 errors simply logs the error and returns a custom message.

## Testing

on Ubuntu 20 under WSL2, `sudo service rsyslog start` to start rsyslog. The functionality described here may be observed by opening a terminal and monitoring `tail -f /var/log/syslog` while running `make run` to start the app and then navigating to an unsupported path such as http://127.0.0.1:5052/test.

## Integration Testing

Integration tests (either hitting mongodb or a third-party integration) should be marked individually with `@pytest.mark.integration` or using the module/class wide marker `pytestmark = pytest.mark.integration`. This will automatically skip integration tests when calling `pytest` unless the `--integration` option is passed or a single test is run.

The logic for skipping integration tests is contained in `conftest.py`.

Implementation sourced from https://til.simonwillison.net/pytest/only-run-integration.

## Sending Emails

This project uses [Twilio SendGrid](https://sendgrid.com/) to send emails. A Template ID is generated when a new template is created on the send grid website and should be stored in `/shared/email/enums.py`.

## Testing Stripe Webhooks

Although webhook events from stripe will be handled in the givewith-transaction-engine project, we can test the data received here using the guide found at https://stripe.com/docs/webhooks/test.

- Forward webhook requests by running `stripe listen --forward-to localhost:5052/stripe/webhook`
- Update `webhook_secret` in `development.yml` with the secret returned by the `listen` command
- Add a breakpoint to `stripe_service.webhook_received()`
- Run and debug the api project
- Trigger an event by running `stripe trigger {event name}`
  - An abbreviated list of events can be retrieved by running `stripe trigger`
  - The full list of events can be found at https://stripe.com/docs/api/events/types

## Environment variables

A `user.env` file in the root of the project is required with the following variables set in order for Sage and Stripe to function properly:

- AWS_ACCESS_KEY_ID
- AWS_SECRET_ACCESS_KEY
- TOKEN_PRIVATE_KEY
- SAGE_SENDER_ID
- SAGE_SENDER_PASSWORD
- SAGE_USER_ID
- SAGE_USER_PASSWORD
- STRIPE_API_KEY
