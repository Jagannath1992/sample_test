aws --region us-east-1 --profile development kms decrypt --ciphertext-blob fileb://development.bin --output text --query Plaintext | base64 --decode 
