# Patch a dataset
#
# Format of a patch:
# {
#     "source": "string"
#     "ISIN": "string",
#     "patchFields": [
#         {
#             "field":,
#             "value":,
#         },
#         ...
#     ]
# }


import pandas as pd

from .utils import expand_dot_fields
from .mongodb import get_dataset_patches
from .loggly import get_logger

# Currently only works for top level fields
def patch(dataset, data):
    if dataset == 'CSRIT':
        return data
    elif dataset == 'MSCI':
        patched = patch_dataset(dataset, data[0])

        return (patched, data[1])
    else:
        return patch_dataset(dataset, data)


def patch_dataset(dataset, data):

    get_logger().info(f'Start patching dataset for {dataset}')

    dataset_patches = get_dataset_patches(dataset)

    for brand_patch in dataset_patches:
        brand = get_brand_by_isin(brand_patch['ISIN'], data)
        if brand:
            for patch in brand_patch['patchFields']:
                brand[patch['field']] = patch['value']

    get_logger().info(f'Start patching dataset for {dataset}')
    return data


def get_brand_by_isin(ISIN, data):
    return data.get(ISIN)

