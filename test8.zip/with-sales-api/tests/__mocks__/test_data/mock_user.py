from bson.objectid import ObjectId

default_user = {
    '_id': ObjectId('5d1a3962d5b3a53c05437ede'),
    'active': True,
    'type': 'admin',
    'first_name': 'Elizabeth',
    'last_name': 'Chan',
    'username': 'elizabeth.chan@givewith.com',
    'orgId': ObjectId('5c1415685b03bb0008c21b06'),
    'orgType': 'brand',
    'name': 'Elizabeth Chan',
    'uuid': 'cfc92a74-f0b8-477e-a366-11303d10fcb2',
    'cognito-id': '5b38f270-675b-4588-ab14-98076eec1555',
    'departmentType': 'Executive',
    'phoneNumber': '(111) 111 1111',
    'businessAddress': 'test business address',
    'title': 'test title123',
    'departmentName': 'test department name123',
    'notes': 'testing',
    'last_login': '2020-08-12T15:06:31.417Z'
}
