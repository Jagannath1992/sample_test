# pylint: disable=redefined-outer-name
import pytest
from unittest.mock import MagicMock

from app.utils.auth import validate_deal_token


@pytest.fixture()
def mock_decrypt():
    _decrypt = MagicMock()
    _decrypt.return_value = 'D0cm14er6B/password/5f3ade65006f58479bb92e3a/2020-08-31T16:31:40.032144Z'

    return _decrypt


def test_validate_deal_token(mock_decrypt, monkeypatch):
    # TODO: Finish these set of tests
    monkeypatch.setattr('app.utils.auth.abort', MagicMock())
    monkeypatch.setattr('app.utils.auth.request', MagicMock())
    monkeypatch.setattr('app.utils.auth._decrypt', mock_decrypt)
    token = 'sample token'
    validate_deal_token(token)

    mock_decrypt.assert_called_once_with(token)
