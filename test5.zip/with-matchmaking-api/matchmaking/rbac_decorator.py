import functools

from typing import Callable
from flask import request
from flask_restful import abort
from urllib.parse import urlparse

from matchmaking.utils import send_loggly
from matchmaking.dao.utils import get_document_by_id

from rbac_library.constants import Action
from rbac_library.enforcer import enforce

def can(action: Action) -> Callable:
    """View Decorator to control access a resource

    Usage:
        @app.route('/', methods=['POST'])
        @can(Action.CREATE)
        def create_deals():
            return success, 200

    Args:
        action (Action): [The CRUD permission required to access the resource]
    """
    def rbac_validator(view_func: Callable) -> Callable:
        @functools.wraps(view_func)
        def v(*args, **kwargs):
            user_brand = get_document_by_id('mm_brands', request.user['orgId'], projection=['featureFlags.rbac'])
            user_brand_supports_rbac = user_brand.get('featureFlags', {}).get('rbac', False)

            hostname = urlparse(request.headers.get('Origin')).hostname or ''
            is_from_enforce_client = any(hostname.startswith(subdomain) for subdomain in ('metpolice', 'impact'))
            is_enforce_request = is_from_enforce_client or to_bool(request.headers.get('X-EnforcePermissions'))

            if user_brand_supports_rbac and is_enforce_request:
                if not enforce(str(action), request.user.get('roles', [])):
                    send_loggly(f'Unauthorized { action } at { str(request.path) } by { request.user["username"] }')
                    abort(403, message='You do not have the appropriate permission to perform this action.')

            return view_func(*args, **kwargs)

        return v
    return rbac_validator


def to_bool(value):
    return value.lower() in ('true', '1', 'yes') if type(value) == str else value
