from os import environ

ENV = environ.get('ENV', 'staging').lower()

default_media_projection = {
    '_id': True,
    'tags': True,
    'media_s3': True,
    'thumbnail_s3': True,
}

PHOTO_TAGS_BY_DEPT = {
    'Sales': ['NPO Generic', 'Photo'],
    'Procurement': ['Beneficiary Profile', 'Photo'],
    'HR': ['Program Representative Profile', 'Photo'],
    'Marketing': ['Beneficiary Profile', 'Photo']
}

VIDEO_TAGS_BY_DEPT = {
    'Sales': [':30', 'NPO Montage', 'Video'],
    'Procurement': [':30', 'Executive Profile', 'Video'],
    'HR': [':30', 'Program Video', 'Video'],
    'Marketing': [':30', 'Beneficiary Profile', 'Video']
}

AWS_BUCKET_GREENLIST = [
    f'{ENV}-simian-media',
    f'share-actions-{ENV}',
    f'givewith-{ENV}-secure-upload',
    'givewith-local-secure-upload',
]
