# forex.py
# This utility file provides some helper functions for
# Foreign exchange rates
from typing import Dict

from ..mongodb import get_forex_rates


def convert_to_usd(amount, symbol):
    if symbol == 'USD':
        return amount

    rate = get_forex_rates().get(symbol)
    if rate and rate != 0:
        return amount / rate
    else:
        return 0

def convert_currency(amount: float, _from: str, _to: str, rates: Dict = None) -> float:
    if _from == _to:
        return amount

    _rates = rates or get_forex_rates()
    from_rate = _rates.get(_from)
    to_rate = _rates.get(_to)

    if from_rate and to_rate:
        return (amount / from_rate) * to_rate
    else:
        return 0
