import os

import boto3

from datetime import datetime
from typing import Union

from flask import current_app
from app.constants import ENV

FIREHOSE_STREAM_NAME = 'audit-log-stream'

FIREHOSE_AWS_ACCESS_KEY = os.environ.get('AUDIT_LOG_FIREHOSE_AWS_ACCESS_KEY')
FIREHOSE_AWS_SECRET_KEY = os.environ.get('AUDIT_LOG_FIREHOSE_AWS_SECRET_KEY')

client = boto3.client(
    'firehose',
    aws_access_key_id=FIREHOSE_AWS_ACCESS_KEY,
    aws_secret_access_key=FIREHOSE_AWS_SECRET_KEY,
    region_name='us-east-1',
)


# timestamps are in UTC
# note: if this takes too long it can be multi threaded
def log(service: str,
        user_id: str ='',
        entity_type: str ='',
        entity_id: str = '',
        action: str ='',
        sub_action: str ='',
        action_value: str = ''
        ) -> bool:
    """ Log an event to the audit log pipeline

    NOTE: matchmaking-api can currently be two services: admin-matchmaking-api and matchmaking-api.
          this will be changed when admin endpoints are in their own repo

    Args:
        service (str): the current service
        user_id (str, optional): the user's id
        entity_type (str, optional): the current entity
        entity_id (str, optional): the id of the current entity
        action (str, optional): the action being done to the entity
        sub_action (str, optional): a more spefic action
        action_value (str, optional): the value of the action, if any

    Returns:
        None
    """
    if not (ENV == 'staging' or ENV == 'production' or ENV == 'sandbox'):
        return

    try:
        timestamp = datetime.utcnow().isoformat()
        data = timestamp + "\t" + service     + "\t" + ENV + "\t" \
             + user_id   + "\t" + entity_type + "\t" + entity_id + "\t" \
             + action    + "\t" + sub_action  + "\t" + action_value + '\n'

        client.put_record(
            DeliveryStreamName=FIREHOSE_STREAM_NAME,
            Record={
                'Data': bytes(data, encoding='ascii')
            }
        )

    except Exception as e:
        current_app.logger.error(e)

