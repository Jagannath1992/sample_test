from datetime import datetime as dt
from time import sleep

import datetime
import pytest
import stripe

from portal.features.stripe.enums import StripeCheckoutSessionMode, StripePaymentMethodType, StripeTestPaymentMethods
from portal.shared.enums import SubscriptionFrequency
from portal.shared.services import stripe_service


class TestStripePOC:
    pytestmark = pytest.mark.integration

    @pytest.mark.skip
    def test_store_ach_payment_and_charge(self):
        # arrange (create checkout session first to create customer with bank account payment method)
        checkout_session_id = ''
        checkout_session = stripe.checkout.Session.retrieve(checkout_session_id)
        customer = stripe.Customer.retrieve(checkout_session.customer)
        payment_methods = stripe.Customer.list_payment_methods(
            customer.id, type=StripePaymentMethodType.US_BANK_ACCOUNT.value)

        # act
        response = stripe_service()._create_payment_intent(100, 'USD', customer.id, payment_methods.data[0].stripe_id)

        # assert
        pass

        stripe_service()._delete_customer(customer.id)

    @pytest.mark.skip
    def test_set_ach_payment_method_as_default_on_subscription(self, fakers):
        # arrange (create checkout session first to create customer with bank account payment method)
        checkout_session_id = ''
        checkout_session = stripe.checkout.Session.retrieve(checkout_session_id)
        customer = stripe.Customer.retrieve(checkout_session.customer)
        payment_methods = stripe.Customer.list_payment_methods(
            customer.id, type=StripePaymentMethodType.US_BANK_ACCOUNT.value)

        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][SubscriptionFrequency.MONTHLY.value]['id']

        # act
        response = stripe.Subscription.create(
            customer=customer.id,
            items=[
                {'price': price_id}
            ],
            default_payment_method=payment_methods.data[0].id
        )

        # assert
        pass

        stripe_service()._delete_customer(customer.id)

    def test_change_subscription_frequency_in_trial(self, fakers):
        # arrange
        test_clock = stripe.test_helpers.TestClock.create(
            frozen_time=int(dt.utcnow().timestamp())
        )
        customer = stripe.Customer.create(
            test_clock=test_clock.id,
            payment_method=StripeTestPaymentMethods.CARD_US_VISA.value,
            invoice_settings={'default_payment_method': StripeTestPaymentMethods.CARD_US_VISA.value}
        )

        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][SubscriptionFrequency.ANNUAL.value]['id']

        subscription = stripe.Subscription.create(
            customer=customer.id,
            items=[{
                'price': price_id,
                'quantity': 1
            }],
            trial_period_days=30,
            # proration_behavior='none'
        )
        advance_test_clock_and_wait(test_clock.id, 31)

        # act
        stripe.Subscription.modify(subscription.id, cancel_at_period_end=True)
        stripe.Subscription.modify(subscription.id, cancel_at_period_end=False)

        # assert
        pass

        stripe_service()._delete_customer(customer.id)

    def test_subscription_checkout_session_meta_data(self, fakers):
        test_clock = stripe.test_helpers.TestClock.create(
            frozen_time=int(dt.utcnow().timestamp())
        )
        customer = stripe.Customer.create(test_clock=test_clock.id)
        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][SubscriptionFrequency.ANNUAL.value]['id']
        checkout_session = stripe.checkout.Session.create(
            success_url='http://google.com',
            cancel_url='http://google.com',
            mode=StripeCheckoutSessionMode.SUBSCRIPTION.value,
            line_items=[{
                'price': price_id,
                'quantity': 1
            }],
            customer=customer.id,
            subscription_data={
                'trial_period_days': 30
            }
        )

        advance_test_clock_and_wait(test_clock.id, 31)


def advance_test_clock_and_wait(test_clock_id, days):
    stripe.test_helpers.TestClock.advance(test_clock_id, frozen_time=int(
        (dt.utcnow() + datetime.timedelta(days=days)).timestamp()))
    test_clock_status = stripe.test_helpers.TestClock.retrieve(test_clock_id).status
    while test_clock_status == 'advancing':
        sleep(1)
        test_clock_status = stripe.test_helpers.TestClock.retrieve(test_clock_id).status
        if test_clock_status == 'internal_failure':
            break
    return
