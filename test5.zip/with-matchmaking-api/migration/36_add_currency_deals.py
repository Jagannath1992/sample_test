from matchmaking import db

db().coll_deals.update_many({}, {'$set': {'currency': 'USD'}})
