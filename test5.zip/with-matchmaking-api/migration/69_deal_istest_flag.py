from matchmaking import db
from bson import ObjectId

deals = db().coll_deals.find()

white_list = ['5f6a480f31df4519b4039499', '5f72584d867a2d54fe2db622', '5ef4c749851ca985874062b6',
              '60491ed464f24dda828ee09c', '60492191fa9db533fb29e9a9', '60397fac6fe59b2d04fa37e9',
              '603987d36fe59b2d04fa3843', '60397e3cae23138920c695ac', '6039702cae23138920c69523',
              '6038feaf8799e00b92deb1fa', '6038fe488799e00b92deb1e7', '60340c8b576207d50f89c029',
              '60340be6576207d50f89c016', '60340a59576207d50f89c008']

for deal in deals:
    isTest = True

    user_id = deal.get('givewithCustomerUser', '')
    if ObjectId.is_valid(user_id):
        customer = db().coll_user.find_one({'_id': ObjectId(user_id)})
        isTest = customer is None or customer.get('type', '') == 'admin'

        if str(deal.get('_id')) in white_list:
            isTest = False

    deal['isTest'] = isTest
    db().coll_deals.update_one({'_id': deal['_id']}, {'$set': {'isTest': isTest}})


