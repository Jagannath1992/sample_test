# -*- coding: utf-8 -*-
import re
import pandas as pd

from os import environ
from bson import ObjectId, Int64
from datetime import datetime, timedelta
from flask import current_app, request
from pymongo import MongoClient, DESCENDING, ASCENDING, TEXT, errors, ReturnDocument
from slugify import slugify
from .models.models import schema_program, schema_program_v2, schema_nonprofit_v1, schema_brand
from .utils import natural_sort, MissingVocabulary, MissingVocabularyError, EntityNotFound, GivewithError, remove_empty, get_descendant_key, set_descendant_key

db_url = environ.get('MONGO_URL')

__db = None
mongo_db = None

VOCAB_V1 = {'$in': [1]}
VOCAB_V2 = {'$in': [2]}

DB_FORM_TYPES = {
    'PFF': 'coll_program_funding_forms',
    'PCF': 'coll_completion_forms',
    'PSF': 'coll_surveys' # legacy name for program_submission_forms
}

class DBCollections:

    vocabulary_list = []
    original_labels_map = []
    map_label_to_id = []
    map_type_label_to_id = []
    map_type_label_to_description = []
    map_id_to_label = []
    map_code_to_id = []
    map_attribute_to_label = []
    map_label_to_type = []
    map_code_to_type = []
    map_id_to_dict = []
    vocabulary_typos_remove = []
    vocabulary_typos_replace = []
    vocabulary_fields = set()

    vocabulary_v2 = None
    vocabulary_by_type_v2 = None

    __attr_to_collection = {
        'coll_brands': 'mm_brands',
        'coll_contacts': 'mm_contacts',
        'coll_nonprofits': 'mm_nonprofits',
        'coll_programs': 'mm_programs',
        'coll_settings': 'mm_settings',
        'coll_tagging_rules': 'mm_tagging_rules',
        'coll_tag_to_field': 'mm_tag_to_field',
        'coll_vocabulary': 'mm_vocabulary',
        'coll_vocabulary_typos': 'mm_vocabulary_typos',
        'coll_gics': 'gics_weights',
        'coll_comm_settings': 'comm_settings',
        'coll_user': 'user',
        'coll_csrhub': 'csrhub',
        'coll_counters': 'counters',
        'coll_deals': 'deals',
        'coll_location_data': 'location_data',
        'coll_nielsen_base_responses': 'nielsen_base_responses',
        'coll_nielsen_respondents': 'nielsen_respondents',
        'coll_nielsen_responses': 'nielsen_responses',
        'coll_tvl_data': 'tvl_data',
        'coll_campaigns': 'campaign',
        'coll_campaign_summary': 'summary',
        'coll_schema_version': 'schema_version',
        'coll_migration_lock': 'migration_lock',
        'coll_snapshot': 'snapshot',
        'coll_auth_token': 'auth_token',
        'coll_surveys': 'surveys',
        'coll_program_funding_forms': 'program_funding_forms',
        'coll_survey_data': 'survey_data',
        'coll_industry_mappings': 'gics_industry_mappings',
        'coll_permission': 'blueprint_permission',
        'coll_refresh_token_scope': 'refresh_token_scope',
        'coll_industry_display_map': 'industry_display_map',
        'coll_program_scc_conversion': 'program_scc_conversion',
        'coll_program_im_divisor': 'program_im_divisor',
        'coll_forex': 'forex',
        'coll_event': 'event',
        'coll_nonprofit_form': 'nonprofit_form',
        'coll_completion_forms': 'program_completion_forms',
        'coll_share_actions': 'share_actions',
        'coll_program_featured_topics': 'program_featured_topics',
        'coll_supplier_analysis_reports': 'supplier_analysis_reports',
        'coll_pilot_deal': 'pilot_deal',
        'coll_award': 'award',
    }

    def __init__(self, db):
        self.db = db

    def __getattr__(self, item):
        col_name = DBCollections.__attr_to_collection.get(item)
        if not col_name:
            raise Exception(f'Unknown collection {item} in MongoDB')
        return self.db.get_collection(col_name)


def init_db(test_db=None):
    global __db
    global mongo_db

    if test_db is None:
        client = MongoClient(db_url)
        mongo_db = client.get_database(environ.get('MONGO_DATABASE'))
    else:
        mongo_db = test_db

    __db = DBCollections(mongo_db)
    reload_vocabulary()
    coll_list = mongo_db.list_collection_names()

    if 'schema_version' not in coll_list:
        db().coll_schema_version.insert_one({'version': 0, 'dirty': False})

    if 'migration_lock' not in coll_list:
        db().coll_migration_lock.create_index('created_at', expireAfterSeconds=60)

    if 'refresh_token_scope' not in coll_list:
        db().coll_refresh_token_scope.create_index('created_at', expireAfterSeconds=2592000)

    load_indexes()

def db():
    if environ.get('ENV', '').lower() == 'staging' and request:
        if not hasattr(request, 'db_count'):
            request.db_count = 1
        else:
            request.db_count += 1

    return __db


def raw_db():
    return mongo_db


indexes = {
    'mm_brands': [[('name', ASCENDING), ('source', ASCENDING)],
                  [('iname', TEXT)],
                  [('slug', ASCENDING)]],
    'mm_programs': [[('slug', ASCENDING)]],
    'surveys': [[('slug', ASCENDING)]],
    'mm_nonprofits': [[('slug', ASCENDING)]],
    'deals': [[('slug', ASCENDING)]],
    'mm_vocabulary': [[('label', 1), ('type', 1)]],
}

index_additional = {
    'slug': {'unique': True},
    'label': {'unique': True},
}


def load_indexes():
    for coll, list_index in indexes.items():
        for index in list_index:
            kwargs = index_additional.get(index[0][0], {})
            try:
                db().db.get_collection(coll).create_index(index, **kwargs)
            except errors.OperationFailure:
                pass

# Utils ------------------------------------------------------------------------------

def create_slug(collection, entity, field_name='name'):
    coll_entity = db().db.get_collection(collection)

    if field_name in entity:
        slug = slugify(entity[field_name])
        _filter = {'slug': {'$regex': re.compile('^%s(-[0-9]*)?$' % slug, re.IGNORECASE)}}

        # find all references to suggested slug
        # NOTE: This fails when there are 10 brands with similar names because
        #       the sort prioritizes `brand_name-9` over `brand_name-10`
        row = list(coll_entity.find(filter=_filter,
                                    projection={'_id': False, 'slug': True},
                                    limit=1).sort('slug', DESCENDING))

        # ensure slug uniqueness
        if not row:
            entity['slug'] = slug
        else:
            # tries to convert the last part of the slug to integer
            try:
                last_num = int(row[0]['slug'].replace('%s-' % slug, ''))
            except ValueError:
                last_num = 0

            entity['slug'] = '%s-%d' % (slug, last_num + 1)

def get_next_reference_value(collection):
    return str(db().coll_counters.find_one_and_update(
        {'collection': collection},
        {'$inc': {'reference': 1}},
        {'reference': 1, '_id': 0},
        new=True).get('reference'))

# ------------------------------------------------------------------------------


# Vocabulary ----------------------------------------------------------------------

def check_and_create_counters_collection():
    if "counters" not in db().db.list_collection_names():
        default_value = {
            "collection": "deals",
            "reference": Int64(0)
        }

        counters = db().db["counters"]
        counters.insert_one(default_value)

def get_fields_by_type(dic, _type, fields):
    for k, field in dic.items():
        if isinstance(field, dict):
            field_type = field.get('type')
            if _type != 'list' and 'schema' in field and 'type' in field['schema']:
                field_type = field['schema']['type']
            if field_type:
                if isinstance(field_type, list) and _type in field_type:
                    fields.add(k)
                    continue
                elif isinstance(field_type, str):
                    if _type == field_type:
                        fields.add(k)
                        continue

            get_fields_by_type(field, _type, fields)

def get_list_fields(dic, fields):
    get_fields_by_type(dic, 'list', fields)

def get_object_id_fields(dic, fields):
    get_fields_by_type(dic, 'object_id', fields)

field_map_to_type = {
    'animalHabitat': 'animalHabitats',
    'audienceAge': 'audience',
    'audienceGender': 'audience',
    'audienceAttribute': 'audience',
    'audienceNeed': 'audience',
    'primaryImpact': 'impact',
    'secondaryImpacts': 'impact',
    'dataMeasurementType': 'dataMeasurement',
    'primaryOutcomeEffectiveness': 'researchType',
    'programActivityEffectiveness': 'researchType'
}

def composite_key(k, v):
    return '%s:%s' % (field_map_to_type.get(k, k), v.lower().strip())

def create_ref(obj_id):
    if type(obj_id) in [str, ObjectId]:
        return ObjectId(obj_id)

def set_vocabulary(document):
    ret_value, errors = set_vocabulary_recursive(None, document)
    if errors:
        raise MissingVocabulary(errors)

    return ret_value

def set_vocabulary_str(key, value):
    if value and key in db().vocabulary_fields:
        if not re.match(r'^(?=[a-f\d]{24}$)(\d+[a-f]|[a-f]+\d)', value):
            try:
                value = fix_vocabulary_typos(value)
                value = db().map_type_label_to_id[composite_key(key, value)]
            except KeyError:
                return None, MissingVocabularyError(key, value)

        return create_ref(value), None

    return value, None

def set_vocabulary_recursive(key, value):
    return_errors = []
    return_value = value
    if type(value) == str:
        return_value, error = set_vocabulary_str(key, value)
        if error is not None:
            return_errors.append(error)
    elif type(value) == dict:
        new_values = {}
        for k, v in value.items():
            new_value, errors = set_vocabulary_recursive(k, v)
            if errors is not None:
                return_errors.extend(errors)
            if new_value is not None:
                new_values[k] = new_value
        return_value = new_values
    elif type(value) == list and value:
        new_values = []
        for v in value:
            new_value, errors = set_vocabulary_recursive(key, v)
            if errors is not None:
                return_errors.extend(errors)
            if new_value is not None:
                new_values.append(new_value)
        return_value = new_values

    return return_value, return_errors

def reload_vocabulary():
    vocabulary_typos_list = list(db().coll_vocabulary_typos.find().sort([('type', ASCENDING)]))

    vocabulary_list = list(db().coll_vocabulary.find({'versions': VOCAB_V1})
                                                  .sort([('type', ASCENDING), ('label', ASCENDING)]))
    db().vocabulary_list = vocabulary_list

    vocabulary_list_v2 = list(db().coll_vocabulary.find({'versions': VOCAB_V2})
                                                  .sort([('type', ASCENDING), ('label', ASCENDING)]))
    db().vocabulary_v2 = pd.DataFrame(vocabulary_list_v2).set_index('_id')
    db().vocabulary_by_type_v2 = pd.DataFrame(vocabulary_list_v2).set_index(['type', 'label'])

    db().original_labels_map = {r['label'].lower(): r['label'] for r in vocabulary_list}
    db().map_id_to_label = {r['_id']: r['label'].lower() for r in vocabulary_list}
    db().map_label_to_id = {v: k for k, v in db().map_id_to_label.items()}
    db().map_type_label_to_id = {'%s:%s' % (r['type'], r['label'].lower()): r['_id'] for r in vocabulary_list}
    db().map_type_label_to_description = {'%s:%s' % (r['type'], r['label'].lower()): r.get('description', '') for r in vocabulary_list}
    db().map_code_to_id = {r['code']: r['_id'] for r in vocabulary_list if 'code' in r}
    db().map_label_to_type = {r['label']: r['type'] for r in vocabulary_list}
    db().map_code_to_type = {r['code']: r['type'] for r in vocabulary_list if 'code' in r}
    db().map_attribute_to_label = {r['attribute']: r['label'] for r in vocabulary_list if 'attribute' in r}
    db().map_id_to_dict = {r['_id']: r for r in vocabulary_list}
    db().vocabulary_typos_remove = [r['value'] for r in vocabulary_typos_list if r['type'] == 'remove']
    db().vocabulary_typos_replace = {r['from']: r['to'] for r in vocabulary_typos_list if r['type'] == 'replace'}

    get_object_id_fields(schema_program, db().vocabulary_fields)
    get_object_id_fields(schema_program_v2, db().vocabulary_fields)
    get_object_id_fields(schema_brand, db().vocabulary_fields)
    get_object_id_fields(schema_nonprofit_v1, db().vocabulary_fields)

    try:
        db().vocabulary_fields.remove('_id')
    except KeyError:
        pass

    try:
        db().vocabulary_fields.remove('nonprofit')
    except KeyError:
        pass
    check_and_create_counters_collection()

def fix_vocabulary_typos(field):
    for term in db().vocabulary_typos_remove:
        field = field.replace(term, '')
    for fromTerm, toTerm in db().vocabulary_typos_replace.items():
        field = field.replace(fromTerm, toTerm)

    return field

def get_vocabulary_label(vocabulary):
    return get_vocabulary(vocabulary).get('label', None)

def expand_item(item, blacklist=set(), **kwargs):
    if kwargs.get('version') == 2:
        return get_vocabulary_label_v2(item) if isinstance(item, ObjectId) else expand_vocabulary_label(item, blacklist, **kwargs)
    else:
        return get_vocabulary_label(item) if isinstance(item, ObjectId) else expand_vocabulary_label(item, blacklist, **kwargs)

def expand_vocabulary_list(items, blacklist=set(), **kwargs):
    expanded_list = [expand_item(i, blacklist, **kwargs) for i in items]
    # TODO: if (None in expanded_list):
    #          log that there are missing vocabularies (dangling ObjectIds)
    return [i for i in expanded_list if i is not None]

def expand_vocabulary_label(entity, blacklist=set(), **kwargs):
    if type(entity) in [dict, list]:
        for key, value in entity.items():
            if key in blacklist:
                continue
            if type(value) == dict:
                expand_vocabulary_label(value, blacklist, **kwargs)
            elif type(value) == list:
                new_list = expand_vocabulary_list(value, blacklist, **kwargs)
                entity[key] = new_list
            elif key in db().vocabulary_fields and isinstance(value, ObjectId):
                label = get_vocabulary_label_v2(value) if kwargs.get('version') == 2 else get_vocabulary_label(value, **kwargs)
                if label:
                    entity[key] = label
    return entity

def set_esg_vocabulary(esg):
    for key, value in esg.items():
        if key == 'issue':
            esg[key] = create_ref(value)
    return esg

def get_vocabulary(vocabulary_ref):
    return db().map_id_to_dict.get(vocabulary_ref, {})

def get_vocabulary_v2(vocab_id):
    try:
        return db().vocabulary_v2.loc[vocab_id]
    # except (KeyError, TypeError):
    except KeyError:
        return {}

def get_vocabulary_v2_by_type(_type, label, match_lower=False):
    try:
        if match_lower:
            # matching by a mask is a little slower, don't use unless you absolutely have to
            mask = (
                (db().vocabulary_v2['type'].str.lower() == _type.lower()) &
                (db().vocabulary_v2['label'].str.lower() == label.lower())
            )
            return db().vocabulary_v2.loc[mask].iloc[0]
        else:
            return db().vocabulary_by_type_v2.loc[(_type, label)].iloc[0]
    except (KeyError, IndexError):
        return {}

def get_vocabulary_label_v2(vocab_id):
    return get_vocabulary_v2(vocab_id).get('label')

def get_vocabulary_id_and_label_from_str(item):
    _id = db().map_label_to_id.get(item)
    return {'_id': _id, 'label': item} if _id else None

def get_vocabulary_id_and_label(item):
    try:
        if type(item) == ObjectId:
            label = db().map_id_to_label[item]
            return {'_id': item, 'label': db().original_labels_map[label]}
        elif type(item) == str:
            _id = db().map_label_to_id[item.strip().lower()]
            return {'_id': _id, 'label': item}
    except KeyError:
        return None

def group_vocabulary(key, master, addition):
    master_set = set(master.get(key, []))
    addition_set = set(addition.get(key, {}).get('data', []))
    reported = [get_vocabulary(i) for i in (master_set & addition_set)]
    new = [get_vocabulary(i) for i in (addition_set - master_set)]
    return {'reported': sorted(reported, key=lambda item: natural_sort(item['code'])),
            'new': sorted(new, key=lambda item: natural_sort(item['code']))}

def translate_to_topic(_id=None, _type=None, label=None):
    if not _id and not (_type and label):
        return None

    vocab = get_vocabulary_v2(_id) if _id else get_vocabulary_v2_by_type(_type, label)
    if isinstance(vocab.get('topic'), ObjectId):
        return get_vocabulary_label_v2(vocab['topic'])
    else:
        return None

def get_sdg_vocabulary_from_labels(labels):
    if not labels:
        return []

    sdg_vocab = db().coll_vocabulary.find({'versions': VOCAB_V1, 'type': 'sdg'})

    result = []
    for sdg in sdg_vocab:
        label = sdg.get('label')
        if label in labels:
            result.append({
                'code': sdg.get('code'),
                'label': label,
                'topic': translate_to_topic(_id=sdg.get('_id'))
            })

    return result

# ------------------------------------------------------------------------------


# Nonprofits ------------------------------------------------------------------------------

def get_is_valid_nonprofit(nonprofits):
    return db().coll_nonprofits.count_documents({'_id': {'$in': nonprofits}, 'isValid': True}) > 0

def get_nonprofit_names(nonprofit_ids):
    """
    Accepts a list of nonprofit ObjectIds and returns their respective names
    """
    if not nonprofit_ids:
        return []

    cursor = db().coll_nonprofits.find({"_id": {"$in": nonprofit_ids}}, {"name": 1})
    return [x for x in cursor]

def get_nonprofit(nonprofit_id, **kwargs):
    if nonprofit_id:
        return db().coll_nonprofits.find_one({'_id': ObjectId(nonprofit_id)}, **kwargs)
    else:
        raise EntityNotFound('nonprofit', nonprofit_id)

# ------------------------------------------------------------------------------


# Programs ------------------------------------------------------------------------------

def get_is_valid_program(programs):
    return db().coll_programs.count_documents({'_id': {'$in': programs}, 'isValid': True}) > 0

def get_program(program_id, **kwargs):
    if program_id:
        return db().coll_programs.find_one({"_id": program_id}, **kwargs)
    else:
        return {}

def get_program_themes_by_id(program_id):
    program = get_program(ObjectId(program_id), projection={'themes': True})

    if not program:
        raise EntityNotFound('program', program_id)

    return program.get('themes', {}).get('data', [])

def get_selected_recommended_programs(deal, projection=None):
    """Queries the DB for Selected Recommended Programs of a deal

    Arguments:
        deal { dictionary } -- deal dictionary
    """
    db_query = {'_id': {'$in': [
        program.get('_id') for program in deal.get('selectedRecommendedPrograms', [])
    ]}}
    return db().coll_programs.find(db_query, projection=projection)

# ------------------------------------------------------------------------------


# FORMS/SURVEYS ------------------------------------------------------------------------------

# program submission forms (PSF)
def get_is_valid_survey(surveys):
    return db().coll_surveys.count_documents({'_id': {'$in': surveys}, 'isValid': True}) > 0

def get_survey(survey_id, **kwargs):
    if survey_id:
        return db().coll_surveys.find_one({"_id": survey_id}, **kwargs)
    else:
        return {}


# funding forms (PFF)
def get_funding_form(form_id, **kwargs):
    if form_id:
        return db().coll_program_funding_forms.find_one({'_id': form_id}, **kwargs)
    else:
        raise EntityNotFound('Funding form', form_id)


# completion forms (PCF)
def get_completion_form(form_id, **kwargs):
    if form_id:
        return db().coll_completion_forms.find_one({'_id': form_id}, **kwargs)
    else:
        raise EntityNotFound('Completion form', form_id)


# psfs, pffs
def get_np_form_collection(form_type):
    """
    Gets a nonprofit form/survey collection from db
    Currently supports PSF -> surveys, PFF -> program_funding_forms, PCF -> program_completion_forms
    """
    try:
        return getattr(db(), DB_FORM_TYPES[form_type])
    except AttributeError:
        raise EntityNotFound('survey')

def get_survey_by_slug(form_type, nonprofit_slug, slug):
    return get_np_form_collection(form_type).find_one({'slug': slug, 'nonprofitSlug': nonprofit_slug})

def update_survey(form_type, survey):
    _id = survey.get('_id')
    if _id:
        return get_np_form_collection(form_type).find_one_and_update({'_id': _id},
                                                                     {'$set': survey},
                                                                     return_document=ReturnDocument.AFTER)
    else:
        raise EntityNotFound('survey')


# survey data (dependencies etc)
def get_survey_metadata():
    return db().coll_survey_data.find_one()

# ------------------------------------------------------------------------------


# Brands ------------------------------------------------------------------------------

def is_brand_valid_for_deal(brand_oid):
    brand = db().coll_brands.find_one({'_id': brand_oid})
    if not brand:
        return False
    return bool(brand['industry'] and brand['name'] and brand['slug'])

def get_mm_brand(brand_id, **kwargs):
    if brand_id:
        return db().coll_brands.find_one({'_id': ObjectId(brand_id)}, **kwargs)
    else:
        return {}

def get_brand_industry_id(brand_or_id):
    if isinstance(brand_or_id, dict):
        brand = brand_or_id
    else:
        brand = get_mm_brand(brand_or_id, projection={'industry': True, 'msci.industry': True})

    industry_name = brand.get('msci', {}).get('industry') or brand.get('industry')
    return db().map_label_to_id.get(industry_name.lower())

def get_brand_csrhub_data(brand):
    """ Looks up csrhub data for brand using brand's ISIN """
    brand_isin = brand.get('ISIN')
    return db().coll_csrhub.find_one({'ISIN': brand_isin})

# ------------------------------------------------------------------------------


# Deals ------------------------------------------------------------------------------

def get_deal(deal_id, **kwargs):
    if deal_id:
        return db().coll_deals.find_one({'_id': deal_id}, **kwargs)
    else:
        raise EntityNotFound('Proposal', deal_id)

def create_deal(deal):
    if not deal.get('slug'):
        return {'ERROR': 'No slug found'}
    try:
        inserted_deal = db().coll_deals.insert_one(deal)
        deal_id = inserted_deal.inserted_id
        deal['_id'] = deal_id
        if deal_id:
            # return deal.type to support different actions if deal is COVID
            return {'SUCCESS': 'Proposal successfully created', 'id': deal_id, 'type': deal.get('type')}
        else:
            return {'ERROR': 'Error creating proposal'}
    except errors.DuplicateKeyError:
        return {'ERROR': 'Duplicate slugs'}

def update_deal_from_users_brand_id(user_brand_id, deal_id, deal_obj):
    """
    Update a deal with a user's brand id given in order to insure
    that a user cannot update a deal they are not associated with
    """
    find_query = {'_id': deal_id, '$or': [{'givewithCustomer': user_brand_id},
                                          {'client': user_brand_id}]}

    return db().coll_deals.find_one_and_update(find_query, {'$set': deal_obj}, return_document=ReturnDocument.AFTER)

def update_deal(deal):
    _id = deal.get('_id')
    if _id:
        return db().coll_deals.find_one_and_update({'_id': _id}, {'$set': deal}, return_document=ReturnDocument.AFTER)
    else:
        raise EntityNotFound('Proposal')

def get_associated_proposals(user_id):
    """ Queries the DB for procurement proposals associated with the given user """
    query = {
        'givewithCustomerUser': str(user_id),
        'archived': {'$ne': True},
        '$or': [
            {'type' : {'$exists' : False}},
            {'type' : 'enterprise'},
            {'type' : 'covid'}
        ]
    }

    return db().coll_deals.find(query).sort('lastUpdated', DESCENDING)

# ------------------------------------------------------------------------------


# Users ------------------------------------------------------------------------------

def get_user_from_cognito_id(cognito_id):
    return db().coll_user.find_one({"cognito-id": cognito_id})

def get_user(user_id, **kwargs):
    return db().coll_user.find_one({'_id': user_id}, **kwargs)

def update_user_by_cognito_id(cognito_id, user_obj):
    update_result = db().coll_user.update_one({'cognito-id': cognito_id}, {'$set': user_obj})
    return (update_result.matched_count, update_result.modified_count)

def get_manager(manager_id):
    return db().coll_user.find_one({"_id": manager_id})

# ------------------------------------------------------------------------------


# Settings ------------------------------------------------------------------------------

def get_screen_one_minimum():
    settings = db().coll_settings.find_one(projection={'_id': False, 'scoringSettings': True})
    if settings is not None:
        return settings['scoringSettings'].get('screenOneMinimum', 0)
    else:
        return 1

def get_recommendations_limit():
    settings = db().coll_settings.find_one(projection={'_id': False, 'recommendationSettings': True})
    if settings:
        return settings.get('recommendationSettings', {}).get('recommendations', 6)
    else:
        return 6

# ------------------------------------------------------------------------------

# Campaigns ------------------------------------------------------------------------------

def get_campaigns(brand_id):
    return db().coll_campaigns.find({"brand": {"id": brand_id}})

# ------------------------------------------------------------------------------

# Location ------------------------------------------------------------------------------

def get_location_data():
    return db().coll_location_data.find_one()

# ------------------------------------------------------------------------------

# Industry Display Map------------------------------------------------------------------------------

def get_industry_display_map():
    mappings = db().coll_industry_display_map.find_one({})
    mappings.pop('_id')
    return mappings

# ------------------------------------------------------------------------------

# Nielsen ----------------------------------------------------------------------

def filter_base_responses_by_company(company):
    cursor = db().coll_nielsen_base_responses.find({"company": company})
    return [x for x in cursor]

def filter_base_responses_by_industry(industry):
    cursor = db().coll_nielsen_base_responses.find({"industry": industry})
    return [x for x in cursor]

def filter_responses_by_company(company):
    cursor = db().coll_nielsen_responses.find({"company": company})
    return [x for x in cursor]

def filter_responses_by_industry(industry):
    cursor = db().coll_nielsen_responses.find({"industry": industry})
    return list(cursor)

def get_nielsen_industry(gics_industry):
    """ Returns a nielsen industry from a gics industry """
    # If industry is passed as an ObjectId, look up gics industry in vocabulary
    if type(gics_industry) == ObjectId:
        industry = db().coll_vocabulary.find_one({'_id': gics_industry, 'type': 'industry'})
        if industry:
            gics_industry = industry.get('name', '')

    if gics_industry:
        result = db().coll_industry_mappings.find_one({'type':'nielsen','gics_industry': gics_industry})
        if result:
            return result['industry']
        else:
            return ''

    else:
        raise GivewithError('No industry given for nielsen lookup')

# ------------------------------------------------------------------------------


# NielsenDemographics ----------------------------------------------------------------------

def get_filtered_nielsen_respondents(filters):
    query = {}
    for key in filters:
        values = filters[key]
        if filters[key] and key == 'age':
            age_query = []
            for ages in values:
                low = ages[0]
                high = ages[1]
                age_query.append({'age': {'$gte': low, '$lte': high}})
            query['$or'] = age_query
        elif filters[key]:
            query[key] = {'$in': values}

    return db().coll_nielsen_respondents.find(query)

def get_nielsen_responses(respondents):
    themes_count = {}
    grouped_by_id = db().coll_nielsen_responses.aggregate([
            {'$group': {
            '_id': '$respondent_id',
            'themeIds': {'$addToSet': '$theme_id'}
            }}
        ])

    for respondent in grouped_by_id:
        if respondent['_id'] in respondents:
            themes = respondent['themeIds']
            for theme in themes:
                themes_count[theme] = themes_count.get(theme, 0) + 1

    return themes_count

def get_forex_rates():
    """ Gets foreign exchange rates with a USD base
    NOTE: rates updated daily via a lambda function
    Data comes from https://ratesapi.io/
    """
    forex = db().coll_forex.find_one()

    if not forex:
        current_app.logger.error('MissingForexError: No Foreign Exchange data found')
        return {}

    forex_date = datetime.strptime(forex['date'], '%Y-%m-%d')
    forex_date_age = datetime.utcnow() - forex_date

    if forex_date_age > timedelta(days=7):
        current_app.logger.error('ExpiredForexData: Foreign Exchange data is older than 7 days')
        return {}

    return forex['rates']

# ------------------------------------------------------------------------------


# TVL Data ----------------------------------------------------------------------

def get_tvl_data(isin, sasb_ids):
    if not isin:
        return {}
    data = db().coll_tvl_data.find_one({'ISIN': isin}, projection={"CUSIP": False, "SEDOL": False})
    if not data:
        return {}
    data['insight'] = remove_empty(data['insight'])
    data['momentum'] = remove_empty(data['momentum'])
    data['volume_daily'] = remove_empty(data['volume_daily'])
    data['volume_ttmdaily'] = remove_empty(data['volume_ttmdaily'])
    data['pulse'] = remove_empty(data['pulse'])
    data['sasb_tags'] = [get_vocabulary(ObjectId(_id)).get('camelCaseName') for _id in sasb_ids]
    data['labels'] = [get_vocabulary(ObjectId(_id)).get('label') for _id in sasb_ids]
    return data

# -------------------------------------------------------------------------------


# ---- Deliverables Generation ---------------------------------------------------
# send back one giant dictionary of the info we need to create the merge lookup table

def get_deliverables_master_data(deal_id):
    master_data = dict()
    key_name = 'master_data_status'
    master_data[key_name] = 'complete'

    if not deal_id:
        master_data[key_name] = 'incomplete: no deal id passed in request'
        return master_data

    ##### Add in the deal object
    deal = db().coll_deals.find_one({'_id': ObjectId(deal_id)})
    if deal:
        master_data['deal'] = deal
    else:
        master_data[key_name] = 'incomplete - no deal data for ' + deal_id
        return master_data

    ##### Add in the customer (brand)
    customer = db().coll_brands.find_one({'_id': deal['givewithCustomer']})
    if customer:
        master_data['customer'] = customer
    else:
        master_data[key_name] = 'incomplete: no givewithCustomer'
        return master_data

    ##### Add in the client (brand)
    client = db().coll_brands.find_one({'_id':deal['client']})
    if client:
        master_data['client'] = client
    else:
        master_data[key_name] = 'incomplete: no client'
        return master_data

    ##### Add in the selected program (program)
    program = db().coll_programs.find_one({'_id': deal['selectedProgram']})
    if program:
        master_data['program'] = program
    else:
        master_data[key_name] = 'incomplete: no selectedProgram'
        return master_data


    ##### Add in the non profit (nonprofit)
    npo_id = program['nonprofit']
    nonprofit = db().coll_nonprofits.find_one({'_id': npo_id})
    if nonprofit:
        master_data['nonprofit'] = nonprofit
    else:
        master_data[key_name] = 'incomplete: no nonprofit related to selected program'
        return master_data

    ##### Should be successful here
    return master_data

def get_sdg_for_deliverables():
    sdg_vocab = db().coll_vocabulary.find({'versions': VOCAB_V2, 'type': 'sdg'})
    result = dict()
    for sdg in sdg_vocab:
        result[sdg['label']] = (sdg['code'].replace('SDG ', 'SDG #') + ': ' + sdg['label'])
    return result

def get_gri_for_deliverables():
    gri_dict = dict()
    for document in db().coll_vocabulary.find({'type': 'gri', 'versions': VOCAB_V2}):
        gri_dict[str(document['_id'])] = document['code'] + ': ' + document['label']
    return gri_dict

def get_sasb_for_deliverables():
    sasb_master = dict()
    for document in db().coll_vocabulary.find({'type': 'sasb', 'versions': VOCAB_V2}):
        sasb_master[str(document['label'])] = document['code'] + ' - '
    return sasb_master

# Move deliverable to deal  ------------------------------------------------------------------------------

def grab_deliverables(deliverables, program_deliverables, funding_deliverables):
    deliverable_mapping = {
        'Photos': 'photoGallery',
        'LongFormVideo': 'longVideo',
        'ShortFormVideo': 'shortVideo',
    }

    for index, item in enumerate(deliverables):
        if item['name'] in ['Photos', 'ShortFormVideo', 'LongFormVideo']:
            if program_deliverables.get(deliverable_mapping[item['name']]):
                deliverables[index]['url'] = program_deliverables.get(deliverable_mapping[item['name']], '')
        else:
            if funding_deliverables:
                filtered_deliv = list(filter(lambda a: a['name'] == item['name'], funding_deliverables))
                if filtered_deliv:
                    deliverables[index]['url'] = filtered_deliv[0].get('url', '')

    return deliverables

def copy_deliverables_and_licensing(deal_id, deal_obj):
    if not deal_obj.get('selectedProgram'):
        return None, None

    program = get_program(ObjectId(deal_obj.get('selectedProgram')), projection={'deliverables': True, 'altLicensing': True})
    funding_form_list = list(db().coll_program_funding_forms.find({'deal': deal_id}, projection={'deliverables': True})
                                                            .sort('createdAt', DESCENDING).limit(1))

    funding_deliverables = funding_form_list[0].get('deliverables', []) if funding_form_list else []
    program_deliverables = program.get('deliverables', {})

    customer_deliverables = get_descendant_key(deal_obj, 'deliverables.givewithCustomer.deliverables', [])
    client_deliverables = get_descendant_key(deal_obj, 'deliverables.client.deliverables', [])

    customer_deliverables = grab_deliverables(customer_deliverables, program_deliverables, funding_deliverables)
    client_deliverables = grab_deliverables(client_deliverables, program_deliverables, funding_deliverables)

    set_descendant_key(customer_deliverables, deal_obj, 'deliverables.givewithCustomer.deliverables')
    set_descendant_key(client_deliverables, deal_obj, 'deliverables.client.deliverables')

    if program.get('altLicensing'):
        deal_obj['altLicensingClient'] = program.get('altLicensing')
        deal_obj['altLicensingGivewithCustomer'] = program.get('altLicensing')
