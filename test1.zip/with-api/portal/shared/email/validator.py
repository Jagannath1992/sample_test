import re


class EmailAddress():
    def __init__(self, username, domain):
        self.username = username
        self.domain = domain

    def __str__(self):
        return '@'.join([self.username, self.domain])


class EmailValidator():
    def __init__(self, pattern='([^@]+)@([^@]+\.[^@]+)'):
        self.pattern = re.compile(pattern)

    def validate(self, address):
        match = self.pattern.match(address)
        if match:
            return EmailAddress(*match.groups())
