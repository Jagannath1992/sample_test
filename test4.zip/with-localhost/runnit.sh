./read_local_envs.sh > env
source ./env

docker-compose up

rm ./env
