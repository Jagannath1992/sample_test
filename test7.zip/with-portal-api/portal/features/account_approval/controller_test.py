import pytest
from bson import ObjectId

from portal.features.account_approval.schema import AccountApprovalResponse
from portal.shared.enums import UserRole
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import account_approval_repository, account_repository, user_repository


class TestAccountApprovalResource:
    def test_get(self, client, givewith_header, mocker, fakers):
        approvals = fakers.approval.generate_single()
        mocker.patch.object(account_approval_repository(), 'get_single', return_value=approvals)

        expected = AccountApprovalResponse().dump(approvals)

        response = client.get(f'/accounts/{ObjectId()}/approvals', headers=givewith_header)

        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES],
        indirect=True
    )
    def test_get_account_permission(self, client, custom_auth_header):
        response = client.get(f'/accounts/{ObjectId()}/approvals', headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_put(self, client, givewith_header, mocker, fakers):
        approval = fakers.approval.insert_single()
        mocker.patch.object(account_approval_repository(), 'get_single', return_value=approval)
        mocker.patch.object(account_approval_repository(), 'update', return_value=approval)
        mocker.patch.object(account_repository(), 'exists', return_value=True)
        mocker.patch.object(user_repository(), 'exists', return_value=True)
        expected = AccountApprovalResponse().dump(approval)

        response = client.put(f'accounts/{approval["_id"]}/approvals', json=expected, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN, UserRole.FINANCE]],
        indirect=True
    )
    def test_put_role_permissions(self, client, custom_auth_header, fakers):
        approval = fakers.approval.generate_single()
        json_request = AccountApprovalResponse().dump(approval)
        response = client.put(f'accounts/{ObjectId()}/approvals', json=json_request, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_put_account_permissions(self, client, custom_auth_header, fakers, mocker):
        approval = fakers.approval.generate_single()
        mocker.patch.object(account_repository(), 'exists', return_value=True)
        mocker.patch.object(user_repository(), 'exists', return_value=True)

        json_request = AccountApprovalResponse().dump(approval)
        response = client.put(f'accounts/{ObjectId()}/approvals', json=json_request, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}
