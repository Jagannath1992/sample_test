from portal.shared import dates

from portal.shared.sage.models import SageLegacyDate

def get_sage_date(date=None) -> str:
    if date is None:
        date = dates.get_utcnow()
    return date.strftime('%m/%d/%Y')


def get_sage_legacy_date(date=None) -> SageLegacyDate:
    if date is None:
        date = dates.get_utcnow()
    return SageLegacyDate(
        year=date.year,
        month=date.month,
        day=date.day
    )
