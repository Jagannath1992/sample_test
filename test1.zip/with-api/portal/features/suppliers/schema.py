from marshmallow import Schema, fields, post_load, pre_dump

from portal.features.accounts.schema import AccountSchema, AccountRequest, AccountGiveFieldsSchema
from portal.features.users.schema import UserSchema, UserRegisterRequest
from portal.shared.custom_fields import ObjectIdField
from portal.shared.enums import AccountStatus, AccountType
from portal.shared.schema import OrderedSchema, SearchRequestBaseSchema, SearchRequestSchema, SearchResponseSchema


class SupplierSearchRequest(SearchRequestSchema):
    """Request model for GET Suppliers search request"""
    id = ObjectIdField(attribute='_id')
    accountId = ObjectIdField()
    company = fields.String()
    city = fields.String()
    state = fields.String()
    status = fields.String()
    type = fields.String()
    industry = fields.String()
    address = fields.String()

    class Meta:
        contains_fields = ['company', 'city', 'state', 'industry', 'address']

    @post_load
    def post_load(self, data, **kwargs):
        # Return all new/pending suppliers when pending is requested
        if data.get('status', "") == AccountStatus.PENDING.value:
            data['status'] = {'$in': [
                AccountStatus.NEW.value,
                AccountStatus.PENDING.value,
                AccountStatus.PENDING_FINANCE.value,
                AccountStatus.PENDING_STRIPE.value,
            ]}

        return super().post_load(data, **kwargs)

    def _convert_nested(self, key):
        if key == 'company':
            return 'company.name'
        elif key == 'city':
            return 'company.address.city'
        elif key == 'state':
            return 'company.address.stateProvince'
        elif key == 'industry':
            return 'industry.displayLabel'
        elif key == 'address':
            return 'company.address.address1'
        return key


class SupplierResponse(Schema):
    """Supplier user/account response model"""
    account = fields.Nested(AccountSchema)
    user = fields.Nested(UserSchema)

    @pre_dump
    def pre_dump(self, data, **kwargs):
        # keys we want to return
        account_keys = ['_id', 'status', 'type', 'industry', 'company']
        user_keys = ['first_name', 'last_name', 'createdAt', 'username', 'title', 'departmentName', 'phoneNumber']
        for key in list(data['account']):
            if key not in account_keys:
                del data['account'][key]
        if data['user']:
            for key in list(data['user']):
                if key not in user_keys:
                    del data['user'][key]
        return data


class SupplierSearchResponse(SearchResponseSchema):
    """Response model for GET Suppliers search response"""
    results = fields.List(fields.Nested(SupplierResponse))


class SupplierRequest(AccountRequest):
    """Request Model for POST/PUT Supplier requests"""
    accountId = ObjectIdField(allow_none=True)


class SupplierUserInviteRequest(UserRegisterRequest):
    """Supplier user invite request model"""
    @post_load
    def post_load(self, data, **kwargs):
        super().post_load(data)
        account = data.get('account')
        account['type'] = AccountType.SUPPLIER.value
        return data


class SupplierInviteRequest(Schema):
    """Request model for POST Supplier invite requests"""
    accountId = ObjectIdField()
    suppliers = fields.List(fields.Nested(SupplierUserInviteRequest))


class SupplierUserInviteResponse(Schema):
    """Supplier user invite response model"""
    user = fields.Nested(UserSchema)
    message = fields.String()


class SupplierInviteResponse(Schema):
    """Response model for Supplier invite responses"""
    suppliers = fields.List(fields.Nested(SupplierUserInviteResponse))


class SupplierInviteCSVResponse(Schema):
    """Response model for Parse Suppliers CSV file"""
    columns = fields.List(fields.List(fields.String()))


class SupplierResendInviteRequest(Schema):
    """Request model for POST Supplier Resend Invite"""
    accountId = ObjectIdField(allow_none=True)
    username = fields.String(required=True)


class SupplierResendInviteResponse(Schema):
    """Response model for POST Supplier Resend Invite"""
    message = fields.String()


class SupplierMetricsRequest(SearchRequestBaseSchema):
    """Supplier Metrics Filters"""
    accountId = ObjectIdField(allow_none=True)
    lastUpdatedFrom = fields.DateTime(allow_none=True)
    lastUpdatedTo = fields.DateTime(allow_none=True)
    # causeAreas = fields.List(ObjectIdField, allow_none=True)
    # instances = fields.List(ObjectIdField, allow_none=True)
    # instanceType = fields.String(allow_none=True)
    # locales = fields.List(ObjectIdField, allow_none=True)
    industries = fields.List(fields.String, allow_none=True)
    accounts = fields.List(ObjectIdField, allow_none=True)
    # accountType = fields.String(allow_none=True)
    active = fields.List(fields.Boolean, allow_none=True)
    
    class Meta:
        in_fields = ['causeAreas', 'locales', 'instances', 'industries', 'accounts', 'active']
        range_fields = ['lastUpdated']

    def _convert_nested(self, key):
        if key == 'accountId':
            return 'sharedWith._id'
        # if key == 'causeAreas':
        #     return 'causeArea._id'
        # if key == 'locales':
        #     return 'loc._id'
        # if key == 'instances':
        #     return 'inst._id'
        # if key == 'instanceType':
        #     return 'inst.type'
        if key == 'accounts':
            return 'account._id'
        # if key == 'accountType':
        #     return 'acct.type'
        if key == 'industries':
            return 'acct.industry.subIndustry'
        if key == 'active':
            return 'ca.active'
        return key


class MetricsGroupKey(OrderedSchema):
    account = fields.String()
    causeArea = fields.String()
    causeAreaUrl = fields.String()
    currency = fields.String()
    currencySymbol = fields.String()


class MetricsDetail(OrderedSchema):
    status = fields.String()
    totalDealAmount = fields.Number()
    totalGiveAmount = fields.Number()
    totalGivePercent = fields.Number()
    count = fields.Number()
    mostGives = fields.Email()


class SummmaryMetricsDetail(OrderedSchema):
    avgGivePercent = fields.Number()
    totalGiveAmount = fields.Number()
    participation = fields.Number()


class MetricsResult(OrderedSchema):
    key = fields.Nested(MetricsGroupKey, attribute='_id')
    avgDealAmount = fields.Number()
    avgGiveAmount = fields.Number()
    avgGivePercent = fields.Number()
    participation = fields.Number()
    winRate = fields.Number(default=0)
    impact = fields.Number()
    impactMeasurement = fields.String()
    details = fields.List(fields.Nested(MetricsDetail))


class MetricsCurrency(OrderedSchema):
    currency = fields.String()
    symbol = fields.String()


class SupplierMetricsResponse(OrderedSchema):
    """Response model for supplier metrics"""
    results = fields.List(fields.Nested(MetricsResult))
    summary = fields.Nested(SummmaryMetricsDetail)
    currencies = fields.List(fields.Nested(MetricsCurrency))

    
class SupplierAppSettingsResponse(Schema):
    """Response Model for GET Supplier App Settings"""
    id = ObjectIdField()
    giveFields = fields.Nested(AccountGiveFieldsSchema)
