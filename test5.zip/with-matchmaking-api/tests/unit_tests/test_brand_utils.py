from datetime import datetime
import pytest

from matchmaking.controllers.matchmaking.brands import utils


@pytest.mark.parametrize('brand', [
    {'name': 'Monkey', 'nameLabel': 'Luffy'},
    {'name': 'Chopper'},
    {'nameLabel': 'Trafaglar'}
])
def test_get_brand_display_name(brand):
    returned_name = utils.get_display_name(brand)

    expected = brand['nameLabel'] if 'nameLabel' in brand else brand.get('name')
    assert returned_name == expected


@pytest.mark.parametrize('brand, expected', [
    ({'source': 'CUSTOMER'}, False),
    ({'source': 'MSCI'}, True),
    ({'source': 'MANUAL'}, True),
    ({'source': 'CUSTOMER', 'verifiedByAdmin': datetime.utcnow()}, True),
    ({'source': 'CUSTOMER', 'verifiedByAdmin': None}, False),
])
def test_is_brand_verified_by_admin(brand, expected):
    assert utils.is_brand_verified_by_admin(brand) == expected
