# -*- coding: utf-8 -*-

from flask import jsonify, request, current_app
from pymongo import ASCENDING
from pymongo.collation import Collation

from matchmaking import auth, public_mm_bp
from .. import root_protected_bp, protected_commerce_bp, secure_commerce_bp
from ..controllers import admin_bp
from ..mongodb import reload_vocabulary, db, VOCAB_V2, VOCAB_V1
from ..s3 import get_cnd_url
from ..utils import get_locale_string, EntityNotFound, dict_merge
from ..permission_decorator import require_admin_permission, require_client_permission

entity_name = 'vocabulary'
target_collection = 'mm_vocabulary'


@root_protected_bp.route('/vocabulary', methods=['GET'])
@secure_commerce_bp.route('/vocabulary', methods=['GET'])
@admin_bp.route('/vocabulary', methods=['GET'])
def admin_list_vocabulary():
    """ Fetch all available Vocabulary """
    version = request.args.get('version', None)
    return jsonify(get_vocabulary(version))


@root_protected_bp.route('/vocabulary/<grouping>', methods=['GET'])
@secure_commerce_bp.route('/vocabulary/<grouping>', methods=['GET'])
@admin_bp.route('/vocabulary/<grouping>', methods=['GET'])
@require_admin_permission
def admin_list_vocabulary_by_type(grouping):
    """ Fetch all Vocabulary from a specific Type """
    return jsonify(list_vocabulary_by_type(grouping))


@admin_bp.route('/vocabulary/reload', methods=['PUT'])
@require_admin_permission
def admin_reload_vocabulary():
    reload_vocabulary()
    return current_app.response_class(status=204)


@protected_commerce_bp.route('/deal/<slug>/vocabulary', methods=['GET'])
def commerce_list_vocabulary(slug):
    """ Fetch all available Vocabulary """
    return jsonify(get_vocabulary(version=2))


@public_mm_bp.route('/vocabulary/<grouping>', methods=['GET'])
@auth.authenticate_with_one_of(
    require_client_permission,
    auth.validate_token_against_collection('mm_brands'),
    auth.validate_token_against_collection('deals'),
)
def commerce_list_vocabulary_by_type(grouping):
    """ Fetch all Vocabulary from a specific Type """
    return jsonify(list_vocabulary_by_type(grouping))


def expand_icon_url(vocabulary):
    try:
        vocabulary['icon'] = get_cnd_url(vocabulary['icon'])
    except KeyError:
        pass  # ignore

    return vocabulary


def transform_all(vocabulary_list):
    result = {}
    for row in vocabulary_list:
        row_type = row['type']
        row_group = row.get('group', None)
        del row['type']
        try:
            if row_group:
                del row['group']
                add_to = result[row_type][row_group]
            else:
                add_to = result[row_type]

            add_to.append(expand_icon_url(row))
        except KeyError:
            if row_group:
                if row_type not in result:
                    result[row_type] = {}

                result[row_type][row_group] = [expand_icon_url(row)]
            else:
                result[row_type] = [expand_icon_url(row)]

    return result


def transform_typed(vocabulary_list):
    result = []
    for row in vocabulary_list:
        row_group = row.get('group', None)

        # change from array to dict
        if row_group and not result:
            result = {}

        try:
            if row_group:
                del row['group']
                add_to = result[row_group]
            else:
                add_to = result

            add_to.append(expand_icon_url(row))
        except KeyError:
            if row_group:
                result[row_group] = [expand_icon_url(row)]
            else:
                result = [expand_icon_url(row)]

    return result


def list_vocabulary_by_type(grouping):
    return get_vocabulary('2', {'type': grouping}, {'type': False, 'versions': False}, transform_typed)


def get_vocabulary(version, types_query={}, projection=None, transform=transform_all):
    vocab_version = VOCAB_V2 if str(version) == '2' else VOCAB_V1
    query = dict_merge({'versions': vocab_version}, types_query)

    vocabulary = list(db().coll_vocabulary.find(query, projection)
                      .sort([('type', ASCENDING),
                             ('group', ASCENDING),
                             ('code', ASCENDING),
                             ('label', ASCENDING)])
                      .collation(Collation(locale=get_locale_string(), numericOrdering=True)))

    if not vocabulary:
        raise EntityNotFound(entity_name)

    # NOTE: Assume transform is generic and can transform vocabulary to a list, dictionary or whatever is needed.
    vocabulary = transform(vocabulary)

    if isinstance(vocabulary, dict) and 'industry' in vocabulary:
        vocabulary['industry'] = sorted(vocabulary['industry'], key=lambda x: (x.get('code'), x['label']))

    return vocabulary
