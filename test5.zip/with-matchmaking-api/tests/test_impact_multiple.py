import json
from matchmaking.service.impact_multiple import ready_for_calc

def test_impact_multiple(client, admin_header, program_id):
    response = client.get('/admin/programs/' + str(program_id), headers=admin_header)
    program = response.data

    response = client.post('/admin/program/impact-multiple:calc', headers=admin_header, data=program)
    score = json.loads(response.data.decode())

    assert score['score'] >= 1


def test_scc_conversion(client, admin_header):
    response = client.get('/admin/program/impact-multiple/scc-conversion', headers=admin_header)

    assert response.status_code == 200
    assert len(json.loads(response.data.decode())) == 27


def test_divisor(client, admin_header):
    response = client.get('/admin/program/impact-multiple/divisor', headers=admin_header)
    assert response.status_code == 200

    divisor = json.loads(response.data.decode())

    index = 0
    while index < len(divisor):
        assert index == divisor[index].get('index')
        assert len(divisor[index].get('value')) == 150
        index += 1

    assert len(divisor) == 101


def map_index(i):
    unit_digits = int(i % 10)
    ten_digits = int(i / 10) * 3

    if unit_digits <= 2:
        unit_digits = 0

    elif 3 <= unit_digits <= 6:
        unit_digits = 1

    elif unit_digits >= 7:
        unit_digits = 2

    return ten_digits + unit_digits


def test_im_validation(client, admin_header):
    program = {
        'Finance': {
            'budgetFile': {
                'value': {
                    'name': 'IMG_4123.JPG',
                    'url': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/IMG_4123_1569253026502.JPG'
                }
            }
        },
        'ImpactAndScope': {
            'additionalLocationDetails': {
                'value': 'County: Punjab'
            },
            'countries': {
                'value': {
                    'selected': ['Asia;Pakistan']
                }
            },
            'protectAndEnhanceForest': {
                'value': False
            },
            'regions': {
                'value': {
                    'selected': ['Asia']
                }
            }
        },
        '_id': '5beded370f36530008cef126',
        'active': True,
        'altLicensing': 'some sample termsaDasd tes',
        'approach': [{
            '_id': '5d44b3b4d5b3a55e9e513cee',
            'evidenceScore': 0.2
        }, {
            '_id': '5d44b3b4d5b3a55e9e513d07',
            'evidenceScore': 0.8
        }, {
            '_id': '5d44b3b4d5b3a55e9e513d20',
            'conversionRateId': '5df7d7b935236e681b139b86',
            'echoOutput': 123213
        }],
        'approachDuration': '5d44b3b4d5b3a55e9e513d27',
        'audienceAge': ['5a99921742073d0946343f9e', '5a99921742073d0946343f9f', '5a99921742073d0946343fa0', '5a99921742073d0946343fa1', '5a99921742073d0946343fa2'],
        'audienceAttribute': ['5a99921742073d0946343fa9', '5a99921742073d0946343fad', '5d44b3b4d5b3a55e9e513cc5'],
        'budget': 12920,
        'cashContributions': 77520,
        'causes': ['5a99921742073d0946343fb2'],
        'cdp': {
            'isCustom': False
        },
        'createdAt': '2018-11-15T22:03:35.261000Z',
        'csrhub': {
            'data': ['5cddf7f1f231fc514d9ea7f1', '5cddf7f1f231fc514d9ea7f5'],
            'isCustom': False
        },
        'dataMeasurementType': '5af48f88a64082a02a943c09',
        'deliverables': {
            'investorCommunications': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/GW_PLATFORM_HEADER_01_1558105863242.jpg',
            'longVideo': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/duck_1557781030992.png',
            'photoGallery': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/heber-galindo-1567018-unsplash-min_1557775084753.jpg',
            'pressRelease': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/Image_from_iOS_1558105899804.jpg',
            'sustainabilityReporting': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/Givewith_1574113850496.png'
        },
        'description': 'The goal of Oxfam’s girls’ education program in Pakistan is to make girls education a national priority through multi-pronged approaches. The program primarily targets girls who are at risk of early marriages or drop-out despite inspiring academic track record. These young girls are living in resource constrained rural areas of Punjab and Sindh. Oxfam envisions a better tomorrow for young Pakistani girls who are at risk of early marriage or drop-out  from school supporting them with scholarships and advocating for girls education. \n\nThe program introduces several approaches to improve enrollment, retention and enhance learning. Oxfam offers competency-based stipends and scholarships to complete the transition from primary to secondary and from secondary to higher education. In addition, the program mobilizes civil society, media and policymakers to put girls education as a priority. Oxfam works to build the capacity of the local government officials of Sindh and Punjab. ',
        'esg': {
            'data': [{
                'issue': '5a99921742073d0946343fe7',
                'key': '1576612056203'
            }, {
                'issue': '5a99921742073d0946343ff4',
                'key': '1576612056203'
            }],
            'isCustom': False
        },
        'evidenceDescription': ['N/A'],
        'gri': {
            'data': ['5a99921742073d0946343ffa', '5aec6b72344200d826997488', '5aec6b72344200d826997489', '5aec6b72344200d82699748d'],
            'isCustom': False
        },
        'ignoreThreshold': True,
        'imageLandscape': 'https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5beded370f36530008cef126/GW_Pakistan_Oxfam_PRG_LND_1536x860_1545611145439.jpg',
        'imagePortrait': 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/GW_Safe-At-Home_Rebuilding-Together_2018_59_of_102_1568656232980.jpg',
        'impactMultiple': 3.14,
        'impactMultipleVisibility': True,
        'inKindContributions': 30000,
        'isValid': True,
        'isValidNonprofit': True,
        'lastUpdated': '2019-12-17T18:13:33.476000Z',
        'name': 'Advance education for girls in Pakistan',
        'nonprofit': '5b30eee0e3dde1001ae17753',
        'nonprofitPartners': True,
        'notes': 'Location: Two major Pakistani provinces of Punjab and Sindh.',
        'outcomes': [{
            'description': 'of women graduate high school',
            'quantity': '100%',
            'key': '1576612056167'
        }],
        'outputs': [{
            'description': 'Girls who transition from Primary School to Secondary School',
            'quantity': 1794,
            'scaleType': '5af4a134a64082a02a943c13',
            'key': '1576612056155'
        }, {
            'description': 'Girls and women who receive Education and Training',
            'quantity': 86133,
            'scaleType': '5af4a134a64082a02a943c13',
            'key': '1576612056156'
        }, {
            'description': 'Gender responsive and disaster resilient school infrastructure provided',
            'quantity': 184,
            'scaleType': '5af4a134a64082a02a943c13',
            'key': '1576612056156'
        }, {
            'description': 'Women and girls receiving enhanced vocational skills and linking with financial institutions',
            'quantity': 8613,
            'scaleType': '5af4a134a64082a02a943c13',
            'key': '1576612056156'
        }, {
            'description': "Public officers trained or educated on policies that improve girls' education",
            'quantity': 430,
            'scaleType': '5af4a134a64082a02a943c13',
            'key': '1576612056156'
        }],
        'participants': 123,
        'preferredByBrands': [{
            '_id': '5d49a739982fbd26dfb1a6b4',
            'name': 'CARLAW CAPITAL III CORP'
        }, {
            '_id': '5d85002ca87e188959c32d86',
            'name': 'Courtneys new company 920'
        }, {
            '_id': '5da64d52d39389e9cef9e7d5',
            'name': 'a new brand'
        }],
        'primaryImpact': ['5a99921742073d094634402b', '5a99921742073d094634402f', '5a99921742073d0946344040', '5aec61bff581061865110ca7'],
        'programApproach': ['5af49c75a64082a02a943c0b', '5af49c75a64082a02a943c0c', '5af49c75a64082a02a943c0d', '5af49c75a64082a02a943c0e'],
        'programStrength': ['High-need audience', 'Long term changes', 'Strategic partners', 'Multiple impacts'],
        'programStrengthRating': 4,
        'sasb': {
            'data': ['5ced8752f231fc16de6d16a6', '5ced8752f231fc16de6d16a8'],
            'isCustom': False
        },
        'screenOneMinimum': 20,
        'sdg': {
            'data': ['5a99921742073d09463440b6', '5a99921742073d09463440b7', '5a99921742073d09463440ba', '5a99921742073d09463440bc'],
            'isCustom': False
        },
        'secondaryImpacts': ['5a99921742073d094634402d', '5aec61bff581061865110ca6', '5d44b3b4d5b3a55e9e513ce7'],
        'selectedByDeals': [{
            '_id': '5dd5b723e01098652629c74a',
            'client': '5c1415685b03bb0008c21b06',
            'clientName': 'AMEX',
            'fundingAmount': 0.03,
            'givewithCustomer': '5c1415685b03bb0008c21b06',
            'givewithCustomerName': 'AMEX',
            'name': 'test email'
        }, {
            '_id': '5dcf049c468e3db763a53f15',
            'client': '5c1415685b03bb0008c222d9',
            'clientName': 'Kezar Life Sciences Inc',
            'fundingAmount': 87.5,
            'givewithCustomer': '5c1415685b03bb0008c21b06',
            'givewithCustomerName': 'AMEX',
            'name': 'gsdfg'
        }, {
            '_id': '5dcef673468e3db763a53ecd',
            'client': '5c1415685b03bb0008c2197c',
            'clientName': 'NIKE, INC.',
            'fundingAmount': 8488.3,
            'givewithCustomer': '5d49a739982fbd26dfb1a6b4',
            'givewithCustomerName': 'CARLAW CAPITAL III CORP',
            'name': 'Test for Emails and Program Manager'
        }, {
            '_id': '5dc9b0f82927a714f3361917',
            'client': '5c1415685b03bb0008c222eb',
            'clientName': 'KLX ENERGY SERVICES HOLDINGS, INC.',
            'fundingAmount': 15750,
            'givewithCustomer': '5d49a739982fbd26dfb1a6b4',
            'givewithCustomerName': 'CARLAW CAPITAL III CORP',
            'name': 'Anotha one'
        }, {
            '_id': '5dc99d972927a714f33618f6',
            'client': '5c33a0f15b03bb000929b07f',
            'clientName': 'IBM',
            'fundingAmount': 0.03,
            'givewithCustomer': '5c1415685b03bb0008c21b06',
            'givewithCustomerName': 'AMEX',
            'name': '1'
        }, {
            '_id': '5dc330ebbbce2052093b167a',
            'client': '5c1415685b03bb0008c21e1d',
            'clientName': 'TARGET CORPORATION',
            'fundingAmount': 19250,
            'givewithCustomer': '5d49a739982fbd26dfb1a6b4',
            'givewithCustomerName': 'CARLAW CAPITAL III CORP',
            'name': 'program test'
        }, {
            '_id': '5dc33033a4fa0ca384f33ffe',
            'client': '5c1415685b03bb0008c21ba2',
            'clientName': 'CITIGROUP INC.',
            'fundingAmount': 15750,
            'givewithCustomer': '5c1415685b03bb0008c21adf',
            'givewithCustomerName': 'AMERICAN AIRLINES GROUP INC. ',
            'name': 'confirmation test 1'
        }, {
            '_id': '5dc32d66bbce2052093b166f',
            'client': '5c1415685b03bb0008c21ba2',
            'clientName': 'CITIGROUP INC.',
            'fundingAmount': 15750,
            'givewithCustomer': '5d49a739982fbd26dfb1a6b4',
            'givewithCustomerName': 'CARLAW CAPITAL III CORP',
            'name': 'Legal Test'
        }, {
            '_id': '5da6325b09555099eee5d089',
            'client': '5c1415685b03bb0008c21e1d',
            'clientName': 'TARGET CORPORATION',
            'fundingAmount': 3500,
            'givewithCustomer': '5c61c84cd5b3a57eab70aea1',
            'givewithCustomerName': 'SAP SE',
            'name': 'test email flow oct 15'
        }, {
            '_id': '5da5fc5eae42af61b70fbcd7',
            'client': '5c1415685b03bb0008c222e4',
            'clientName': 'Rubius Therapeutics Inc',
            'fundingAmount': 3500,
            'givewithCustomer': '5c1415685b03bb0008c21bdb',
            'givewithCustomerName': 'DELTA AIR LINES, INC.',
            'name': 'test emails oct 15'
        }, {
            '_id': '5d9c9cbc9208f31b6cd7e914',
            'client': '5d49c8e6982fbd2ac5f7f7a0',
            'clientName': 'IBMC CHINA AG',
            'fundingAmount': 1234,
            'givewithCustomer': '5c1415685b03bb0008c21b06',
            'givewithCustomerName': 'AMEX',
            'name': 'testing email confirmation fields'
        }, {
            '_id': '5d7fc16ed5b3a511050b637e',
            'client': '5d49c8e6982fbd2ac5f7f7a0',
            'clientName': 'IBMC CHINA AG',
            'fundingAmount': 123,
            'givewithCustomer': '5c1415685b03bb0008c21b06',
            'givewithCustomerName': 'AMEX',
            'name': 'testing email service'
        }, {
            '_id': '5cd9dbead5b3a5252274c155',
            'client': '5c1415685b03bb0008c21b06',
            'clientName': 'AMEX',
            'fundingAmount': 100,
            'givewithCustomer': '5c1415685b03bb0008c222dc',
            'givewithCustomerName': 'Translate Bio Inc',
            'name': 'testing deliverables copying'
        }, {
            '_id': '5cd9d57cd5b3a52521d52b3e',
            'client': '5c3368ed6bf7b300084d2e09',
            'clientName': 'Borden Dairy',
            'fundingAmount': 10,
            'givewithCustomer': '5c1415685b03bb0008c222eb',
            'givewithCustomerName': 'KLX ENERGY SERVICES HOLDINGS, INC.',
            'name': 'testing legal docs'
        }, {
            '_id': '5ccb2467d5b3a547d9fba4fc',
            'client': '5c7965efd5b3a53b66cad62b',
            'clientName': 'courtney test',
            'fundingAmount': 100,
            'givewithCustomer': '5c2f760d6bf7b300084cc751',
            'givewithCustomerName': 'Siri test',
            'name': 'test pw'
        }, {
            '_id': '5cb0b654d5b3a56ddc33bf58',
            'client': '5c1415685b03bb0008c222d8',
            'clientName': 'ESSENTIAL PROPERTIES REALTY TRUST, INC.',
            'fundingAmount': 2,
            'givewithCustomer': '5c1415685b03bb0008c222e1',
            'givewithCustomerName': 'Liquidia Technologies Inc',
            'name': 'q'
        }],
        'slug': 'x-6',
        'tempImpactMultiple': 0,
        'themes': {
            'data': ['5c07d2a0b5162e2144e658d6', '5c07d2a0b5162e2144e658cf', '5d44b3b4d5b3a55e9e513ce0', '5d44b3b4d5b3a55e9e513cd9', '5d44b3b4d5b3a55e9e513ce1', '5d44b3b4d5b3a55e9e513cd3', '5d44b3b4d5b3a55e9e513cdb', '5d44b3b4d5b3a55e9e513cd6', '5d44b3b4d5b3a55e9e513cd5', '5d44b3b4d5b3a55e9e513cd2'],
            'isCustom': True
        },
        'version': 2,
        'approachIds': ['5d44b3b4d5b3a55e9e513cee', '5d44b3b4d5b3a55e9e513d07', '5d44b3b4d5b3a55e9e513d20']
    }

    assert ready_for_calc(program)
