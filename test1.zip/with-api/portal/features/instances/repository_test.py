from portal.shared.repositories import instance_settings_repository


class TestInstanceSettingsRepository:
    def test_instance_associated_with_ca(self, repositories, fakers):
        # generate cause area
        ca_repo = repositories['cause_area']
        new_ca = fakers.cause_area.generate_new()
        cause_area = ca_repo.insert(new_ca)
        # generate new instance
        instance_repo = repositories['instance_settings']
        new_instance = fakers.instance_settings.generate_new()
        # set cause area in instance to above generated cause area
        new_instance['causeAreas'][0]['causeArea']['_id'] = cause_area['_id']
        instance = instance_repo.insert(new_instance)
        data = instance_settings_repository().get_associated(cause_area['_id'])
        assert str(data['ID'][0]) == str(instance['_id'])

    def test_instance_not_associated_with_ca(self, repositories, fakers):
        # generate cause area
        ca_repo = repositories['cause_area']
        new_ca = fakers.cause_area.generate_new()
        cause_area = ca_repo.insert(new_ca)
        # generate new instance
        instance_repo = repositories['instance_settings']
        new_instance = fakers.instance_settings.generate_new()
        instance = instance_repo.insert(new_instance)
        data = instance_settings_repository().get_associated(cause_area['_id'])
        assert str(data['ID']) == str({})
