from app.rest.cognito_authorize import auth_bp
from app.rest.cognito_user import user_bp, revoke_bp
from app.rest.health_checks import health_check_bp
from app.rest.okta_auth import okta_bp
from app.rest.okta_user import okta_user_bp
from app.rest.saml_idp import saml_bp
from app.rest.saml_sp import saml_sp_bp
from app.rest.sales_force import salesforce_bp


def register_blueprints(app):
    app.register_blueprint(health_check_bp, url_prefix='/')

    # cognito endpoints
    app.register_blueprint(auth_bp, url_prefix='/v1/authorize')
    app.register_blueprint(user_bp, url_prefix='/v1/user')
    app.register_blueprint(revoke_bp, url_prefix='/v1/revoke')

    # okta endpoints
    app.register_blueprint(okta_bp, url_prefix='/v1/okta')
    app.register_blueprint(okta_user_bp, url_prefix='/v1/okta/user')

    # saml endpoints
    app.register_blueprint(saml_bp, url_prefix='/v1/saml')
    app.register_blueprint(saml_sp_bp, url_prefix='/v1/saml/sp')

    # salesforce endpoints
    app.register_blueprint(salesforce_bp, url_prefix='/v1/sf')
