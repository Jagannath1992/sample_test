yum -y groupinstall "Development Tools"
yum -y install gcc
yum -y install python3
yum -y install python3-devel.x86_64
su ec2-user -c 'pip3 install --user gunicorn'
su ec2-user -c 'pip3 install --user numpy'
su ec2-user -c 'pip3 install --user scipy'
su ec2-user -c 'pip3 install --user matplotlib'
su ec2-user -c 'pip3 install --user ipython'
su ec2-user -c 'pip3 install --user jupyter'
su ec2-user -c 'pip3 install --user pandas'
su ec2-user -c 'pip3 install --user sympy'
su ec2-user -c 'pip3 install --user nose'
