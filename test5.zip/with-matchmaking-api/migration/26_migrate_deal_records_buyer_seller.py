from matchmaking import db


for deal in db().coll_deals.find({}):
    gw_customer_role = deal['givewithCustomerRole'].lower()

    # safeguard for running migration more than once
    if 'buyer' in deal and 'seller' in deal:
        if gw_customer_role == 'buyer':
            deal['givewithCustomer'] = deal.pop('buyer')
            deal['client'] = deal.pop('seller')

        elif gw_customer_role == 'seller':
            deal['givewithCustomer'] = deal.pop('seller')
            deal['client'] = deal.pop('buyer')

    # these are stale fields we don't use anymore that are left over
    deal.pop('buyerName', None)
    deal.pop('sellerName', None)
    deal.pop('whoSelectsProgram', None)
    deal.pop('sellerPassword', None)
    deal.pop('clientPassword', None)

    db().coll_deals.find_one_and_replace({'_id': deal['_id']}, deal)


# REVERSE MIGRATION ##########33
# for deal in db().coll_deals.find():
#     gw_customer_role = deal['givewithCustomerRole'].lower()

#     if 'givewithCustomer' in deal and 'client' in deal:
#         if gw_customer_role == 'buyer':
#             deal['buyer'] = deal.pop('givewithCustomer')
#             deal['seller'] = deal.pop('client')

#         elif gw_customer_role == 'seller':
#             deal['seller'] = deal.pop('givewithCustomer')
#             deal['buyer'] = deal.pop('client')
