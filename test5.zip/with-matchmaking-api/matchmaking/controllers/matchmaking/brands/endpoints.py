# -*- coding: utf-8 -*-
import re

from copy import deepcopy
from flask import jsonify, request, current_app, send_file
import pymongo
from werkzeug.utils import secure_filename
from pymongo import ReturnDocument
from pymongo.collation import Collation
from tempfile import TemporaryFile

from matchmaking import auth
from matchmaking.service.email import ADMIN_URL
from matchmaking.service.slack import send_new_brand_message
from matchmaking.service.recommendations import get_brand_recommended_programs
from matchmaking.validation.utils import validate_object_id
from matchmaking.dao.utils import update_document_by_id, get_document_by_id
from matchmaking.s3 import upload_file, delete_file, save_custom_deliverable_to_s3, download_file
from .utils import *
from .. import public_mm_bp
from ....models.models import v, schema_brand, schema_brand_ui, to_bool
from ....controllers import admin_bp
from ....data_providers.nielsen import get_consumer_preferences_from_brand
from ....mongodb import (ObjectId, set_vocabulary, db, get_location_data, get_filtered_nielsen_respondents,
                         get_nielsen_responses, get_tvl_data)
from ....triggers import set_brand_parents_is_valid, remove_blacklisted_nonprofit_programs_from_associated_deals
from ....permission_decorator import require_admin_permission, require_client_permission
from ....utils import (generate_secure_password, remove_empty, set_created_at, set_last_updated, get_locale_string,
                       get_descendant_key, EntityNotFound, UnsupportedId, UnsupportedPayload, ValidationError,
                       create_validation_error_response, generate_random_slug, set_descendant_key, set_last_updated_by)

ENTITY_NAME = 'brand'
TARGET_COLLECTION = 'mm_brands'


##
# Protected Endpoints
##
@admin_bp.route('/brands', methods=['GET'])
@require_admin_permission
def admin_list_brands():
    """ List all available Brands
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    parameters:
        - in: query
          name: offset
          schema:
            type: integer
          description: Number of itens to skip
        - in: query
          name: limit
          schema:
            type: integer
          description: Number of itens to return

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                type: object
                properties:
                  _id:
                    type: string
                  name:
                    type: string
                  slug:
                    type: string
                  hasAnalysis:
                    type: boolean
                  lastUpdated:
                    type: string
                    format: date-time
                  source:
                    type: string
                  msci.lastImported:
                    type: string
                    format: date-time
                  msci.industry:
                    type: string
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    projection = {
        '_id': True,
        'name': True,
        'nameLabel': True,
        'slug': True,
        'industry': True,
        'hasAnalysis': True,
        'lastUpdated': True,
        'lastUpdatedBy': True,
        'source': True,
        'msci.lastImported': True,
        'msci.industry': True,
        'verifiedByAdmin': True,
    }
    brands = list(db().coll_brands.find(request.filter_params, projection=projection).skip(request.skip).limit(request.page_size).collation(Collation(locale=get_locale_string(), numericOrdering=True)).sort(request.sort_params))

    total_brands_count = db().coll_brands.count_documents({})

    for brand in brands:
        brand['industry'] = get_brand_industry_id(brand)

    return jsonify(
        {
            'brands': brands,
            'activeBrandsCount': len(brands),
            'totalBrandsCount': total_brands_count
        })


@admin_bp.route('/brands/search', methods=['GET'])
@require_admin_permission
def admin_search_brands():
    """Search Brands Admin
    """
    additional_fields = ['proposalOptions', 'lastUpdated', 'source', 'givewithManager',
      'givePercentageType', 'customGivePercentage', 'givewithFeePercentage']
    return search_brands(additional_fields)


@public_mm_bp.route('/brands/search', methods=['GET'])
@auth.authenticate_with_one_of(
    require_client_permission, auth.validate_token_against_collection('supplier_analysis_reports')
)
def client_search_brands():
    """Search Brands Client
    """
    return search_brands()


@admin_bp.route('/brands/<id>', methods=['GET'])
@require_admin_permission
def admin_get_brand_by_id(id):
    """ Fetch Brand data
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Brand'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    brand = db().coll_brands.find_one({'_id': obj_id})
    if not brand:
        raise EntityNotFound(ENTITY_NAME, id)

    # transform external data onto brand
    # NOTE: This step should be done before sdgs and nonprofits are transformed
    brand.update(wrap_csrit(brand))

    if 'industry' in brand:
        brand['industryName'] = brand['industry']
        brand['industry'] = get_brand_industry_id(brand)

    brand['insights'] = format_insights(brand)
    brand['nonprofits'] = format_nonprofits(brand.get('nonprofits', None))

    brand['sdg'] = format_metrics_to_ids(brand, 'sdg')
    brand['cdp'] = format_metrics_to_ids(brand, 'cdp')
    brand['gri'] = format_metrics_to_ids(brand, 'gri')

    if 'sasb' in brand:
        brand['sasb'] = format_sasb_to_ids(brand)

    brand['proposals'] = get_proposals_for_brand(brand)
    # selected brands intentionally left blank below
    if 'industry' in brand:
        brand['consumer_preferences'] = get_consumer_preferences_from_brand(brand, [])

    brand = clean_brand(brand)

    if 'ISIN' in brand:
        sasbIds = brand.get('sasb', [])
        isin_id = brand['ISIN']
        brand['tvl'] = get_tvl_data(isin_id, sasbIds)

    brand['parent_brand_names'], brand['child_brand_names'] = get_related_brand_names(brand)

    if not brand.get('preferredPrograms'):
        brand['preferredPrograms'] = {
          'editing': False,
          'cart': [],
          'selected': [],
          'additional': [],
        }
    else:
        selected_programs = brand.get('preferredPrograms', {}).get('selected', [])
        if selected_programs:
            programs_list = list(db().coll_programs.find( { '_id': { '$in': selected_programs } }, projection={'_id' : True, 'slug': True, 'name': True, 'nonprofit': True }))

            for program in programs_list:
                program.update({'nonprofit' : get_nonprofit_by_id(program.get('nonprofit')).get('name')})
            brand['preferredPrograms']['selected'] = programs_list

        additional_programs = brand.get('preferredPrograms', {}).get('additional', [])
        if additional_programs:
            programs_list = list(db().coll_programs.find( { '_id': { '$in': additional_programs } }, projection={'_id' : True, 'slug' : True, 'name': True, 'nonprofit': True }))

            for program in programs_list:
                program.update({'nonprofit' : get_nonprofit_by_id(program.get('nonprofit')).get('name')})
            brand['preferredPrograms']['additional'] = programs_list

    if not brand.get('awards'):
        brand['awards'] = []
    else:
        brand_awards = brand.get('awards')
        if brand_awards:
            for brand_award in brand_awards:
                award = db().coll_award.find_one({ '_id': brand_award["award_id"]})
                brand_award["name"] = award["name"]

    if 'industry' in brand:
        brand['recommendedPrograms'] = get_brand_recommended_programs(brand, include_invalid=True)

    return jsonify(check_and_set_valid_for_dummy(brand))


@admin_bp.route('/brands', methods=['POST'])
@require_client_permission
def insert_brand(brand=None, public=False):

    """ Create new Brand
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Brand'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Brand'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    if brand:
        document = brand
    else:
        document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    if 'name' not in document:
        return create_validation_error_response('name')

    if request.origin != ADMIN_URL or request.origin != "http://localhost:8080":
        from_sales = True
    else:
        from_sales = False

    document.pop('_id', None)

    document['slug'] = generate_random_slug()
    set_recommendations(document)
    set_custom_investor_metrics(document)

    if document.get('source', '').lower() != 'customer':
        document['source'] = 'MANUAL'
    set_brand_parents_is_valid(document)

    document = v.normalized(document, schema_brand_ui)
    if v.errors:
        raise ValidationError(v.errors)

    be_document = deepcopy(document)
    be_document = from_ui_to_be(be_document, {})

    be_document['isValid'] = v.validate(be_document, schema_brand)

    if hasattr(request, 'user'):
        be_document['lastUpdatedBy'] = {
            '_id': request.user['_id'],
            'name': request.user['name'],
            'username': request.user['username']
        }

    if v.errors:
        current_app.logger.warning('Brand validation error: %s', v.errors)

    inserted_id = db().coll_brands.insert_one(set_created_at(be_document)).inserted_id
    be_document['_id'] = inserted_id

    # If brand was created, add brand to it's parents and children
    if inserted_id:
        update_brand_relations(be_document, {})

    document['_id'] = be_document['_id']
    document['isValid'] = be_document['isValid']
    document['createdAt'] = be_document['createdAt']
    if public and from_sales:
        send_new_brand_message(True, {'_id': be_document['_id'], 'name': be_document['name']}, from_sales=from_sales)
    return jsonify(check_and_set_valid_for_dummy(document))


@public_mm_bp.route('/brands', methods=['POST'])
@auth.validate_token_against_collection('supplier_analysis_reports')
def create_brands_customer():
    """Create Customer suggested Brand(s)

        Sample Request:
        [
            {'name': 'brand_name_0', 'industry': 'industry_name_0'}
            {'name': 'brand_name_1', 'industry': 'industry_name_1'}
            {'name': 'brand_name_2'}
        ]

        Sample Response:
        {
            '_ids': ['brand_id_0', 'brand_id_1'],
            'failed': [
                {
                    'payload': {'name': 'brand_name_2'},
                    'error': 'industry is missing'
                }
            ]
        }
    """
    document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    brand_template = lambda brand: {
        'name': brand['name'],
        'industry': brand['industry'],
        'source': 'CUSTOMER',
        'preferredPrograms': {'editing': False, 'cart': [], 'selected': [], 'additional': []}
    }

    brands = {'_ids': [], 'failed': []}
    for new_brand in document:
        try:
            brand = insert_brand.__wrapped__(brand_template(new_brand)).get_json()
            brands['_ids'].append(brand['_id'])

            current_app.logger.info(f'New brand created: {brand["_id"]}')
            send_new_brand_message(True, {'_id': brand['_id'], 'name': brand['name']})
        except Exception as error:
            brands['failed'].append({'payload': new_brand, 'error': str(error)})

            current_app.logger.error(f'Customer brand creation failed: {new_brand}, Error: {error}')
            send_new_brand_message(False, new_brand)

    return jsonify(brands)


@admin_bp.route('/brands/<id>', methods=['PATCH'])
@require_admin_permission
def patch_brand(id):
    """ Update Brand
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Brand'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Brand'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    if 'name' not in document:
        return create_validation_error_response('name')

    set_recommendations(document)
    set_custom_investor_metrics(document)
    document = set_vocabulary(document)
    remove_empty(document)

    try:
        #  fail-safe
        document.pop('_id', None)
    except KeyError:
        pass  # ignore

    db_document = db().coll_brands.find_one({'_id': ObjectId(id)})

    is_brand_verified = is_brand_verified_by_admin(db_document)
    if not is_brand_verified and document.get('verifiedByAdmin'):
        document['verifiedByAdmin'] = datetime.utcnow()
    else:
        document.pop('verifiedByAdmin', None)

    document['isValid'] = v.validate(document, schema_brand, True)

    # overwrite un-editable fields
    document['name'] = db_document['name']
    document['iname'] = db_document['iname']

    if (db_document['source'] != 'MANUAL'):
        document['ISIN'] = db_document['ISIN']

    if 'slug' in document:
        document['slug'] = db_document.get('slug') or document['slug']

    document['searchString'] = create_search_string(document)

    if v.errors:
        current_app.logger.warning('Brand validation error: %s', v.errors)

    document.pop('createdAt', None)

    document['lastUpdatedBy'] = {
        '_id': request.user['_id'],
        'name': request.user['name'],
        'username': request.user['username']
    }

    set_brand_parents_is_valid(document)
    updated_document = db().coll_brands.find_one_and_update({'_id': ObjectId(id)},
                                                       {'$set': set_last_updated(document)},
                                                       return_document=ReturnDocument.AFTER)

    update_brand_relations(updated_document, db_document)

    return admin_get_brand_by_id(id)


@admin_bp.route('/brands/<id>', methods=['PUT'])
@require_admin_permission
def update_brand(id):
    """ Replace Brand data
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Brand'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Brand'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """

    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    formatted_document = request.get_json()
    if not formatted_document:
        raise UnsupportedPayload()

    if 'name' not in formatted_document:
        return create_validation_error_response('name')

    if 'msci' in formatted_document:
        formatted_document.pop('msci')

    db_document = db().coll_brands.find_one({'_id': obj_id})

    parsed_industry = handle_industry(formatted_document['industry'])
    if  'industry' in db_document and parsed_industry != db_document['industry']:
        if formatted_document.get('insights', {}).get('themes'):
            formatted_document['insights']['themes'] = reset_brand_themes(formatted_document)

    set_recommendations(formatted_document)
    set_custom_investor_metrics(formatted_document)

    formatted_document['_id'] = obj_id
    if 'createdAt' in db_document:
        formatted_document['createdAt'] = db_document['createdAt']
    else:
        formatted_document['createdAt'] = db_document['_id'].generation_time

    # overwrite un-editable fields
    formatted_document['iname'] = db_document['iname']
    formatted_document['name'] = db_document['name']
    formatted_document['slug'] = db_document['slug']

    if db_document['source'] not in ['MANUAL', 'CUSTOMER']:
        formatted_document['ISIN'] = db_document.get('ISIN', '')
        if not db_document.get('ISIN'):
            current_app.logger.warning(f"Brand {obj_id} was found without an isin and a source of {db_document['source']}. It is probably stale")

    formatted_document['searchString'] = create_search_string(formatted_document)

    set_brand_parents_is_valid(formatted_document)
    set_last_updated(formatted_document)


    # Verfication for "other" (incomplete) brand creation
    is_brand_verified = is_brand_verified_by_admin(db_document)
    if not is_brand_verified and formatted_document.get('verifiedByAdmin'):
        formatted_document['verifiedByAdmin'] = datetime.utcnow()
    else:
        formatted_document.pop('verifiedByAdmin', None)

    formatted_document['lastUpdatedBy'] = {
        '_id': request.user['_id'],
        'name': request.user['name'],
        'username': request.user['username']
    }

    if 'sasb' in formatted_document:
        formatted_document['sasb'] = db_document['sasb']

    formatted_document.pop('recommendedPrograms', None)

    if 'preferredPrograms' in formatted_document:
        remove_blacklisted_nonprofit_programs_from_brand(formatted_document)
        formatted_document['preferredPrograms'] = formatPreferredPrograms(formatted_document.get('preferredPrograms'))

    pp = formatted_document['preferredPrograms']
    if pp.get('selected') and db_document['preferredPrograms'].get('editing') == False and pp.get('editing') == True:
      pp['cart'] = pp.get('selected')

    formatted_document = deepcopy(formatted_document)

    formatted_document = from_ui_to_be(
        formatted_document, msci_data=db_document.get('msci', {}))


    if 'insights' in formatted_document.keys():
        formatted_document.pop('insights')
    # NOTE: This action should be done only after sdgs and nonprofits are transformed
    formatted_document.update(unwrap_csrit(formatted_document, db_document))

    formatted_document['isValid'] = v.validate(formatted_document, schema_brand)
    if v.errors:
        current_app.logger.warning('Brand validation error: %s', v.errors)

    normalized_document = v.normalized(formatted_document, schema_brand)
    if v.errors:
        current_app.logger.warning('Brand normalization error: %s', v.errors)

    result = db().coll_brands.update_one(
        {'_id': obj_id},
        {'$set': normalized_document})

    if result.modified_count > 0:
        update_brand_relations(normalized_document, db_document)
        remove_blacklisted_nonprofit_programs_from_associated_deals(normalized_document)

    return admin_get_brand_by_id(obj_id)

@admin_bp.route('/brands/<brand_id>/outreach-material', methods=['PUT'])
@require_admin_permission
def upload_outreach_material(brand_id):
    """ Upload Outreach Material Deliverable
    """
    validate_object_id(brand_id, 'mm_brands')

    if 'file' not in request.files:
        return 'file not found', 400

    file = request.files['file']
    if file.filename == '':
        return 'invalid file name', 400

    brand = get_document_by_id('mm_brands', brand_id, projection=['outreachMaterials'])

    file = request.files['file']
    url = save_custom_deliverable_to_s3(file, 'brands/%s/outreach-material/%s' % (brand_id, secure_filename(file.filename)))

    payload = request.form

    key = payload.get('key', '')
    outreach_materials = brand.get('outreachMaterials', [])

    does_key_exist = False

    for material in outreach_materials:
        if material['key'] == key:
            material['name'] = payload.get('name', '')
            material['fileName'] = payload.get('icon', '')
            material['description'] = payload.get('icon', '')
            material['display'] = to_bool(payload.get('display')) if payload.get('display') else False
            if url != '':
                material['url'] = url

            does_key_exist = True
            break

    if not does_key_exist:
        new_outreach_material = {
            'display': to_bool(payload.get('display')) if payload.get('display') else False,
            'name': payload.get('name', ''),
            'description': payload.get('description', ''),
            'fileName': payload.get('fileName', ''),
            'url': url,
            'key': payload.get('key', '')
        }

        if brand.get('outreachMaterials'):
            brand['outreachMaterials'].append(new_outreach_material)
        else:
            brand['outreachMaterials'] = [new_outreach_material]

    update_document_by_id('mm_brands', brand_id, brand)

    return admin_get_brand_by_id(brand_id)

@admin_bp.route('/brands/<brand_id>/outreach-material/<key>', methods=['GET'])
@require_admin_permission
def download_outreach_material(brand_id, key):
    """ Download Outreach Material
    """
    validate_object_id(brand_id, 'mm_brands')

    brand = get_document_by_id('mm_brands', brand_id, projection=['outreachMaterials'])

    file = TemporaryFile()

    outreach_materials = brand.get('outreachMaterials', [])
    for material in outreach_materials:
        if material['key'] == key:
            url = material['url']
            download_file(url, file, is_public=False)

            attachment_filename = url.rsplit('/', 1)[-1]
            if material.get('fileName'):
                attachment_filename = material.get('fileName')

            response = send_file(file, as_attachment=True, attachment_filename=attachment_filename, cache_timeout=0)
            return response

    return 'key not found', 400


@admin_bp.route('/brands/<id>', methods=['DELETE'])
@require_admin_permission
def delete_brand(id):
    """ Remove Brand
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Brand'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_brands.find_one_and_delete({'_id': obj_id})
    return jsonify(deleted_document)


##
# Public Endpoints
##
@public_mm_bp.route('/brands/<id_or_slug>')
def get_brand_by_id(id_or_slug):
    """ Fetch Brand data
    ---
    tags: ['Brand Public']

    parameters:
      - name: id_or_slug
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                $ref: '#/components/schemas/PublicBrand'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    _filter = {}

    try:
        _filter['_id'] = ObjectId(id_or_slug)
    except InvalidId:
        _filter['slug'] = id_or_slug

    brand = db().coll_brands.find_one(filter=_filter,
                                      projection={'name': True,
                                                  'nameLabel': True,
                                                  'slug': True,
                                                  'industry': True,
                                                  'isValid': True})

    brand = check_and_set_valid_for_dummy(brand)
    if not brand or brand.get('isValid', False) is False:
        raise EntityNotFound(ENTITY_NAME)

    del brand['isValid']

    return jsonify(brand)


@admin_bp.route('/locations')
@require_admin_permission
def get_locations():
    return jsonify(get_location_data())


@admin_bp.route('/demographics', methods=['POST'])
@require_admin_permission
def get_demographics():
    payload = request.get_json()

    if not payload:
        raise UnsupportedPayload()

    if 'demographicFilter' not in payload:
        return create_validation_error_response('demographicFilter')

    demographic_filters = request.get_json().get('demographicFilter', '')
    index = demographic_filters.pop('index', '')
    selected_themes = demographic_filters.pop('selected_themes', [])
    selected_theme_ids = [t['valueId'] for t in selected_themes]
    filtered_respondents = get_filtered_nielsen_respondents(demographic_filters)
    filtered_respondents_count = filtered_respondents.count()
    filtered_respondents_ids = set(filtered_respondents.distinct('respondent_id'))
    themes_count = get_nielsen_responses(filtered_respondents_ids)
    total_respondents = db().coll_nielsen_respondents.count()

    themes_vocab = db().coll_vocabulary.find({'_id': {'$in': list(themes_count.keys())}})

    themes_count_labels = {str(item.get('_id')): themes_count[item.get('_id')] for item in themes_vocab}

    demographic_data = {'sample_size': filtered_respondents_count,
                        'index': index,
                        'total_respondents': total_respondents,
                        'themes': themes_count_labels,
                        'selected_themes': selected_theme_ids}

    return jsonify(demographic_data)



@admin_bp.route('/brands/<brand_id>/themes', methods=['GET'])
@require_admin_permission
def list_brands_themes(brand_id):
    """ List themes and relevancies for an industry of a given brand
      ---
      tags: ['Brand Admin']

      security:
        - GivewithAuth: []

      parameters:
          - in: path
            name: brand_id
            schema:
              type: string
            description: Id of the brand
      responses:
        200:
          description: Success
          content:
            application/json:
              schema:
                type: array
                items:
                  type: object
                  properties:
                    theme:
                        type: string
                    relevancy:
                        type: integer
      """

    brand = db().coll_brands.find_one(filter={"_id": ObjectId(brand_id)})

    industry = brand.get('industry')

    themes = get_themes_by_industry(industry)

    return jsonify(themes)


@admin_bp.route('/brands/<_id>/upload', methods=['POST'])
@require_admin_permission
def brand_upload_file(_id):
    validate_object_id(_id, 'mm_brands')

    if 'file' not in request.files:
        raise UnsupportedPayload('file is missing')

    file = request.files['file']
    if file.name == '':
        raise UnsupportedPayload('file is missing')

    if 'field' not in request.form:
        return create_validation_error_response('field')

    url = upload_file(file, f'{ENTITY_NAME}/%s/%s' % (_id, secure_filename(file.filename)))
    updates = {}
    set_descendant_key({'name': file.filename, 'url': url}, updates, request.form['field'])

    updated_document = update_document_by_id('mm_brands', _id, updates)

    return jsonify(updated_document)


@admin_bp.route('/brands/<_id>/<field>/<file_name>', methods=['DELETE'])
@require_admin_permission
def brand_delete_file(_id, field, file_name):
    validate_object_id(_id, 'mm_brands')

    document = get_document_by_id('mm_brands', _id, projection=[field])
    file_url = get_descendant_key(document, f'{field}.url', None)

    if file_url is None:
        raise GivewithError(f'Field {file_name} not found in document {_id}')

    if not file_url.endswith(file_name):
        raise GivewithError(f'File {file_name} on document {_id} is not on field {field}')

    if not delete_file(ENTITY_NAME, _id, file_name):
        raise GivewithError(f'Unable to delete {file_name} of document {_id}')

    updated_document = update_document_by_id('mm_brands', _id, {}, deletions=[field])
    return jsonify(updated_document)


@admin_bp.route('/brands/<_id>/preferred-programs/password', methods=['POST'])
@require_admin_permission
def generate_preferred_programs_password(_id):
    """
      Generate Preferred Programs Password
    """
    validate_object_id(_id, 'mm_brands')

    updates = {'preferredPrograms.password': generate_secure_password()}
    updated_document = update_document_by_id('mm_brands', _id, set_last_updated_by(updates))

    return jsonify(updated_document)


def get_nonprofit_by_id(nonprofit_id):
    nonprofit = db().coll_nonprofits.find_one(filter={'_id': ObjectId(nonprofit_id)})
    if not nonprofit:
        raise EntityNotFound('nonprofit_id')

    return nonprofit


def search_brands(additional_fields=[]):
    from_sales = request.args.get('sales') == 'true'
    search_query = request.args.get('query', '').lower()
    limit = int(request.args.get('limit', 50))
    offset = int(request.args.get('offset', 0))
    sasb = request.args.get('sasb') != 'false'

    brand_fields = [
        '_id', 'name', 'nameLabel', 'industry', 'msci.industry', 'verifiedByAdmin'
    ] + additional_fields

    brands = []
    if search_query:
        search_query = re.escape(search_query)
        query = {'searchString': {'$regex': f'.*{search_query}.*'}}
        if from_sales:
            return search_brands_for_sales(brand_fields, search_query, limit, offset)
        if not sasb:
            query['source'] = {'$ne': 'SASB'}

        cursor = db().coll_brands.find(
            query, projection=brand_fields
        ).collation(Collation(locale=get_locale_string(), numericOrdering=True))

        if offset:
            cursor = cursor.skip(offset)
        if limit:
            cursor = cursor.limit(limit)

        if not cursor:
            raise EntityNotFound(ENTITY_NAME)

    for brand in cursor:
        brand['industry'] = get_brand_industry_id(brand)
        brand['verifiedByAdmin'] = is_brand_verified_by_admin(brand)
        brands.append(brand)

    return jsonify({
        'brands': list(brands),
        'limit': limit,
        'offset': offset
    })

def search_brands_for_sales(brand_fields, search_query, limit, offset):
      brand_fields.append("msci.score")
      projects_pipeline = {
          "$project": {brand: 1 for brand in brand_fields}
        }
      match_pipeline = {
          "$match": {
            "$or": [{ "name": {'$regex': f'.*{search_query}.*'}}, { "iname": {'$regex': f'.*{search_query}.*'}}]
          }
        }
      limit_pipeline = { "$limit": limit }
      add_social_impact_pipelines = {
          "$addFields": {
            "has_social_impact_rating": {
              "$cond": [{"$not": ["$msci.score"]}, "false", "true"]
            }
          }
        }
      offset_pipeline = { '$skip': offset }
      sort_pipeline = {
          "$sort": {
            "has_social_impact_rating": pymongo.DESCENDING,
            "award_count": pymongo.DESCENDING,
            "name": pymongo.ASCENDING
            }
        }
      pipeline = [
        match_pipeline,
        projects_pipeline,
        limit_pipeline,
        offset_pipeline,
        add_social_impact_pipelines,
        sort_pipeline
      ]
      brand_collection = db().coll_brands.aggregate(pipeline)
      if not brand_collection:
        raise EntityNotFound(ENTITY_NAME)
      return jsonify({
        'brands': list(brand_collection),
        'limit': limit,
        'offset': offset
      })
