from matchmaking import db

db().coll_deals.update_many(filter={'type': {'$exists': False}}, update={'$set': {'type': 'enterprise'}})
