import json
from unittest.mock import MagicMock
import pytest
from bson import ObjectId


def test_asset_unit_no_url(client, client_header):
    # no url provided
    response = client.get('/asset/download', headers=client_header)
    data = response.data.decode()
    assert 'No url provided' in data
    assert response.status_code == 404


def test_asset_unit_invalid_url(client, client_header):
    # invalid url provided
    response = client.get('/asset/download?url=hey', headers=client_header)
    data = response.data.decode()
    assert 'Not a valid url' in data
    assert response.status_code == 404


def test_asset_unit_invalid_platform(client, client_header):
    # platform string is not accepted
    response = client.get('/asset/download?url=https%3A%2F%2Fstaging-simian-media.s3.amazonaws.com%2F5113video_1591129778.mp4&platform=wrongplatformname', headers=client_header)
    data = response.data.decode()
    assert 'Invalid platform type' in data
    assert response.status_code == 404


def test_asset_unit_file_not_found(client, client_header):
    # file not found in s3 bucket
    response = client.get('/asset/download?url=https%3A%2F%2Fstaging-simian-media.s3.amazonaws.com%2Frandom.mp4&platform=impact', headers=client_header)
    data = response.data.decode()
    assert 'File not found in bucket' in data
    assert response.status_code == 404


def test_asset_success(client, admin_header, client_header, invalid_header):
    response = client.get('/asset/download?url=https://staging-simian-media.s3.amazonaws.com/4165image_1592342618.jpg&platform=impact', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/asset/download?url=https://staging-simian-media.s3.amazonaws.com/4165image_1592342618.jpg&platform=impact', headers=client_header)
    assert response.status_code == 200

    response = client.get('/asset/download?url=https://staging-simian-media.s3.amazonaws.com/4165image_1592342618.jpg&platform=impact', headers=invalid_header)
    assert response.status_code == 401
