# pylint: disable=missing-docstring, broad-except, eval-used, invalid-name
from bson.objectid import ObjectId
from .utils import init_vocabulary, _vocab_alone, fetch_tagging_programs, add_term_to_vocab, remove_program_tagging, remove_term_from_vocab
from .csrhub import tag_csrhub
from .sasb import tag_sasb
from .themes import tag_themes
from .sdg import tag_sdg
from .gri import tag_gri
from .msci import tag_msci
from .constants import *
import json
import traceback
from research_api.loggly import get_logger

TAG_TYPES = {
    'CSR': tag_csrhub,
    'SASB': tag_sasb,
    'THEMES': tag_themes,
    'SDG': tag_sdg,
    'GRI': tag_gri,
    'MSCI': tag_msci
}

TAG_VOCAB_MAP = {
    'CSRHUB': CSRHUB_VOCAB,
    'SASB': SASB_VOCAB,
    'MSCI': MSCI_VOCAB
}

def tag(tag_type, document, mm_vocab, ddata, verbose):
    log = TAG_TYPES[tag_type](document, mm_vocab)  # Call tagging method for the given tag_type
    ddata[tag_type] = "complete"
    verbose[tag_type] = log


def verbose_tagging(tag_type, program_id):
    return tagging(tag_type, program_id, True)

def plain_tagging(tag_type, program_id):
    return tagging(tag_type, program_id, False)

def check_vocab(tag_type):
    if tag_type == 'ALL':
        for type in TAG_VOCAB_MAP.keys():
            check_vocab(type)
    else:
        for vocab in TAG_VOCAB_MAP.get(tag_type, []):
            add_term_to_vocab(vocab, tag_type)

def start_pipeline(tag_type, isVerbose, remove_tagging = False):
    if remove_tagging:
        get_logger().info(f'Remove all vocabulary')
        remove_program_tagging()
    get_logger().info(f'Updating all vocabulary')
    check_vocab(tag_type)
    get_logger().info(f'Fetching all program ids to be tagged')
    programs = fetch_tagging_programs()
    get_logger().info(f'Total programs to be tagged {len(programs)}')

    for program in programs:
        tagging(tag_type, program.get('_id'), isVerbose)

    get_logger().info(f'Finished tagging total programs {len(programs)}')
    

def tagging(tag_type, program_id, isVerbose):

    response_data = dict()

    # let's validate the request, first
    # is tag_type something we can do? write that here
    if not ObjectId.is_valid(program_id):
        error = dict()
        error["status_code"] = 500
        error["status"] = "did not receive a valid project objectid (wront format)"
        return error

    # ok, load 'em up
    try:
        # init_vocabulary is in the utils.py file in this directory, and it returnsObject
        # the document to be tagged and a big old dictionary with all the terms we
        # might need.
        mm_vocab, document = init_vocabulary(program_id)
        ddata = dict()
        verbose = dict()

        # make it all upper case so it's easier to eval, below:
        tag_type = tag_type.upper()

        if tag_type == 'ALL':
            for mtag in TAG_TYPES:
                tag(mtag, document, mm_vocab, ddata, verbose)
        else:
            tag(tag_type, document, mm_vocab, ddata, verbose)

        response_data["status_code"] = 1
        response_data["status"] = "complete"
        if not ddata:
            response_data["status"] = "no tags changed"
            response_data["status_code"] = 0
        response_data["data"] = ddata
        if isVerbose:
            response_data["verbose"] = verbose

    except Exception as eee:
        traceback.print_exc()
        error = dict()
        error["status_code"] = -1
        error["status"] = "Exception: "  + str(eee)
        return error

    if isVerbose:
        return_string = "Retagging Status: " + response_data["status"] + "<BR><BR>"
        ds = response_data["verbose"].keys()
        showedName = False
        showedTags = False
        for d in ds:
            dslist = response_data["verbose"][d]
            if not showedName:
                return_string = return_string + dslist[0].replace("\t", "&nbsp;&nbsp;&nbsp;Program ID: ") + "<BR>"
                showedName = True

            if not showedTags:
                tagsdict = json.loads(dslist[1].replace("STRINGED \t", "").replace("'", '"'))
                tagtypes = tagsdict.keys()
                TAGS = ""
                for t in tagtypes:
                    TAGS = TAGS + "&nbsp;&nbsp;&nbsp;" + t + "<BR>"
                    for m in tagsdict[t]:
                        TAGS = TAGS + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + m + "<BR>"
                return_string = return_string + "<BR><BR>TAGS:<BR>" + TAGS + "<BR>"
                showedTags = True

            return_string = return_string + d + "<BR>"
            counter = 4

            while counter < len(dslist):
                if counter == len(dslist) - 1:
                    return_string = return_string + "&nbsp;&nbsp;&nbsp;" + d + " Tag " + dslist[counter] + "<BR>"
                else:
                    return_string = return_string + "&nbsp;&nbsp;&nbsp;" + dslist[counter] + "<BR>"
                counter = counter + 1

            return_string = return_string + "<BR><BR>"

        return return_string
    else:
        return response_data

# /tagging/validate
# this end point will check the validity of our python source
# code for tagging, by loading the python source files as strings
# and checking the validity of each `check_term` call (based
# on the constants used and the data collections in the DB).
# while other checks try to make sure the string value (even
# in a constant) is valid for use (or, at least 'in use') -- this
# check will load the collection (vocabulary) and check the specific
# subbranches to make sure the string exist and have an objectID

def validate():
    vocabulary = _vocab_alone(False)
    result = dict()
    result["gri"] = validate_source("gri.py", vocabulary)
    result["csr_hub"] = validate_source("csrhub.py", vocabulary)
    result["sasb"] = validate_source("sasb.py", vocabulary)
    result["sdg"] = validate_source("sdg.py", vocabulary)
    result["themes"] = validate_source("themes.py", vocabulary)
    result["msci"] = validate_source("msci.py", vocabulary)
    return result

def validate_source(which, vocabulary):
    f = open("./research_api/controllers/tagging/" + which, "r")
    contents = f.read()
    lines = contents.split("check_term(")
    f.close()
    total_count = 0
    valid = 0
    missing = list()
    for x in lines:
        mini = x.split(")")
        data = mini[0].split(",")
        if len(data) == 3:
            total_count = total_count + 1
            key = eval(data[0])
            branch = eval(data[1])
            if branch in vocabulary:
                if key in vocabulary[branch].values():
                    valid = valid + 1
                else:
                    missing.append("val " + key)
            else:
                missing.append("branch " + branch)
    if valid < total_count:
        return str(missing)
    return "pass"


def constants():
    return _vocab_alone(True)