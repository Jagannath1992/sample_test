# -*- coding: utf-8 -*-
from io import StringIO
from itertools import chain
from functools import partial

from datetime import datetime, timezone

import pandas as pd
from flask import request, jsonify, current_app

from ...controllers import admin_bp
from ...utils import check_data_encoding, GivewithError
from ...mongodb import db
from ...permission_decorator import require_admin_permission
import sys

def check_z_score(mean, std, value):
    return (value - mean) / std


def apply_zscore(df):
    all_gics_raw_weights = pd.Series(list(chain(*df.values)))
    global_gics_mean = all_gics_raw_weights.mean()
    global_gics_std = all_gics_raw_weights.std()
    df_gics_zscore_check = df.apply(partial(check_z_score, global_gics_mean, global_gics_std))
    return df_gics_zscore_check


@check_data_encoding
def _gics_csv_parser(data):

    COLUMNS = {
        'Sub-Industry',
        'Aging populations',
        'Animal welfare',
        'Arts and culture',
        'Criminal justice',
        'Disaster response, relief and recovery',
        'Diversity and inclusion',
        'Economic empowerment',
        'Education',
        'Environment',
        'Food and hunger',
        'Health and wellness',
        'Housing and homelessness',
        'Human rights and civic engagement',
        'Immigrants',
        'Indigenous peoples',
        'LGBTQQIA+',
        'People of color',
        'People with disabilities/disabled persons',
        'Poverty alleviation',
        'Refugees',
        'Veterans',
        'Women and girls',
        'Youth development'
    }



    df_gics = pd.read_csv(StringIO(data), skiprows=1)
    df_gics = pd.DataFrame(df_gics)  # read_csv can return DF or TextParser, which confuses pylint

    USELESS_GICS_COLUMNS: set = {
        'Unnamed: 0', '#', 'Sector', 'Group', 'Industry', 'Sub-Industry Description',
        'Total Weight (sum must add up to 100)', 'code2', 'code4', 'code6', 'code8'
    }
    USEFUL_COLUMNS: list = list(set(df_gics.columns) - USELESS_GICS_COLUMNS)
    USEFUL_COLUMNS.sort()

    if not set(COLUMNS).issubset(set(df_gics.columns)):
        print(df_gics.columns, file=sys.stderr)
        diff_columns = list(set(COLUMNS) - set(df_gics.columns))
        raise GivewithError(f'Missing {diff_columns} columns in GICS File')

    df_gics = df_gics[USEFUL_COLUMNS]

    df_gics.dropna(inplace=True)
    df_gics['Sub-Industry'] = df_gics['Sub-Industry'].apply(lambda x: x.strip())
    df_gics = df_gics.rename(columns={'Sub-Industry': 'esg_industry'})

    df_gics.set_index('esg_industry', inplace=True)

    return df_gics


@admin_bp.route('/gics/importer', methods=['POST'])
@require_admin_permission
def gics_upload_file():
    """Upload GICS csv
    ---
    tags: ['Brand Admin']

    security:
      - GivewithAuth: []

    requestBody:
      description: GICS CSV content to be imported
      required: true
      content:
        text/plain:
          schema:
            type: string

    responses:
      200:
        description: Success
    """
    df_gics = _gics_csv_parser(request.data)

    df_gics = df_gics.apply(pd.to_numeric, errors='coerce')

    timestamp = datetime.utcnow().replace(tzinfo=timezone.utc, microsecond=0).isoformat()
    db().coll_settings.update_many({}, {'$set': {'csv.themesLastUpdated': timestamp}})

    db().coll_gics.drop()
    db().coll_gics.insert_one(
        {
            'dataframe': df_gics.to_json(),
            'type': 'raw',
            'imported': datetime.today()
        })

    info_message = f'Imported {len(df_gics)} records from GICS file'
    if len(df_gics) == 0:
        info_message = info_message + ".  Maybe you've got some empty data?"
    current_app.logger.info(info_message)

    return jsonify(success=True, message=info_message)
