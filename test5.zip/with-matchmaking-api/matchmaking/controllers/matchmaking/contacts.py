# -*- coding: utf-8 -*-

from bson import ObjectId
from bson.errors import InvalidId
from flask import jsonify

from ...mongodb import db
from ...utils import EntityNotFound, UnsupportedId
from ...controllers import admin_bp
from ...permission_decorator import require_admin_permission

entity_name = 'contact'


##
# Protected Endpoints
##
@admin_bp.route('/contacts', methods=['GET'])
@require_admin_permission
def admin_list_contacts():
    """ List all available Contacts
    ---
    tags: ['Contact Admin']

    security:
      - GivewithAuth: []

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                type: object
                properties:
                  _id:
                    type: string
                  name:
                    type: string
                  role:
                    type: string
                  email:
                    type: string
                    format: email
                  lastUpdated:
                    type: string
                    format: date-time
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    contact_cursor = db().coll_contacts.find(projection={'_id': True,
                                                    'name': True,
                                                    'role': True,
                                                    'email': True,
                                                    'lastUpdated': True})
    if not contact_cursor:
        raise EntityNotFound(entity_name)

    return jsonify([contact for contact in contact_cursor])


@admin_bp.route('/contacts/<id>', methods=['GET'])
@require_admin_permission
def admin_get_contact_by_id(id):
    """ Fetch Contact data
    ---
    tags: ['Contact Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Contact'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    contact = db().coll_contacts.find_one({'_id': obj_id})
    if not contact:
        raise EntityNotFound(entity_name, id)

    if 'brandRef' in contact and isinstance(contact['brandRef'], ObjectId):
        contact_ref = contact['brandRef']
        contact['brandRef'] = db().coll_brands.find_one({'_id': contact_ref},
                                                   {'name': True})

    def expand_program(program):
        if isinstance(program, ObjectId):
            return db().coll_programs.find_one({'_id': program}, {'name': True})

    contact['programRefs'] = [expand_program(program) for program in contact.get('programRefs', [])]

    return jsonify(contact)


@admin_bp.route('/contacts/<id>', methods=['DELETE'])
@require_admin_permission
def delete_contact(id):
    """ Contact Brand
    ---
    tags: ['Contact Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Contact'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_contacts.find_one_and_delete({'_id': obj_id})
    return jsonify(deleted_document)
