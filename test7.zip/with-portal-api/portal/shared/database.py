from os import environ
from pymongo import MongoClient
from pymongo.database import Database

db: Database = None


def init_db(app):
    global db
    config = app.config['config']['db']['mongodb']
    url = environ.get('MONGO_URL', '')
    if url:
        config['uri'] = url
    
    client = MongoClient(config['uri'])
    db = client.get_database(config['db_name'])
    return db


def get_db() -> Database:
    return db
