import json

def test_event(client, admin_header, brand_id):
    payload = {
        'name': 'test event',
        'customer': str(brand_id)
    }

    # test post
    response = client.post('admin/event', data=json.dumps(payload), headers=admin_header)
    assert response.status_code == 200

    event = json.loads(response.data.decode())
    brand_id = event['customer']
    event_id = event['_id']
    assert event['name'] == 'test event'
    assert event['customer'] == str(brand_id)

    # test get
    response = client.get('admin/event/brand/' + brand_id, headers=admin_header)
    events = json.loads(response.data.decode())

    assert response.status_code == 200
    assert len(events) > 0

    # test put
    update_event = {
        'customer': str(brand_id),
        'name': 'updated test event',
        'category': 'category',
        'type': 'type',
        'tcv': 'tcv',
    }

    response = client.put('/admin/event/' + event_id, data=json.dumps(update_event), headers=admin_header)
    assert response.status_code == 200

    event = json.loads(response.data.decode())
    assert event['name'] == 'updated test event'

    # test get event by id
    response = client.get('admin/event/' + event_id, headers=admin_header)
    assert response.status_code == 200

    # test delete event by id
    response = client.delete('admin/event/' + event_id, headers=admin_header)
    assert response.status_code == 200

    # get event again, expect 404
    response = client.get('admin/event/' + event_id, headers=admin_header)
    assert response.status_code == 404


def test_pilot_deal(client, admin_header, brand_id, program_id):
    # create a event
    payload = {
        'name': 'test event',
        'customer': str(brand_id)
    }

    response = client.post('admin/event', data=json.dumps(payload), headers=admin_header)
    event = json.loads(response.data.decode())
    event_id = event['_id']

    # add a deal to event
    deal = {
        'type': 'pilot-procurement',
        'supplier': str(brand_id),
        'estimatedContractValue': 0,
        'allocation': 0,
        'givewithPortion': 1000,
        'feePercentage': 15,
        'fundingAmount': 1000,
        'supplierName': 'supplier name',
        'contact': 'contact@customer.com',
        'fundingStatus': 'string field',
        'invoicingTerms': 'string field',
        'totalInvoicingAmount': 200,
        'selectedProgram': [{
            'programId': str(program_id),
            'funding': 1000,
            'fundingPeriod': 'string field',
            'progress': 20
        }]
    }
    response = client.post('admin/event/' + event_id + '/deal', data=json.dumps(deal), headers=admin_header)
    assert response.status_code == 200

    # verify deals count in event
    response = client.get('admin/event/' + event_id, headers=admin_header)
    event = json.loads(response.data.decode())

    assert event['deals'][0]['password']
    assert event['deals'][0]['slug']

    # update deal
    deal_id = event['deals'][0]['_id']
    new_portion_value = 91828112
    deal = {
        'type': 'pilot-procurement',
        'supplier': str(brand_id),
        'estimatedContractValue': 0,
        'allocation': 0,
        'givewithPortion': new_portion_value,
        'feePercentage': 15,
        'fundingAmount': 1000,
        'supplierName': 'supplier name',
        'contact': 'contact@customer.com',
        'fundingStatus': 'string field',
        'invoicingTerms': 'string field',
        'totalInvoicingAmount': 200,
        'selectedProgram': [{
            'programId': str(program_id),
            'funding': 1000,
            'fundingPeriod': 'string field',
            'progress': 20
        }]
    }
    response = client.put('admin/pilot_deal/' + deal_id, data=json.dumps(deal), headers=admin_header)
    assert response.status_code == 200

    status_payload = {
        'status': 'COMPLETE'
    }
    response = client.put('admin/pilot_deal/status/' + deal_id, data=json.dumps(status_payload), headers=admin_header)
    assert response.status_code == 200

    response = client.get('admin/pilot_deal/' + deal_id, headers=admin_header)
    assert response.status_code == 200

    # verify updated result
    response = client.get('admin/event/' + event_id, headers=admin_header)
    event = json.loads(response.data.decode())
    assert event['deals'][0]['givewithPortion'] == new_portion_value

    # delete pilot deal
    response = client.delete('admin/pilot_deal/' + deal_id, data=json.dumps(deal), headers=admin_header)
    assert response.status_code == 200

    # verify delete result
    response = client.get('admin/event/' + event_id, headers=admin_header)
    event = json.loads(response.data.decode())
    assert len(event['deals']) == 0


def test_list_event(client, admin_header):
    response = client.get('admin/event', headers=admin_header)
    assert response.status_code == 200

