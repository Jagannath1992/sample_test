import pytest
from portal.features.locales.validators import LocaleValidator
from werkzeug.exceptions import NotFound, BadRequest
from portal.shared.repositories import locale_repository, instance_settings_repository


class TestInstanceValidator:
    def test_locale_name_exist(self, mocker, fakers):
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repository(), 'exists_by_filter', return_value=True)
        validator = LocaleValidator(locale)
        with pytest.raises(BadRequest):
            validator.validate_locale_name()

    def test_locale_name_not_exist(self, mocker, fakers):
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repository(), 'exists_by_filter', return_value=False)
        validator = LocaleValidator(locale)
        assert validator.validate_locale_name() == None

    def test_instance_for_locale_exist(self, mocker, fakers):
        locale = fakers.locale.generate_single()
        update = fakers.locale.generate_single()
        validator = LocaleValidator(update, locale)
        locale['instanceCount'] = 1
        update['active'] = False
        mocker.patch.object(instance_settings_repository(), 'populate_locale_instance_counts', return_value=locale)
        with pytest.raises(BadRequest):
            validator.validate_active_instance()

    def test_instance_for_locale_not_exist(self, mocker, fakers):
        locale = fakers.locale.generate_single()
        update = fakers.locale.generate_single()
        validator = LocaleValidator(update, locale)
        locale['instanceCount'] = 0
        update['active'] = False
        mocker.patch.object(instance_settings_repository(), 'populate_locale_instance_counts', return_value=locale)
        assert validator.validate_active_instance() == None
