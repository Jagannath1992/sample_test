from datetime import datetime
from flask import jsonify, request
from bson import ObjectId
from pymongo import ReturnDocument
from bson.errors import InvalidId
import sys

from matchmaking.service.recommendations import get_brand_recommended_programs, select_programs
from matchmaking.dao.utils import get_documents
from matchmaking import auth, public_mm_bp
from matchmaking.controllers import secure_commerce_bp
from matchmaking.permission_decorator import require_client_permission
from matchmaking.validation.utils import validate_existences
from matchmaking.utils import UnsupportedPayload, UnsupportedId, GivewithError, set_last_updated, DATETIME_FORMAT

from ...mongodb import db
from ...models.models import Currency, to_bool
from .utils import (get_brand_by_id_or_slug, get_program_by_id_or_slug, transform_programs, get_insights,
                    annotate_nonprofits_with_programs)
from .deal import get_brand_program

# static sample funding amount to be used where funding amount is needed
FUNDING_AMOUNT = 50000
FUNDING_CURRENCY = str(Currency.USD)

MIN_SELECTIONS = 0
MAX_SELECTIONS = sys.maxsize

@public_mm_bp.route('brand/<brand_slug>/preferred-programs/login', methods=['POST'])
def login_preferred_programs_dispatch(brand_slug):
    result = login_preferred_programs(brand_slug)
    return jsonify(result)

@public_mm_bp.route('brand/<brand_id_or_slug>/preferred-programs', methods=['GET'])
@auth.validate_token_against_collection('mm_brands')
def get_preferred_programs_dispatch(brand_id_or_slug):
    result = get_preferred_programs(brand_id_or_slug)
    return jsonify(result)

@public_mm_bp.route('brand/<brand_id_or_slug>/preferred-programs', methods=['PATCH'])
@auth.validate_token_against_collection('mm_brands')
def add_preferred_program_cart_dispatch(brand_id_or_slug):
    result = add_preferred_program_cart(brand_id_or_slug)
    return jsonify(result)

@public_mm_bp.route('brand/<brand_id_or_slug>/preferred-programs', methods=['POST'])
@auth.validate_token_against_collection('mm_brands')
def post_preferred_programs_dispatch(brand_id_or_slug):
    result = post_preferred_programs(brand_id_or_slug)
    return jsonify(result)

@public_mm_bp.route('brand/<brand_id_or_slug>/preferred-programs/<program_id>', methods=['DELETE'])
@auth.validate_token_against_collection('mm_brands')
def remove_preferred_program_cart_dispatch(brand_id_or_slug, program_id):
    result = remove_preferred_program_cart(brand_id_or_slug, program_id)
    return jsonify(result)

@public_mm_bp.route('/brand/<brand_id_or_slug>/program/<program_id_or_slug>', methods=['GET'])
@auth.authenticate_with_one_of(
    require_client_permission,
    auth.validate_token_against_collection('mm_brands'),
)
def get_brand_layered_program_dispatch(brand_id_or_slug, program_id_or_slug):
    result = get_brand_transformed_program(brand_id_or_slug, program_id_or_slug)
    return jsonify(result)

'''
@api {get} brand/:brand_id_or_slug/recommendations/?only_active=:only_active_value
@apiDescription returns all programs a brand can fund sorted by relevance

@apiParam {String} brand_id_or_slug the brand's id or slug to recommend programs for
@apiParam {String=true,false} only_active_value specifies whether to return active programs only, default=false
'''
@secure_commerce_bp.route('brand/<brand_id_or_slug>/recommendations', methods=['GET'])
@public_mm_bp.route('brand/<brand_id_or_slug>/recommendations', methods=['GET'])
@auth.authenticate_with_one_of(
    auth.validate_token_against_collection('mm_brands'),
    require_client_permission,
)
def get_recommendations_dispatch(brand_id_or_slug):
    result = get_recommendations(brand_id_or_slug)
    return jsonify(result)


def login_preferred_programs(brand_slug):
    document = request.get_json()
    if not document or not document.get('password'):
        raise GivewithError('Password is required.', code=400)

    password = document['password']
    password_field = 'preferredPrograms.password' # nosec

    if not validate_existences({'slug': brand_slug, password_field: password}, 'mm_brands'):
        raise GivewithError('Link or password is invalid.', code=401)

    expires = (datetime.utcnow() + auth.TOKEN_VALIDITY).strftime(DATETIME_FORMAT)
    token = auth.create_token(f'{password}/{password_field}', brand_slug, expires)

    return {'token': token}

def get_preferred_programs(brand_id_or_slug):
    brand = get_brand_by_id_or_slug(brand_id_or_slug, projection=['preferredPrograms', 'isPilot'])
    pref_programs = brand.get('preferredPrograms', {})

    return {
        'selected': pref_programs.get('selected', []),
        'cart': pref_programs.get('cart', []),
        'editing': pref_programs.get('editing', False),
        'isPilot': brand.get('isPilot', False),
    }

def get_brand_transformed_program(brand_id_or_slug, program_id_or_slug):
    brand = get_brand_by_id_or_slug(brand_id_or_slug)
    program = get_program_by_id_or_slug(program_id_or_slug)


    recommended_programs = get_brand_recommended_programs(brand)
    return get_brand_program(brand, program, recommended_programs, FUNDING_AMOUNT, FUNDING_CURRENCY)

def get_recommendations(brand_id_or_slug):
    brand = get_brand_by_id_or_slug(brand_id_or_slug)

    projection = {
        'name': True, 'slug': True, 'nonprofit': True, 'imagePortrait': True,
        'imageLandscape': True, 'themes.data': True, 'sdg.data': True
    }
    all_programs = get_documents('mm_programs', projection=projection)
    programs_map = {str(program.get('_id')): program for program in all_programs}

    # NOTE: in the case of preferred programs,
    # invalid programs with tags (PROGRAM_INVALID or PROGRAM_INACTIVE) are included

    # if only_active = False, the value of `invalids_to_include` doesn't quite matter since
    # `get_brand_recommended_programs` won't return any invalid programs anyway
    # It is added here only as a sanity check to make things a bit less confusing
    only_active = to_bool(request.args.get('only_active')) or False
    invalids_to_include = set() if only_active else {'PROGRAM_INVALID', 'PROGRAM_INACTIVE'}

    recommended_programs = get_brand_recommended_programs(brand, include_invalid=(not only_active))
    selected_programs = select_programs(recommended_programs)

    research_nonprofits = brand.get('researchCorpCommitments', {}).get('nonprofits', {}).get('preferred', [])
    preferred_nonprofits = list(set(brand.get('nonprofits', {}).get('preferred', []) + research_nonprofits))

    return {
        'analysis': get_insights(brand),
        'preferredNonprofits': annotate_nonprofits_with_programs(preferred_nonprofits),
        'programs': transform_programs(selected_programs, programs_map),
        'allPrograms': transform_programs(recommended_programs, programs_map,
                                          invalid_reasons_to_include=invalids_to_include)
    }

def add_preferred_program_cart(brand_id_or_slug):
    fields = request.get_json()

    if not fields or not fields.get('programId'):
        raise UnsupportedPayload()

    # will be an overkill to use cerberus validation and coerceion
    # Refactor in the future to use a model if schema becomes a bit complex

    # NOTE: cart model: list of objectIds
    program_id = fields['programId']
    try:
        obj_id = ObjectId(program_id)
    except InvalidId:
        raise UnsupportedId(program_id)

    brand = get_brand_by_id_or_slug(brand_id_or_slug, projection=['preferredPrograms'])
    if not brand.get('preferredPrograms', {}).get('editing'):
        raise GivewithError('Adding items to cart is disabled', code=400)

    # check to ensure supplied _id is a valid program (), get_program_by_id_or_slug
    # will throw error if program isn't found
    program = get_program_by_id_or_slug(obj_id, projection={'_id': True})

    cart = set(brand.get('preferredPrograms', {}).get('cart', []))
    cart.add(program['_id'])

    updates = {
        'preferredPrograms.cart': list(cart),
        'preferredPrograms.editing': True,
    }

    updated_brand = db().coll_brands.find_one_and_update(filter={'_id': brand['_id']},
                                                         update={'$set': set_last_updated(updates)},
                                                         return_document=ReturnDocument.AFTER)

    return {
        'selected': updated_brand['preferredPrograms'].get('selected', []),
        'cart': updated_brand['preferredPrograms']['cart'],
        'editing': updated_brand['preferredPrograms']['editing']
    }

def remove_preferred_program_cart(brand_id_or_slug, program_id):
    try:
        obj_id = ObjectId(program_id)
    except InvalidId:
        raise UnsupportedId(program_id)

    brand = get_brand_by_id_or_slug(brand_id_or_slug, projection=['preferredPrograms'])
    if not brand.get('preferredPrograms', {}).get('editing'):
        raise GivewithError('Adding items to cart is disabled', code=400)

    cart = set(brand.get('preferredPrograms', {}).get('cart', []))

    if obj_id in cart:
        cart.remove(obj_id)
    else:
        raise GivewithError(f'Program with id {program_id} not in cart', code=400)

    updates = {
        'preferredPrograms.cart': list(cart),
        'preferredPrograms.editing': True,
    }

    updated_brand = db().coll_brands.find_one_and_update(filter={'_id': brand['_id']},
                                                         update={'$set': set_last_updated(updates)},
                                                         return_document=ReturnDocument.AFTER)

    return {
        'selected': updated_brand['preferredPrograms'].get('selected', []),
        'cart': updated_brand['preferredPrograms']['cart'],
        'editing': updated_brand['preferredPrograms']['editing']
    }

def post_preferred_programs(brand_id_or_slug):
    brand = get_brand_by_id_or_slug(brand_id_or_slug, projection=['preferredPrograms'])

    preferred_programs = brand.get('preferredPrograms', {})

    if not preferred_programs.get('editing'):
        raise GivewithError('Editing is disabled', code=400)

    updates = {
        'preferredPrograms.cart': [],
        'preferredPrograms.selected': preferred_programs['cart'],
        'preferredPrograms.editing': False,
    }

    updated_brand = db().coll_brands.find_one_and_update(filter={'_id': brand['_id']},
                                                         update={'$set': set_last_updated(updates)},
                                                         return_document=ReturnDocument.AFTER)

    return {
        'selected': updated_brand['preferredPrograms']['selected'],
        'cart': updated_brand['preferredPrograms']['cart'],
        'editing': updated_brand['preferredPrograms']['editing']
    }
