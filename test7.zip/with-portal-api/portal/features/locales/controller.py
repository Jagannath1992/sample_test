from locale import currency
from typing import Dict

from bson import ObjectId
from flask import request, Response
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from werkzeug.exceptions import Forbidden, NotFound, BadRequest
from portal.features.locales.schema import LocaleRequest, LocalePatchRequest, LocaleSearchResponse, \
    LocaleSearchRequest, LocaleResponse
from portal.shared.auth.requests import role_required, token_required
from portal.shared.auth.security import has_role
from portal.shared.enums import AccountStatus, UserRole
from portal.shared.repositories import locale_repository, instance_settings_repository
from portal.features.locales.validators import LocaleValidator

namespace = Namespace('locales', description='Locale related operations')


@namespace.route('')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class Locales(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(query_params_schema=LocaleSearchRequest, api=namespace)
    @responds(schema=LocaleSearchResponse, api=namespace)
    def get(self):
        """Search Locales"""
        filters = request.parsed_query_params
        total_count, locales = locale_repository().get_page(filters)
        instance_settings_repository().populate_locale_instance_counts(locales)
        return {
            'totalCount': total_count,
            'results': locales
        }

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=LocaleRequest, api=namespace)
    @responds(schema=LocaleResponse, api=namespace)
    @namespace.response(502, 'An error occurred while attempting to create a locale')
    def post(self):
        """Create Locale"""
        locale_request = request.parsed_obj
        validator = LocaleValidator(locale_request)
        validator.validate_locale_name()
        new_locale = locale_repository().insert(locale_request, request.user['username'])
        return new_locale


@namespace.route('/<string:id>')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Locale not found'
    }
)
class LocaleById(Resource):
    @token_required
    @responds(schema=LocaleResponse, api=namespace)
    def get(self, id: str):
        """Get Locale by ID"""
        locale = self._get(id)
        instance_settings_repository().populate_locale_instance_counts([locale])
        return locale

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=LocaleRequest, api=namespace)
    @responds(schema=LocaleResponse, api=namespace)
    def put(self, id: str):
        """Update Locale by ID"""
        locale = self._get(id)
        update = request.parsed_obj
        validator = LocaleValidator(update, locale)
        validator.validate_locale_name()
        validator.validate_active_instance()
        updated_name = update["name"]
        is_name_change = locale["name"] != updated_name
        locale.update(update)
        locale = locale_repository().update(locale, request.user['username'])

        if is_name_change:
            update_values = {
                "name": updated_name
            }
            instance_settings_repository().update_references("settings.locale", id, update_values)
        return locale

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=LocalePatchRequest(partial=True), api=namespace)
    @responds(schema=LocaleResponse, api=namespace)
    def patch(self, id: str):
        """Activate locale"""
        locale = self._get(id)
        update = request.parsed_obj
        validator = LocaleValidator(update, locale)
        validator.validate_locale_name()
        validator.validate_active_instance()
        locale = locale_repository().patch(id, update, request.user['username'])
        return locale

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @responds(schema=LocaleResponse, api=namespace)
    def delete(self, id: str):
        """Deactivate locale"""
        locale = self._get(id)
        update = {'active': False}
        validator = LocaleValidator(update, locale)
        validator.validate_active_instance()
        locale = locale_repository().patch(id, update, request.user['username'])
        return locale

    def _get(self, id):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        locale = locale_repository().get_single(id)
        if not locale:
            raise NotFound('Locale not found')
        return locale
