# pylint: disable=line-too-long, missing-docstring, invalid-name, wildcard-import, unused-wildcard-import, too-many-boolean-expressions
from .utils import check_term, add_feature, save_program_document, \
    SELECTED_VOCABULARY_VERSION, critical_alert, init_tagging
from .constants import * # pylint: disable=unused-import

def tag_sasb(document, vocabulary):
    # here is where we're modifying data on records
    # what's our general approach?  well - let's load up the mm_vocabulary object into this hash named vocabulary
    # then we pass that and the given document (program record) together to output a stringified - meaning: readable
    # version of the document.

    log = list()
    _MY_SOURCE = VOCAB_SASB

    try:
        tag_data = init_tagging(document, vocabulary, log, _MY_SOURCE)

        # NOW START TURNING THE RULES INTO CODE

        # Rule 1: GHG Emissions
        log.append("  rule 1")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, GHG_EMISSIONS, tag_data)

        log.append("----")

        # Rule 2: Ecological Impacts
        log.append("  rule 2")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, ECOLOGICAL_IMPACTS, tag_data)

        log.append("----")

        # Rule 3: Human Rights & Community Relations
        log.append("  rule 3")
        add_feature(_MY_SOURCE, HUMAN_RIGHTS_AND_COMMUNITY_RELATIONS, tag_data)

        log.append("----")

        # Rule 4: Access and Affordability
        log.append("  rule 4")
        if (check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
            check_term(EDUCATION, VOCAB_CAUSES, tag_data) or \
            check_term(FOOD_AND_HUNGER, VOCAB_CAUSES, tag_data) or \
            check_term(HOUSING_AND_HOMELESSNESS, VOCAB_CAUSES, tag_data) or \
            check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data)) and \
                (check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_NUTRITIOUS_FOOD, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY__AFFORDABLE_HEALTHCARE_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_HOMELESSNESS, VOCAB_IMPACTS, tag_data)) and \
                (check_term(DEVELOP_FINANCIAL_LITERACY_AND_FINANCIAL_RESILIENCE, VOCAB_APPROACHES, tag_data) or \
                 check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_AFFORDABLE_HOUSING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_POTABLE_WATER, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUFFICIENT__AFFORDABLE_AND_NUTRITIOUS_FOODS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_AND_CONNECTIVITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TEMPORARY_HOUSING, VOCAB_APPROACHES, tag_data) or \
                 check_term(RUN_PATIENT_AND_FAMILY_SUPPORT_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(RUN_PATIENT_QUALITY_OF_LIFE_PROGRAMS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, ACCESS_AND_AFFORDABILITY, tag_data)

        log.append("----")

        # Rule 5: Business Ethics
        log.append("  rule 5")
        add_feature(_MY_SOURCE, BUSINESS_ETHICS, tag_data)
        log.append("----")

        # Rule 6: Physical Impacts of Climate Changes
        log.append("  rule 6")
        if (check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) or \
            check_term(DISASTER_RESPONSE__RELIEF_AND_RECOVERY, VOCAB_CAUSES, tag_data)) and \
                (check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
                (check_term(IMPROVE_CONDITIONS_AFTER_NATURAL_DISASTERS_AND_CRISES, VOCAB_IMPACTS, tag_data)) and \
                check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or \
                check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                 check_term(CREATE_POLICY_CHANGE, VOCAB_APPROACHES, tag_data)):            
            add_feature(_MY_SOURCE, PHYSICAL_IMPACTS_OF_CLIMATE_CHANGE , tag_data)

# Rule 7: Employee Engagement, Diversity and Inclusion
        log.append("  rule 7")
        if (check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
                check_term(PROMOTE_JOB_CREATION, VOCAB_APPROACHES, tag_data)) and \
                (check_term(AGE_0_5_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                check_term(AGE_19_24_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                check_term(AGE_13_18_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                check_term(AGE_6_12_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                check_term(AGE_25_64_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                check_term(AGE_65__YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                check_term(PEOPLE_WITH_SPECIAL_NEEDS, VOCAB_AUDIENCES, tag_data) or \
                check_term(VETERANS, VOCAB_AUDIENCES, tag_data) or \
                check_term(NONBINARY, VOCAB_AUDIENCES, tag_data) or \
                check_term(IMMIGRANTS, VOCAB_AUDIENCES, tag_data) or \
                check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) or \
                check_term(REFUGEES_DISPLACED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
                check_term(OTHER, VOCAB_AUDIENCES, tag_data) or \
                check_term(PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
                check_term(LGBTQQIA_, VOCAB_AUDIENCES, tag_data) or \
                check_term(PARENTS_GUARDIANS, VOCAB_AUDIENCES, tag_data) or \
                check_term(WOMEN_AND_GIRLS, VOCAB_AUDIENCES, tag_data) or \
                check_term(ELDERLY_POPULATIONS_65_, VOCAB_AUDIENCES, tag_data) or \
                check_term(INDIGENOUS_PEOPLES, VOCAB_AUDIENCES, tag_data) or \
                    check_term(PEOPLE_OF_COLOR, VOCAB_AUDIENCES, tag_data)):            
            add_feature(_MY_SOURCE, EMPLOYEE_ENGAGEMENT_DIVERSITY_AND_INCLUSION , tag_data)
# Rule 8: Air Quality
        log.append("  rule 8")
        if (check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data)) and \
            (check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
            check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data)):            
            add_feature(_MY_SOURCE, AIR_QUALITY , tag_data)
# Rule 9: Water and Waste water management
        log.append("  rule 9")
        if (check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data)) and \
                (check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)) or \
                    check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data):            
            add_feature(_MY_SOURCE, WATER_AND_WASTE_WATER_MANAGEMENT, tag_data)
 # Rule 10: Customer Welfare
        log.append("  rule 10")
        if (check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data)) and \
                (check_term(REDUCE_DISEASE_IMPROVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                check_term(REDUCE_HUNGER_AND_MALNUTRITION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_NUTRITIOUS_FOOD, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_ACCESS_TO_QUALITY__AFFORDABLE_HEALTHCARE_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                check_term(REDUCE_RISKY_AND_ADDICTIVE_BEHAVIORS, VOCAB_IMPACTS, tag_data)):            
            add_feature(_MY_SOURCE, CUSTOMER_WELFARE , tag_data)

        log.append("  Summary: " + ', '.join(document[_MY_SOURCE]["strings"]))

        # now put the version number into the same object
        document[_MY_SOURCE]["tagging-version"] = SELECTED_VOCABULARY_VERSION

        # cool!  save that object back and go!
        save_program_document(document)

    except Exception as eee:
        critical_alert(eee, log, "vocab_error_in_tagging")
        raise eee

    return log
