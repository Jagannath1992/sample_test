import json
import requests
from flask import request, current_app as app


def get_mm_api(path):
    mm_api_url = app.config['MATCHMAKING_API_ENDPOINT']
    # mm_api_url = 'http://172.17.10.251:3000'
    uri = f'{mm_api_url}{path}'

    headers = {
        'authorization': request.headers['authorization'],
        'refresh_token': request.headers['refresh_token']
    }

    response = requests.get(uri, headers=headers, timeout=15.0)

    if response.status_code is 200:
        return json.loads(response.text)
    else:
        return {'error': response.text}, response.status_code


def post_mm_api(path, data):
    mm_api_url = app.config['MATCHMAKING_API_ENDPOINT']
    # mm_api_url = 'http://172.17.10.251:3000'
    uri = f'{mm_api_url}{path}'

    headers = {
        'authorization': request.headers['authorization'],
        'refresh_token': request.headers['refresh_token'],
        'Content-Type': 'application/json'
    }

    response = requests.post(uri, data=json.dumps(data), headers=headers, timeout=15.0)

    if response.status_code is 200:
        return json.loads(response.text)
    else:
        return {'error': response.text}, response.status_code
