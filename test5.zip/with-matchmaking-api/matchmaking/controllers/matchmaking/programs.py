# -*- coding: utf-8 -*-
import math
import os
import sys
import pandas as pd

from io import StringIO
from bson.errors import InvalidId
from flask import jsonify, request, current_app
from pymongo import ReturnDocument
from pymongo.collation import Collation, CollationStrength
from werkzeug.utils import secure_filename
from . import public_mm_bp
from ...controllers import admin_bp
from ...controllers.commerce.data_triggers import trigger_program_tagging
from ... import (program_screen_one_calculation,
                 program_strength_calculation)
from ...models.models import v, schema_program_csv, schema_program_v2, to_bool
from ...mongodb import (get_list_fields, create_slug, ASCENDING, DESCENDING, ObjectId, schema_program, get_vocabulary,
                        group_vocabulary, expand_vocabulary_label, set_vocabulary, create_ref, get_vocabulary_v2,
                        get_is_valid_nonprofit, get_nonprofit, fix_vocabulary_typos, set_vocabulary_str,
                        get_screen_one_minimum, db, get_program)
from ...s3 import upload_file, delete_file
from ...tagging import auto_fill
from ...triggers import set_brands_is_valid_of_programs, remove_program_from_brands
from matchmaking.service.slack import send_si_platform_message
from ...util.program_strength_calculation_v2 import calculate_program_strength_v2
from ...utils import (set_last_updated, remove_empty, set_created_at, ensure_valid_elements, set_booleans,
                      format_cerberus_errors_for_csv, get_locale_string, check_data_encoding, EntityNotFound,
                      MissingVocabulary, UnsupportedId, UnsupportedPayload, GivewithError, ValidationError,
                      dict_merge, create_validation_error_response, get_descendant_key, set_descendant_key,
                      pop_descendant_key, watermark_file, send_loggly)
from ...permission_decorator import require_admin_permission, require_client_permission
from ...utils import DealStatus
from matchmaking.service.impact_multiple import calc_impact_multiple
from matchmaking.dao.utils import get_documents, update_document_by_id
from ...validation.utils import validate_object_id
from matchmaking.util.singular_converter import form_program_output

entity_name = 'program'
target_collection = 'mm_programs'

name_map = {
    "Status": "Status",
    "Finished": "Finished",
    "Q1": "nonprofit",
    "Q4": "name",
    "Q3": "causes",
    "Q6": "descriptionLong",
    "Q62": "description",
    "Q7": "primaryImpact",
    "Q71": "animalHabitat",
    "Q72": "d_animalHabitat",
    "Q73": "secondaryImpacts",
    "Q75": "forestProtection",
    "Q74": "d_forestProtection",
    "Q24": "interventions",
    "Q25": "programApproach",
    "Q5": "isOngoingProgram",
    "Q64": "effectivenessRating",
    "Q17": "dataMeasurementType",
    "Q19": "programActivityEffectiveness",
    "Q22": "primaryOutcomeEffectiveness",
    "Q32": "audienceAge",
    "Q65": "audienceGender",
    "Q34": "audienceAttribute",
    "Q66": "programDensity",
    "Q38": "budget",
    "Q77_1": "outputs_0_label",
    "Q77_2": "outputs_1_label",
    "Q77_3": "outputs_2_label",
    "Q77_4": "outputs_3_label",
    "Q77_5": "outputs_4_label",
    "Q81_1_1": "outputs_0_cost",
    "Q81_1_2": "outputs_0_quantity",
    "Q81_2_1": "outputs_1_cost",
    "Q81_2_2": "outputs_1_quantity",
    "Q81_3_1": "outputs_2_cost",
    "Q81_3_2": "outputs_2_quantity",
    "Q81_4_1": "outputs_3_cost",
    "Q81_4_2": "outputs_3_quantity",
    "Q81_5_1": "outputs_4_cost",
    "Q81_5_2": "outputs_4_quantity",
    "Q41": "additionalValueFields_savingsSociety",
    "Q45": "additionalValueFields_savingsBeneficiary",
    "Q54": "additionalValueFields_volunteerValueFields_hours",
    "Q56": "additionalValueFields_contributionsCash",
    "Q57": "additionalValueFields_contributionsInKind",
    "Q55": "oneOrMorePartnerOrganizations",
}

field_to_column = {v: k for k, v in name_map.items()}

output_base_values = {
    "valueFifty": 50000,
    "valueOneHundred": 100000,
    "valueTwoHundredFifty": 250000,
    "valueFiveHundred": 500000
}

PROGRAM_FILTERS = [
    '_id', 'outputs', 'outcomes', 'name', 'causes', 'imageLandscape', 'imagePortrait', 'impactMultiple', 'topics',
    'impactMultipleVisibility', 'description', 'match', 'themes', 'sdg', 'esg', 'sasb', 'cdp', 'gri', 'csrhub',
    'related', 'programStrengthRating', 'programStrength', 'nonprofit', 'contentSettings', 'screenOneMinimum', 'budget',
    'tvl', 'previewImage', 'vimeoID', 'slug'
]

@check_data_encoding
def _programs_csv_parser(data):
    df = pd.read_csv(StringIO(data), skiprows=[1, 2])
    df = pd.DataFrame(df)  # read_csv can return DF or TextParser, which confuses pylint
    df.fillna('', inplace=True)

    keys_of_interest = list(name_map.keys())
    df_keys = df[keys_of_interest]
    df_renamed = df_keys.rename(columns=name_map)
    documents = []
    for index, row in df_renamed.iterrows():
        if row['Status'] == 'Survey Preview' or not row['Finished']:
            continue

        outputs = _df_rows_to_dict_list(row, "outputs")
        for output in outputs:
            scale_type, _ = set_vocabulary_str('scaleType', 'Proportional')
            if scale_type:
                output['scaleType'] = scale_type

        additional_value_fields = _df_row_to_dict(row, 'additionalValueFields')
        document = row.to_dict()
        document['outputs'] = outputs
        document['additionalValueFields'] = additional_value_fields

        document['isOngoingProgram'] = (document['isOngoingProgram'] == 'Ongoing program')
        document['oneOrMorePartnerOrganizations'] = \
            (document['oneOrMorePartnerOrganizations'] == 'One or more partner organizations')

        if not document['animalHabitat'].strip():
            document['animalHabitat'] = document['d_animalHabitat'].strip()

        if not document['forestProtection'].strip():
            document['forestProtection'] = document['d_forestProtection'].strip()

        documents.append(remove_empty(document))

    return documents


def _df_row_to_dict(row, columns_prefix):
    columns = row.filter(regex='^{}_.*$'.format(columns_prefix)).index
    dic = {}
    for col_name in columns:
        token = col_name.split('_', maxsplit=1)
        if '_' in token[1]:
            tk = token[1].split('_', maxsplit=1)
            row.rename(index={col_name: token[1]}, inplace=True)
            dic[tk[0]] = _df_row_to_dict(row, tk[0])
            continue
        dic[token[1]] = row[col_name]
        row.drop(index=col_name, inplace=True)
    return dic


def _df_rows_to_dict_list(row, columns_prefix):
    columns = row.filter(regex='^{}_.*$'.format(columns_prefix)).index
    dict_list = []
    for i in range(0, columns.size // 2):
        dic = {}
        for col_name in row.filter(regex='^{}_{}.*$'.format(columns_prefix, i)).index:
            token = col_name.split('_')
            value = row[col_name]
            row.drop(index=col_name, inplace=True)
            if isinstance(value, str) and not value.strip():
                continue
            dic[token[2]] = value
        if dic:
            dict_list.append(dic)
    return dict_list


def set_fields_to_list(document):
    list_fields = set()
    get_list_fields(schema_program, list_fields)

    for key in document.keys():
        field = document[key]
        if key in list_fields and isinstance(field, str):
            field = fix_vocabulary_typos(field)
            field = field.replace(', ', '|')
            document[key] = [item.replace('|', ', ') for item in field.split(',')]


def append_virtual_fields_v2(program):
    """ Append calculated fields to a program
    Currently known calculated fields include -> program strength, output costs and program score (TBD)
    NOTE: This function has side effects, adds programStrength, programStrengthRating keys
    """
    # Append Program Strength
    strengths = calculate_program_strength_v2(program)
    program_strength = [db().map_attribute_to_label.get(s) for s in strengths]

    program['programStrength'] = program_strength
    program['programStrengthRating'] = len(program_strength)


def create_virtual_fields(program, settings=None):
    """
    Create all virtual fields (calculated) and add them to the `dict`
    :param program: program dict representation
    :param settings:
    :return: None
    """
    if not settings:
        settings = db().coll_settings.find_one()

    default_settings = settings['defaultsSettings']

    # virtual fields for additionalValue
    additional_value_fields = program.get('additionalValueFields', {})

    # calculate partnerValue
    contributions_cash = float(additional_value_fields.get('contributionsCash', 0))
    contributions_in_kind = float(additional_value_fields.get('contributionsInKind', 0))
    program['partnerValue'] = (contributions_cash + contributions_in_kind) > 0

    # calculate volunteerValue
    volunteer_value_fields = additional_value_fields.get('volunteerValueFields', None)
    if volunteer_value_fields:
        volunteer_hours = float(volunteer_value_fields.get('hours', 0))
        volunteer_rate = float(default_settings.get('volunteerRate', 0))
        additional_value_fields['volunteerValue'] = round(volunteer_hours * volunteer_rate, 2)

    # calculate additionalValue
    program['additionalValue'] = round(float(additional_value_fields.get('volunteerValue', 0))
                                       + float(additional_value_fields.get('savingsBeneficiary', 0))
                                       + float(additional_value_fields.get('savingsSociety', 0))
                                       + float(additional_value_fields.get('contributionsCash', 0))
                                       + float(additional_value_fields.get('contributionsInKind', 0)), 2)

    program.setdefault('impactMultipleVisibility', False)

    # calculate value on outputs
    outputs = program.get('outputs', [])
    if outputs:
        for output in outputs:
            remove_empty(output)
            cost = float(output.get('cost', 0))
            quantity = float(output.get('quantity', 0))
            if cost and quantity:
                output['value'] = round(cost / quantity, 2)

    # calculate value on custom outputs
    outputs = program.get('customOutputs', [])
    if outputs:
        for output in outputs:
            remove_empty(output)
            cost = float(output.get('cost', 0))
            quantity = float(output.get('quantity', 0))
            if cost and quantity:
                output['value'] = round(cost / quantity, 2)


def normalize_impacts_field(program):
    """auto_fill expects a single impacts field with an array containing primaryImpact and secondaryImpacts
    :param program: Program dict representation
    :return: program instance with annotated 'impacts' key
    """
    if ('primaryImpact' in program) or ('secondaryImpacts' in program):
        aux = [program.get('primaryImpact', None)]
        aux.extend(program.get('secondaryImpacts', []))
        program['impacts'] = [i for i in aux if i is not None]
    return program


def normalize_audience_field(program):
    """auto_fill expects a single audience field with an array containing the respective audience fields in
    Program instances.
    :param program: Program dict representation
    :return: program instance with annotated 'impacts' key
    """
    if ('audienceAge' in program) or ('audienceGender' in program) or ('audienceAttribute' in program):
        aux = []
        aux.extend(program.get('audienceAge', []))
        aux.extend(program.get('audienceGender', []))
        aux.extend(program.get('audienceAttribute', []))
        program['audience'] = aux
    return program


def _format_tag(field_type, field_value):
    if field_type != 'esg':
        return field_value
    else:
        if type(field_value) == list:
            return [{'issue': i} for i in field_value]
        else:
            return {'issue': field_value}


def auto_fill_tags(program, override=False):
    tag_field_types = ['cdp', 'esg', 'gri', 'sdg', 'themes']

    program = normalize_audience_field(normalize_impacts_field(program))

    suggested_tags = auto_fill(program)

    for field_type in tag_field_types:

        field_suggestion = suggested_tags.get(field_type, [])

        if override:
            value = {'isCustom': False, 'data': _format_tag(field_type, field_suggestion)}
        else:
            value = program.get(field_type, {})

            assert(type(value) == dict)  # nosec pylint: disable=invalid-name,superfluous-parens,unidiomatic-typecheck

            is_custom = value and value.get('isCustom', False)
            if is_custom:
                continue

            if not field_suggestion:
                program.pop(field_type, None)  # no suggestion for this tag type, we can safely remove it
            else:
                value = {'isCustom': False, 'data': _format_tag(field_type, field_suggestion)}

        program[field_type] = value

    program.pop('audience', None)
    program.pop('impacts', None)


def math_screen_one_score(program, *args, **kw):
    total_score = sum([getattr(program_screen_one_calculation, i)(program, *args, **kw)
                       for i in dir(program_screen_one_calculation) if i.startswith('rule')])
    if total_score == 0:
        program['screenOneScore'] = total_score
    else:
        program['screenOneScore'] = round((total_score / 110) * 100)


def math_strength_rating(program, *args, **kw):
    strengths = [getattr(program_strength_calculation, i)(program, *args, **kw)
                 for i in dir(program_strength_calculation) if i.startswith('rule')]

    program['programStrength'] = sorted([v['label'] for s in strengths if s[1] is not None
                                         for v in db().vocabulary_list if v.get('attribute', None) == s[1]])

    total = sum([s[0] for s in strengths])
    if total <= 3:
        program['programStrengthRating'] = 1
    else:
        program['programStrengthRating'] = total - 2
    return program


def math_output_values(program):
    for output in program.get('outputs', []):
        if 'value' in output:
            for field, base in output_base_values.items():
                try:
                    output[field] = math.floor(base / output['value'])
                except ZeroDivisionError:
                    output[field] = 0


def transform_esg_admin(program):
    transformed_esg = []
    esg = program.get('esg', {})
    if esg and isinstance(esg, dict):
        data = esg.get('data', [])
        if data:
            for row in data:
                issue = row.get('issue', None)
                if issue:
                    transformed_esg.append({'issue': issue})

    program['esg'] = transformed_esg
    return program


def transform_esg_public(program):
    transformed_esg = []
    esg = program.get('esg', {})
    if esg:
        data = esg.get('data', [])
        if data:
            for row in data:
                issue = row.get('issue', None)
                if issue:
                    transformed_esg.append({'label': issue})

    program['esg'] = transformed_esg
    return program


def transform_investor_metrics(program):
    program['cdp'] = [get_vocabulary(row) for row in program.get('cdp', {}).get('data', [])]
    program['gri'] = [get_vocabulary(row) for row in program.get('gri', {}).get('data', [])]
    program['sdg'] = [get_vocabulary(row) for row in program.get('sdg', {}).get('data', [])]


def transform_program(program, nonprofit):
    program['screenOneMinimum'] = get_screen_one_minimum()
    program.pop('nonprofit', None)

    if nonprofit:
        program['nonprofitId'] = nonprofit['_id']
        program['nonprofitName'] = nonprofit['general']['name']['publicOrganizationName']

    transform_esg_admin(program)
    theme_ids = program.get('themes', {}).get('data', [])
    program['themeNames'] = [get_vocabulary(_id).get('label', '') for _id in theme_ids]

    return program


def filter_program(program):
    return {key: program[key] for key in PROGRAM_FILTERS if key in program}

def add_selected_preferred_fields(program):
    from ..commerce.utils import get_gw_customer_and_client_names

    obj_id = ObjectId(program.get('_id'))

    selected_deals = list(db().coll_deals.find({'selectedProgram': obj_id, 'status':
                                                {'$in': [str(DealStatus.PAYMENT_PENDING),
                                                str(DealStatus.COMPLETE)]}},
                                                projection={'name': True, 'fundingAmount': True,
                                                'givewithCustomer': True, 'client': True})
                                                .sort('createdAt', DESCENDING))

    preferred_brands = list(db().coll_brands.find({'preferredPrograms.selected': obj_id},
                                                  projection={'name': True}))

    for deal in selected_deals:
        deal.update(get_gw_customer_and_client_names(deal))

    program['selectedByDeals'] = selected_deals
    program['preferredByBrands'] = preferred_brands

class IdNone:
    id = None


##
# Protected Endpoints
##
@admin_bp.route('/programs', methods=['GET'])
@require_admin_permission
def admin_list_programs():
    """ List all available Programs
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                type: object
                properties:
                  _id:
                    type: string
                  slug:
                    type: string
                  name:
                    type: string
                  causes:
                    type: array
                    items:
                      type: string
                  active:
                    type: boolean
                  nonprofitId:
                    type: string
                  nonprofitName:
                    type: string
                  isValid:
                    type: boolean
                  screenOneMinimum:
                    type: integer
                  screenOneScore:
                    type: integer
                  ignoreThreshold:
                    type: boolean
                  esg:
                    type: array
                    items:
                      properties:
                        issue:
                          type: string
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    projection = {
        '_id': True,
        'slug': True,
        'name': True,
        'causes': True,
        'themes': True,
        'active': True,
        'nonprofit': True,
        'isValid': True,
        'screenOneScore': True,
        'ignoreThreshold': True,
        'esg': True,
    }
    programs = list(db().coll_programs.find(request.filter_params, projection=projection)
                    .skip(request.skip)
                    .limit(request.page_size)
                    .collation(Collation(locale=get_locale_string(), numericOrdering=True))
                    .sort(request.sort_params))

    nonprofits = {n['_id']: n for n in db().coll_nonprofits.find()}

    return jsonify([transform_program(program, nonprofits.get(program.get('nonprofit', IdNone), None))
                    for program in programs])


"""
check or update program validity status
example: /admin/program:validate?include_invalid=true&include_diff=true&update_validity_status=true
"""
@admin_bp.route('/program:validate', methods=['POST'])
@require_admin_permission
def validate_program():
    results = {
        'invalid': [],
        'valid': [],
        'diff': [],
    }

    overwrite = request.args.get('update_validity_status') == 'true'
    include_diff = request.args.get('include_diff') == 'true'
    include_invalid = request.args.get('include_invalid') == 'true'
    include_valid = request.args.get('include_valid') == 'true'

    programs = get_documents('mm_programs')
    for program in programs:
        version = program.get('version')
        schema = schema_program_v2 if version == 2 else schema_program

        is_valid = v.validate(program, schema)

        if include_valid and is_valid:
            results['valid'].append({'_id': program['_id']})

        if include_invalid and not is_valid:
            results['invalid'].append({'_id': program['_id'], 'details': v.errors})

        if is_valid != program.get('isValid'):
            if include_diff:
                results['diff'].append({'_id': program['_id'], 'previous': program['isValid'], 'current': is_valid})

            if overwrite:
                update_document_by_id('mm_programs', str(program['_id']), {'isValid': is_valid})

    return jsonify(results)


@admin_bp.route('/programs/<id>', methods=['GET'])
@require_admin_permission
def admin_get_program_by_id(id):
    """ Fetch Program data
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    program = db().coll_programs.find_one({'_id': obj_id})

    if not program:
        raise EntityNotFound(entity_name, id)

    program_version = program.get('version')
    program_schema = schema_program_v2 if program_version == 2 else schema_program

    valid_status = v.validate(program, program_schema)
    if not valid_status and v.errors:
        program['validation_errors'] = str(v.errors)

    if valid_status != program.get('isValid'):
        program['isValid'] = valid_status
        # TODO: Update the DB

    program['screenOneMinimum'] = get_screen_one_minimum()
    program['tempImpactMultiple'] = calc_impact_multiple(program).get('score')

    if program_version == 2:
        append_virtual_fields_v2(program)
    else:
        create_virtual_fields(program)
        math_strength_rating(program)

    # add proposals and brands that have preferred/selected this program
    add_selected_preferred_fields(program)
    form_program_output(program['outputs'])

    return jsonify(program)


@admin_bp.route('/programs', methods=['POST'])
@require_admin_permission
def insert_program():
    """ Create new Program
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Program'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    if 'name' not in document:
        return create_validation_error_response('name')

    document.pop('_id', None)

    create_slug(target_collection, document)
    document = set_vocabulary(document)
    create_virtual_fields(document)
    math_screen_one_score(document)
    remove_empty(document)

    document['isValid'] = v.validate(document, schema_program)
    if v.errors:
        current_app.logger.warning('Program validation error: %s', v.errors)

    document = v.normalized(document, schema_program)
    if v.errors:
        raise ValidationError(v.errors)

    auto_fill_tags(document)

    try:
        nonprofit_id = ObjectId(document['nonprofit'])
        document['nonprofit'] = create_ref(nonprofit_id)
        document['isValidNonprofit'] = get_is_valid_nonprofit([nonprofit_id])
    except KeyError:
        pass  # ignored

    inserted_id = db().coll_programs.insert_one(set_created_at(document)).inserted_id
    document['_id'] = inserted_id

    if inserted_id:
        npo_name = get_nonprofit(document['nonprofit']).get('name')
        slack_obj = {
            'id': str(inserted_id),
            'name': document['name'],
            'npo': npo_name,
            'by': request.user.get('first_name') + ' ' + request.user.get('last_name')
        }
        send_si_platform_message(True, 'Program created successfully', slack_obj)
    else:
        send_si_platform_message(False, 'Program creation failed', document)

    # todo Investigate how to remove this call
    create_virtual_fields(document)

    math_strength_rating(document)

    return jsonify(document)


@admin_bp.route('/programs/importer', methods=['POST'])
@require_admin_permission
def importer_programs():
    """ Import Programs through CSV files
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    requestBody:
      description: CSV content to be imported
      required: true
      content:
        text/plain:
          schema:
            type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              properties:
                count:
                  type: integer
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    documents = _programs_csv_parser(request.data)

    to_import_list = []
    for index, document in enumerate(documents):
        # try:
        remove_empty(document)

        ensure_valid_elements(document, 'outputs', 'esg')

        # Relationship between program and nonprofit will be doing manually
        document.pop('nonprofit', None)

        create_slug(target_collection, document)
        set_fields_to_list(document)
        set_booleans(document)

        try:
            document = set_vocabulary(document)
        except MissingVocabulary as ex:
            messages = []
            for e in ex.vocab_errors:
                messages.append('column {0}:{1}'.format(field_to_column[e.key], e.value))

            raise GivewithError('Unable to import CSV entries, in row {0} - Vocabulary not found on {1}'
                                .format(index + 4, messages))

        create_virtual_fields(document)
        math_screen_one_score(document)
        math_output_values(document)

        # import as inactive
        document['active'] = False

        # validate CSV only
        v.validate(document, schema_program_csv)
        if v.errors:
            msg = format_cerberus_errors_for_csv(v.errors, field_to_column)
            current_app.logger.error('Program validation error on row {0} - {1}'.format(index + 4, msg))
            raise GivewithError('Unable to import CSV entries, validation error on row {0} - {1}'
                                .format(index + 4, msg))

        document['isValid'] = v.validate(document, schema_program)
        if v.errors:
            current_app.logger.error('Program validation error on row {0} - {1}'.format(index + 4, v.errors))
        document = v.normalized(document, schema_program)
        if v.errors:
            raise ValidationError(v.errors)

        auto_fill_tags(document)

        to_import_list.append(set_created_at(document))

        # except Exception as e:
        #     return current_app.response_class(
        #         response='Unable to import CSV entries, validation error on entry {0} - {1}'.format(index, str(e)),
        #         status=400)  # Bad Request

    try:
        result = db().coll_programs.insert_many(to_import_list)
        send_si_platform_message(True, 'Program import successful', result.inserted_ids)
    except Exception as e:
        raise GivewithError('Error inserting entries on database: {0}'.format(str(e)))

    return jsonify(count=len(to_import_list))


@admin_bp.route('/programs/importer/<id>', methods=['PUT'])
@require_admin_permission
def importer_program(id):
    """ Replace Program data
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      description: CSV content to be imported
      required: true
      content:
        text/plain:
          schema:
            type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    documents = _programs_csv_parser(request.data)
    if not documents or len(documents) > 1:
        raise GivewithError('CSV file is empty or have more than one row with data')

    try:
        document = documents[0]
        ensure_valid_elements(document, 'outputs', 'esg')

        # Relationship between program and nonprofit will be doing manually
        document.pop('nonprofit', None)

        set_fields_to_list(document)
        set_booleans(document)

        try:
            document = set_vocabulary(document)
        except MissingVocabulary as ex:
            messages = []
            for e in ex.vocab_errors:
                messages.append('column {0}:{1}'.format(field_to_column[e.key], e.value))

            raise GivewithError('Unable to import CSV entries, in row 4 - Vocabularies not found on {}'
                                .format(messages))

        create_virtual_fields(document)
        remove_empty(document)
        math_screen_one_score(document)
        math_output_values(document)

        # validate CSV only
        v.validate(document, schema_program_csv)
        if v.errors:
            msg = format_cerberus_errors_for_csv(v.errors, field_to_column)
            current_app.logger.error('Program validation error: {}'.format(msg))
            raise GivewithError('Unable to import CSV, invalid fields: {}'.format(msg))

        db_document = db().coll_programs.find_one(filter={'_id': obj_id})
        if not db_document:
            current_app.logger.error('Program {} not found on database, can not update'.format(id))
            raise GivewithError('Program {} not found on database, can not update'.format(id))

        db_document.update(document)
        # validate entire document after merged with data already on DB
        db_document['isValid'] = v.validate(db_document, schema_program)
        if v.errors:
            current_app.logger.warning('Program validation error: %s', v.errors)

        db_document = v.normalized(db_document, schema_program)
        if v.errors:
            raise ValidationError(v.errors)

        auto_fill_tags(db_document)

        db().coll_programs.replace_one(filter={'_id': obj_id}, replacement=set_last_updated(db_document))

        # todo Investigate how to remove this call
        create_virtual_fields(db_document)

        set_brands_is_valid_of_programs(obj_id)

        add_selected_preferred_fields(db_document)

        return jsonify(db_document)
    except Exception as e:
        raise GivewithError('Unable to import CSV row: {}'.format(str(e)))


@admin_bp.route('/programs/<id>', methods=['PATCH'])
@require_admin_permission
def patch_program(id):
    """ Update Program
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Program'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    if 'name' not in document:
        return create_validation_error_response('name')

    if 'related' in document and isinstance(document['related'], list):
        document['related'] = [create_ref(related) for related in document['related']]

    program_version = document.get('version')
    program_schema = schema_program_v2 if program_version == 2 else schema_program

    if program_version == 2:
        # set vocabulary, creating virtual fields and calculating screen one score for db
        # isn't relevant to v2 programs
        pass
    else:
        document = set_vocabulary(document)
        create_virtual_fields(document)
        math_screen_one_score(document)

    remove_empty(document)

    document['isValid'] = v.validate(document, program_schema)
    if v.errors:
        current_app.logger.warning('Program validation error: %s', v.errors)

    document.pop('createdAt', None)

    try:
        nonprofit_id = ObjectId(document['nonprofit'])
        document['nonprofit'] = create_ref(nonprofit_id)
        document['isValidNonprofit'] = get_is_valid_nonprofit([nonprofit_id])
    except KeyError:
        pass  # ignored

    updated_document = db().coll_programs.find_one_and_update(filter={'_id': obj_id},
                                                              update={'$set': set_last_updated(document)},
                                                              return_document=ReturnDocument.AFTER)

    # consistency check because when nothing updates, query returns None
    if not updated_document:
        updated_document = document

    if updated_document.get('version') == 2:
        append_virtual_fields_v2(updated_document)
    else:
        # todo Investigate how to remove this call
        create_virtual_fields(updated_document)
        math_strength_rating(updated_document)
        set_brands_is_valid_of_programs(obj_id)

    add_selected_preferred_fields(updated_document)

    return jsonify(updated_document)


@admin_bp.route('/programs/<id>', methods=['PUT'])
@require_admin_permission
def update_program(id):
    """ Replace Program data
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Program'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    if 'name' not in document:
        return create_validation_error_response('name')

    db_document = db().coll_programs.find_one(filter={'_id': obj_id}, projection={'createdAt': True, 'name': True})

    # if name is new and the name already exists
    name = document['name']
    collation = Collation(locale=get_locale_string(), strength=CollationStrength.PRIMARY) # case insensitive
    if name != db_document['name'] and db().coll_programs.count_documents({'name': name}, limit=1, collation=collation):
        raise GivewithError('A program already exists with this name')

    program_version = document.get('version')
    program_schema = schema_program_v2 if program_version == 2 else schema_program

    if document.get('version') == 2:
        # set vocabulary, creating virtual fields and calculating screen one score for db
        # isn't relevant to v2 programs
        pass
    else:
        document = set_vocabulary(document)
        create_virtual_fields(document)
        math_screen_one_score(document)

    remove_empty(document)
    document['isValid'] = v.validate(document, program_schema)
    if v.errors:
        current_app.logger.warning('Program validation error: %s', v.errors)

    document = v.normalized(document, program_schema)
    if v.errors:
        raise ValidationError(v.errors)

    try:
        nonprofit_id = ObjectId(document['nonprofit'])
        document['nonprofit'] = create_ref(nonprofit_id)
        document['isValidNonprofit'] = get_is_valid_nonprofit([nonprofit_id])
    except KeyError:
        pass  # ignore

    document['_id'] = obj_id
    document['createdAt'] = db_document['createdAt']

    db().coll_programs.replace_one(filter={'_id': obj_id}, replacement=set_last_updated(document))

    if document.get('version') == 2:
        append_virtual_fields_v2(document)
    else:
        # todo Investigate how to remove this call
        create_virtual_fields(document)
        math_strength_rating(document)
        set_brands_is_valid_of_programs(obj_id)

    add_selected_preferred_fields(document)

    return jsonify(document)


@admin_bp.route('/programs/refresh-tags', methods=['PUT'])
@require_admin_permission
def refresh_tags_programs():
    """ Update Tags on all Programs
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    responses:
      204:
        description: No content
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    programs = db().coll_programs.find()
    for program in programs:
        current_app.logger.debug('name: %s' % program['name'])

        remove_empty(program)
        auto_fill_tags(program, override=True)
        db().coll_programs.replace_one(filter={'_id': program['_id']}, replacement=set_last_updated(program))

    return current_app.response_class(status=204)

@admin_bp.route('/programs/<id>/deletion-side-effects', methods=['GET'])
@require_admin_permission
def admin_get_program_deletion_side_effects(id):
    validate_object_id(id, 'mm_programs')

    program = get_program(ObjectId(id), projection={'submissionFormId': True,})

    deletion_info = get_program_deletion_side_effects(program, id)

    return jsonify(deletion_info)

@admin_bp.route('/programs/<id>', methods=['DELETE'])
@require_admin_permission
def delete_program(id):
    """ Remove Program
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_programs.find_one_and_delete({'_id': obj_id})
    if not deleted_document:
        raise EntityNotFound(entity_name, id)

    deleted_document.update({'isValid': False})

    set_brands_is_valid_of_programs(obj_id)
    remove_program_from_brands(obj_id)
    remove_program_dependencies(obj_id)

    return jsonify(deleted_document)


def get_program_deletion_side_effects(program, id):
    # program submission form
    program_submission_form = db().coll_surveys.find_one({'programId': ObjectId(id)}, projection={'submissionFormName': True})
    psf_data = []
    if program_submission_form:
        psf_data.append({**program_submission_form, 'name' : program_submission_form.get('submissionFormName')})

    # funding form
    funding_forms = list(db().coll_program_funding_forms.find({'program': ObjectId(id)}, projection={'name': True}))

    # completion form
    completion_forms = list(db().coll_completion_forms.find({'program': ObjectId(id)}, projection={'name': True}))

    # deal
    # -- within recommended programs
    deals_recommended = list(db().coll_deals.find({'selectedRecommendedPrograms._id' : {'$in' : [ObjectId(id)]}}, projection={'name': True, 'reference': True}))

    # -- chosen program
    deals_chosen_program = list(db().coll_deals.find({'selectedProgram' : ObjectId(id)}, projection={'name': True, 'reference': True, 'status': True}))

    # preferred programs cart
    brands = list(db().coll_brands.find({'$or' : [
                                          {'preferredPrograms.cart' : {'$in': [ObjectId(id)]}},
                                          {'preferredPrograms.selected' : {'$in': [ObjectId(id)]}},
                                          {'preferredPrograms.additional' : {'$in': [ObjectId(id)]}}
                                        ]},
                                        projection={'name': True}))

    deletion_info = [
        {
            'data': psf_data,
            'heading': 'By deleting this program, this program submission form will be deleted:',
            'collection': 'programSubmissionForm',
            'isDeleted': True,
        },
        {
            'data': funding_forms,
            'heading': 'By deleting this program, this/these funding form(s) will be deleted:',
            'collection': 'fundingForm', #used to map collection name to FE route
            'isDeleted': True,
        },
        {
            'data': completion_forms,
            'heading': 'By deleting this program, this/these completion form(s) will be deleted:',
            'collection': 'completionForm',
            'isDeleted': True,
        },
        {
            'data': deals_recommended,
            'heading': 'By deleting this program, this/these deal(s) will be affected in the following ways:',
            'collection': 'deals',
            'fieldsAffected': ['selectedRecommendedPrograms'],
            'valueDeleted': 'This program'
        },
        {
            'data': deals_chosen_program,
            'heading': 'By deleting this program, this/these deal(s) will be affected in the following ways:',
            'collection': 'deals',
            'fieldsAffected': ['selectedProgram'],
            'valueDeleted': 'This program'
        },
        {
            'data': brands,
            'heading': 'By deleting this program, this/these brand(s) will be affected in the following ways:',
            'collection': 'brands',
            'fieldsAffected': ['preferredPrograms'],
            'valueDeleted': 'This program'
        }
    ]

    return deletion_info

def remove_program_dependencies(id):
    # funding form
    db().coll_program_funding_forms.delete_many({'program': ObjectId(id)})

    # completion form
    db().coll_completion_forms.delete_many({'program': ObjectId(id)})

    # deal
    # -- within recommended programs
    deals_recommended = list(db().coll_deals.find({'selectedRecommendedPrograms._id' : {'$in' : [ObjectId(id)]}}, projection={'selectedRecommendedPrograms': True}))
    for deal in deals_recommended:
        changes = {}
        selected_recommended_programs = deal.get('selectedRecommendedPrograms', [])
        for (index, program) in enumerate(deal.get('selectedRecommendedPrograms', [])):
            if program.get('_id') == ObjectId(id):
                selected_recommended_programs.pop(index)

        changes['selectedRecommendedPrograms'] = selected_recommended_programs
        update_document_by_id('deals', deal.get('_id'), changes)

    # -- chosen program
    db().coll_deals.delete_many({'selectedProgram' : ObjectId(id)})

    # preferred programs cart
    brands = list(db().coll_brands.find({'$or' : [
                                          {'preferredPrograms.cart' : {'$in': [ObjectId(id)]}},
                                          {'preferredPrograms.selected' : {'$in': [ObjectId(id)]}},
                                          {'preferredPrograms.additional' : {'$in': [ObjectId(id)]}}
                                        ]},
                                        projection={'name': True, 'preferredPrograms': True}))

    for brand in brands:
        changes = {}
        keys = ['cart', 'selected', 'additional']
        for key in keys:
            if ObjectId(id) in brand.get('preferredPrograms', {}).get(key):
                preferred_programs = brand.get('preferredPrograms').get(key)
                try:
                    delete_index = preferred_programs.index(ObjectId(id))
                    preferred_programs.pop(delete_index)
                except ValueError:
                    send_loggly('No program id found in brand id ' + str(id) + ' preferred programs field: preferredPrograms.' + key)

                changes['preferredPrograms.' + key] = preferred_programs

        update_document_by_id('mm_brands', brand.get('_id'), changes)

    # program submission form
    db().coll_surveys.find_one_and_delete({'programId': ObjectId(id)})

@admin_bp.route('/programs/<id>/upload', methods=['POST'])
@require_admin_permission
def program_upload_file(id):
    """ Upload a file to a specific Field on Program
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      content:
        multipart/form-data:
          schema:
            properties:
              field:
                type: string
              file:
                type: string
                format: binary

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    db_document = db().coll_programs.find_one({'_id': obj_id})

    if not db_document:
        raise EntityNotFound(entity_name, id)

    if 'file' not in request.files:
        raise UnsupportedPayload()

    file = request.files['file']
    if file.name == '':
        raise UnsupportedPayload()

    if 'field' not in request.form:
        return create_validation_error_response('field')

    field = request.form['field']
    is_not_watermarked = request.form.get('watermarkFile', False)
    # stopgap: generic uploads to program (uploads other than deliverables/images) should not be public
    is_public = to_bool(request.form.get('isPublic'))

    file_location = ''
    if to_bool(is_not_watermarked):
        file_location = watermark_file(file)

    if file_location:
        with open(file_location, 'rb') as watermarked_image:
            url = upload_file(watermarked_image, 'programs/%s/%s' % (id, secure_filename(file.filename)), is_public, file.content_type)
        # delete file after upload
        os.remove(file_location)
    else:
        url = upload_file(file, 'programs/%s/%s' % (id, secure_filename(file.filename)), is_public)

    # Payload for deliverables comes in the format of `deliverables.field`,
    # so we first check to make sure both parts exist and the first element
    # is `deliverables`
    fields = field.split('.')
    if len(fields) == 2 and fields[0] == 'deliverables':
        deliverables = {fields[1]: url}

        if 'deliverables' in db_document:
            db_document['deliverables'] = dict_merge(db_document['deliverables'], deliverables)
        else:
            db_document['deliverables'] = deliverables
    elif 'sampleDeliverables' in field:
        set_descendant_key(url, db_document, field)
    elif '.' in field:
        # NOTE: 'name' field is only for ui display purposes only, do not use to lookup the file
        # use the string after the last / in the url as the filename for lookups
        field_data = {'name': file.filename, 'url': url}
        set_descendant_key(field_data, db_document, field)
    else:
        db_document[field] = url

    program_version = db_document.get('version')
    program_schema = schema_program_v2 if program_version == 2 else schema_program

    db_document['isValid'] = v.validate(db_document, program_schema)

    # remove not mapped fields
    db_document = v.normalized(db_document, program_schema)
    if v.errors:
        raise ValidationError(v.errors)

    db().coll_programs.update_one({'_id': ObjectId(id)}, {'$set': set_last_updated(db_document)})
    return jsonify(db_document)


@admin_bp.route('/programs/<id>/<field>/<file_name>', methods=['DELETE'])
@require_admin_permission
def delete_program_asset(id, field, file_name):
    """ Remove file from specific field of a Program
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string
      - name: field
        in: path
        required: true
        schema:
          type: string
      - name: file_name
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Program'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = db().coll_programs.find_one({'_id': obj_id})

    if not document:
        raise EntityNotFound(entity_name, id)

    payload = request.get_json()
    is_public = to_bool(payload.get('isPublic'))

    # generic (non deliverable/PDP images) uploads are of the format: value = {'name': filename, 'url': url}
    # deliverable uploads are of the format: value = url
    if 'deliverables' in field or '.' not in field:
        url_path = field
    else:
        url_path = f'{field}.url'

    value = get_descendant_key(document, url_path, None)

    if value is None:
        raise GivewithError(f'Field {file_name} not found in document {id}')

    if not value.endswith(file_name):
        raise GivewithError(f'File {file_name} on document {id} is not on field {field}')

    if not delete_file('programs', id, file_name, is_public):
        raise GivewithError(f'Unable to delete {file_name} of document {id}')

    pop_descendant_key(document, field, None)
    remove_empty(document)

    program_version = document.get('version')
    program_schema = schema_program_v2 if program_version == 2 else schema_program

    document['isValid'] = v.validate(document, program_schema, update=True)

    updated_document = db().coll_programs.find_one_and_replace(filter={'_id': obj_id},
                                                               replacement=set_last_updated(document),
                                                               return_document=ReturnDocument.AFTER)
    return jsonify(updated_document)


@admin_bp.route('/programs/auto-fill', methods=['POST'])
@require_admin_permission
def auto_fill_program():
    """ Suggest Program Tags according to provided data
    ---
    tags: ['Program Admin']

    security:
      - GivewithAuth: []

    requestBody:
      content:
        application/json:
          schema:
            properties:
              causes:
                type: array
                items:
                  type: string
              impacts:
                type: array
                items:
                  type: string
              audience:
                type: array
                items:
                  type: string
              animalHabitat:
                 type: string
              forestProtection:
                 type: boolean

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              properties:
                cdp:
                  type: array
                  items:
                    type: string
                esg:
                  type: array
                  items:
                    type: string
                gri:
                  type: array
                  items:
                    type: string
                sdg:
                  type: array
                  items:
                    type: string
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    program_id = document.get('program_id', None)

    data_trigger = trigger_program_tagging(program_id)

    if data_trigger.status_code != 200:
        raise GivewithError('ResearchAPI tagging not available')

    new_tags = {}
    program = db().coll_programs.find_one({'_id': ObjectId(program_id)})
    print(program, file=sys.stderr)
    gri = program.get('gri', {}).get('data', None)
    esg = program.get('esg', {}).get('data', None)

    if esg:
        esg = [x.get('issue') for x in esg]

    themes = program.get('themes', {}).get('data', None)
    csrhub = program.get('csrhub', {}).get('data', None)
    sasb = program.get('sasb', {}).get('data', None)
    sdg = program.get('sdg', {}).get('data', None)
    cdp = program.get('cdp', {}).get('data', None)

    if gri:
        new_tags['gri'] = gri
    if esg:
        new_tags['esg'] = esg
    if themes:
        new_tags['themes'] = themes
    if csrhub:
        new_tags['csrhub'] = csrhub
    if sasb:
        new_tags['sasb'] = sasb
    if sdg:
        new_tags['sdg'] = sdg
    if cdp:
        new_tags['cdp'] = cdp

    return jsonify(new_tags)


@admin_bp.route('/programs/<id>/duplicate', methods=['POST'])
@require_admin_permission
def duplicate_program(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = db().coll_programs.find_one({'_id': obj_id})

    if not document:
      raise EntityNotFound(entity_name, id)

    document.pop('_id')
    document.pop('slug')
    document['name'] = document.get('name', '') + ' - COPY'
    create_slug(target_collection, document)

    inserted_id = db().coll_programs.insert_one(set_created_at(document)).inserted_id
    document['_id'] = inserted_id

    if inserted_id:
        npo_name = get_nonprofit(document['nonprofit']).get('name')
        slack_obj = {
            'id': str(inserted_id),
            'name': document['name'],
            'npo': npo_name,
            'by': request.user.get('first_name') + ' ' + request.user.get('last_name')
        }
        send_si_platform_message(True, 'Program duplicated successfully', slack_obj)
    else:
        send_si_platform_message(False, 'Program duplication failed', document)

    # todo Investigate how to remove this call
    create_virtual_fields(document)

    math_strength_rating(document)

    return jsonify(document)


##
# Public Endpoints
##
@public_mm_bp.route('/programs/<id_or_slug>', methods=['GET'])
def get_program_by_id(id_or_slug):
    """ Fetch Program data
    ---
    tags: ['Program Public']

    parameters:
      - name: id_or_slug
        in: path
        required: true
        schema:
          type: string
      - brand:
        description: Brand Slug to compare Tags
        in: query
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                $ref: '#/components/schemas/PublicProgram'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    program_filter = {'isValid': True,
                      'isValidNonprofit': True,
                      'active': True,
                      '$or': [{'ignoreThreshold': True},
                              {'screenOneScore': {'$gte': get_screen_one_minimum()}}]}
    brand_filter = {
        'isValid': True,
        'isValidNonprofit': True,
        'isValidProgram': True,
    }
    try:
        program_filter['_id'] = ObjectId(id_or_slug)
    except InvalidId:
        program_filter['slug'] = id_or_slug

    program = db().coll_programs.find_one(filter=program_filter)

    if not program:
        raise EntityNotFound(entity_name, id_or_slug)

    if 'brand' in request.args:
        brand_id_or_slug = request.args['brand']

        try:
            brand_filter['_id'] = ObjectId(brand_id_or_slug)
        except InvalidId:
            brand_filter['slug'] = brand_id_or_slug

        brand = db().coll_brands.find_one(brand_filter)

        if brand:
            program['cdp'] = group_vocabulary('cdp', brand, program)
            program['gri'] = group_vocabulary('gri', brand, program)
            program['sdg'] = group_vocabulary('sdg', brand, program)

            custom_investor_metrics = brand.get('customInvestorMetrics', [])
            for metric in custom_investor_metrics:
                program_ref = metric.get('program', None)
                if program_ref and metric['program'] == program['_id']:
                    del metric['program']
                    program['esg']['data'].append(metric)
        else:
            transform_investor_metrics(program)
    else:
        transform_investor_metrics(program)

    try:
        nonprofit_ref = program['nonprofit']
        program['nonprofit'] = db().coll_nonprofits.find_one({'_id': nonprofit_ref,
                                                         'isValid': True})

        program_filter.update({'nonprofit': nonprofit_ref, '_id': {'$ne': program['_id']}})
        program_filter.pop('slug', None)

        program['related'] = list(db().coll_programs.find(filter=program_filter,
                                                     projection={'slug': True, 'name': True})
                                  .sort('name', ASCENDING)
                                  .collation(Collation(locale=get_locale_string(), numericOrdering=True)))
    except KeyError:
        pass  # ignore

    program['topics'] = list({get_vocabulary_v2(_id).get('topic') for _id in program.get('themes', {}).get('data', [])})
    program['screenOneMinimum'] = get_screen_one_minimum()

    program_version = program.get('version')

    if program_version == 2:
        append_virtual_fields_v2(program)
    else:
        create_virtual_fields(program)
        math_strength_rating(program)

    expand_vocabulary_label(program, version=program_version)
    transform_esg_public(program)

    # Annotate contentSettings (also available from /settings)
    settings = db().coll_settings.find_one(projection={'contentSettings': 1})
    if settings:
        program['contentSettings'] = settings['contentSettings']

    return jsonify(filter_program(program))


@admin_bp.route('/program/impact-multiple:calc', methods=['POST'])
@require_admin_permission
def impact_multiple():
    program = request.get_json()
    return jsonify(calc_impact_multiple(program))


@admin_bp.route('/program/impact-multiple/scc-conversion', methods=['GET'])
@require_admin_permission
def get_scc_conversion():
    return jsonify(list(db().coll_program_scc_conversion.find()))


@admin_bp.route('/program/impact-multiple/divisor', methods=['GET'])
@require_admin_permission
def get_divisor():
    return jsonify(list(db().coll_program_im_divisor.find()))


