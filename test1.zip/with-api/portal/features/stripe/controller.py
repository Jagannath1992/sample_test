from flask import jsonify, request
from flask_restx import Namespace, Resource
from flask_accepts import accepts, responds
from werkzeug.exceptions import NotFound, Forbidden
from portal.features.orders.validators import StatusValidator
from portal.features.stripe.schema import CancelSubscriptionRequest, CreateCustomerPortalSessionRequest, CreateCustomerPortalSessionResponse, CreateOrderSetupCheckoutSessionRequest, CreateOrderSetupCheckoutSessionResponse, CreateSetupCheckoutSessionRequest, CreateSetupCheckoutSessionResponse, CreateSubscriptionCheckoutSessionRequest, CreateSubscriptionCheckoutSessionResponse, DeleteAutoPayRequest, UpdateSubscriptionFrequencyRequest
from portal.shared.auth.requests import role_required
from portal.shared.auth.security import get_validated_account_id, has_role
from portal.shared.enums import OrderStatus, UserRole, AccountType
from portal.shared.repositories import account_repository, instance_settings_repository, locale_repository, order_repository
from portal.shared.services import order_service, stripe_service

namespace = Namespace('stripe', description='Stripe related operations')


@namespace.route('/setup-checkout-session')
class SetupCheckoutSession(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @namespace.response(400, 'Bad Request')
    @namespace.response(404, 'Account not found')
    @accepts(schema=CreateSetupCheckoutSessionRequest, api=namespace)
    @responds(schema=CreateSetupCheckoutSessionResponse, api=namespace)
    def post(self):
        account_id = get_validated_account_id(request.parsed_obj.pop('accountId', None), request)
        account = account_repository().get_single(account_id, {'stripe.customerId': 1, 'instance._id': 1})
        if not account:
            raise NotFound('Account not found')
        instance = instance_settings_repository().get_single(account['instance']['_id'], {'settings.locale._id': 1})
        if not instance:
            raise NotFound('Instance settings not found')
        locale = locale_repository().get_single(instance['settings']['locale']['_id'], {'settings.currency': 1})
        if not locale:
            raise NotFound('Locale not found')
        currency = locale['settings']['currency']
        checkout_session = stripe_service().create_setup_checkout_session(
            account['stripe']['customerId'], currency, **request.parsed_obj)
        return checkout_session


@namespace.route('/order-setup-checkout-session')
class OrderSetupCheckoutSession(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @accepts(schema=CreateOrderSetupCheckoutSessionRequest, api=namespace)
    @responds(schema=CreateOrderSetupCheckoutSessionResponse, api=namespace)
    def post(self):
        account_id = get_validated_account_id(request.parsed_obj.pop('accountId', None), request)
        account = account_repository().get_single(account_id, {'stripe.customerId': 1, 'instance._id': 1})
        if not account:
            raise NotFound('Account not found')
        if account.get('stripe', {}).get('autopay', {}).get('paymentMethodId'):
            raise Forbidden('Cannot use pay as you go when autopay is enabled')
        order_ids = request.parsed_obj['order_ids']
        for order_id in order_ids:
            if (not has_role(UserRole.SUPER_ADMIN, request.user) and not order_repository().has_access(order_id, request.user['accountId'])):
                raise Forbidden('You do not have permission to access one or more Gives')
            validator = StatusValidator(order_id, OrderStatus.COMPLETED.value, request.user)
            if not validator.is_authorized():
                raise Forbidden('Not authorized to update Give status')
            if not validator.is_valid():
                raise Forbidden('Invalid Give status')
        instance = instance_settings_repository().get_single(account['instance']['_id'], {'settings.locale._id': 1})
        if not instance:
            raise NotFound('Instance settings not found')
        locale = locale_repository().get_single(instance['settings']['locale']['_id'], {'settings.currency': 1})
        if not locale:
            raise NotFound('Locale not found')
        currency = locale['settings']['currency']
        checkout_session = stripe_service().create_order_setup_checkout_session(
            account['stripe']['customerId'], currency, **request.parsed_obj)
        for order_id in order_ids:
            order_update = {
                'status': OrderStatus.PENDING_PAYMENT.value,
                'comments': [
                    {'comment': 'Pending payment processing'}
                ]
            }
            order_service().timestamp_comments(order_update, request.user['username'], order_id)
            order_repository().patch(order_id, order_update, request.user['username'])
        return checkout_session


@namespace.route('/customer-portal-session')
class CustomerPortalSession(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @namespace.response(400, 'Bad Request')
    @namespace.response(404, 'Account not found')
    @accepts(schema=CreateCustomerPortalSessionRequest, api=namespace)
    @responds(schema=CreateCustomerPortalSessionResponse, api=namespace)
    def post(self):
        account_id = get_validated_account_id(request.parsed_obj.get('accountId'), request)
        account = account_repository().get_single(account_id, {'stripe.customerId': 1})
        if not account:
            raise NotFound('Account not found')
        portal_session = stripe_service().create_customer_portal_session(account['stripe']['customerId'])
        return portal_session


@namespace.route('/subscription-checkout-session')
class SubscriptionCheckoutSession(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @namespace.response(404, 'Resource not found')
    @accepts(schema=CreateSubscriptionCheckoutSessionRequest, api=namespace)
    @responds(schema=CreateSubscriptionCheckoutSessionResponse, api=namespace)
    def post(self):
        data = request.parsed_obj
        account_id = get_validated_account_id(data.get('accountId'), request)
        account = account_repository().get_single(
            account_id, {'stripe.customerId': 1, 'stripe.trialPeriodUsed': 1, 'instance._id': 1})
        if not account:
            raise NotFound('Account not found')
        instance = instance_settings_repository().get_single(account['instance']['_id'])
        checkout_session = stripe_service().create_subscription_checkout_session(
            instance, data['frequency'],
            account['stripe'].get('trialPeriodUsed'),
            account['stripe']['customerId'],
            data['success_url'],
            data['cancel_url'],
            account['type'])
        return checkout_session


@namespace.route('/autopay')
class AutoPay(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @namespace.response(400, 'Bad Request')
    @namespace.response(404, 'Account not found')
    @accepts(schema=DeleteAutoPayRequest, api=namespace)
    def delete(self):
        account_id = get_validated_account_id(request.parsed_obj.get('accountId'), request)
        account_update = {'stripe': {'autopay': {'paymentMethodId': None, 'enabledDate': None}}}
        account = account_repository().patch(account_id, account_update, request.user['username'])
        if not account:
            raise NotFound('Account not found')


@namespace.route('/subscription')
class Subscription(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @namespace.response(404, 'Resource not found')
    @accepts(schema=UpdateSubscriptionFrequencyRequest, api=namespace)
    def patch(self):
        account_id = get_validated_account_id(request.parsed_obj.get('accountId'), request)
        account = account_repository().get_single(account_id)
        if not account:
            raise NotFound('Account not found')
        subscription_id = account['stripe']['subscription']['id']
        current_frequency = account['subscriptionFrequency']
        new_frequency = request.parsed_obj['subscriptionFrequency']
        instance = instance_settings_repository().get_single(account['instance']['_id'])
        account_update = stripe_service().update_subscription_frequency(
            instance, subscription_id, current_frequency, new_frequency, account['type'])
        if account_update:
            account_repository().patch(account_id, account_update, request.user['username'])

    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @accepts(schema=CancelSubscriptionRequest, api=namespace)
    def delete(self):
        account_id = get_validated_account_id(request.parsed_obj.get('accountId'), request)
        account = account_repository().get_single(account_id, {'stripe.subscription.id': 1})
        if not account:
            raise NotFound('Account not found')
        subscription_id = account['stripe']['subscription']['id']
        account_update = stripe_service().cancel_subscription(subscription_id)
        account_repository().patch(account_id, account_update, request.user['username'])


@namespace.route('/webhook')
class ReceivedWebhook(Resource):
    # For Testing Purposes Only
    def post(self):
        stripe_signature = request.headers.get('stripe-signature')
        data = request.data
        try:
            stripe_service()._webhook_received(stripe_signature, data)
        except Exception as e:
            return e

        return jsonify({'status': 'success'})
