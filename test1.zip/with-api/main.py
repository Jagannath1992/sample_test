from portal import create_app

app = create_app()

if __name__ == '__main__':
    if app is not None:
        app.run(host='0.0.0.0', port=5052) # nosec
