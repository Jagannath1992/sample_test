from matchmaking import db

# rename = [
#     ('High-need audience', 'High-need beneficiaries'),
#     ('Long term changes', 'Long-term changes')
# ]

strength_map = {
    'causes': {
        'vocab': ['Environment'],
        'strengthKey': 'audienceAttribute'
    },
    'programApproach': {
        'vocab': [
            'Changing behavior (train; mentor)',
            'Building capacity (strengthen institutions, programs or systems)'
        ],
        'strengthKey': 'programApproach'
    },
    'studyEvidenceType': {
        'vocab': [
            'Published in peer-reviewed journal',
            'Independent study conducted by research institution',
        ],
        'strengthKey': 'primaryOutcomeEffectiveness'
    },
    'researchDataType': {
        'vocab': [
            'Government data sets',
            'Historical, longitudinal data',
        ],
        'strengthKey': 'dataMeasurementType'
    }
}

# rename do vocabulary labels -> these are low impact vocabulary labels (just labels to surface to front-end as
# program strength categories)
# for item in rename:
#     db().coll_vocabulary.find_one_and_update({'type': 'effectiveness', 'label': item[0]}, {
#         '$set': {'label': item[1]}
#     })

for key, values in strength_map.items():
    for item in values.get('vocab'):
        db().coll_vocabulary.find_one_and_update({'type': key, 'label': item}, {'$set': {
            'strengthKey': values.get('strengthKey')
        }})
