import json
from typing import List
from datetime import datetime
import requests
from portal.shared.email.enums import EmailTemplateId
from portal.shared.enums import OrderStatus, UserRole,InstanceType
from portal.shared.constants import ROLES_TO_STRING
from portal.shared.repositories import account_approval_repository, locale_repository, user_repository, account_repository
from portal.shared.strings import format_currency, format_phone_number, format_zip_code

def get_product_type(instanceType):
    if instanceType== InstanceType.PROCUREMENT.value:
        product = "BuyWith"
    else:
        product = "SellWith"
    return product


class EmailService:
    def __init__(self, config: dict):
        self.base_url = config['base_url']
        self.enabled = config.get('enabled', True)

    def send_email(self, payload):        
        if self.enabled:
            response = requests.post(self.base_url, data=json.dumps(payload))
            return response

    def send_new_account_created_email(self, instance, user, account):
        templateId = EmailTemplateId.PORTAL_ACCOUNTS_NEW_ACCOUNT_CREATED
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']
        company = account['company']
        address = company['address']
        industry = account['industry']
        instanceType = instance['type']
        product = get_product_type(instanceType)
        data = {
            'firstName': user['first_name'],
            'lastName': user['last_name'],
            'username': user['username'],
            'company': company['name'],
            'address1': address['address1'],
            'address2': address['address2'],
            'city': address['city'],
            'stateProvince': address['stateProvince'],
            'postalCode': format_zip_code(address['postalCode']),
            'industry': industry['displayLabel'],
            'phoneNumber': format_phone_number(company['phoneNumber']),
            'website': company['website'],
            'activateUrl': f'{portal_url}/app/accounts/{account["_id"]}',
            'app': product
        }
        tos = [givewith_email]
        payload = _format_payload(templateId, data, tos)
        response = self.send_email(payload)
        return response

    def send_account_activated_email(self, instance, account):
        templateId = EmailTemplateId.PORTAL_ACCOUNTS_ACCOUNT_ACTIVATED
        givewith_email = instance['settings']['givewithEmail']
        data = {}
        tos = user_repository().get_usernames_by_role(account['_id'], [UserRole.SUPER_ADMIN, UserRole.FINANCE])
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_account_deactivated_email(self, instance, account):
        templateId = EmailTemplateId.PORTAL_ACCOUNTS_ACCOUNT_DEACTIVATED
        givewith_email = instance['settings']['givewithEmail']
        instanceType = instance['type']
        product = get_product_type(instanceType)
        data = {
            'clientName': account['company']['name'],
            'sageCustomerId': account.get('sageCustomerId', ''),
            'app': product
        }
        tos = user_repository().get_usernames_by_role(account['_id'], [UserRole.FINANCE])
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_user_resend_invite_email(self):
        templateId = EmailTemplateId.PORTAL_USERS_RESEND_INVITE
        data = {}
        tos = []
        payload = _format_payload(templateId, data, tos)
        response = self.send_email(payload)
        return response

    def send_give_submitted_for_approval_email(self, instance, order):
        templateId = EmailTemplateId.PORTAL_GIVES_SUBMITTED_FOR_APPROVAL
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']
        grand_total = order['grandTotal']
        symbol = self._get_currency_symbol(instance)
        data = {
            'giveId': order['giveId'],
            'customerName': order['customerName'],
            'grandTotal': format_currency(symbol, grand_total),
            'quoteNumber': order.get('quoteNumber', ''),
            'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details',
            'showErrorMessage': False
        }
        account_id = order['account']['_id']
        approver = account_approval_repository().get_approver(account_id, grand_total)
        tos = [approver] if approver else []
        if not tos:
            tos = user_repository().get_usernames_by_role(account_id, [UserRole.APPROVER])
        if not tos:
            tos = user_repository().get_usernames_by_role(account_id, [UserRole.ORG_ADMIN])
            data['showErrorMessage'] = True
        ccs = [order['createdBy']]
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, ccs, bccs)
        response = self.send_email(payload)
        return response

    def send_give_approved_email(self, instance, order, account, cause_area):
        templateId = EmailTemplateId.PORTAL_GIVES_APPROVED
        givewith_email = instance['settings']['givewithEmail']
        symbol = self._get_currency_symbol(instance)
        data = {
            'giveId': order['giveId'],
            'grandTotal': format_currency(symbol, order['grandTotal']),
            'quoteNumber': order.get('quoteNumber', ''),
            'customerName': order['customerName'],
            'approvalComment': next((comment['comment'] for comment in order['comments'] if comment['newStatus'] == OrderStatus.APPROVED.value), ''),
            'causeAreaTooltip': cause_area['tooltip'],
            'clientName': account['company']['name'],
            'sageCustomerId': account.get('sageCustomerId', ''),
            'showErrorMessage': False
        }
        account_id = order['account']['_id']
        tos = user_repository().get_usernames_by_role(account_id, [UserRole.TRANSACTOR])
        if not tos:
            tos = user_repository().get_usernames_by_role(account_id, [UserRole.ORG_ADMIN])
            data['showErrorMessage'] = True
        tos.append(order['createdBy'])
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_give_denied_email(self, instance, order):
        templateId = EmailTemplateId.PORTAL_GIVES_DENIED
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        symbol = self._get_currency_symbol(instance)
        data = {
            'giveId': order['giveId'],
            'customerName': order['customerName'],
            'grandTotal': format_currency(symbol, order['grandTotal']),
            'quoteNumber': order.get('quoteNumber', ''),
            'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
        }
        tos = [order['createdBy']]
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_give_financial_hold_email(self, instance, order, account):
        templateId = EmailTemplateId.PORTAL_GIVES_FINANCIAL_HOLD
        givewith_email = instance['settings']['givewithEmail']
        symbol = self._get_currency_symbol(instance)
        data = {
            'giveId': order['giveId'],
            'customerName': order['customerName'],
            'grandTotal': format_currency(symbol, order['grandTotal']),
            'quoteNumber': order.get('quoteNumber', ''),
            'clientName': account['company']['name'],
            'sageCustomerId': account.get('sageCustomerId', ''),
            'showErrorMessage': False
        }
        account_id = order['account']['_id']
        tos = user_repository().get_usernames_by_role(account_id, [UserRole.FINANCE])
        if not tos:
            tos = user_repository().get_usernames_by_role(account_id, [UserRole.ORG_ADMIN])
            data['showErrorMessage'] = True
        ccs = [order['createdBy']]
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, ccs, bccs)
        response = self.send_email(payload)
        return response

    def send_give_completed_won_email(self, instance, order, account, cause_area, tos: List[str] = []):
        templateId = EmailTemplateId.PORTAL_GIVES_COMPLETED_WON
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']
        symbol = self._get_currency_symbol(instance)
        data = {
            'giveId': order['giveId'],
            'causeAreaImageUrl': f'{portal_url}{cause_area["detailImageName"]}',
            'grandTotal': format_currency(symbol, order['grandTotal']),
            'quoteNumber': order.get('quoteNumber', ''),
            'customerName': order['customerName'],
            'causeAreaTooltip': cause_area['tooltip'],
            'clientName': account['company']['name'],
            'sageCustomerId': account.get('sageCustomerId', '')
        }
        if not tos:
            tos = [order['createdBy']]
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_give_completed_won_shared_email(self, instance, order, tos: List[str] = []):
        templateId = EmailTemplateId.PORTAL_GIVES_SHARED
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        if not tos:
            tos = user_repository().get_usernames_by_role(order['sharedWith']['_id'], [UserRole.ORG_ADMIN])
        data = {
            'Subject': f"{order['account']['name']}'s Give has successfully been completed",
            'Message': f"{order['account']['name']} has successfully completed a Give",
            'CustomerSharedWithName': order['sharedWith']['name'],
            'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
        }
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_give_approved_shared_email(self, instance, order, tos: List[str] = []):
        templateId = EmailTemplateId.PORTAL_GIVES_SHARED
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        if not tos:
            tos = user_repository().get_usernames_by_role(order['sharedWith']['_id'], [UserRole.ORG_ADMIN])
        data = {
            'Subject': f"{order['account']['name']}'s Give is ready to be reviewed",
            'Message': f"{order['account']['name']} has shared a Give with you to be reviewed.",
            'CustomerSharedWithName': order['sharedWith']['name'],
            'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
        }
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_give_abandoned_lost_email(self, instance, order):
        templateId = EmailTemplateId.PORTAL_GIVES_ABANDONED_LOST
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        symbol = self._get_currency_symbol(instance)
        data = {
            'giveId': order['giveId'],
            'grandTotal': format_currency(symbol, order['grandTotal']),
            'quoteNumber': order.get('quoteNumber', ''),
            'customerName': order['customerName'],
            'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
        }
        tos = [order['createdBy']]
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_balance_deposit_to_account_email(self, instance, account):
        templateId = EmailTemplateId.PORTAL_BALANCE_DEPOSIT_TO_ACCOUNT
        givewith_email = instance['settings']['givewithEmail']
        login_url = instance['settings']['loginUrl']
        instanceType = instance['type']
        product = get_product_type(instanceType)
        data = {
            'clientName': account['company']['name'],
            'sageCustomerId': account.get('sageCustomerId', ''),
            'loginUrl': login_url,
            'app':product
        }
        tos = user_repository().get_usernames_by_role(account['_id'], [UserRole.FINANCE])
        bccs = [givewith_email]
        payload = _format_payload(templateId, data, tos, [], bccs)
        response = self.send_email(payload)
        return response

    def send_role_update_email(self, instance, user, updated_user, assigner):
        templateId = EmailTemplateId.PORTAL_ROLES_UPDATED
        givewith_email = instance['settings']['givewithEmail']
        now = datetime.now().strftime('%Y/%m/%d %I:%M:%S')
        data = {
            'userName': user['name'] if user['name'] else user['first_name']+" "+user['last_name'],
            'userEmail': user['username'],
            'currentRoles': [ROLES_TO_STRING[role] for role in updated_user['roles']],
            'previousRoles': [ROLES_TO_STRING[role] for role in user['roles']] if user['roles'] else 'N/A',
            'assigner': assigner,
            'timeStamp': now
        }
        tos = [givewith_email]
        ccs = []
        payload = _format_payload(templateId, data, tos, ccs)
        response = self.send_email(payload)
        return response

    def send_client_payment_failed_email(self, instance, account):
        template_id = EmailTemplateId.PORTAL_PAYMENT_FAILED_CLIENT
        givewith_email = instance['settings']['givewithEmail']
        data = {
            'customerName': account['company']['name'],
            'sageCustomerId': account.get('sageCustomerId', '')
        }
        tos = user_repository().get_usernames_by_role(account["_id"], [UserRole.ORG_ADMIN, UserRole.FINANCE])
        ccs = []
        bccs = [givewith_email]
        payload = _format_payload(template_id, data, tos, ccs, bccs)
        response = self.send_email(payload)
        return response

    def send_generic_notification(self, instance: dict, subject: str, message: str, data: dict):
        template_id = EmailTemplateId.PORTAL_GENERIC_NOTIFICATION
        givewith_email = instance['settings']['givewithEmail']
        data = {
            'subject': subject,
            'message': message,
            'data': data
        }
        tos = [givewith_email]
        ccs = []
        payload = _format_payload(template_id, data, tos, ccs)
        response = self.send_email(payload)
        return response

    def _get_currency_symbol(self, instance) -> str:
        locale = locale_repository().get_single(instance['settings']['locale']['_id'])
        symbol = locale['settings']['symbol']
        return symbol


def _format_payload(templateId: EmailTemplateId, data: dict, tos: List[str], ccs: List[str] = [], bccs: List[str] = []):
    return {
        'tos': tos,
        'ccs': ccs,
        'bccs': bccs,
        'template': {
            'id': templateId.value,
            'data': data
        }
    }
