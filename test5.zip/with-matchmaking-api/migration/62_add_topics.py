from pymongo import ReturnDocument
from matchmaking import db

topics = [
    {'label': 'Economic empowerment', 'type': 'topic', 'versions': [2]},
    {'label': 'Youth development', 'type': 'topic', 'versions': [2]},
]

data = [
    ('themes', 'Economic empowerment', 'Economic empowerment'),
    ('esg', 'Access to Communications', 'Economic empowerment'),
    ('esg', 'Access to Finance', 'Economic empowerment'),
    ('gri', 'Infrastructure Investment', 'Economic empowerment'),
    ('gri', 'Positive Economic Impacts in the Community', 'Economic empowerment'),
    ('sasb', 'Access and Affordability', 'Economic empowerment'),
    ('sdg', 'Decent work and economic growth', 'Economic empowerment'),
    ('themes', 'Youth development', 'Youth development'),
]

db().coll_vocabulary.insert_many(topics)


def get_topic_id(label):
    vocab = db().coll_vocabulary.find_one({'type': 'topic', 'label': label})
    return vocab['_id']


# ---- Associate existing vocabulary with topics ----- #############3
for vocab_tuple in data:
    vocab_type = vocab_tuple[0]
    vocab_label = vocab_tuple[1]
    topic_label = vocab_tuple[2]

    topic_id = get_topic_id(topic_label)
    updated_vocab = db().coll_vocabulary.find_one_and_update({'type': vocab_type, 'label': vocab_label},
                                                             {'$set': {'topic': topic_id}},
                                                             return_document=ReturnDocument.AFTER)

    if not updated_vocab or not updated_vocab.get('topic'):
        print(f'Error adding topic to vocabulary: {vocab_type} - {vocab_label}')

updated_diversity = db().coll_vocabulary.find_one_and_update({'type': 'topic', 'label': 'Diversity and inclusion'},
                                                             {'$set': {'label': 'Diversity, equity and inclusion'}},
                                                             return_document=ReturnDocument.AFTER)