import pytest
import requests
from bson.objectid import ObjectId
from matchmaking.service import email

def test_asset_email_recipient(test_deal, user_id, test_db):
    emails = email.NotificationEmail(objective='completed', data=test_deal, roles=['customer'])

    user_email = test_db.user.find_one({'_id': user_id}).get('username')
    r = email.prepare_completed_request(emails)

    assert user_email in r[0].get('tos')


def test_new_deal_email(test_deal):
    responses = email.NotificationEmail(objective='new_deal', data=test_deal).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_selection_pending_email(test_deal):
    responses = email.NotificationEmail(objective='program_selection_pending', data=test_deal).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_program_selected_email(test_deal):
    responses = email.NotificationEmail(objective='program_selected', data=test_deal, roles=['customer', 'client', 'manager']).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_partially_confirmed_email(test_deal):
    responses = email.NotificationEmail(objective='partially_confirmed', data=test_deal, roles=['client', 'manager'], cc=['test@givewith.com']).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_confirm_transaction_email(test_deal):
    responses = email.NotificationEmail(objective='confirm_transaction', data=test_deal, roles=['manager'], cc=['test@givewith.com']).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_payment_pending_email(test_deal):
    responses = email.NotificationEmail(objective='payment_pending', data=test_deal).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_completed_email(test_deal):
    responses = email.NotificationEmail(objective='completed', data=test_deal, roles=['client', 'customer']).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_covid_completed_email(test_deal):
    test_deal['type'] = 'covid'
    responses = email.NotificationEmail(objective='covid_completed', data=test_deal, roles=['client', 'customer']).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_covid_client_confirm_email(brand_id):
    test_deal = {
        "name" : "SJ test split covid email #2",
        "givewithCustomer" : brand_id,
        "client" : brand_id,
        "type" : "covid",
        "totalBudget" : 0,
        "fundingAmount" : 20.0,
        "givewithPortion" : 20.0,
        "giveOption" : "fixed",
        "splitGiveAmount" : True,
        "currency" : "USD",
        "givewithCustomerUser" : "5d1a713205944281edb3eec5",
        "givewithCustomerEmails" : [
            "shanyan.jiang@givewith.com"
        ],
        "clientEmails" : [
            "shanyan.jiang@givewith.com"
        ],
        "createdBy" : ObjectId("5d1a713205944281edb3eec5"),
        "reference" : "3259",
        "slug" : "RlyJ32OtN3u0WCa",
        "password" : "KWy27q5k8xAw",
        "status" : "PAYMENT_PENDING",
        "givewithCustomerRole" : "supplier",
        "isValid" : True,
        "manager" : ObjectId("5d767cecd5b3a526195f7300"),
        "deliverables" : {
            "givewithCustomer" : {
                "deliverables" : []
            },
            "client" : {
                "deliverables" : []
            }
        },
        "selectedRecommendedPrograms" : []
    }

    responses = email.NotificationEmail(objective='covid_client_confirm', data=test_deal, roles=['client']).send()
    assert len(responses) > 0

    for r in responses:
        assert r.status_code == 202


def test_timeout(test_deal):
    internal_dns = 'http://ec2-100-26-32-138.compute-1.amazonaws.com'

    request = email.NotificationEmail(objective='new_deal', data=test_deal)
    request.email_service_api = internal_dns
    with pytest.raises(requests.exceptions.ConnectTimeout):
        request.send()

