import requests
import base64
import jwt

from flask import Blueprint, Response, redirect, request, current_app
from app.utils.saml_idp import create_assertion_response, create_idp_metadata
from app.db.database import get_db
from app.rest.cognito_authorize import PRIVATE_KEY

saml_bp = Blueprint('saml_idp', __name__)


"""
@api {GET} /v1/saml/idp/metadata Get SAML IDP metadata
@apiName GetIdpMetadata
@apiGroup Saml
@apiDescription Get idp metadata

"""
@saml_bp.route('/idp/metadata', methods=['GET'])
def metadata():
    return Response(create_idp_metadata(current_app.config, 'givewith'), mimetype='application/xml')


"""
@api {post} /v1/saml/golden/login Login to Golden SP
@apiName SAMLGoldenLogin
@apiGroup Saml
@apiDescription Login to Golden SP

@apiHeaderExample {json} Header-Example:
{
    "Authorization": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZGE3NTd..."
}
@apiParamExample {json} Body example:
{
    "relayState": "insights",
}

@apiSuccessExample Success-Response:
HTTP/1.1 302 found
"""
@saml_bp.route('/golden/login', methods=['POST'])
def saml_login_golden():
    # validate auth token
    token = request.headers.get('authorization')
    if token is None:
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, PRIVATE_KEY, algorithms='HS256')
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401

    golden_config = current_app.config['config']['saml']['sp']['golden']

    # validate user org ID
    if claims.get('orgId') not in golden_config['org_ids']:
        return 'Invalid user org id', 400

    # load user from db
    username = claims.get('email')
    user = get_db().user.find_one({'username': username})
    if user is None:
        return 'User %s not found' % username, 401

    # create assertion response
    assertion_response = create_assertion_response(user, current_app.config)
    response_bytes = assertion_response.encode('ascii')
    encoded_response = base64.b64encode(response_bytes)

    # post assertion response to golden sp
    resp = requests.post(
        url=golden_config['consume_service_endpoint'],
        json={
            'RelayState': request.json.get('relayState'),
            'SAMLResponse': encoded_response.decode("utf-8"),
        },
        allow_redirects=False
    )

    if resp.status_code != 302:
        return resp, 401

    redirect(resp.headers.get('location'))

@saml_bp.route('/golden/assertion_token', methods=['GET'])
def get_golden_assertion_token():
    # validate auth token
    token = request.headers.get('authorization')
    if token is None:
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, PRIVATE_KEY, algorithms='HS256')
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401

    golden_config = current_app.config['config']['saml']['sp']['golden']

    # validate user org ID
    if claims.get('orgId') not in golden_config['org_ids']:
        return 'Invalid user org id', 400

    # load user from db
    username = claims.get('email')
    user = get_db().user.find_one({'username': username})
    if user is None:
        return 'User %s not found' % username, 401

    # create assertion response
    assertion_response = create_assertion_response(user, current_app.config)
    response_bytes = assertion_response.encode('ascii')
    return base64.b64encode(response_bytes)
