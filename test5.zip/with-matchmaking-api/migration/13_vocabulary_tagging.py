from matchmaking import db
from copy import deepcopy

# Clone existing vocabulary into a temporary new collection as backup
all_vocabulary = list(db().coll_vocabulary.find({}))
db().db.get_collection('mm_vocabulary_backup').insert_many(all_vocabulary)

# Tag all existing vocabulary as version 1 and version 2
db().coll_vocabulary.update_many({}, {'$set': {'versions': [1, 2]}})

# Tag only the following vocabulary as version 2
# version_agnostic_types = {'cdp', 'esg', 'gri', 'sdg', 'dataMeasurement', 'scaleType', 'researchType',
#                           'programApproach', 'industry', 'csrhub', 'sasb', 'effectiveness'}

# for vocabulary_type in version_agnostic_types:
#     db().coll_vocabulary.update_many({'type': vocabulary_type}, {'$addToSet': {'versions': 2}})

# # Audience of certain types are agnostic for now
# audience_groups = {'age', 'gender'}
# for group in audience_groups:
#     db().coll_vocabulary.update_many({'type': 'audience', 'group': group}, {'$addToSet': {'versions': 2}})
#----------------------------------------

# Utility Functions
def _insert(document):
    db().coll_vocabulary.insert_one(document)

# insert a new label as v2
def _insert_generic_labels(labels, type_string):
    for item in labels:
        document = {
            'label': item,
            'type': type_string,
            'versions': [2]
        }
        db().coll_vocabulary.insert_one(document)

# rename fields using label if it exist by duplicate existing, tagging as v1
# and inserting duplicate as v2
def _duplicate_rename_insert(document, labels):
    global deepcopy
    _id = document['_id']
    for item in labels:
        if document['label'] == item[0]:

            # Duplicate document and clean up
            duplicate = deepcopy(document)
            duplicate['label'] = item[1]
            duplicate['versions'] = [2]
            duplicate.pop('_id', None)

            # Insert duplicate, update existing to version 1 only
            db().coll_vocabulary.insert_one(duplicate)
            db().coll_vocabulary.update_one({'_id': _id}, {'$set': {'versions': [1]}})

            return

# same as _duplicate_rename_insert but duplicate all and update all
# using update_dict
def _duplicate_rename_insert_update(document, labels, update_dict):

    # sample: {'type': 500}
    _id = document['_id']

    # Duplicate document and clean up
    duplicate = deepcopy(document)

    # update all keys
    for key, value in update_dict.items():
        duplicate[key] = value

    duplicate['versions'] = [2]
    duplicate.pop('_id', None)

    for item in labels:
        if document['label'] == item[0]:
            duplicate['label'] = item[1]
            break

        # Insert duplicate, update existing to version 1 only
    db().coll_vocabulary.insert_one(duplicate)
    db().coll_vocabulary.update_one({'_id': _id}, {'$set': {'versions': [1]}})


#------------------- Duplicate version 1 only vocabulary to version 2 and implement changes ----------------------------

######### ATTRIBUTES ################
attributes = db().coll_vocabulary.find({'type': 'audience', 'group': 'attribute'})

rename = [
    ('People with Disabilities', 'People with disabilities/disabled persons'),
    ('Parents/Guardians', 'Parents/guardians'),
    ('LGBTQI+', 'LGBTQQIA+')
]

for attribute in attributes:
    _duplicate_rename_insert(attribute, rename)

new_labels = ['Women and girls', 'Indigenous peoples', 'Elderly populations (65+)', 'People of color']

for label in new_labels:
    _insert({
        'label': label,
        'type': 'audience',
        'group': 'attribute',
        'versions': [2]
    })

################# CAUSES #################

causes = db().coll_vocabulary.find({'type': 'causes'})

rename = [
    ('Arts & Culture', 'Arts and culture'),
    ('Criminal Justice', 'Criminal justice'),
    ('Economic Development', 'Economic empowerment'),
    ('Food/Hunger', 'Food and hunger'),
    ('Housing/Homelessness', 'Housing and homelessness'),
    ('Human Rights/Civil Society', 'Human rights and civic engagement'),
    ('Public Health', 'Health and wellness')
]

for cause in causes:
    _duplicate_rename_insert(cause, rename)

new_labels = ['Disaster response, relief and recovery']

for label in new_labels:
    _insert({
        'label': label,
        'type': 'causes',
        'icon': 'assets/causes/icons/disaster-response-relief-recovery.svg', # need to populate this svg
        'slug': 'disaster-response-relief-recovery',
        'versions': [2]
    })

################## THEMES #######################
themes = db().coll_vocabulary.find({'type': 'themes'})

rename = [
    ('Disaster Relief', 'Disaster response, relief and recovery'),
    ('Youth Development', 'Youth development'),
    ('LGBTQ+', 'LGBTQQIA+'),
    ('People with Disabilities', 'People with disabilities/disabled persons'),
    ('Women and Girls', 'Women and girls'),
    ('Poverty Alleviation', 'Poverty alleviation'),
    ('Housing and Homelessness', 'Housing and homelessness'),
    ('Health and Wellness', 'Health and wellness'),
    ('Food and Hunger', 'Food and hunger'),
    ('Economic Empowerment', 'Economic empowerment'),
    ('Diversity and Inclusion', 'Diversity and inclusion'),
    ('Criminal Justice', 'Criminal justice'),
    ('Arts and Culture', 'Arts and culture'),
    ('Animal Welfare', 'Animal welfare'),
    ('Aging Populations', 'Aging populations')
]

for theme in themes:
    _duplicate_rename_insert(theme, rename)

new_labels = ['Human rights and civic engagement', 'Immigrants', 'Indigenous peoples', 'People of color', 'Refugees']
_insert_generic_labels(new_labels, 'themes')

################### IMPACT ###########################
impacts = db().coll_vocabulary.find({'type': 'impact'})

rename = [
    ('Enhance community infrastructure', 'Enhance physical community infrastructure'),
    ('Increase access to clean water', 'Increase access to potable water'),
    ('Increase active participation in society', 'Increase civic participation'),
    ('Protect endangered, vulnerable or threatened species', 'Protect endangered, vulnerable, or threatened species'),
    ('Increase land protection', 'Increase protection of public lands'),
    ('Increase water protection', 'Increase protection of public waters'),
    ('Reduce carbon impact', 'Reduce carbon and greenhouse gas impact')
]

for impact in impacts:
    _duplicate_rename_insert(impact, rename)

new_labels = ['Improve conditions after natural disasters and crises', 'Increase recycling and/or reduce waste']
_insert_generic_labels(new_labels, 'impact')


################## INTERVENTIONS ##############################
interventions = db().coll_vocabulary.find({'type': 'interventions'})

rename = [
    ('Develop skills to secure employment housing and financial stability', 'Develop skills to secure employment, housing and financial stability'),
    ('Increase college readiness access persistence and completion', 'Increase college readiness, access, persistence and completion'),
    ('Provide quality water', 'Provide potable water'),
    ('Provide STEM interest proficiency and persistence programs', 'Provide STEM interest, proficiency and persistence programs'),
    ('Provide sufficient affordable and nutritious foods', 'Provide sufficient, affordable and nutritious foods'),
    ('Provide support programs to maintain employment housing financial stability and physical and mental health', 'Provide support programs to maintain employment, housing, financial stability, and physical and mental health')
]

## special case - since all fields type are begin renamed, duplicate all and rename all
for intervention in interventions:
    _duplicate_rename_insert_update(intervention, rename, update_dict={'type': 'approach'})


################## ANIMAL HABITATS ##########################
habitats = db().coll_vocabulary.find({'type': 'animalHabitats'})

rename = [
    ('Animals living on land', 'Land'),
    ('Animals living in water', 'Water'),
    ('Animals living both on land and in water', 'Both land and water')
]

for habitat in habitats:
    _duplicate_rename_insert(habitat, rename)


# ------------------------ ADDING NEW VOCABULARY ------------------------------------- #

############ INTERVENTION DURATION ###########
new_labels = ['Ongoing', 'One-time']
_insert_generic_labels(new_labels, 'approachDuration')


############## BOOLEAN ####################
new_labels = ['Yes', 'No']
_insert_generic_labels(new_labels, 'boolean')


############## EVIDENCE TYPE ################3
new_labels = [
    'Independent study conducted by research institution',
    'Published in peer-reviewed journal',
    'Outcome report or white paper or program summary published by your organization',
    'Published by authors employed and/or funded by your organization'
]
_insert_generic_labels(new_labels, 'studyEvidenceType') # v2 for existing v1 researchType


#################  STUDY/DESIGN DESCRIPTION ##############
new_labels = [
    'Randomized controlled trial (RCT)',
    'Quasi-experimental designs (QED) with well-defined comparison group',
    'Anecdotal evidence',
    'Qualitative report on impact',
    'Survey of participants',
    'Pre/post analysis of participants without a control group'
]
_insert_generic_labels(new_labels, 'studyDesignType')

################ RESEARCH DATATYPES ######################
new_labels = [
    'Government data sets',
    'Historical, longitudinal data',
    'Self-reported survey results',
    'Observation data'
]
_insert_generic_labels(new_labels, 'researchDataType')

################## EFFECT ##############
new_labels = [
    'Positive effect',
    'Mixed effect',
    'Negative effect',
    'No effect'
]
_insert_generic_labels(new_labels, 'effect')

################ STRENGTH #############
new_labels = [
    'Strong',
    'Neutral',
    'Weak'
]
_insert_generic_labels(new_labels, 'strength')
