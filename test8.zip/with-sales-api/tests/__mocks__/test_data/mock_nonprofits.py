from bson.objectid import ObjectId

nonprofits = [
    {
        '_id': ObjectId('5c387a30a08c41000a17947f'),
        'name': 'Katarina'
    },
    {
        '_id': ObjectId('5e4da534dba98318df35a302'),
        'name': 'Black Girls Code'
    }
]