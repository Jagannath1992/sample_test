import pandas as pd

from flask import send_file

from matchmaking.permission_decorator import require_admin_permission
from matchmaking.controllers import admin_bp
from matchmaking.dao.utils import get_documents

"""
@api {get} /admin/month-reconciliation Get Monthly Reconciliation Data
@apiName Get Monthly Reconciliation
@apiGroup Billing
@apiDescription Get month end reconciliation between Stripe, Product Admin, and Sage

"""
@admin_bp.route('/month-reconciliation', methods=['GET'])
@require_admin_permission
def month_reconciliation():
    table = {
        'Date': {},
        'Customer-ID': {},
        'Givewith-Client-Name': {},
        'Give-Transaction-ID': {},
        'Status': {},
        'Transaction-Amount': {},
        'Give-Amount': {},
        'Social-Cause': {},
        'Current-Account-Balance': {},
        'User': {},
    }

    orders = get_documents('order')
    for counter in range(len(orders)):
        order = orders[counter]
        if 'orderDate' in order:
            table['Date'][counter] = order.get('orderDate', '').strftime("%m/%d/%Y")
        else:
            table['Date'][counter] = ''
        table['Customer-ID'][counter] = str(order.get('account', {}).get('_id', '')).strip()
        table['Givewith-Client-Name'][counter] = order.get('customerName', '').strip()
        table['Give-Transaction-ID'][counter] = str(order.get('_id', '')).strip()
        table['Status'][counter] = order.get('status', '').strip()
        table['Transaction-Amount'][counter] = order.get('quoteAmount', '')
        table['Give-Amount'][counter] = order.get('grandTotal', '')
        table['Social-Cause'][counter] = order.get('causeArea', {}).get('name', '').strip()
        table['User'][counter] = order.get('createdBy', '').strip()

    data = pd.DataFrame(table)

    open("month_reconciliation.csv", "w").close()
    f = open("month_reconciliation.csv", "a")
    f.write(data.to_csv())
    f.close()

    f = open("month_reconciliation.csv")
    return send_file(f, as_attachment=True, attachment_filename='month_reconciliation.csv')


