# This file is a temporary fix for the brand dedup lambda until we get the deplopyment working for lambdas
import json
import requests

import boto3
import Levenshtein

from base64 import b64decode
from os import environ

from bson import ObjectId
from pymongo import MongoClient, DESCENDING, ASCENDING, TEXT, errors, ReturnDocument

from ..mongodb import db



ENV = environ['ENV'].upper()
SLACK_URL = environ['BRAND_DEDUP_SLACK_URL']


DEDUP_KEYS = set(['name', 'ISIN'])
N_GRAM_LENGTH = 12
MIN_LEVENSHTEIN_DISTANCE = 3

N_GRAM_FILTER = []

def dedup_brands_handler():
    brands = get_brands()

    duplicates = dedup_brands(brands)

    if duplicates:
        send_slack_message(True, duplicates)
    else:
        # send_slack_message(False, {})
        pass

    return {'message': json.dumps(duplicates)}


def get_brands():
    projection={'_id': True}
    for key in DEDUP_KEYS:
        projection[key] = True

    cursor = db().coll_brands.find(filter={}, projection=projection)

    return list(cursor)


def clean_field(field):
    string = str(field).lower().strip()

    for word in N_GRAM_FILTER:
        string.replace(word, '')

    return string


def dedup_brands(brands):
    """ Deduplicates brand data """
    duplicates = {}

    # For each key: check each brand for duplicates
    for key in DEDUP_KEYS:
        if key == 'name':
            # dedup_names_n_gram(brands, duplicates)
            dedup_names_levenshtein(brands, duplicates)
            continue

        memo = {}
        for brand in brands:
            if key in brand:
                brand_id = brand['_id']
                value = clean_field(brand[key])

                if value in memo:
                    add_duplicate(duplicates, key, memo[value], brand_id)
                else:
                    memo[value] = brand_id

    return list(duplicates.values())


def dedup_names_n_gram(brands, duplicates):
    memo = {}
    for brand in brands:
        if 'name' in brand:
            brand_id = brand['_id']
            brand_name = clean_field(brand['name'])

            # There will be multiple values when we are checking 'name'
            values = get_n_grams(brand_name, N_GRAM_LENGTH)

            # The set of values that have already been memoized
            memoized = set(memo.keys())

            collisions = memoized.intersection(values)
            new_keys = values - collisions

            # Add the collisions to duplicates
            if collisions:
                collision_key = collisions.pop()
                add_duplicate(duplicates, 'n_gram', memo[collision_key], brand_id)

            # Add the newly found keys
            for new_key in new_keys:
                memo[new_key] = brand_id
        else:
            print(str(brand['_id']) + ' does not have a name')
            continue


def dedup_names_levenshtein(brands, duplicates):
    memo = {}
    for brand in brands:
        if 'name' in brand:
            brand_id = brand['_id']
            brand_name = clean_field(brand['name'])

            collision = ''
            for memo_brand_name in memo.keys():
                distance = Levenshtein.distance(brand['name'], memo_brand_name)
                if distance <= MIN_LEVENSHTEIN_DISTANCE:
                    collision = memo_brand_name
                    break

            if collision:
                add_duplicate(duplicates, f'Levenshtein- {distance}', memo[collision], brand_id)
            else:
                memo[brand_name] = brand_id

        else:
            print(str(brand['_id']) + ' does not have a name')
            continue



def add_duplicate(duplicates, key, brand_a, brand_b):
    """
    Orders brands then appends them to duplicates so that
    we only record a pair of brands once
    """
    brand_a = str(brand_a)
    brand_b = str(brand_b)

    # String to be hashed by the dict so we do not get duplicate collisions
    if brand_a > brand_b:
        dict_key = f'{brand_a}{brand_b}'
    else:
        dict_key = f'{brand_b}{brand_a}'

    duplicates[dict_key] = (key, brand_a, brand_b)


def get_n_grams(word, n):
    """ Gets all n grams for a given word

    Returns a set of n-grams
    """
    n_grams = []
    end_index = len(word) + 1 - n
    for x in range(0, end_index):
        n_grams.append(word[x : x+n])

    return set(n_grams)


def send_slack_message(success, results):
    headers = {'Content-Type': 'application/json'}

    if ENV.lower() == 'production' or ENV.lower() == 'prod':
        pretext = 'production: '
    elif ENV.lower() == 'staging' or ENV.lower() == 'stage':
        pretext = 'staging: '
    else:
        pretext = ''
    pretext += 'Brand dedup job successfully ran' if success else 'Brand Dedup job failed'

    for result in results:
        pretext += f"\nBrand: `{result[1]}`; Reason: {result[0]}"

    data = {
        'pretext': pretext,
        'color': '#DAF7A6' if success else '#C70039',
        'fields': []
    }

    try:
        r = requests.post(SLACK_URL, data=json.dumps(data), headers=headers)
    except Exception as e:
        print(e)
    return 'SUCCESS' if success else 'FAILED'
