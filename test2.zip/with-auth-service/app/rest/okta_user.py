from http.client import OK
import jwt

from flask import request, Blueprint, jsonify
from bson import ObjectId
from datetime import datetime, timedelta
from app.loggly import send_loggly
from app.rest.okta_auth import get_user_platform

from app.service import services
from app.service.emails import EmailService
from app.rest.cognito_authorize import PRIVATE_KEY
from app.db.utils import add_document, get_document_by_id, update_document_by_id, \
    get_document, update_document, hard_delete_document, get_documents


okta_user_bp = Blueprint('okta_user', __name__)


"""
@api {post} /user Create User
@apiName Create User
@apiGroup Okta
@apiDescription Create user

@apiError 400 Bad request

@apiParamExample {json} Authenticate user example:
{
    "active": true,
    "businessAddress": "business address",
    "departmentType": "Marketing",
    "first_name": "first name",
    "last_name": "last name",
    "orgId": "5c1415685b03bb0008c222dc",
    "orgName": "Translate Bio Inc",
    "orgType": "brand",
    "phoneNumber": "(315) 416 4432",
    "type": "client",
    "username": "shanyan.jiang+5@givewith.com",
}

@apiErrorExample {json} Error create user response example:
{
    "errorCode": "E0000001",
    "errorSummary": "Api validation failed: login",
    "errorLink": "E0000001",
    "errorId": "oaevdkCqMz8QCijvnUv9nnA5w",
    "errorCauses": [
        {
            "errorSummary": "login: An object with this field already exists in the current organization"
        }
    ]
}

@apiSuccessExample {json} Success create user response example:
{
    "id": "00ux6ioeew8pAYYyt5d6",
    "status": "ACTIVE",
    "created": "2021-06-10T06:42:18.000Z",
    "activated": "2021-06-10T06:42:18.000Z",
    "statusChanged": "2021-06-10T06:42:18.000Z",
    "lastLogin": null,
    "lastUpdated": "2021-06-10T06:42:18.000Z",
    "passwordChanged": "2021-06-10T06:42:18.000Z",
    "type": {
        "id": "otyrc85e2cLaYR8pq5d6"
    },
    "profile": {
        "firstName": "first name",
        "lastName": "last name",
        "mobilePhone": "(315) 416 4432",
        "secondEmail": null,
        "login": "shanyan.jiang+12@givewith.com",
        "email": "shanyan.jiang+12@givewith.com"
    },
    "credentials": {
        "password": {},
        "emails": [{
            "value": "shanyan.jiang+12@givewith.com",
            "status": "VERIFIED",
            "type": "PRIMARY"
        }],
        "provider": {
            "type": "OKTA",
            "name": "OKTA"
        }
    }
}
"""
@okta_user_bp.route('/', methods=['POST'])
def create_user():
    okta_service = services['okta']
    creation_request = request.json
    tmp_password = okta_service.generate_temporary_password()
    password = creation_request.pop('password', tmp_password)
    platformName = creation_request.get('app', 'Givewith')
    is_active = False

    # Some apps are allowed to set the password when creating users
    if platformName in ['Salesforce']:
        tmp_password = password
        is_active = True

    okta_request = {
        "profile": {
            "firstName": creation_request['first_name'],
            "lastName": creation_request['last_name'],
            "email": creation_request['username'],
            "login": creation_request['username'],
        },
        "credentials": {
            "password": {"value": tmp_password}
        }
    }

    # set optional fields.
    if 'phoneNumber' in creation_request:
        okta_request['profile']['mobilePhone'] = creation_request['phoneNumber']
    response = okta_service.create_user(okta_request)
    if response.status_code != 200:
        return response.content, response.status_code

    # validate if admin user is under admin brand
    admin_brand = get_document('admin_brand', {'type': 'admin_brand'})
    if admin_brand and creation_request['type'] == 'admin' and creation_request['orgId'] != str(admin_brand['brand_id']):
        return 'admin user must be add under admin brand', 400

    okta_id = response.json()['id']
    creation_request['oktaId'] = okta_id
    creation_request['name'] = creation_request['first_name'] + ' ' + creation_request['last_name']
    creation_request['active'] = is_active
    
    # orgId is not set for new "Portal" users
    if "orgId" in creation_request and creation_request['orgId']:
        creation_request['orgId'] = ObjectId(creation_request['orgId'])

    # pull metadata object before creating user document
    metadata = creation_request.pop('metadata', {})
    skip_email = metadata.pop('skipEmail', False)

    user = get_document('user', {'username': creation_request['username']})
    if user is None:
        user = add_document('user', creation_request)
    else:
        update_document_by_id('user', user['_id'], {'oktaId': okta_id})

    if not skip_email:
        email_service = EmailService()
        supplier_invite  = metadata.pop('supplierInvite', False)
        if supplier_invite :
            response = email_service.send_supplier_invite_email(creation_request['username'], tmp_password, creation_request['first_name'], metadata)
        else:
            response = email_service.send_user_activation_email(creation_request['username'], tmp_password, platformName)
        if response.status_code != 202:
            return response.content, response.status_code

    return jsonify(user), 200


"""
@api {post} /user Update User
@apiName Update User
@apiGroup Okta
@apiDescription Update user

@apiError 400 Bad request

@apiParamExample {json} Authenticate user example:
{
    "active": true,
    "businessAddress": "business address",
    "departmentType": "Marketing",
    "first_name": "first name",
    "last_name": "last name",
    "orgId": "5c1415685b03bb0008c222dc",
    "orgName": "Translate Bio Inc",
    "orgType": "brand",
    "phoneNumber": "(315) 416 4432",
    "type": "client",
    "username": "shanyan.jiang+5@givewith.com",
}

@apiSuccessExample {json} Success create user response example:
{
    "active": true,
    "businessAddress": "business address",
    "departmentType": "Marketing",
    "first_name": "first name",
    "last_name": "last name",
    "orgId": "5c1415685b03bb0008c222dc",
    "orgName": "Translate Bio Inc",
    "orgType": "brand",
    "phoneNumber": "(315) 416 4432",
    "type": "client",
    "username": "shanyan.jiang+5@givewith.com",
}
"""
@okta_user_bp.route('/<user_id>', methods=['PUT'])
def put_user(user_id):
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404

    okta_service = services['okta']
    updates = request.get_json()

    # validation
    immutable_fields = ['oktaId', 'username', 'orgType', 'orgId']
    for field in immutable_fields:
        if str(updates.get(field)) != str(user.get(field)):
            return str(immutable_fields) + ' are immutable', 400

    if updates['orgType'] == 'nonprofit' and updates['type'] == 'admin':
        return 'nonprofit user cannot be admin', 400

    # validate if admin user is under admin brand
    admin_brand = get_document('admin_brand', {'type': 'admin_brand'})
    if admin_brand and updates['type'] == 'admin' and updates['orgId'] != str(admin_brand['brand_id']):
        return 'admin user must be add under admin brand', 400

    updates['name'] = updates['first_name'] + ' ' + updates['last_name']

    # activate / deactivate user
    if updates['active'] != user['active']:
        if updates['active']:
            response = okta_service.activate_user(user['oktaId'])
            if response.status_code != 200:
                return response.content, response.status_code
        else:
            response = okta_service.deactivate_user(user['oktaId'])
            if response.status_code != 200:
                return response.content, response.status_code

    return update_document_by_id('user', user['_id'], updates), 200


"""
@api {post} /user/password Set user initial password
@apiName Set user password
@apiGroup Okta
@apiDescription This endpoint will be used to set user initial password after creation (from email)

@apiParamExample {json} Authenticate user example:
{
    "currentPassword": "password",
    "newPassword": "new_password"
}
"""
@okta_user_bp.route('/<user_name>/password', methods=['POST'])
def set_initial_password(user_name):
    okta_service = services['okta']
    current_password = request.json['currentPassword']
    new_password = request.json['newPassword']
    user = get_document('user', {'username': user_name})
    if user is None:
        return 'user not found', 404

    # validate old password
    username = user['username']
    response = okta_service.authenticate(username, current_password)
    if response.status_code != 200:
        return 'invalid old password', 400

    okta_user_id = user['oktaId']
    response = okta_service.set_password(okta_user_id, new_password)

    if response.status_code == 200:
        update_document_by_id('user', user['_id'], {'active': True})

    return response.content, response.status_code


@okta_user_bp.route('/<user_id>', methods=['DELETE'])
def deactivate_user(user_id):
    okta_service = services['okta']
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404

    if not user['active']:
        return 'user is already inactive', 400

    # remove user emails from deals
    customer_email = 'givewithCustomerEmails'
    client_email = 'clientEmails'
    username = user.get('username')

    deals = get_user_emails_in_deals(username, customer_email, client_email)
    if deals:
        remove_user_emails_in_deals(deals, username, customer_email, client_email)

    # deactivate user in okta
    if 'oktaId' in user:
        response = okta_service.deactivate_user(user['oktaId'])

    update_document_by_id('user', user['_id'], {'active': False})
    return response.content, response.status_code


"""
@api {post} /user/request_forget_password Request forget password
@apiName Request forget password
@apiGroup Okta
@apiDescription Request forget password. it will send a reset password email to user's account

@apiParamExample {json} Authenticate user example:
{
    "email": "email@givewith.com"
}
"""
@okta_user_bp.route('/request_forget_password', methods=['POST'])
def request_forget_password():
    email = request.json['email']
    okta_service = services['okta']
    user = get_document('user', {'username': email})
    if user is None:
        send_loggly("Email " + email + " is invalid. Could not generate forgot password link")
        return '', 204

    reset_password_code = okta_service.generate_temporary_password()

    email_service = EmailService()
    platform = get_user_platform(user)
    response = email_service.send_forget_password_email(email, reset_password_code, platform)
    if response.status_code != 202:
        return response.content, response.status_code

    update_document('reset_password_code', {'email': email}, {'email': email, 'code': reset_password_code})
    return '', 204


"""
@api {post} /user/reset_password Rest password.
@apiName Reset password
@apiGroup Okta
@apiDescription This endpoint will be used when user forget password.

@apiParamExample {json} Authenticate user example:
{
    "email": "email@givewith.com",
    "code": "AaE6WZ47E3nk",
    "newPassword": "tmp_password"
}
"""
@okta_user_bp.route('/reset_password', methods=['POST'])
def change_password():
    email = request.json['email']
    code = request.json['code']
    new_password = request.json['newPassword']

    # verify code
    record = get_document('reset_password_code', {"$and": [{"email": email}, {"code": code}]})
    if not record:
        return 'invalid reset password code', 400

    # look for user in DB
    user = get_document('user', {'username': email})
    if user is None:
        return 'user not found', 404

    # we are supporting reset password for old user in cognito.
    # if user does not exist in okta. create one with temporary password.
    okta_service = services['okta']
    response = okta_service.find_user(email)
    if not response.json():
        tmp_password = okta_service.generate_temporary_password()
        okta_request = {
            "profile": {
                "firstName": user['first_name'],
                "lastName": user['last_name'],
                "email": user['username'],
                "login": user['username'],
            },
            "credentials": {
                "password": {"value": tmp_password}
            }
        }
        response = okta_service.create_user(okta_request)
        if response.status_code == 200:
            user['oktaId'] = response.json()['id']
            user = update_document_by_id('user', user['_id'], {'oktaId': response.json()['id']})

    # set new password
    response = okta_service.set_password(user['oktaId'], new_password)

    if response.status_code != 200:
        return response.json()['errorCauses'][0]['errorSummary'], response.status_code

    # delete code. ensure code can only be use once.
    hard_delete_document('reset_password_code', {'email': email})
    return response.content, response.status_code


"""
@api {post} /supplier/resend-invite resend invite to user 
@apiName Resend Invite
@apiGroup Okta
@apiDescription Use to reset user password and resend request.  

@apiParamExample {json} reset supplier user password:
{
    "username": "email@givewith.com",
    "metadata" :{
    "supplierInvite": "True",
    "supplierCompanyName": "Supplier Org",
    "procurementClientName": "Procurement Org"
    }
} 
"""
@okta_user_bp.route('/resend-invite', methods=['POST'])
def resend_invite():
    email = request.json['username']
    metadata = request.json['metadata']
    okta_service = services['okta']
    user = get_document('user', {'username': email})
    tmp_password = okta_service.generate_temporary_password()

    if user is None:
        return "Email " + email + " is invalid", 204

    okta_response = okta_service.set_password(user['oktaId'], tmp_password) 
    if okta_response.status_code != 200:
        return response.json()['errorCauses'][0]['errorSummary'], response.status_code
    
    email_service = EmailService()
    supplier_invite  = metadata.pop('supplierInvite', False)
    if supplier_invite :    
        response = email_service.send_supplier_invite_email(email, tmp_password, user['first_name'], metadata)
    # future
    # else:
    #    response = email_service.send_user_activation_email(user['username'], tmp_password, platformName)

    if response.status_code != 202:
        return response.content, response.status_code

    return response.content, response.status_code


"""
@api {post} /user/migrate-user-to-okta Migrate user from cognito to okta
@apiName Migrate user
@apiGroup Okta
@apiDescription Move existing user from cognito to okta.  

@apiParamExample {json} Authenticate user example:
{}
"""
@okta_user_bp.route('/migrate-to-okta', methods=['POST'])
def migrate_user_to_okta():
    token = request.headers.get('authorization')
    if token is None:
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, PRIVATE_KEY, algorithms='HS256')
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401

    if claims['type'] != 'admin':
        return 'Insufficient Permission', 401

    okta_service = services['okta']

    # filter user logged in 6 months ago
    users = get_documents('user', {'last_login': {'$gte': datetime.today() - timedelta(days=180)}})
    success_details = {'count': 0, 'accounts': []}
    error_details = {'count': 0, 'accounts': {}}

    existing_user_emails = okta_service.list_user_email()
    for user in users:
        # check if user exists in okta
        if 'username' not in user:
            continue

        if user['username'] in existing_user_emails:
            continue

        # create user in okta
        tmp_password = okta_service.generate_temporary_password()

        okta_request = {
            "profile": {
                "firstName": user.get('first_name', ''),
                "lastName": user.get('last_name', ''),
                "email": user['username'],
                "login": user['username'],
            },
            "credentials": {
                "password": {"value": tmp_password}
            }
        }

        if 'phoneNumber' in user:
            okta_request['profile']['mobilePhone'] = user['phoneNumber']

        response = okta_service.create_user(okta_request)
        if response.status_code != 200:
            error_details['count'] += 1
            error_details['accounts'][user['username']] = response.content
            continue

        # send migration email
        email_service = EmailService()
        response = email_service.send_migration_email(user['username'], tmp_password)
        if response.status_code != 202:
            return response.content, response.status_code

        success_details['count'] += 1
        success_details['accounts'].append(user['username'])

    return {
        'success details': success_details,
        'error details': error_details
    }, 200


"""
@api {get} /user List users
@apiName List user
@apiGroup Okta
@apiDescription List all users in okta  

@apiParamExample {json} Authenticate user example:
{}
"""
@okta_user_bp.route('/', methods=['GET'])
def list_user():
    token = request.headers.get('authorization')
    if token is None:
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, PRIVATE_KEY, algorithms='HS256')
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401

    if claims['type'] != 'admin':
        return 'Insufficient Permission', 401

    okta_service = services['okta']
    response = okta_service.list_user()
    if response.status_code != 200:
        return response.content, response.status_code

    return jsonify(response.json()), response.status_code


"""
@api {PUT] /admin_brand Mark a brand as givewith admin brand
@apiName Mark admin brand
@apiGroup Util
@apiDescription Mark a brand as givewith admin brand. All admin user will move under the admin brand

@apiParamExample {json} Authenticate user example:
{
    'brand_id': "00ux6ioeew8pAYYyt5d6",
}
"""
@okta_user_bp.route('/admin_brand', methods=['PUT'])
def mark_admin_brand():
    token = request.headers.get('authorization')
    if token is None:
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, PRIVATE_KEY, algorithms='HS256')
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401

    if claims['type'] != 'admin':
        return 'Insufficient Permission', 401

    # validate
    brand_id = request.json['brand_id']
    brand = get_document_by_id('mm_brands', brand_id)
    if not brand:
        return 'brand not found', 400

    # update admin_brand collection
    update_document('admin_brand', {'type': 'admin_brand'}, {'type': 'admin_brand', 'brand_id': ObjectId(brand_id)})

    # move admin_user
    admin_users = get_document('user', {'type': 'admin'})
    for user in admin_users:
        update_document_by_id('user', user['_id'], {'orgId': ObjectId(brand_id)})

    return str(len(admin_users)) + ' admin users has been moved to admin brand', 200

def get_user_emails_in_deals(username, customer_email, client_email):
    projection = {'name': True, customer_email: True, client_email: True}
    query = {'$or' : [{customer_email : {'$in': [username]}}, {client_email : {'$in' : [username]}}]}
    deals = get_documents('deals', query, projection=projection)
    return deals

def remove_user_emails_in_deals(deals, username, customer_email, client_email):
    for deal in deals:
        changes = {}
        if username in deal.get(customer_email, []):
            new_customer_emails = deal.get(customer_email)
            new_customer_emails.remove(username)
            changes[customer_email] = new_customer_emails

        if username in deal.get(client_email, []):
            new_client_emails = deal.get(client_email)
            new_client_emails.remove(username)
            changes[client_email] = new_client_emails

        if changes:
            update_document_by_id('deals', deal.get('_id'), changes)


"""
@api {post} /user/<user_id>/mfa_enroll Enroll user in MFA
@apiName Enroll in MFA
@apiGroup Okta
@apiDescription Enroll in MFA and add to user's list of factors

@apiParamExample {json} Enroll MFA example:
{
    "factorType": "sms",
    "provider": "OKTA",
    "phoneNumber": "+1-555-415-1337"
}
"phoneNumber" parameter is only for sms

@apiSuccessExample {json} Success enroll MFA response example:
{
    "name": "sms",
    "id": "sms1o51EADOTFXHHBXBP",
    "type": "sms",
    "provider": "OKTA",
    "active": false,
    "phoneNumber": "+1-555-415-1337",
    "preferred": false
}
"phoneNumber" parameter is specifically for sms
email method has "email"
Okta Verify/ Google Auth have "qrCode"
"""
@okta_user_bp.route('/<user_id>/mfa_enroll', methods=['POST'])
def mfa_enroll(user_id):
    okta_service = services['okta']
    factor_type = request.json['factorType']
    provider = request.json['provider']

    # look for user in DB
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404
    
    okta_request = {
        "factorType": factor_type, 
        "provider": provider,
    }

    # add profile with phoneNumber if MFA method is sms
    # add with email if MFA method is email
    if factor_type == 'sms':
        okta_request['profile'] = {'phoneNumber': request.json['phoneNumber']}
    elif factor_type == 'email':
        okta_request['profile'] = {'email': user['username']}

    response = okta_service.mfa_enroll(user['oktaId'], okta_request)
    if response.status_code != 200:
        if factor_type == 'sms':
            response = okta_service.update_phone(user['oktaId'], okta_request)
            
        if response.status_code == 429 and response.json()['errorCode'] == 'E0000186':
            return 'SMS authentication currently unavaiable. ' \
                    'Please choose a different method from More Options.', response.status_code
        if response.status_code != 200:
            return response.content, response.status_code
   
    new_factor = {
        "id": response.json()['id'],
        "type": factor_type,
        "provider": provider,
        "active": False
    }

    # account for re-enrollment of previously verified phone
    if response.json()['status'] == 'ACTIVE':
        new_factor['active'] = True
        okta_service.add_to_group(user['oktaId'], okta_service.mfa_group_id)

    # add important additional factor info depending on type
    if factor_type == 'sms':
        new_factor['name'] = 'sms'
        new_factor['phoneNumber'] = response.json()['profile']['phoneNumber']
    elif factor_type == 'email':
        new_factor['name'] = 'email'
        new_factor['email'] = user['username']
    else:
        new_factor['name'] = 'OKTA' if provider == 'OKTA' else 'GOOGLE'
        new_factor['qrCode'] = response.json()['_embedded']['activation']['_links']['qrcode']['href']
    
    # set 'preferred' flag
    new_factor['preferred'] = False
    if 'factors' in user:
        factor_exists, position = is_factor_prev_enrolled(user['factors'], new_factor['name'])
        if factor_exists and user['factors'][position]['preferred'] is True:
            new_factor['preferred'] = True

        # check for auto-activation (sms factor)
        elif new_factor['active'] is True:
            new_pref, old_pref = find_pref_factor(user['factors'] + [new_factor])
            if new_pref['name'] == new_factor['name']:
                new_factor['preferred'] = True
                if old_pref is not None:
                    user = update_document('user', {'username': user['username'], 'factors.id': old_pref['id']}, {'factors.$.preferred': False})

    # update user in user collection
    if 'factors' in user:
        factor_exists, position = is_factor_prev_enrolled(user['factors'], new_factor['name'])
        if factor_exists:
            user['factors'][position] = new_factor
        else:
            user['factors'].append(new_factor)
        update_document_by_id('user', user['_id'], {'factors': user['factors']})
    else:
        update_document_by_id('user', user['_id'], {'factors': [new_factor]})
    
    return jsonify(new_factor), 200

def is_factor_prev_enrolled(factors, factor_name):
    """
    Prevent factors from being added to user document more than once
    """
    for i in range(len(factors)):
        if factors[i]['name'] == factor_name:
            return (True, i)
    return (False, None)


"""
@api {post} /user/<user_id>/mfa_enroll/activate Activate MFA Factor
@apiName Activate MFA
@apiGroup Okta
@apiDescription Activate the MFA Factor

@apiParamExample {json} Activate MFA example:
{
    "factor_id": "sms1o51EADOTFXHHBXBP"
    "passcode": "123456"
}

@apiSuccessExample {json} Success activate MFA response example:
{
    "id": "sms1o51EADOTFXHHBXBP",
    "type": "sms",
    "provider": "OKTA",
    "active": true,
    "phoneNumber": "+1-555-415-1337"
}
"""
@okta_user_bp.route('/<user_id>/mfa_enroll/activate', methods=['POST'])
def mfa_activate(user_id):
    okta_service = services['okta']
    factor_id = request.json['factor_id']
    passcode = request.json['passcode']

    # look for user in DB
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404
    
    response = okta_service.mfa_activate(user['oktaId'], factor_id, passcode)
    if response.status_code != 200:
        return response.content, response.status_code

    # set factor active status to 'true' 
    username = user['username']
    active_factor_id = response.json()['id']
    user = update_document('user', {'username': username, 'factors.id': factor_id}, {'factors.$.id': active_factor_id, 'factors.$.active': True})
    active_factor = next(f for f in user['factors'] if f['id'] == active_factor_id)

    # set preferred
    active_factors = 0
    if 'factors' in user:
        for factor in user['factors']:
            if factor['active'] == True:
                active_factors += 1
    
    if active_factors == 1:
        update_document('user', {'username': user['username'], 'factors.id': active_factor_id}, {'factors.$.preferred': True})
    else:
        factor_exists, position = is_factor_prev_enrolled(user['factors'], active_factor['name'])
        if (factor_exists is False) or (factor_exists and user['factors'][position]['preferred'] is False):
            new_pref, old_pref = find_pref_factor(user['factors'])
            if new_pref['name'] == active_factor['name']:
                update_document('user', {'username': user['username'], 'factors.id': active_factor_id}, {'factors.$.preferred': True})
                update_document('user', {'username': user['username'], 'factors.id': old_pref['id']}, {'factors.$.preferred': False})

    # add user to "MFA Users" group
    response = okta_service.add_to_group(user['oktaId'], okta_service.mfa_group_id)
    if response.status_code != 204:
        return response.content, response.status_code

    return jsonify(active_factor), 200


"""
@api {get} /user/<user_id>/factors List factors
@apiName List factors
@apiGroup Okta
@apiDescription List all factors that the user is enrolled in

@apiParamExample {json} List MFA factors example:
{}
"""
@okta_user_bp.route('/<user_id>/factors', methods=['GET'])
def list_factors(user_id):
    # look for user in DB
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404
        
    return jsonify({
        'factors': user.get('factors')
    }), 200


"""
@api {post} /user/<user_id>/mfa_enroll/resend Resend code to sms or email
@apiName Resend MFA
@apiGroup Okta
@apiDescription Passcode sent to user through sms/email expires after ~5 min.
                Need to send user a new code to activate their account.

@apiParamExample {json} Resend MFA example:
{
    "factor_id": "sms1o51EADOTFXHHBXBP"
}
"""
@okta_user_bp.route('/<user_id>/mfa_enroll/resend', methods=['POST'])
def mfa_resend_code(user_id):
    okta_service = services['okta']
    factor_id = request.json['factor_id']

    # look for user in DB
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404
    
    # find factor based on id in user's factors list
    for factor in user['factors']:
        if factor['id'] == factor_id:
            okta_request = {
                "factorType": factor['type'], 
                "provider": factor['provider'],
                "profile": {}
            }
        
            if 'phoneNumber' in factor:
                okta_request['profile'] = {'phoneNumber': factor['phoneNumber']}
            else:
                okta_request['profile'] = {'email': factor['email']}
    
    response = okta_service.mfa_resend_enroll(user['oktaId'], factor_id, okta_request)
    if response.status_code != 200:
        return response.content, response.status_code

    return jsonify(response.json()), 200


"""
@api {delete} /user/<user_id>/mfa_remove Remove MFA factor
@apiName Remove MFA factor
@apiGroup Okta
@apiDescription Remove MFA factor from user's activated factors list
@apiParamExample {json} Remove MFA example:
{
    "name": "sms",
}

@apiSuccessExample {json} Success remove MFA response example:
{
    "name": "sms"
}
"""
@okta_user_bp.route('/<user_id>/mfa_remove', methods=['DELETE'])
def mfa_remove(user_id):
    okta_service = services['okta']
    factor_name = request.json['name']
    replace = request.json.get('replace', False)

    # look for user in DB
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404

    # find factor based on name
    for factor in user['factors']:
        if factor['name'] == factor_name:
            factor_id = factor['id']
            disenrolled_factor = factor

    # remove factor from user in okta
    response = okta_service.mfa_remove(user['oktaId'], factor_id)

    # update user's factor list in DB
    user = update_document('user', {'username': user['username'], 'factors.id': factor_id}, {'factors.$.active': False})
    if disenrolled_factor['preferred'] is True:
        if replace is False:
            update_document('user', {'username': user['username'], 'factors.id': factor_id}, {'factors.$.preferred': False})

            # find and set new preferred factor
            new_pref, _ = find_pref_factor(user['factors'])
            if new_pref is not None:
                update_document('user', {'username': user['username'], 'factors.id': new_pref['id']}, {'factors.$.preferred': True})

    active_factors = 0
    for factor in user['factors']:
        if factor['active'] == True:
            active_factors += 1

    # Remove user from "MFA Users" group if there are no more active factors
    if active_factors == 0:
        response = okta_service.remove_from_group(user['oktaId'], okta_service.mfa_group_id)
        if response.status_code != 204:
            return response.content, response.status_code
    
    return jsonify({
        'name': factor_name,
        'replace': replace
    }), 200

def find_pref_factor(factors):
    # find current preferred factor and active factors
    active_factors = {}
    current_pref = None
    for factor in factors:
        if factor['preferred'] is True:
            current_pref = factor
        if factor['active'] is True:
            active_factors[factor['name']] = factor 
    
    # find preferred factor based on secuity level among active factors 
    if 'GOOGLE' in active_factors:
        return active_factors['GOOGLE'], current_pref
    elif 'OKTA' in active_factors:
        return active_factors['OKTA'], current_pref
    elif 'sms' in active_factors:
        return active_factors['sms'], current_pref
    elif 'email' in active_factors:
        return active_factors['email'], current_pref
                
    return None, current_pref


"""
@api {patch} /user/<user_id>/preferred_factor Set Preferred MFA method
@apiName Set Preferred MFA method
@apiGroup Okta
@apiDescription Set a chosen factor as the preferred method for MFA verification

@apiParamExample {json} Preferred MFA example:
{
    "name": "sms"
}

@apiSuccessExample {json} Success set preferred MFA response example:
{
    "name": "sms"
}
"""
@okta_user_bp.route('/<user_id>/preferred_factor', methods=['PATCH'])
def set_pref_factor(user_id):
    factor_name = request.json['name']

    # look for user in DB
    user = get_document_by_id('user', user_id)
    if user is None:
        return 'user not found', 404
    
    for factor in user['factors']:
        # unset previously preferred method
        if factor['preferred'] is True:
            update_document('user', {'username': user['username'], 'factors.id': factor['id']}, {'factors.$.preferred': False})
        
        # set new preferred method
        if factor['name'] == factor_name:
            update_document('user', {'username': user['username'], 'factors.id': factor['id']}, {'factors.$.preferred': True})

    return jsonify({
        'name': factor_name
    }), 200


"""
@api {POST] /lost_my_device Lost my device
@apiName Lost my device
@apiGroup Okta
@apiDescription Check if user has email enrolled as MFA method
                If not, auto-enroll email
                Then, send challenge to email

@apiParamExample {json} Lost my device example:
{
    "email": "user@givewith.com"
}
"""
@okta_user_bp.route('/lost_my_device', methods=['POST'])
def lost_my_device():
    okta_service = services['okta']
    email = request.json.get('email')
    state_token = request.json.get('stateToken')

    user = get_document('user', {'username': email})
    if user is None:
        return 'user not found', 404
    
    email_enrolled = False
    for factor in user['factors']:
        if factor['name'] == 'email' and factor['active'] is True:
            email_factor = factor
            email_enrolled = True
            break
    
    if email_enrolled is False:
        # auto-enroll in email
        okta_request = {
            'factorType': 'email', 
            'provider': 'OKTA',
            'profile': {
                'email': email
            }
        }
        response = okta_service.mfa_auto_enroll(user['oktaId'], okta_request)
        if response.status_code != 200:
            return response.content, response.status_code

        email_factor = {
            'id': response.json()['id'],
            'type': 'email',
            'provider': 'OKTA',
            'active': True,
            'name': 'email',
            'email': email,
            'preferred': False
        }

        # add email factor to user DB
        factor_exists, position = is_factor_prev_enrolled(user['factors'], 'email')
        if factor_exists:
            user['factors'][position] = email_factor
        else:
            user['factors'].append(email_factor)
        update_document_by_id('user', user['_id'], {'factors': user['factors']})
    
    if state_token is None:
        response = okta_service.factor_verify(user['oktaId'], email_factor['id'])
    else:
        response = okta_service.mfa_verify(email_factor['id'], state_token)
    
    return jsonify(response.json()), 200
