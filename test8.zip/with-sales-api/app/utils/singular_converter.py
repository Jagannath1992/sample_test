import inflect

p = inflect.engine()


def form_program_output(outputs):
    """
    form the singular of the program outputs based on the quantity.
    """
    if outputs:
        for o in outputs:
            o['description'] = form_singular_conditionally(o['description'], o.get('quantity', 0))

    return outputs


def form_singular_conditionally(sentence, count):
    """
    form the singular of the sentence based on the count.
    e.g.:
    if count > 1:
        Group events held - > Group event held
    else:
        Group events held - > Group events held
    """
    if not isinstance(count, int) and not isinstance(count, float):
        return sentence

    if not sentence or sentence == '' or count > 1:
        return sentence

    words = sentence.split(' ')
    output = ""
    for word in words:
        output = output + " " + force_singular(word)

    return output.strip()


def force_singular(word):
    """
    Return the singular of text, where text is a plural noun. otherwise return text unchanged.
    e.g:
    cats -> cat
    cat -> cat
    """
    if p.singular_noun(word):
        return p.singular_noun(word)
    else:
        return word


