from pymongo import MongoClient

db = None


def init_db(app, test_db=None):

    config = app.config['config']['db']['mongodb']

    global client
    client = MongoClient(config['uri'])

    global db
    if test_db is not None:
        db = test_db
    else:
        db = client.get_database(config['db_name'])


def get_db():
    return db
