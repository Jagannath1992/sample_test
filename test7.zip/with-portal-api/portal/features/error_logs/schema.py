from marshmallow import Schema, fields
from portal.shared.custom_fields import ObjectIdField
from portal.shared.schema import AccountReferenceSchema, EntitySchema, OrderReferenceSchema, SearchRequestSchema, SearchResponseSchema, TransactionReferenceSchema


class ErrorLogMessagesSchema(Schema):
    code = fields.String()
    message = fields.String()


class ErrorLogSchema(EntitySchema):
    '''Error Logs model'''
    source = fields.String(required=True)
    description = fields.String(required=True)
    account = fields.Nested(AccountReferenceSchema, required=True)
    order = fields.Nested(OrderReferenceSchema)
    transaction = fields.Nested(TransactionReferenceSchema)
    messages = fields.List(fields.Nested(ErrorLogMessagesSchema))
    isResolved = fields.Boolean(default=False)
    resolvedBy = fields.String(default=None)
    resolvedAt = fields.DateTime(allow_none=True)


class ErrorLogRequest(ErrorLogSchema):
    """Response model for GET, PATCH ErrorLog by Id response"""
    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated')


class ErrorLogResponse(ErrorLogSchema):
    pass


class ErrorLogSearchRequest(SearchRequestSchema):
    id = ObjectIdField(attribute='_id', allow_none=True)
    source = fields.String(allow_none=True)
    description = fields.String(allow_none=True)
    accountId = ObjectIdField(allow_none=True)
    accountName = fields.String(allow_none=True)
    orderId = ObjectIdField(allow_none=True)
    orderName = fields.String(allow_none=True)
    transactionId = ObjectIdField(allow_none=True)
    transactionName = fields.String(allow_none=True)
    createdBy = fields.String(allow_none=True)
    createdAtFrom = fields.DateTime(allow_none=True)
    createdAtTo = fields.DateTime(allow_none=True)
    isResolved = fields.Boolean(allow_none=True)
    resolvedBy = fields.String(allow_none=True)
    resolvedAtFrom = fields.DateTime(allow_none=True)
    resolvedAtTo = fields.DateTime(allow_none=True)

    class Meta:
        contains_fields = ['description', 'createdBy', 'resolvedBy', 'accountName', 'orderName', 'transactionName']
        range_fields = ['createdAt', 'resolvedAt']

    def _convert_nested(self, key):
        if key == 'accountId':
            return 'account._id'
        elif key == 'accountName':
            return 'account.name'
        elif key == 'orderId':
            return 'order._id'
        elif key == 'orderName':
            return 'order.name'
        elif key == 'transactionId':
            return 'transaction._id'
        elif key == 'transactionName':
            return 'transaction.name'
        return key



class ErrorLogSearchResponse(SearchResponseSchema):
    """Response model for GET all ErrorLogs response"""
    results = fields.List(fields.Nested(ErrorLogSchema))

