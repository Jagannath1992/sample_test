from bson import ObjectId
from marshmallow import Schema, ValidationError, fields, validate, validates
from portal.features.stripe.enums import StripeSetupIntentAction
from portal.shared.custom_fields import ObjectIdField
from portal.shared.enums import SubscriptionFrequency
from portal.shared.repositories import order_repository
from portal.shared.schema import OrderedSchema


class CreateSetupCheckoutSessionRequest(OrderedSchema):
    accountId = ObjectIdField(allow_none=True)
    successUrl = fields.String(required=True, attribute='success_url')
    cancelUrl = fields.String(required=True, attribute='cancel_url')
    actionType = fields.String(required=True, attribute='action_type', validate=validate.OneOf(
        [sat.value for sat in StripeSetupIntentAction]))


class CreateSetupCheckoutSessionResponse(Schema):
    url = fields.String()


class CreateOrderSetupCheckoutSessionRequest(Schema):
    accountId = ObjectIdField(allow_none=True)
    successUrl = fields.String(required=True, attribute='success_url')
    cancelUrl = fields.String(required=True, attribute='cancel_url')
    orderIds = fields.List(fields.String(required=True), required=True, attribute='order_ids')

    @validates('orderIds')
    def validate_orderIds(self, value):
        invalid_order_ids = []
        for order_id in value:
            if not ObjectId.is_valid(order_id) or not order_repository().exists(order_id):
                invalid_order_ids.append(order_id)
        if len(invalid_order_ids):
            raise ValidationError('One or more Gives were not found', 'orderIds', invalid_order_ids)


class CreateOrderSetupCheckoutSessionResponse(Schema):
    url = fields.String()


class DeleteAutoPayRequest(Schema):
    accountId = ObjectIdField(allow_none=True)


class CreateCustomerPortalSessionRequest(Schema):
    accountId = ObjectIdField(allow_none=True)


class CreateCustomerPortalSessionResponse(Schema):
    url = fields.String()


class UpdateSubscriptionFrequencyRequest(Schema):
    accountId = ObjectIdField(allow_none=True)
    subscriptionFrequency = fields.String(required=True, validate=validate.OneOf([sf.value for sf in SubscriptionFrequency]))


class CancelSubscriptionRequest(Schema):
    accountId = ObjectIdField(allow_none=True)


class CreateSubscriptionCheckoutSessionRequest(Schema):
    accountId = ObjectIdField(allow_none=True)
    frequency = fields.String(required=True, validate=validate.OneOf([sf.value for sf in SubscriptionFrequency]))
    successUrl = fields.String(required=True, attribute='success_url')
    cancelUrl = fields.String(required=True, attribute='cancel_url')


class CreateSubscriptionCheckoutSessionResponse(Schema):
    url = fields.String()
