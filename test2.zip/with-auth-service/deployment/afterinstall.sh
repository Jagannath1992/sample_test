cd /home/ec2-user

chown ec2-user deployment

python3 -m pip install --upgrade pip
pip3 install -r requirements.txt

rm -f /home/ec2-user/.envs
cd /home/ec2-user/deployment
source /home/ec2-user/.bashrc
chown ec2-user ./environment_variables.sh
chmod 755 ./environment_variables.sh
./environment_variables.sh > /tmp/environ_debug

# overwrite configurations.
#    - change datadog agent port to 5010 (datadog agent default port is 5000, it has a conflict with our flask app)
cp ../config/datadog.yaml /etc/datadog-agent/datadog.yaml