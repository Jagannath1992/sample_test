import json
import requests

from bson import json_util
from os import environ
from app.utils.token import get_user_from_token
from app.db.utils import get_document_by_id, get_document


EMAIL_SERVICE_URL = environ.get('EMAIL_SERVICE_URL', 'http://emailloadbalancer-1769123919.us-east-1.elb.amazonaws.com/email')
ADMIN_URL = environ.get('ADMIN_URL', 'https://admin.nohardstops.com')
ENV = environ.get('ENV', 'local')
STAGING = True if ENV == 'staging' else False
SANDBOX = True if ENV == 'sandbox' else False
default_program_manager = 'Melissa Gordon'

customer_success_email = 'customer-success-staging@givewith.com'
if ENV == 'sandbox':
    customer_success_email = 'customer-success-sandbox@givewith.com'
if ENV == 'production':
    customer_success_email = 'customer-success@givewith.com'


def request_pitch_material(message):
    user = get_user_from_token()

    payload = {
        'tos': [customer_success_email],
        'template': {
            'id': 'd-ae0ffcec131b432d8f8e8c474d2f37af',
            'data': {
                'name': user.get('name'),
                'email': user.get('username'),
                'message': message
            }
        }
    }

    return requests.post(EMAIL_SERVICE_URL, json=json.loads(json_util.dumps(payload)), timeout=3)


def new_deal(deal):
    customer_brand = get_document_by_id('mm_brands', deal.get('givewithCustomer'))
    client_brand = get_document_by_id('mm_brands', deal.get('client'))

    tos = [customer_success_email]

    # cc customer (brand) manager
    customer_brand_manager_id = customer_brand.get('givewithManager', '')
    manager = get_document_by_id('user', customer_brand_manager_id)

    if manager is not None:
        tos.append(manager.get('username'))

    payload = {
        'tos': tos,
        'template': {
            'id': 'd-6095cc86c11a47d792200892dfaa8e36',
            'data': {
                'deal': deal,
                'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'proposalRecordLink': ADMIN_URL + '/#/deals/' + str(deal.get('_id')),
                'staging': STAGING,
                'sandbox': SANDBOX,
            }
        }
    }

    return requests.post(EMAIL_SERVICE_URL, json=json.loads(json_util.dumps(payload)), timeout=3)


def program_selected(deal):
    program = get_document_by_id('mm_programs', deal.get('selectedProgram'))
    nonprofit = get_document_by_id('mm_nonprofits', deal.get('nonprofit'))
    customer_brand = get_document_by_id('mm_brands', deal.get('givewithCustomer'))
    client_brand = get_document_by_id('mm_brands', deal.get('client'))

    tos = [customer_success_email]

    # cc customer (brand) manager
    customer_brand_manager_id = customer_brand.get('givewithManager', '')
    manager = get_document_by_id('user', customer_brand_manager_id)

    if manager is not None:
        tos.append(manager.get('username'))

    # send to customer
    customer_emails = deal.get('givewithCustomerEmails', [])
    if len(customer_emails) > 0:
        tos.extend(customer_emails)

    payload = {
        'tos': tos,
        'template': {
            'id': 'd-b63a08df1c304778b3d42f3858ee5486',
            'data': {
                'deal': deal,
                'program': program,
                'nonprofit': nonprofit,
                'givewithCustomerName': customer_brand.get('nameLabel') or customer_brand.get('name'),
                'clientName': client_brand.get('nameLabel') or client_brand.get('name'),
                'proposalRecordLink': ADMIN_URL + '/#/deals/' + str(deal.get('_id')),
                'staging': STAGING,
                'sandbox': SANDBOX,
            }
        }
    }

    return requests.post(EMAIL_SERVICE_URL, json=json.loads(json_util.dumps(payload)), timeout=3)


def set_default_program_manager(program):
    p = program.copy()
    if 'givewithAdmin' not in p:
        p['givewithAdmin'] = default_program_manager
    else:
        admin_id = p.get('givewithAdmin')
        user = get_document_by_id('users', admin_id)
        p['givewithAdmin'] = user.get('name')

    return p
