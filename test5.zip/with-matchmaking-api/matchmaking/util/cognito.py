import boto3
from os import environ

from ..utils import generate_secure_password


AWS_REGION = environ.get('COGNITO_AWS_REGION', 'us-east-1')
USERPOOL_ID = environ.get('COGNITO_USERPOOL_ID', 'us-east-1_aHNsxROA7')
CLIENT_ID = environ.get('COGNITO_CLIENT_ID', '1nmeh7a4rs6gs58d6uhmlq6dmo')
AWS_ACCESS_KEY_ID = environ.get('AWS_ACCESS_KEY_ID', None)
AWS_SECRET_ACCESS_KEY = environ.get('AWS_SECRET_ACCESS_KEY', None)

def ___get_cognito_client():
    return boto3.client('cognito-idp', region_name=AWS_REGION,
                        aws_access_key_id=AWS_ACCESS_KEY_ID, aws_secret_access_key=AWS_SECRET_ACCESS_KEY)

def create_user(username, given_name, family_name, user_type, org_type):
    client = ___get_cognito_client()

    response = client.admin_create_user(
        UserPoolId=USERPOOL_ID,
        Username=username,
        UserAttributes=[
            {'Name': 'given_name', 'Value': given_name},
            {'Name': 'family_name', 'Value': family_name},
            {'Name': 'custom:org_type', 'Value': org_type},
            {'Name': 'custom:user_type', 'Value': user_type},
            {'Name': 'email', 'Value': username},
            {'Name': 'email_verified', 'Value': 'true'}
        ],
        TemporaryPassword=generate_secure_password(length=12),
        DesiredDeliveryMediums=['EMAIL']
    )

    user = response.get('User', {})

    return user


def update_user(username, given_name, family_name, user_type):
    """
    Updates a user's cognito attributes
    NOTE: As it's currently written, this will override given_name and family_name if they are not passed
    """
    client = ___get_cognito_client()

    response = client.admin_update_user_attributes(
        UserPoolId=USERPOOL_ID,
        Username=username,
        UserAttributes=[
            {'Name': 'given_name', 'Value': given_name},
            {'Name': 'family_name', 'Value': family_name},
            {'Name': 'custom:user_type', 'Value': user_type},
            {'Name': 'email', 'Value': username}
        ]
    )

    return response


def disable_user(username):
    client = ___get_cognito_client()

    response = client.admin_disable_user(
        UserPoolId=USERPOOL_ID,
        Username=username,
    )

    return response


def enable_user(username):
    client = ___get_cognito_client()

    response = client.admin_enable_user(
        UserPoolId=USERPOOL_ID,
        Username=username,
    )

    return response


def delete_user(username):
    client = ___get_cognito_client()

    response = client.admin_delete_user(
        UserPoolId=USERPOOL_ID,
        Username=username,
    )

    return response

def resend_conf_code(username, given_name, family_name, user_type, org_type):
    client = ___get_cognito_client()

    response = client.admin_create_user(
        UserPoolId=USERPOOL_ID,
        Username=username,
        UserAttributes=[
            {'Name': 'given_name', 'Value': given_name},
            {'Name': 'family_name', 'Value': family_name},
            {'Name': 'custom:org_type', 'Value': org_type},
            {'Name': 'custom:user_type', 'Value': user_type},
            {'Name': 'email', 'Value': username},
            {'Name': 'email_verified', 'Value': 'true'}
        ],
        TemporaryPassword=generate_secure_password(length=12),
        DesiredDeliveryMediums=['EMAIL'],
        MessageAction='RESEND',
    )

    user = response.get('User', {})

    return user

