import re

from bson import ObjectId
from typing import Dict

from portal.shared.repository import DocumentRepository


class AccountRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['account'])

    def get_industries(self):
        return self.db['industry_display_map'].find_one()

    def company_exists(self, company_name: str) -> bool:
        return self.collection.count_documents({'company.name': re.compile(re.escape(company_name), re.IGNORECASE)}) != 0

    def get_next_give_id(self, accountId: ObjectId) -> int:
        # adds nextGiveId prop if it doesn't exist on account yet
        next_give_id = self.collection.find_one_and_update(
            {'_id': ObjectId(accountId)},
            {'$inc': {'nextGiveId': 1}},
            {'_id': 0, 'nextGiveId': 1}).get('nextGiveId')
        if not next_give_id:  # If added in first call, call again to get first id and increase next to 2
            next_give_id = self.get_next_give_id(accountId)
        return next_give_id
    
    def get_industry_counts(self) -> Dict[str,int]:
        result = self.collection.aggregate([
            {'$group': {
                '_id': {'subIndustry':'$industry.subIndustry'},
                'count': {'$sum':1}
            }}
        ])
        counts = {ind['_id']['subIndustry']: ind['count'] for ind in list(result)}
        return counts
