from abc import ABC, abstractmethod
from pymongo.collection import Collection


class DocumentFaker(ABC):
    def __init__(self, faker, db, collection):
        self.db = db
        self.collection: Collection = db[collection]
        self.faker = faker

    @abstractmethod
    def _generate_document(self, i):
        pass

    def generate_new(self):
        document = self._generate_document(0)
        audit_fields = ['_id', 'lastUpdated', 'createdAt', 'createdBy', 'lastUpdatedBy']
        for key in audit_fields:
            document.pop(key)

        return document

    def generate_single(self, custom_values={}, index=1):
        document = self._generate_document(index)
        self._update_nested_fields(document, custom_values)
        return document

    def generate_many(self, quantity, custom_values={}) -> list:
        return [
            self.generate_single(custom_values, i)
            for i in range(1, quantity + 1)
        ]

    def insert_single(self, custom_values={}, index=0):
        document = self.generate_single(custom_values, index)
        self.collection.insert_one(document)
        return document

    def insert_many(self, quantity, custom_values={}):
        documents = self.generate_many(quantity, custom_values)
        self.collection.insert_many(documents)
        return documents

    def _update_nested_fields(self, document, custom_values):
        for key, value in custom_values.items():
            if isinstance(value, dict):
                document[key] = document.get(key, {})
                self._update_nested_fields(document[key], value)
            else:
                document[key] = value
