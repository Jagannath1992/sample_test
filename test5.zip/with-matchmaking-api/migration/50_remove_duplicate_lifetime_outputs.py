from matchmaking import db

nonprofits = list(db().coll_nonprofits.find({}))
pre_output_count = 1

for nonprofit in nonprofits:
    nonprofit['name'] = nonprofit['general']['name']['publicOrganizationName']

    # 2 remove duplicate output
    # outputs = nonprofit['overviewAndMission']['lifetimeOutputs']
    # outputs_length = len(outputs)
    #
    # for each_output in outputs:
    #     # change name from outputNumber to quantity
    #     each_output['quantity'] = each_output.get('outputNumber', 0)
    #     each_output.pop('outputNumber', None)
    #
    # # remove duplicate output
    # outputs = outputs[pre_output_count:]
    # nonprofit['overviewAndMission']['lifetimeOutputs'] = outputs
    # pre_output_count = outputs_length
    #
    # db().coll_nonprofits.find_one_and_replace({'_id': nonprofit['_id']}, nonprofit)
