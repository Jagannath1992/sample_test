import pytest
import stripe
from portal.shared.repositories import account_repository
from portal.shared.sage.enums import SageObjectType
from portal.shared.services import account_service, sage_service
from portal.testing.fakers import Fakers


@pytest.mark.integration
def test_create_missing_sage_and_stripe_customer_records_test(fakers: Fakers):
    # arrange
    accounts = fakers.account.insert_many(8, {'company': {'address': {'country': 'United States'}}})

    account_stripe_customerId_and_sageCustomerId = accounts[0]

    account_no_stripe = accounts[1]
    del account_no_stripe['stripe']
    account_no_stripe = account_repository().update(account_no_stripe)

    account_no_stripe_customerId = accounts[2]
    del account_no_stripe_customerId['stripe']['customerId']
    account_no_stripe_customerId = account_repository().update(account_no_stripe_customerId)

    account_none_stripe_customerId = accounts[3]
    account_none_stripe_customerId['stripe']['customerId'] = None
    account_none_stripe_customerId = account_repository().update(account_none_stripe_customerId)

    account_no_sageCustomerId = accounts[4]
    del account_no_sageCustomerId['sageCustomerId']
    account_no_sageCustomerId = account_repository().update(account_no_sageCustomerId)

    account_none_sageCustomerId = accounts[5]
    account_none_sageCustomerId['sageCustomerId'] = None
    account_none_sageCustomerId = account_repository().update(account_none_sageCustomerId)

    account_no_sageRecordNo = accounts[6]
    del account_no_sageRecordNo['sageRecordNo']
    account_no_sageRecordNo = account_repository().update(account_no_sageRecordNo)

    account_none_sageRecordNo = accounts[7]
    account_none_sageRecordNo['sageRecordNo'] = None
    account_none_sageRecordNo = account_repository().update(account_none_sageRecordNo)

    # act
    updated_accounts = account_service().create_missing_sage_and_stripe_customer_records()

    # assert
    for updated_account in updated_accounts:
        stripe_customer_id = updated_account.get('stripe_customer_id')
        if stripe_customer_id:
            stripe.Customer.delete(stripe_customer_id)
        sage_record_no = updated_account.get('sage_record_no')
        if sage_record_no:
            sage_service()._delete_object(SageObjectType.CUSTOMER, sage_record_no)


@pytest.mark.integration
@pytest.mark.use_staging_environment
def test_create_missing_sage_and_stripe_customer_records_staging():
    # arrange

    # act
    updated_accounts = account_service().create_missing_sage_and_stripe_customer_records()

    # assert
