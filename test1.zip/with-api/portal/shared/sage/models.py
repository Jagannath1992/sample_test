from dataclasses import dataclass, field
from typing import List


@dataclass
class SageMailAddress:
    ADDRESS1: str = None
    ADDRESS2: str = None
    CITY: str = None
    STATE: str = None
    ZIP: str = None
    COUNTRY: str = None


@dataclass
class SageContact:
    FIRSTNAME: str
    LASTNAME: str
    COMPANYNAME: str
    PRINTAS: str = field(init=False)
    CONTACTNAME: str = field(init=False)
    EMAIL1: str = None
    MAILADDRESS: SageMailAddress = None

    def __post_init__(self):
        self.PRINTAS = f'{self.FIRSTNAME} {self.LASTNAME}'
        self.CONTACTNAME = f'{self.LASTNAME}, {self.FIRSTNAME} ({self.COMPANYNAME})'


@dataclass
class SageContactListInfoContact:
    NAME: str


@dataclass
class SageContactListInfo:
    CATEGORYNAME: str
    CONTACT: SageContactListInfoContact


@dataclass
class SageCustomer:
    NAME: str = None
    DISPLAYCONTACT: SageContact = None
    CONTACT_LIST_INFO: List[SageContactListInfo] = None
    GIVEWITH_ACCOUNT_ID: str = None
    STRIPE_CUSTOMER_ID: str = None


@dataclass
class SageGetObject:
    object: str
    key: str
    fields: str = '*'


@dataclass
class SageResult:
    recordNo: str



@dataclass
class SageContactResult(SageResult):
    contactName: str


@dataclass
class SageInvoiceResult(SageResult):
    invoiceNumber: str


@dataclass
class SageBillResult(SageResult):
    billNumber: str


@dataclass
class SageInvoiceBillResults:
    invoice: SageInvoiceResult
    bill: SageBillResult


@dataclass
class SageCustomerResult(SageResult):
    customerId: str



@dataclass
class SageLegacyDate:
    year: str = None
    month: str = None
    day: str = None


@dataclass
class SageTaxEntry:
    detailid: str = None
    trx_tax: float = None


@dataclass
class SageTaxEntries:
    taxentry: List[SageTaxEntry] = None


@dataclass
class SageCustomField:
    customfieldname: str = None
    customfieldvalue: str = None


@dataclass
class SageCustomFields:
    customfield: SageCustomField


@dataclass
class SageBillTaxEntry:
    DETAILID: str = None
    TRX_TAX: float = None


@dataclass
class SageBillTaxEntries:
    TAXENTRY: List[SageBillTaxEntry] = None


@dataclass
class SageBillItem: 
    ACCOUNTNO: str = None  # GL account number. Required if not using ACCOUNTLABEL
    ACCOUNTLABEL: str = None #AP account label. Required if not using ACCOUNTNO.
    OFFSETGLACCOUNTNO: str = None  
    TRX_AMOUNT: float = None  # req if INCLUSIVETAX if false
    TOTALTRXAMOUNT: float = None  # req if INCLUSIVETAX if true
    LOCATIONID: str = None
    DEPARTMENTID: str = None
    GIVEWITH_ORDER_ID: str = None
    GIVEWITH_TRANSACTION_ID: str = None
    STRIPE_TRANSACTION_ID: str = None
    PRODUCT_NAME: str = None
    PARTIALEXEMPT: bool = False
    TAXENTRIES: SageBillTaxEntries = None


@dataclass
class SageBillItems:
    APBILLITEM: List[SageBillItem] = None


@dataclass
class SageBill: 
    VENDORID: str = None #req if Action is not set to Draft
    WHENCREATED: str = None # transaction date in format mm/dd/yyyy req if action not set to Draft
    WHENPOSTED: str = None  #GL posting date mm/dd/yyyy not used if PBBATCH is provided
    RECORDID: str = None
    DESCRIPTION: str = None
    WHENDUE: str = None # Due date  mm/dd/yyyy. Req if Action is not set to Draft.
    PRBATCH: str = None # Req if bill summary is set to user specin AP config
    CURRENCY: str = None
    BASECURR: str = None
    EXCH_RATE_DATE: str = None  # date mm/dd/yyyy
    EXCH_RATE_TYPE_ID: str = None  # Do not use if EXCHANGE_RATE is set.
    EXCHANGE_RATE: str = None  # Do not use if EXCH_RATE_TYPE_ID is set.
    INCLUSIVETAX: bool = False
    ACTION: str = 'Submit' # is default - if draft affects other fields
    TAXSOLUTIONID: str = None
    APBILLITEMS: SageBillItems = None


@dataclass
class SageLineItem:
    glaccountno: str = None  # GL account number. Required if not using accountlabel
    accountlabel: str = None  # AP account label. Required if not using glaccountno
    offsetglaccountno: str = None
    amount: float = 0.0
    locationid: str = None
    departmentid: str = None
    totalpaid: float = None
    totaldue: float = None
    customfields: SageCustomFields = None
    taxentries: SageTaxEntries = None


@dataclass
class SageInvoiceItems:
    lineitem: List[SageLineItem] = None


@dataclass
class SageInvoice:
    customerid: str = None
    datecreated: SageLegacyDate = None
    dateposted: SageLegacyDate = None
    datedue: SageLegacyDate = None
    description: str = None
    basecurr: str = None
    currency: str = None
    exchratedate: SageLegacyDate = None
    exchratetype: str = None
    exchrate: float = None
    taxsolutionid: str = None
    invoiceitems: SageInvoiceItems = None
