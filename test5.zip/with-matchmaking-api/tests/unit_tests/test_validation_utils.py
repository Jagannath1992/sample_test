from matchmaking.utils import is_date
from matchmaking.validation.event import validate_deal_config

def test_is_date():
    assert is_date('2019-09-13T19:33:56.636Z')
    assert not is_date('11')

def test_validate_deal_config():
    good_deal = {
        'totalBudget': 1,
        'supplier': 1,
        'selectedPrograms': [{'programId': '5a14a8690992b2d24d8acda3'}],
        'customFields': {
            'newField2' : 1,
        }
    }

    deal_config = {
        "funding" : [
            {
                "fieldKey" : "totalBudget",
                "required" : True
            },
            {
                "fieldKey" : "givePercent",
                "required" : False
            },
            {
                "fieldKey" : "selectedPrograms",
                "required" : True
            },
        ],
        "general" : [
            {
                "fieldKey" : "supplier",
                "required" : True
            },
            {
                "fieldKey" : "supplierEmail",
                "required" : False
            },
            {
                "label" : "new field 1",
                "options" : [],
                "path" : "newField1",
                "required" : False,
                "type" : "textarea"
            },
            {
                "label" : "new field 2",
                "options" : [],
                "path" : "newField2",
                "required" : True,
                "type" : "textarea"
            }
        ]
    }

    isValid, result = validate_deal_config(deal_config, good_deal)
    assert isValid

    bad_deal = {
        'randomField': 1,
        'supplier': 1,
        'selectedPrograms': [{'programId': '5a14a8690992b2d24d8acda3'}],
        'customFields': {
            'newField2' : 1,
        }
    }

    isValid, result = validate_deal_config(deal_config, bad_deal)
    assert not isValid

    for k, v in result.items():
        if k == 'totalBudget':
            assert not v
        else:
            assert v

    # test 0
    deal = {
        'totalBudget': 0,
        'supplier': 1,
        'customFields': {
            'newField2' : 1,
        }
    }

    isValid, result = validate_deal_config(deal_config, deal)
    assert not isValid

    # test empty string
    deal = {
        'totalBudget': '',
        'supplier': 1,
        'customFields': {
            'newField2' : 1,
        }
    }

    isValid, result = validate_deal_config(deal_config, deal)
    assert not isValid

    # test empty list
    deal = {
        'totalBudget': [],
        'supplier': 1,
        'customFields': {
            'newField2' : 1,
        }
    }

    isValid, result = validate_deal_config(deal_config, deal)
    assert not isValid

    # test selected programs
    deal = {
        'totalBudget': [],
        'supplier': 1,
        'selectedPrograms': [{'programId': '1'}],
        'customFields': {
            'newField2' : 1,
        }
    }

    isValid, result = validate_deal_config(deal_config, deal)
    assert not isValid
