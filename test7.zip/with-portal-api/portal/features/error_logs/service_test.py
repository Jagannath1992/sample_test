import pytest
from portal.shared.repositories import error_log_repository
from portal.shared.services import error_log_service

class TestErrorLogService:

    @pytest.fixture
    def test_error_log_init(self, mocker, fakers, frozen_utcnow):
        error_log = fakers.error_log.generate_single()
        error_log['createdAt'] = frozen_utcnow
        mocker.patch.object(error_log_repository(), 'insert', return_value=error_log)
        return error_log


    def test_insert_log_error_sage(self, test_error_log_init, frozen_utcnow):
        #arrange
        error_log = test_error_log_init 
        created_by = error_log['createdBy']
        del error_log['_id']
        del error_log['createdBy']
        del error_log['createdAt']

        error_log_service().log(
            error_log['description'],
            error_log['source'],
            created_by,
            error_log['account'],
            error_log['messages'],
            error_log['order'],
            error_log['transaction']
        )

        #assert         
        error_log_repository().insert.assert_called_once_with(error_log, created_by)


    def test_send_notification(self):
        pass
