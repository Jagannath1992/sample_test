from flask import abort
from datetime import datetime, timedelta

from ..service.s3 import generate_signed_url
from app.db.utils import get_document


def has_tags(document, *tags):
    '''
    Search for a tag in the doc
    '''
    tag_string = document.get('tags', '')
    return tags and all(tag in tag_string for tag in tags)


def parse_tags(document, set_lowercase=True):
    '''
    Adds array of tags to document
    NOTE: This function has side effects
    '''
    if document.get('tags'):
        list_of_tags = document.get('tags').split(',')

        if set_lowercase:
            list_of_tags = [tag.lower() for tag in list_of_tags]

        while '' in list_of_tags:
            list_of_tags.remove('')

        document['list_of_tags'] = list_of_tags


def get_filtered_document(documents, filter_tags):
    '''
    Return document in which all strings in filter_tags are found within the 'tags' field
    '''
    filter_tags = [tag.lower() for tag in filter_tags]

    document = None
    for doc in documents:
        parse_tags(doc)

        if all(tag.lower() in doc['list_of_tags'] for tag in filter_tags):
            document = doc
            break

    return document


def get_filtered_documents(documents, filter_tags):
    '''
    Return documents in which all strings in filter_tags are found within the 'tags' field
    '''
    filter_tags = [tag.lower() for tag in filter_tags]

    document = []
    for doc in documents:
        parse_tags(doc)

        if all(tags in doc['list_of_tags'] for tags in filter_tags):
            document.append(doc)

    return document


def get_assets(document):
    '''
    Returns signed url of media and thumbnail images from a simian-media document
    '''
    media = document.get('media_s3', None)
    thumbnail = document.get('thumbnail_s3', None)

    _id = str(document.get('_id'))
    if media is None:
        abort(404, description='The field - media_s3 - in simian document ' + _id + ' is not found')
    if thumbnail is None:
        abort(404, description='The field - thumbnail_s3 - in simian document ' + _id + ' is not found')

    return {
        'media': generate_signed_url(media),
        'thumbnail': generate_signed_url(thumbnail)
    }


def add_assets_to_documents(documents):
    '''
    Adds signed url of media and thumbnail images to list of documents
    '''
    document_with_assets = []
    for doc in documents:
        doc = {**doc, **get_assets(doc)}

        for key in ['media_s3', 'thumbnail_s3']:
            doc.pop(key)

        document_with_assets.append(doc)

    return document_with_assets


def get_forex_rates():
    ''' Gets foreign exchange rates with a USD base
    NOTE: rates updated daily via a lambda function
    Data comes from https://ratesapi.io/
    '''
    forex = get_document('forex', {})

    if not forex:
        return {}

    forex_date = datetime.strptime(forex['date'], '%Y-%m-%d')
    forex_date_age = datetime.utcnow() - forex_date

    if forex_date_age > timedelta(days=7):
        return {}

    return forex['rates']


def get_now_time_string() -> str:
    """
    Returns the current date in milliseconds
    """
    return str(round(datetime.utcnow().timestamp() * 1000))
