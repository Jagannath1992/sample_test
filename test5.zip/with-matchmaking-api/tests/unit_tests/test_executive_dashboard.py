from datetime import datetime
from matchmaking.controllers.commerce.executive_dashboard import organize_deals_by_quarter, get_past_quarters, get_sum_per_quarter


def test_quarterly_date_full():
    deals = [{
        '_id': '1',
        'fundingAmount': 140000,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2020, 7, 13, 16, 29, 44, 87000),
        'totalBudget': 10000000
    }, {
        '_id': '2',
        'fundingAmount': 140000,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2020, 4, 13, 16, 29, 44, 87000),
        'totalBudget': 10000000
    }, {
        '_id': '3',
        'fundingAmount': 500,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2020, 2, 24, 16, 2, 48, 419000),
        'totalBudget': 1234134444
    }, {
        '_id': '4',
        'fundingAmount': 70000,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2020, 1, 27, 20, 51, 59, 855000),
        'totalBudget': 5000000
    }, {
        '_id': '5',
        'fundingAmount': 0.03,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 11, 11, 18, 6, 16, 50000),
        'totalBudget': 1
    }, {
        '_id': '6',
        'fundingAmount': 1,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 10, 10, 20, 0, 9, 920000),
        'totalBudget': 1
    }, {
        '_id': '7',
        'fundingAmount': 10000,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 9, 27, 17, 50, 45, 315000),
        'totalBudget': 250000
    }, {
        '_id': '8',
        'fundingAmount': 100000,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 9, 23, 17, 40, 50, 767000),
        'totalBudget': 250000
    }, {
        '_id': '9',
        'fundingAmount': 123,
        'statusUpdatedAt': datetime(2019, 8, 13, 17, 16, 47, 538000),
        'totalBudget': 1233,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '10',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 6, 11, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '11',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 3, 8, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '12',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 1, 2, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }]

    date_to_compare = datetime(2020, 7, 14)

    organized_deals = organize_deals_by_quarter(deals, date_to_compare)

    assert len(organized_deals.get(2020)['Q3']) == 1
    assert len(organized_deals.get(2020)['Q2']) == 1
    assert len(organized_deals.get(2020)['Q1']) == 2
    assert len(organized_deals.get(2019)['Q4']) == 2
    assert len(organized_deals.get(2019)['Q3']) == 3
    assert len(organized_deals.get(2019)['Q2']) == 1
    assert len(organized_deals.get(2019)['Q1']) == 2

    quarters = get_past_quarters(organized_deals, 4, date_to_compare)
    assert 'Q3' in quarters[0].get('deals')
    assert len(quarters[0].get('deals').get('Q3')) == 1
    assert 'Q2' in quarters[1].get('deals')
    assert len(quarters[1].get('deals').get('Q2')) == 1
    assert 'Q1' in quarters[2].get('deals')
    assert len(quarters[2].get('deals').get('Q1')) == 2
    assert 'Q4' in quarters[3].get('deals')
    assert len(quarters[3].get('deals').get('Q4')) == 2

    quarters_sum = get_sum_per_quarter(quarters)
    assert quarters_sum[0].get('quarter') == 'Q4'
    assert quarters_sum[0].get('value') == 2
    assert quarters_sum[1].get('quarter') == 'Q1'
    assert quarters_sum[1].get('value') == 2
    assert quarters_sum[2].get('quarter') == 'Q2'
    assert quarters_sum[2].get('value') == 1
    assert quarters_sum[3].get('quarter') == 'Q3'
    assert quarters_sum[3].get('value') == 1


def test_quarterly_date_missing_data():
    deals = [{
        '_id': '1',
        'fundingAmount': 0.03,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 11, 11, 18, 6, 16, 50000),
        'totalBudget': 1
    }, {
        '_id': '2',
        'fundingAmount': 1,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 10, 10, 20, 0, 9, 920000),
        'totalBudget': 1
    }, {
        '_id': '3',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 3, 8, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '4',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 1, 2, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }]

    date_to_compare = datetime(2020, 7, 14)

    organized_deals = organize_deals_by_quarter(deals, date_to_compare)

    assert len(organized_deals.get(2020)['Q3']) == 0
    assert len(organized_deals.get(2020)['Q2']) == 0
    assert len(organized_deals.get(2020)['Q1']) == 0
    assert len(organized_deals.get(2019)['Q4']) == 2
    assert len(organized_deals.get(2019)['Q3']) == 0
    assert len(organized_deals.get(2019)['Q2']) == 0
    assert len(organized_deals.get(2019)['Q1']) == 2

    quarters = get_past_quarters(organized_deals, 4, date_to_compare)
    assert 'Q3' in quarters[0].get('deals')
    assert len(quarters[0].get('deals').get('Q3')) == 0
    assert 'Q2' in quarters[1].get('deals')
    assert len(quarters[1].get('deals').get('Q2')) == 0
    assert 'Q1' in quarters[2].get('deals')
    assert len(quarters[2].get('deals').get('Q1')) == 0
    assert 'Q4' in quarters[3].get('deals')
    assert len(quarters[3].get('deals').get('Q4')) == 2

    quarters_sum = get_sum_per_quarter(quarters)
    assert quarters_sum[0].get('quarter') == 'Q4'
    assert quarters_sum[0].get('value') == 2
    assert quarters_sum[1].get('quarter') == 'Q1'
    assert quarters_sum[1].get('value') == 0
    assert quarters_sum[2].get('quarter') == 'Q2'
    assert quarters_sum[2].get('value') == 0
    assert quarters_sum[3].get('quarter') == 'Q3'
    assert quarters_sum[3].get('value') == 0


def test_quarterly_date_future_date():
    deals = [{
        '_id': '1',
        'fundingAmount': 0.03,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 11, 11, 18, 6, 16, 50000),
        'totalBudget': 1
    }, {
        '_id': '2',
        'fundingAmount': 1,
        'givewithCustomerRole': 'buyer',
        'statusUpdatedAt': datetime(2019, 10, 10, 20, 0, 9, 920000),
        'totalBudget': 1
    }, {
        '_id': '3',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 3, 8, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }, {
        '_id': '4',
        'fundingAmount': 1,
        'statusUpdatedAt': datetime(2019, 1, 2, 22, 11, 13, 414000),
        'totalBudget': 1,
        'givewithCustomerRole': 'buyer',
    }]

    date_to_compare = datetime(2022, 12, 5)

    organized_deals = organize_deals_by_quarter(deals, date_to_compare)

    assert 2022 in organized_deals

    quarters = get_past_quarters(organized_deals, 4, date_to_compare)
    assert len(quarters[0].get('deals').get('Q4')) == 0
    assert len(quarters[1].get('deals').get('Q3')) == 0
    assert len(quarters[2].get('deals').get('Q2')) == 0
    assert len(quarters[3].get('deals').get('Q1')) == 0

