import pytest
from portal.features.instances.validators import InstanceValidator
from werkzeug.exceptions import NotFound, BadRequest
from portal.shared.repositories import instance_settings_repository


class TestInstanceValidator:
    def test_no_ca_while_create(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance.pop('causeAreas')
        validator = InstanceValidator(instance)
        with pytest.raises(BadRequest):
            validator.validate_active_instance()

    def test_no_ca_while_update_to_active(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['status'] = 'inactive'
        instance.pop('causeAreas')
        update = fakers.instance_settings.generate_single()
        update.pop('causeAreas')
        validator = InstanceValidator(update, instance)
        with pytest.raises(BadRequest):
            validator.validate_active_instance(True)
    
    def test_ca_while_update_to_active(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['status'] = 'inactive'
        instance.pop('causeAreas')
        update = fakers.instance_settings.generate_single()
        validator = InstanceValidator(update, instance)
        assert validator.validate_active_instance(True) == None

    def test_no_skus_while_create(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance.pop('skus')
        validator = InstanceValidator(instance)
        with pytest.raises(BadRequest):
            validator.validate_active_instance()

    def test_no_skus_while_update_to_active(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['status'] = 'inactive'
        instance.pop('skus')
        update = fakers.instance_settings.generate_single()
        update.pop('skus')
        validator = InstanceValidator(update, instance)
        with pytest.raises(BadRequest):
            validator.validate_active_instance(True)
    
    def test_skus_while_update_to_active(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['status'] = 'inactive'
        instance.pop('skus')
        update = fakers.instance_settings.generate_single()
        validator = InstanceValidator(update, instance)
        assert validator.validate_active_instance(True) == None

    def test_no_url_while_create(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['settings']['termsOfUseUrl'] = None
        validator = InstanceValidator(instance)
        with pytest.raises(BadRequest):
            validator.validate_active_instance()

    def test_no_url_while_update_to_active(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['status'] = 'inactive'
        instance['settings']['termsOfUseUrl'] = None
        update = fakers.instance_settings.generate_single()
        update['settings']['termsOfUseUrl'] = None
        validator = InstanceValidator(update, instance)
        with pytest.raises(BadRequest):
            validator.validate_active_instance(True)
    
    def test_url_while_update_to_active(self, fakers):
        instance = fakers.instance_settings.generate_single()
        instance['status'] = 'inactive'
        instance['settings']['termsOfUseUrl'] = None
        update = fakers.instance_settings.generate_single()
        validator = InstanceValidator(update, instance)
        assert validator.validate_active_instance(True) == None

    def test_instance_name_exist(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'exists_by_filter', return_value=True)
        validator = InstanceValidator(instance)
        with pytest.raises(BadRequest):
            validator.validate_instance_name()
    
    def test_instance_name_not_exist(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'exists_by_filter', return_value=False)
        validator = InstanceValidator(instance)
        assert validator.validate_instance_name() == None

