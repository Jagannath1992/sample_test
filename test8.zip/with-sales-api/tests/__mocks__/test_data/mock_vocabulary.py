from bson.objectid import ObjectId

vocabulary = [
    # THEMES
    {
        '_id' : ObjectId('5d44b3b4d5b3a55e9e513cd7'),
        'type' : 'themes',
        'label' : 'Animal welfare',
        'versions' : [
            2
        ],
        'topic' : ObjectId('5db31645c8beeecf128d7321')
    },
    {
        '_id' : ObjectId('5d44b3b4d5b3a55e9e513cda'),
        'type' : 'themes',
        'label' : 'Arts and culture',
        'versions' : [
            2
        ],
        'topic' : ObjectId('5db31645c8beeecf128d7328')
    },
    {
        '_id' : ObjectId('5d44b3b4d5b3a55e9e513cd8'),
        'type' : 'themes',
        'label' : 'Criminal justice',
        'versions' : [
            2
        ],
        'topic' : ObjectId('5db31645c8beeecf128d732b')
    },

    # TOPICS
    {
        '_id' : ObjectId('5db31645c8beeecf128d7321'),
        'label' : 'Animal welfare',
        'type' : 'topic',
        'versions' : [
            2
        ]
    },
    {
        '_id' : ObjectId('5db31645c8beeecf128d7328'),
        'label' : 'Arts and culture',
        'type' : 'topic',
        'versions' : [
            1,
            2
        ]
    },
    {
        '_id' : ObjectId('5db31645c8beeecf128d732b'),
        'label' : 'Human rights and social justice',
        'type' : 'topic',
        'versions' : [
            1,
            2
        ]
    },

    # SCALETYPE
    {
        '_id' : ObjectId('5af4a134a64082a02a943c13'),
        'type' : 'scaleType',
        'label' : 'Proportional',
        'versions' : [
            1,
            2
        ],
    },
    {
        '_id' : ObjectId('5af4a134a64082a02a943c15'),
        'type' : 'scaleType',
        'label' : 'Static',
        'versions' : [
            1,
            2
        ]
    }
]
