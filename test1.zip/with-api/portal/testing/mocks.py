class MockResponse:
    def __init__(self, status: int = 200, data: any = None):
        self.data = data
        self.status_code = status

    def json(self) -> dict:
        return self.data

    @property
    def content(self):
        return self.data
