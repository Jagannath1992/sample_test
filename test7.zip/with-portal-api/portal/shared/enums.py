from enum import Enum, unique


@unique
class AccountStatus(str, Enum):
    NEW = 'new'
    PENDING = 'pending'
    PENDING_STRIPE = 'pending stripe'
    PENDING_FINANCE = 'pending finance'
    ACTIVE = 'active'
    LOCKED = 'locked'
    INACTIVE = 'inactive'
    DELETED = 'deleted'


@unique
class OrderStatus(str, Enum):
    DRAFT = 'draft'
    PENDING_APPROVAL = 'pending approval'
    APPROVED = 'approved'
    DENIED = 'denied'
    FINANCIAL_HOLD = 'financial hold'
    PENDING_PAYMENT = 'pending payment'
    COMPLETED = 'completed'
    ABANDONED = 'abandoned'
    FULFILLED = 'fulfilled'
    REJECTED = 'rejected'
    DELETED = 'deleted'


@unique
class UserRole(str, Enum):
    SUPER_ADMIN = 'givewith'
    GW_CSM = 'gw_csm'
    GW_FINANCE = 'gw_finance'
    GW_OPERATIONS = 'gw_operations'
    ORG_ADMIN = 'org_admin'
    USER_ADMIN = 'user_admin'
    FINANCE = 'finance'
    SALES = 'sales'
    APPROVER = 'approver'
    TRANSACTOR = 'transactor'
    EXECUTIVE = 'executive'


@unique
class SubscriptionFrequency(str, Enum):
    MONTHLY = 'monthly'
    ANNUAL = 'annual'


@unique
class FundingType(str, Enum):
    AUTOMATIC = 'automatic'
    MANUAL = 'manual'


@unique
class ErrorLogSourceType(str, Enum):
    OKTA = 'okta'
    PORTAL = 'portal'
    SAGE = 'sage'
    STRIPE = 'stripe'


@unique
class InstanceStatus(str, Enum):
    ACTIVE = 'active'
    INACTIVE = 'inactive'
 
 
@unique
class InstanceType(str, Enum):
    DEFAULT = 'default'
    PROCUREMENT = 'procurement'


@unique
class AccountType(str, Enum):
    DEFAULT = 'default'
    PROCUREMENT = 'procurement'
    SUPPLIER = 'supplier'

@unique
class ProductType(str, Enum) :
    SEllWITH = 'sellWith'
    BUYWITH = 'buyWith'

