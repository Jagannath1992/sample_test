import pytest
from bson import ObjectId
from portal.features.transactions.schema import TransactionRequest, TransactionSearchRequest
from portal.shared.repositories import account_repository, order_repository


class TestTransactionRequest:
    @pytest.fixture
    def schema(self):
        return TransactionRequest()

    @pytest.fixture
    def request_data(self, mocker, schema, fakers):
        mocker.patch.object(account_repository(), 'exists', return_value=True)
        mocker.patch.object(order_repository(), 'exists', return_value=True)
        return schema.dump(fakers.transaction.generate_single())

    def test_load(self, schema, request_data):
        # arrange
        account = request_data['account']
        order = request_data['order']
        expected = {
            'account': {
                '_id': ObjectId(account['id']),
                '_type': 'account',
                'name': account['name']
            },
            'order': {
                '_id': ObjectId(order['id']),
                '_type': 'order',
                'name': order['name']
            },
            'memo': request_data['memo'],
            'amount': request_data['amount']
        }

        # act
        result = schema.load(request_data)

        # assert
        assert result == expected

    class TestTransactionSearchRequest:
        def test_load_error_log_ids(self):
            data = {
                'count': 10,
                'orderBy': 'decending',
                'offset': 0,
                'accountId': str(ObjectId()),
                'id': str(ObjectId())
            }

            response = TransactionSearchRequest().load(data)

            assert not response.get('accountId')
            assert response['account._id'] == ObjectId(data['accountId'])
            assert response['_id'] == ObjectId(data['id'])
            assert response['orderBy'] == 'decending'

