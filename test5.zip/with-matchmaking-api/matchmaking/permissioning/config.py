from functools import wraps
from typing import Callable, Iterable, List, Tuple
from urllib.parse import urlparse

import casbin
from flask import request

from matchmaking.dao.utils import get_document_by_id
from matchmaking.models.models import to_bool
from matchmaking.permissioning.constants import Action
from matchmaking.utils import GivewithError, send_loggly


CASBIN_ENFORCER: casbin.Enforcer = None
ENFORCE_ON_SUBDOMAINS = ('metpolice', 'impact')


class ArrayAdapter(casbin.persist.Adapter):
    """Read-Only Array adapter for Cabsin.
    It can load policy from an iterable of iterable
    """
    def __init__(self, policy_rules: Iterable[Iterable[str]]) -> None:
        self.rules = policy_rules

    def load_policy(self, model: casbin.model.Model) -> None:
        for rule in self.rules:
            casbin.persist.load_policy_line(', '.join(rule), model)


def init_enforcer(policies: Iterable[Iterable]) -> None:
    """Initialize the Casbin Enforcer"""
    global CASBIN_ENFORCER # pylint: disable=global-statement

    casbin_model = casbin.model.Model()

    casbin_model_str = '''
        [request_definition]
        r = sub, obj_type, act

        [policy_definition]
        p = sub_rule, sub, obj_type, act

        [role_definition]
        g = _, _

        [policy_effect]
        e = some(where (p.eft == allow))

        [matchers]
        m = ((p.sub_rule == "" || eval(p.sub_rule)) && (p.sub == "*" || g(r.sub, p.sub)) && keyMatch2(r.obj_type, p.obj_type) && (p.act == "*" || r.act == p.act)) || r.sub == 'superuser'
    '''

    casbin_model.load_model_from_text(casbin_model_str)
    CASBIN_ENFORCER = casbin.Enforcer(casbin_model, ArrayAdapter(policies))


def can(action: Action, object_type: str = '') -> Callable:
    """View Decorator to control access a resource

    Usage:
        @app.route('/', methods=['POST'])
        @can(Action.CREATE, 'Deal')
        def create_deals():
            return success, 200

    Args:
        action (Action): [The CRUD permission required to access the resource]
        object_type (str, optional): [The resource label - not yet used]. Defaults to ''.
    """
    def enforcer(view_func: Callable) -> Callable:
        @wraps(view_func)
        def enforce(*args, **kwargs):
            user_brand = get_document_by_id('mm_brands', request.user['orgId'], projection=['featureFlags.rbac'])
            user_brand_supports_rbac = user_brand.get('featureFlags', {}).get('rbac', False)

            hostname = urlparse(request.headers.get('Origin')).hostname or ''
            is_from_enforce_client = any(hostname.startswith(subdomain) for subdomain in ENFORCE_ON_SUBDOMAINS)
            is_enforce_request = is_from_enforce_client or to_bool(request.headers.get('X-EnforcePermissions'))

            if user_brand_supports_rbac and is_enforce_request:
                for subject in request.user.get('roles', []):
                    if CASBIN_ENFORCER.enforce(subject, object_type, str(action)):
                        break
                else:
                    send_loggly(f'Unauthorized { action } at { str(request.path) } by { request.user["username"] }')
                    raise GivewithError('You do not have the appropriate permission to perform this action.', code=403)

            return view_func(*args, **kwargs)

        return enforce
    return enforcer
