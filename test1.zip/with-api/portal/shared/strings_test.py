from portal.shared.strings import format_currency


def test_format_currency():
    # arrange
    input = 123456.25
    expected = '$123,456.25'

    # act
    actual = format_currency('$', input)

    # assert
    assert actual == expected


def test_format_currency_none():
    # arrange
    input = None
    expected = ''

    # act
    actual = format_currency('$', input)

    # assert
    assert actual == expected


def test_format_currency_wrong_format():
    # arrange
    input = 'Not a number'
    expected = ''

    # act
    actual = format_currency('$', input)

    # assert
    assert actual == expected
