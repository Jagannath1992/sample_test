CSRHUB_MAPPING = {
    "Community Dev & Philanthropy": "Community Development and Philanthropy",
    "Diversity & Labor Rights" :"Diversity and Labor Rights",
    "Human Rights & Supply Chain" : "Human Rights and Supply Chain",
    "Energy & Climate Change" : "Energy and Climate Change",
    "Leadership Ethics" : "Leadership Ethics",
}
VOCAB_TO_CSRHUB = {
    "Community Development and Philanthropy":"Community Dev & Philanthropy",
    "Diversity and Labor Rights": "Diversity & Labor Rights",
    "Human Rights and Supply Chain": "Human Rights & Supply Chain",
    "Energy and Climate Change":"Energy & Climate Change",
    "Leadership Ethics":"Leadership Ethics"
}