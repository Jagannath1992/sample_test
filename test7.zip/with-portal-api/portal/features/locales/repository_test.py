import multiprocessing
import pytest
#from portal.shared.repositories import locale_repository
from portal.features.locales.faker import LocaleFaker


class TestLocaleRepository:

    def test_get_locales(self, repositories, fakers):
        expected = fakers.locale.insert_many(4)
        locale_repo = repositories['locale']

        request_filters = {
            'count': 10,
            'offset': 0,
            'orderBy': 'name',
            'descending': False
        }

        actual = locale_repo.get_page(request_filters)
        assert actual == (4, expected)
