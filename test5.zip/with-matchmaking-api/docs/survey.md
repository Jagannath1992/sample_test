# Surveys (PSF, PCF, PFF)

## schema

Please glance over the `survey_model` schema in `models.py` before reading this.

`survey_model` schema is used to validate, normalize and calculate the progress of surveys. Surveys were designed to capture as much user data as possible and allow future edits of it. Hence, validation is a bit relaxed when they are still in progress. The parameters `set_required` and `set_empty` are False and True respectively by default to allow this (i.e no entries are required and they all can be empty)

The required and empty toggles are useful when calculating how many required fields have been fully filled out and hence, allowing the form to become a program.

`dependencies` refer to the question dependencies config in the `survey_data` collection in the db that toggles some questions' required flag on or off based on other values in the form data.

NOTE: Ideally, such a dependency config should live in a python file, however, it relies heavily on vocabulary ids and is hence kept in the database to keep the vocab ids consistent across environments.

A sample config entry in this collection has the following structure. Below describes the config for a question whose unique key is "animalHabitat" (i.e the survey question: `'Please select the habitat of the animals that you protect'` in the `'Impact And Scope'` section of the PSF)

```js
{
    "animalHabitat": { // unique question key - used to access the dependency config
        // boolean operator -> ie. this question is required if one of formData["keys"]["key"] in | nin "values"
        "operation": "in" | "nin",
        // the key in formData where the answer for this question is stored
        // useful for deleting the value of this question if answer is no longer required
        // i.e question was required, and answered but user went back to change their answers such that it was no longer required
        "key": "impactAndScope.animalHabitat.value",
        // the keys in formData whose values can make this question required or not
        "keys": [
            {
                "key": "impactAndScope.primaryImpact.value",
                // the front-end needs to show why this question is required. DescriptionSuffix is used for this
                // eg. `This question was added because you selected xyz as this program's primary targeted impact`
                "descriptionSuffix": "this program's primary targeted impact"
            },
            {
                "key": "impactAndScope.secondaryImpact.value",
                "descriptionSuffix": "a secondary impact of this program"
            },
        ],
        // values at which this question should be required or not
        "values": {
            "vocab_object_id_a": "Protect animal welfare",
            "vocab_object_id_b": "Protect endangered, vulnerable, or threatened species"
        }
    }
}
```
