from flask_profiler import Profiler
from os import environ

def init_profiler(app):
    return
    env = environ['ENV']
    if env.lower() == 'production' or env.lower() == 'prod':
        return

    app.config['flask_profiler'] = {
        'enabled': True,
        'storage': {
            'engine': 'mongodb',
            'MONGO_URL': environ.get('MONGO_URL'),
            'DATABASE': environ.get('MONGO_DATABASE'),
            'COLLECTION': 'measurements',
        },
        'endpointRoot': 'profile',
        'ignore': [
            '^/static/.*',
            '^\/$',
        ]
    }
    profiler = Profiler()
    profiler.init_app(app)
