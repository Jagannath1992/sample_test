from enum import Enum, unique


@unique
class WebhookEventType(str, Enum):
    CHECKOUT_SESSION_COMPLETED = 'checkout.session.completed'
    CUSTOMER_SUBSCRIPTION_TRIAL_WILL_END = 'customer.subscription.trial_will_end'
    CUSTOMER_SUBSCRIPTION_CREATED = 'customer.subscription.created'
    CUSTOMER_SUBSCRIPTION_UPDATED = 'customer.subscription.updated'
    CUSTOMER_SUBSCRIPTION_DELETED = 'customer.subscription.deleted'


@unique
class StripeCheckoutSessionMode(str, Enum):
    # PAYMENT = 'payment'
    SUBSCRIPTION = 'subscription'
    SETUP = 'setup'


@unique
class StripePaymentMethodType(str, Enum):
    '''See: https://stripe.com/docs/api/payment_methods/object#payment_method_object-type '''
    CARD = 'card',
    US_BANK_ACCOUNT = 'us_bank_account'
    # UK_BANK_DEBIT = 'bacs_debit'


@unique
class StripeTestPaymentMethods(str, Enum):
    CARD_US_VISA = 'pm_card_us'
    US_BANK_ACCOUNT_SUCCESS = 'pm_usBankAccount_success'

# https://stripe.com/docs/testing


@unique
class StripeSetupIntentAction(str, Enum):
    UPDATE_SUBSCRIPTION_PAYMENT_METHOD = 'update_subscription_payment_method'
    UPDATE_AUTOMATIC_PAYMENT_METHOD = 'update_automatic_payment_method'
    COMPLETE_ORDERS = 'complete_orders'


@unique
class StripeSetupIntentNextAction(str, Enum):
    VERIFY_MICRO_DEPOSITS = 'verify_micro_deposits'


@unique
class StripeSubscriptionStatus(str, Enum):
    ACTIVE = 'active'
    TRIALING = 'trialing'
