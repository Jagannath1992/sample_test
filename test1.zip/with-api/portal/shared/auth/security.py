from typing import Dict, List

from bson import ObjectId
from flask import Request
from werkzeug.exceptions import Forbidden, BadRequest, NotFound
from portal.shared.enums import UserRole, SubscriptionType
from portal.shared.constants import GIVEWITH_ROLES


def has_role(roles: List[UserRole], user: Dict) -> bool:
    return any([
        role for role in user.get('roles', [])
        if role in roles
    ])


def has_subscription_type(account: Dict, sub_type: SubscriptionType) -> bool:
    try:
        account_sub_type = account['subscription']
    except KeyError:
        raise NotFound('The Subscription type information is not found.')
    return sub_type == account_sub_type

def get_validated_account_id(request_account_id: ObjectId, request: Request) -> ObjectId:
    user_account_id = request.user['accountId']
    if not has_role(GIVEWITH_ROLES, request.user):
        if not request_account_id or ObjectId(request_account_id) == user_account_id:
            return user_account_id
        raise Forbidden('You do not have permission to access this resource')
    if not request_account_id:
        raise BadRequest('accountId is required')
    return ObjectId(request_account_id)
