from bson import ObjectId
from portal.testing.faker import DocumentFaker
from portal.shared.dates import get_utcnow


class CauseAreaFaker(DocumentFaker):
    def _generate_document(self, i):
        now = get_utcnow()
        return {
            '_id': ObjectId(),
            'name': f'Cause area {i}',
            'partnerName': f'Partner {i}',
            'description': f'Description {i}',
            'tooltip': f'Tooltip {i}',
            'listImageName': f'ListImageName {i}',
            'detailImageName': f'DetailImageName {i}',
            'detailLinkText': f'DetailLinkText {i}',
            'detailLinkUrl': 'https://impact.givewith.com/program-preview',
            'sageVendorId': f'V-58{i}',
            'skuPrefix': f'123{i}',
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now,
            'active': True
        }
