import pandas as pd

from bson import ObjectId
from flask import request, Response
from flask_restx import Namespace, Resource
from flask_accepts import accepts, responds
from werkzeug.exceptions import NotFound, BadRequest

from portal.shared.auth.requests import role_required, token_required
from portal.shared.auth.security import get_validated_account_id
from portal.shared.enums import UserRole
from portal.shared.repositories import account_repository, cause_area_repository, instance_settings_repository, locale_repository
from portal.shared.services import order_service
from portal.features.cause_areas.schema import CauseAreaRequest, CauseAreaResponse, SkuResponse, \
    CauseAreaSearchRequest, CauseAreaSearchResponse, CauseAreaMetricsRequest, CauseAreaMetricsResponse
from portal.features.cause_areas.validators import CauseAreaValidator

namespace = Namespace('cause-areas', description='Cause Area related operations')


@namespace.route('')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class CauseAreas(Resource):
    @token_required
    @accepts(query_params_schema=CauseAreaSearchRequest, api=namespace)
    @responds(schema=CauseAreaSearchResponse, api=namespace)
    def get(self):
        """Search Cause Areas"""
        filters = request.parsed_query_params
        account_id = filters.pop('accountId', None)

        # Check to see if we need to filter for the current account/instance
        if account_id:
            account_id = get_validated_account_id(account_id, request)
            account = account_repository().get_single(account_id, {'instance._id': 1})
            instance = instance_settings_repository().get_single(account['instance']['_id'])
            cause_area_ids = [ca['causeArea']['_id'] for ca in instance.get('causeAreas', [])]
            if cause_area_ids:
                filters['_id'] = {'$in': cause_area_ids}

        total_count, cause_areas = cause_area_repository().get_page(filters)
        instance_settings_repository().populate_cause_area_instance_counts(cause_areas)
        return {
            'totalCount': total_count,
            'results': cause_areas
        }

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=CauseAreaRequest, api=namespace)
    @responds(schema=CauseAreaResponse, api=namespace)
    @namespace.response(502, 'An error occurred while attempting to create a cause area')
    def post(self):
        """Create Cause Area"""
        cause_area_request = request.parsed_obj
        validator = CauseAreaValidator(cause_area_request)
        validator.validate_cause_area_name()
        validator.validate_image_names()
        cause_area = cause_area_repository().insert(cause_area_request, request.user['username'])
        return cause_area


@namespace.route('/<id>')
class CauseAreaById(Resource):
    @token_required
    @namespace.doc(security="Bearer")
    @namespace.response(401, 'Token is invalid or expired')
    @namespace.response(404, 'Cause Area not found')
    @responds(schema=CauseAreaResponse, api=namespace)
    def get(self, id: ObjectId):
        """Get Cause Area by ID"""
        cause_area = self._get(id)
        return cause_area

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=CauseAreaRequest, api=namespace)
    @responds(schema=CauseAreaResponse, api=namespace)
    def put(self, id: str):
        """Update Cause Area by ID"""
        cause_area = self._get(id)
        update = request.parsed_obj
        validator = CauseAreaValidator(update, cause_area)
        validator.validate_cause_area_name()
        validator.validate_cause_area_status()
        validator.validate_image_names()
        cause_area.update(update)
        cause_area = cause_area_repository().update(cause_area, request.user['username'])
        return cause_area

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=CauseAreaRequest(partial=True), api=namespace)
    @responds(schema=CauseAreaResponse, api=namespace)
    def patch(self, id: str):
        """Update Cause Area from Partial"""
        cause_area = self._get(id)
        update = request.parsed_obj
        validator = CauseAreaValidator(update, cause_area)
        validator.validate_cause_area_name()
        validator.validate_cause_area_status()
        instance = cause_area_repository().patch(id, update, request.user['username'])
        return instance

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @responds(schema=CauseAreaResponse, api=namespace)
    def delete(self, id: str):
        """Deactivate Cause Area"""
        cause_area = self._get(id)
        update = {'active': False}
        validator = CauseAreaValidator(update, cause_area)
        validator.validate_cause_area_status()
        cause_area = cause_area_repository().patch(id, update, request.user['username'])
        return cause_area

    def _get(self, id):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        cause_area = cause_area_repository().get_single(id)
        if not cause_area:
            raise NotFound('Cause Area not found')
        return cause_area


@namespace.route('/<id>/instances')
class CauseAreaByIdInstances(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @responds(api=namespace)
    def get(self, id: str):
        '''Get Associated Instances'''
        data = instance_settings_repository().get_associated(id)
        dataFrame = pd.DataFrame(data)

        return Response(
            dataFrame.to_csv(index=False),
            mimetype = "text/csv",
            headers = {"content-disposition": "attachment; filename='associated-instances.csv'"})


@namespace.route('/<cause_id>/skus')
@namespace.route('/<cause_id>/skus/<account_id>')
class CauseAreaByIdSkus(Resource):
    @token_required
    @namespace.doc(security="Bearer")
    @namespace.response(401, 'Token is invalid or expired')
    @responds(schema=SkuResponse(many=True), api=namespace)
    def get(self, cause_id: str, account_id: str = None):
        account_id = get_validated_account_id(account_id, request)
        account = account_repository().get_single(account_id, {'instance._id': 1})
        if not account:
            raise NotFound('Account not found')

        cause_area = cause_area_repository().get_single(cause_id)
        if not cause_area:
            raise NotFound('Cause Area not found')

        instance = instance_settings_repository().get_single(account['instance']['_id'])
        cause_map = { str(ca['causeArea']['_id']): ca for ca in instance.get('causeAreas', []) }
        skus = instance.get('skus', [])

        # Check for SKU overrides
        if cause_id in cause_map:
            cause_skus = cause_map[cause_id].get('skus', [])
            if cause_skus:
                skus = cause_skus

        locale = locale_repository().get_single(instance['settings']['locale']['_id'])
        currency = locale['settings']['currency']
        symbol = locale['settings']['symbol']
        prefix = cause_area['skuPrefix']

        skus = [
            {
                '_id': f'{cause_id}-{sku:.0f}',
                'name': f'{prefix}-{sku:05.0f}',
                'description': f'{symbol}{sku:,.0f}',
                'unitCost': sku,
                'currency': currency
            } for sku in skus
        ]

        return skus


@namespace.route('/metrics/detail')
class CauseAreaMetricsDetail(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=CauseAreaMetricsRequest, api=namespace)
    @responds(schema=CauseAreaMetricsResponse, api=namespace)
    def post(self):
        '''Cause Area metrics detail by Cause Area'''
        filters = request.parsed_obj
        results, currencies = order_service().get_metrics(filters, False, False)
        return {
            'results': results,
            'currencies': currencies
        }


@namespace.route('/metrics/overview')
class CauseAreaMetricsOverview(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=CauseAreaMetricsRequest, api=namespace)
    @responds(schema=CauseAreaMetricsResponse, api=namespace)
    def post(self):
        '''Cause Area metrics overview'''
        filters = request.parsed_obj
        results, currencies = order_service().get_metrics(filters, True, False)
        return {
            'results': results,
            'currencies': currencies
        }


@namespace.route('/metrics/download')
class CauseAreaMetricsDownload(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=CauseAreaMetricsRequest, api=namespace)
    @responds(api=namespace)
    def post(self):
        '''Cause Area metrics detail for download'''
        filters = request.parsed_obj
        results, _ = order_service().get_metrics(filters, False, False)

        data = order_service().flatten_metrics(results)
        filename = order_service().get_filename(filters, 'cause-area-metrics')

        return Response(
            data.to_csv(index=False),
            mimetype = "text/csv",
            headers = {"content-disposition": f"attachment; filename='{filename}'"})
