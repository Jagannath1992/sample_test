from decimal import Decimal
from bson import ObjectId
from portal.shared.dates import get_utcnow
from portal.testing.faker import DocumentFaker


class TransactionFaker(DocumentFaker):
    def _generate_document(self, i):
        now = get_utcnow()
        document = {
            '_id': ObjectId(),
            'account': {
                '_id': ObjectId(),
                '_type': 'account',
                'name': f'Account {i}',
            },
            'order': {
                '_id': ObjectId(),
                '_type': 'order',
                'name': f'Order {i}',
            },
            'memo': f'Memo {i}',
            'amount': i,
            'startingBalance': i,
            'endingBalance': i,
            'currency': 'USD',
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now,
            'stripe': {
                'paymentIntentId': 'pi_3LFhjjFpuAfBZp0K0zzS8f45'
            },
            'sage': {
                'invoiceId': f'INV00{i}',
                'invoiceRecordNo': i,
                'billRecordNumber': f'B00{i}',
                'billRecordNo': i
            }
        }
        return document
