from datetime import datetime

import pytest
from bson import ObjectId
from flask import request

from portal.conftest import AuthHeaderUsername, get_account_id_from_header
from portal.features.locales.schema import LocaleRequest, LocaleSearchResponse, LocaleResponse
from portal.shared.enums import AccountStatus, UserRole
from portal.shared.repositories import locale_repository, instance_settings_repository
from portal.shared.services import email_service


class TestLocaleResource:
    def test_get_all(self, client, givewith_header, mocker, fakers):
        locales = fakers.locale.generate_many(3)
        mocker.patch.object(locale_repository(), 'get_page', return_value=(3, locales))
        expected = LocaleSearchResponse().dump({
            'totalCount': 3,
            'results': locales
        })

        query_params = {
            'orderBy': 'name',
            'offset': 0,
            'count': 10
        }

        response = client.get('/locales', query_string=query_params, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == expected

    def test_create(self, client, givewith_header, fakers):
        new = LocaleRequest().dump(fakers.locale.generate_new())
        assert locale_repository().collection.count_documents({}) == 0

        response = client.post('/locales', json=new, headers=givewith_header)

        assert response.status_code == 200
        assert locale_repository().collection.count_documents({}) == 1

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS]],
        indirect=True
    )
    def test_create_locale_permissions(self, client, custom_auth_header, fakers):
        new = LocaleRequest().dump(fakers.locale.generate_new())

        response = client.post('/locales', json=new, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}


class TestLocaleByIdResource:
    def test_get(self, client, givewith_header, mocker, fakers):
        locale_repo = locale_repository()
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repo, 'get_single', return_value=locale)
        response = client.get(f'locales/{ObjectId()}', headers=givewith_header)
        expected = LocaleResponse().dump(locale)
        assert response.status_code == 200
        assert response.json == expected

    def test_get_404(self, mocker, client, givewith_header):
        mocker.patch.object(locale_repository(), 'get_single', lambda id: None)
        response = client.get(f'/locales/{ObjectId()}', headers=givewith_header)
        assert response.status_code == 404

    def test_put(self, client, givewith_header, fakers, mocker):
        locale = fakers.locale.insert_single()
        request_json = LocaleRequest().dump(locale)
        request_json["name"] = "USA"
        response = client.put(f'/locales/{locale["_id"]}', json=request_json, headers=givewith_header)
        assert response.status_code == 200

    def test_put_locale_notfound(self, client, givewith_header, fakers, mocker):
        locale = fakers.locale.insert_single()
        request_json = LocaleRequest().dump(locale)
        request_json["name"] = "USA"
        response = client.put(f'/locales/{ObjectId()}', json=request_json, headers=givewith_header)
        assert response.status_code == 404
        assert response.json == {"message": f"Locale not found"}

    def test_delete(self, client, fakers, givewith_header, mocker):
        instance_repo = instance_settings_repository()
        locale_repo = locale_repository()
        inst_count = [{'_id': 'US', 'total': 0}]
        mocker.patch.object(instance_repo, 'get_count_by_locale', return_value=inst_count)
        locale = fakers.locale.generate_single()
        locale['active'] = False
        mocker.patch.object(locale_repo, 'get_single', return_value=locale)
        mocker.patch.object(locale_repo, 'patch', return_value=locale)
        response = client.delete(f'locales/{ObjectId()}', headers=givewith_header)
        assert response.status_code == 200
        assert response.json["active"] == False

    def test_patch(self, client, fakers, givewith_header):
        locale = fakers.locale.insert_single()
        request = {
            "description": "Another description",
            "settings": {
                "currency": "GMC",
                "regionLabel": "Province"
            },
            "active": False
        }
        response = client.patch(f'locales/{locale["_id"]}', json=request, headers=givewith_header)
        assert response.status_code == 200
        assert response.json["active"] == False
        assert response.json["settings"]["symbol"] == locale["settings"]["symbol"]


class TestLocale_integration:
    pytestmark = pytest.mark.integration

    def test_delete(self, client, fakers, givewith_header):
        locale = fakers.locale.insert_single()
        response = client.delete(f'locales/{locale["_id"]}', headers=givewith_header)
        assert response.status_code == 200
        assert response.json["active"] == False
