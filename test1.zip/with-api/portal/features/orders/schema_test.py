import pytest
from bson import ObjectId
from marshmallow import ValidationError
from portal.features.orders.schema import OrderByIdResendNotificationRequest, OrderDetailSchema, OrderRequest, OrderSearchRequest
from portal.shared.email.validator import EmailValidator
from portal.shared.repositories import account_repository, cause_area_repository, sku_repository, user_repository, \
    order_repository


class TestOrderDetailSchema:

    def test_validate_total_cost_fails(self, fakers):
        # 2 items of 20 each exceeds the totalCost
        data = {
            'skuId': str(ObjectId()),
            'skuName': 'SKU 1',
            'qty': 2,
            'unitCost': 20,
            'totalCost': 20
        }
        with pytest.raises(ValidationError) as error:
            OrderDetailSchema().load(data)

        assert error.value.messages == {'totalCost': ['Invalid Total for SKU SKU 1']}


class TestPostOrderRequest:
    @pytest.fixture()
    def schema(self) -> OrderRequest:
        return OrderRequest()

    @pytest.fixture()
    def account_fake(self, fakers):
        return fakers.account.generate_single()

    @pytest.fixture()
    def cause_area_fake(self, fakers):
        return fakers.cause_area.generate_single()

    @pytest.fixture()
    def request_data(self, mocker, fakers, account_fake, cause_area_fake):
        mocker.patch.object(account_repository(), 'exists', return_value=True)
        mocker.patch.object(user_repository(), 'exists', return_value=True)
        mocker.patch.object(cause_area_repository(), 'exists', return_value=True)
        mocker.patch.object(sku_repository(), 'exists', return_value=True)
        order = fakers.order.generate_single()
        mocker.patch.object(order_repository(), 'get_single', return_value=order)
        return OrderRequest().dump(order)

    def test_validate(self, request_data, schema):
        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_validate_grandTotal(self, request_data, schema):
        # arrange
        request_data.update({
            'detail': [
                {
                    'skuId': str(ObjectId()),
                    'skuName': 'SKU 1',
                    'qty': 1,
                    'unitCost': 20,
                    'totalCost': 20
                },
                {
                    'skuId': str(ObjectId()),
                    'skuName': 'SKU 2',
                    'qty': 2,
                    'unitCost': 10,
                    'totalCost': 20
                }
            ],
            'grandTotal': 45
        })

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'grandTotal': ['Invalid Grand Total']}


class TestOrderSearchRequest:

    def test_post_load_cause_area(self):
        data = {
            'count': 10,
            'orderBy': 'approver',
            'offset': 0,
            'causeArea': str(ObjectId())
        }

        response = OrderSearchRequest().load(data)

        assert not response.get('causeArea')
        assert response['causeArea._id'] == ObjectId(data['causeArea'])

    def test_post_load_account_id(self):
        data = {
            'count': 10,
            'orderBy': 'approver',
            'offset': 0,
            'accountId': ObjectId()
        }

        response = OrderSearchRequest().load(data)

        assert not response.get('accountId')
        assert response['account._id'] == data['accountId']


class TestOrderByIdResendNotificationRequest:
    @pytest.fixture()
    def schema(self) -> OrderByIdResendNotificationRequest:
        return OrderByIdResendNotificationRequest()

    def test_validate_emailAddresses(self, mocker, schema):
        # arrange
        mocker.patch.object(EmailValidator, 'validate', return_value=None)
        request_data = {
            'emailAddresses': [
                'test@test.com'
            ]
        }

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'emailAddresses': ['Invalid email address "test@test.com" provided.']}
