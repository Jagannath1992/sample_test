from bson import ObjectId
from datetime import datetime
from matchmaking import db

from matchmaking.mongodb import create_ref, get_is_valid_nonprofit
from matchmaking.utils import get_descendant_key, set_descendant_key, remove_empty
from matchmaking.models.models import schema_program_v2, v

# def undo_migration():
#     global db
#     programs = list(db().db.get_collection('mm_programs_v1').find({}))

#     for program in programs:
#         program_id = program.get('_id')
#         db().coll_programs.find_one_and_replace({'_id': program_id}, program)

#     db().db.get_collection('mm_programs_v1').drop()

def append_to_descendant_key(value, dict_item, desc_str):
    """
    Sets a descendant key of a dictionary as value
    """
    arr = desc_str.split('.')

    while len(arr) > 1:
        dict_item = dict_item.setdefault(arr.pop(0), {})

    dict_item.setdefault(arr.pop(0), []).append(value)

def isEmpty(value):
    if isinstance(value, bool):
        return False

    return not value

# these functions will transform the answers as needed
def _to_list(value, *args):
    return [value]

def _bool_to_approach(value, *args):
    if value is True:
        return db().coll_vocabulary.find_one({'versions': {'$in': [2]}, 'label': 'Ongoing'}).get('_id')
    else:
        return db().coll_vocabulary.find_one({'versions': {'$in': [2]}, 'label': 'One-time'}).get('_id')

def _gender_to_attribute(value, *args):
    global ObjectId

    for item in value:
        v1_label = db().coll_vocabulary.find_one({'_id': ObjectId(item)})

        if v1_label and v1_label['label'] == 'Female':
            v2_label = db().coll_vocabulary.find_one({'label': 'Women and girls'})
            return v2_label['_id']
    else:
        return None

def _transform_outputs(value, budget, *args):
    global remove_empty

    outputs = []

    # for outputs, quantity is actually = budget/cost_per_output,
    # cost_per_output is calculated by output['cost] / quantity
    for output in value:
        scale_type = output.get('scaleType', '')
        quantity = output.get('quantity')

        try:
            scale_label = db().coll_vocabulary.find_one({'_id': ObjectId(scale_type)})['label']
            if scale_label.lower() == 'proportional':
                quantity = int(budget / (output['cost'] / quantity))
        except Exception as e:
            print(f'Exception: {e} when calculating quantity for {output}')

        data = {
            'quantity': quantity,
            'description': output.get('label', ''),
            'scaleType': scale_type
        }

        remove_empty(data)

        if data:
            outputs.append(data)

    return outputs

def _transform_outcomes(value, *args):
    global remove_empty

    outcomes = []
    for outcome in value:
        data = {
            'quantity': outcome.get('value') or outcome.get('staticValue'),
            'description': outcome.get('description')
        }

        remove_empty(data)

        if data:
            outcomes.append(data)

    return outcomes

# commented out fields are fields that are being kept without any modifications
fields_map = {
    # program_v1 : # program_v2
    'name': {'key': 'General.name.platformProgramName'},
    'primaryImpact': {'key':'primaryImpact', 'transform': [_to_list]},
    'secondaryImpacts': {'key': 'secondaryImpacts', 'default': ['N/A']},
    'animalHabitat': {'key': 'ImpactAndScope.animalHabitat.value'},
    'forestProtection': {'key': 'ImpactAndScope.protectAndEnhanceForest.value'},
    'isOngoingProgram': {'key': 'approachDuration', 'transform': [_bool_to_approach]},
    'outputs': {'key': 'outputs', 'helperKey': 'budget', 'transform': [_transform_outputs]},
    'outputNotes': {'key': 'StrategiesAndApproaches.outputs.optional'},
    'customOutputs': {'key': 'outcomes', 'transform': [_transform_outcomes]},
    'oneOrMorePartnerOrganizations': {'key': 'nonprofitPartners', 'default': False},
    'interventions': {'key': 'approach'},
    'additionalValueFields.contributionsCash': {'key': 'cashContributions'},
    'additionalValueFields.contributionsInKind': {'key': 'inKindContributions'},
    'audienceGender': {'key': 'audienceAttribute', 'type': 'append', 'transform': [_gender_to_attribute]},
    'audienceAttribute': {'key': 'audienceAttribute', 'default': ['N/A']}
}


programs = list(db().coll_programs.find({}))

for program in programs:
    program_id = program.get('_id')

    if program.get('version') == 2:
        # just in case we have to run this migration more than once,
        # find check to see if this program has a v1 version, then re-transform it
        program = db().db.get_collection('mm_programs_v1').find_one({'_id': program_id})

        # if this is a pure v2 program, simply ignore and continue
        if not program:
            continue

    # create a backup of the program -> simply overwrite if pulled from backup
    # upsert is True so that if the program has never been transformed, it will be backed up
    db().db.get_collection('mm_programs_v1').find_one_and_replace({'_id': program_id}, program, upsert=True)

    for v1_field, mapping in fields_map.items():
        # get the value from the program
        value = get_descendant_key(program, v1_field, None)
        default_value = mapping.get('default')
        key = mapping.get('key', v1_field)

        if isEmpty(value) and default_value is not None:
            set_descendant_key(default_value, program, key)
        elif value is not None:
            # Transform the value (migration, cast to another value, etc)
            transformations = mapping.get('transform', [])
            helper_key = mapping.get('helperKey')
            helper_value = get_descendant_key(program, helper_key, None) if helper_key else ''

            for transformation in transformations:
                value = transformation(value, helper_value)

            if mapping.get('type') == 'append' and value:
                append_to_descendant_key(value, program, key)
            else:
                set_descendant_key(value, program, key)

    # the following fields get default_values
    set_descendant_key(['N/A'], program, 'evidenceDescription')

    # normalize using the db schema
    program = v.normalized(program, schema_program_v2)
    remove_empty(program)

    if v.errors:
        print(f'Unable to migrate program with id {program_id}')
        continue

    # set a few more things
    program['isValid'] = v.validate(program, schema_program_v2)
    program['version'] = 2
    program['ignoreThreshold'] = True
    program['lastUpdated'] = datetime.utcnow()

    try:
        nonprofit_id = ObjectId(program['nonprofit'])
        program['nonprofit'] = create_ref(nonprofit_id)
        program['isValidNonprofit'] = get_is_valid_nonprofit([nonprofit_id])
    except KeyError:
        pass  # ignore

    db().coll_programs.find_one_and_replace({'_id': program_id}, replacement=program)
