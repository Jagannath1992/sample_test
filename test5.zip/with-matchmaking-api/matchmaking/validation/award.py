def validate_award(award):
    valid = True
    errors = []

    # validate required fields
    required = ['name']
    for key in required:
        if key not in award:
            valid = False
            errors.append(key + ' is required')


    # set default value for optional fields
    optional = {
        'url': '' ,
        'description': '',
        'active': True
    }
    for key in optional:
        if key not in award:
            award[key] = optional.get(key)

    # remove redundant fields
    redundant_keys = []
    for key in award.keys():
        if key not in required and key not in optional:
            redundant_keys.append(key)

    for key in redundant_keys:
        award.pop(key)

    return valid, errors


