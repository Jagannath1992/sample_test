from datetime import datetime
from typing import Any, Dict, List, Tuple

from bson.objectid import ObjectId

from matchmaking.dao import utils
from matchmaking.controllers.matchmaking.brands import utils as brand_utils
from matchmaking.mongodb import db, get_vocabulary_label_v2
from matchmaking.utils import generate_random_slug, generate_secure_password, project_dict


def add_report(report: Dict, return_fields: set = {}) -> Dict:
    report['slug'] = generate_random_slug()
    report['password'] = generate_secure_password()

    if 'name' not in report:
        company = utils.get_document_by_id('mm_brands', report['brandId'], projection={
            'name': True, 'nameLabel': True
        })

        month_year = datetime.utcnow().strftime('%B %Y')
        report['name'] = f'{brand_utils.get_display_name(company)} Supplier Analysis {month_year}'

    return set_report_details(utils.add_document('supplier_analysis_reports', report), return_fields)


def get_report(_filter: Dict, return_fields: set = {}) -> Dict:
    return set_report_details(utils.get_document('supplier_analysis_reports', _filter), return_fields)


def list_reports(return_fields: set = {}) -> List[Dict]:
    def _parse(report):
        parsed_report = set_report_details(report, return_fields)

        if 'suppliers' in parsed_report:
            parsed_report['suppliers'] = len(parsed_report['suppliers'])

        return parsed_report

    projection = {'suppliers': True, 'brandId': True, 'name': True}
    reports = map(_parse, utils.list_documents('supplier_analysis_reports', projection))
    return list(reports)


def update_report(_filter: Dict, report: Dict, return_fields: set = {}) -> Dict:
    return set_report_details(utils.update_document('supplier_analysis_reports', _filter, report), return_fields)


def delete_report(_id: ObjectId) -> None:
    return utils.hard_delete_document_by_id('supplier_analysis_reports', _id)


def set_report_details(report: Dict, return_fields: set = {}) -> Dict:
    brand = utils.get_document_by_id('mm_brands', report['brandId'], projection={'name': True, 'nameLabel': True})
    report['brandName'] = brand_utils.get_display_name(brand)

    report['status'] = 'IN_PROGRESS'

    if report.get('suppliers'):
        suppliers = utils.get_documents('mm_brands', {'_id': {'$in': report['suppliers']}}, projection={
            'nameLabel': True, 'name': True, 'source': True, 'verifiedByAdmin': True
        })
        report['suppliers'] = [
            {
                '_id': brand['_id'],
                'name': brand_utils.get_display_name(brand),
                'inProgress': not brand_utils.is_brand_verified_by_admin(brand),
            }
            for brand in suppliers
        ]

        report['suppliersNotAnalyzed'] = sum(
            1 for supplier in suppliers if not brand_utils.is_brand_verified_by_admin(supplier)
        )
        if report['suppliersNotAnalyzed'] == 0:
            report['status'] = 'COMPLETE'

    if return_fields:
        report = project_dict(report, return_fields)

    return report


def add_report_analysis(report: Dict, return_fields: set = {}) -> Dict:
    if report.get('suppliers'):
        supplier_ids = [supplier['_id'] for supplier in report['suppliers']]
        topic_labels, supplier_analysis = get_supplier_analysis_for_brand(report['brandId'], supplier_ids)

        report['topics'] = topic_labels

        for supplier in report['suppliers']:
            supplier_id = str(supplier['_id'])
            supplier.update(supplier_analysis[supplier_id])

        report['suppliers'] = sorted(report['suppliers'], key=lambda a: a['matchProportion'], reverse=True)

    if return_fields:
        report = project_dict(report, return_fields)

    return report


def get_supplier_analysis_for_brand(brand_id: ObjectId, supplier_ids: List[ObjectId]) -> Tuple[List, Dict]:
    brand = utils.get_document_by_id('mm_brands', brand_id, projection={'topics': True})
    brand_topic_labels = [get_vocabulary_label_v2(topic_dict['topic']) for topic_dict in brand.get('topics', [])]
    brand_topic_scores = calculate_topic_alignment_scores(brand.get('topics', []))
    total_brand_score = sum(brand_topic_scores.values())

    supplier_analysis = {}
    suppliers = get_brands_with_industry_topics_aggregated(supplier_ids)
    for supplier in suppliers:
        supplier_topic_scores = remove_zero_topics(calculate_topic_alignment_scores(supplier.get('topics', [])))
        normalized_supplier_topic_points = transfer_topic_scores(brand_topic_scores, supplier_topic_scores)
        total_supplier_score = sum(normalized_supplier_topic_points.values())
        match_proportion = (total_supplier_score / total_brand_score) if total_brand_score else 0

        supplier_analysis[str(supplier['_id'])] = {
            'matchProportion': round(match_proportion, 2),
            'topics': {
                get_vocabulary_label_v2(ObjectId(key)): score
                for key, score in supplier_topic_scores.items()
            }, # contains topics with non-zero scores only
            'industry': supplier.get('industry', '')
        }

    return brand_topic_labels, supplier_analysis


def get_brands_with_industry_topics_aggregated(brand_ids: List[ObjectId]) -> List[Dict[str, Any]]:
    """Returns documents of provided brand_ids.
    Topics fallback to the brand's industry topics if no topics are available yet for the brand
    """
    pipeline = [
        {
            '$match': {'_id': {'$in': brand_ids}}
        },
        {
            '$lookup': {
                'from': 'topics_per_industry',
                'localField': 'industry',
                'foreignField': 'industry_name',
                'as': 'industryTopics'
            }
        },
        {
            '$project': {
                'topics': {'$ifNull': ['$topics', {'$arrayElemAt': ['$industryTopics.topics', 0]}]},
                'source': True, 'verifiedByAdmin': True, 'industry': True,
            }
        }
    ]

    return list(db().coll_brands.aggregate(pipeline))


def transfer_topic_scores(topics_a: Dict[str, int], topics_b: Dict[str, int]) -> Dict[str, float]:
    """Assigns topic scores from topics in topics_a to topics in topics_b"""
    def _get_points(key):
        if not topics_a.get(key, 0):
            return 0

        fraction_of_points = min(1, (topics_b[key] / topics_a[key]))
        return fraction_of_points * topics_a[key]

    return {key: _get_points(key) for key in topics_b}


def remove_zero_topics(topics: Dict[str, int]) -> Dict[str, int]:
    """Filters topics to remove keys with 0 values"""
    return {key: value for key, value in topics.items() if value > 0}


def calculate_topic_alignment_scores(topics: Dict[str, Any]) -> Dict[str, int]:
    """Assign each topic in topics an alignment score  between 0 - 3"""
    total = sum(topic['score'] for topic in topics)

    return {
        str(topic['topic']): (convert_topic_fraction_to_score(topic['score'] / total) if total else 0)
        for topic in topics
    }


def convert_topic_fraction_to_score(topic_fraction: float) -> int:
    """Convert a topic_fraction value (in range [0, 1]) to a score in range [0, 3]"""
    if topic_fraction > 0.15:
        return 3

    if topic_fraction > 0.1:
        return 2

    if topic_fraction > 0.05:
        return 1

    return 0
