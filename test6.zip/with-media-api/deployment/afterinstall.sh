cd /home/ec2-user

rm -rf dist
mkdir dist
cp logging.json dist
cp flask_app.py dist
cp requirements.txt dist
cp -r keys dist
cp -r app dist
cp -r config dist
cd dist
chown -R ec2-user /home/ec2-user/.local/lib/python3.7/site-packages
chown -R ec2-user /usr/local/lib/python3.7/site-packages/
export PATH=$PATH:/home/ec2-user/.local/bin
su ec2-user -c 'pip3 install -r requirements.txt --user --no-cache-dir'

rm -f /home/ec2-user/.envs

cd /home/ec2-user
chown ec2-user deployment

cd /home/ec2-user/deployment
source /home/ec2-user/.bashrc
chown ec2-user ./environment_variables.sh
chmod 755 ./environment_variables.sh
./environment_variables.sh > /tmp/environ_debug
