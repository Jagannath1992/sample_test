import math

from flask import jsonify, request, send_file
from bson import objectid
from datetime import timezone
from tempfile import TemporaryFile

from .dash_utils import *

from matchmaking.utils import generate_secure_password, generate_random_slug
from matchmaking.controllers import dash_bp
from matchmaking.dao.utils import add_document, get_document, get_documents, get_document_by_id, update_document_by_id
from matchmaking.permission_decorator import require_client_permission
from matchmaking.validation.event import validate_create_event_request, validate_pilot_deal_progress
from matchmaking.validation.utils import validate_object_id
from matchmaking.utils import replace_object_ids, GivewithError, ValidationError, UnsupportedPayload
from matchmaking.s3 import download_file
from matchmaking.util.forex import convert_to_usd, convert_currency
from matchmaking.mongodb import translate_to_topic, get_forex_rates, get_program, get_nonprofit
from matchmaking.models.models import v, actualization_schema, Currency
from matchmaking.controllers.dashboard.pilot_reporting import organize_funding_items_by_quarter

"""
@api {post} /dashboard/event Create Event
@apiName Create Event
@apiGroup Event
@apiDescription Create a new event

@apiParamExample {json} Create event example:
{
    "name": "event name",
    'customer': '5c1415685b03bb0008c21adf',
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
}

@apiSuccessExample {json} Success created event example:
{
    "name": "event name",
    'customer': '5c1415685b03bb0008c21adf',
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z'
}
"""
@dash_bp.route('/event', methods=['POST'])
@require_client_permission
def create_event():
    payload = request.get_json()
    valid, errors = validate_create_event_request(payload)
    if not valid:
        return jsonify(errors), 400

    payload = replace_object_ids(payload)
    event = {
        'name': payload['name'],
        'customer': request.user['orgId'],
        'category': payload.get('category', ''),
        'type': payload.get('type', ''),
        'customFields': payload.get('customFields', {}),
        'totalContractValue': float(payload.get('totalContractValue') or 0),
        'currency': payload.get('currency', ''),
        'deleted': False,
        'status': 'OPEN',
    }

    event = add_document('event', event)
    return jsonify(join_event(event))


"""
@api {get} /dashboard/event/brand/:brandId List Events By Brand ID
@apiName List Events
@apiGroup Event
@apiDescription Return list of events that belong to the requesting user's company

@apiParamExample {json} Create event example:
{}

@apiSuccessExample {json} Success created event example:
[
    {
        "name": "event name 1",
        "category": "event category",
        "type": "event type",
        "tcv": "event tct",
        'customer': '5c1415685b03bb0008c21adf',
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z'
    },
    {
        "name": "event name 2",
        "category": "event category",
        "type": "event type",
        "tcv": "event tct",
        'customer': '5c1415685b03bb0008c21adf',
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z'
    }
}
"""
@dash_bp.route('/event/brand/<brand_id>', methods=['GET'])
@require_client_permission
def list_event_by_brand(brand_id):
    if not objectid.ObjectId.is_valid(brand_id):
        return 'invalid brand id', 400

    events = get_documents('event', {'customer': objectid.ObjectId(brand_id), 'deleted': False})
    for event in events:
        if not event['deleted']:
            join_event(event)

    return jsonify(events)


"""
@api {put} /dashboard/event/:event_id Update Event
@apiName Update Event
@apiGroup Event
@apiDescription Update an event by ID

@apiParamExample {json} Update event example:
{
    "name": "event name",
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
}

@apiSuccessExample {json} Success created event example:
{
    "name": "event name",
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
    'customer': '5c1415685b03bb0008c21adf',
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z'
}
"""
@dash_bp.route('/event/<event_id>', methods=['PUT'])
@require_client_permission
def update_event(event_id):
    if not objectid.ObjectId.is_valid(event_id):
        return 'invalid event id', 400

    event = get_document_by_id('event', event_id)
    if event is None or event['deleted']:
        return 'event not found', 404

    update_request = request.get_json()
    update_request = replace_object_ids(update_request)

    event = {
        'name': update_request['name'],
        'customer': request.user['orgId'],
        'category': update_request.get('category', ''),
        'type': update_request.get('type', ''),
        'totalContractValue': float(update_request.get('totalContractValue') or 0),
        'customFields': update_request.get('customFields', {}),
        'currency': update_request.get('currency', ''),
    }

    updated_event = update_document_by_id('event', event_id, event, blacklist=['customer'])
    return jsonify(join_event(updated_event))


"""
@api {get} /dashboard/event/:event_id Get Event
@apiName Get Event
@apiGroup Event
@apiDescription Get an event by ID

@apiSuccessExample {json} Success created event example:
{
    "name": "event name",
    "category": "event category",
    "type": "event type",
    "tcv": "event tct",
    'customer': '5c1415685b03bb0008c21adf',
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z'
}
"""
@dash_bp.route('/event/<event_id>', methods=['GET'])
@require_client_permission
def get_event(event_id):
    if not objectid.ObjectId.is_valid(event_id):
        return 'invalid event id', 400

    event = get_document_by_id('event', event_id)
    if event is None or event['deleted']:
        return 'event not found', 404

    return jsonify(join_event(event))


"""
@api {put} /dashboard/event/:event_id DELETE Event
@apiName DELETE Event
@apiGroup Event
@apiDescription DELETE an event by ID
"""
@dash_bp.route('/event/<event_id>', methods=['DELETE'])
@require_client_permission
def delete_event(event_id):
    if not objectid.ObjectId.is_valid(event_id):
        return 400, 'invalid event id'

    event = get_document_by_id('event', event_id)
    if event is None:
        return 404, 'event not found'

    event['deleted'] = True
    update_document_by_id('event', event_id, event)

    return jsonify(success=True)


"""
@api {post} /dashboard/event/:event_id/deal Add deal to event
@apiName Add Deal
@apiGroup Event
@apiDescription Add deal to an event

@apiParamExample {json} Add deal example:
{
    'type': 'pilot-procurement',
    'customer': '5c1415685b03bb0008c21adf',
    'customerUser': '5c129041228ea85cfd418dec',
    'estimatedContractValue': 0,
    'allocation': 0,
    'portion': 1000,
    'feePercentage': 15,
    'fundingAmount': 1000,
    'supplierName': 'supplier name',
    'contact': 'contact@customer.com',
    'fundingStatus': 'string field',
    'invoicingTerms': 'string field',
    'totalInvoicingAmount': 200,
    'selectedProgram': [{
        'programId': '5c129041228ea85cfd418auf',
        'funding': 1000,
        'fundingPeriod': 'string field',
        'progress': 20
    }]
}

@apiSuccessExample {json} Success added deal example:
{
    'type': 'pilot-procurement',
    'customer': '5c1415685b03bb0008c21adf',
    'customerUser': '5c129041228ea85cfd418dec',
    'estimatedContractValue': 0,
    'allocation': 0,
    'portion': 1000,
    'feePercentage': 15,
    'fundingAmount': 1000,
    'supplierName': 'supplier name',
    'contact': 'contact@customer.com',
    'fundingStatus': 'string field',
    'invoicingTerms': 'string field',
    'totalInvoicingAmount': 200,
    'selectedProgram': [{
        'programId': '5c129041228ea85cfd418auf',
        'funding': 1000,
        'fundingPeriod': 'string field',
        'progress': 20
    }]
}
"""
@dash_bp.route('/event/<event_id>/deal', methods=['POST'])
@require_client_permission
def add_deal_to_event(event_id):
    payload = request.get_json()
    payload = replace_object_ids(payload)

    deal = {
        'eventId': objectid.ObjectId(event_id),
        'status': 'OPEN',
        'supplier': payload['supplier'],
        'supplierEmail': payload.get('supplierEmail'),
        'accountsPayableEmail': payload.get('accountsPayableEmail'),
        'totalBudget': float(payload.get('totalBudget') or 0),
        'givePercent': float(payload.get('givePercent') or 0),
        'currency': payload.get('currency'),
        'paymentOption': payload.get('paymentOption'),
        'givewithPortion': float(payload.get('givewithPortion') or 0),
        'invoicingTerms': payload.get('invoicingTerms'),
        'customFields': payload.get('customFields', {}),
        'password': generate_secure_password(),
        'slug': generate_random_slug(),
        'selectedPrograms': [],
        'deleted': False,
        'invoiceOption': payload.get('invoiceOption')
    }

    # selectedPrograms will be sent as a list of ObjectIds strings, convert to the same schema used in dashboard.
    selected_program_ids = payload.get('selectedPrograms', [])
    for pid in selected_program_ids:
        deal['selectedPrograms'].append({
            'programId': pid,
            'fundingAmount': 0,
            'fundingPeriod': '',
            'fundingAmountGiven': 0,
        })

    deal = calc_funding_amount(deal)
    deal = add_document('pilot_deal', deal)

    join_deal(deal)
    return jsonify(deal)


"""
@api {post} /dashboard/pilot_deal/:pilot_deal_id Delete Pilot Deal
@apiName Delete Pilot Deal
@apiGroup PilotDeal
@apiDescription Soft delete a pilot deal
"""
@dash_bp.route('/pilot_deal/<pilot_deal_id>', methods=['DELETE'])
@require_client_permission
def delete_pilot_deal(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    deal['deleted'] = True
    update_document_by_id('pilot_deal', pilot_deal_id, deal)

    return jsonify(success=True)

"""
@api {put} admin/pilot_deal/status/:pilot_deal_id Update pilot deal status
@apiName Update Deal Status
@apiGroup Pilot Deal
@apiDescription Update deal status by id. Update parent event status to FUNDING_IN_PROGRESS, if all deals status
under parent event are FUNDING_IN_PROGRESS. Update parent event status to COMPLETE, if all deals status are COMPLETE.

@apiParamExample {json} Add deal example:
{
    'status': 'FUNDING_IN_PROGRESS'
}
"""
@dash_bp.route('/pilot_deal/status/<pilot_deal_id>', methods=['PUT'])
@require_client_permission
def update_deal_status(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid pilot deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    payload = request.get_json()

    # validate status
    if payload['status'] not in ['COMPLETE', 'FUNDING_IN_PROGRESS']:
        return 'Invalid status', 400

    # validate deal.config
    valid, details = validate_pilot_deal_progress(deal)
    if not valid:
        return jsonify(details), 400

    # update deal status
    deal['status'] = payload['status']
    update_document_by_id('pilot_deal', pilot_deal_id, payload)

    # update deal status
    event_id = deal['eventId']
    event = get_document_by_id('event', event_id)
    sibling_deals = get_documents('pilot_deal', {'eventId': event_id})

    is_funding_in_progress = True
    is_complete = True

    for d in sibling_deals:
        if d['status'] != 'FUNDING_IN_PROGRESS':
            is_funding_in_progress = False
        if d['status'] != 'COMPLETE':
            is_complete = False

    if is_funding_in_progress:
        event['status'] = 'FUNDING_IN_PROGRESS'
        update_document_by_id('event', event_id, event)

    if is_complete:
        event['status'] = 'COMPLETE'
        update_document_by_id('event', event_id, event)

    join_deal(deal)
    return jsonify(deal)

"""
@api {post} /dashboard/pilot_deal Update Pilot Deal
@apiName Delete Pilot Deal
@apiGroup PilotDeal
@apiDescription Update a pilot deal by id
"""
@dash_bp.route('/pilot_deal/<pilot_deal_id>', methods=['PUT'])
@require_client_permission
def update_pilot_deal(pilot_deal_id):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    update_request = request.get_json()
    update_request = replace_object_ids(update_request)

    updated_deal = {
        'eventId': deal['eventId'],
        'supplierEmail': update_request.get('supplierEmail'),
        'accountsPayableEmail': update_request.get('accountsPayableEmail'),
        'totalBudget': float(update_request.get('totalBudget') or 0),
        'givePercent': float(update_request.get('givePercent') or 0),
        'currency': update_request.get('currency'),
        'paymentOption': update_request.get('paymentOption'),
        'givewithPortion': float(update_request.get('givewithPortion') or 0),
        'invoicingTerms': update_request.get('invoicingTerms'),
        'customFields': update_request.get('customFields', {}),
        'selectedPrograms': [],
        'deleted': False,
        'invoiceOption': update_request.get('invoiceOption')
    }

    new_program_flag = False
    existing_programs = {}
    for program in deal['selectedPrograms']:
        existing_programs[program.get('programId')] = program

    selected_program_ids = update_request.get('selectedPrograms', [])
    for selected_program_id in selected_program_ids:
        if selected_program_id in existing_programs:
            updated_deal['selectedPrograms'].append(existing_programs.get(selected_program_id))
        else:
            updated_deal['selectedPrograms'].append({
                'programId': selected_program_id,
                'fundingAmount': 0,
                'fundingPeriod': '',
                'fundingAmountGiven': 0,
            })
            new_program_flag = True

    if deal.get('totalBudget', 0) != updated_deal.get('totalBudget', 0) \
        or len(deal.get('selectedPrograms', [])) != len(updated_deal.get('selectedPrograms', [])) \
        or deal.get('givePercent', 0) != updated_deal.get('givePercent', 0) or new_program_flag:
        updated_deal = calc_funding_amount(updated_deal)

    updated_deal = update_document_by_id('pilot_deal', pilot_deal_id, updated_deal)

    join_deal(updated_deal)
    return jsonify(updated_deal)

"""
@api {get} admin/pilot_deal/:pilot_deal_id/deliverable/:key Download Deliverables
@apiName Download Deliverables
@apiGroup Pilot Deal
@apiDescription Download Deliverables
"""
@dash_bp.route('/pilot_deal/<pilot_deal_id>/program/<program_id>/deliverable/<key>', methods=['GET'])
@require_client_permission
def download_deliverables(pilot_deal_id, program_id, key):
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'deal not found', 404

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    return download_pilot_deliverable(deal, program_id, key)


"""
download deliverable
"""
def download_pilot_deliverable(deal, program_id, deliverable_key):
    selected_programs = deal.get('selectedPrograms', [])

    file = TemporaryFile()
    for program in selected_programs:
        if program['programId'] == objectid.ObjectId(program_id):
            deliverables = program.get('deliverables', [])
            for d in deliverables:
                if d['key'] == deliverable_key:
                    url = d['url']
                    download_file(url, file, is_public=False)

                    filename = url.rsplit('/', 1)[-1]
                    response = send_file(file, as_attachment=True, attachment_filename=filename, cache_timeout=0)
                    return response

    return 'key not found', 400


"""
join event and pilot deals associated to it by event ID.
"""
def join_event_by_id(event_id):
    event = get_document_by_id('event', event_id)
    return join_event(event)

"""
join event and pilot deals associated to it.
"""
def join_event(event):
    # add supplier name
    customer_id = event['customer']
    brand = get_document_by_id('mm_brands', customer_id)
    owner = get_document_by_id('user', event['createdBy'], projection=['name'])

    event['owner'] = owner['name'] if owner else ''

    event['customer_name'] = brand['name']
    event['customer_iname'] = brand['iname']

    # join deals
    event['deals'] = []
    deals = get_documents('pilot_deal', {'eventId': event['_id']})

    for deal in deals:
        if deal['deleted']:
            continue

        join_deal(deal)
        for p in deal.get('selectedPrograms', []):
            program = get_document_by_id(
                'mm_programs', p['programId'],
                projection=['name', 'slug', 'nonprofit', 'themes', 'outputs', 'outcomes']
            )

            p['name'] = program['name']
            p['slug'] = program['slug']

            nonprofit = get_document_by_id('mm_nonprofits', program['nonprofit'])
            p['nonprofit_name'] = nonprofit['name']

            theme_ids = program.pop('themes', {}).get('data', [])
            p['topics'] = list({translate_to_topic(theme_id) for theme_id in theme_ids})

            # set impacts
            transform_outputs_to_commerce_outputs_v2(program, (p.get('fundingAmount') or 0), deal.get('currency'))
            p['outputs'] = program['outputs']
            p['outcomes'] = program.get('outcomes', [])

        event['deals'].append(deal)

    return event


'''
add extra deal fields
'''
def join_deal(deal):
    deal_customer_id = deal['supplier']
    brand = get_document_by_id('mm_brands', deal_customer_id)
    deal['supplier_name'] = brand['name']
    deal['supplier_iname'] = brand['iname']

    valid, progress = validate_pilot_deal_progress(deal)
    deal['progress'] = progress

    if deal.get('paymentOption') == 'payAsYouGo':
        deal['givewithPortion'] = deal.get('totalBudget', 0) * (deal.get('givePercent', 0) / 100)


"""
calc pilot deal funding amount
"""
def calc_funding_amount(deal):
    if deal['paymentOption'] == 'payAsYouGo':
        give_portion = deal.get('totalBudget') * deal.get('givePercent') / 100
    else:
        give_portion = deal.get('givewithPortion')
    DEFAULT_FEE_PERCENT = 15
    event_id = deal['eventId']
    event = get_document_by_id('event', event_id)
    customer_id = event['customer']

    customer = get_document_by_id('mm_brands', customer_id)
    give_fee_percent = deal.get('givewithFeePercentage') or customer.get('givewithFeePercentage') or DEFAULT_FEE_PERCENT
    total_funding_amount = give_portion * ((100 - give_fee_percent) / 100)

    program_count = len(deal.get('selectedPrograms', []))
    for program in deal.get('selectedPrograms', []):
        program['fundingAmount'] = total_funding_amount / program_count

    return deal

def transform_outputs_to_commerce_outputs_v2(program, funding_amount, funding_currency):
    """ Calculate output values from output quantity, budget and proposal funding amount
        Each output_cost = program_budget / quantity, and hence output value = funding_amount / output_cost if
        the output scaleType is proportional
        Also, append outcomes to outputs to easy rendering by front-end
        NOTE: This function has side-effects (transforms outputs and removes outcomes)
    """
    outputs = program.get('outputs', [])
    for output in outputs:
        scale_type = get_document_by_id('mm_vocabulary', output.get('scaleType'))
        if scale_type:
            output['scaleType'] = scale_type.get('label', '')

    budget = program.get('budget')
    program_currency = program.get('currency') or 'USD'

    # if currencies aren't equal, convert as needed
    if (program_currency != funding_currency) and (funding_currency is not None):
        funding_amount = convert_to_usd(funding_amount, funding_currency)
        budget = convert_to_usd(budget, program_currency)

    if budget:
        for output in outputs:
            quantity = output.get('quantity', 0)
            if quantity and output.get('scaleType').lower() == 'proportional' and funding_amount:
                output_cost = budget / quantity
                output['value'] = math.floor(float(funding_amount) / output_cost)
            else:
                output['value'] = quantity


@dash_bp.route('/event/reporting', methods=['GET'])
@require_client_permission
def get_event_reporting():
    user = request.user
    org_id = user.get('orgId', '')

    events = get_documents('event', {'customer': objectid.ObjectId(org_id), 'deleted': False}, projection={'_id': True})

    all_deals = []
    for event in events:
        deals = get_documents('pilot_deal', {'deleted': False, 'eventId': event['_id']})
        # need to get deals that are NOT deleted
        all_deals.extend(deals)

    user_currency = get_document_by_id('mm_brands', org_id, projection={
        'givePercentageCurrency': True, '_id': False
    }).get('givePercentageCurrency', str(Currency.USD))

    return jsonify(get_reporting_data(all_deals, user_currency))

def get_reporting_data(deals, user_currency):
    social_impact = 0
    funding_generated = 0
    clients = []
    programs = []
    topics = set()

    currency_rates = get_forex_rates()

    for deal in deals:
        current_deal_funding_amount = 0
        deal_currency = deal.get('currency') or str(Currency.USD)
        social_impact += convert_currency(
            amount=float(deal.get('totalBudget') or 0),
            _from=deal_currency,
            _to=user_currency,
            rates=currency_rates
        )

        parent_event = get_document('event', {'_id': deal.get('eventId')}, projection=['status', 'category', 'type'])

        deal['category'] = parent_event.get('category')
        deal['type'] = parent_event.get('type')
        deal['parentStatus'] = parent_event.get('status', 'OPEN')

        if deal.get('supplier') not in clients:
            clients.append(deal.get('supplier'))

        # Add Actualizations amount if FIP
        if deal.get('status') in ['FUNDING_IN_PROGRESS']:
            if 'actualizations' in deal:
                totalActualizations = 0
                for actualization in deal['actualizations']:
                    totalActualizations += convert_currency(
                        amount=float(actualization.get('spend') or 0),
                        _from=deal_currency,
                        _to=user_currency,
                        rates=currency_rates
                    )
                    # Defines the amount needed to add to total funding generated
                    actualization['currentFundingAmount'] = float(actualization.get('spend') or 0)
                    # Used on FE to select the actualization for Reporting
                    actualization['status'] = 'ACTUALIZATION_SPEND'

                funding_generated += totalActualizations

        if deal.get('status') in ['COMPLETE', 'FUNDING_IN_PROGRESS']:
            selected_programs = deal.get('selectedPrograms', [])

            for p in selected_programs:
                # Add total funding amount if completed
                if (deal.get('status') in ['COMPLETE']):
                    currentFunding = convert_currency(
                        amount=float(p.get('fundingAmount') or 0),
                        _from=deal_currency,
                        _to=user_currency,
                        rates=currency_rates
                    )
                    funding_generated += currentFunding
                    current_deal_funding_amount += currentFunding
                
                # Add how much has been funded so far if funding is in progress
                if (deal.get('status') in ['FUNDING_IN_PROGRESS']):
                    currentFunding = convert_currency(
                        amount=float(p.get('fundingAmountGiven') or 0),
                        _from=deal_currency,
                        _to=user_currency,
                        rates=currency_rates
                    )
                    funding_generated += currentFunding
                    current_deal_funding_amount += currentFunding

                program_document = get_program(p.get('programId'), projection=['imageLandscape', 'imagePortrait', 'name', 'nonprofit', 'themes'])

                program_topics = list({translate_to_topic(_id=_id) for _id in program_document.get('themes', {}).get('data', [])})
                topics.update(program_topics)

                # Only add program in program reporting list if deal is complete or in progress
                if (deal.get('status') in ['COMPLETE', 'FUNDING_IN_PROGRESS']):
                    nonprofit_document = get_nonprofit(program_document['nonprofit'], projection=['name'])

                    program = {
                        **program_document,
                        'nonprofit': nonprofit_document,
                        'fundingAmount': convert_currency(
                            amount=float(p.get('fundingAmount') or 0),
                            _from=deal_currency,
                            _to=user_currency,
                            rates=currency_rates
                        ),
                        'year': deal.get('lastUpdated').year
                    }
                    programs.append(program)

        deal['currentFundingAmount'] = current_deal_funding_amount
    
    organized_funding_items = organize_funding_items_by_quarter(deals, 'createdAt')

    return {
        'quarterlyFundingItems': organized_funding_items,
        'proposals': deals,
        'numberOfProposals': len(deals),
        'socialImpact': social_impact,
        'fundingGenerated': funding_generated,
        'numberOfClients': len(clients),
        'programs': programs,
        'topics': list(topics),
    }


"""
@api {get} /dashboard/pilot_deal/:pilot_deal_id/actualization Get Actualizations
@apiName Get Actualizations
@apiGroup Pilot Deal

@apiSuccessExample {json} Success added actualization example:
{
    "actualizations": [
        "spend": "123",
        "currency": "$",
        "date": {
            "startDate": "2021-03-17T00:00:00Z",
            "endDate": "2021-03-20T00:00:00Z"
        },
    ],
}
"""
@dash_bp.route('/pilot_deal/<pilot_deal_id>/actualizations', methods=['GET'])
@require_client_permission
def get_actualizations(pilot_deal_id):
    pilot_deal_id = objectid.ObjectId(pilot_deal_id)
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    actualizations = deal.get('actualizations', [])

    return jsonify(actualizations)


"""
@api {post} /dashboard/pilot_deal/:pilot_deal_id/actualization Add Pilot Deal Actualization
@apiName Add Actualization
@apiGroup Pilot Deal

@apiSuccessExample {json} Success added actualization example:
{
    'type': 'pilot-procurement',
    'customer': '5c1415685b03bb0008c21adf',
    'customerUser': '5c129041228ea85cfd418dec',
    'estimatedContractValue': 0,
    'allocation': 0,
    'portion': 1000,
    'feePercentage': 15,
    'fundingAmount': 1000,
    'supplierName': 'supplier name',
    'contact': 'contact@customer.com',
    'fundingStatus': 'string field',
    'invoicingTerms': 'string field',
    'totalInvoicingAmount': 200,
    'selectedProgram': [{
        'programId': '5c129041228ea85cfd418auf',
        'funding': 1000,
        'fundingPeriod': 'string field',
        'progress': 20
    }]
    'actualizations': [
        'spend': '123',
        'currency': '$',
        'date': {
            'startDate': '2021-03-17T00:00:00Z',
            'endDate': '2021-03-20T00:00:00Z'
        },
    ],
}
"""
@dash_bp.route('/pilot_deal/<pilot_deal_id>/actualization', methods=['POST'])
@require_client_permission
def add_actualization_to_deal(pilot_deal_id):
    pilot_deal_id = objectid.ObjectId(pilot_deal_id)
    if not objectid.ObjectId.is_valid(pilot_deal_id):
        return 'invalid deal id', 400

    deal = get_document_by_id('pilot_deal', pilot_deal_id)
    if deal is None or deal['deleted']:
        return 'deal not found', 404

    payload = request.get_json()
    if not payload:
        raise UnsupportedPayload()

    new_actualization = payload.get('actualization')

    # Manually check because validation below is the entire array
    if not new_actualization:
        raise GivewithError('actualization is a required field')

    actualizations = deal.setdefault('actualizations', [])

    prev_actualization = actualizations[-1] if actualizations else {}  # Grab from end of the list before appending

    actualizations.append(new_actualization)
    actualizations = v.normalized({'actualizations': actualizations}, actualization_schema).get('actualizations')
    if v.errors:
        raise ValidationError(v.errors)

    new_actualization = actualizations[-1] if actualizations else {}  # Have to grab this again after normalization

    new_start_date = new_actualization['date']['startDate'].replace(tzinfo=timezone.utc)
    new_end_date = new_actualization['date']['endDate'].replace(tzinfo=timezone.utc)

    if new_start_date > new_end_date:
        raise GivewithError('startDate must be after the endDate of the most recent actualization')

    if prev_actualization:
        prev_end_date = prev_actualization['date']['endDate'].replace(tzinfo=timezone.utc)

        if  prev_end_date > new_start_date:
            raise GivewithError('startDate must be after the previous endDate')

    deal['actualizations'] = actualizations
    updated_deal = update_document_by_id('pilot_deal', pilot_deal_id, deal)

    join_deal(updated_deal)
    return jsonify(updated_deal)

@dash_bp.route('/outreach-material/<key>', methods=['GET'])
@require_client_permission
def download_outreach_material(key):
    """ Download Outreach Material
    """
    user = request.user
    user_brand_id = str(user.get('orgId', ''))

    brand = get_document_by_id('mm_brands', user_brand_id, projection=['outreachMaterials'])

    file = TemporaryFile()

    outreach_materials = brand.get('outreachMaterials', [])
    for material in outreach_materials:
        if material['key'] == key:
            url = material['url']

            # references object id of brand stored in path of file
            url_brand_id = url.split('/')[1]

            if user_brand_id != url_brand_id:
                return 'user does not have access to this file', 404

            download_file(url, file, is_public=False)

            attachment_filename = url.rsplit('/', 1)[-1]
            if material.get('fileName'):
                attachment_filename = material.get('fileName')

            response = send_file(file, as_attachment=True, attachment_filename=attachment_filename, cache_timeout=0)
            return response

    return 'key not found', 400
