from matchmaking.controllers.commerce.utils import is_program_funding_qualified


def test_is_program_funding_qualified():
    deal = {'fundingAmount': 1000, 'currency': 'USD'}
    program = {}
    # if program minimumFunding and currency are not defined
    assert is_program_funding_qualified(
        program.get('minimumFunding'), program.get('currency'), deal.get('fundingAmount'), deal.get('currency'))

    program['minimumFunding'] = 1000
    # if program currency is not defined
    assert is_program_funding_qualified(
        program.get('minimumFunding'), program.get('currency'), deal.get('fundingAmount'), deal.get('currency'))

    program['currency'] = 'USD'
    assert is_program_funding_qualified(
        program.get('minimumFunding'), program.get('currency'), deal.get('fundingAmount'), deal.get('currency'))

    program['currency'] = 'EUR'

    assert not is_program_funding_qualified(
        program.get('minimumFunding'), program.get('currency'), deal.get('fundingAmount'), deal.get('currency'))

    deal['currency'] = 'GBP'

    assert is_program_funding_qualified(
        program.get('minimumFunding'), program.get('currency'), deal.get('fundingAmount'), deal.get('currency'))
