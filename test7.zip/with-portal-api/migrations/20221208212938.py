import pymongo

"""
This scripts does the following:
1) Remove Procurement terms of use from Instance Settings 
2) Procurement terms of use to Procurement Accounts 
"""
name = '20221208212938'
dependencies = ['20220919193301']


def upgrade(db: pymongo.database.Database):
    instance_cursor = db['instance_settings'].find({'type': 'procurement'})
    for instance in instance_cursor:
        try:
            supplierTermsOfUseText = instance['settings']['procurement']['supplierTermsOfUseText']
            supplierTermsOfUseUrl = instance['settings']['procurement']['supplierTermsOfUseUrl']
        except:
            supplierTermsOfUseText = ''
            supplierTermsOfUseUrl = ''

        db['account'].update_many(
            {'instance._id': instance['_id'], 'type': 'procurement'},
            {'$set': {
                'procurement': {
                    'supplierTermsOfUseText': supplierTermsOfUseText,
                    'supplierTermsOfUseUrl': supplierTermsOfUseUrl
                },
            }})

        # add invitedBy to suppliers
        procurement_account = db['account'].find_one({'instance._id': instance['_id'], 'type': 'procurement'})
        db['account'].update_many(
            {'instance._id': instance['_id'], 'type': 'supplier'},
            {'$set': {
                'invitedBy': {
                    '_id': procurement_account['_id'],
                    '_type': 'account',
                    'name': procurement_account['company']['name']

                },
            }})

    # remove custom fields after giveFields set
    db['instance_settings'].update_many(
        {'type': 'procurement'},
        {'$unset': {
            'settings.procurement': {},
        }})


def downgrade(db: pymongo.database.Database):
    instance_cursor = db['instance_settings'].find({'type': 'procurement'})
    for instance in instance_cursor:
        account = db['account'].find_one({'instance._id': instance['_id'], 'type': 'procurement'})

        try:
            supplierTermsOfUseText = account['procurement']['supplierTermsOfUseText']
            supplierTermsOfUseUrl = account['procurement']['supplierTermsOfUseUrl']

            db['instance_settings'].find_one_and_update(
                {'instance._id': instance['_id']},
                {'$set': {
                    'settings.procurement.supplierTermsOfUseText': supplierTermsOfUseText,
                    'settings.procurement.supplierTermsOfUseUrl': supplierTermsOfUseUrl
                }})
        except:
            pass

    db['account'].update_many(
        {'type': 'procurement'},
        {'$unset': {
            'procurement': {},
        }})

    db['account'].update_many(
        {'type': 'supplier'},
        {'$unset': {
            'invitedBy': {},
        }})
