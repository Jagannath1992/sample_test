from portal.features.account_approval.faker import AccountApprovalFaker
from portal.features.accounts.faker import AccountFaker
from portal.features.instances.faker import InstanceSettingsFaker
from portal.features.transactions.faker import TransactionFaker
from portal.features.users.faker import UserFaker
from portal.features.cause_areas.faker import CauseAreaFaker
from portal.features.orders.faker import OrderFaker
from portal.features.locales.faker import LocaleFaker
from portal.features.error_logs.faker import ErrorLogFaker


class Fakers:
    def __init__(self, faker, db):
        self.account = AccountFaker(faker, db, 'account')
        self.user = UserFaker(faker, db, 'user')
        self.cause_area = CauseAreaFaker(faker, db, 'cause_area')
        self.order = OrderFaker(faker, db, 'order')
        self.approval = AccountApprovalFaker(faker, db, 'account_approval')
        self.transaction = TransactionFaker(faker, db, 'transaction')
        self.instance_settings = InstanceSettingsFaker(faker, db, 'instance_settings')
        self.locale = LocaleFaker(faker, db, 'locale')
        self.error_log = ErrorLogFaker(faker, db, 'error_log')
