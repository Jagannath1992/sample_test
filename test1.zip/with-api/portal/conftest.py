import jwt
import pytest

from bson import ObjectId
from datetime import datetime, timedelta
from enum import Enum, unique

from portal import create_app
from portal.shared import dates
from portal.shared.database import get_db
from portal.shared.encoder import CustomJSONEncoder
from portal.shared.enums import AccountStatus, UserRole
from portal.shared.repositories import all_repositories
from portal.shared.services import all_services
from portal.testing.fakers import Fakers

TOKEN_PRIVATE_KEY = 'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl' \
    '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9'


@unique
class AuthHeaderUsername(str, Enum):
    GIVEWITH = 'givewith_user@example.com'


@pytest.fixture(autouse=True)
def app(monkeypatch, mocker, request):
    env = 'testing'
    if 'use_sandbox_environment' in request.keywords:
        env = 'sandbox'
    elif 'use_staging_environment' in request.keywords:
        env = 'staging'
    elif 'use_production_environment' in request.keywords:
        env = 'production'

    monkeypatch.setenv('FLASK_ENV', env)
    monkeypatch.setenv('TOKEN_PRIVATE_KEY', TOKEN_PRIVATE_KEY)

    mocker.patch('portal.shared.auth.requests._get_account', return_value={'status': AccountStatus.ACTIVE.value})

    app = create_app()

    yield app


@pytest.fixture()
def client(app):
    client = app.test_client()
    context = app.app_context()
    context.push()

    yield client

    context.pop()


@pytest.fixture()
def db():
    db = get_db()
    load_test_data(db)

    yield db

    db.client.drop_database('test_db')


def load_test_data(db):
    db.role.insert_many([{
        'name': 'givewith',
        'description': 'Givewith users / admins'
    }, {
        'name': 'acct_admin',
        'description': 'Can import accounts from Sage'
    }, {
        'name': 'data_admin',
        'description': 'Can manage reference data'
    }, {
        'name': 'org_admin',
        'description': 'Full Access to their account'
    }, {
        'name': 'user_admin',
        'description': 'Can invite/update users'
    }, {
        'name': 'finance',
        'description': 'Can credit account, approve orders'
    }, {
        'name': 'sales',
        'description': 'Can create orders'
    }, {
        'name': 'svc_acct',
        'description': 'Can create transactions, debit account'
    }])


@pytest.fixture()
def fakers(faker, db):
    yield Fakers(faker, db)


@pytest.fixture()
def repositories():
    yield all_repositories


@pytest.fixture()
def services():
    yield all_services


@pytest.fixture()
def test_user(frozen_utcnow):
    username = AuthHeaderUsername.GIVEWITH.value
    first_name = 'Givewith'
    last_name = 'User'
    return {
        '_id': ObjectId('123456789012345678901234'),  # <-- so we don't have to insert a user for auth
        'accountId': ObjectId('123456789012345678901234'),
        'username': username,
        'first_name': first_name,
        'last_name': last_name,
        'name': first_name + ' ' + last_name,
        'title': '',
        'orgId': '',
        'orgName': 'Acme Corp',
        'orgType': 'brand',
        'type': 'client',
        'departmentType': 'Portal',
        'industry': 'Make Things Industry',
        'businesssAddress': '',
        'companyWebsite': '',
        'phoneNumber': '',
        'active': True,
        'createdBy': username,
        'createdAt': frozen_utcnow,
        'lastUpdatedBy': username,
        'lastUpdated': frozen_utcnow,
    }


@pytest.fixture()
def custom_auth_header(request, test_user):
    test_user['roles'] = [request.param]
    return get_auth_header(test_user)


@pytest.fixture()
def givewith_header(test_user):
    test_user['roles'] = [UserRole.SUPER_ADMIN.value]
    return get_auth_header(test_user)


@pytest.fixture()
def org_admin_header(test_user):
    test_user['roles'] = [UserRole.ORG_ADMIN.value]
    return get_auth_header(test_user)


@pytest.fixture()
def user_admin_header(test_user):
    test_user['roles'] = [UserRole.USER_ADMIN.value]
    return get_auth_header(test_user)


@pytest.fixture()
def finance_header(test_user):
    test_user['roles'] = [UserRole.FINANCE.value]
    return get_auth_header(test_user)


def get_auth_header(user):
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': get_jwt(user)
    }


def get_jwt(user):
    now = datetime.now()
    hour_later = (now + timedelta(hours=1)).timestamp()
    claims = user.copy()
    claims.update({
        'auth_time': now.timestamp(),
        'exp': hour_later,
        'email': user['username'],
    })
    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256', json_encoder=CustomJSONEncoder)


def get_user_from_header(header):
    token = header['Authorization']
    return jwt.decode(token, TOKEN_PRIVATE_KEY, algorithms='HS256')


def get_account_id_from_header(header):
    user = get_user_from_header(header)
    return user['accountId']


@pytest.fixture()
def frozen_utcnow(mocker):
    now = dates.get_utcnow().replace(microsecond=0)
    mocker.patch.object(dates, 'get_utcnow', return_value=now)
    return now
