import pytest
from decimal import Decimal
from flask import request
from portal.features.transactions.schema import TransactionRequest, TransactionResponse, TransactionSearchRequest, TransactionSearchResponse
from portal.shared.enums import UserRole
from portal.shared.repositories import account_repository, instance_settings_repository, order_repository, transaction_repository, locale_repository
from portal.shared.services import email_service


class TestTransactionsResource:
    @pytest.fixture
    def post_init(self, fakers, mocker):
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        instance = fakers.instance_settings.generate_single()
        instance['settings']['locale']['_id'] = locale['_id']
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(account_repository(), 'exists', return_value=True)
        mocker.patch.object(order_repository(), 'exists', return_value=True)
        account = fakers.account.generate_single()
        account['instance']['_id'] = instance['_id']
        mocker.patch.object(account_repository(), 'get_single', return_value=account.copy())
        transaction = fakers.transaction.generate_single()
        mocker.patch.object(transaction_repository(), 'insert', return_value=transaction)
        mocker.patch.object(account_repository(), 'patch', return_value=account)
        mocker.patch.object(email_service(), 'send_balance_deposit_to_account_email')
        return (locale, instance, account, transaction)

    @pytest.fixture
    def post_request_json(self, post_init):
        _, _, _, transaction = post_init
        return TransactionRequest().dump(transaction)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN], indirect=True)
    def test_post_200_initial_transaction(self, client, custom_auth_header, post_init, post_request_json):
        # arrange
        locale, instance, account, transaction = post_init
        del account['initialBalance']
        account_repository().get_single.return_value = account

        with client:
            # act
            response = client.post('/transactions', json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single.assert_called_once_with(
                request.parsed_obj['account']['_id'],
                {'initialBalance': 1, 'currentBalance': 1, 'instance._id':1})
            transaction_repository().insert.assert_called_once_with({
                **request.parsed_obj,
                'startingBalance': 0.0,
                'endingBalance': request.parsed_obj['amount'],
                'currency': locale['settings']['currency']
            }, request.user['username'])
            account_repository().patch.assert_called_once_with(request.parsed_obj['account']['_id'], {
                **account,
                'initialBalance': request.parsed_obj['amount'],
                'currentBalance': request.parsed_obj['amount']
            })
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            email_service().send_balance_deposit_to_account_email.assert_called_once_with(instance, account)
            assert response.status_code == 200
            assert response.json == TransactionResponse().dump(transaction)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN], indirect=True)
    def test_post_200_subsequent_transaction(self, client, custom_auth_header, post_init, post_request_json):
        # arrange
        locale, instance, account, transaction = post_init

        with client:
            # act
            response = client.post('/transactions', json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single.assert_called_once_with(
                request.parsed_obj['account']['_id'],
                {'initialBalance': 1, 'currentBalance': 1, 'instance._id':1})
            transaction_repository().insert.assert_called_once_with({
                **request.parsed_obj,
                'startingBalance': account['currentBalance'],
                'endingBalance': account['currentBalance'] + request.parsed_obj['amount'],
                'currency': locale['settings']['currency']
            }, request.user['username'])
            account_repository().patch.assert_called_once_with(request.parsed_obj['account']['_id'], {
                **account,
                'currentBalance': account['currentBalance'] + request.parsed_obj['amount']
            })
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            email_service().send_balance_deposit_to_account_email.assert_called_once_with(instance, account)
            assert response.status_code == 200
            assert response.json == TransactionResponse().dump(transaction)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN], indirect=True)
    def test_post_200_amount_0(self, client, custom_auth_header, post_init, post_request_json):
        # arrange
        post_request_json['amount'] = 0
        locale, _, account, transaction = post_init

        with client:
            # act
            response = client.post('/transactions', json=post_request_json, headers=custom_auth_header)

            # assert
            account_repository().get_single.assert_called_once_with(
                request.parsed_obj['account']['_id'],
                {'initialBalance': 1, 'currentBalance': 1, 'instance._id':1})
            transaction_repository().insert.assert_called_once_with({
                **request.parsed_obj,
                'startingBalance': account['currentBalance'],
                'endingBalance': account['currentBalance'] + request.parsed_obj['amount'],
                'currency': locale['settings']['currency']
            }, request.user['username'])
            account_repository().patch.assert_called_once_with(request.parsed_obj['account']['_id'], {
                **account,
                'currentBalance': account['currentBalance'] + request.parsed_obj['amount']
            })
            #instance_settings_repository().get_single.assert_not_called()
            email_service().send_balance_deposit_to_account_email.assert_not_called()
            assert response.status_code == 200
            assert response.json == TransactionResponse().dump(transaction)

    @pytest.fixture
    def get_init(self, fakers, mocker):
        transactions = fakers.transaction.generate_many(3)
        get_validated_account_id_mock = mocker.patch(
            'portal.features.transactions.controller.get_validated_account_id',
            return_value=transactions[0]['account']['_id'])
        mocker.patch.object(transaction_repository(), 'get_page', return_value=(3, transactions))
        return (transactions, get_validated_account_id_mock)

    @pytest.fixture
    def get_query_string(self, get_init):
        transactions, _ = get_init
        return TransactionSearchRequest().dump({
            **transactions[0],
            'accountId': transactions[0]['account']['_id'],
            'offset': 0,
            'count': 10,
            'orderBy': 'createdAt'
        })

    @pytest.mark.parametrize(
        'custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE, UserRole.EXECUTIVE],
        indirect=True)
    def test_get_200(self, client, custom_auth_header, get_init, get_query_string):
        # arrange
        transactions, get_validated_account_id_mock = get_init

        with client:
            # act
            response = client.get('/transactions', query_string=get_query_string, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(request.parsed_query_params['account._id'], request)
            transaction_repository().get_page.assert_called_once_with(request.parsed_query_params)
            assert response.status_code == 200
            assert response.json == TransactionSearchResponse().dump({'totalCount': 3, 'results': transactions})

    @pytest.mark.parametrize(
        'custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.GW_FINANCE],
        indirect=True)
    def test_get_200(self, client, custom_auth_header):
        # arrange

        with client:
            # act
            response = client.get('/transactions/monthly-recon', headers=custom_auth_header)

            # assert

            assert response.status_code == 200
