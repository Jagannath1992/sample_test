# pylint: disable-msg=redefined-outer-name
import json
from unittest import mock
import pytest

from tests.__mocks__.test_data import mock_programs

@pytest.fixture()
def recommendations():
    mock_dict = {
        'recommendations': [
            {'position': 1, 'programID': str(mock_programs.programs[0]['_id']), 'ranking': 100.0, 'raw_score': 45.0763},
            {'position': 2, 'programID': str(mock_programs.programs[1]['_id']), 'ranking': 97.764, 'raw_score': 44.068},
            {'position': 3, 'programID': str(mock_programs.programs[2]['_id']), 'ranking': 84.676, 'raw_score': 38.169},
            {'position': 4, 'programID': str(mock_programs.programs[3]['_id']), 'ranking': 75.500, 'raw_score': 34.06},
            {'position': 5, 'programID': str(mock_programs.programs[4]['_id']), 'ranking': 71.194, 'raw_score': 32.089},
            {'position': 6, 'programID': str(mock_programs.programs[5]['_id']), 'ranking': 68.568, 'raw_score': 30.906},
            {'position': 7, 'programID': str(mock_programs.programs[6]['_id']), 'ranking': 66.332, 'raw_score': 29.88},
        ]
    }

    mock_recos_response = mock.MagicMock()
    mock_recos_response.dict = mock_dict
    mock_recos_response.text = json.dumps(mock_dict)

    return mock_recos_response


def test_get_potential_deal(client, client_header, monkeypatch, recommendations):
    mock_requests = mock.MagicMock()
    mock_requests.get.return_value = recommendations
    monkeypatch.setattr('app.service.program_recommendation.requests', mock_requests)

    potential_client_id = '5fad58987cae51199d14525b'
    response = client.get(f'/deal/potential/{ potential_client_id }', headers=client_header)
    assert response.status_code == 200
    mock_requests.get.assert_called()

    deal = json.loads(response.data.decode())
    assert deal['client'] == potential_client_id

    # confirm recommended program fields
    assert deal['recommendedPrograms']
    assert deal['recommendedPrograms'][0]['_id'] == recommendations.dict['recommendations'][0]['programID']
