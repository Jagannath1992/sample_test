from typing import Dict

from bson import ObjectId
from flask import request
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from werkzeug.exceptions import Forbidden, NotFound, BadRequest

from portal.features.account_approval.schema import AccountApprovalResponse, AccountApprovalRequest
from portal.features.accounts.schema import IndustrySchema, PutAccountActivateRequest, AccountSearchResponse, AccountRequest, AccountResponse, AccountSearchRequest, \
    AccountAppSettingsResponse
from portal.shared.auth.requests import role_required, token_required
from portal.shared.auth.security import has_role
from portal.shared.enums import AccountStatus, UserRole
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import account_repository, account_approval_repository, instance_settings_repository
from portal.shared.services import email_service

namespace = Namespace('accounts', description='Account related operations')


def _validate_access(account_id: str):
    if not has_role(GIVEWITH_ROLES, request.user) and request.user['accountId'] != ObjectId(account_id):
        raise Forbidden('You do not have permission to access this resource')


@namespace.route('')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class Accounts(Resource):
    @role_required(roles=GIVEWITH_ROLES)
    @accepts(query_params_schema=AccountSearchRequest, api=namespace)
    @responds(schema=AccountSearchResponse, api=namespace)
    def get(self):
        filters = request.parsed_query_params
        total_count, accounts = account_repository().get_page(filters)
        return {
            'totalCount': total_count,
            'results': accounts
        }

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=AccountRequest, api=namespace)
    @responds(schema=AccountResponse, api=namespace)
    def post(self):
        new_account = account_repository().insert(request.parsed_obj, request.user['username'])
        account_approval_repository().insert({'_id': new_account['_id'], 'levels': []}, request.user['username'])
        return new_account


@namespace.route('/<string:id>')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Account not found'
    }
)
class AccountById(Resource):
    @token_required
    @responds(schema=AccountResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')
        return account

    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE,
    ])
    @accepts(schema=AccountRequest, api=namespace)
    @responds(schema=AccountResponse, api=namespace)
    def put(self, id: str):
        """Update Account"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')

        update = self._restrict_instance_customer_id_type_and_status(request.parsed_obj)

        is_status_changed = False
        if 'status' in update:
            is_status_changed = (account['status'] == AccountStatus.ACTIVE.value and update['status'] != AccountStatus.ACTIVE.value) or (
                account['status'] != AccountStatus.ACTIVE.value and update['status'] == AccountStatus.ACTIVE.value)

        account.update(update)
        account = account_repository().update(account, by=request.user['username'])

        if is_status_changed:
            instance = instance_settings_repository().get_single(account['instance']['_id'])
            if account['status'] == AccountStatus.ACTIVE.value:
                pass  # email_service().send_account_activated_email(instance, account)
            else:
                email_service().send_account_deactivated_email(instance, account)
        return account

    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE
    ])
    @accepts(schema=AccountRequest(partial=True), api=namespace)
    @responds(schema=AccountResponse, api=namespace)
    def patch(self, id: str):
        """Update Account from Partial"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')

        update = self._restrict_instance_customer_id_type_and_status(request.parsed_obj)

        is_status_changed = False
        if 'status' in update:
            is_status_changed = (account['status'] == AccountStatus.ACTIVE.value and update['status'] != AccountStatus.ACTIVE.value) or (
                account['status'] != AccountStatus.ACTIVE.value and update['status'] == AccountStatus.ACTIVE.value)

        account.update(update)
        account = account_repository().update(account, request.user['username'])

        if is_status_changed:
            instance = instance_settings_repository().get_single(account['instance']['_id'])
            if account['status'] == AccountStatus.ACTIVE.value:
                pass  # email_service().send_account_activated_email(instance, account)
            else:
                email_service().send_account_deactivated_email(instance, account)
        return account

    def _restrict_instance_customer_id_type_and_status(self, params: Dict) -> Dict:
        '''only givewith admin can update instance, sageCustomerId, Type, or status'''
        if has_role([UserRole.SUPER_ADMIN, UserRole.GW_FINANCE, UserRole.GW_OPERATIONS], request.user):
            return params
        if 'instance' in params:
            params.pop('instance')
        if 'sageCustomerId' in params:
            params.pop('sageCustomerId')
        if 'status' in params:
            params.pop('status')
        if 'type' in params:
            params.pop('type')
        return params


@namespace.route('/<string:id>/approvals')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class AccountApproval(Resource):

    @token_required
    @responds(schema=AccountApprovalResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        approvals = account_approval_repository().get_single(id)
        return approvals

    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE
    ])
    @accepts(schema=AccountApprovalRequest, api=namespace)
    @responds(schema=AccountApprovalResponse, api=namespace)
    def put(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        approval = account_approval_repository().get_single(id)
        if approval is None:
            raise NotFound('Account not found')

        approval.update(request.parsed_obj)
        return account_approval_repository().update(approval, request.user['username'])


@namespace.route('/<string:id>/activate')
class AccountActivate(Resource):
    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE
    ])
    @accepts(schema=PutAccountActivateRequest, api=namespace)
    @namespace.response(404, 'Not Found')
    def put(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')
        if account['status'] != AccountStatus.PENDING.value:
            return Forbidden('Account is not pending')
        account['status'] = AccountStatus.ACTIVE.value
        account.update(request.parsed_obj)
        account['lastUpdatedBy'] = request.user['username']
        account = account_repository().update(account)
        # email_service().send_account_activated_email(account)
        return 200


@namespace.route('/<string:id>/app-settings')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Invalid id provided',
        403: 'You do not have permission to access this resource',
        404: 'Account not found'
    })
class AccountAppSettingsByID(Resource):
    @token_required
    @responds(schema=AccountAppSettingsResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')

        supplier_account = account_repository().get_single(request.user['accountId'])
        procurement_account = account_repository().get_single_by_filter(
            {'_id': ObjectId(id), 'instance._id': supplier_account['instance']['_id']})

        if procurement_account is None:
            raise NotFound('Account not found')
        if procurement_account['_id'] != supplier_account.get('invitedBy', {}).get('_id'):
            raise Forbidden('You do not have permission to access this resource')

        response = {
            'id': id,
            'procurement': procurement_account.get('procurement', {})
        }
        return response


@namespace.route('/industries')
@namespace.route('/industries/<string:action>')
class AccountIndustries(Resource):
    @responds(schema=IndustrySchema(many=True), api=namespace)
    def get(self, action: str = None):
        industries = account_repository().get_industries()
        industries = [{'name': i, 'items': industries[i]} for i in industries if i != '_id']

        if action == 'counts':
            counts = account_repository().get_industry_counts()
            for industry in industries:
                for subIndustry in industry['items']:
                    count = counts.get(subIndustry['subIndustry'], None)
                    subIndustry['count'] = count

        return industries
