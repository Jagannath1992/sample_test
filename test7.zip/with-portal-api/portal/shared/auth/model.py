from bson import ObjectId
from cerberus import Validator
from enum import Enum, unique, auto
from typing import List

type_object_id = ['object_id', 'string']
type_datetime = ['datetime', 'string']
type_number = ['number', 'string']


def get_enum_members(enum_class: Enum) -> List[str]:
    return [str(member) for member in enum_class]


def to_object_id(value):
    if value:
        return ObjectId(value)
    else:
        return None


def to_bool(value):
    return value.lower() in ('true', '1', 'yes') if type(value) == str else value


def to_lower(string):
    return string.lower()


class GivewithValidator(Validator):
    def _validate_type_object_id(self, value):
        if type(value) == ObjectId:
            return True


@unique
class OrgType(Enum):
    """Enum representing the organization types a user can belong to

    NOTE: A user's organization type will be stored in the db as a lowercase
    string under the key orgType. hence, always compare orgType with
    OrgType.value rather than OrgType.name
    """
    BRAND = 'brand'
    NONPROFIT = 'nonprofit'

    def __str__(self):
        return self.value


@unique
class UserType(Enum):
    """Enum representing user types. Mostly used to to limit permissions if needed
    and for validation.

    NOTE: A user's type will be stored in the db as a lowercase string under
    the key type. Hence, always compare userType with UserType.value rather
    than UserType.name
    """
    ADMIN = 'admin'
    CLIENT = 'client'

    REOWNER = 're-owner'
    REMANAGER = 're-manager'
    REVENDOR = 're-vendor'
    REMARQUEETENANT = 're-marquee-tenant'
    RETENTANT = 're-tenant'

    def __str__(self):
        return self.value


@unique
class UserRole(Enum):
    """User Role for determining resource access"""
    IC = 'ic'
    MANAGER = 'manager'
    ADMIN = 'admin'
    SUPERUSER = 'superuser'

    def __repr__(self) -> str:
        return self.value

    __str__ = __repr__


@unique
class RBACGroup(Enum):
    """Basic RBAC groups for CRUD permissions"""
    READER = 'reader'
    CREATOR = 'creator'
    UPDATER = 'updater'
    DELETER = 'deleter'

    def __repr__(self) -> str:
        return self.value

    __str__ = __repr__


class UserDepartmentType(Enum):
    """Enum representing a user's department type
    """
    PROCUREMENT = 'Procurement'
    SALES = 'Sales'
    CSR = 'CSR'
    MARKETING = 'Marketing'
    HR = 'HR'
    EXECUTIVE = 'Executive'
    OTHER = 'Other'
    PORTAL = 'Portal'

    def __str__(self):
        return self.value


v = GivewithValidator(purge_unknown=True)

allowed_org_types = get_enum_members(OrgType)
allowed_user_types = get_enum_members(UserType)
allowed_user_roles = get_enum_members(UserRole) + get_enum_members(RBACGroup)
allowed_department_types = get_enum_members(UserDepartmentType)

schema_user = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'accountId': {'type': type_object_id, 'required': True, 'coerce': to_object_id},
    'uuid': {'type': 'string'},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'first_name': {'type': 'string', 'required': True, 'empty': False},
    'last_name': {'type': 'string', 'required': True, 'empty': False},
    'active': {'type': 'boolean', 'required': True, 'coerce': to_bool},
    'title': {'type': 'string', 'required': False, 'empty': True},
    'notes': {'type': 'string', 'required': False, 'empty': True},
    'cognito-id': {'type': 'string', 'required': True, 'empty': False},
    'type': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_user_types},
    'username': {'type': 'string', 'required': True, 'empty': False, 'coerce': to_lower},
    'orgName': {'type': 'string', 'required': True, 'empty': False},
    'orgType': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_org_types},
    'orgId': {'type': type_object_id, 'required': True, 'coerce': to_object_id},
    'roles': {'type': 'list', 'allowed': allowed_user_roles},
    'departmentName': {'type': 'string'},
    'departmentType': {'type': 'string', 'allowed': allowed_department_types},
    'phoneNumber': {'type': 'string'},
    'businessAddress': {'type': 'string'},
    'companyWebsite': {'type': 'string'},
    'industry': {'type': 'string'},
    'createdAt': {'type': type_datetime},
}
