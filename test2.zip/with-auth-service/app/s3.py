import boto3
import os

ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
s3_client = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)


def upload_file(bucket_name, file_name):
    with open(file_name, "rb") as f:
        s3_client.upload_fileobj(f, bucket_name, file_name)

    return 'https://' + bucket_name + '.s3.amazonaws.com/' + file_name


def download_file(bucket_name, file_name):
    s3 = boto3.client('s3')
    with open(file_name, 'wb') as f:
        s3.download_fileobj(bucket_name, file_name, f)

    return f
