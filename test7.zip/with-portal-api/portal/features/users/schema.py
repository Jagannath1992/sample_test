from marshmallow import fields, Schema, post_load, validates, validate, ValidationError

from portal.features.accounts.schema import AccountSchema
from portal.shared.custom_fields import LoweredString, ObjectIdField
from portal.shared.email.validator import EmailValidator
from portal.shared.enums import AccountStatus, SubscriptionFrequency, UserRole, ProductType
from portal.shared.repositories import user_repository
from portal.shared.schema import BusinessSchema, EntitySchema, SearchRequestSchema, SearchResponseSchema, SubIndustrySchema


class UserSchema(EntitySchema):
    """User model"""
    accountId = ObjectIdField()
    username = LoweredString(required=True)
    firstName = fields.String(attribute='first_name', required=True)
    lastName = fields.String(attribute='last_name', required=True)
    title = fields.String()
    departmentName = fields.String()
    phoneNumber = fields.String()
    active = fields.Boolean()
    roles = fields.List(fields.String(validate=validate.OneOf([ur.value for ur in UserRole])))

    def set_defaults(user: dict):
        user.update({
            'orgId': '',
            'orgName': '',
            'orgType': 'brand',
            'type': 'client',
            'departmentType': 'Portal'
        })

    @validates('username')
    def validate_username(self, value):
        valid_email_address = EmailValidator().validate(value)
        if not valid_email_address:
            raise ValidationError('Invalid username')

        blocked_domains = user_repository().get_blocked_domains()
        if blocked_domains and 'domains' in blocked_domains and valid_email_address.domain in blocked_domains['domains']:
            raise ValidationError('Blocked domain')

        if user_repository().username_exists(value):
            raise ValidationError('Email address must be unique')


class CreateAccountSchema(Schema):
    """Partial Account model for registration Step 1"""
    industry = fields.Nested(SubIndustrySchema, required=True)
    company = fields.Nested(BusinessSchema(partial=True), required=True)
    


class UpdateAccountSchema(Schema):
    """Partial Account model for registration Step 2"""
    company = fields.Nested(BusinessSchema(partial=True), required=True)
    termsAccepted = fields.Boolean(required=False)


class UserRegisterRequest(Schema):
    """Request model for POST registration Step 1"""
    user = fields.Nested(UserSchema, required=True)
    account = fields.Nested(CreateAccountSchema, required=True)
    locale = fields.String(attribute='locale', required=False)
    productType = fields.String(attribute='productType', required=False, validate=validate.OneOf([s.value for s in ProductType]))

    @post_load
    def post_load(self, data, **kwargs):
        user = data.get('user')
        user['roles'] = [UserRole.ORG_ADMIN.value]
        account = data.get('account')
        AccountSchema.set_defaults(account)
        UserSchema.set_defaults(user)
        return data


class AccountRegisterRequest(Schema):
    """Request model for PUT registration Step 2"""
    account = fields.Nested(UpdateAccountSchema, required=True)

    @post_load
    def post_load(self, data, **kwargs):
        account = data.get('account')
        account.update({
            'status': AccountStatus.PENDING.value,
        })
        return data


class AccountSubscriptionOptionsSchema(Schema):
    subscriptionFrequency = fields.String(required=True, validate=validate.OneOf([
                                          sf.value for sf in SubscriptionFrequency]))


class AccountSubscriptionRequest(Schema):
    """Request model for PUT registration Step 3"""
    subscriptionOptions = fields.Nested(AccountSubscriptionOptionsSchema)
    createSetupSubscriptionCheckoutSession = fields.Boolean(load_default=False)


class AccountSubscriptionResponse(Schema):
    url = fields.String()


class AccountSubscriptionActivateRequest(Schema):
    """Request model for POST registration Step 4"""
    checkoutSessionId = fields.String(required=True)


class AccountSubscriptionActivateResponse(Schema):
    url = fields.String()


class UserInviteRequest(UserSchema):
    """Request model for POST User invite requests"""

    @post_load
    def post_load(self, data, **kwargs):
        UserSchema.set_defaults(data)
        return data

    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated',
                   'title', 'departmentName', 'phoneNumber', 'active')


class UserProvisionRequest(UserInviteRequest):
    """Request model for POST User provision requests"""
    accountId = ObjectIdField(allow_none=True)
    password = fields.String(required=True)


class UserProvisionResponse(Schema):
    """Response model for POST User provision requests"""
    id = ObjectIdField()
    username = fields.String()
    error = fields.String()


class UserRequest(UserSchema):
    """Request model for PUT User requests"""
    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated', 'accountId', 'username')


class UserMyProfileRequest(UserSchema):
    """Request model for PUT User My Profile requests"""
    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy',
                   'lastUpdated', 'accountId', 'username', 'active', 'roles')


class UserResponse(UserSchema):
    """Response model for GET/POST/PUT User responses"""
    pass


class UserSearchRequest(SearchRequestSchema):
    """Request model for GET Users search request"""
    accountId = ObjectIdField(allow_none=True)
    username = fields.String(allow_none=True)
    firstName = fields.String(attribute='first_name', allow_none=True)
    lastName = fields.String(attribute='last_name', allow_none=True)
    active = fields.Boolean()
    roles = fields.String(allow_none=True)

    class Meta:
        contains_fields = ['username', 'first_name', 'last_name']


class UserSearchResponse(SearchResponseSchema):
    """Response model for GET Users search response"""
    results = fields.List(fields.Nested(UserSchema, required=True))


class BlockedDomainsResponse(Schema):
    """Response model for GET Blocked Domains response"""
    domains = fields.List(fields.String())
