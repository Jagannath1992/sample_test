# pylint: disable=redefined-outer-name
from datetime import datetime, timedelta
from os import environ

import jwt
import pytest
from pymongo import MongoClient

from app import create_app
from app.utils import auth
from tests.__mocks__.test_data import (mock_brands, mock_programs, mock_vocabulary, mock_nonprofits, mock_tokens,
                                       mock_user, mock_supplier_analysis_reports)

DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
TOKEN_PRIVATE_KEY = ('Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy'
                     '6ok78k6SKl3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')


@pytest.fixture(scope='session')
def client(test_db):
    """Configure test client"""
    app = create_app(test_db)
    test_client = app.test_client()

    load_testing_data(test_db)

    ctx = app.app_context()
    ctx.push()

    yield test_client
    ctx.pop()


@pytest.fixture(scope='session')
def test_db():
    """Create test db"""
    test_db_url = environ.get('TEST_DB_URL', 'mongodb://localhost:27017/')
    db_client = MongoClient(test_db_url)

    db = db_client['sales_test_db']

    yield db
    db_client.drop_database('sales_test_db')


@pytest.fixture(scope='session')
def admin_token():
    now = datetime.now().timestamp()
    hour_later = (datetime.utcnow() + timedelta(hours=1)).timestamp()

    _admin_token = mock_tokens.admin_token
    claims = {**_admin_token, 'auth_time': now, 'exp': hour_later}

    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture(scope='session')
def client_token():
    now = datetime.now().timestamp()
    hour_later = (datetime.utcnow() + timedelta(hours=1)).timestamp()

    _client_token = mock_tokens.client_token
    claims = {**_client_token, 'auth_time': now, 'exp': hour_later}

    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture(scope='session')
def supplier_analysis_report_token():
    hour_later = (datetime.utcnow() + timedelta(hours=1)).strftime(DATETIME_FORMAT)

    sample_report = mock_supplier_analysis_reports.reports[0]
    password, slug = sample_report['password'], sample_report['slug']
    token = auth.create_keyczar_token(f'{password}/password', slug, hour_later)

    return token


@pytest.fixture()
def default_header():
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    }


@pytest.fixture()
def admin_header(default_header, admin_token):
    return {
        **default_header,
        'Authorization': admin_token,
    }


@pytest.fixture()
def client_header(default_header, client_token):
    return {
        **default_header,
        'Authorization': client_token,
    }

@pytest.fixture()
def supplier_analysis_report_header(default_header, supplier_analysis_report_token):
    return {
        **default_header,
        'Authorization': supplier_analysis_report_token
    }


def load_testing_data(db):
    db.user.insert_one(mock_user.default_user)
    db.mm_brands.insert_many(mock_brands.brands)
    db.mm_programs.insert_many(mock_programs.programs)
    db.mm_vocabulary.insert_many(mock_vocabulary.vocabulary)
    db.mm_nonprofits.insert_many(mock_nonprofits.nonprofits)
    db.supplier_analysis_reports.insert_many(mock_supplier_analysis_reports.reports)
