import functools
from datetime import datetime
from typing import Callable
from os import environ

import jwt
from flask import abort, request
from keyczar import keyczar

from app.db.utils import get_document_by_id
from app.validation.utils import validate_with_collection

DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
TOKEN_PRIVATE_KEY = environ.get('TOKEN_PRIVATE_KEY',
                                'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl'
                                '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')
CRYPTER = keyczar.Crypter.Read('keys')


def _decrypt(encoded):
    return CRYPTER.Decrypt(encoded)


def authenticate(func):
    '''
    Authenticate user wrapper
    '''
    @functools.wraps(func)
    def wrapper(*args, **kws):
        token = request.headers.get('authorization')
        request.user = validate_token(token)

        return func(*args, **kws)

    return wrapper


def authenticate_deal(func: Callable) -> Callable:
    '''
    Authenticate deal token
    '''
    @functools.wraps(func)
    def wrapper(*args, **kws):
        token = request.headers.get('authorization')
        request.slug = validate_deal_token(token)

        return func(*args, **kws)

    return wrapper

def authenticate_user_or_deal(func):
    '''
    Authenticate with either user token or deal token
    '''
    @functools.wraps(func)
    def wrapper(*args, **kws):
        token = request.headers.get('authorization')

        # JWT tokens will always have two periods to separate the three parts of the token
        # https://auth0.com/docs/tokens/json-web-tokens/validate-json-web-tokens
        if len(token.split('.')) == 3:
            request.user = validate_token(token)
        else:
            request.slug = validate_deal_token(token)
            request.user = {}

        return func(*args, **kws)

    return wrapper

def validate_token(token):
    '''
    Validate authorization token from the header
    '''
    if token is None:
        abort(401, description='Token not found')
    try:
        claims = jwt.decode(token, TOKEN_PRIVATE_KEY, algorithms='HS256')
        if 'type' not in claims:
            user = get_document_by_id('user', claims['username'])
            user_type = user.get('type')
        else:
            user_type = claims['type']

        if (user_type != 'admin') and (user_type != 'client'):
            abort(403, description='Admin user or client user only')

        return claims

    except jwt.ExpiredSignatureError:
        abort(401, description='Expired token')
    except jwt.PyJWTError:
        abort(401, description='Invalid token')


def validate_deal_token(token: str) -> str:
    '''
    Validate authorization token from header for a deal
    '''
    try:
        password, field_name, slug, expires = _decrypt(token).split('/')
    except KeyError:
        abort(403, description='Credentials not found')

    # prevent users logged in one deal to access others
    current_slug = request.view_args.get('slug')
    if current_slug and current_slug != slug:
        abort(403, description='Invalid token for requested deal.')

    # validate expire date
    if datetime.utcnow() > datetime.strptime(expires, DATETIME_FORMAT):
        abort(401, description='Your token has expired.')

    # validate user credentials
    if not validate_with_collection({'slug': slug, field_name: password}, 'deals'):
        abort(403, description='Invalid token')

    return slug
