# pylint: disable=redefined-outer-name
from unittest import mock
from werkzeug.urls import url_decode, url_encode
import pytest


@pytest.fixture()
def mock_api_utils():
    api_utils = mock.MagicMock()
    api_utils.get_mm_api.return_value = {
        'brands': [
            {
                '_id': '5c1415685b03bb0008c21a30',
                'industry': '5b57801735bfd45127610a51',
                'lastUpdated': None,
                'name': 'BARNES & NOBLE, INC.',
                'source': 'MSCI'
            }
        ],
        'limit': 50,
        'offset': 0
    }

    return api_utils


def test_search_brand_with_special_characters(client, mock_api_utils, client_header, monkeypatch):
    monkeypatch.setattr('app.rest.brand.api', mock_api_utils)

    sample_brand_search = 'Barnes & Noble'
    sample_query = url_encode({'q': sample_brand_search})
    response = client.get(f'/brand/search?{sample_query}', headers=client_header)
    assert response.status_code == 200

    mock_api_utils.get_mm_api.assert_called()
    mm_api_url_params = dict(url_decode(mock_api_utils.get_mm_api.call_args.args[0].split('?')[1]))
    assert mm_api_url_params['query'] == sample_brand_search
