
import string
import secrets

from matchmaking import db

VOCAB_V2 = {'$in': [2]}

topics = [
    {
        'topic': 'Aging populations',
        'programs': [
            'Help older adults improve their physical and financial well-being',
            'Prevent homelessness and eviction for families, seniors and supportive populations',
            'Keep older adults safe in their homes through home modifications',
        ],
        'featured': 'Help older adults improve their physical and financial well-being',
        'description': 'Programs that support aging populations through services such as health screenings, meal services, and equitable housing.',
        'slug': 'k0af6fs1L3BpjnE',
    },
    {
        'topic': 'Animal welfare',
        'programs': [
            'Protect stray dogs through humane treatment',
            'Restore the Lower Rio Grande Watershed in Texas',
            'Restore coastal resilience to protect communities from climate change',
        ],
        'featured': 'Restore coastal resilience to protect communities from climate change',
        'description': 'Programs that work to protect animal welfare by activities such as  providing adequate veterinary services, rehabilitating natural habitats and protect endangered species.',
        'slug': 'VUOPFXm8Oa5MD86',
    },
    {
        'topic': 'Arts and culture',
        'programs': [
            'Invest in youth through free arts education',
            'Bring music education to K-12 students',
            'Encourage self-expression and confidence through the arts',
        ],
        'featured': 'Invest in youth through free arts education',
        'description': 'Programs that impact arts and culture by providing programming such as free art classes, music lessons, or theatre classes.',
        'slug': 'o28a1u8jWNHrTin',
    },
    {
        'topic': 'Criminal justice',
        'programs': [
            'RFK Human Rights',
            'Pair at-risk youth with law enforcement for a life-skills mentoring program',
        ],
        'featured': 'Pair at-risk youth with law enforcement for a life-skills mentoring program',
        'description': 'Programs that support criminal justice work through activities which reduce criminal activity and reduce criminal recidivism.',
        'slug': '3xO1LDkEapDLE7Y',
    },
    {
        'topic': 'Disaster response, relief and recovery',
        'programs': [
            'Train veterans and civilian volunteers to respond to disasters',
            'Respond to disasters with urgent needs and resources to rebuild',
            'Rebuild communities after natural disasters',
        ],
        'featured': 'Train veterans and civilian volunteers to respond to disasters',
        'description': 'Programs that improve conditions for individuals and communities after disasters, such as first aid, rebuilding efforts, and economic rehabilitation work.',
        'slug': 'z0RM2g2p4tFOwrH',
    },
    {
        'topic': 'Diversity and inclusion',
        'programs': [
            'Teach young women of color key coding and tech skills',
            'Support 1000 American Dreams',
            'Equip children with inclusive play environments',
        ],
        'featured': 'Teach young women of color key coding and tech skills',
        'description': 'Programs that foster diversity in spaces, such as providing job training to underrepresented populations in specific industries or providing sensitivity training around diversity.',
        'slug': 'PN76tOc8GIYm47a',
    },
    {
        'topic': 'Economic empowerment',
        'programs': [
            'Disburse microloans to female entrepreneurs',
            'Sustainable Graduation',
            'Equip teens to be money wise via finance lessons and a transformative hands-on, real-life simulation',
        ],
        'featured': 'Disburse microloans to female entrepreneurs',
        'description': 'Programs that help individuals and communities achieve financial stability through financial literacy training, employment training, and access to capital.',
        'slug': '13qlhMigY9OFzjr',
    },
    {
        'topic': 'Education',
        'programs': [
            'Improve school environments through individualized support',
            'Cultivate lifelong readers through tutoring',
            'Provide school supplies to children in need',
        ],
        'featured': 'Cultivate lifelong readers through tutoring',
        'description': 'Programs that further education by increasing access to quality education programs and services, ensuring 21st Century skills proficiency, and improving academic achievement.',
        'slug': 'vW5LkgKU8nd8a4V',
    },
    {
        'topic': 'Environment',
        'programs': [
            'Time for Trees',
            'Solar-powered education',
            'Remove trash and plastic pollution from waterways' ,
        ],
        'featured': 'Time for Trees',
        'description': 'Programs that improve the environment by reducing carbon emissions,  increasing use of renewable energy, or enhance sustainable agricultural practices and programs. ',
        'slug': '8GVZV2zMo8sFYSH',
    },
    {
        'topic': 'Food and hunger',
        'programs': [
            'End childhood hunger in the United States',
            'Provide lifesaving treatment for malnourished women and children',
            'Create communities of health through fresh food',
        ],
        'featured': 'Provide lifesaving treatment for malnourished women and children',
        'description': 'Programs that increase access to nutritious food or reduce hunger and malnutrition by providing healthy eating behavior and nutrition training or providing sufficient, affordable, and nutritious foods.',
        'slug': 'x0NgW7eNa6AeliA',
    },
    {
        'topic': 'Housing and homelessness',
        'programs': [
            'Prevent homelessness and eviction for families, seniors and supportive populations',
            'Reduce educational inequality for homeless youth',
            'Support homeless youth through educational advancement and job training',
        ],
        'featured': 'Prevent homelessness and eviction for families, seniors and supportive populations',
        'description': 'Programs that support the homeless and those with unstable housing by providing affordable housing, temporary housing, or providing support programs to maintain employment, housing, financial stability, and physical and mental health.',
        'slug': 'pp7qPe4Ww01XC8s',
    },
    {
        'topic': 'Human rights and civic engagement',
        'programs': [
            'Provide human rights education to students of all ages',
            'Strengthen relations with communities to build peace',
            'Inspire youth in El Salvador to become community leaders',
        ],
        'featured': 'Provide human rights education to students of all ages',
        'description': 'Programs that promote and protect human rights and civil engagement by enhancing legal protections, creating policy change, and passing legislation.',
        'slug': 'CtukA8y1B0X5VVT',
    },
    {
        'topic': 'Health and wellness',
        'programs': [
            'Weekly home visits to expectant mothers',
            'International antibiotic distribution',
            'Accelerate a cure for diabetes',
        ],
        'featured': 'Accelerate a cure for diabetes',
        'description': 'Programs that improve health and wellness for beneficiaries by running infant health programs, providing fitness programs, providing support for substance abuse, and addictive behaviors, or increasing disease research. ',
        'slug': 'ZFV132VAW1xn0GZ',
    },
    {
        'topic': 'Immigrants',
        'programs': [
            'Support 1000 American Dreamers',
            'Empower migrant youth in NYC',
            'Safe Spaces for immigrant and refugee girls',
        ],
        'featured': 'Safe Spaces for immigrant and refugee girls',
        'description': 'Programs that support immigrants by providing access to education and job training and placement.',
        'slug': 'GSlKE2tva9a6vYW',
    },
    {
        'topic': 'Indigenous peoples',
        'programs': [
            'Guatemala',
            'Install solar for low-income families',
        ],
        'featured': 'Guatemala',
        'description': 'Programs that support indigenous peoples by preserving traditional cultural practices or protecting native lands.',
        'slug': '6qR8SYssrxNi7zp',
    },
    {
        'topic': 'LGBTQQIA+',
        'programs': [
            'Screenings',
            'Build a more gender-equitable workforce',
        ],
        'featured': 'Screenings',
        'description': 'Programs that support LGBTQQIA+ persons through services such as providing mental health programs.',
        'slug': 'HlZtaYAD03C6vpg',
    },
    {
        'topic': 'Poverty alleviation',
        'programs': [
            'Provide bicycles to women entrepreneurs to improve business success',
            'Connect families to resources and networks to break poverty',
            'Reduce inequality while increasing resilience for households' ,
        ],
        'featured': 'Provide bicycles to women entrepreneurs to improve business success',
        'description': 'Programs that help to lift beneficiaries out of poverty while providing for basic needs, creating economic opportunities, or addressing systemic challenges.',
        'slug': '36Uumfn9fLtoIVK',
    },
    {
        'topic': 'People of color',
        'programs': [
            'Teach young women of color key coding and tech skills',
            'Accelerate STEM success for girls from marginalized communities',
            'Introduce under-represented minority youth to technology careers through technical training',
        ],
        'featured': 'Teach young women of color key coding and tech skills',
        'description': 'Programs that support people of color specifically, by improving  access to healthcare, ensuring quality education, and closing the opportunity gap.',
        'slug': '72uhNK4DpkI7Q2E',
    },
    {
        'topic': 'People with disabilities/disabled persons',
        'programs': [
            'Provide wheelchairs to children and young people in need',
            'Equip children with inclusive play environments',
            'Make mental health screenings widely available',
        ],
        'featured': 'Provide wheelchairs to children and young people in need',
        'description': 'Programs that address the needs of people with disabilities including physical health and community accessibility.',
        'slug': '3OGZ5S1Usw1ubZq',
    },
    {
        'topic': 'Refugees',
        'programs': [
            'Provide mentoring to immigrant and refugee girls',
            'Support 1000 American Dreams',
            'Aid women in war zones',
        ],
        'featured': 'Provide mentoring to immigrant and refugee girls',
        'description': 'Programs that address the urgent and long-term needs of refugees, displaced persons, and migrants including providing for basic needs and transitional services.',
        'slug': '42Nq6tBRj9dKj3R',
    },
    {
        'topic': 'Veterans',
        'programs': [
            'Train veterans and civilian volunteers to respond to disasters',
            'Provide lodging for veteran families' ,
            'Reach at-risk veterans through peer support and resource navigation',
        ],
        'featured': 'Veteran and civilian volunteer training',
        'description': 'Programs that support veterans by providing mental health, job access, and scholarship services.',
        'slug': 'T2agf0mSJn3UT5Y',
    },
    {
        'topic': 'Women and girls',
        'programs': [
            'Prepare abuse survivors for sustainable, living-wage careers',
            'Teach girls life skills through running',
            'Teach girls to code',
        ],
        'featured': 'Teach girls life skills through running',
        'description': 'Programs that empower women and girls in schools, in the workplace, and in communities.',
        'slug': 'd2r3S0DkBf93OpZ',
    },
    {
        'topic': 'Youth development',
        'programs': [
            'Bring artistic and creative development programming to low-income youth in southern California',
            'Train school staff to promote inclusive and healthy play',
            'Renovate health and fitness spaces in at-risk communities',
        ],
        'featured': 'Bring artistic and creative development programming to low-income youth in southern California',
        'description': 'Programs that serve young people by providing access to education, community empowerment, or health and wellness activities.',
        'slug': 'cEE43cbjykUowX5',
    }
]


def get_program_id_by_name(name):
    res = db().coll_programs.find_one({'name': name})

    if not res:
        print(f'\nCould not find program with name: {name}')
        res = {}

    return res.get('_id')

print('start')

topic_docs = []
for topic_obj in topics:
    # topic_id = db().coll_vocabulary.find_one({'type': 'themes', 'label': topic_obj['topic']})['_id']
    topic_id = db().coll_vocabulary.find_one({
        'type': 'themes',
        'label': topic_obj['topic'],
        'versions': VOCAB_V2
    })
    if not topic_id:
        print('missing topic')
        print(topic_obj['topic'])
        topic_id = {}
    topic_id = topic_id.get("_id")

    program_ids = []
    for p in topic_obj['programs']:
        program_id = get_program_id_by_name(p)
        if program_id:
            program_ids.append(program_id)

    featured = get_program_id_by_name(topic_obj['featured'])
    if not featured:
        # raise Exception('Missing featured program: ' + topic_obj['featured'])
        print('Missing featured program: ' + topic_obj['featured'])

    topic_docs.append({
        'topic': topic_id,
        'programs': program_ids,
        'featured': featured,
        'slug': topic_obj['slug'],
        'description': topic_obj['description']
    })

db().coll_program_featured_topics.insert_many(topic_docs)

