from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv
from portal.config import get_config
from portal.features.root.controller import api_bp
from portal.logging import init_logging, send_loggly
from portal.datadog import init_datadog
from portal.shared.database import init_db
from portal.shared.encoder import CustomJSONEncoder
from portal.shared.repositories import init_repositories
from portal.shared.services import init_services


def register_blueprints(app):
    # Swagger API documentation
    app.register_blueprint(api_bp)

def after_request(response):
    response.headers.add('Access-Control-Expose-Headers', 'Content-Disposition')
    return response

def create_app():
    app = Flask(__name__)

    # load config
    app.config['config'] = get_config()
    app.config['RESTX_MASK_SWAGGER'] = False  # Removes X-Fields parameter in swagger documentation
    app.config['ERROR_404_HELP'] = False  # Removes additional help message in response json when 404

    load_dotenv('user.env')

    # init_logging
    init_logging(app)

    try:
        init_datadog()
    except Exception as e:
        send_loggly("failed to to init datadog: " + str(e))

    # if __name__ != 'matchmaking':
    #     gunicorn_logger = getLogger('gunicorn.error')
    #     app.logger.handlers = gunicorn_logger.handlers

    db = init_db(app)
    init_repositories(db)
    # init_enforcer(POLICY_DEFINITIONS + ROLE_DEFINITIONS)

    # init services
    init_services(app.config['config'])

    app.json_encoder = CustomJSONEncoder
    app.url_map.strict_slashes = False
    # app.before_request(before_request)
    app.after_request(after_request)

    register_blueprints(app)

    # if test_db is None:
    #     init_profiler(app)

    # global error handling example
    app.register_error_handler(404, not_found_handler)

    CORS(app)

    return app


def not_found_handler(e):
    send_loggly("page not found")
    send_loggly(e)
    return 'Page not found!', 404
