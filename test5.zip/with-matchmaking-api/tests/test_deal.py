import json
import unittest.mock as mock
from matchmaking.service.email import NotificationEmail

def test_get_deals(client, admin_header):
    response = client.get('/admin/deals', headers=admin_header)
    assert response.status_code == 200


def test_create_deal(client, admin_header, user_id, brand_id):
    new_deal = {
        'fundingAmount' : 7000,
        'givewithCustomerUser' : str(user_id),
        'name' : 'test_other_brand_creation',
        'status' : 'PROGRAM_SELECTION_PENDING',
        'totalBudget' : 500000,
        'currency': 'USD',
        'givewithCustomerRole' : 'supplier',
        'managerName' : 'Elizabeth Chan',
        'manager' : str(user_id),
        'selectedRecommendedPrograms' : [],
        'isValid' : True,
        'clientEmails' : [],
        'givewithCustomerEmails' : [
            'daniel.obeng@givewith.com'
        ],
        'givewithCustomer' : str(brand_id),
        'client' : str(brand_id),
        'archived' : False,
    }

    # add the deal
    response = client.post('/admin/deals', data=json.dumps(new_deal), headers=admin_header)
    assert response.status_code == 200
    deal_id = json.loads(response.data.decode()).get('_id')

    # get deals
    response = client.get('/admin/deals/' + deal_id, headers=admin_header)
    assert response.status_code == 200
    deal = json.loads(response.data.decode())

    # verify deals
    for key in new_deal.keys():
        assert key in deal
        assert new_deal.get(key) == deal.get(key)

def test_update_deal(client, admin_header):
    # get deals
    response = client.get('/admin/deals', headers=admin_header)
    deal_id = json.loads(response.data.decode())[0].get('_id')
    deal = json.loads(response.data.decode())[0]
    del deal['_id']
    deal['preventUpdateEmail'] = True
    deal['currency'] = 'USD'

    with mock.patch.object(NotificationEmail, 'send') as sender:
        response = client.put('/admin/deals/' + deal_id, data=json.dumps(deal), headers=admin_header)
        assert response.status_code == 200
        assert not sender.called

    # validate deal was updated
    response = client.get('/admin/deals/' + deal_id, headers=admin_header)
    assert response.status_code == 200
    assert json.loads(response.data.decode()).get('preventUpdateEmail') is True

    # toggle preventUdpateEmail to false and assert emails are sent
    programs_response = client.get('/admin/programs', headers=admin_header)
    program_id = json.loads(programs_response.data.decode())[0].get('_id')
    deal['selectedProgram'] = program_id
    deal['status'] = 'CONFIRMATION_PENDING'
    deal['preventUpdateEmail'] = False
    with mock.patch.object(NotificationEmail, 'send') as sender:
        response = client.put('/admin/deals/' + deal_id, data=json.dumps(deal), headers=admin_header)
        assert response.status_code == 200
        assert sender.called

def test_reference_id(client, admin_header, user_id, brand_id):
    new_deal = {
        'fundingAmount' : 7000,
        'givewithCustomerUser' : str(user_id),
        'name' : 'test_other_brand_creation',
        'status' : 'PROGRAM_SELECTION_PENDING',
        'totalBudget' : 500000,
        'currency': 'USD',
        'givewithCustomerRole' : 'supplier',
        'managerName' : 'Elizabeth Chan',
        'manager' : str(user_id),
        'selectedRecommendedPrograms' : [],
        'isValid' : True,
        'clientEmails' : [],
        'givewithCustomerEmails' : [
            'daniel.obeng@givewith.com'
        ],
        'givewithCustomer' : str(brand_id),
        'client' : str(brand_id),
        'archived' : False,
    }

    # add deal
    response = client.post('/admin/deals', data=json.dumps(new_deal), headers=admin_header)
    assert response.status_code == 200
    reference_id_1 = json.loads(response.data.decode()).get('reference')

    # add deal again
    response = client.post('/admin/deals', data=json.dumps(new_deal), headers=admin_header)
    assert response.status_code == 200
    reference_id_2 = json.loads(response.data.decode()).get('reference')

    # reference number should increase by 1
    assert reference_id_2 == reference_id_1 + 1


def test_get_deal_by_id(client, admin_header):
    deals = client.get('/admin/deals', headers=admin_header)
    deal_to_get = json.loads(deals.data.decode())[0]
    deal_id = deal_to_get.get('_id')
    deal_response = client.get('/admin/deals/' + deal_id, headers=admin_header)
    deal = json.loads(deal_response.data.decode())

    # verify deal
    for key in deal.keys():
        if deal_to_get.get(key):
            assert deal.get(key) == deal_to_get.get(key)
