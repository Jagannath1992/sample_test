from bson.objectid import ObjectId
from flask import current_app

from ..matchmaking.brands.endpoints import insert_brand # pylint: disable=relative-beyond-top-level

from ...auth import get_cognito_id_from_token # pylint: disable=relative-beyond-top-level
from ...models.models import OrgType # pylint: disable=relative-beyond-top-level
from ...mongodb import get_user_from_cognito_id # pylint: disable=relative-beyond-top-level

from matchmaking.service.slack import send_new_brand_message # pylint: disable=relative-beyond-top-level
from ...utils import GivewithError # pylint: disable=relative-beyond-top-level


PROPOSAL_SUMMARY_STATUS_FILTERS = [
    '_id', 'name', 'type', 'status', 'givewithCustomerRole', 'givewithCustomerName', 'client', 'contact', 'currency',
    'clientName', 'clientIsVerified', 'fundingAmount', 'totalBudget', 'givewithPortion', 'customerNotes', 'owner', 'manager',
    'aribaRfpId', 'slug', 'password', 'selectedRecommendedPrograms', 'selectedProgram', 'selectedProgramSlug', 'createdAt', 'type',
    'giveOption', 'splitGiveAmount', 'customerGivewithPercent', 'deliverables', 'expectedClientToConfirm', 'clientConfirmation',
    'givewithFeePercentage', 'completionDate', 'department', 'category', 'sourcingEventType', 'paymentStatus'
]


def get_users_brand_id(request):
    """ Gets the brand id associated with the user who made the request """
    cognito_id = get_cognito_id_from_token(request.headers.get('Authorization'))
    user = get_user_from_cognito_id(cognito_id)

    return ObjectId(user['orgId']) if user['orgType'] == str(OrgType.BRAND) else ''


def lookup_by_field(document, from_field, lookup_field, lookup_func):
    """
    Replace original objectId field from document with field value in lookup result
    This can trigger KeyError exception when from_field do not exists and when lookup_field do not exists
    on both cases we want to ignore error

    :param document: Base dict to replace field
    :param from_field: Field name to be replace
    :param lookup_field: Field name from lookup result to be placed on target field
    :param lookup_func: Function to lookup for result
    :return: lookup return
    """
    try:
        return lookup_func(document.get(from_field))[lookup_field]
    except (KeyError, GivewithError):
        pass


def filter_none_values(dict_obj):
    """ Filters objects in a dictionary if their value is None """
    return {k:v for k,v in dict_obj.items() if v is not None}


def create_incomplete_brand(name, industry):
    """
    Creates a new brand for a client if we do not have the brand in our DB yet
    """
    brand = {
        'name': name,
        'source': 'CUSTOMER',
        'preferredPrograms': {
            'editing': False,
            'cart': [],
            'selected': [],
            'additional': []
        }
    }

    if industry:
        brand['industry'] = industry

    result = insert_brand(brand, public=True).get_json()  # insert_brand returns a response obj
    if result.get('_id'):
        _id = str(result['_id'])
        send_new_brand_message(True, {'id': _id, 'name': name})
        current_app.logger.info(f'New brand created: {_id}')
        return result.get('_id')
    else:
        send_new_brand_message(False, brand)
        current_app.logger.error(f'Customer brand creation failed: {name}, {industry}')
        return ''


def filter_proposal_summary(proposal):
    result = {}
    for key, value in proposal.items():
        if key in PROPOSAL_SUMMARY_STATUS_FILTERS:
            result[key] = value

    if proposal.get('status', '') != 'COMPLETE':
        result.pop('deliverables', None)

    return result

