from matchmaking.dao.utils import build_update_query

def test_create_upate_query():
    changes = {
        'general': {
            'social': {
                'facebook': 'facebook.com/gw',
            },
            'location': {
                'city': 'new york'
            }
        }
    }

    query = build_update_query(changes)
    assert query == {
        'general.social.facebook': 'facebook.com/gw',
        'general.location.city': 'new york'
    }
