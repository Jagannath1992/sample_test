# -*- coding: utf-8 -*-
import json
import uuid
import time
import traceback
import flask
from urllib.parse import urlparse
from functools import partial
from logging import Formatter, getLogger
from flask import Flask, request, current_app, g
from matchmaking.migrator import run_migration
from matchmaking.query_parser import parse_sort_params, parse_filter_params, parse_pagination_params
from matchmaking.service.profiler import init_profiler
from os import environ
from .auth import authenticate_request, secure_commerce
from .utils import GivewithJSONEncoder, MaintenanceMode, GivewithErrorType, init_loggly, send_loggly
from .controllers import root_public_bp, root_protected_bp, public_bp, admin_bp, dash_bp, survey_bp, secure_commerce_bp, mpa_bp
from .controllers.sessions import sessions_bp
from .controllers.commerce.deal import protected_commerce_bp, public_commerce_bp
from .controllers.matchmaking import public_mm_bp, award, billing
from .mongodb import init_db, load_indexes, db
from matchmaking.permissioning.policies import POLICY_DEFINITIONS, ROLE_DEFINITIONS
from matchmaking.permissioning.config import init_enforcer

# Register routes
from . import controllers
from .controllers import sessions, vocabulary, users, generic  # noqa
from .controllers.matchmaking import (
    brands, contacts, nonprofits, programs, settings, surveys, funding_forms, nonprofit_form, completion_forms,
    mpa, supplier_analysis_report, admin_pilot_deal)  # noqa
from .controllers.commerce import deal, gics, data_triggers, brand, executive_dashboard  # noqa
from .controllers.dashboard import dashboard, pilot_dashboard, pilot_reporting, pilot_deal
from .controllers.commerce import survey
from .controllers.deliverables import deliverables


def request_id():
    if not flask.has_request_context():
        return ''

    if getattr(flask.g, 'request_id', None):
        return flask.g.request_id

    headers = flask.request.headers
    new_uuid = headers.get('X-Request-Id')
    if not new_uuid:
        new_uuid = uuid.uuid4()
    flask.g.request_id = new_uuid

    return new_uuid


class LogTimeFormatter(Formatter):
    def formatTime(self, record, datefmt=None):
        converted = self.converter(record.created)
        if datefmt:
            if '%Q' in datefmt:
                msec = '%03d' % record.msecs
                datefmt = datefmt.replace('%Q', msec)
            str_time = time.strftime(datefmt, converted)
        return str_time


def exception_handler(error):
    code = (error.code if hasattr(error, 'code') else 501 if type(error) == NotImplementedError else 500)  # pylint: disable=unidiomatic-typecheck,line-too-long
    error_type = error.type if hasattr(error, 'type') else GivewithErrorType.ERROR

    message = (error.message if hasattr(error, 'message') else
               'Not Yet Implemented' if type(error) == NotImplementedError else str(error))  # pylint: disable=unidiomatic-typecheck,line-too-long

    response_body = {'type': error_type, 'message': message}

    stack_trace = traceback.format_exc()

    current_app.logger.error(message)
    current_app.logger.error(stack_trace)
    send_loggly('Exception handler: request {1} {0};  from IP {2}; {3}'.format(request.path,
                                                                               str(request.method),
                                                                               str(request.remote_addr),
                                                                               str(stack_trace)))

    return current_app.response_class(
        response=json.dumps(response_body),
        status=code,
        mimetype='application/json')


def register_blueprints(app):
    # Public
    app.register_blueprint(public_bp)

    # Public Root unprotected
    app.register_blueprint(root_public_bp)

    # Public Matchmaking
    app.register_blueprint(public_mm_bp, url_prefix='/matchmaking')

    # Sessions
    app.register_blueprint(sessions_bp, url_prefix='/sessions')

    # Admin
    admin_bp.before_request(partial(authenticate_request, app))
    app.register_blueprint(admin_bp, url_prefix='/admin')

    # root protected
    root_protected_bp.before_request(partial(authenticate_request, app))
    app.register_blueprint(root_protected_bp, url_prefix='/')

    # Protected commerce
    protected_commerce_bp.before_request(partial(secure_commerce, app))
    app.register_blueprint(protected_commerce_bp, url_prefix='/commerce')

    # Public commerce
    app.register_blueprint(public_commerce_bp, url_prefix='/commerce')

    # Commerce with authentication
    secure_commerce_bp.before_request(partial(authenticate_request, app))
    app.register_blueprint(secure_commerce_bp, url_prefix='/commerce')

    # Dashboard
    dash_bp.before_request(partial(authenticate_request, app))
    app.register_blueprint(dash_bp, url_prefix='/dashboard')

    # Nonprofit endpoints
    survey_bp.before_request(partial(authenticate_request, app))
    app.register_blueprint(survey_bp, url_prefix='/survey')

    # MPA endpoints
    mpa_bp.before_request(partial(authenticate_request, app))
    app.register_blueprint(mpa_bp, url_prefix='/')

    app.register_error_handler(Exception, exception_handler)


def before_request():
    """ Before Request execute """

    g.start = time.time()

    current_app.logger.info('Request {0} received on {1}'.format(request.method, request.path))
    current_app.logger.debug('Parameters: {0} headers: {1}'.format(request.data, request.headers))

    if request.method == 'GET' and not 'api/measurements' in request.path:
        request.sort_params = parse_sort_params(request.args.get('sort'))
        request.filter_params = parse_filter_params(request.args.get('filter'))
        request.page_size, request.skip = parse_pagination_params(request.args.get('page_size'),
                                                                  request.args.get('page_num'))


def after_request(response):
    if 'Origin' in request.headers:
        origin = request.headers.get('Origin')
        hostname = urlparse(origin).hostname
        if any(name in hostname for name in ('nohardstops.com', 'givewith.com', 'givewithus.com', 'scalewith.com', 'localhost')):
            response.headers.set('Access-Control-Allow-Origin', origin)

    response.direct_passthrough = False
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type, Authorization, refresh_token')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,PATCH,DELETE,OPTIONS')

    # to allow clients to take an action based on whether the content is an attachment (file) vs inline data
    response.headers.add('Access-Control-Expose-Headers', 'Content-Disposition')
    response.headers.add('Access-Control-Allow-Credentials', True)
    response.headers['X-Request-Id'] = request_id()

    stack_trace = ''
    if response.status_code == 500:
        trace = traceback.format_exc()
        if trace is not None:
            stack_trace = 'stacktrace: ' + str(traceback.format_exc())

    current_app.logger.info('Request on {0} finished with status {1}'.format(request.path, response.status_code))
    request_dur = time.time() - g.start

    request_username = "None"
    try:
        request_user_dict = request.user
        request_username = request_user_dict.get('username', 'NA')
    except AttributeError as e:
        request_username = 'no_user_object'

    loggly_msg = 'Request {2} {0};  status {1}; from IP {3}; {4}; dur: {5}; username: {6}'.format(request.path,
                                                                                                  response.status_code,
                                                                                                  str(request.method),
                                                                                                  str(request.remote_addr),
                                                                                                  str(stack_trace),
                                                                                                  str(round(request_dur, 4)),
                                                                                                  request_username)
    if environ.get('ENV', '').lower() == 'staging' and request and hasattr(request, 'db_count'):
        loggly_msg = loggly_msg + f'; db_count: {request.db_count}'

    send_loggly(loggly_msg)

    return response


def create_app(test_db=None):
    from flasgger import Swagger
    # This creates the connexion application instance.
    # connexion_app = connexion.App(__name__)
    # # This gets the underlying Flask app instance.
    # flask_app = connexion_app.app  # Flask(__name__)
    import connexion
    connexion_app = connexion.App(__name__, specification_dir="../")
    connexion_app.add_api("swagger.yml")
    # app = Flask(__name__)
    app = connexion_app.app
    init_loggly()

    if __name__ != 'matchmaking':
        gunicorn_logger = getLogger('gunicorn.error')
        app.logger.handlers = gunicorn_logger.handlers

    init_db(test_db)
    init_enforcer(POLICY_DEFINITIONS + ROLE_DEFINITIONS)

    # stop server if migration failed
    if not run_migration(app):
        return None

    app.json_encoder = GivewithJSONEncoder
    app.url_map.strict_slashes = False
    app.before_request(before_request)
    app.after_request(after_request)

    register_blueprints(app)

    if test_db is None:
        init_profiler(app)

    swagger = Swagger(app)
    return app
