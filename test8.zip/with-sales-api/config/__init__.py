import os
import logging
from logging.handlers import SysLogHandler

openshift_deploy = os.environ.get('OPENSHIFT_DEPLOY', 'False')
syslog_host = os.environ.get('SYSLOG_HOST', '')

base_config = {
    'MATCHMAKING_API_ENDPOINT': 'http://localhost:5001',
    'MONGO_URL': 'mongodb://localhost:27017',
    'MONGO_DATABASE': 'givewith_production',
    'SLACK_WEB_HOOK': 'https://hooks.slack.com/services/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'
}


def init_config(app):
    for k in base_config:
        if os.environ.get(k, None) is not None:
            app.config[k] = os.environ.get(k)
        else:
            app.config[k] = base_config[k]


def init_logger(app):
    if os.getenv('ENV', 'local') == 'local':
        return

    gunicorn_logger = logging.getLogger('gunicorn.error')
    app.logger.handlers = gunicorn_logger.handlers
    app.logger.setLevel(gunicorn_logger.level)

    # init loggly
    logger = logging.getLogger('SALES')  # set this value as per your repo/project
    logger.setLevel(logging.INFO)
    handler = SysLogHandler('/dev/log')
    if openshift_deploy == "True":
        handler = SysLogHandler(address = (syslog_host,514))
    formatter = logging.Formatter(
        'Python: { "loggerName":"%(name)s", \
            "timestamp":"%(asctime)s", \
            "pathName":"%(pathname)s", \
            "logRecordCreationTime":"%(created)f", \
            "functionName":"%(funcName)s", \
            "levelNo":"%(levelno)s", \
            "lineNo":"%(lineno)d", \
            "time":"%(msecs)d", \
            "levelName":"%(levelname)s", \
            "message":"%(message)s"}'
    )
    handler.formatter = formatter
    logger.addHandler(handler)
    logger.info("Init logging on Sales")


def send_loggly(msg):
    logging.getLogger('SALES').error(msg)
