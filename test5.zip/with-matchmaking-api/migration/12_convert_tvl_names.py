from matchmaking import db
import sys

tvl_data = list(db().coll_tvl_data.find())

for tvl_brand in tvl_data:
    isin = tvl_brand['ISIN']
    brand = db().coll_brands.find_one({'ISIN': isin})
    if brand and 'tvlVisibility' in brand:
        brand['tvlVisibility']['accessAndAffordability'] = brand['tvlVisibility'].pop('accessAndAffordabilityVisibility')
        brand['tvlVisibility']['businessEthicsAndTransparencyOfPayments'] = brand['tvlVisibility'].pop('businessEthicsAndTransparencyOfPaymentsVisibility')
        brand['tvlVisibility']['humanRightsAndCommunityRelations'] = brand['tvlVisibility'].pop('humanRightsAndCommunityRelationsVisibility')
        brand['tvlVisibility']['biodiversityImpacts'] = brand['tvlVisibility'].pop('biodiversityImpactsVisibility')
        brand['tvlVisibility']['gHGEmissions'] = brand['tvlVisibility'].pop('gHGEmissionsVisibility')

        db().coll_brands.replace_one(filter={'_id': brand["_id"]}, replacement=brand)
