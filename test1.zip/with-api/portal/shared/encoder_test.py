import uuid
from _decimal import Decimal
from bson.objectid import ObjectId
from datetime import datetime
from pymongo.cursor import Cursor
from unittest.mock import patch
from portal.shared.encoder import CustomJSONEncoder


def test_default_ObjectId():
    encoder = CustomJSONEncoder()
    expected = "0123456789ab0123456789ab"
    value = ObjectId(expected)
    
    result = encoder.default(value)
    assert result == expected

def test_default_bytes():
    encoder = CustomJSONEncoder()
    expected = "abc123"
    value = str.encode(expected, "utf-8")
    
    result = encoder.default(value)
    assert result == expected


@patch.object(Cursor, "next")
def test_default_Cursor(next):
    # TODO: Implement Cursor test
    #encoder = CustomJSONEncoder()
    #expected = ["A", "B", "C"]
    #next.return_value = expected
    #
    #result = encoder.default(next)
    #assert result == expected
    pass


def test_default_Decimal():
    encoder = CustomJSONEncoder()
    expected = "123.45"
    value = Decimal(expected)
    
    result = encoder.default(value)
    assert result == float(expected)


def test_default_datetime():
    encoder = CustomJSONEncoder()
    expected = "2022-01-01T12:13:14.000000Z"
    value = datetime(2022, 1, 1, 12, 13, 14)
    
    result = encoder.default(value)
    assert result == expected


def test_default_JSONEncoder():
    encoder = CustomJSONEncoder()
    expected = "ebfd9e9a-2db5-41ca-ba68-7de5bd3275f3"
    value = uuid.UUID(expected)
    
    result = encoder.default(value)
    assert result == expected
