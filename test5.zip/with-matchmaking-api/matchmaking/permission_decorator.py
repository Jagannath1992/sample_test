import jwt
import functools

from flask import request
from .utils import GivewithError


"""
Define permission check decorators that are run before endpoints. Permission check decorators use the 
scope in token to determine if the request should be permitted.
 
Decorators can wire be at blueprint.route functions. e.g:

@admin_bp.route('/nonprofits', methods=['GET'])
@require_admin_permission
def admin_list_nonprofits():
    pass
    
"""

ADMIN_SCOPE = 'admin'
IMPACT_SCOPE = 'impact'
PSF_SCOPE = 'psf'

def require_admin_permission(func):
    """ ensure token scope is 'admin' only. Mostly for givewith platform endpoints.
    """
    @functools.wraps(func)
    def check_scope(*args, **kws):
        scope = get_token_claim('scope')
        if scope != ADMIN_SCOPE:
            raise GivewithError('Insufficient permission: permitted user role: admin', code=403)
        return func(*args, **kws)

    return check_scope


def require_client_permission(func):
    """ ensure token scope is 'admin' or 'impact'. Mostly for matchmaking platform endpoints.
    """
    @functools.wraps(func)
    def check_scope(*args, **kws):
        scope = get_token_claim('scope')
        if scope != ADMIN_SCOPE and scope != IMPACT_SCOPE:
            raise GivewithError('Insufficient permission: permitted user role: admin, impact', code=403)
        return func(*args, **kws)

    return check_scope


def require_nonprofit_permission(func):
    """ ensure token scope is 'admin' or 'psf'. Mostly for proposal submission form endpoints.
    """
    @functools.wraps(func)
    def check_scope(*args, **kws):
        scope = get_token_claim('scope')
        if scope != ADMIN_SCOPE and scope != PSF_SCOPE:
            raise GivewithError('Insufficient permission: permitted user role: admin, psf', code=403)
        return func(*args, **kws)

    return check_scope


def require_same_org(url_param_name):
    """ ensure org_id is identical to the resource_id in token.
    """
    def decorator(func):
        @functools.wraps(func)
        def check_org_id(*args, **kwargs):
            # no need check for admin scope
            scope = get_token_claim('scope')
            if scope == ADMIN_SCOPE:
                return func(*args, **kwargs)

            resource_ids = get_token_claim('resource_ids')
            if kwargs[url_param_name] not in resource_ids:
                raise GivewithError('Insufficient permission: organization id not match', code=403)

            return func(*args, **kwargs)
        return check_org_id
    return decorator


def get_token_claim(key):
    try:
        token = request.headers['authorization']
        claims = jwt.decode(token, verify=False)
        val = claims[key]
    except Exception as e:
        raise GivewithError('error getting token from header: ' + str(e), code=401)

    return val

