import pymongo

from bson import ObjectId
from pymongo.collection import Collection, ReturnDocument
from pymongo.database import Database
from typing import List, Any, Dict, Tuple

from portal.shared import dates


default_blacklist = ['createdAt', 'createdBy', 'slug', '_id']


class DocumentRepository:
    def __init__(self, db: Database, collection: Collection):
        self.db = db
        self.collection = collection

    def get_single(self, document_id, projection: Dict[str, bool] = None) -> Dict[str, Any]:
        return self.get_single_by_filter(ObjectId(document_id), projection)

    def get_single_by_filter(self, filter, projection: Dict[str, bool] = None) -> Dict[str, Any]:
        return self.collection.find_one(filter, projection=projection)

    def count_by_filter(self, filter) -> int:
        return self.collection.count_documents(filter)

    def exists_by_filter(self, filter) -> bool:
        return self.count_by_filter(filter) != 0

    def get_many(self, filter={}) -> List[Any]:
        return list(self.collection.find(filter))

    def get_page(self, filters: Dict[str, Any], add_fields: dict={}) -> Tuple[int, List[Any]]:
        count = filters.pop('count')
        offset = filters.pop('offset')
        order_by = filters.pop('orderBy')
        order = pymongo.DESCENDING if filters.pop('descending') else pymongo.ASCENDING
        total_count = 0
        result = []

        if add_fields:
            result = list(self.collection.aggregate([{'$addFields':add_fields}, {'$match': filters}, {'$limit': count}, {'$sort': {order_by: order}}, {'$skip': offset} ]))
            count = list(self.collection.aggregate([{'$addFields':add_fields}, {'$match': filters}, {'$count': 'count'} ]))
            if count:
                total_count = count[0]['count']
        else:
            total_count = self.collection.count_documents(filter=filters)
            result = list(self.collection.find(filter=filters, skip=offset, limit=count, sort=[(order_by, order)]))

        return total_count, result

    def exists(self, document_id) -> bool:
        return self.collection.count_documents({'_id': ObjectId(document_id)}) != 0

    def insert(self, document: Dict[str, Any], by: str = None) -> Dict[str, Any]:
        now = dates.get_utcnow()
        document['createdAt'] = now
        document['lastUpdated'] = now
        if by:
            document['createdBy'] = by
            document['lastUpdatedBy'] = by

        doc_id = self.collection.insert_one(document).inserted_id
        return self.get_single(doc_id)

    def insert_many(self, documents, by: str = None) -> list:
        now = dates.get_utcnow()
        for document in documents:
            document['createdAt'] = now
            if by:
                document['createdBy'] = by
            document['lastUpdated'] = now
            if by:
                document['lastUpdatedBy'] = by
        return self.collection.insert_many(documents).inserted_ids

    def update(self, document: Dict[str, Any], by: str = None) -> Dict[str, Any]:
        now = dates.get_utcnow()
        document['lastUpdated'] = now
        if by:
            document['lastUpdatedBy'] = by
        self.collection.replace_one(
            filter={'_id': document.get('_id')},
            replacement=document
        )
        return document

    def update_references(self, entity_ref, id, updated_values):
        entity_ref_dict = dict()
        for key, value in updated_values.items():
            new_key = f"{entity_ref}.{key}"
            entity_ref_dict[new_key] = value
        self.collection.update_many(
            {f"{entity_ref}._id": ObjectId(id)},
            {"$set": entity_ref_dict})

    def patch(self, document_id: str, changes: Dict[str, Any], by: str = None, set_arrays: bool = False) -> Dict[str, Any]:
        now = dates.get_utcnow()
        changes['lastUpdated'] = now
        if by:
            changes['lastUpdatedBy'] = by

        update = remove_blacklisted(changes)
        update = build_update_query(update, set_arrays = set_arrays)

        doc = self.collection.find_one_and_update(
            {'_id': ObjectId(document_id)},
            update, return_document=ReturnDocument.AFTER)
        return doc

    def delete(self, document_id, by: str = None) -> bool:
        return self.collection.delete_one(
            {'_id': ObjectId(document_id)}).deleted_count == 1


def remove_blacklisted(document):
    for key in document.copy():
        if key in default_blacklist:
            document.pop(key)
    return document


def build_update_query(document, query=None, parent_key='', set_arrays: bool = False):
    if query is None:
        query = {
            '$set': {},
            '$push': {}
        }
    for key in document:
        value = document.get(key)
        if len(parent_key) > 0:
            key = parent_key + '.' + key

        if isinstance(value, dict):
            build_update_query(value, query, key)
        elif isinstance(value, list) and not set_arrays:
            query['$push'][key] = {'$each': value}
        else:
            query['$set'][key] = value

    return query
