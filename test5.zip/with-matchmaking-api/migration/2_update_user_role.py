from matchmaking import db

users = list(db().coll_user.find())

for user in users:
    if "type" not in user or user["type"] == "Power User":
        user["type"] = "admin"
        db().coll_user.replace_one(filter={'_id': user["_id"]}, replacement=user)
