from bson import objectid

from matchmaking.dao.utils import get_document_by_id
"""
validate create event request, return if the request is valid, and details of errors
expected json format:
{
    'name': string - required,
    'customer': object id - required
    'category': string - optional,
    'type': string -optional,
    'tcv': string - optional,
}
"""
def validate_create_event_request(request) -> (bool, []):
    errors = []

    if 'name' not in request:
        errors.append({'name': 'field name is required'})

    if 'customer' not in request:
        errors.append({'category': 'field customer is required'})
        return False, errors

    if not objectid.ObjectId.is_valid(request['customer']):
        errors.append({'customer': 'invalid customer'})
        return False, errors

    customer = get_document_by_id('mm_brands', request['customer'])
    if customer is None:
        errors.append({'customer': 'customer not found'})
        return False, errors

    return len(errors) == 0, errors


'''
validate pilot deal fill progress
'''
def validate_pilot_deal_progress(deal):
    event_id = deal['eventId']
    event = get_document_by_id('event', event_id)
    customer = get_document_by_id('mm_brands', event['customer'])
    deal_config = customer.get('dealConfig', {})
    return validate_deal_config(deal_config, deal)


'''
valid date brand's deal config against a pilot deal
return {
    'a' : True,
    'b': False
}
'''
def validate_deal_config(deal_config, deal):
    result = {}
    is_valid = True
    config = []
    config += deal_config.get('funding', [])
    config += deal_config.get('general', [])

    for c in config:
        if 'fieldKey' in c:
            if not c['required']:
                continue

            if c['fieldKey'] == 'paymentOption':
                validate_payment_option(deal, result)
                continue

            is_field_valid = validate_deal_config_key(c['fieldKey'], c['required'], deal)
            result[c['fieldKey']] = is_field_valid
            is_valid = is_valid and is_field_valid

        if 'path' in c:
            if not c['required']:
                continue

            is_path_valid = validate_deal_config_path(c['path'], c['required'], deal)
            result[c['path']] = is_path_valid
            is_valid = is_valid and is_path_valid

    return is_valid, result

def validate_deal_config_key(key, required, deal):
    if key not in deal:
        return False

    # force check selectedPrograms
    if key == 'selectedPrograms':
        if len(deal[key]) == 0:
            return False

        for p in deal[key]:
            program_id = p['programId']
            if not objectid.ObjectId.is_valid(program_id):
                return False

    value = deal[key]
    return validate_zero_value(value)

def validate_deal_config_path(key, required, deal):
    deal_custom_fields = deal.get('customFields') or {}
    if key not in deal_custom_fields:
        return False

    value = deal['customFields'][key]
    return validate_zero_value(value)

def validate_zero_value(v):
    if isinstance(v, str):
        return bool(v.strip())

    if isinstance(v, (float, int)):
        return v > 0

    return bool(v)

"""
validate payment option field for pilot deal
"""
def validate_payment_option(deal, result):
    payment_option = deal.get('paymentOption', '')
    result['paymentOption'] = payment_option in ['payAsYouGo', 'prePaid']

    if payment_option == 'payAsYouGo':
        result['totalBudget'] = float(deal.get('totalBudget') or 0) != 0
        result['givePercent'] = float(deal.get('givePercent') or 0 ) != 0

    if payment_option == 'prePaid':
        result['givewithPortion'] = float(deal.get('givewithPortion') or 0) != 0
