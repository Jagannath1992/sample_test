from matchmaking import db

deliverable_names = {
    'socialMediaPosts': 'SocialMediaPosts',
    'pressRelease': 'PressRelease',
    'csrReportHighlight': 'CSRHighlight',
    'sustainabilityReporting': 'ESGReportingGuide',
    'investorCommunications': 'InvestorsRelations',
    'programFactSheet': 'FactSheet',
    'infographic': 'Infographic',
    'photoGallery': 'Photos',
    'longVideo': 'LongFormVideo',
    'shortVideo': 'ShortFormVideo',
}

deals = list(db().coll_deals.find())
for deal in deals:
    deliverables = deal.get('deliverables', {})

    customer_deliverables = deliverables.get('givewithCustomer', {})
    client_deliverables = deliverables.get('client', {})

    new_customer_deliverables = []

    for key in deliverable_names:
        new_customer_deliverables.append({
            'name': deliverable_names[key],
            'url': customer_deliverables.get(key, '') if customer_deliverables else '',
            'display': False,
        })

    new_client_deliverables = []

    for key in deliverable_names:
        new_client_deliverables.append({
            'name': deliverable_names[key],
            'url': client_deliverables.get(key, '') if client_deliverables else '',
            'display': False,
        })

    deliverables = {
        'givewithCustomer': {
            'deliverables': new_customer_deliverables
        },
        'client': {
            'deliverables': new_client_deliverables
        }
    }

    db().coll_deals.update_one({'_id' : deal.get('_id')}, {'$set': {'deliverables': deliverables}})

