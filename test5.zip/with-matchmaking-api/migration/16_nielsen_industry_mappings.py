from matchmaking import db

industry_mappings = [
    {'type': 'sasb', 'industry': 'Apparel, Accessories & Footwear', 'gics_industry': 'Apparel, Accessories & Luxury Goods'},
    {'type': 'sasb', 'industry': 'Appliance Manufacturing', 'gics_industry': 'Household Appliances'},
    {'type': 'sasb', 'industry': 'Building Products & Furnishings', 'gics_industry': 'Home Furnishings'},
    {'type': 'sasb', 'industry': 'E-Commerce', 'gics_industry': 'Internet & Direct Marketing Retail'},
    {'type': 'sasb', 'industry': 'Household & Personal Products', 'gics_industry': 'Household Products'},
    {'type': 'sasb', 'industry': 'Multiline and Specialty Retailers & Distributors', 'gics_industry': 'Department Stores'},
    {'type': 'sasb', 'industry': 'Toys & Sporting Goods', 'gics_industry': 'Leisure Products'},
    {'type': 'sasb', 'industry': 'Construction Materials', 'gics_industry': 'Construction Materials'},
    {'type': 'sasb', 'industry': 'Coal Operations', 'gics_industry': 'Coal & Consumable Fuels'},
    {'type': 'sasb', 'industry': 'Oil & Gas – Exploration & Production', 'gics_industry': 'Oil & Gas Exploration & Production'},
    {'type': 'sasb', 'industry': 'Iron & Steel Producers', 'gics_industry': 'Steel'},
    {'type': 'sasb', 'industry': 'Oil & Gas – Midstream', 'gics_industry': 'Oil & Gas Storage & Transportation'},
    {'type': 'sasb', 'industry': 'Metals & Mining', 'gics_industry': 'Diversified Metals & Mining'},
    {'type': 'sasb', 'industry': 'Oil & Gas – Refining & Marketing', 'gics_industry': 'Oil & Gas Refining & Marketing'},
    {'type': 'sasb', 'industry': 'Oil & Gas – Services', 'gics_industry': 'Oil & Gas Equipment & Services'},
    {'type': 'sasb', 'industry': 'Alcoholic Beverages', 'gics_industry': 'Distillers & Vintners'},
    {'type': 'sasb', 'industry': 'Agricultural Products', 'gics_industry': 'Agricultural Products'},
    {'type': 'sasb', 'industry': 'Food Retailers & Distributors', 'gics_industry': 'Food Retail'},
    {'type': 'sasb', 'industry': 'Meat, Poultry & Dairy', 'gics_industry': 'Packaged Foods & Meats'},
    {'type': 'sasb', 'industry': 'Non-Alcoholic Beverages', 'gics_industry': 'Soft Drinks'},
    {'type': 'sasb', 'industry': 'Processed Foods', 'gics_industry': 'Packaged Foods & Meats'},
    {'type': 'sasb', 'industry': 'Restaurants', 'gics_industry': 'Restaurants'},
    {'type': 'sasb', 'industry': 'Tobacco', 'gics_industry': 'Tobacco'},
    {'type': 'sasb', 'industry': 'Asset Management & Custody Activities', 'gics_industry': 'Asset Management & Custody Banks'},
    {'type': 'sasb', 'industry': 'Commercial Banks', 'gics_industry': 'Diversified Banks'},
    {'type': 'sasb', 'industry': 'Consumer Finance', 'gics_industry': 'Consumer Finance'},
    {'type': 'sasb', 'industry': 'Security & Commodity Exchanges', 'gics_industry': 'Financial Exchanges & Data'},
    {'type': 'sasb', 'industry': 'Investment Banking & Brokerage', 'gics_industry': 'Investment Banking & Brokerage'},
    {'type': 'sasb', 'industry': 'Insurance', 'gics_industry': 'Multi-line Insurance'},
    {'type': 'sasb', 'industry': 'Mortgage Finance', 'gics_industry': 'Thrifts & Mortgage Finance'},
    {'type': 'sasb', 'industry': 'Biotechnology & Pharmaceuticals', 'gics_industry': 'Pharmaceuticals'},
    {'type': 'sasb', 'industry': 'Health Care Distributors', 'gics_industry': 'Health Care Distributors'},
    {'type': 'sasb', 'industry': 'Drug Retailers', 'gics_industry': 'Drug Retail'},
    {'type': 'sasb', 'industry': 'Health Care Delivery', 'gics_industry': 'Health Care Services'},
    {'type': 'sasb', 'industry': 'Managed Care', 'gics_industry': 'Managed Health Care'},
    {'type': 'sasb', 'industry': 'Medical Equipment & Supplies', 'gics_industry': 'Health Care Equipment'},
    {'type': 'sasb', 'industry': 'Engineering & Construction Services', 'gics_industry': 'Construction & Engineering'},
    {'type': 'sasb', 'industry': 'Electric Utilities & Power Generators', 'gics_industry': 'Electric Utilities'},
    {'type': 'sasb', 'industry': 'Gas Utilities & Distributors', 'gics_industry': 'Gas Utilities'},
    {'type': 'sasb', 'industry': 'Home Builders', 'gics_industry': 'Building Products'},
    {'type': 'sasb', 'industry': 'Real Estate', 'gics_industry': 'Diversified Real Estate Activities'},
    {'type': 'sasb', 'industry': 'Real Estate Services', 'gics_industry': 'Real Estate Services'},
    {'type': 'sasb', 'industry': 'Waste Management', 'gics_industry': 'Environmental & Facilities Services'},
    {'type': 'sasb', 'industry': 'Water Utilities & Services', 'gics_industry': 'Water Utilities'},
    {'type': 'sasb', 'industry': 'Biofuels', 'gics_industry': 'Renewable Electricity'},
    {'type': 'sasb', 'industry': 'Fuel Cells & Industrial Batteries', 'gics_industry': 'Renewable Electricity'},
    {'type': 'sasb', 'industry': 'Forestry Management', 'gics_industry': 'Forest Products'},
    {'type': 'sasb', 'industry': 'Pulp & Paper Products', 'gics_industry': 'Paper Products'},
    {'type': 'sasb', 'industry': 'Solar Technology & Project Developers', 'gics_industry': 'Independent Power Producers & Energy Traders'},
    {'type': 'sasb', 'industry': 'Wind Technology & Project Developers', 'gics_industry': 'Independent Power Producers & Energy Traders'},
    {'type': 'sasb', 'industry': 'Aerospace & Defense', 'gics_industry': 'Aerospace & Defense'},
    {'type': 'sasb', 'industry': 'Chemicals', 'gics_industry': 'Diversified Chemicals'},
    {'type': 'sasb', 'industry': 'Containers & Packaging', 'gics_industry': 'Paper Packaging'},
    {'type': 'sasb', 'industry': 'Electrical & Electronic Equipment', 'gics_industry': 'Electrical Components & Equipment'},
    {'type': 'sasb', 'industry': 'Industrial Machinery & Goods', 'gics_industry': 'Industrial Machinery'},
    {'type': 'sasb', 'industry': 'Advertising & Marketing', 'gics_industry': 'Advertising'},
    {'type': 'sasb', 'industry': 'Casinos & Gaming', 'gics_industry': 'Casinos & Gaming'},
    {'type': 'sasb', 'industry': 'Education', 'gics_industry': 'Education Services'},
    {'type': 'sasb', 'industry': 'Hotels & Lodging', 'gics_industry': 'Hotels, Resorts & Cruise Lines'},
    {'type': 'sasb', 'industry': 'Leisure Facilities', 'gics_industry': 'Leisure Facilities'},
    {'type': 'sasb', 'industry': 'Media & Entertainment', 'gics_industry': 'Movies & Entertainment'},
    {'type': 'sasb', 'industry': 'Professional & Commercial Services', 'gics_industry': 'Diversified Support Services'},
    {'type': 'sasb', 'industry': 'Electronic Manufacturing Services & Original Design Manufacturing', 'gics_industry': 'Consumer Electronics'},
    {'type': 'sasb', 'industry': 'Hardware', 'gics_industry': 'Technology Hardware, Storage & Peripherals'},
    {'type': 'sasb', 'industry': 'Internet Media & Services', 'gics_industry': 'Interactive Media & Services'},
    {'type': 'sasb', 'industry': 'Semiconductors', 'gics_industry': 'Semiconductors'},
    {'type': 'sasb', 'industry': 'Software & IT Services', 'gics_industry': 'IT Consulting & Other Services'},
    {'type': 'sasb', 'industry': 'Telecommunication Services', 'gics_industry': 'Wireless Telecommunication Services'},
    {'type': 'sasb', 'industry': 'Air Freight & Logistics', 'gics_industry': 'Air Freight & Logistics'},
    {'type': 'sasb', 'industry': 'Airlines', 'gics_industry': 'Airlines'},
    {'type': 'sasb', 'industry': 'Auto Parts', 'gics_industry': 'Auto Parts & Equipment'},
    {'type': 'sasb', 'industry': 'Automobiles', 'gics_industry': 'Automobile Manufacturers'},
    {'type': 'sasb', 'industry': 'Cruise Lines', 'gics_industry': 'Hotels, Resorts & Cruise Lines'},
    {'type': 'sasb', 'industry': 'Car Rental & Leasing', 'gics_industry': 'Trucking'},
    {'type': 'sasb', 'industry': 'Marine Transportation', 'gics_industry': 'Marine'},
    {'type': 'sasb', 'industry': 'Rail Transportation', 'gics_industry': 'Railroads'},
    {'type': 'sasb', 'industry': 'Road Transportation', 'gics_industry': 'Trucking'},
]











coll_nielsen_industry_map = db().db.get_collection('nielsen_industry_map')

nielsen_industry_map = coll_nielsen_industry_map.find()
for nielsen_mappings in nielsen_industry_map:
    industry_mappings.append({
        'type': 'nielsen',
        'gics_industry': nielsen_mappings['gics_industry'],
        'industry': nielsen_mappings['nielsen_industry'],
    })


for doc in industry_mappings:
    db().db.get_collection('gics_industry_mappings').insert_one(doc)

coll_nielsen_industry_map.drop()
