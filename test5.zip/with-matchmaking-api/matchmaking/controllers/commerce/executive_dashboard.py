from bson import ObjectId
from flask import jsonify, request
import jwt
from datetime import datetime
from pymongo import DESCENDING
from ...controllers import secure_commerce_bp
from ...permission_decorator import require_client_permission
from ...mongodb import db, get_program, get_mm_brand, get_user
from ...utils import DealStatus, get_descendant_key
from ...dao.utils import get_document_by_id
from ...util.forex import convert_currency
from ...models.models import Currency

YEARLY_QUARTERS = {
  1: 'Q1',
  2: 'Q1',
  3: 'Q1',
  4: 'Q2',
  5: 'Q2',
  6: 'Q2',
  7: 'Q3',
  8: 'Q3',
  9: 'Q3',
  10: 'Q4',
  11: 'Q4',
  12: 'Q4',
}

QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4']

@secure_commerce_bp.route('/executive-dashboard', methods=['GET'])
@require_client_permission
def get_executive_dashboard_data():
    token = request.headers['authorization']
    claims = jwt.decode(token, verify=False)
    org_id = claims.get('orgId', '')
    user_id = claims.get('user_id', '')
    try:
        user_currency = get_document_by_id('mm_brands', org_id, projection={
            'givePercentageCurrency': True, '_id': False
        }).get('givePercentageCurrency', str(Currency.USD))
    except:
        user_currency = 'USD'

    projection = {
      'givewithCustomerRole': 1,
      'totalBudget': 1,
      'fundingAmount': 1,
      'client': 1,
      'selectedProgram': 1,
      'statusUpdatedAt': 1,
      'createdAt':1
    }
    deals = list(db().coll_deals.find({'givewithCustomer': ObjectId(org_id), 'status': str(DealStatus.COMPLETE), 'type': {'$nin': ['covid']}}, projection=projection)
                                .sort('statusUpdatedAt', DESCENDING))
    events = list(db().coll_event.find({'customer': ObjectId(org_id)}))
    projection_actualizations = {
      'totalBudget': 1,
      'supplier': 1,
      'selectedPrograms': 1,
      'lastUpdated': 1,
      'actualizations': 1,
      'currency': 1,
      'status': 1,
    }
    # sales data
    sales_opportunities = [deal for deal in deals if deal.get('givewithCustomerRole') == 'supplier']
    sales_data = get_sales_procurement_data('sales', sales_opportunities)

    # procurement data
    procurement_deals = [deal for deal in deals if deal.get('givewithCustomerRole') == 'buyer']
    procurement_data = get_sales_procurement_data('procurement', procurement_deals)

    if events:
        pilot_deals= list(db().coll_pilot_deal.find({"$or": [{"eventId": ObjectId(eventId['_id'])} for eventId in events], "$or": [{'status': str(DealStatus.COMPLETE)}, {'status': "FUNDING_IN_PROGRESS"}],'deleted': False, 'type': {'$nin': ['covid']}}, projection=projection_actualizations)
                                    .sort('lastUpdated', DESCENDING))
        organized_pilot_deals =get_pilot_funded('procurement', pilot_deals, user_currency)
        procurement_data = combine_data(procurement_data, organized_pilot_deals, 'proposals')
    pilot_deals_sales= list(db().coll_pilot_deal.find({'supplier': ObjectId(org_id), "$or": [{'status': str(DealStatus.COMPLETE)}, {'status': "FUNDING_IN_PROGRESS"}],'deleted': False, 'type': {'$nin': ['covid']}}, projection=projection_actualizations)
                                .sort('lastUpdated', DESCENDING))
    if pilot_deals_sales:
        organized_pilot_deals_sales=get_pilot_funded('sales', pilot_deals_sales, user_currency)
        sales_data = combine_data(sales_data, organized_pilot_deals_sales, 'opportunities')
    # share data
    all_share_actions = list(db().coll_share_actions.find({}, projection={'userId': 1, 'actionType': 1}))

    share_actions = []
    # grab all share_actions whose user's brand is associated with the logged-in user's brand
    for share_action in all_share_actions:
      user = get_user(share_action.get('userId'), projection={'name': 1, 'orgId': 1})
      if user and user.get('orgId') == ObjectId(org_id):
        share_actions.append(share_action)

    share_actions_data = get_share_data(share_actions)

    # impact data
    sales_programs = [program.get('_id') for program in sales_data.get('programs', [])]

    procurement_programs = [program.get('_id') for program in procurement_data.get('programs', [])]

    aggregated_program_list = sales_programs + procurement_programs
    impact_data = aggregate_topics_and_sdgs(aggregated_program_list)
    data = {
      'metrics': {
        'Sales': sales_data,
        'Procurement': procurement_data,
        'Share': share_actions_data,

      },
      'impact': impact_data
    }

    return jsonify(data)

# organize a given set of deals by their year and quarter
def organize_deals_by_quarter(deals, today = datetime.now()):
    todays_year = today.year
    todays_month = today.month
    todays_quarter = YEARLY_QUARTERS[todays_month]
    # get index of quarter of current data
    current_index = QUARTERS.index(todays_quarter)

    organized_deals = {
        todays_year: {},
        todays_year - 1: {},
    }

    for quarter in reversed(QUARTERS[:current_index + 1]):
        organized_deals[todays_year][quarter] = []

    for quarter in reversed(QUARTERS):
        organized_deals[todays_year - 1][quarter] = []

    for deal in deals:
        if 'statusUpdatedAt' in deal:
            deal_date = deal['statusUpdatedAt']
        else:
            deal_date = deal['createdAt']
        d_year = deal_date.year
        d_month = deal_date.month
        d_quarter = YEARLY_QUARTERS[d_month]

        if d_year in organized_deals and d_quarter in organized_deals[d_year]:
            organized_deals[d_year][d_quarter].append({
            'statusUpdatedAt': deal_date,
            '_id': deal['_id'],
            })

    return organized_deals

# return a subset of organize_deals_by_quarter (see func above)
# only works for current and last year
# min of 1
# max of 8 quarters (4 from current year, 4 from previous)
def get_past_quarters(all_data, numOfQuarters, today = datetime.now()):
    todays_month = today.month
    todays_year = today.year
    todays_quarter = YEARLY_QUARTERS[todays_month]

    # get index of quarter of current data
    current_index = QUARTERS.index(todays_quarter)

    final_data = []

    # current year quarters
    for q in QUARTERS[:current_index + 1]:
        if len(final_data) < numOfQuarters:
            final_data.insert(0, {
                'year': todays_year,
                'deals': {
                    q: all_data[todays_year][q]
                }
            })

    # past year quarters
    for last_years_quarters in all_data[todays_year - 1]:
        if len(final_data) < numOfQuarters:
            final_data.append({
                'year': todays_year - 1,
                'deals' : {
                  last_years_quarters: all_data[todays_year - 1][last_years_quarters]
                }
            })

    return final_data

# get the sum of deals per quarter
def get_sum_per_quarter(quarters):
    sum_per_quarter = []

    for q in quarters:
        for k, v in q['deals'].items():
            sum_per_quarter.insert(0, {
              'quarter': k,
              'value': len(v),
            })

    return sum_per_quarter

def get_sales_procurement_data(type, deals):
    organized_data = organize_deals_by_quarter(deals)
    quarters = get_past_quarters(organized_data, 4)
    sum_per_quarter = get_sum_per_quarter(quarters)

    social_impact = 0
    funding_generated = 0
    clients = []
    programs = {}

    # get deal ids from past 4 quarters
    quarter_deals = []
    for q in quarters:
        quarter_deals.extend(list(q.get('deals').values())[0])

    # get all the objects associated with deal_ids
    past_four_deals = []
    for deal in deals:
        for deal_obj in quarter_deals:
            if (deal.get('_id') == deal_obj.get('_id')):
                past_four_deals.append(deal)

    for deal in past_four_deals:
        social_impact += deal['totalBudget']
        funding_generated += deal['fundingAmount']

        if deal['client'] not in clients:
            clients.append(deal['client'])
        client_brand = get_mm_brand(deal['client'], projection={'name': 1, 'nameLabel': 1})

        program = get_program(deal['selectedProgram'], projection={ 'imageLandscape' : 1, 'imagePortrait': 1, 'name': 1})
        programs[program['_id']] = {
            **program,
            'clientName': client_brand.get('nameLabel') or client_brand.get('name')
        }

    # get current quarter and past three (still in the works)
    dealName = 'opportunities' if type == 'sales' else 'proposals'
    return {
        dealName: sum_per_quarter,
        'socialImpact': social_impact,
        'fundingGenerated': funding_generated,
        'numberOfClients': len(clients),
        'programs': list(programs.values()),
        'clients': clients
    }

def get_share_data(share_actions_list):
    share_actions = {
        'Internal': {
            'hr_engagement_survey': 0,
            'hr_social_impact_topic_survey': 0,
            'hr_newsletter': 0,
            'hr_intranet': 0,
            'hr_event': 0,
        },
        'External': {
            'marketing_engagement_survey': 0,
            'marketing_social_impact_topic_announcement': 0,
            'marketing_website': 0,
            'marketing_event': 0,
        },
    }

    for action in share_actions_list:
        if action['actionType'] in share_actions['Internal']:
            share_actions['Internal'][action['actionType']] += 1

        elif action['actionType'] in share_actions['External']:
            share_actions['External'][action['actionType']] += 1

    return share_actions

def get_display_date(date):
  split_date = date.split('-')

  year = int(split_date[0])
  month = int(split_date[1])
  day = int(split_date[2])

  datetime_date = datetime(year, month, day)

  return datetime_date.strftime("%B") + ' ' + str(day)

def get_campaign_data(campaign_list):
  total_views = 0
  total_give_actions = 0
  funding_generated = 0
  total_campaigns = 0
  campaign_summaries = []
  program_data = []
  programs = []

  for campaign in campaign_list:
      end_date = campaign.get('endDate')
      end_date_split = end_date.split('-')

      year = int(end_date_split[0])
      month = int(end_date_split[1])
      day = int(end_date_split[2])

      # check if the campaign's endDate already passed
      if datetime(year, month, day) < datetime.today():
          summary = db().coll_campaign_summary.find_one({'campaign-id': str(campaign['_id'])}, projection={'sections' : 1})
          if summary:
              total_campaigns += 1
              campaign_summaries.append(summary)
              program_data.append({
                'program' : campaign['program'],
                'startDate': get_display_date(campaign['startDate']),
                'endDate': get_display_date(campaign['endDate']),
                'url': campaign['url'],
              })

  for summary in campaign_summaries:
      for index, section in enumerate(summary['sections']):
          if section['id'] == 'conversion':
              scrollData = get_descendant_key(summary['sections'][index], 'components.landing.scrollData', [])

              foundHundredPercentage = False
              for scroll in scrollData:
                  if scroll.get('percentage') == 100:
                      foundHundredPercentage = True
                      total_views += scroll.get('sessions')

              if not foundHundredPercentage and len(scrollData) > 0:
                  total_views += float(scrollData[0].get('sessions'))

          if section['id'] == 'ads':
              campaignStatus = get_descendant_key(summary['sections'][index], 'components.campaignStatus', {})
              total_give_actions += float(campaignStatus.get('giveActions', '0').replace(',', ''))

          if section['id'] == 'impact':
              heroChart = get_descendant_key(summary['sections'][index], 'components.heroChart', {})
              funding_generated += float(heroChart.get('amount', 0))

  for program in program_data:
      programs.append({
          **get_program(ObjectId(program['program']), projection={ 'imageLandscape' : 1, 'imagePortrait': 1, 'name': 1}),
          'startDate': program['startDate'],
          'endDate': program['endDate'],
          'url': program['url']
      })

  return {
    'totalViews': total_views,
    'totalGiveActions': total_give_actions,
    'fundingGenerated': funding_generated,
    'totalCampaigns': total_campaigns,
    'programs': programs,
  }

def aggregate_topics_and_sdgs(program_list):
    program_list = list(set(program_list))
    db_programs = db().coll_programs.find({'_id': {'$in': program_list}}, projection={'themes': 1, 'sdg': 1})

    topics = []
    sdgs = []
    sdg_labels = {}
    for program in db_programs:
      program_themes = get_descendant_key(program, 'themes.data', [])
      db_themes = list(db().coll_vocabulary.find({'_id': {'$in': program_themes}}, projection={'topic': 1}))
      isolated_topics = [t['topic'] for t in db_themes]
      db_topics = list(db().coll_vocabulary.find({'_id': {'$in': isolated_topics}}, projection={'label': 1}))
      topics.extend([t['label'] for t in db_topics])

      program_sdgs = get_descendant_key(program, 'sdg.data', [])
      db_sdgs = list(db().coll_vocabulary.find({'_id': {'$in': program_sdgs}}, projection={'code': 1, 'label': 1}))

      for s in db_sdgs:
        sdgs.append(s['code'])
        if s['code'] not in sdg_labels:
          sdg_labels[s['code']] = s['label']

    topics = list(set(topics))
    sdgs = sorted(list(set(sdgs)), key=lambda sdg: int(sdg.split(' ')[1]))

    return {
        'topics': topics,
        'sdgs': sdgs,
        'sdgLabels': sdg_labels,
    }

def organize_pilot_deals_by_quarter(deals, today = datetime.now()):
    todays_year = today.year
    todays_month = today.month
    todays_quarter = YEARLY_QUARTERS[todays_month]
    # get index of quarter of current data
    current_index = QUARTERS.index(todays_quarter)

    organized_deals = {
        todays_year: {},
        todays_year - 1: {},
    }
    organized_deals_partial = {
        todays_year: {},
        todays_year -1: {}
    }

    for quarter in reversed(QUARTERS[:current_index + 1]):
        organized_deals[todays_year][quarter] = []
        organized_deals_partial[todays_year][quarter] = []

    for quarter in reversed(QUARTERS):
        organized_deals[todays_year - 1][quarter] = []
        organized_deals_partial[todays_year-1][quarter] = []

    for deal in deals:
        d_year = deal['lastUpdated'].year
        d_month = deal['lastUpdated'].month
        d_quarter = YEARLY_QUARTERS[d_month]

        if deal['status'] == 'COMPLETE':
            if d_year in organized_deals and d_quarter in organized_deals[d_year]:
                organized_deals[d_year][d_quarter].append({
                'statusUpdatedAt': deal['lastUpdated'],
                '_id': deal['_id'],
                })
        else:
            if d_year in organized_deals_partial and d_quarter in organized_deals_partial[d_year]:
                organized_deals_partial[d_year][d_quarter].append({
                'statusUpdatedAt': deal['lastUpdated'],
                '_id': deal['_id'],
                })

    return (organized_deals, organized_deals_partial)

def get_pilot_funded(type, deals, user_currency):
    organized_data, organized_deals_partial = organize_pilot_deals_by_quarter(deals)
    quarters = get_past_quarters(organized_data, 4)
    quarters_partial = get_past_quarters(organized_deals_partial, 4)
    sum_per_quarter = get_sum_per_quarter(quarters)
    social_impact = 0
    funding_generated = 0
    clients = [] 
    programs = {}

    # get deal ids from past 4 quarters
    quarter_deals = []
    quarter_deals_partial = []
    for q in quarters:
        quarter_deals.extend(list(q.get('deals').values())[0])
    for p in quarters_partial:
        quarter_deals_partial.extend(list(p.get('deals').values())[0])


    # get all the objects associated with deal_ids
    past_four_deals = []
    past_four_deals_partial = []
    for deal in deals:
        for deal_obj in quarter_deals:
            if (deal.get('_id') == deal_obj.get('_id')):
                past_four_deals.append(deal)
        for deal_obj in quarter_deals_partial:
            if (deal.get('_id')== deal_obj.get('_id')):
                past_four_deals_partial.append(deal)

    for deal in past_four_deals:
        deal_currency = deal.get('currency') or str(Currency.USD)
        client_brand = get_mm_brand(deal['supplier'], projection={'name': 1, 'nameLabel': 1})
        if deal['status'] == 'COMPLETE':
            social_impact += convert_currency(amount=deal['totalBudget'], _from=deal_currency, _to=user_currency)
        # get the funding generated from the programs as well as programs
        for pro in deal['selectedPrograms']:
            funding_generated += convert_currency(amount=float(pro.get('fundingAmount') or 0), _from=deal_currency, _to=user_currency)
            program = get_program(pro['programId'], projection={ 'imageLandscape' : 1, 'imagePortrait': 1, 'name': 1})
            programs[program['_id']] = {
                **program,
                'clientName': client_brand.get('nameLabel') or client_brand.get('name')
            }
    for deal in past_four_deals_partial:
        deal_currency = deal.get('currency') or str(Currency.USD)
        client_brand = get_mm_brand(deal['supplier'], projection={'name': 1, 'nameLabel': 1})
        for pro in deal['selectedPrograms']:
            funding_generated += convert_currency(amount=float(pro.get('fundingAmountGiven') or 0), _from=deal_currency, _to=user_currency)
            program = get_program(pro['programId'], projection={ 'imageLandscape' : 1, 'imagePortrait': 1, 'name': 1})
            programs[program['_id']] = {
                **program,
                'clientName': client_brand.get('nameLabel') or client_brand.get('name')
            }
        if 'actualizations' in deal:
                totalActualizations = 0
                for actualization in deal['actualizations']:
                    totalActualizations += convert_currency(
                        amount=float(actualization.get('spend') or 0),
                        _from=actualization['currency'] or deal_currency,
                        _to=user_currency
                    )
                    # Defines the amount needed to add to total funding generated
                    actualization['currentFundingAmount'] = float(actualization.get('spend') or 0)
                    # Used on FE to select the actualization for Reporting
                    actualization['status'] = 'ACTUALIZATION_SPEND'

                funding_generated += totalActualizations

        if deal['supplier'] not in clients and type != 'sales':
            clients.append(deal['supplier'])


    # get current quarter and past three (still in the works)
    dealName = 'opportunities' if type == 'sales' else 'proposals'
    return {
        dealName: sum_per_quarter,
        'socialImpact': social_impact,
        'fundingGenerated': funding_generated,
        'numberOfClients': len(clients),
        'programs': list(programs.values()),
        'clients': clients
    }

def combine_data(data, pilot_data, type):
    data['socialImpact'] += pilot_data['socialImpact']
    data['fundingGenerated'] += pilot_data['fundingGenerated']
    data['numberOfClients'] = len(list(set(data['clients'] + pilot_data['clients'])))
    data['programs'] = data['programs']+ pilot_data['programs']
    for i in range(len(data[type])):
        if data[type][i]['quarter'] == pilot_data[type][i]['quarter']:
            data[type][i]['value'] += pilot_data[type][i]['value']
    return data