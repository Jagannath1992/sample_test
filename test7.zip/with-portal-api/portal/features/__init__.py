from flask_restx import Api

from portal.features.accounts.controller import namespace as accounts_ns
from portal.features.cause_areas.controller import namespace as cause_areas_ns
from portal.features.error_logs.controller import namespace as error_log_ns
from portal.features.instances.controller import namespace as instance_settings_ns
from portal.features.locales.controller import namespace as locale_ns
from portal.features.orders.controller import namespace as orders_ns
from portal.features.root.controller import api_bp, namespace as root_ns
from portal.features.stripe.controller import namespace as stripe_ns
from portal.features.suppliers.controller import namespace as suppliers_ns
from portal.features.transactions.controller import namespace as transactions_ns
from portal.features.users.controller import namespace as users_ns

protected_api = Api(
    api_bp,
    title="Givewith API",
    description="Givewith API documentation and testing",
    version="1.0",
    authorizations={
        "Bearer": {
            "type": "apiKey",
            "in": "header",
            "name": "Authorization",
        }
    },
    doc='/swagger',
)


protected_api.add_namespace(root_ns, path="/")
protected_api.add_namespace(accounts_ns, path="/accounts")
protected_api.add_namespace(users_ns, path="/users")
protected_api.add_namespace(orders_ns, path="/orders")
protected_api.add_namespace(cause_areas_ns, path="/cause-areas")
protected_api.add_namespace(transactions_ns, path="/transactions")
protected_api.add_namespace(instance_settings_ns, path="/instance-settings")
protected_api.add_namespace(locale_ns, path="/locales")
protected_api.add_namespace(stripe_ns, path="/stripe")
protected_api.add_namespace(suppliers_ns, path="/suppliers")
protected_api.add_namespace(error_log_ns, path="/error-logs")
