from matchmaking import db

VOCAB_V2 = {'$in': [2]}

question_dependencies = {
    'protectAndEnhanceForest': {
        'operation': 'in',
        'path': 'ImpactAndScope.protectAndEnhanceForest.value',
        'keys': [
            {'key': 'ImpactAndScope.primaryImpact.value', 'operator': 'in', 'descriptionSuffix': 'this program\'s primary targeted impact'},
            {'key': 'ImpactAndScope.secondaryImpact.value', 'operator': 'in', 'descriptionSuffix': 'a secondary impact of this program'},
        ],
        'values': ['Increase protection of public lands'],
    },
    'animalHabitat': {
        'operation': 'in', # any of the keys are in values
        'path': 'ImpactAndScope.animalHabitat.value',
        'keys': [
            {'key': 'ImpactAndScope.primaryImpact.value', 'descriptionSuffix': 'this program\'s primary targeted impact'},
            {'key': 'ImpactAndScope.secondaryImpact.value', 'descriptionSuffix': 'a secondary impact of this program'},
        ],
        'values': ['Protect animal welfare', 'Protect endangered, vulnerable, or threatened species']
    },
    'countries': {
        'operation': 'nin',
        'path': 'ImpactAndScope.countries.value',
        'keys': [
            {'key': 'ImpactAndScope.regions.value'},
        ],
        'values': ['N/A']
    },
    'states': {
        'operation': 'in',
        'path': 'ImpactAndScope.states.value',
        'keys': [
            {'key': 'ImpactAndScope.countries.value', 'descriptionSuffix': 'a country this program operates from. Please select all that apply'},
        ],
        'values': ['North America;United States', 'North America;Canada']
    },
    'cities': {
        'operation': 'nin', # all keys are not in values
        'path': 'ImpactAndScope.cities.value',
        'keys': [
            {'key': 'ImpactAndScope.countries.value'},
        ],
        'values': ['N/A']
    },
    'studyDescription': {
        'operation': 'nin',
        'path': 'ResearchAndEvaluation.studyDescription.value',
        'keys': [
            {'key': 'ResearchAndEvaluation.evidenceDescription.value', 'descriptionSuffix': 'the description of this program\'s evidence or data'}
        ],
        'values': ['N/A']
    },
    'dataDescription': {
        'operation': 'nin',
        'path': 'ResearchAndEvaluation.dataDescription.value',
        'keys': [
            {'key': 'ResearchAndEvaluation.evidenceDescription.value', 'descriptionSuffix': 'the description of this program\'s evidence or data'}
        ],
        'values': ['N/A']
    },
    'outcomeDescription': {
        'operation': 'nin',
        'path': 'ResearchAndEvaluation.outcomeDescription.value',
        'keys': [
            {'key': 'ResearchAndEvaluation.evidenceDescription.value', 'descriptionSuffix': 'the description of this program\'s evidence or data'}
        ],
        'values': ['N/A']
    },
    'researchApproaches': {
        'operation': 'nin',
        'path': 'ResearchAndEvaluation.researchApproaches.value',
        'keys': [
            {'key': 'ResearchAndEvaluation.evidenceDescription.value', 'descriptionSuffix': 'the description of this program\'s evidence or data'}
        ],
        'values': ['N/A']
    },
    'strength': {
        'operation': 'nin',
        'path': 'ResearchAndEvaluation.strength.value',
        'keys': [
            {'key': 'ResearchAndEvaluation.evidenceDescription.value', 'descriptionSuffix': 'the description of this program\'s evidence or data'}
        ],
        'values': ['N/A']
    },
}

################### ------ Map questions dependent on impacts -------- ######################
for key, item_dict in question_dependencies.items():
    values_dict = {}
    for value in item_dict['values']:
        impact = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'impact', 'label': value})

        if impact:
            label = impact.get('label')
            impact_id = str(impact.get('_id'))
            values_dict[impact_id] = label
        else:
            values_dict[value] = value

    question_dependencies[key]['values'] = values_dict


db().coll_survey_data.find_one_and_update({}, {
    '$set': {'questionDependencies': question_dependencies }
})
