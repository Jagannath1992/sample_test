import pytest
from bson import ObjectId

from portal.conftest import get_user_from_header
from portal.features.orders.validators import StatusValidator
from portal.shared.enums import OrderStatus, UserRole
from portal.shared.repositories import order_repository


class TestOrderValidator:
    validator = StatusValidator(str(ObjectId()), OrderStatus.DRAFT.value, {})

    @pytest.fixture()
    def custom_validator(self, request):
        return StatusValidator(str(ObjectId()), request.param.value, {})

    def test_valid_transition(self, mocker):
        mocker.patch.object(order_repository(), 'get_single', return_value={'status': OrderStatus.DELETED.value})

        assert self.validator.is_valid()
        order_repository().get_single.assert_called_once_with(self.validator.order_id)

    def test_invalid_transition(self, mocker):
        mocker.patch.object(order_repository(), 'get_single', return_value={'status': OrderStatus.APPROVED.value})

        assert not self.validator.is_valid()

    def test_new_order_valid_transition(self):
        valid = StatusValidator(None, OrderStatus.DRAFT.value, {})
        assert valid.is_valid()

        invalid = StatusValidator(None, OrderStatus.APPROVED.value, {})
        assert not invalid.is_valid()

    def test_no_status_transition(self):
        no_status = StatusValidator(ObjectId(), None, {})
        assert no_status.is_valid()

    @pytest.mark.parametrize('custom_validator', [OrderStatus.COMPLETED, OrderStatus.ABANDONED], indirect=True)
    def test_financial_hold_valid_transitions(self, mocker, custom_validator):
        mocker.patch.object(order_repository(), 'get_single', return_value={'status': OrderStatus.FINANCIAL_HOLD.value})
        assert custom_validator.is_valid()

    @pytest.mark.parametrize(
        'custom_validator',
        [s for s in OrderStatus if s not in [OrderStatus.COMPLETED, OrderStatus.ABANDONED]],
        indirect=True
    )
    def test_financial_hold_invalid_transitions(self, mocker, custom_validator):
        mocker.patch.object(order_repository(), 'get_single', return_value={'status': OrderStatus.FINANCIAL_HOLD.value})
        assert not custom_validator.is_valid()

    @pytest.mark.parametrize(
        'custom_auth_header',
        [UserRole.SUPER_ADMIN, UserRole.SALES],
        indirect=True
    )
    def test_draft_pending_deleted_authorization(self, custom_auth_header):
        user = get_user_from_header(custom_auth_header)

        draft = StatusValidator(str(ObjectId()), OrderStatus.DRAFT.value, user)
        assert draft.is_authorized()

        pending = StatusValidator(str(ObjectId()), OrderStatus.PENDING_APPROVAL.value, user)
        assert pending.is_authorized()

        deleted = StatusValidator(str(ObjectId()), OrderStatus.DELETED.value, user)
        assert deleted.is_authorized()

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.SALES]],
        indirect=True
    )
    def test_draft_pending_deleted_unauthorized(self, custom_auth_header):
        user = get_user_from_header(custom_auth_header)

        draft = StatusValidator(str(ObjectId()), OrderStatus.DRAFT.value, user)
        assert not draft.is_authorized()

        pending = StatusValidator(str(ObjectId()), OrderStatus.PENDING_APPROVAL.value, user)
        assert not pending.is_authorized()

        deleted = StatusValidator(str(ObjectId()), OrderStatus.DELETED.value, user)
        assert not deleted.is_authorized()

    @pytest.mark.parametrize(
        'custom_auth_header',
        [UserRole.SUPER_ADMIN, UserRole.APPROVER],
        indirect=True
    )
    def test_approved_denied_authorized(self, custom_auth_header):
        user = get_user_from_header(custom_auth_header)

        approved = StatusValidator(str(ObjectId()), OrderStatus.APPROVED.value, user)
        assert approved.is_authorized()

        denied = StatusValidator(str(ObjectId()), OrderStatus.DENIED.value, user)
        assert denied.is_authorized()

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.APPROVER]],
        indirect=True
    )
    def test_approved_denied_unauthorized(self, custom_auth_header):
        user = get_user_from_header(custom_auth_header)

        approved = StatusValidator(str(ObjectId()), OrderStatus.APPROVED.value, user)
        assert not approved.is_authorized()

        denied = StatusValidator(str(ObjectId()), OrderStatus.DENIED.value, user)
        assert not denied.is_authorized()

    @pytest.mark.parametrize(
        'custom_auth_header',
        [UserRole.SUPER_ADMIN, UserRole.TRANSACTOR],
        indirect=True
    )
    def test_completed_not_from_hold(self, custom_auth_header, mocker):
        user = get_user_from_header(custom_auth_header)
        mocker.patch.object(order_repository(), 'get_single', return_value={'status': 'fulfilled'})
        order_id = ObjectId()

        completed = StatusValidator(str(order_id), OrderStatus.COMPLETED.value, user)
        auth = completed.is_authorized()

        assert auth
        order_repository().get_single.assert_called_once_with(order_id)

    def test_completed_from_hold(self, mocker):
        user = {'roles': [UserRole.FINANCE.value]}
        mocker.patch.object(order_repository(), 'get_single', return_value={'status': 'financial hold'})
        order_id = ObjectId()

        completed = StatusValidator(str(order_id), OrderStatus.COMPLETED.value, user)
        auth = completed.is_authorized()

        assert auth
        order_repository().get_single.assert_called_once_with(order_id)
