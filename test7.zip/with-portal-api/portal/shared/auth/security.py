from typing import Dict, List

from bson import ObjectId
from flask import Request
from werkzeug.exceptions import Forbidden, BadRequest
from portal.shared.enums import UserRole
from portal.shared.constants import GIVEWITH_ROLES


def has_role(roles: List[UserRole], user: Dict) -> bool:
    return any([
        role for role in user.get('roles', [])
        if role in roles
    ])


def get_validated_account_id(request_account_id: ObjectId, request: Request) -> ObjectId:
    user_account_id = request.user['accountId']
    if not has_role(GIVEWITH_ROLES, request.user):
        if not request_account_id or ObjectId(request_account_id) == user_account_id:
            return user_account_id
        raise Forbidden('You do not have permission to access this resource')
    if not request_account_id:
        raise BadRequest('accountId is required')
    return ObjectId(request_account_id)
