import re
from bson import ObjectId
from portal.shared.repository import DocumentRepository


class LocaleRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['locale'])
