from os import environ
import constants

def isLocalEnv():
    env = environ.get(constants.ENV, 'local').lower()
    
    if env == 'local':
        return True
    else:
        return False

def getEnvVariable():
    return environ.get(constants.ENV)