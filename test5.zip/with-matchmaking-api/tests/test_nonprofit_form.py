import json
import os
from io import BytesIO
from datetime import datetime

def test_nonprofit_form_work_flow(client, admin_header, user_id):
    name = 'test nonprofit'
    init_request = {
        'applicationFormName': name,
        'givewithAdmin': str(user_id)
    }

    # add the form
    response = client.post('/admin/nonprofit-form:init', data=json.dumps(init_request), headers=admin_header)
    assert response.status_code == 200

    # check result
    write_form = json.loads(response.data.decode())
    assert write_form['givewithAdmin'] == str(user_id)
    assert write_form['applicationFormName'] == str(name)
    assert write_form['editing'] == True
    assert write_form['percentComplete'] == 0
    assert write_form['progress'] == {}

    write_form.pop('createdAt')
    write_form.pop('lastUpdated')

    # read the form
    response = client.get('/nonprofit-form/' + str(write_form['_id']), headers=admin_header)
    assert response.status_code == 200

    read_form = json.loads(response.data.decode())
    read_form.pop('createdAt')
    read_form.pop('lastUpdated')

    assert write_form == read_form

    # delete the from
    response = client.delete('/admin/nonprofit-form/' + str(write_form['_id']), headers=admin_header)
    assert response.status_code == 200

    # read the form again, expect 404
    response = client.get('/admin/nonprofit-form/' + str(write_form['_id']), headers=admin_header)
    assert response.status_code == 404


def test_get_all_forms(client, admin_header, user_id):
    form1 = {
        'applicationFormName': 'test form 1',
        'givewithAdmin': str(user_id)
    }
    form2 = {
        'applicationFormName': 'test form 2',
        'givewithAdmin': str(user_id)
    }

    # add the form1
    response = client.post('/admin/nonprofit-form:init', data=json.dumps(form1), headers=admin_header)
    assert response.status_code == 200

    # add the form2
    response = client.post('/admin/nonprofit-form:init', data=json.dumps(form2), headers=admin_header)
    assert response.status_code == 200

    response = client.get('/admin/nonprofit-form', headers=admin_header)
    assert response.status_code == 200

    forms = json.loads(response.data.decode())
    assert len(forms) == 2


def test_update_form(client, admin_header, user_id):
    update_request = {
        'general':{
            'name': {
                'legalOrganizationName': 'Plan International USA',
                'publicOrganizationName': 'Plan International USA',
            },
            'social': {
                'websiteURL': 'https://www.planusa.org',
                'facebook': 'https://www.facebook.com/planusa',
                'instagram': 'https://www.instagram.com/plan_usa/',
                'twitter': 'https://twitter.com/PlanUSA',
                'linkedIn': 'https://www.linkedin.com/company/plan-usa',
            },
            'contact': {
                'name': 'alice',
                'professionalTitle': 'manager',
                'email': 'alice@email.com',
                'phone': '111-222-333',
            },
            'location': {
                'generalLocation': 'US',
                'specificLocation': 'Plan International USA, 155 Plan Way, Warwick, RI 02886',
                'taxId': '111-11-111',
                'w9': 'TODO',
                'charityNumber': 'TODO',
                'companyHouseNumber': '155',
                'otherId': '',
            },
            'missionAgreement': False,
        }
    }

    init_request = {
        'applicationFormName': 'test form',
        'givewithAdmin': str(user_id)
    }

    response = client.post('/admin/nonprofit-form:init', data=json.dumps(init_request), headers=admin_header)
    assert response.status_code == 200

    _id = json.loads(response.data.decode())['_id']

    # test full update
    response = client.patch('/admin/nonprofit-form/' + _id, data=json.dumps(update_request), headers=admin_header)
    assert response.status_code == 200

    # test partial update
    update_request = {
        'general': {
            'social': {
                'websiteURL': 'https://www.planusa.org/update',
            }
        }
    }

    response = client.patch('/admin/nonprofit-form/' + _id, data=json.dumps(update_request), headers=admin_header)
    assert response.status_code == 200

    # check result
    response = client.get('/admin/nonprofit-form/' + _id, headers=admin_header)
    assert response.status_code == 200
    form = json.loads(response.data.decode())

    assert form['general']['social']['websiteURL'] == 'https://www.planusa.org/update'
    assert form['general']['social']['facebook'] == 'https://www.facebook.com/planusa'


def test_approve_form(client, admin_header):
    response = client.get('/admin/nonprofit-form', headers=admin_header)
    forms = json.loads(response.data.decode())

    _id = str(forms[0]['_id'])
    update_request = {
        'general':{
            'name': {
                'publicOrganizationName': 'name',
            },
        }
    }
    response = client.patch('/admin/nonprofit-form/' + _id, data=json.dumps(update_request), headers=admin_header)
    assert response.status_code == 200

    response = client.post('/admin/nonprofit-form:approve/' + _id, headers=admin_header)
    assert response.status_code == 200

    response = client.get('/admin/nonprofit-form/' + _id, headers=admin_header)
    form = json.loads(response.data.decode())
    nonprofit_id = form['nonprofitId']

    assert form['status'] == 'APPROVED'
    assert 'nonprofitId' in form

    response = client.get('/admin/nonprofits/' + nonprofit_id , headers=admin_header)
    assert response.status_code == 200
    nonprofit = json.loads(response.data.decode())

    assert nonprofit['nonprofitSubmissionId'] == _id
    assert 'createdAt' in nonprofit
    assert 'lastUpdated' in nonprofit
    assert 'createdBy' in nonprofit


def test_upload(client, admin_header):
    response = client.get('/admin/nonprofit-form', headers=admin_header)
    _id = str(json.loads(response.data.decode())[0]['_id'])

    # add the file
    file_name = 'integration_test_file.txt'
    file = open(file_name, 'w+')
    file.write('test file created at ' + str(datetime.utcnow()))
    file.close()

    upload_request = {
        'file': (BytesIO(b'This is a test file from api test, feel free to delete me'), file_name),
        'path': 'financialStatement.file'
    }

    response = client.post('/nonprofit-form/' + _id + '/operationalInformation/file', headers=admin_header, data=upload_request, content_type='multipart/form-data')
    assert response.status_code == 200

    # make sure file name and url has been update
    response = client.get('/admin/nonprofit-form/' + _id, headers=admin_header)
    form = json.loads(response.data.decode())

    f = form['operationalInformation']['financialStatement']['file']
    assert len(f['name']) > 0
    assert len(f['url']) > 0

    # delete file
    delete_request = {
        'path': 'financialStatement.file'
    }

    response = client.delete('/nonprofit-form/' + _id + '/operationalInformation/file', headers=admin_header, data=json.dumps(delete_request))
    assert response.status_code == 200

    response = client.get('/admin/nonprofit-form/' + _id, headers=admin_header)
    form = json.loads(response.data.decode())

    # make sure file name and url has been deleted
    assert 'file' not in form['operationalInformation']['financialStatement']

    os.remove(file_name)


def test_progress(client, admin_header, user_id):
    init_request = {
        'applicationFormName': 'test progress',
        'givewithAdmin': str(user_id)
    }
    response = client.post('/admin/nonprofit-form:init', data=json.dumps(init_request), headers=admin_header)
    assert response.status_code == 200

    form = json.loads(response.data.decode())
    _id = form['_id']
    percentage = form['percentComplete']
    progress = form['progress']
    assert percentage == 0
    assert progress == {}
    assert form['status'] == 'INITIALIZED'

    # update form
    update_request = {
        'general':{
            'contact': {
                'name': 'alice',
            },
        }
    }
    response = client.patch('/admin/nonprofit-form/' + _id, data=json.dumps(update_request), headers=admin_header)
    assert response.status_code == 200


    # check result
    response = client.get('/admin/nonprofit-form/' + _id, headers=admin_header)
    assert response.status_code == 200
    form = json.loads(response.data.decode())

    assert form['percentComplete'] > percentage
    assert form['progress']['general']['complete'] == 1
    assert form['status'] == 'IN_PROGRESS'


def test_get_vocabulary(client):
    response = client.get('/nonprofit-form/vocabulary')
    assert response.status_code == 200


def test_submit_form(client, admin_header, user_id):
    update_request = {
        'general': {
            'name': {
                'legalOrganizationName': 'Plan International USA',
                'publicOrganizationName': 'Plan International USA',
            },
            'social': {
                'websiteURL': 'https://www.planusa.org',
                'facebook': 'https://www.facebook.com/planusa',
                'instagram': 'https://www.instagram.com/plan_usa/',
                'twitter': 'https://twitter.com/PlanUSA',
                'linkedIn': 'https://www.linkedin.com/company/plan-usa',
            },
            'contact': {
                'name': 'alice',
                'professionalTitle': 'manager',
                'email': 'alice@email.com',
                'phone': '111-222-333',
            },
            'location': {
                'generalLocation': 'United States',
                'specificLocation': 'Plan International USA, 155 Plan Way, Warwick, RI 02886',
                'taxId': '111-11-111',
                'w9': 'TODO',
                'charityNumber': 'TODO',
                'companyHouseNumber': '155',
                'otherId': '',
            },
            'missionAgreement': True,
        },
        'overviewAndMission': {
            'historyDescription': 'Plan International USA was originally incorporated as Foster Parents Plan, Inc.',
            'problemDescription': 'Returning from a recent congressional delegation to El Salvador.',
            'causeAreas': {
                'selected': ['0']
            },
            'initiativesDescription': 'TODO',
            'programLocations': 'Warwick',
            'researchAndEvaluation': 'TODO',
            'researchAndEvaluationFile': 's3:link',
            'lifetimeOutputs': [
                {
                    'output': 'TODO',
                    'outputNumber': 1,
                }
            ],
        },
        'operationalInformation': {
            'staff': {
                'fullTime': '10',
                'partTime': '15',
                'volunteers': '20',
            },
            'partnershipsDescription': 'description',
            'yearlyBudget': '1',
            'yearlyBudgetCurrency': 'USD',
            'financialStatement': {
                'website': 'fs',
            },
            'supportersAndPartners': 'TODO',
        },
        'review': {
            'name': 'alice',
            'email': 'alice@planusa.com',
            'agreement': True,
        }
    }

    init_request = {
        'applicationFormName': 'test submit form',
        'givewithAdmin': str(user_id)
    }

    # init
    response = client.post('/admin/nonprofit-form:init', data=json.dumps(init_request), headers=admin_header)
    assert response.status_code == 200

    _id = json.loads(response.data.decode())['_id']

    # update
    response = client.patch('/admin/nonprofit-form/' + _id, data=json.dumps(update_request), headers=admin_header)
    assert response.status_code == 200

    # submit - expect success
    response = client.post('/nonprofit-form:submit/' + _id, headers=admin_header)
    assert response.status_code == 200

    # set required fields to empty value
    update_request['general']['name']['publicOrganizationName'] = ''

    response = client.patch('/admin/nonprofit-form/' + _id, data=json.dumps(update_request), headers=admin_header)
    assert response.status_code == 200

    # submit again - expect fail
    response = client.post('/nonprofit-form:submit/' + _id, headers=admin_header)
    assert response.status_code == 400
