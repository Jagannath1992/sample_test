import pymongo
from datetime import datetime
"""
This scripts does the following:
1) sets currecyFactor value and a status flag
2) unsets/removes active element which was set in previous migration script
3) update Instance Settings API to support site footer URLs
4) remove currency elements from account, account_approval, cause_area
"""
name = '20220722180754'
dependencies = ['20220702181438']


def upgrade(db: pymongo.database.Database):
    now = datetime.utcnow()
    instance_name = 'Givewith for Sales'

    db['account'].update({}, {'$unset': {'currency':1}}, multi=True)
    db['account_approval'].update({}, {'$unset': {'levels.currency':1}}, multi=True)
    db['cause_area'].update({}, {'$unset': {'calculation':1}}, multi=True)
    db['cause_area'].update({}, {'$set': {'active':True}}, multi=True)

    db['instance_settings'].update({}, {'$unset': {'active': 1}}, multi=True)
    db['instance_settings'].update({}, {'$unset': {'settings.stripe.prices': 1}}, multi=True)
    db['instance_settings'].update_many(
        {},
        {'$set': {'causeAreas.$[elem].assignedDate': now}},
        array_filters=[{'elem.assignedDate':{'$exists':False}}])

    db['instance_settings'].find_one_and_update(
        {'name': instance_name},
        {'$set': {
            'settings.stripe.currencyFactor': 0.01,
            'settings.stripe.prices.monthly': {
                'id': 'price_1KjQjAFpuAfBZp0KrlBgK1Qj',
                'amount': 499.00,
                'footer': None
            },
            'settings.stripe.prices.annual': {
                'id': 'price_1L2dc0FpuAfBZp0KsVPHLu2i',
                'amount': 4999.00,
                'footer': '$1000 savings'
            },
            'settings.termsOfUseUrl': 'https://www.givewith.com/terms-of-use/',
            'settings.cookiePolicyUrl': 'https://www.givewith.com/cookie-policy-eu/',
            'settings.privacyPolicyUrl': 'https://www.givewith.com/privacy-policy/',
            'status': 'active'
        }}
    )


def downgrade(db: pymongo.database.Database):
    pass
