from flask import Flask
from flask_cors import CORS
from os import environ

#register blueprints and routes
from app.controllers import root_bp
from app.controllers import root

from app.controllers import nonprofit_bp
from app.controllers import nonprofit

from app.controllers import program_bp
from app.controllers import program

from app.controllers import asset_bp
from app.controllers import asset

from app.controllers import preview_assets_bp
from app.controllers import preview_assets

from app.controllers import deal_bp
from app.controllers import deal

from app.db.database import initialize_db
from app.utils.JSONEncoder import CustomJSONEncoder


base_config = {
    'MONGO_URL': 'mongodb://localhost:27017',
    'MONGO_DATABASE': 'givewith_staging' if environ.get('ENV', 'local') == 'local' else 'givewith_production'
}


def create_app(test_db=None):
    '''
    Create and configure the app
    '''
    app = Flask(__name__)

    CORS(app)

    initialize_config(app)

    initialize_db(app, test_db)

    app.config['RESTFUL_JSON'] = {'cls': CustomJSONEncoder}
    app.json_encoder = CustomJSONEncoder

    app.register_error_handler(400, bad_request_handler)
    app.register_error_handler(500, internal_server_error_handler)

    add_blueprints(app)

    return app


def initialize_config(app):
    for k in base_config:
        if environ.get(k, None) is not None:
            app.config[k] = environ.get(k)
        else:
            app.config[k] = base_config[k]


def bad_request_handler(e):
    return 'Invalid JSON!', 400


def internal_server_error_handler(e):
    exc_type, exc_value, exc_traceback = sys.exc_info()
    exception_details = {
        'extract_traceback': repr(traceback.extract_tb(exc_traceback)),
        'format_traceback': repr(traceback.format_tb(exc_traceback)),
        'exception': repr(traceback.format_exception(exc_type, exc_value, exc_traceback)),
        'formatted_lines': str(traceback.format_exc().splitlines()),
        'line_no': exc_traceback.tb_lineno,
    }
    return 'Internal Server Error!', 500


def add_blueprints(app):
    # root
    app.register_blueprint(root_bp)

    # nonprofits
    app.register_blueprint(nonprofit_bp, url_prefix='/nonprofit')

    # programs
    app.register_blueprint(program_bp, url_prefix='/program')

    # download assets
    app.register_blueprint(asset_bp, url_prefix='/asset')

    # preview assets
    app.register_blueprint(preview_assets_bp, url_prefix='/preview-assets')

    # deals
    app.register_blueprint(deal_bp, url_prefix='/deal')

