# pylint: disable=line-too-long, missing-docstring, invalid-name, wildcard-import, unused-wildcard-import, too-many-boolean-expressions
# pylint: disable=too-many-branches, too-many-statements
from .utils import check_term, add_feature, save_program_document, SELECTED_VOCABULARY_VERSION, critical_alert, init_tagging
from .constants import * # pylint: disable=unused-import


def tag_msci(document, vocabulary):
    # here is where we're modifying data on records
    # what's our general approach?  well - let's load up the mm_vocabulary object into this hash named vocabulary
    # then we pass that and the given document (program record) together to output a stringified - meaning: readable
    # version of the document.

    log = list()
    _MY_SOURCE = VOCAB_ESG  # set this up for each data source!

    try:

        tag_data = init_tagging(document, vocabulary, log, _MY_SOURCE)

        log.append("  rule 1 - access to communication")
        if (check_term(PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
            check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) or \
            check_term(REFUGEES_DISPLACED_PERSONS, VOCAB_AUDIENCES, tag_data)) and \
                (check_term(PROVIDE_TECHNOLOGY_AND_CONNECTIVITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_LITERACY_TRAINING, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, ACCESS_TO_COMMUNICATIONS, tag_data)

        log.append("----")

        log.append("  rule 2 - carbon emissions")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_SUSTAINABLE_AGRICULTURE_PRACTICES_AND_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, CARBON_EMISSIONS, tag_data)

        log.append("----")

        log.append("  rule 3 - climate change vulnerability")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(PROVIDE_POTABLE_WATER, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_COMMUNITY_ENVIRONMENTS_OR_SPACES, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_SUSTAINABLE_AGRICULTURE_PRACTICES_AND_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                     check_term(PRESERVE_WILDLIFE, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, CLIMATE_CHANGE_VULNERABILITY, tag_data)

        log.append("----")


        log.append("  rule 4 - human capital development")
        if (check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
            check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
            check_term(ENSURE_21ST_CENTURY_SKILLS_PROFICIENCY, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_ACCESS_TO_QUALITY_EDUCATION_PROGRAMS_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
            check_term(IMPROVE_ACADEMIC_ACHIEVEMENT, VOCAB_IMPACTS, tag_data) or \
            check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data)) and \
                (check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_BUSINESS_AND_ENTERPRISE_DEVELOPMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_JOB_CREATION, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_JOB_PLACEMENT_RETENTION_SERVICES, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_ENTREPRENEURSHIP_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_SKILLS_FOR_SELF_SUFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPROVE_ACADEMIC_ENVIRONMENTS, VOCAB_APPROACHES, tag_data) or \
                 check_term(ENHANCE_SCHOOL_READINESS_SKILLS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_HIGH_SCHOOL_COMPLETION_SUPPORT, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_COLLEGE_READINESS__ACCESS__PERSISTENCE_AND_COMPLETION, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_LITERACY_AND_NUMERACY_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_LITERACY_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_STEM_INTEREST__PROFICIENCY_AND_PERSISTENCE_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TEACHER_EFFECTIVENESS_PROGRAMS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, HUMAN_CAPITAL_DEVELOPMENT, tag_data)

        log.append("----")

        log.append("  rule 5 - responsible investment")
        add_feature(_MY_SOURCE, RESPONSIBLE_INVESTMENT, tag_data)
        log.append("----")

        log.append("  rule 6 - access to finance")
        if (check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
            check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
            check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data)) and \
                (check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(DEVELOP_FINANCIAL_LITERACY_AND_FINANCIAL_RESILIENCE, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_BUSINESS_AND_ENTERPRISE_DEVELOPMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_ENTREPRENEURSHIP_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, ACCESS_TO_FINANCE, tag_data)

        log.append("----")

        log.append("  rule 7 - opportunities in green building")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data)) and \
                (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                 check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                 check_term(IMPLEMENT_INFRASTRUCTURE_AND_TRANSPORTATION_PROJECTS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, OPPORTUNITIES_IN_GREEN_BUILDING, tag_data)



        log.append("----")
        log.append("  rule 8 - renewable Energy ")
        if check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data):
            add_feature(_MY_SOURCE, OPPS_IN_RENEWABLE_ENERGY, tag_data)

        log.append("----")
        log.append("  rule 9 - community relations")
        add_feature(_MY_SOURCE, COMMUNTIY_RELATIONS, tag_data)
        log.append("----")

        log.append("----")

        log.append("  rule 10 - Access to Health Care")
        if check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data) and \
                (check_term(REDUCE_DISEASE_IMPROVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_REPRODUCTIVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY__AFFORDABLE_HEALTHCARE_AND_SERVICES, VOCAB_IMPACTS, tag_data)) and \
                (check_term(INCREASE_DISEASE_AWARENESS, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_DISEASE_RESEARCH, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_HEALTHY_EATING_BEHAVIOR_AND_NUTRITION_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_MATERNAL_HEALTH_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_MENTAL_HEALTH_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SEXUAL_HEALTH_TRAINING_AND_PROGRAMS , VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUFFICIENT__AFFORDABLE_AND_NUTRITIOUS_FOODS, VOCAB_APPROACHES, tag_data) or \
                 check_term(RUN_INFANT_HEALTH_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(RUN_PATIENT_AND_FAMILY_SUPPORT_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                 check_term(RUN_PATIENT_QUALITY_OF_LIFE_PROGRAMS, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, ACCESS_TO_HEALTH_CARE, tag_data)

        log.append("----")
        log.append("  rule 11 - Opportunities in Nutrition & Health")
        if check_term(FOOD_AND_HUNGER, VOCAB_CAUSES, tag_data) or \
                (check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_NUTRITIOUS_FOOD, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_DISEASE_IMPROVE_HEALTH, VOCAB_IMPACTS, tag_data)) and \
                (check_term(PROVIDE_SUFFICIENT__AFFORDABLE_AND_NUTRITIOUS_FOODS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_HEALTHY_EATING_BEHAVIOR_AND_NUTRITION_TRAINING, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, OPPS_IN_NUTRITION_AND_HEALTH, tag_data)

        log.append("----")

        # the last few steps
        # log it:
        log.append("  Summary: " + ', '.join(document[_MY_SOURCE]["strings"]))

        # now put the version number into the same object
        document[_MY_SOURCE]["tagging-version"] = SELECTED_VOCABULARY_VERSION

        # cool!  save that object back and go!
        save_program_document(document)

    except Exception as eee:
        critical_alert(eee, log, "vocab_error_in_tagging")
        raise eee

    return log
