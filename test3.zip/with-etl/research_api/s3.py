import boto3
import os

ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID', 'None')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', 'None')
client = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)


def upload_file(bucket_name, file_name):
    with open(file_name, "rb") as f:
        client.upload_fileobj(f, bucket_name, file_name)

    return 'https://' + bucket_name + '.s3.amazonaws.com/' + file_name


def delete_file(bucket, file_name):
    return client.delete_object(
        Bucket=bucket,
        Key=file_name,
        RequestPayer='research-api',
    )
