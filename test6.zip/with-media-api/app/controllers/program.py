from flask import jsonify, abort, request
from bson import ObjectId

from ..controllers import program_bp

from ..validation.utils import validate_slug_or_id_with_collection, validate_object_id_with_collection
from ..db.utils import get_documents, get_document_by_id
from ..utils.utils import get_assets, get_filtered_document
from ..constants import default_media_projection


PROGRAM_PROJECTION = {
    'imageLandscape': True,
    'imagePortrait': True
}

@program_bp.route('/<string:program_id_or_slug>/hero', methods=['GET'])
def get_public_program_hero_images(program_id_or_slug):
    '''
    Query the simian-media collection to return the appropriate
    imageLandscape and imagePortrait images for a program.

    imageLandscape: tags in document must include --> Horizontal, Photo, Hero
    imagePortrait: tags in document must include --> Vertical, Photo, Hero

    If either are not found, fallback to corresponding imageLandscape or imagePortrait fields in program
    '''

    program_id, _ = validate_slug_or_id_with_collection(program_id_or_slug, 'mm_programs')

    program = get_document_by_id('mm_programs', program_id, projection=PROGRAM_PROJECTION)

    images = get_hero_images(program_id, program)

    hero_images = {
        'imageLandscape': images['landscape'],
        'imagePortrait': images['portrait'],
    }

    return jsonify(hero_images)


@program_bp.route('/list-of-heros', methods=['POST'])
def get_program_hero_image_list():
    '''
    Query the simian-media collection to return all appropriate
    imageLandscape and imagePortrait images for a list of programs


    imageLandscape: tags in document must include --> Horizontal, Photo, Hero
    imagePortrait: tags in document must include --> Vertical, Photo, Hero
    '''

    data = request.get_json()
    if '_ids' not in data:
        abort(404, description='No _ids found in body')

    program_ids = data.get('_ids')

    program_docs = list(get_documents('mm_programs', {'_id' : {'$in' : [ObjectId(_id) for _id in program_ids]}},
                                      projection=PROGRAM_PROJECTION))

    programs_images = {}
    for program in program_docs:

        program_id = str(program.get('_id'))
        if not validate_object_id_with_collection(program_id, 'mm_programs'):
            abort(404, description='Program id not found: ' + program_id)

        images = get_hero_images(program_id, program)

        programs_images[program_id] = {
            'imageLandscape': images['landscape'],
            'imagePortrait': images['portrait'],
        }

    return jsonify(programs_images)



def get_hero_images(program_id, program):
    '''
    Get hero images for a given program
    '''
    query = {
        'credits.program_id': str(program_id),
        # decrease number of documents return to be filtered by type below
        '$text': {'$search': 'Photo Hero'}
    }
    documents = list(get_documents('simian_media', query, projection=default_media_projection))

    landscape = None
    portrait = None

    if documents:
        filtered_landscape = get_filtered_document(documents, ['horizontal', 'photo', 'hero'])
        filtered_portrait = get_filtered_document(documents, ['vertical', 'photo', 'hero'])

        if filtered_landscape:
            landscape = get_assets(filtered_landscape)
        if filtered_portrait:
            portrait = get_assets(filtered_portrait)

    if landscape is None:
        landscape = {
            'media': program.get('imageLandscape', '')
        }
    if portrait is None:
        portrait = {
            'media': program.get('imagePortrait', '')
        }

    return {
        'landscape': landscape,
        'portrait': portrait,
    }
