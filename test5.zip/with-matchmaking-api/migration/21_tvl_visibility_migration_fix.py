from matchmaking import db

tvlVisibilityObj = {'accessAndAffordability': True,
                    'businessEthicsAndTransparencyOfPayments': True,
                    'humanRightsAndCommunityRelations': True,
                    'biodiversityImpacts': True,
                    'gHGEmissions': True}

db().coll_brands.update_many({'tvlVisibility': {'$exists': True}}, {'$set': {'tvlVisibility': tvlVisibilityObj}})