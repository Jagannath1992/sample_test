from matchmaking import db


db().coll_nonprofits.update_many(filter={'registeredCountry': {'$exists': False}}, update={'$set': {'registeredCountry': ''}})

nonprofits = list(db().coll_nonprofits.find())
maps = {}
for n in nonprofits:
    maps[n['_id']] = n['registeredCountry']

deals = list(db().coll_deals.find({'selectedRecommendedPrograms': {'$exists': True}}))
for deal in deals:
    for program in deal['selectedRecommendedPrograms']:
        nonprofit_id = program['nonprofit']
        if nonprofit_id in maps:
            register_country = maps[nonprofit_id]
            program['registeredCountry'] = register_country

    db().coll_deals.update_one({'_id': deal['_id']}, {'$set': deal})
