import functools
import pytest
from matchmaking import auth, utils


def authenticator_a(func):
    @functools.wraps(func)
    def wrapper(*args, **kws):
        if args[0] == 'valid_1':
            return func(*args, **kws)

        raise utils.GivewithError('Unauthorized', code=401)
    return wrapper


def authenticator_b(func):
    @functools.wraps(func)
    def wrapper(*args, **kws):
        if args[0] == 'valid_2':
            return func(*args, **kws)

        raise utils.GivewithError('Forbidden', code=403)
    return wrapper


def test_authenticate_with_one_of():
    @auth.authenticate_with_one_of(authenticator_a, authenticator_b)
    def test_function(value):
        return value

    assert test_function('valid_1') == 'valid_1'
    assert test_function('valid_2') == 'valid_2'

    with pytest.raises(utils.GivewithError):
        test_function('invalid_1')


def test_authenticate_with_one_of_allow_function_exceptions_through():
    @auth.authenticate_with_one_of(authenticator_a, authenticator_b)
    def test_function(value):
        raise ValueError()

    with pytest.raises(utils.GivewithError):
        test_function('invalid_1')

    with pytest.raises(ValueError):
        test_function('valid_1')
