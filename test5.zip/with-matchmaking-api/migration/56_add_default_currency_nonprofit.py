from matchmaking import db

db().coll_nonprofits.update_many(filter={'operationalInformation.yearlyBudgetCurrency':{'$exists': False}}, update={'$set': {'operationalInformation.yearlyBudgetCurrency': 'USD'}})