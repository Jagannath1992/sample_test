from bson import ObjectId
from typing import List, Any, Dict, Tuple

from portal.shared.dates import get_formatted_utc_string
from portal.shared.repository import DocumentRepository


class InstanceSettingsRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['instance_settings'])

    def get_page(self, filters: Dict[str, Any], add_fields: dict={}) -> Tuple[int, List[Any]]:
        """ Overides the default get_page method to add a calculated field for causeAreaCount """
        add_fields = {
            'causeAreaCount': {'$size': '$causeAreas'}
        }
        return DocumentRepository.get_page(self, filters, add_fields)

    def get_associated(self, cause_id) -> dict:
        instances = self.collection.aggregate([
            {'$unwind': '$causeAreas'},
            {'$match': {'causeAreas.causeArea._id': ObjectId(cause_id)}},
            {'$project': {'name': 1, 'causeAreas.causeArea.name': 1, 'causeAreas.assignedDate': 1}}
        ])
        result = {
            'ID': {},
            'Instance': {},
            'Cause Area': {},
            'Assigned Date': {},
        }
        counter = 0
        for instance in list(instances):
            result['ID'][counter] = instance['_id']
            result['Instance'][counter] = instance['name']
            result['Cause Area'][counter] = instance['causeAreas']['causeArea']['name']
            result['Assigned Date'][counter] = get_formatted_utc_string(instance['causeAreas']['assignedDate'])
            counter += 1
        return result

    def get_count_by_locale(self):
        result = self.collection.aggregate([
            {"$group": {"_id": "$settings.locale.name", "total": {"$sum": 1 }}}
        ])
        return result

    def get_count_by_area(self):
        result = self.collection.aggregate([
            {"$unwind": {"path": "$causeAreas"}},
            {"$group": {"_id": "$causeAreas.causeArea.name", "total": {"$sum": 1}}}
        ])
        return result

    def populate_locale_instance_counts(self, locales):
        instance_counts = list(self.get_count_by_locale())
        _populate_list(locales, instance_counts)

    def populate_cause_area_instance_counts(self, cause_areas):
        instance_counts = list(self.get_count_by_area())
        _populate_list(cause_areas, instance_counts)


def _get_instance_count(items: list, instance_count: list):
    '''
    This method updates the instance count within a list of items
    This instance count is the number of instances using the related item
    '''
    for item in items:
        for inst_count in instance_count:
            if item['name'] in inst_count:
                val = item['name']
                item['instanceCount'] = inst_count[val]['total']


def _get_instance_count_map(items):
    mapper = [{x['_id']: x} for x in items]
    return mapper


def _populate_list(items, instance_counts):
    instance_count_mapper = _get_instance_count_map(instance_counts)
    _get_instance_count(items, instance_count_mapper)
