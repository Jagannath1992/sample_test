from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from airflow.operators.docker_operator import DockerOperator
from airflow.operators.python_operator import BranchPythonOperator
from airflow.operators.dummy_operator import DummyOperator
from docker.types import Mount
from airflow.models import Variable

default_args = {
    'owner': 'GiveWith',
    'description': 'WITH-ETL NIELSEN JOB',
    'depend_on_past': False,
    'start_date': datetime(2021, 5, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5)
}

ETL_SOURCE = "NIELSEN"
ENV = Variable.get("ENV")
MONGO_URL = Variable.get("MONGO_URL")
MONGO_DATABASE = Variable.get("MONGO_DATABASE")
TVL_HOST_KEY_TYPE = Variable.get("TVL_HOST_KEY_TYPE")
TVL_HOST_KEY = Variable.get("TVL_HOST_KEY")
TVL_PASSWORD = Variable.get("TVL_PASSWORD")
TVL_URL = Variable.get("TVL_URL")
TVL_USERNAME = Variable.get("TVL_USERNAME")
RESEARCH_API_BUCKET = Variable.get("RESEARCH_API_BUCKET")
RESEARCH_API_URL = Variable.get("RESEARCH_API_URL")
S3_ASSETS_BUCKET = Variable.get("S3_ASSETS_BUCKET")
SASB_S3_KEY = Variable.get("SASB_S3_KEY")
SASB_S3_KEY_TOPICS = Variable.get("SASB_S3_KEY_TOPICS")
SASB_S3_KEY_TOPICS_MATERIALITY_MAP = Variable.get("SASB_S3_KEY_TOPICS_MATERIALITY_MAP")
CSRHUB_S3_KEY = Variable.get("CSRHUB_S3_KEY")
NIELSEN_S3_KEY = Variable.get("NIELSEN_S3_KEY")
MSCI_API_ESG_ENDPOINT = Variable.get("MSCI_API_ESG_ENDPOINT")
MSCI_API_KEY = Variable.get("MSCI_API_KEY")
MSCI_API_SECRET = Variable.get("MSCI_API_SECRET")
BRAND_DEDUP_SLACK_URL = Variable.get("BRAND_DEDUP_SLACK_URL")
AWS_ACCESS_KEY_ID = Variable.get("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = Variable.get("AWS_SECRET_ACCESS_KEY")
SIMIAN_TOKEN = Variable.get("SIMIAN_TOKEN")
AIRFLOW_ALERTS_SLACK_URL=Variable.get("AIRFLOW_ALERTS_SLACK_URL")
ENABLE_SLACK_ALERTS=Variable.get("ENABLE_SLACK_ALERTS")

with DAG('with-etl-nielsen-dag', default_args=default_args, schedule_interval=None, catchup=False, max_active_runs=1) as dag:
    start_dag = DummyOperator(
        task_id='start_dag'
    )

    end_dag = DummyOperator(
        task_id='end_dag'
    )

    t1 = DockerOperator(
        task_id='with-etl-nielsen-task',
        image='932027492231.dkr.ecr.us-east-1.amazonaws.com/with-etl:latest',
        container_name='with-etl-load-nielsen-data',
        api_version='auto',
        auto_remove=True,
        environment={
                'ETL_SOURCE': ETL_SOURCE,
                'ENV': ENV,
                'MONGO_URL': MONGO_URL,
                'MONGO_DATABASE': MONGO_DATABASE,
                'TVL_HOST_KEY_TYPE': TVL_HOST_KEY_TYPE,
                'TVL_HOST_KEY': TVL_HOST_KEY,
                'TVL_PASSWORD': TVL_PASSWORD,
                'TVL_URL': TVL_URL,
                'TVL_USERNAME': TVL_USERNAME,
                'RESEARCH_API_BUCKET': RESEARCH_API_BUCKET,
                'RESEARCH_API_URL': RESEARCH_API_URL,
                'S3_ASSETS_BUCKET': S3_ASSETS_BUCKET,
                'SASB_S3_KEY': SASB_S3_KEY,
                'SASB_S3_KEY_TOPICS': SASB_S3_KEY_TOPICS,
                'SASB_S3_KEY_TOPICS_MATERIALITY_MAP': SASB_S3_KEY_TOPICS_MATERIALITY_MAP,
                'CSRHUB_S3_KEY': CSRHUB_S3_KEY,
                'NIELSEN_S3_KEY': NIELSEN_S3_KEY,
                'MSCI_API_ESG_ENDPOINT': MSCI_API_ESG_ENDPOINT,
                'MSCI_API_KEY': MSCI_API_KEY,
                'MSCI_API_SECRET': MSCI_API_SECRET,
                'BRAND_DEDUP_SLACK_URL': BRAND_DEDUP_SLACK_URL,
                'AWS_ACCESS_KEY_ID': AWS_ACCESS_KEY_ID,
                'AWS_SECRET_ACCESS_KEY': AWS_SECRET_ACCESS_KEY,
                'SIMIAN_TOKEN': SIMIAN_TOKEN,
                'AIRFLOW_ALERTS_SLACK_URL': AIRFLOW_ALERTS_SLACK_URL,
                'ENABLE_SLACK_ALERTS': ENABLE_SLACK_ALERTS
        },
        docker_url='tcp://docker-proxy:2375',
        network_mode="bridge"
    )

    t2 = BashOperator(
        task_id='sendEmail',
        bash_command='echo "Email sent done!!"'
    )

    start_dag >> t1
    t1 >> t2
    t2 >> end_dag
