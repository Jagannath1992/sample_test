import pymongo
from datetime import datetime
"""
Update Instance settings with cause areas and skus
"""
name = '20220702181438'
dependencies = ['20220623202116']


def upgrade(db: pymongo.database.Database):
    instance_name = 'Givewith for Sales'
    cause_areas = list()
    cause_area_cursor = db['cause_area'].find()
    i = 1
    for record in cause_area_cursor:
        cause_area_rec = {
            "_id": record["_id"],
            "_type": "cause_area",
            "name": record["name"]
        }
        impact_rec = {
            'unitPrice': record['calculation']['unitPrice'],
            'unitValue': record['calculation']['unitValue'],
            'impactMeasurement': record['calculation']['uom']
        }
        cause_area = {
            "causeArea": cause_area_rec,
            "impact": impact_rec,
            "displayOrder": i,
            "active": True
        }
        cause_areas.append(cause_area)
        i += 1

    db['instance_settings'].find_one_and_update(
        {'name': instance_name},
        {'$set': {
            'causeAreas': cause_areas,
            'skus': [100, 1000, 10000],
            'active': True
        }
        }
    )


def downgrade(db: pymongo.database.Database):
    pass
