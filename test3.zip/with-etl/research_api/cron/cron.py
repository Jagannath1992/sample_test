import yaml
import os
from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler
from research_api.cron import job_handler


def init():
    scheduler = BackgroundScheduler()

    __location__ = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))
    with open(os.path.join(__location__, 'config.yaml')) as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
        config_jobs = config.get('jobs')

        for config in config_jobs:
            enable = bool(config.get('enable'))
            if not enable:
                continue

            func_name = getattr(job_handler, str(config.get('func_name')))
            frequency = config.get('frequency')
            second = frequency.get('second')

            scheduler.add_job(id=config.get('func_name'), func=func_name, trigger="interval", seconds=second,
                              next_run_time=datetime.now(), replace_existing=True)

    return scheduler
