# pylint: disable=redefined-outer-name
from datetime import datetime, timedelta
from os import environ

import jwt
import pytest
from keyczar import keyczar
from pymongo import TEXT, MongoClient

import data
from app import create_app


DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
TOKEN_PRIVATE_KEY = ('Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy'
                     '6ok78k6SKl3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')
CRYPTER = keyczar.Crypter.Read('keys')


@pytest.fixture(scope='session')
def client(test_db):
    '''
    Configure tests
    '''
    app = create_app(test_db)
    client = app.test_client()

    load_testing_data(test_db)

    ctx = app.app_context()
    ctx.push()

    yield client
    ctx.pop()


@pytest.fixture(scope='session')
def test_db():
    '''
    Create database to test with
    '''
    test_db_url = environ.get('TEST_DB_URL', 'mongodb://localhost:27017/')
    db_client = MongoClient(test_db_url)

    db = db_client['simian_test_db']

    db.simian_media.create_index([('tags', TEXT)])

    load_initial_data(db)

    yield db
    db_client.drop_database('simian_test_db')


# tokens
@pytest.fixture(scope='session')
def admin_token():
    '''
    Generate an admin token
    '''
    now = datetime.now().timestamp()
    hour_later = (datetime.utcnow() + timedelta(hours=1)).timestamp()

    claims = {**data.admin_token, 'auth_time': now, 'exp': hour_later}

    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture(scope='session')
def client_token():
    '''
    Generate an client token
    '''
    now = datetime.now().timestamp()
    hour_later = (datetime.utcnow() + timedelta(hours=1)).timestamp()

    claims = {**data.client_token, 'auth_time': now, 'exp': hour_later}

    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture()
def client_token_with_dept(department):
    '''
    Generate an client token with a dynamic department
    '''
    now = datetime.now().timestamp()
    hour_later = (datetime.utcnow() + timedelta(hours=1)).timestamp()

    claims = {**data.client_token, 'auth_time': now, 'exp': hour_later, 'departmentType': department}

    return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


@pytest.fixture()
def deal_token(slug, password):
    '''
    Generate a deal token
    '''
    password_digest = f'{password}/password'
    expires = (datetime.utcnow() + timedelta(hours=1)).strftime(DATETIME_FORMAT)

    return CRYPTER.Encrypt('/'.join((password_digest, slug, expires)))


@pytest.fixture()
def client_user():
    return data.client_token


# headers
@pytest.fixture()
def admin_header(admin_token):
    '''
    Headers with admin token
    '''
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': admin_token,
    }


@pytest.fixture()
def client_header(client_token):
    '''
    Headers with client token
    '''
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': client_token,
    }

@pytest.fixture()
def deal_header(deal_token):
    '''
    Headers with a deal token
    '''
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': deal_token
    }


@pytest.fixture()
def client_header_with_dept(client_token_with_dept):
    '''
    Headers with client token
    '''
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': client_token_with_dept,
    }


@pytest.fixture()
def invalid_header():
    '''
    Headers with invalid token
    '''
    return {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'aaa.bbb.ccc',
    }


# load initial data
def load_initial_data(db):
    '''
    Add initial user data to authenticate tokens
    '''
    db.user.insert_one(data.user)


#  load test data
def load_testing_data(db):
    '''
    Add data to test
    '''
    db.mm_nonprofits.insert_many(data.nonprofits)
    db.mm_programs.insert_many(data.programs)
    db.simian_media.insert_many(data.media)
    db.deals.insert_many(data.deals)
    db.share_actions.insert_many(data.share_actions)
