# Givewith auth service

![Build Status](https://codebuild.us-east-1.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiRFZOaDJ3VWFIcGFtZHJTYXVrWGFjYTYwdnNmN1EyMERaVUxzT1NaSjFqTlhFc2JyUzRxNmRibklQQlQ3VEJZV0VEdS93aXRyTjJBeldCOUt1Qit4QllFPSIsIml2UGFyYW1ldGVyU3BlYyI6IlB5RVFhQXVieGd2TmhMRWQiLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=develop)

This service provides authentication services [Admin API](https://github.com/EcoMedia/givewith-pyadmin-api) 
and [Matchmaking API](https://github.com/EcoMedia/givewith-matchmaking-api).
This service exposes a REST interface for querying the access permissions for user or refresh tokens, and is
implemented based on [The OAuth 2.0 Authorization Framework](https://tools.ietf.org/html/rfc6749) with grant type 
[Resource Owner Password Credentials](https://tools.ietf.org/html/rfc6749#section-1.3.3)

## API documentation
[documentation](https://givewith-internal-apidoc.s3.amazonaws.com/auth-apidoc/index.html)
built with http://apidocjs.com


## System Logging and Audit Logging

As a part of our security practice, we are now capturing log-in information to be able to manually audit user
access and sessions, if needed.  This data is explicitly set via sending data to the 
[loggly service](givewith.loggly.com) via code such as this:

`send_loggly("authorize user: " + request.json.get('username'))` in `authorize.py`

These logs should not receive any secure data (i.e. unencrypted passwords!), but PII of this nature (names, contact info)
will be rotated out of storage (deleted) at pre-defined intervals (~30 days).  Note that Loggly is receiving all
`syslog` data, thus, as always, you are cautioned to be congnizant of what does/doesn't get logged.  

