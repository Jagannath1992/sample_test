import pytest

from datetime import datetime

from portal.shared.dates import get_utcnow
from portal.shared.enums import OrderStatus


@pytest.fixture
def init_test_data(fakers):
    cause_areas = fakers.cause_area.insert_many(2)

    gives = [
        {'status': OrderStatus.PENDING_APPROVAL.value, 'lastUpdated': _to_date('2022-01-01'), 'quoteAmount': 1000.00, 'grandTotal': 100.00}, # 10%
        {'status': OrderStatus.PENDING_APPROVAL.value, 'lastUpdated': _to_date('2022-02-01'), 'quoteAmount': 1500.00, 'grandTotal': 450.00}, # 30%

        {'status': OrderStatus.APPROVED.value, 'lastUpdated': _to_date('2022-03-01'), 'quoteAmount': 2000.00, 'grandTotal': 400.00}, # 20%
        {'status': OrderStatus.APPROVED.value, 'lastUpdated': _to_date('2022-04-01'), 'quoteAmount': 2500.00, 'grandTotal': 500.00}, # 20%

        {'status': OrderStatus.COMPLETED.value, 'lastUpdated': _to_date('2022-05-01'), 'quoteAmount': 3000.00, 'grandTotal': 300.00}, # 10%
        {'status': OrderStatus.COMPLETED.value, 'lastUpdated': _to_date('2022-06-01'), 'quoteAmount': 4000.00, 'grandTotal': 800.00}, # 20%
    ]

    locale_us = fakers.locale.insert_single()
    instance_us = fakers.instance_settings.insert_single({
        'settings': {'locale': _to_ref('locale', locale_us)},
        'causeAreas': _to_instance_cause_areas(cause_areas)
    })
    account_us = fakers.account.insert_single({'instance': _to_ref('instance_settings', instance_us)})
    orders_us = _create_orders(fakers, locale_us, instance_us, account_us, gives)
    us = {
        'locale': locale_us,
        'instance': instance_us,
        'account': account_us,
        'orders': orders_us,
    }

    locale_uk = fakers.locale.insert_single({'name': 'UK', 'settings': {'currency': 'GBP', 'symbol': '£'}})
    instance_uk = fakers.instance_settings.insert_single({
        'settings': {'locale': _to_ref('locale', locale_uk)},
        'causeAreas': _to_instance_cause_areas(cause_areas)
    })
    account_uk = fakers.account.insert_single({'instance': _to_ref('instance_settings', instance_uk)})
    orders_uk = _create_orders(fakers, locale_uk, instance_uk, account_uk, gives)
    uk = {
        'locale': locale_uk,
        'instance': instance_uk,
        'account': account_uk,
        'orders': orders_uk,
    }

    return us, uk


def _to_ref(type: str, entity: dict) -> dict:
    return {'_id': entity['_id'], '_type': type, 'name': entity.get('name')}


def _to_instance_cause_areas(cause_areas: list) -> list:
    now = get_utcnow()
    return [{
        'causeArea': _to_ref('cause_area', c),
        'skus': [],
        'displayOrder': 1,
        'active': True,
        'impact': {
            'unitPrice': 100,
            'unitValue': 10,
            'impactMeasurement': 'meals'
        },
        'assignedDate': now
    } for c in cause_areas]


def _create_orders(fakers, locale: dict, instance: dict, account: dict, gives: list) -> list:
    account_ref = _to_ref('account', account)
    cause_areas = [{'impact': c['impact'], **c['causeArea']} for c in instance['causeAreas']]
    orders = []

    for cause_area in cause_areas:
        for give in gives:
            totalValue = give['grandTotal'] / cause_area['impact']['unitPrice'] * cause_area['impact']['unitValue']
            cause_area['impact']['totalValue'] = totalValue

            order = fakers.order.insert_single({
                'account': account_ref,
                'causeArea': cause_area,
                'currency': locale['settings']['currency'],
                'comments': _get_comments(give['status']),
                **give
            })

            orders.append(order)

    return orders


def _get_comments(status: str):
    statuses = [OrderStatus.PENDING_APPROVAL, OrderStatus.APPROVED, OrderStatus.COMPLETED]
    comments = []
    old_status = ''

    for new_status in statuses:
        comments.append({'comment': '', 'oldStatus': old_status, 'newStatus': new_status.value})
        old_status = new_status.value

        # stop when we get to the desired status
        if old_status == status:
            break

    return comments


def _to_date(value: str):
    return datetime.fromisoformat(value)
