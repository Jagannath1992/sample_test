import pandas as pd

from datetime import datetime

from research_api.fetchers.fetchers import fetch
from research_api.transformers.transformers import transform
from research_api.validators import clean
from research_api.mongodb import db, get_gics_industry
from research_api.utils import GivewithError, generate_random_slug


DATASETS = ['SASB', 'MSCI', 'CSRHUB', 'TVL', 'CSRIT', 'NIELSEN']

NAME_KEY_MAP = {
    'TVL': 'companyName',
    'SASB': 'Company',
    'CSRHUB': 'CSRHub Official Name',
    'MSCI': 'issuerName',
}

INDUSTRY_KEY_MAP = {
    'SASB': 'SICS Codified Industry ',  # The space is intentional
    'CSRHUB': 'Primary Industry'
}

def batch_create_new_brands():
    """
    Finds and creates brands from a dataset that are currenlty not in `mm_brands`
    If `new_brand_names` is given, only the given brands will be uploaded
    """

    # EXAMPLE ONLY
    json = {"dataset": "MSCI", "new_brand_names": "Test"}
    
    if not json:
        raise GivewithError('Missing parameter: dataset')

    dataset = json.get('dataset', '').upper()
    if dataset not in DATASETS:
        raise GivewithError('Incorrect dataset')

    new_brand_names = json.get('new_brand_names', '')
    if isinstance(new_brand_names, str):
        new_brand_names = [new_brand_names]

    data = {}
    for stage in [fetch, clean, transform]:
        data = stage(dataset, data)

    # MSCI currently returns as a dict from transform
    if dataset == 'MSCI':
        data = pd.DataFrame.from_dict(data)

    # If new_brands was passed, filter to get only these brands
    if new_brand_names:
        name_key = NAME_KEY_MAP.get(dataset, 'name')
        data = data.loc[data[name_key].isin(new_brand_names)]

    # Convert dataframes to dicts
    if dataset in ['SASB', 'CSRHUB', 'MSCI']:
        data = data.to_dict('records')
    elif dataset == 'TVL':
        data = data[0][1].to_dict('records')

    # Upload new brands
    success = []
    failed = []
    count = 0
    for doc in data:
        try:
            count += 1
            if count % 10000 == 0:
                print(f'{count}: {len(success)} : {len(failed)}')
            success.append(create_new_brand(dataset, doc))
        except Exception as e:
            failed.append({'data': doc, 'error': str(e)})

def create_new_brand(dataset, brand):
    """
    Method currently checked too work with: SASB, TVL, CSRHub
    """
    # Normalize `name` field
    name_key = NAME_KEY_MAP.get(dataset)
    if name_key:
        brand['name'] = brand[name_key]

    # Normalize `industry` field
    industry_key = INDUSTRY_KEY_MAP.get(dataset)
    if industry_key:
        brand['industry'] = get_gics_industry(brand[industry_key], dataset)

    if 'ISIN' not in brand or 'name' not in brand or 'industry' not in brand:
        raise GivewithError('Incomplete brand: missing ISIN, name, or industry')

    # Check if ISIN already exists in the DB
    brand_isin_match = db().coll_brands.find_one({'ISIN': brand['ISIN']})
    if brand_isin_match:
        raise GivewithError('ISIN already exists')

    # Check if name already exists in the DB
    brand_name_match = db().coll_brands.find_one({'name': brand['name']})
    if brand_name_match:
        raise GivewithError('Name already exists')

    # If neither are found in the DB, create the brand
    brand_obj = _get_brand_obj(brand['ISIN'], brand['name'], brand.get('nameLabel', ''), brand['industry'], dataset)
    result = db().coll_brands.insert_one(brand_obj)

    if result:
        return str(result.inserted_id)
    else:
        raise GivewithError('Error inserting brand')


def _get_brand_obj(isin, name, name_label, industry, dataset):
    # copied from mm-api's create_search_string()
    search_string = name + (name_label and (' ' + name_label)).lower()

    return {
        'ISIN': isin,
        'name': name,
        'iname': name.lower(),
        'slug': generate_random_slug(),
        'industry': industry,
        'source': dataset,
        'lastUpdated': datetime.utcnow(),
        'createdAt': datetime.utcnow(),
        'searchString': search_string,
        'givePercentageType': 'default',
    }

