from ddtrace import config, patch_all
from os import environ

def init_datadog():
    env = environ.get('FLASK_ENV', 'local')
    config.env = env
    config.service = "portal"
    config.version = "0.1"
    patch_all()
