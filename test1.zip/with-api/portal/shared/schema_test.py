from marshmallow import ValidationError
import pytest
from bson import ObjectId
from portal.shared.repositories import account_repository, cause_area_repository, order_repository, locale_repository

from portal.shared.schema import AccountReferenceSchema, CauseAreaReferenceSchema, OrderReferenceSchema, LocaleReferenceSchema


class TestAccountReferenceSchema:
    @pytest.fixture()
    def schema(self):
        return AccountReferenceSchema()

    @pytest.fixture()
    def request_data(self, mocker):
        mocker.patch.object(account_repository(), 'exists', return_value=True)
        return {
            'id': str(ObjectId()),
            'name': 'Account'
        }

    def test_validate(self, schema, request_data):
        # arrange

        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_validate_id(self, mocker, schema, request_data):
        # arrange
        mocker.patch.object(account_repository(), 'exists', return_value=False)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'id': ['Account does not exist']}


class TestOrderReferenceSchema:
    @pytest.fixture()
    def schema(self):
        return OrderReferenceSchema()

    @pytest.fixture()
    def request_data(self, mocker):
        mocker.patch.object(order_repository(), 'exists', return_value=True)
        return {
            'id': str(ObjectId()),
            'name': 'Order'
        }

    def test_validate(self, schema, request_data):
        # arrange

        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_validate_id(self, mocker, schema, request_data):
        # arrange
        mocker.patch.object(order_repository(), 'exists', return_value=False)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'id': ['Order does not exist']}


class TestCauseAreaReferenceSchema:
    @pytest.fixture()
    def schema(self):
        return CauseAreaReferenceSchema()

    @pytest.fixture()
    def request_data(self, mocker):
        mocker.patch.object(cause_area_repository(), 'exists', return_value=True)
        return {
            'id': str(ObjectId()),
            'name': 'Cause Area'
        }

    def test_validate(self, schema, request_data):
        # arrange

        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_validate_id(self, mocker, schema, request_data):
        # arrange
        mocker.patch.object(cause_area_repository(), 'exists', return_value=False)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'id': ['Cause Area does not exist']}

class TestLocaleReferenceSchema:
    @pytest.fixture()
    def schema(self):
        return LocaleReferenceSchema()

    @pytest.fixture()
    def request_data(self, mocker):
        mocker.patch.object(locale_repository(), 'exists', return_value=True)
        return {
            'id': str(ObjectId()),
            'name': 'locale'
        }

    def test_validate(self, schema, request_data):
        # arrange

        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_validate_id(self, mocker, schema, request_data):
        # arrange
        mocker.patch.object(locale_repository(), 'exists', return_value=False)

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'id': ['Locale does not exist']}
