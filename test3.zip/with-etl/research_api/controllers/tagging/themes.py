# pylint: disable=line-too-long, missing-docstring, invalid-name, wildcard-import, unused-wildcard-import, too-many-branches, too-many-statements, too-many-boolean-expressions, unused-import
from .utils import check_term, init_tagging, add_feature, save_program_document, \
    SELECTED_VOCABULARY_VERSION, critical_alert
from .constants import *

def tag_themes(document, vocabulary):
    # here is where we're modifying data on records
    # what's our general approach?  well - let's load up the mm_vocabulary object into this hash named vocabulary
    # then we pass that and the given document (program record) together to output a stringified - meaning: readable
    # version of the document.
    log = list()
    _MY_SOURCE = VOCAB_THEMES

    try:

        tag_data = init_tagging(document, vocabulary, log, _MY_SOURCE)

        # NOW START TURNING THE RULES INTO CODE

        # Rule 1: Aging Populations
        log.append("  1 - ")
        if check_term(ELDERLY_POPULATIONS_65_, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, AGING_POPULATIONS, tag_data)
        log.append("----")

        # Rule 2: Animal Welfare
        log.append(" 2 - ")
        if check_term(PROTECT_ANIMAL_WELFARE, VOCAB_IMPACTS, tag_data) or \
            check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data):
            add_feature(_MY_SOURCE, ANIMAL_WELFARE, tag_data)
        log.append("____")

        # Rule 3: Arts and Culture
        log.append(" 3 - ")
        if check_term(ARTS_AND_CULTURE, VOCAB_CAUSES, tag_data):
            add_feature(_MY_SOURCE, ARTS_AND_CULTURE, tag_data)
        log.append("____")

        # Rule 4: Criminal Justice
        log.append(" 4 - ")
        if check_term(CRIMINAL_JUSTICE, VOCAB_CAUSES, tag_data) or \
                (check_term(REDUCE_CRIMINAL_ACTIVITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CRIMINAL_RECIDIVISM, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, CRIMINAL_JUSTICE, tag_data)
        log.append("____")

        # Rule 5: Disaster Response, Relief and Recovery
        log.append(" 5 - ")
        if check_term(DISASTER_RESPONSE__RELIEF_AND_RECOVERY, VOCAB_CAUSES, tag_data) or \
            check_term(IMPROVE_CONDITIONS_AFTER_NATURAL_DISASTERS_AND_CRISES, VOCAB_IMPACTS, tag_data):
            add_feature(_MY_SOURCE, DISASTER_RESPONSE__RELIEF_AND_RECOVERY, tag_data)
        log.append("____")

        # Rule 6: Diversity and Inclusion
        log.append(" 6 - ")
        if (check_term(PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
            check_term(PEOPLE_WITH_SPECIAL_NEEDS, VOCAB_AUDIENCES, tag_data) or \
            check_term(LGBTQQIA_, VOCAB_AUDIENCES, tag_data) or \
            check_term(PEOPLE_OF_COLOR, VOCAB_AUDIENCES, tag_data) or \
            check_term(WOMEN_AND_GIRLS, VOCAB_AUDIENCES, tag_data) or \
            check_term(REFUGEES_DISPLACED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
            check_term(IMMIGRANTS, VOCAB_AUDIENCES, tag_data) or \
            check_term(INDIGENOUS_PEOPLES, VOCAB_AUDIENCES, tag_data)) and \
            (check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_CIVIC_PARTICIPATION, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
            check_term(ENSURE_21ST_CENTURY_SKILLS_PROFICIENCY, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_ACCESS_TO_QUALITY_EDUCATION_PROGRAMS_AND_SERVICES, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, DIVERSITY_AND_INCLUSION, tag_data)
        log.append("____")

        # Rule 7: Economic Empowerment
        log.append(" 7 - ")
        if check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
                (check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, ECONOMIC_EMPOWERMENT, tag_data)
        log.append("_____")

        # Rule 8: Education
        log.append(" 8 - ")
        if check_term(EDUCATION, VOCAB_CAUSES, tag_data) or \
                (check_term(ENSURE_21ST_CENTURY_SKILLS_PROFICIENCY, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY_EDUCATION_PROGRAMS_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_ACADEMIC_ACHIEVEMENT, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, EDUCATION, tag_data)
        log.append("_____")

        # Rule 9: Environment
        log.append(" 9 - ")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) or \
                (check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ANIMAL_WELFARE, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, ENVIRONMENT, tag_data)
        log.append("_____")

        # Rule 10: Food and Hunger
        log.append(" 10 - ")
        if check_term(FOOD_AND_HUNGER, VOCAB_CAUSES, tag_data) or \
                (check_term(REDUCE_HUNGER_AND_MALNUTRITION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_NUTRITIOUS_FOOD, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_POTABLE_WATER, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_FOOD_SYSTEMS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_SUSTAINABLE_WATER_SYSTEMS, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, FOOD_AND_HUNGER, tag_data)
        log.append("_____")

        # Rule 11: Housing and Homelessness
        log.append(" 11 - ")
        if check_term(HOUSING_AND_HOMELESSNESS, VOCAB_CAUSES, tag_data) or \
                (check_term(REDUCE_HOMELESSNESS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_AMOUNT_AND_ACCESS_TO_QUALITY_AFFORDABLE_HOUSING, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, HOUSING_AND_HOMELESSNESS, tag_data)
        log.append("_____")

        # Rule 12 Human Rights and Civil Engagement
        log.append(" 12 - ")
        if check_term(HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, VOCAB_CAUSES, tag_data) or \
                (check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PEACE_THROUGH_CONFLICT_RESOLUTION, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_CIVIC_PARTICIPATION, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, tag_data)
        log.append("_____")


        # Rule 13 Health and Wellness
        log.append(" 13 - ")
        if check_term(HEALTH_AND_WELLNESS, VOCAB_CAUSES, tag_data) or \
                (check_term(REDUCE_DISEASE_IMPROVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_ACCESS_TO_QUALITY__AFFORDABLE_HEALTHCARE_AND_SERVICES, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_REPRODUCTIVE_HEALTH, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_RISKY_AND_ADDICTIVE_BEHAVIORS, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_TRAUMA, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, HEALTH_AND_WELLNESS, tag_data)
        log.append("_____")


        # Rule 14 Immigrants
        log.append(" 14 - ")
        if check_term(IMMIGRANTS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, IMMIGRANTS, tag_data)
        log.append("____")


        # Rule 15 Indigenous peoples
        log.append(" 15 - ")
        if check_term(INDIGENOUS_PEOPLES, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, INDIGENOUS_PEOPLES, tag_data)
        log.append("____")


        # Rule 16 LGBTQQIA+
        log.append(" 16 - ")
        if check_term(LGBTQQIA_, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, LGBTQQIA_, tag_data)
        log.append("____")

        # Rule 17 Poverty Alleviation
        log.append(" 18 - ")
        if check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, POVERTY_ALLEVIATION, tag_data)
        log.append("____")

        # Rule 18 People of Color
        log.append(" 19 - ")
        if check_term(PEOPLE_OF_COLOR, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, PEOPLE_OF_COLOR, tag_data)
        log.append("____")


        # Rule 19 People with Disabilities
        log.append(" 19 - ")
        if check_term(PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
            check_term(PEOPLE_WITH_SPECIAL_NEEDS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, tag_data)
        log.append("____")

        # Rule 20 Refugees
        log.append(" 20 - ")
        if check_term(REFUGEES_DISPLACED_PERSONS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, REFUGEES, tag_data)
        log.append("____")

        # Rule 21 Veterans
        log.append(" 21 - ")
        if check_term(VETERANS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, VETERANS, tag_data)
        log.append("_____")

        # Rule 22 Women and Girls
        log.append(" 22 - ")
        if check_term(WOMEN_AND_GIRLS, VOCAB_AUDIENCES, tag_data):
            add_feature(_MY_SOURCE, WOMEN_AND_GIRLS, tag_data)
        log.append("_____")

        # Rule 23 Youth Development
        if check_term(EDUCATION, VOCAB_CAUSES, tag_data) and \
                (check_term(AGE_0_5_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                 check_term(AGE_6_12_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                 check_term(AGE_13_18_YEARS_OLD, VOCAB_AUDIENCES, tag_data) or \
                 check_term(AGE_19_24_YEARS_OLD, VOCAB_AUDIENCES, tag_data)):
            add_feature(_MY_SOURCE, YOUTH_DEVELOPMENT, tag_data)


        log.append("  Summary: " + ', '.join(document[_MY_SOURCE]["strings"]))

        # now put the version number into the same object
        document[_MY_SOURCE]["tagging-version"] = SELECTED_VOCABULARY_VERSION

        # cool!  save that object back and go!
        save_program_document(document)

    except Exception as eee:
        critical_alert(eee, log, "vocab_error_in_tagging")
        raise eee

    return log
