# pylint: disable=line-too-long, missing-docstring, invalid-name, wildcard-import, unused-wildcard-import, too-many-boolean-expressions
from .constants import *
from .utils import check_term, init_tagging, add_feature, \
    save_program_document, SELECTED_VOCABULARY_VERSION, \
    critical_alert


def tag_csrhub(document, vocabulary):
    # here is where we're modifying data on records
    # what's our general approach?  well - let's load up the mm_vocabulary object
    # into this hash named vocabulary then we pass that and the given document
    # (program record) together to output a stringified - meaning: readable
    # version of the document.
    log = list()
    _MY_SOURCE = VOCAB_CSRHUB

    try:
        tag_data = init_tagging(document, vocabulary, log, _MY_SOURCE)

        # NOW START TURNING THE RULES INTO CODE

        # Rule 1: Community Development and Philanthropy (always add)
        log.append("  rule 1")

        # everyone gets one
        add_feature(_MY_SOURCE, COMMUNITY_DEVELOPMENT_AND_PHILANTHROPY, tag_data)

        # Rule 2 "Human Rights and Supply Chain"
        log.append("  rule 2")
        if check_term(HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, VOCAB_CAUSES, tag_data) or \
            check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
                check_term(INCREASE_CIVIC_PARTICIPATION, VOCAB_IMPACTS, tag_data) or \
         check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                check_term(IMPROVE_COMMUNITY_ENVIRONMENTS_OR_SPACES, VOCAB_APPROACHES, tag_data) or \
                check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data):
                add_feature(_MY_SOURCE, HUMAN_RIGHTS_AND_SUPPLY_CHAIN, tag_data)

        # Rule 3: "Diversity and Labor Rights"
        log.append("  rule 3")
        if check_term(ECONOMIC_EMPOWERMENT, VOCAB_CAUSES, tag_data) or \
                check_term(EDUCATION, VOCAB_CAUSES, tag_data) or \
                check_term(HUMAN_RIGHTS_AND_CIVIC_ENGAGEMENT, VOCAB_CAUSES, tag_data):
            if check_term(ACHIEVE_EQUALITY_ELIMINATE_DISCRIMINATION, VOCAB_IMPACTS, tag_data) or \
                    check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data):
                if check_term(ENHANCE_LEGAL_PROTECTIONS, VOCAB_APPROACHES, tag_data) or \
                        check_term(INCREASE_COLLEGE_READINESS__ACCESS__PERSISTENCE_AND_COMPLETION, VOCAB_APPROACHES, tag_data) or \
                        check_term(INCREASE_JOB_PLACEMENT_RETENTION_SERVICES, VOCAB_APPROACHES, tag_data) or \
                        check_term(PROMOTE_JOB_CREATION, VOCAB_APPROACHES, tag_data) or \
                        check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                        check_term(PROVIDE_STEM_INTEREST__PROFICIENCY_AND_PERSISTENCE_PROGRAMS, VOCAB_APPROACHES, tag_data) or \
                        check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data):
                    if check_term(WOMEN_AND_GIRLS, VOCAB_AUDIENCES, tag_data) or \
                            check_term(IMMIGRANTS, VOCAB_AUDIENCES, tag_data) or \
                            check_term(LGBTQQIA_, VOCAB_AUDIENCES, tag_data) or \
                            check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) or \
                            check_term(PEOPLE_WITH_DISABILITIES_DISABLED_PERSONS, VOCAB_AUDIENCES, tag_data) or \
                            check_term(PEOPLE_WITH_SPECIAL_NEEDS, VOCAB_AUDIENCES, tag_data) or \
                            check_term(REFUGEES_DISPLACED_PERSONS, VOCAB_AUDIENCES, tag_data):
                        add_feature(_MY_SOURCE, DIVERSITY_AND_LABOR_RIGHTS, tag_data)

        # Rule 4: "Energy and Climate Change"
        log.append("  rule 4")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data):
            if check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data) or \
                    check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                    check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                    check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                    check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data) or \
                    check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data):
                add_feature(_MY_SOURCE, ENERGY_AND_CLIMATE_CHANGE, tag_data)

        # Rule 5: "Leadership Ethics"
        log.append("  rule 5")
        # everyone gets one
        add_feature(_MY_SOURCE, LEADERSHIP_ETHICS, tag_data)


        # the last few steps
        # log it:
        log.append("  Summary: " + ', '.join(document[_MY_SOURCE]["strings"]))

        # now put the version number into the same object
        document[_MY_SOURCE]["tagging-version"] = SELECTED_VOCABULARY_VERSION

        # cool!  save that object back and go!
        save_program_document(document)

    except Exception as eee:
        print(log)
        critical_alert(eee, log, "vocab_error_in_tagging")
        raise eee

    return log
