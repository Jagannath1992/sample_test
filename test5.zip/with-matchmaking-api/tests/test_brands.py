import json
from unittest import mock
from io import BytesIO

import pytest
from pytest_lazyfixture import lazy_fixture


def test_get_brands(client, admin_header):
    response = client.get('/admin/brands', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/admin/brands?sort=name asc&filter=name eq abc', headers=admin_header)
    assert response.status_code == 200


def test_create_brands_without_token(client, default_header):
    new_brands = [{'name': 'name', 'industry': 'industry'}]
    response = client.post('/matchmaking/brands', data=json.dumps(new_brands), headers=default_header)
    assert response.status_code in [401, 403]


def test_create_brands_with_token(client, supplier_analysis_report_header, monkeypatch):
    new_brands = [
        {'name': 'Test Brand A', 'industry': 'Food and Packaging'},
        {'name': 'Test Brand B', 'industry': 'Software'}
    ]

    mock_requests = mock.MagicMock()
    monkeypatch.setattr('matchmaking.service.slack.requests', mock_requests)
    response = client.post('/matchmaking/brands', data=json.dumps(new_brands), headers=supplier_analysis_report_header)
    assert response.status_code == 200

    brands = json.loads(response.data.decode())

    assert len(brands['_ids']) == len(new_brands)
    assert not brands['failed']

    # slack message requests
    assert mock_requests.post.call_count == len(new_brands)


def test_create_brand_mixed_success(client, supplier_analysis_report_header, monkeypatch):
    new_brands_success = [
        {'name': 'Test Brand C', 'industry': 'Food and Packaging'},
        {'name': 'Test Brand D', 'industry': 'Software'}
    ]

    new_brands_failure = [
        {'id': 'some_id'},
        {'industry': 'Food and Software'},
        {'name': 'Test Brand'}
    ]

    mock_requests = mock.MagicMock()
    monkeypatch.setattr('matchmaking.service.slack.requests', mock_requests)
    response = client.post('/matchmaking/brands', data=json.dumps([*new_brands_failure, *new_brands_success]),
                           headers=supplier_analysis_report_header)
    assert response.status_code == 200

    brands = json.loads(response.data.decode())

    assert len(brands['_ids']) == len(new_brands_success)
    assert len(brands['failed']) == len(new_brands_failure)

    # slack message requests
    assert mock_requests.post.call_count == len(new_brands_success) + len(new_brands_failure)


def test_search_brand_without_token(client, default_header):
    query = 'spartan'
    response = client.get(f'admin/brands/search?query={query}&limit=50&offset=0&sasb=false', headers=default_header)
    assert response.status_code in [403, 401]


@pytest.mark.parametrize('headers, blueprint', [
    (lazy_fixture('client_header'), 'matchmaking'),
    (lazy_fixture('admin_header'), 'admin'),
    (lazy_fixture('supplier_analysis_report_header'), 'matchmaking')
])
def test_search_brand_with_valid_tokens(client, headers, blueprint):
    query = 'spartan'
    response = client.get(f'{blueprint}/brands/search?query={query}&limit=50&offset=0&sasb=false', headers=headers)

    assert response.status_code == 200

    brands = json.loads(response.data.decode())
    assert 'brands' in brands
    assert brands['brands']


@pytest.mark.parametrize('headers, blueprint, expected_fields', [
    (lazy_fixture('client_header'), 'matchmaking', ['_id', 'name']),
    (lazy_fixture('admin_header'), 'admin', ['industry', 'verifiedByAdmin', 'name', '_id', 'source']),
])
def test_search_brand_returns_expected_fields(client, headers, blueprint, expected_fields):
    query = 'spartan'
    response = client.get(f'{blueprint}/brands/search?query={query}&limit=50&offset=0&sasb=false', headers=headers)

    brands = json.loads(response.data.decode())

    for field in expected_fields:
        assert field in brands['brands'][0]


def test_get_brand(client, admin_header, brand_id):
    response = client.get(f'/admin/brands/{brand_id}', headers=admin_header)
    assert response.status_code == 200

    response_data = json.loads(response.data.decode())
    assert response_data['_id'] == str(brand_id)
    assert response_data['name']


def test_brand_upload_delete(client, admin_header, brand_id, monkeypatch):
    # TEST UPLOAD
    mock_s3_url = 'https://s3-uploaded-file/brands/summary.txt'
    monkeypatch.setattr('matchmaking.controllers.matchmaking.brands.endpoints.upload_file',
                        mock.MagicMock(return_value=mock_s3_url))

    upload_request_a = {
        'file': (BytesIO(b'test file'), 'test.txt'),
        'field': 'writtenSummary'
    }
    response = client.post(f'/admin/brands/{brand_id}/upload', headers=admin_header,
                           data=upload_request_a, content_type='multipart/form-data')
    assert response.status_code == 200

    upload_request_b = {
        'file': (BytesIO(b'test file'), 'test.txt'),
        'field': 'parent.writtenSummary'
    }

    response = client.post(f'/admin/brands/{brand_id}/upload', headers=admin_header,
                           data=upload_request_b, content_type='multipart/form-data')
    assert response.status_code == 200
    assert json.loads(response.data.decode())['writtenSummary']['url'] == mock_s3_url
    assert json.loads(response.data.decode())['writtenSummary']['name'] == 'test.txt'

    response = client.get(f'/admin/brands/{brand_id}', headers=admin_header)
    assert json.loads(response.data.decode())['parent']['writtenSummary']['url'] == mock_s3_url
    assert json.loads(response.data.decode())['parent']['writtenSummary']['name'] == 'test.txt'

    # TEST DELETE
    monkeypatch.setattr('matchmaking.controllers.matchmaking.brands.endpoints.delete_file',
                        mock.MagicMock(return_value=True))

    response = client.delete(f'/admin/brands/{brand_id}/writtenSummary/summary.txt', headers=admin_header)
    assert response.status_code == 200
    with pytest.raises(KeyError):
        json.loads(response.data.decode())['writtenSummary'] # pylint: disable=expression-not-assigned

    response = client.delete(f'/admin/brands/{brand_id}/parent.writtenSummary/summary.txt', headers=admin_header)
    assert response.status_code == 200
    with pytest.raises(KeyError):
        json.loads(response.data.decode())['parent']['writtenSummary'] # pylint: disable=expression-not-assigned


@pytest.mark.parametrize('upload_request', [
    {'file': (BytesIO(b'test file'), 'test.txt')},
    {'field': 'writtenSummary'},
    {}
])
def test_brand_upload_bad_fields(client, admin_header, brand_id, upload_request):
    response = client.post(f'/admin/brands/{brand_id}/upload', headers=admin_header,
                           data=upload_request, content_type='multipart/form-data')
    assert response.status_code == 400


@pytest.mark.parametrize('path', [
    f'/admin/brands/{lazy_fixture("brand_id")}/writtenSummary/summary.txt',
    f'/admin/brands/{lazy_fixture("brand_id")}/name/summary.txt',
])
def test_brand_delete_file_bad_request(client, admin_header, path):
    response = client.delete(path, headers=admin_header)
    assert response.status_code == 400


def test_generate_preferred_programs_password(client, admin_header, brand_id, monkeypatch):
    mock_gen_pass = mock.MagicMock(return_value='sample_password')
    monkeypatch.setattr('matchmaking.controllers.matchmaking.brands.endpoints.generate_secure_password', mock_gen_pass)

    response = client.post(f'/admin/brands/{brand_id}/preferred-programs/password', headers=admin_header)

    assert response.status_code == 200
    generated_pass = json.loads(response.data.decode())['preferredPrograms']['password']

    assert generated_pass == mock_gen_pass()
