import types
import pytest
from flask import request

from portal.features.users.schema import AccountRegisterRequest, AccountSubscriptionActivateRequest, AccountSubscriptionRequest, BlockedDomainsResponse, UserInviteRequest, UserMyProfileRequest, UserProvisionRequest, UserProvisionResponse, UserRegisterRequest, UserRequest, UserResponse, UserSearchRequest, UserSearchResponse
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.enums import AccountStatus, SubscriptionFrequency, UserRole, AccountType, InstanceType
from portal.shared.repositories import account_approval_repository, account_repository, instance_settings_repository, user_repository
from portal.shared.sage.models import SageContact, SageContactListInfo, SageContactListInfoContact, SageCustomer, SageCustomerResult, SageMailAddress
from portal.shared.services import auth_service, email_service, flag_service, sage_service, stripe_service
from portal.testing.mocks import MockResponse


class TestBlockedDomains:
    def test_get_200(self, client, mocker):
        # arrange
        blocked_domains = {'domains': ['domain1.com', 'domain2.com']}
        mocker.patch.object(user_repository(), 'get_blocked_domains', return_value=blocked_domains)

        # act
        response = client.get('/users/blocked-domains')

        # assert
        user_repository().get_blocked_domains.assert_called_once()
        assert response.status_code == 200
        assert response.json == BlockedDomainsResponse().dump(blocked_domains)

    def test_get_200_no_data(self, client, mocker):
        # arrange
        mocker.patch.object(user_repository(), 'get_blocked_domains', return_value={})

        # act
        response = client.get('/users/blocked-domains')

        # assert
        assert response.status_code == 200
        assert response.json == BlockedDomainsResponse().dump({'domains': []})


class TestRegistration:
    @pytest.fixture()
    def post_init(self, mocker, fakers):
        mocker.patch.object(user_repository(), 'get_blocked_domains', return_value={'domains': []})
        mocker.patch.object(user_repository(), 'username_exists', return_value=False)
        mocker.patch.object(flag_service(), 'validate_domains', return_value=True)
        mocker.patch.object(user_repository(), 'domain_exists', return_value=False)
        mocker.patch.object(account_repository(), 'company_exists', return_value=False)

        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single_by_filter', return_value=instance)

        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'insert', return_value=account)
        mocker.patch.object(account_approval_repository(), 'insert')

        user = fakers.user.generate_single()
        mocker.patch.object(auth_service(), 'create_user', return_value=user)

        return account, user, instance

    @pytest.fixture()
    def post_request_json(self, post_init):
        account, user, _ = post_init
        return UserRegisterRequest().dump({
            'user': user,
            'account': account
        })

    def test_post_200(self, client, post_init, post_request_json):
        # arrange
        account, user, instance = post_init
        expected_account = {
            **UserRegisterRequest().load(post_request_json)['account'],
            'type': AccountType.DEFAULT.value,
            'instance': {
                '_id': instance['_id'],
                '_type': 'instance_settings',
                'name': instance['name']
            }
        }

        with client:
            # act
            response = client.post("/users/register", json=post_request_json)

            # assert
            instance_settings_repository().get_single_by_filter.assert_called_once_with({
                'settings.portalUrl': request.origin})
            flag_service().validate_domains.assert_called_once()
            user_repository().domain_exists.assert_called_once_with(user['username'])
            account_repository().company_exists.assert_called_once_with(account['company']['name'])
            account_repository().insert.assert_called_once_with(expected_account, user['username'])
            account_approval_repository().insert.assert_called_once_with(
                {'_id': account['_id'], 'levels': []}, user['username'])
            auth_service().create_user.assert_called_once_with(
                request.parsed_obj['user'],
                account['_id'],
                'An error occurred while attempting to create the account',
                request.parsed_obj['user']['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    def test_post_400_duplicate_domain(self, client, post_init, post_request_json):
        # arrange
        user_repository().domain_exists.return_value = True
        _, user, _ = post_init

        with client:
            # act
            response = client.post('users/register', json=post_request_json)

            # assert
            instance_settings_repository().get_single_by_filter.assert_called_once_with({
                'settings.portalUrl': request.origin})
            flag_service().validate_domains.assert_called_once()
            user_repository().domain_exists.assert_called_once_with(user['username'])
            account_repository().company_exists.assert_not_called()
            account_repository().insert.assert_not_called()
            account_approval_repository().insert.assert_not_called()
            auth_service().create_user.assert_not_called()
            assert response.status_code == 400
            assert response.json == {'message': 'An account already exists for this company'}

    def test_post_400_duplicate_company(self, client, post_init, post_request_json):
        # arrange
        flag_service().validate_domains.return_value = True
        user_repository().domain_exists.return_value = False
        account_repository().company_exists.return_value = True
        account, user, _ = post_init

        with client:
            # act
            response = client.post('users/register', json=post_request_json)

            # assert
            instance_settings_repository().get_single_by_filter.assert_called_once_with({
                'settings.portalUrl': request.origin})
            flag_service().validate_domains.assert_called_once()
            user_repository().domain_exists.assert_called_once_with(user['username'])
            account_repository().company_exists.assert_called_once_with(account['company']['name'])
            account_repository().insert.assert_not_called()
            account_approval_repository().insert.assert_not_called()
            auth_service().create_user.assert_not_called()
            assert response.status_code == 400
            assert response.json == {'message': 'An account already exists for this company'}

    def test_post_404_instance_not_found(self, client, post_init, post_request_json):
        # arrange
        instance_settings_repository().get_single_by_filter.return_value = None
        _, _, _ = post_init

        with client:
            # act
            response = client.post("/users/register", json=post_request_json)

            # assert
            instance_settings_repository().get_single_by_filter.assert_called_once_with({
                'settings.portalUrl': request.origin})
            flag_service().validate_domains.assert_not_called()
            user_repository().domain_exists.assert_not_called()
            account_repository().company_exists.assert_not_called()
            account_repository().insert.assert_not_called()
            account_approval_repository().insert.assert_not_called()
            auth_service().create_user.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'No instance settings configured for this URL'}

    def test_post_200_procurement_instance(self, client, post_init, post_request_json):
        # arrange
        account, user, instance = post_init
        instance['type'] = InstanceType.PROCUREMENT.value
        expected_account = {
            **UserRegisterRequest().load(post_request_json)['account'],
            'type': AccountType.PROCUREMENT.value,
            'instance': {
                '_id': instance['_id'],
                '_type': 'instance_settings',
                'name': instance['name']
            }
        }

        with client:
            # act
            response = client.post("/users/register", json=post_request_json)

            # assert
            instance_settings_repository().get_single_by_filter.assert_called_once_with({'settings.portalUrl': request.origin})
            flag_service().validate_domains.assert_called_once()
            user_repository().domain_exists.assert_called_once_with(user['username'])
            account_repository().company_exists.assert_called_once_with(account['company']['name'])
            account_repository().insert.assert_called_once_with(expected_account, user['username'])
            account_approval_repository().insert.assert_called_once_with(
                {'_id': account['_id'], 'levels': []}, user['username'])
            auth_service().create_user.assert_called_once_with(
                request.parsed_obj['user'],
                account['_id'],
                'An error occurred while attempting to create the account',
                request.parsed_obj['user']['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    @pytest.fixture()
    def put_init(self, mocker, fakers):
        instance = fakers.instance_settings.insert_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        account = fakers.account.insert_single(
            {'instance': {'_id': instance['_id']}, 'status': AccountStatus.NEW.value})
        user = fakers.user.generate_single({'accountId': account['_id']})
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        mocker.patch.object(account_repository(), 'patch', return_value=account)
        return (account, user, instance)

    @pytest.fixture()
    def put_request_json(self, put_init):
        account, _, _ = put_init
        return AccountRegisterRequest().dump({
            'account': account
        })

    def test_put_200(self, client, org_admin_header, put_init, put_request_json):
        # arrange
        account, user, instance = put_init

        with client:
            # act
            response = client.put("/users/register", json=put_request_json, headers=org_admin_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().patch.assert_called_once_with(
                user['accountId'], request.parsed_obj['account'], user['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    def test_put_404(self, client, org_admin_header, put_init, put_request_json):
        # arrange
        user_repository().get_single.return_value = None

        with client:
            # act
            response = client.put("/users/register", json=put_request_json, headers=org_admin_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().patch.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'User not found'}


class TestSubscription:
    @pytest.fixture
    def put_init(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        user = fakers.user.generate_single()

        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        mocker.patch.object(account_repository(), 'patch')
        mocker.patch.object(stripe_service(), 'create_subscription_checkout_session',
                            return_value=types.SimpleNamespace(url='http://example.com'))

        return instance, account, user

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_put(self, client, put_init, custom_auth_header):
        # arrange
        _, _, user = put_init

        with client:
            # act
            response = client.put('/users/subscription', json={}, headers=custom_auth_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().get_single.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            stripe_service().create_subscription_checkout_session.assert_not_called()
            account_repository().patch.assert_called_once_with(
                user['accountId'],
                {'status': AccountStatus.PENDING_FINANCE.value, },
                user['username'])
            assert response.status_code == 200

    def test_put_with_subscription_options(self, client, put_init, org_admin_header):
        # arrange
        _, _, user = put_init
        request_json = AccountSubscriptionRequest().dump({
            'subscriptionOptions': {
                'subscriptionFrequency': SubscriptionFrequency.ANNUAL.value
            }
        })

        with client:
            # act
            response = client.put('/users/subscription', json=request_json, headers=org_admin_header)

            subscription_options = request.parsed_obj['subscriptionOptions']
            subscription_frequency = subscription_options['subscriptionFrequency']

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().get_single.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            stripe_service().create_subscription_checkout_session.assert_not_called()
            account_repository().patch.assert_called_once_with(user['accountId'], {
                'status': AccountStatus.PENDING_STRIPE.value,
                'subscriptionFrequency': subscription_frequency
            }, user['username'])
            assert response.status_code == 200

    def test_put_with_subscription_options_with_checkout_session(self, client, put_init, org_admin_header):
        # arrange
        instance, account, user = put_init
        request_json = AccountSubscriptionRequest().dump({
            'subscriptionOptions': {
                'subscriptionFrequency': SubscriptionFrequency.ANNUAL.value
            },
            'createSetupSubscriptionCheckoutSession': True
        })

        with client:
            # act
            response = client.put('/users/subscription', json=request_json, headers=org_admin_header)

            subscription_options = request.parsed_obj['subscriptionOptions']
            subscription_frequency = subscription_options['subscriptionFrequency']

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().get_single.assert_called_once_with(
                user['accountId'], {'stripe.trialPeriodUsed': 1, 'instance._id': 1})
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            stripe_service().create_subscription_checkout_session.assert_called_once_with(
                instance, subscription_frequency, account['stripe']['trialPeriodUsed'], account['type'])
            account_repository().patch.assert_called_once_with(user['accountId'], {
                'status': AccountStatus.PENDING_STRIPE.value,
                'subscriptionFrequency': subscription_frequency
            }, user['username'])
            assert response.status_code == 200

    @pytest.fixture
    def post_init(self, mocker, fakers):
        stripe_subscription_id = 'sub_123'
        stripe_customer_id = 'cus_123'
        mocker.patch.object(stripe_service(), 'get_checkout_session', return_value=types.SimpleNamespace(
            subscription=stripe_subscription_id, customer=stripe_customer_id))
        user = fakers.user.generate_single()
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        sage_customer_id = '123'
        sage_customer_record_no = '456'
        mocker.patch.object(sage_service(), 'create_customer', return_value=SageCustomerResult(
            customerId=sage_customer_id, recordNo=sage_customer_record_no))
        mocker.patch.object(stripe_service(), 'update_customer')
        mocker.patch.object(user_repository(), 'patch')
        mocker.patch.object(sage_service(), 'update_customer')
        mocker.patch.object(account_repository(), 'patch', return_value=account)
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(email_service(), 'send_new_account_created_email')
        return instance, user, account, stripe_subscription_id, stripe_customer_id, sage_customer_id, sage_customer_record_no

    @pytest.fixture
    def post_request_json(self):
        return AccountSubscriptionActivateRequest().dump({
            'checkoutSessionId': 'cs_123'
        })

    @pytest.fixture
    def post_sage_customer(self, post_init):
        _, user, account, _, stripe_customer_id, _, _ = post_init
        company = account['company']
        address = company['address']
        return SageCustomer(
            NAME=company['name'],
            DISPLAYCONTACT=SageContact(
                FIRSTNAME=user['first_name'],
                LASTNAME=user['last_name'],
                COMPANYNAME=company['name'],
                EMAIL1=user['username'],
                MAILADDRESS=SageMailAddress(
                    ADDRESS1=address['address1'],
                    ADDRESS2=address['address2'],
                    CITY=address['city'],
                    STATE=address['stateProvince'],
                    ZIP=address['postalCode'],
                    COUNTRY=address['country']
                )
            ),
            GIVEWITH_ACCOUNT_ID=user['accountId'],
            STRIPE_CUSTOMER_ID=stripe_customer_id,
        )

    @pytest.fixture
    def post_sage_customer_update(self, post_sage_customer):
        return SageCustomer(
            CONTACT_LIST_INFO=[
                SageContactListInfo(
                    CATEGORYNAME='Finance',
                    CONTACT=SageContactListInfoContact(
                        NAME=post_sage_customer.DISPLAYCONTACT.CONTACTNAME
                    )
                )
            ]
        )

    @pytest.fixture
    def post_account_update(self, post_init):
        _, _, _, stripe_subscription_id, stripe_customer_id, sage_customer_id, sage_customer_record_no = post_init
        return {
            'status': AccountStatus.ACTIVE.value,
            'stripe': {
                'customerId': stripe_customer_id,
                'subscription': {
                    'id': stripe_subscription_id
                }
            },
            'sageCustomerId': sage_customer_id,
            'sageRecordNo': sage_customer_record_no
        }

    def test_post(
            self, client, post_init, post_request_json, org_admin_header, post_sage_customer, post_sage_customer_update,
            post_account_update):
        # arrange
        instance, user, account, _, stripe_customer_id, sage_customer_id, sage_customer_record_no = post_init

        # act
        with client:
            response = client.post('/users/subscription', json=post_request_json, headers=org_admin_header)

            # assert
            stripe_service().get_checkout_session.assert_called_once_with(request.parsed_obj['checkoutSessionId'])
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().get_single.assert_called_once_with(user['accountId'])
            sage_service().create_customer.assert_called_once_with(account, post_sage_customer)
            stripe_service().update_customer.assert_called_once_with(
                stripe_customer_id, account['_id'], sage_customer_id),
            user_repository().patch.assert_called_once_with(user['_id'], {'roles': [UserRole.FINANCE.value]}, user['username'])
            sage_service().update_customer.assert_called_once_with(account, post_sage_customer_update, sage_customer_record_no)
            account_repository().patch.assert_called_once_with(
                user['accountId'], post_account_update, user['username'])
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            email_service().send_new_account_created_email.assert_called_once_with(instance, user, account)
            assert response.status_code == 200

    def test_post_finance(self, client, post_init, post_request_json, finance_header, post_sage_customer,
                          post_sage_customer_update, post_account_update):
        # arrange
        instance, user, account, _, stripe_customer_id, sage_customer_id, sage_customer_record_no = post_init

        # act
        with client:
            response = client.post('/users/subscription', json=post_request_json, headers=finance_header)

            # assert
            stripe_service().get_checkout_session.assert_called_once_with(request.parsed_obj['checkoutSessionId'])
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().get_single.assert_called_once_with(user['accountId'])
            sage_service().create_customer.assert_called_once_with(account, post_sage_customer)
            stripe_service().update_customer.assert_called_once_with(
                stripe_customer_id, account['_id'], sage_customer_id),
            user_repository().patch.assert_not_called()
            sage_service().update_customer.assert_called_once_with(account, post_sage_customer_update, sage_customer_record_no)
            account_repository().patch.assert_called_once_with(
                user['accountId'], post_account_update, user['username'])
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            email_service().send_new_account_created_email.assert_called_once_with(instance, user, account)
            assert response.status_code == 200

    def test_post_404_checkout_session(self, client, post_init, post_request_json, org_admin_header):
        # arrange
        stripe_service().get_checkout_session.return_value = None

        # act
        with client:
            response = client.post('/users/subscription', json=post_request_json, headers=org_admin_header)

            # assert
            stripe_service().get_checkout_session.assert_called_once_with(request.parsed_obj['checkoutSessionId'])
            user_repository().get_single.assert_not_called()
            account_repository().get_single.assert_not_called()
            sage_service().create_customer.assert_not_called()
            stripe_service().update_customer.assert_not_called()
            user_repository().patch.assert_not_called()
            sage_service().update_customer.assert_not_called()
            account_repository().patch.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            email_service().send_new_account_created_email.assert_not_called()
            assert response.status_code == 404

    def test_post_404_user(self, client, post_init, post_request_json, org_admin_header):
        # arrange
        user_repository().get_single.return_value = None

        # act
        with client:
            response = client.post('/users/subscription', json=post_request_json, headers=org_admin_header)

            # assert
            stripe_service().get_checkout_session.assert_called_once_with(request.parsed_obj['checkoutSessionId'])
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            account_repository().get_single.assert_not_called()
            sage_service().create_customer.assert_not_called()
            stripe_service().update_customer.assert_not_called()
            user_repository().patch.assert_not_called()
            sage_service().update_customer.assert_not_called()
            account_repository().patch.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            email_service().send_new_account_created_email.assert_not_called()
            assert response.status_code == 404


class TestUsers:
    @pytest.fixture
    def get_init(self, fakers, mocker):
        users = fakers.user.generate_many(3)
        get_validated_account_id_mock = mocker.patch(
            'portal.features.users.controller.get_validated_account_id', return_value=users[0]['accountId'])
        mocker.patch.object(user_repository(), 'get_page', return_value=(3, users))
        return (users, get_validated_account_id_mock)

    @pytest.fixture
    def get_query_string(self, get_init):
        users, _ = get_init
        return UserSearchRequest().dump({
            **users[0],
            'offset': 0,
            'count': 10,
            'orderBy': 'firstName'
        })

    @pytest.mark.parametrize(
        'custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.ORG_ADMIN, UserRole.USER_ADMIN],
        indirect=True)
    def test_get_200(self, client, custom_auth_header, get_init, get_query_string):
        # arrange
        users, get_validated_account_id_mock = get_init

        with client:
            # act
            response = client.get('/users', query_string=get_query_string, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(request.parsed_query_params['accountId'], request)
            user_repository().get_page.assert_called_once_with(request.parsed_query_params)
            assert response.status_code == 200
            assert response.json == UserSearchResponse().dump({'totalCount': 3, 'results': users})

    @pytest.fixture
    def post_init(self, fakers, mocker):
        user = fakers.user.generate_single()
        get_validated_account_id_mock = mocker.patch(
            'portal.features.users.controller.get_validated_account_id', return_value=user['accountId'])
        mocker.patch.object(auth_service(), 'create_user', return_value=user)
        return (user, get_validated_account_id_mock)

    @pytest.fixture
    def post_request_json(self, post_init):
        user, _ = post_init
        return UserInviteRequest().dump(user)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.ORG_ADMIN, UserRole.USER_ADMIN], indirect=True)
    def test_post_200(self, client, custom_auth_header, post_init, post_request_json):
        # arrange
        user, get_validated_account_id_mock = post_init

        with client:
            # act
            response = client.post("/users", json=post_request_json, headers=custom_auth_header)

            # assert
            get_validated_account_id_mock.assert_called_once_with(user['accountId'], request)
            auth_service().create_user.assert_called_once_with(
                request.parsed_obj, user['accountId'],
                'An error occurred while attempting to invite this user', request.user['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)


class TestUserById:
    @pytest.fixture
    def get_init(self, mocker, fakers):
        mocker.patch.object(user_repository(), 'has_access', return_value=True)
        user = fakers.user.generate_single()
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        return user

    def test_get_200_givewith(self, client, givewith_header, get_init):
        # arrange
        user = get_init

        with client:
            # act
            response = client.get(f'/users/{user["_id"]}', headers=givewith_header)

            # assert
            user_repository().has_access.assert_not_called()
            user_repository().get_single.assert_called_once_with(str(user['_id']))
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.USER_ADMIN],
                             indirect=True)
    def test_get_200(self, client, custom_auth_header, get_init):
        # arrange
        user = get_init

        with client:
            # act
            response = client.get(f'/users/{user["_id"]}', headers=custom_auth_header)

            # assert
            user_repository().has_access.assert_called_once_with(str(user['_id']), request.user['accountId'])
            user_repository().get_single.assert_called_once_with(str(user['_id']))
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    def test_get_400_invalid_id(self, client, givewith_header, get_init):
        # arrange

        with client:
            # act
            response = client.get('/users/invalid', headers=givewith_header)

            # assert
            user_repository().has_access.assert_not_called()
            user_repository().get_single.assert_not_called()
            assert response.status_code == 400
            assert response.json == {'message': 'Invalid id provided'}

    def test_get_404(self, client, givewith_header, get_init):
        # arrange
        user = get_init
        user_repository().get_single.return_value = None

        # act
        response = client.get(f'/users/{user["_id"]}', headers=givewith_header)

        # assert
        user_repository().has_access.assert_not_called()
        user_repository().get_single.assert_called_once_with(str(user['_id']))
        assert response.status_code == 404
        assert response.json == {'message': 'User not found'}

    @pytest.fixture
    def put_init(self, mocker, fakers):
        mocker.patch.object(user_repository(), 'has_access', return_value=True)
        user = fakers.user.generate_single()
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        mocker.patch.object(auth_service(), 'update_user', return_value=MockResponse())
        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        mocker.patch.object(email_service(), 'send_role_update_email')
        mocker.patch.object(user_repository(), 'get_by_username', return_value=user)
        return user, account, instance

    @pytest.fixture
    def put_request_json(self, put_init):
        user, _, _ = put_init
        return UserRequest().dump(user)

    def test_put_200_givewith(self, client, givewith_header, put_init, put_request_json):
        # arrange
        user, account, instance = put_init
        put_request_json['roles'].append(UserRole.GW_FINANCE.value)

        with client:
            # act
            response = client.put(f'/users/{user["_id"]}', json=put_request_json, headers=givewith_header)

            # assert
            user_repository().has_access.asset_not_called()
            user_repository().get_single.assert_called_once_with(str(user['_id']))
            auth_service().update_user.assert_called_once_with(str(user['_id']), {
                **request.parsed_obj,
                'oktaId': user['oktaId'],
                'username': user['username'],
                'orgType': user['orgType'],
                'orgId': user['orgId']
            }, request.user['username'])
            account_repository().get_single.assert_called_once_with(request.user['accountId'], {'instance._id': 1})
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            email_service().send_role_update_email.assert_called_once_with(
                instance, user, request.parsed_obj, request.user['username'])
            user_repository().get_by_username.assert_called_once_with(user['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.USER_ADMIN],
                             indirect=True)
    def test_put_200(self, client, custom_auth_header, put_init, put_request_json):
        # arrange
        user, _, _ = put_init

        with client:
            # act
            response = client.put(f'/users/{user["_id"]}', json=put_request_json, headers=custom_auth_header)

            # assert
            user_repository().has_access.asset_called_once_with(str(user['_id']), request.user['accountId'])
            user_repository().get_single.assert_called_once_with(str(user['_id']))
            auth_service().update_user.assert_called_once_with(str(user['_id']), {
                **request.parsed_obj,
                'oktaId': user['oktaId'],
                'username': user['username'],
                'orgType': user['orgType'],
                'orgId': user['orgId']
            }, request.user['username'])
            account_repository().get_single.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            email_service().send_role_update_email.assert_not_called()
            user_repository().get_by_username.assert_called_once_with(user['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    def test_put_400_invalid_id(self, client, givewith_header, put_init, put_request_json):
        # arrange

        with client:
            # act
            response = client.put('/users/invalid', json=put_request_json, headers=givewith_header)

            # assert
            user_repository().has_access.assert_not_called()
            user_repository().get_single.assert_not_called()
            auth_service().update_user.assert_not_called()
            account_repository().get_single.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            email_service().send_role_update_email.assert_not_called()
            user_repository().get_by_username.assert_not_called()
            assert response.status_code == 400
            assert response.json == {'message': 'Invalid id provided'}

    def test_put_404(self, client, givewith_header, put_init, put_request_json):
        # arrange
        user, _, _ = put_init
        user_repository().get_single.return_value = None

        with client:
            # act
            response = client.put(f'/users/{user["_id"]}', json=put_request_json, headers=givewith_header)

            # assert
            user_repository().has_access.asset_not_called()
            user_repository().get_single.assert_called_once_with(str(user['_id']))
            auth_service().update_user.assert_not_called()
            account_repository().get_single.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            email_service().send_role_update_email.assert_not_called()
            user_repository().get_by_username.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'User not found'}

    def test_put_502(self, client, givewith_header, put_init, put_request_json):
        # arrange
        auth_service().update_user.return_value = MockResponse(500)
        user, _, _ = put_init

        with client:
            # act
            response = client.put(f'/users/{user["_id"]}', json=put_request_json, headers=givewith_header)

            # assert
            user_repository().has_access.asset_not_called()
            user_repository().get_single.assert_called_once_with(str(user['_id']))
            auth_service().update_user.assert_called_once_with(str(user['_id']), {
                **request.parsed_obj,
                'oktaId': user['oktaId'],
                'username': user['username'],
                'orgType': user['orgType'],
                'orgId': user['orgId']
            }, request.user['username'])
            account_repository().get_single.assert_not_called()
            instance_settings_repository().get_single.assert_not_called()
            email_service().send_role_update_email.assert_not_called()
            user_repository().get_by_username.assert_not_called()
            assert response.status_code == 502
            assert response.json == {'message': 'An error occurred while attempting to update this user'}


class TestSalesforceUsers:
    @pytest.fixture
    def post_init(self, mocker, fakers):
        users = fakers.user.generate_many(2)
        index = 0
        for user in users:
            index = index + 1
            user['password'] = f'P@ssw0rd{index}'
        def get_user(user, acctId, error, username):
            for u in users:
                if user['username'] == u['username']:
                    user['_id'] = u['_id']
            return user
        mocker.patch.object(auth_service(), 'create_user', get_user)
        return users

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS], indirect=True)
    def test_post_givewith_200(self, client, custom_auth_header, post_init):
        # arrange
        users = post_init
        expected = [{'id': u['_id'], 'username': u['username']} for u in users]
        request_json = UserProvisionRequest(many=True).dump(users)
        expected_json = UserProvisionResponse(many=True).dump(expected)

        with client:
            # act
            response = client.post('/users/salesforce', json=request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 200
            assert response.json == expected_json

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.USER_ADMIN], indirect=True)
    def test_post_org_200(self, client, custom_auth_header, post_init):
        # arrange
        users = post_init
        for user in users:
            del user['accountId']
        expected = [{'id': u['_id'], 'username': u['username']} for u in users]
        request_json = UserProvisionRequest(many=True).dump(users)
        expected_json = UserProvisionResponse(many=True).dump(expected)

        with client:
            # act
            response = client.post('/users/salesforce', json=request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 200
            assert response.json == expected_json

    @pytest.mark.parametrize('custom_auth_header', [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN, UserRole.USER_ADMIN]], indirect=True)
    def test_post_401(self, client, custom_auth_header, post_init):
        # arrange
        users = post_init
        request_json = UserProvisionRequest(many=True).dump(users)

        with client:
            # act
            response = client.post('/users/salesforce', json=request_json, headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json == {'message': 'You do not have permission to access this resource'}


class TestUserProfile:
    @pytest.fixture
    def get_init(self, mocker, fakers):
        user = fakers.user.generate_single()
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        return user

    def test_get_200(self, client, givewith_header, get_init):
        # arrange
        user = get_init

        with client:
            # act
            response = client.get('/users/profile', headers=givewith_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    def test_get_404(self, client, givewith_header, get_init):
        # arrange
        user_repository().get_single.return_value = None

        with client:
            # act
            response = client.get('/users/profile', headers=givewith_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            assert response.status_code == 404
            assert response.json == {'message': 'User not found'}

    @pytest.fixture
    def put_init(self, mocker, fakers):
        user = fakers.user.generate_single()
        mocker.patch.object(user_repository(), 'get_single', return_value=user)
        mocker.patch.object(user_repository(), 'update', return_value=user)
        return user

    @pytest.fixture
    def put_request_json(self, put_init):
        user = put_init
        return UserMyProfileRequest().dump(user)

    def test_put_200(self, client, givewith_header, put_init, put_request_json):
        # arrange
        user = put_init

        with client:
            # act
            response = client.put('/users/profile', json=put_request_json, headers=givewith_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            user_repository().update.assert_called_once_with(
                {**user, **request.parsed_obj}, by=request.user['username'])
            assert response.status_code == 200
            assert response.json == UserResponse().dump(user)

    def test_put_404(self, client, givewith_header, put_init, put_request_json):
        # arrange
        user_repository().get_single.return_value = None

        with client:
            # act
            response = client.put('/users/profile', json=put_request_json, headers=givewith_header)

            # assert
            user_repository().get_single.assert_called_once_with(request.user['_id'])
            user_repository().update.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'User not found'}
