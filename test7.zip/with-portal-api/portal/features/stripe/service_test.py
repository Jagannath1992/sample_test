import time
import types
import pytest
import stripe
from bson import ObjectId
from portal.features.stripe.enums import StripeSetupIntentAction, StripeCheckoutSessionMode, StripePaymentMethodType, StripeSubscriptionStatus, StripeTestPaymentMethods
from portal.shared.dates import get_utc_date_from_timestamp
from portal.shared.enums import AccountStatus, SubscriptionFrequency, AccountType, InstanceType
from portal.shared.services import stripe_service


class TestStripeService:
    @pytest.fixture
    def test_create_subscription_init(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        subscription = types.SimpleNamespace(id='sub_123')
        mocker.patch.object(stripe.Subscription, 'create', return_value=subscription)
        return instance, subscription

    def test_create_subscription(self, test_create_subscription_init):
        # arrange
        instance, subscription = test_create_subscription_init
        customer_id = 'cus_123'
        frequency = SubscriptionFrequency.ANNUAL.value
        account_type = AccountType.DEFAULT.value
        price_id = instance['settings']['stripe']['prices'][frequency]['id']
        expected_args = {
            'customer': 'cus_123',
            'items': [{
                'price': price_id,
                'quantity': 1
            }]
        }

        # act
        result = stripe_service().create_subscription(instance, customer_id, frequency, account_type)

        # assert
        stripe.Subscription.create.assert_called_once_with(**expected_args)
        assert result == subscription

    @pytest.fixture
    def test_update_subscription_frequency_init(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        subscription = {
            'id': 'sub_123',
            'status': StripeSubscriptionStatus.ACTIVE.value,
            'cancel_at_period_end': True,
            'items': {
                'data': [{
                    'id': 'item_123'
                }]
            }
        }
        mocker.patch.object(stripe.Subscription, 'retrieve', return_value=subscription)
        updated_subscription = {
            'canceled_at': int(time.time()),
            'cancel_at': None,
            'current_period_start': int(time.time()),
            'current_period_end': int(time.time())
        }
        mocker.patch.object(stripe.Subscription, 'modify', return_value=updated_subscription)
        expected_result = {
            'stripe': {
                'subscription': {
                    'canceledAt': get_utc_date_from_timestamp(updated_subscription['canceled_at']),
                    'cancelAt': get_utc_date_from_timestamp(updated_subscription['cancel_at']),
                    'currentPeriodStart': get_utc_date_from_timestamp(updated_subscription['current_period_start']),
                    'currentPeriodEnd': get_utc_date_from_timestamp(updated_subscription['current_period_end'])
                }
            }
        }
        return instance, subscription, expected_result

    def test_update_subscription_frequency_same_frequency(self, test_update_subscription_frequency_init):
        # arrange
        instance, subscription, expected_result = test_update_subscription_frequency_init
        current_frequency = SubscriptionFrequency.ANNUAL.value
        new_frequency = SubscriptionFrequency.ANNUAL.value
        expected_result['stripe']['subscription'].update({'newFrequencyAtPeriodEnd': None})
        account_type = AccountType.DEFAULT.value

        # act
        result = stripe_service().update_subscription_frequency(
            instance, subscription['id'], current_frequency, new_frequency, account_type)

        # assert
        stripe.Subscription.retrieve.assert_called_once_with(subscription['id'])
        stripe.Subscription.modify.assert_called_once_with(subscription['id'], cancel_at_period_end=False)
        assert result == expected_result

    def test_update_subscription_frequency_different_frequency_trailing(self, fakers, test_update_subscription_frequency_init):
        # arrange
        instance, subscription, expected_result = test_update_subscription_frequency_init
        subscription['status'] = StripeSubscriptionStatus.TRIALING.value
        current_frequency = SubscriptionFrequency.ANNUAL.value
        new_frequency = SubscriptionFrequency.MONTHLY.value
        expected_result['subscriptionFrequency'] = new_frequency
        account_type = AccountType.DEFAULT.value

        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][new_frequency]['id']

        # act
        result = stripe_service().update_subscription_frequency(
            instance, subscription['id'], current_frequency, new_frequency, account_type)

        # assert
        stripe.Subscription.retrieve.assert_called_once_with(subscription['id'])
        stripe.Subscription.modify.assert_called_once_with(subscription['id'], items=[{
            'id': subscription['items']['data'][0]['id'],
            'price': price_id
        }])
        assert result == expected_result

    def test_update_subscription_frequency_different_frequency_active(self, test_update_subscription_frequency_init):
        # arrange
        instance, subscription, expected_result = test_update_subscription_frequency_init
        subscription['status'] = StripeSubscriptionStatus.ACTIVE.value
        current_frequency = SubscriptionFrequency.ANNUAL.value
        new_frequency = SubscriptionFrequency.MONTHLY.value
        expected_result['stripe']['subscription']['newFrequencyAtPeriodEnd'] = new_frequency
        account_type = AccountType.DEFAULT.value
        # act
        result = stripe_service().update_subscription_frequency(
            instance, subscription['id'], current_frequency, new_frequency, account_type)

        # assert
        stripe.Subscription.retrieve.assert_called_once_with(subscription['id'])
        stripe.Subscription.modify.assert_called_once_with(subscription['id'], cancel_at_period_end=True)
        assert result == expected_result

    def test_update_subscription_frequency_different_frequency_other_status(self, test_update_subscription_frequency_init):
        # arrange
        instance, subscription, _ = test_update_subscription_frequency_init
        subscription['status'] = 'other_status'
        current_frequency = SubscriptionFrequency.ANNUAL.value
        new_frequency = SubscriptionFrequency.MONTHLY.value
        account_type = AccountType.DEFAULT.value

        # act
        result = stripe_service().update_subscription_frequency(
            instance, subscription['id'], current_frequency, new_frequency, account_type)

        # assert
        stripe.Subscription.retrieve.assert_called_once_with(subscription['id'])
        stripe.Subscription.modify.assert_not_called()
        assert result == None

    @pytest.fixture
    def test_cancel_subscription_init(self, mocker):
        subscription = {'status': StripeSubscriptionStatus.ACTIVE.value}
        mocker.patch.object(stripe.Subscription, 'retrieve', return_value=subscription)
        mocker.patch.object(stripe.Subscription, 'delete')
        updated_subscription = {
            'canceled_at': int(time.time()),
            'cancel_at': None,
            'current_period_start': int(time.time()),
            'current_period_end': int(time.time())
        }
        mocker.patch.object(stripe.Subscription, 'modify', return_value=updated_subscription)
        return subscription, updated_subscription

    def test_cancel_subscription_active(self, test_cancel_subscription_init):
        # arrange
        subscription_id = 'sub_123'
        _, updated_subscription = test_cancel_subscription_init

        # act
        result = stripe_service().cancel_subscription(subscription_id)

        # assert
        stripe.Subscription.retrieve.assert_called_once_with(subscription_id)
        stripe.Subscription.delete.assert_not_called
        stripe.Subscription.modify.assert_called_once_with(subscription_id, cancel_at_period_end=True)
        assert result == {
            'stripe': {
                'subscription': {
                    'canceledAt': get_utc_date_from_timestamp(updated_subscription['canceled_at']),
                    'cancelAt': get_utc_date_from_timestamp(updated_subscription['cancel_at']),
                    'currentPeriodStart': get_utc_date_from_timestamp(updated_subscription['current_period_start']),
                    'currentPeriodEnd': get_utc_date_from_timestamp(updated_subscription['current_period_end']),
                    'newFrequencyAtPeriodEnd': None
                }
            }
        }

    def test_cancel_subscription_not_active(self, test_cancel_subscription_init):
        # arrange
        subscription_id = 'sub_123'
        subscription, _ = test_cancel_subscription_init
        subscription['status'] = 'not active'

        # act
        result = stripe_service().cancel_subscription(subscription_id)

        # assert
        stripe.Subscription.retrieve.assert_called_once_with(subscription_id)
        stripe.Subscription.delete.assert_called_once_with(subscription_id)
        stripe.Subscription.modify.assert_not_called()
        assert result == {
            'status': AccountStatus.PENDING_STRIPE.value,
            'stripe': {
                'subscription': {}
            }
        }

    def test_update_customer(self, mocker):
        # arrange
        stripe_customer_id = 'cus_123'
        givewith_account_id = ObjectId()
        sage_customer_id = '123456'
        mocker.patch.object(stripe.Customer, 'modify')

        # act
        stripe_service().update_customer(stripe_customer_id, givewith_account_id, sage_customer_id)

        # assert
        stripe.Customer.modify.asert_called_once_with(
            stripe_customer_id, metadata={'givewithAccountId': str(givewith_account_id),
                                          'sageCustomerId': sage_customer_id})

    @pytest.mark.parametrize('frequency', [SubscriptionFrequency.ANNUAL, SubscriptionFrequency.MONTHLY])
    def test_create_subscription_checkout_session(self, mocker, fakers, frequency):
        # arrange
        expected_result = types.SimpleNamespace(url="http://example.com")
        mocker.patch.object(stripe.checkout.Session, 'create', return_value=expected_result)

        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][frequency.value]['id']
        trial_days = instance['settings']['stripe']['trialPeriodDays']
        portal_url = instance['settings']['portalUrl']

        args = {
            'instance': instance,
            'frequency': frequency.value,
            'trial_period_used': False,
            'account_type': AccountType.DEFAULT.value
        }
        expected_args = {
            'success_url': f'{portal_url}{stripe_service().success_url}',
            'cancel_url': f'{portal_url}{stripe_service().cancel_url}',
            'mode': StripeCheckoutSessionMode.SUBSCRIPTION.value,
            'line_items': [{
                'price': price_id,
                'quantity': 1
            }],
            'subscription_data': {
                'trial_period_days': trial_days
            }
        }

        # act
        result = stripe_service().create_subscription_checkout_session(**args)

        # assert
        stripe.checkout.Session.create.assert_called_once_with(**expected_args)
        assert result == expected_result

    @pytest.mark.parametrize('frequency', [SubscriptionFrequency.ANNUAL, SubscriptionFrequency.MONTHLY])
    def test_create_subscription_checkout_session_trial_used_and_urls_passed_in(self, mocker, fakers, frequency):
        # arrange
        expected_result = types.SimpleNamespace(url="http://example.com")
        mocker.patch.object(stripe.checkout.Session, 'create', return_value=expected_result)

        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][frequency.value]['id']

        args = {
            'instance': instance,
            'frequency': frequency.value,
            'trial_period_used': True,
            'customer_id': 'cus_123',
            'success_url': 'http://example.com/success',
            'cancel_url': 'http://example.com/cancel',
            'account_type': AccountType.DEFAULT.value
        }
        expected_args = {
            'success_url': args['success_url'],
            'cancel_url': args['cancel_url'],
            'mode': StripeCheckoutSessionMode.SUBSCRIPTION.value,
            'line_items': [{
                'price': price_id,
                'quantity': 1
            }],
            'customer': args['customer_id']
        }

        # act
        result = stripe_service().create_subscription_checkout_session(**args)

        # assert
        stripe.checkout.Session.create.assert_called_once_with(**expected_args)
        assert result == expected_result

    def test_setup_funding_checkout_session(self):
        pytest.skip()

    def test_create_payment_intent(self, fakers, mocker):
        # arrange
        instance = fakers.instance_settings.generate_single({'settings': {'stripe': {'currencyFactor': 0.01}}})
        payment_intent = {'payment': 'intent'}
        mocker.patch.object(stripe.PaymentIntent, 'create', return_value=payment_intent)
        stripe_customer_id = 'cus_123'
        payment_method_id = 'pm_123'
        amount = 100
        order_id = str(ObjectId())
        currency = 'USD'
        give_id = '1'
        currency_factor = instance['settings']['stripe']['currencyFactor']
        payment_method_types = stripe_service().get_payment_method_types(currency)

        # act
        result = stripe_service().create_payment_intent(instance, stripe_customer_id,
                                                        payment_method_id, amount, order_id, currency, give_id)

        # assert
        stripe.PaymentIntent.create.assert_called_once_with(
            customer=stripe_customer_id,
            payment_method=payment_method_id,
            amount=int(amount / currency_factor),
            currency=currency.lower(),
            payment_method_types=payment_method_types,
            off_session=True,
            confirm=True,
            statement_descriptor=f'GIVEWITH* Ref: {give_id}',
            metadata={
                'orderId': order_id
            }
        )
        assert result == payment_intent

    def test_get_checkout_session(self):
        pytest.skip()

    @ pytest.mark.parametrize('action_type', [sat.value for sat in StripeSetupIntentAction])
    def test_create_setup_checkout_session(self, mocker, action_type):
        # arrange
        expected_session = types.SimpleNamespace(url='http://example.com/stripe')
        mocker.patch.object(stripe.checkout.Session, 'create', return_value=expected_session)
        currency = 'USD'
        payment_method_types = stripe_service().get_payment_method_types(currency)
        args = {
            'stripe_customer_id': 'cus_123',
            'currency': currency,
            'success_url': 'http://example.com/success',
            'cancel_url': 'http://example.com/cancel',
            'action_type': action_type
        }
        expected_args = {
            'mode': StripeCheckoutSessionMode.SETUP.value,
            'customer': args['stripe_customer_id'],
            'success_url': args['success_url'],
            'cancel_url': args['cancel_url'],
            'payment_method_types': payment_method_types,
            'setup_intent_data': {
                'metadata': {
                    'action': args['action_type']
                }
            }
        }

        # act
        result = stripe_service().create_setup_checkout_session(**args)

        # assert
        stripe.checkout.Session.create.assert_called_once_with(**expected_args)
        assert result == expected_session

    def test_create_order_setup_checkout_session(self, mocker):
        # arrange
        expected_session = types.SimpleNamespace(url='http://example.com/stripe')
        mocker.patch.object(stripe.checkout.Session, 'create', return_value=expected_session)
        currency = 'USD'
        payment_method_types = stripe_service().get_payment_method_types(currency)
        args = {
            'stripe_customer_id': 'cus_123',
            'currency': currency,
            'success_url': 'http://example.com/success',
            'cancel_url': 'http://example.com/cancel',
            'order_ids': ['123', '456']
        }
        expected_args = {
            'mode': StripeCheckoutSessionMode.SETUP.value,
            'customer': args['stripe_customer_id'],
            'success_url': args['success_url'],
            'cancel_url': args['cancel_url'],
            'payment_method_types': payment_method_types,
            'setup_intent_data': {
                'metadata': {
                    'action': StripeSetupIntentAction.COMPLETE_ORDERS.value,
                    'orderIds': ','.join(args['order_ids'])
                }
            }
        }

        # act
        result = stripe_service().create_order_setup_checkout_session(**args)

        # assert
        stripe.checkout.Session.create.assert_called_once_with(**expected_args)
        assert result == expected_session

    def test_get_stripe_setting_default_default(self):
        result = stripe_service().get_stripe_setting_type(InstanceType.DEFAULT.value, AccountType.DEFAULT.value)
        assert result == 'prices'

    def test_get_stripe_setting_default_procurement(self):
        result = stripe_service().get_stripe_setting_type(InstanceType.DEFAULT.value, AccountType.PROCUREMENT.value)
        assert result == 'prices'

    def test_get_stripe_setting_default_supplier(self):
        result = stripe_service().get_stripe_setting_type(InstanceType.DEFAULT.value, AccountType.SUPPLIER.value)
        assert result == 'prices'

    def test_get_stripe_setting_procurment_default(self):
        result = stripe_service().get_stripe_setting_type(InstanceType.PROCUREMENT.value, AccountType.DEFAULT.value)
        assert result == 'prices'

    def test_get_stripe_setting_procurment_procurement(self):
        result = stripe_service().get_stripe_setting_type(InstanceType.PROCUREMENT.value, AccountType.PROCUREMENT.value)
        assert result == 'prices'

    def test_get_stripe_setting_procurment_supplier(self):
        result = stripe_service().get_stripe_setting_type(InstanceType.PROCUREMENT.value, AccountType.SUPPLIER.value)
        assert result == 'suppliers'


class TestStripeService_Integration:
    pytestmark = pytest.mark.integration

    def test_create_subscription(self, fakers):
        # arrange
        instance = fakers.instance_settings.insert_single()
        account_type = AccountType.DEFAULT.value
        customer = stripe.Customer.create(
            payment_method=StripeTestPaymentMethods.CARD_US_VISA.value,
            invoice_settings={
                'default_payment_method': StripeTestPaymentMethods.CARD_US_VISA.value
            }
        )
        frequency = SubscriptionFrequency.ANNUAL.value

        # act
        subscription = stripe_service().create_subscription(instance, customer.id, frequency, account_type)

        # assert
        assert subscription
        stripe.Customer.delete(customer.id)

    def test_update_customer(self):
        # arrange
        args = {
            'email': 'test@example.com',
            'name': 'Test Example'
        }
        stripe_customer = stripe_service().create_customer(**args)
        args = {
            'stripe_customer_id': stripe_customer.stripe_id,
            'givewith_account_id': str(ObjectId()),
            'sage_customer_id': 'sage_123'
        }

        # act
        stripe_customer = stripe_service().update_customer(**args)

        # assert
        assert stripe_customer.metadata['givewithAccountId'] == args['givewith_account_id']
        assert stripe_customer.metadata['sageCustomerId'] == args['sage_customer_id']
        stripe_service()._delete_customer(stripe_customer.stripe_id)

    def test_create_subscription_checkout_session(self, fakers):
        # arrange
        instance = fakers.instance_settings.generate_single()
        args = {
            'instance': instance,
            'frequency': SubscriptionFrequency.MONTHLY.value,
            'trial_period_used': True
        }

        # act
        checkout_session = stripe_service().create_subscription_checkout_session(**args)

        # assert
        assert checkout_session.url is not None

    def test_create_setup_checkout_session(self):
        # arrange
        customer = stripe_service().create_customer('test@example.com', 'Test Example')

        # act
        checkout_session = stripe_service().create_setup_checkout_session(
            customer.stripe_id,
            'USD',
            'http://example.com',
            'http://example.com',
            StripeSetupIntentAction.UPDATE_SUBSCRIPTION_PAYMENT_METHOD)

        # assert
        assert checkout_session.url
        stripe_service()._delete_customer(customer.stripe_id)

    def test_create_payment_intent_card(self):
        # arrange
        customer = stripe_service().create_customer('test@example.com', 'Test Example')

        args = {
            'stripe_customer_id': customer.stripe_id,
            'payment_method_id': StripeTestPaymentMethods.CARD_US_VISA.value,
            'amount': 100,
            'currency': 'USD',
            'order_id': str(ObjectId()),
            'give_id': '1'
        }

        # act
        payment_intent = stripe_service().create_payment_intent(**args)

        # assert
        assert payment_intent.status == 'succeeded'
        stripe_service()._delete_customer(customer.stripe_id)

    def test_create_payment_intent_bank_account(self):
        # arrange
        customer = stripe_service().create_customer('test@example.com', 'Test Example')

        args = {
            'stripe_customer_id': customer.stripe_id,
            'payment_method_id': StripeTestPaymentMethods.US_BANK_ACCOUNT_SUCCESS.value,
            'amount': 100,
            'currency': 'USD',
            'order_id': str(ObjectId()),
            'give_id': '1'
        }

        # act
        payment_intent = stripe_service().create_payment_intent(**args)

        # assert
        assert payment_intent.status == 'processing'

    @pytest.mark.parametrize('current_frequency, new_frequency, cancel_at_period_end, trialing',
                             [(SubscriptionFrequency.ANNUAL, SubscriptionFrequency.ANNUAL, True, False),
                              (SubscriptionFrequency.ANNUAL, SubscriptionFrequency.MONTHLY, False, True),
                              (SubscriptionFrequency.ANNUAL, SubscriptionFrequency.MONTHLY, False, False)])
    def test_update_subscription_frequency(
            self, fakers, current_frequency, new_frequency, cancel_at_period_end, trialing):
        # arrange
        instance = fakers.instance_settings.generate_single()
        price_id = instance['settings']['stripe']['prices'][current_frequency.value]['id']
        trial_days = instance['settings']['stripe']['trialPeriodDays']
        account_type = AccountType.DEFAULT.value

        customer = stripe.Customer.create(
            payment_method=StripeTestPaymentMethods.CARD_US_VISA.value,
            invoice_settings={'default_payment_method': StripeTestPaymentMethods.CARD_US_VISA.value}
        )
        subscription = stripe.Subscription.create(
            customer=customer.id,
            items=[{
                'price': price_id,
                'quantity': 1
            }],
            trial_period_days=(trial_days if trialing else 0),
            cancel_at_period_end=cancel_at_period_end
        )

        # act
        result = stripe_service().update_subscription_frequency(instance, subscription.id,
                                                                current_frequency.value, new_frequency.value, account_type)

        # asert
        assert result
        stripe.Customer.delete(customer.id)

    def test_create_order_setup_checkout_session(self):
        # arrange
        customer = stripe_service().create_customer('test@example.com', 'Test Example')

        # act
        checkout_session = stripe_service().create_order_setup_checkout_session(
            customer.stripe_id,
            'USD',
            'http://example.com',
            'http://example.com',
            ['123', '456'])

        # assert
        assert checkout_session.url
        stripe_service()._delete_customer(customer.stripe_id)
