import pandas as pd
from portal.shared.constants import MONTH_END_TABLE
from portal.shared.repositories import account_repository, transaction_repository, order_repository, user_repository

class TransactionService:
       
    def monthly_reconciliation_data(self):
        table = MONTH_END_TABLE

        orders = order_repository().get_many()
        for counter in range(len(orders)):
            order = orders[counter]
            account = account_repository().get_single(order.get('account', {}).get('_id'))
            client_name = order.get('createdBy', '')
            if not client_name:
                user = {}
            else:
                user = user_repository().get_single_by_filter({'username':order.get('createdBy')})
            transaction = transaction_repository().get_single_by_filter({'order._id':order.get('_id')})
            
            table['Givewith-Order-ID'][counter] = order.get('_id', '')
            if 'orderDate' in order:
                table['Date'][counter] = order.get('orderDate', '').strftime("%m/%d/%Y")
            else:
                table['Date'][counter] = order.get('createdAt','').strftime("%m/%d/%Y")
            if transaction:
                table['Transaction-ID'][counter] = transaction.get('_id', '')
                table['Transaction-Amount'][counter] = transaction.get('amount', '')
                sage = transaction.get('sage', {})
                # SAGE TRANSACTION INFORMATION
                table['Sage-Bill-Record-Number'][counter] = sage.get('billRecordNumber','')
                table['Sage-Bill-Record-No'][counter]= sage.get('billRecordNo','')
                table['Sage-Invoice-ID'][counter]=sage.get('invoiceId','')
                table['Sage-Invoice-Record-No'][counter]=sage.get('invoiceRecordNo','')
                table['Stripe-Payment-Intent-ID'][counter] = transaction.get('stripe', {}).get('paymentIntentId')
            table['Client-ID'][counter] = str(order.get('account', {}).get('_id', '')).strip()
            table['Customer-Name'][counter] = order.get('customer', {}).get('name', '') if 'customer' in order else order.get('customerName')
            if account:
                table['Client-Account-Name'][counter] = account.get('company',{}).get('name', '')
                table['Stripe-Subscription-ID'][counter] = account.get('stripe', {}).get('subscription', {}).get('id', '')
                table['Subscription-Term'][counter]=account.get('subscriptionFrequency', '')
                table['Sage-Customer-ID'][counter]=account.get('sageCustomerId','')
                stripe = account.get('stripe',{})
                table['Autopay'][counter] = True if stripe.get('autopay', {}).get('paymentMethodId', '') else False
                table['Stripe-Customer-ID'][counter] = stripe.get('customerId','')
                table['Stripe-Period-End'][counter] = stripe.get('subscription', {}).get('currentPeriodEnd','N/A')
                if table['Stripe-Period-End'][counter] != 'N/A':
                    table['Stripe-Period-End'][counter]= stripe.get('subscription', {}).get('currentPeriodEnd').strftime("%m/%d/%Y")
                table['Stripe-Period-Start'][counter] = stripe.get('subscription', {}).get('currentPeriodStart', 'N/A')
                if table['Stripe-Period-Start'][counter] != 'N/A':
                    table['Stripe-Period-Start'][counter]= stripe.get('subscription', {}).get('currentPeriodStart').strftime("%m/%d/%Y")
            table['Status'][counter] = order.get('status', '').strip()
            table['Give-Amount'][counter] = order.get('grandTotal', '')
            table['Social-Cause'][counter] = order.get('causeArea', {}).get('name', '').strip()
            table['User-Email'][counter] = order.get('createdBy', '').strip()
            table['Client-Name'][counter] = user.get('name','') if 'name' in user else user.get('displayName', '')
        return pd.DataFrame(table)