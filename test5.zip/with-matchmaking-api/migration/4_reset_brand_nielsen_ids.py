from matchmaking import db
from bson import ObjectId
from pymongo import UpdateOne


companies = [
    ('Nestle', '5c58a13df46115000961ea27'),
    ("Lowe's Companies", '5c1415685b03bb0008c21cee'),
    ('Lexus', '5c4f6be96fcbf8000868d9f5'),
    ('General Electric', '5c1415685b03bb0008c2185e'),
    ('True Value', '5cc76db59e600660968242c0'),
    ('Mars, Inc.', '5cc853ae9e60066095dea68a'),
    ('TIAA', '5cc855219e60066096827161'),
    ('Canon', '5c58a13df46115000961ed00'),
    ('Burlington Coat Factory', '5c1415685b03bb0008c21ebc'),
    ('Skechers USA', '5c1415685b03bb0008c21ac0'),
    ('Kraft Foods Group, Inc.', '5c1415685b03bb0008c22020'),
    ('Carlsberg', '5c58a13df46115000961ed28'),
    ('Heineken', '5c58a13df46115000961eeaf'),
    ('Dr Pepper Snapple Group, Inc.', '5c1415685b03bb0008c21eab'),
    ('Staples, Inc.', '5cc855cdc603cd624639af00'),
    ('Bayer', '5c58a13df46115000961e595'),
    ('Burger King', '5c58a13df46115000961f7db'),
    ('Target', '5c1415685b03bb0008c21e1d'),
    ('Dell', '5c38e8f7a443cb000886b251'),
    ('ConAgra Foods, Inc.', '5c1415685b03bb0008c21762'),
    ('Wyndham Worldwide Corporation', '5c1415685b03bb0008c222af'),
    ('Whole Foods Market, Inc.', '5c1415685b03bb0008c21b01'),
    ('Northwestern Mutual Life Insurance Company', '5cc856699e60066095dea754'),
    ('Discovery Communications, Inc.', '5c1415685b03bb0008c21a1f'),
    ('Liberty Mutual Holding Company Inc.', '5c58a13df46115000961f44a'),
    ('Safeway Inc.', '5c58a13df46115000961f832'),
    ('Google', '5c1415685b03bb0008c221bb'),
    ('Warner Media', '5c1415685b03bb0008c21ae0'),
    ('DIRECTV', '5c1415685b03bb0008c21ae0'),
    ('Danone / Dannon', '5c58a13df46115000961ee6e'),
    ('Unilever', '5c58a13df46115000961f292'),
    ('Walmart Stores', '5c1415685b03bb0008c218e4'),
    ('Nissan', '5c58a13df46115000961f041'),
    ('Pernod-Ricard', '5c58a13df46115000961e862'),
    ('Adidas', '5cc856c5c603cd6247af26c9'),
    ('ING', '5c58a13df46115000961e678'),
    ('Carnival', '5c1415685b03bb0008c21935'),
    ('Coach, Inc.', '5c1415685b03bb0008c21bab'),
    ('H.J. Heinz Company', '5c1415685b03bb0008c22020'),
    ('Pacific Life', '5cc857c3c603cd6247af2703'),
    ('CVS Caremark', '5c1415685b03bb0008c21b73'),
    ('J.M. Smucker Company', '5c1415685b03bb0008c21722'),
    ('BMW', '5c58a13df46115000961eae0'),
    ('Warby Parker', '5cc8580b82098a60a61dba59'),
    ('Zurich Financial Services', '5c58a13df46115000961ebf4'),
    ('Toyota', '5c58a13df46115000961f21f'),
    ('State Farm Insurance Cos.', '5cc8585e82098a60a61dba73'),
    ('LVMH', '5cc858c0c603cd624639afce'),
    ('IKEA', '5cc8591d9e60066095dea80c'),
    ('Hyundai Kia', '5c58a13df46115000961e826'),
('HP', '5c1415685b03bb0008c221ba'),
    ('Walgreen Co.', '5c1415685b03bb0008c22143'),
    ('J.C. Penney Company, Inc.', '5c1415685b03bb0008c21963'),
    ('PetSmart, Inc.', '5cc859549e600660968272ab'),
    ('Apple', '5c1415685b03bb0008c21b1c'),
    ('Porsche AML', '5c58a13df46115000961ebdb'),
    ('Priceline Group Inc.', '5c1415685b03bb0008c2197d'),
    ('Nokia', '5c58a13df46115000961e599'),
    ('TD Bank', '5c58a13df46115000961e88e'),
    ('Spotify', '5cc85a2682098a60a793b196'),
    ('BP', '5c58a13df46115000961e8f4'),
    ('Honest Company', '5cc85aca9e6006609682730e'),
    ('Pandora', '5c1415685b03bb0008c21f92'),
    ('Lyft', '5cc85b619e60066095dea894'),
    ('J.P. Morgan Chase & Co.', '5c1415685b03bb0008c21967'),
    ('SAP', '5c58a13df46115000961f7a1'),
    ('Airbnb', '5cc85b9e9e60066096827346'),
    ('Oracle Corporation', '5c1415685b03bb0008c21976'),
    ("Popeye's", '5c58a13df46115000961f7db'),
    ('Sonic', '5cc85bd782098a60a793b20c'),
    ('Lego', '5cc85c679e60066095dea8ee'),
]



updates = []
for company in companies:
    nielsen_company = company[0]
    obj_id = ObjectId(company[1])
    updates.append(
        UpdateOne(
            filter={'_id': obj_id},
            update={'$set': {'nielsen_company': nielsen_company}},
            upsert=False
        ))

result = db().coll_brands.bulk_write(updates)

