from pymongo.database import Database
from datetime import datetime

"""
Adds default instance ref to accounts if they don't have an instance set
"""
name = '20220726224224'
dependencies = ['20220722180754']


def upgrade(db: Database):
    accounts_with_no_instance = db['account'].find({'instance': {'$exists': False}}, {'_id': 1})
    if not accounts_with_no_instance:
        return

    instance = db['instance_settings'].find_one({'name': 'Givewith for Sales'})
    now = datetime.utcnow()
    account_update = {
        '$set': {
            'instance': {
                '_id': instance['_id'],
                '_type': 'instance_settings',
                'name': instance['name']
            },
            'lastUpdatedBy': 'admin@givewith.com',
            'lastUpdated': now
        }
    }

    for account_with_no_instance in accounts_with_no_instance:
        account_id = account_with_no_instance['_id']
        db['account'].update_one({'_id': account_id}, account_update)


def downgrade(db: Database):
    pass
