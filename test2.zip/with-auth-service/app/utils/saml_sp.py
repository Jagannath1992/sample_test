from flask import current_app
from signxml import XMLSigner
from defusedxml import lxml

import datetime
import uuid
import base64


def create_sp_metadata(app_config, sp_name):
    """
    create saml sp metadata xml
    """
    sp_config = app_config['config']['saml']['sp'].get(sp_name)
    if sp_config is None:
        return None

    certificate_file = app_config['certificate']

    # read idp metadata template
    metadata = read_sp_metadata_template()

    # update macros
    two_days_later = (datetime.datetime.utcnow() + datetime.timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%S.%f%Z")
    metadata_values = {
        'valid-until': two_days_later,
        'entity-id': sp_config.get('entity_id'),
        'assertion-endpoint': sp_config.get('assertion_endpoint'),
        'certificate': get_certificate_content(certificate_file),
    }

    for key in metadata_values.keys():
        metadata = metadata.replace('{{' + key + '}}', metadata_values.get(key))

    return metadata


def create_saml_request(app_config, sp_name):
    sp_config = app_config['config']['saml']['sp'][sp_name]
    if sp_config is None:
        return None

    # create saml request
    saml_request = read_saml_request_template()
    now = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f%Z")

    request_values = {
        'request-id': str(uuid.uuid4()),
        'issue-instant': now,
        'issuer': sp_config['issuer'],
        'destination': sp_config['destination'],
        'assert-url': sp_config['assertion_endpoint'],
    }

    for key in request_values.keys():
        saml_request = saml_request.replace('{{' + key + '}}', request_values.get(key))

    # sign saml request
    certificate = app_config['certificate']
    private_key = app_config['private_key']
    signer = XMLSigner(signature_algorithm=sp_config['signature_algo'], c14n_algorithm=sp_config['c14n_algo'])
    response_root = lxml.fromstring(saml_request)
    signed_request = signer.sign(response_root, key=read_file_bytes(private_key), cert=read_file_bytes(certificate))
    singed_request_str = lxml.tostring(signed_request).decode('utf-8')

    request_bytes = singed_request_str.encode('ascii')
    return base64.b64encode(request_bytes)


def get_certificate_content(certificate):
    """
    :param certificate:
    :return: certificate content without header and footer
    """
    file = open(certificate.name, 'r')
    lines = file.readlines()[1:-1]
    certificate_str = ''
    for l in lines:
        certificate_str += l.strip()

    return certificate_str


def read_file_bytes(file):
    f = open(file.name, 'r')
    return f.read()


def read_sp_metadata_template():
    return read_xml_file('./saml_template/sp/givewith/metadata.xml')


def read_saml_request_template():
    return read_xml_file('./saml_template/sp/givewith/saml_request.xml')


def read_xml_file(path):
    with current_app.open_resource(path, 'r') as file:
        return file.read().replace('\n', '')
