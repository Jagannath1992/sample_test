from matchmaking.validation.utils import is_valid_phone_number
patch_info_request_schema = {
    'orgDescription': {
        'type': 'string',
        'empty': True,
    },
    'name': {
        'type': 'string',
        'empty': True,
    },
    'title': {
        'type': 'string',
        'empty': True,
    },
    'email': {
        'type': 'string',
        'empty': True,
    },
    'phone': {
        'type': 'string',
        'empty': True,
        'validator': is_valid_phone_number,
    },
    'address': {
        'type': 'string',
        'empty': True,
    },
    'city': {
        'type': 'string',
        'empty': True,
    },
    'state': {
        'type': 'string',
        'empty': True,
    },
    'zip': {
        'type': 'string',
        'empty': True,
    },
}


patch_review_request_schema = {
    'name' :{
        'type': 'string',
        'empty': True,
    },
    'email': {
        'type': 'string',
        'empty': True,
    }
}
