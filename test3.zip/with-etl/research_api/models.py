import copy

from .utils import *

from bson import ObjectId
from cerberus import Validator


class GivewithValidator(Validator):
    def _validate_type_object_id(self, value):
        if type(value) == ObjectId:
            return True


def get_schemata(dataset, allowed_rules={}):
    """
    Returns a schemata with 'allowed' fields pulled from DB and attached, split into seperate normalized and validation schemata
    TODO: Log any rules that didn't get set, this might mean a header got renamed

    It is impossible to normalize and rename using verberus without having 2 seperate schema.
    To simplify this, this function will return two schemata, `normalize_schema` and `validation_schema`.
    validate_schema is calculated from the original schema, but with its 'rename' fields as the actual name
    """
    if dataset in _SCHEMATA:
        schema = _SCHEMATA[dataset]

        # Add 'allowed' fields from lookup_data to their respective schema objects
        for field, allowed in allowed_rules.items():
            # skip '_id' field automatically added by Mongo
            if field == '_id':
                continue

            # Sheets returns a delete character (hex code 127) in the beginning of some strings
            # This strips these characters from strings
            allowed = [a.strip(chr(127)) if isinstance(a, str) else a for a in allowed]
            if field in schema:
                schema[field]['allowed'] = allowed

                # Add the lowercase version of all allowed rules
                if isinstance(allowed, list):
                    schema[field]['allowed'].extend([x.lower() for x in allowed])

        return _split_schema(schema)

    else:
        raise DatasetNotFound(dataset)


def _split_schema(schema):
    """
    Splits a schema into a 'normalization_schema' and 'validation_schema'
    """
    validation_schema = copy.deepcopy(schema)
    normalization_schema = copy.deepcopy(schema)

    for key, rule in schema.items():
        if 'rename' in rule:
            # Rename the rule
            validation_schema[rule['rename']] = validation_schema.pop(key)
            validation_schema[rule['rename']].pop('rename')

            normalization_schema[rule['rename']] = normalization_schema[key]

    # When normalizing, cerberus will rename first, then do the rest
    # therefore, we must include the new names in the normalization_schema as well
    # normalization_schema.update(validation_schema)

    # We do not want to block rows because of missing fields before they are renamed
    for key, rule in normalization_schema.items():
        rule.pop('required', None)

    # Renaming currently messes up the 'allowed' fields rule
    [x.pop('rename', '') for x in validation_schema.values()]

    # Coerce currently messes up the 'allowed' fields rule
    [x.pop('coerce', '') for x in validation_schema.values()]

    return normalization_schema, validation_schema


def _to_object_id(value):
    return ObjectId(value.strip()) if type(value) == str else value


def _to_number(value):
    return float(value) if type(value) == str else value


def _to_integer(value):
    return int(value) if type(value) == str else value


def _to_clean_str(value):
    # strip whitspace before string -> strip any backspace chars -> strip whitespace again
    return value.strip().strip(chr(127)).strip()


def _to_bool(value):
    return value.lower() in ('true', '1', 'yes') if type(value) == str else value


def _to_csrit_list(value):
    """ CSRIT lists are seperated by ';' """
    if isinstance(value, list):
        return list()
    else:
        return [_to_clean_str(x) for x in value.split(';') if _to_clean_str(x)]


def _to_csrit_set(value):
    """ CSRIT lists as a set """
    if isinstance(value, set):
        return set()
    else:
        return {_to_clean_str(x) for x in value.split(';') if _to_clean_str(x)}


type_object_id = ['object_id', 'string']


v = GivewithValidator(empty=True, require_all=False)


_SCHEMATA = {
    'CSRIT': {
        '_id': {'type': type_object_id},
        'object id': {'rename': 'brandId', 'required': True, 'type': type_object_id, 'coerce': _to_object_id},
        'research id': {'rename': 'researchId', 'required': True, 'type': 'integer', 'coerce': _to_integer},
        'company name': {'rename': 'brandName', 'type': 'string'},
        'company investment type': {'rename': 'investmentTypes', 'type': 'list', 'coerce': _to_csrit_list},
        'company strategy': {'rename': 'initiativeStrategies', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'company goal or program name': {'rename': 'goalName', 'type': 'string'},
        'nonprofit name': {'rename': 'nonprofitNames', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'other nonprofit name + ein': {'rename': 'otherNonprofitNames', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'nonprofit program name': {'rename': 'programName', 'type': 'string'},
        'program description': {'rename': 'researchProgramDescription', 'type': 'string'},
        'partnership duration': {'rename': 'partnershipDurations', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'source year': {'rename': 'sourceYears', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'partnership type': {'rename': 'partnershipTypes', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'contient/continental region of program': {'rename': 'continents', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'country of program': {'rename': 'countries', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'state or province (us & canada only)': {'rename': 'states', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'city': {'rename': 'cities', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'other city (not in dropdown)': {'rename': 'otherCities', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'theme alignment': {'rename': 'themes', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'impact alignment': {'rename': 'programImpacts', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'sdg alignment': {'rename': 'sdgs', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'relevancy/importance': {'rename': 'relevancies', 'type': 'list', 'coerce': _to_csrit_list, 'schema': {'type': 'string'}},
        'no data': {'empty': True, 'rename': 'noData', 'type': 'string'},
        'source link': {'rename': 'sources', 'type': 'set', 'coerce': _to_csrit_set, 'schema': {'type': 'string'}},
        'reviewed? y/n': {'rename': 'reviewed', 'type': 'boolean', 'coerce': _to_bool},
        'narrative': {'type': 'string'}
    }
}

# Uses mapped names from translate columns (e.g. "ACCESS_TO_FINANCE")
MSCI_BASE_COLUMNS = [
    'ACCESS_TO_COMMUNICATIONS',
    'ACCESS_TO_FINANCE',
    'ACCESS_TO_HLTHCRE',
    'BIODIV_LAND_USE',
    'CARBON_EMISSIONS',
    'CHEM_SAFETY',
    'CONTROV_SRC',
    'CORP_GOVERNANCE',
    'ENERGY_EFFICIENCY',
    'ENVIRONMENTAL_PILLAR',
    'E_WASTE',
    'FINANCING_ENV_IMP',
    'FIN_PROD_SAFETY',
    'GOVERNANCE_PILLAR',
    'HLTH_SAFETY',
    'HUMAN_CAPITAL_DEVELOPMENT',
    'CLIMATE_CHANGE_VULNERABILITY',
    'INS_HLTH_DEMO_RISK',
    'LABOR_MGMT',
    'OPPS_CLN_TECH',
    'OPPS_GREEN_BUILDING',
    'OPPS_NUTRI_HLTH',
    'OPPS_RENEW_ENERGY',
    'PACK_MAT_WASTE',
    'PRIVACY_DATA_SEC',
    'PROD_CARB_FTPRNT',
    'PROD_SFTY_QUALITY',
    'RAW_MAT_SRC',
    'RESPONSIBLE_INVESTMENT',
    'SOCIAL_PILLAR',
    'SUPPLY_CHAIN_LAB',
    'TOXIC_EMISS_WSTE',
    'WATER_STRESS'
]
# Some fields are mapped to themselves because they're required and this is used for validation
MSCI_TRANSLATE_COLUMNS = {
    'ISSUER_TICKER': 'msciId',
    'ISSUER_NAME': 'ISSUER_NAME',
    'ISSUER_ISIN': 'ISSUER_ISIN',
    'ISSUER_CUSIP': 'ISSUER_CUSIP',
    'ISSUER_SEDOL': 'ISSUER_SEDOL',
    'GICS_SUB_IND': 'esg_industry',
    'INDUSTRY_ADJUSTED_SCORE': 'INDUSTRY_ADJUSTED_SCORE',
    'IVA_COMPANY_RATING': 'IVA_COMPANY_RATING',

    'INS_CLIMATE_CHG_RISK_WEIGHT': 'CLIMATE_CHANGE_VULNERABILITY_WEIGHT',
    'INS_CLIMATE_CHG_RISK_QUARTILE': 'CLIMATE_CHANGE_VULNERABILITY_QUARTIle',
    'INS_CLIMATE_CHG_RISK_SCORE': 'CLIMATE_CHANGE_VULNERABILITY_SCORE',

    'HUMAN_CAPITAL_DEV_WEIGHT': 'HUMAN_CAPITAL_DEVELOPMENT_WEIGHT',
    'HUMAN_CAPITAL_DEV_QUARTILE': 'HUMAN_CAPITAL_DEVELOPMENT_QUARTILE',
    'HUMAN_CAPITAL_DEV_SCORE': 'HUMAN_CAPITAL_DEVELOPMENT_SCORE',

    'RESPONSIBLE_INVEST_WEIGHT': 'RESPONSIBLE_INVESTMENT_WEIGHT',
    'RESPONSIBLE_INVEST_QUARTILE': 'RESPONSIBLE_INVESTMENT_QUARTILE',
    'RESPONSIBLE_INVEST_SCORE': 'RESPONSIBLE_INVESTMENT_SCORE',

    'ACCESS_TO_COMM_WEIGHT': 'ACCESS_TO_COMMUNICATIONS_WEIGHT',
    'ACCESS_TO_COMM_QUARTILE': 'ACCESS_TO_COMMUNICATIONS_QUARTILE',
    'ACCESS_TO_COMM_SCORE': 'ACCESS_TO_COMMUNICATIONS_SCORE',

    'ACCESS_TO_FIN_WEIGHT': 'ACCESS_TO_FINANCE_WEIGHT',
    'ACCESS_TO_FIN_QUARTILE': 'ACCESS_TO_FINANCE_QUARTILE',
    'ACCESS_TO_FIN_SCORE': 'ACCESS_TO_FINANCE_SCORE',   
}

MSCI_REQUIRED_COLUMNS = list(MSCI_TRANSLATE_COLUMNS.keys())

# MSCI_FLOAT_COLUMNS = [
#     'CARBON_EMISSIONS_WEIGHT',
#     'CARBON_EMISSIONS_QUARTILE',
#     'CARBON_EMISSIONS_SCORE',

#     'INS_CLIMATE_CHG_RISK_WEIGHT',
#     'INS_CLIMATE_CHG_RISK_QUARTILE',
#     'INS_CLIMATE_CHG_RISK_SCORE',

#     'HUMAN_CAPITAL_DEV_WEIGHT',
#     'HUMAN_CAPITAL_DEV_QUARTILE',
#     'HUMAN_CAPITAL_DEV_SCORE',

#     'RESPONSIBLE_INVEST_WEIGHT',
#     'RESPONSIBLE_INVEST_QUARTILE',
#     'RESPONSIBLE_INVEST_SCORE',

#     'ACCESS_TO_COMM_WEIGHT',
#     'ACCESS_TO_COMM_QUARTILE',
#     'ACCESS_TO_COMM_SCORE',

#     'ACCESS_TO_FIN_WEIGHT',
#     'ACCESS_TO_FIN_QUARTILE',
#     'ACCESS_TO_FIN_SCORE',

#     'SOCIAL_PILLAR_QUARTILE',
#     'SOCIAL_PILLAR_SCORE',
#     'SOCIAL_PILLAR_WEIGHT',
#     'GOVERNANCE_PILLAR_QUARTILE',
#     'GOVERNANCE_PILLAR_SCORE',
#     'GOVERNANCE_PILLAR_WEIGHT',
#     'ENVIRONMENTAL_PILLAR_QUARTILE',
#     'ENVIRONMENTAL_PILLAR_SCORE',
#     'ENVIRONMENTAL_PILLAR_WEIGHT',
# ]

