import json

def test_nonprofit_overview(client, admin_header, client_header, invalid_header):
    response = client.get('/nonprofit/x-7/overview-video', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/nonprofit/x-7/overview-video', headers=client_header)
    assert response.status_code == 200

    response = client.get('/nonprofit/x-7/overview-video', headers=invalid_header)
    assert response.status_code == 200


def test_nonprofit_overview_video(client, admin_header):
    # test if nonprofit overview video exists
    response_overview = client.get('/nonprofit/x-7/overview-video', headers=admin_header)
    data_overview = json.loads(response_overview.data.decode())

    assert 'media' in data_overview
    assert 'thumbnail' in data_overview


def test_nonprofit_overview_vimeo(client, admin_header):
    # if no overview video, return vimeo id
    response_vimeo = client.get('/nonprofit/sotires/overview-video', headers=admin_header)
    data_vimeo = json.loads(response_vimeo.data.decode())

    assert data_vimeo.get('media') == '309557558'


def test_nonprofit_overview_fallback_image(client, admin_header):
     # if no vimeoId, get fallback image
    response_photo = client.get('/nonprofit/waterkeeper-coastal-cleanup/overview-video', headers=admin_header)
    data_photo = json.loads(response_photo.data.decode())

    assert 'media' in data_photo
    assert 'thumbnail' in data_photo


def test_nonprofit_overview_video_fallback(client, admin_header):
    # finally, if no fallback image, return videoFallback
    response_fallback = client.get('/nonprofit/volunteers-of-america-s-national-veterans-resource-squad-1/overview-video', headers=admin_header)
    data_fallback = json.loads(response_fallback.data.decode())

    assert data_fallback.get('media') == 'https://s3.amazonaws.com/givewith-campaign-assets.staging/nonprofits/5b29101ce3dde10019e1773b/GW_Waterkeeper_NPO_LND_1560x780_1545178108093_1584563008631.jpg'
