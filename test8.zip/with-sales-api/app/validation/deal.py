from app.validation.utils import validate_object_id
from app.db.utils import get_document_by_id


def validate_create_deal_request(request, payment_option):
    errors = []
    if request is None:
        errors.append('invalid request')
        return errors

    if 'companyId' not in request:
        errors.append('companyId is required')
    else:
        if not validate_object_id(request.get('companyId'), 'mm_brands'):
            errors.append('companyId not found')

    # other version is 'prePaid'
    if payment_option == 'payAsYouGo':
        if 'transactionAmount' not in request:
            errors.append('transactionAmount is required')
            return errors

        if request['transactionAmount'] <= 0:
            errors.append('invalid transaction amount')
    else:
        if 'fundingAmount' not in request:
            errors.append('fundingAmount is required')
            return errors

        if request['fundingAmount'] <= 0:
            errors.append('invalid transaction amount')

    return errors

def validate_confirmation_pending_deal_request(request, deal_id):
    errors = []
    if request is None:
        errors.append('invalid request')
        return errors

    if not validate_object_id(deal_id, 'deals'):
        errors.append('deal not found')

    if 'selectedProgram' not in request:
        errors.append('no program selected')
    elif 'selectedProgram' in request and not validate_object_id(request['selectedProgram'], 'mm_programs'):
        errors.append('selected program not found')

    return errors

def validate_payment_pending_deal_request(request, deal_id):
    errors = []
    if request is None:
        errors.append('invalid request')
        return errors

    if not validate_object_id(deal_id, 'deals'):
        errors.append('deal not found')

    deal = get_document_by_id('deals', deal_id)

    if ('programId' not in request) and ('selectedProgram' not in deal):
        errors.append('selected program is required')
        return errors

    if 'programId' in request:
        if not validate_object_id(request['programId'], 'mm_programs'):
            errors.append('selected program not found')

    customer_brand = get_document_by_id('mm_brands',
                                        deal.get('givewithCustomer'),
                                        projection={'paymentOption': True })

    payment_option = deal.get('paymentOption') or customer_brand.get('paymentOption', 'payAsYouGo')

    # other version is 'prePaid'
    if payment_option == 'payAsYouGo':
        if 'transactionAmount' not in request:
            errors.append('transactionAmount is required')
            return errors

        if request['transactionAmount'] <= 0:
            errors.append('invalid transaction amount')
    else:
        if 'fundingAmount' not in request:
            errors.append('fundingAmount is required')
            return errors

        if request['fundingAmount'] <= 0:
            errors.append('invalid funding amount')

    return errors
