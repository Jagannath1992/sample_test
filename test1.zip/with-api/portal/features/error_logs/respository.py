from portal.shared.repository import DocumentRepository


class ErrorLogRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['error_log'])
