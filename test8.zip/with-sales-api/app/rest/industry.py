from flask import jsonify
from flask_restful import Resource

from app.db.utils import get_document
from app.utils.auth import authenticate, can
from rbac_library.constants import Action


class IndustryList(Resource):
    @authenticate
    @can(Action.READ)
    def get(self):
        """
        get industries
        """
        return jsonify(get_document('industry_display_map'))