import multiprocessing
import pytest
from portal.shared.repositories import account_repository


class TestAccountRepository:
    def test_company_exists(self, fakers):
        existing = fakers.account.insert_single()
        account_repo = account_repository()

        assert account_repo.company_exists(existing['company']['name'])
        assert not account_repo.company_exists('Nonexistant Company')

    def test_get_accounts(self, repositories, fakers):
        expected = fakers.account.insert_many(3)
        account_repo = repositories['account']

        request_filters = {
            'count': 10,
            'offset': 0,
            'orderBy': 'id',
            'descending': False
        }

        actual = account_repo.get_page(request_filters)

        assert actual == (3, expected)

    def test_company_filter(self, repositories, fakers):
        expected = fakers.account.insert_many(5)
        account_repo = repositories['account']
        expected_company = expected[1]

        request_filters = {
            'count': 10,
            'offset': 0,
            'orderBy': 'id',
            'descending': False,
            'company.name': expected_company.get('company').get('name')
        }

        actual = account_repo.get_page(request_filters)

        assert actual == (1, [expected_company])

    def test_address_filter(self, repositories, fakers):
        expected = fakers.account.insert_many(5)
        account_repo = repositories['account']
        expected_address = expected[1]

        request_filters = {
            'count': 10,
            'offset': 0,
            'orderBy': 'id',
            'descending': False,
            'company.address.city': expected_address.get('company').get('address').get('city')
        }

        actual = account_repo.get_page(request_filters)

        assert actual == (1, [expected_address])

    def test_update_account(self, repositories, fakers):
        account = fakers.account.insert_single()
        assert account['company']['name'] == 'Company name 0'

        account_repo = repositories['account']
        account['company']['name'] = 'New Company name!'
        account = account_repo.update(account)

        assert account['company']['name'] == 'New Company name!'
        assert account_repo.get_single(account.get('_id')) == account

    def test_create_account(self, repositories, fakers):
        account_repo = repositories['account']
        new = fakers.account.generate_new()

        assert account_repo.collection.count_documents(filter={}) == 0

        account = account_repo.insert(new)

        assert account_repo.collection.count_documents(filter={}) == 1
        assert account == account_repo.get_single(account['_id'])

    def test_get_industries(self, db, repositories):
        # arrange
        expected = {
            'Industry 1': [
                {
                    'displayLabel': 'Industry 1.1',
                    'subIndustry': 'Sub Industry 1.1'
                },
                {
                    'displayLabel': 'Industry 1.2',
                    'subIndustry': 'Sub Industry 1.2'
                }
            ],
            'Industry 2': [
                {
                    'displayLabel': 'Industry 2.1',
                    'subIndustry': 'Sub Industry 2.1'
                }
            ]
        }
        db.industry_display_map.insert_one(expected)

        # act
        actual = repositories['account'].get_industries()

        # assert
        assert actual == expected

    def test_get_next_give_id(self, fakers, db):
        # arrange
        account = fakers.account.insert_single()

        # act
        result = account_repository().get_next_give_id(account['_id'])

        # assert
        assert db.account.find_one({'_id': account['_id']})['nextGiveId'] == account['nextGiveId'] + 1
        assert result == account['nextGiveId']

    def test_get_next_give_id_field_does_not_exist(self, fakers, db):
        # arrange
        account = fakers.account.generate_single()
        del account['nextGiveId']
        db.account.insert_one(account)

        # act
        result = account_repository().get_next_give_id(account['_id'])

        # assert
        assert db.account.find_one({'_id': account['_id']})['nextGiveId'] == 2
        assert result == 1

    @pytest.mark.skip
    def test_get_next_give_id_parallel(self, fakers):
        # arrange
        def call_get_next_give_id_and_update_ids(accountId, ids):
            id = account_repository().get_next_give_id(accountId)
            ids[id] = id

        range_end = 1000
        manager = multiprocessing.Manager()
        ids = manager.dict()
        account = fakers.account.insert_single()
        processes = []

        # act
        for _ in range(0, range_end):
            p = multiprocessing.Process(target=call_get_next_give_id_and_update_ids, args=(account['_id'], ids))
            p.start()
            processes.append(p)
        for p in processes:
            p.join()

        # assert
        assert account_repository().get_single(account['_id'])['nextGiveId'] == range_end + 1
        assert len(ids) == range_end
