import pytest
from bson import ObjectId
from datetime import datetime
from unittest.mock import call
from portal.shared.email.enums import EmailTemplateId
from portal.shared.enums import OrderStatus, UserRole
from portal.shared.constants import ROLES_TO_STRING
from portal.shared.repositories import account_approval_repository, locale_repository, user_repository, account_repository
from portal.shared.services import email_service
from portal.shared.strings import format_currency, format_phone_number, format_zip_code


class TestEmailService:
    def test_send_new_account_created_email(self, mocker, fakers):
        # arrange
        instance = fakers.instance_settings.generate_single()
        user = fakers.user.generate_single()
        account = fakers.account.generate_single()
        company = account['company']
        address = company['address']
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']
        expected_payload = {
            'tos': [givewith_email],
            'ccs': [],
            'bccs': [],
            'template': {
                'id': EmailTemplateId.PORTAL_ACCOUNTS_NEW_ACCOUNT_CREATED.value,
                'data': {
                    'firstName': user['first_name'],
                    'lastName': user['last_name'],
                    'username': user['username'],
                    'company': company['name'],
                    'address1': address['address1'],
                    'address2': address['address2'],
                    'city': address['city'],
                    'stateProvince': address['stateProvince'],
                    'postalCode': format_zip_code(address['postalCode']),
                    'industry': account['industry']['displayLabel'],
                    'phoneNumber': format_phone_number(company['phoneNumber']),
                    'website': company['website'],
                    'activateUrl': f'{portal_url}/app/accounts/{account["_id"]}'
                }
            }
        }

        mocker.patch.object(email_service(), 'send_email', return_value=expected_payload)

        # act
        response = email_service().send_new_account_created_email(instance, user, account)

        # assert
        email_service().send_email.assert_called_once_with(expected_payload)
        assert response == expected_payload

    @pytest.fixture
    def test_send_account_activated_email_init(self, fakers, mocker):
        mocker.patch.object(user_repository(), 'get_usernames_by_role', return_value=['givewith', 'finance'])
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        payload = {
            'tos': ['givewith', 'finance'],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_ACCOUNTS_ACCOUNT_ACTIVATED.value,
                'data': {}
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        return instance, account, payload

    def test_send_account_activated_email(self, test_send_account_activated_email_init):
        # arrange
        instance, account, payload = test_send_account_activated_email_init

        # act
        response = email_service().send_account_activated_email(instance, account)

        # assert
        user_repository().get_usernames_by_role.assert_called_once_with(account['_id'], [UserRole.SUPER_ADMIN, UserRole.FINANCE])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_account_deactivated_email_init(self, fakers, mocker):
        mocker.patch.object(user_repository(), 'get_usernames_by_role', return_value=['finance'])
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        payload = {
            'tos': ['finance'],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_ACCOUNTS_ACCOUNT_DEACTIVATED.value,
                'data': {
                    'clientName': account['company']['name'],
                    'sageCustomerId': account.get('sageCustomerId', '')
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        return instance, account, payload

    def test_send_account_deactivated_email(self, test_send_account_deactivated_email_init):
        # arrange
        instance, account, payload = test_send_account_deactivated_email_init

        # act
        response = email_service().send_account_deactivated_email(instance, account)

        # assert
        user_repository().get_usernames_by_role.assert_called_once_with(account['_id'], [UserRole.FINANCE])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_user_resend_invite_email(self, mocker):
        # arrange
        expected_payload = {
            'tos': [],
            'ccs': [],
            'bccs': [],
            'template': {
                'id': EmailTemplateId.PORTAL_USERS_RESEND_INVITE.value,
                'data': {}
            }
        }

        mocker.patch.object(email_service(), 'send_email', return_value=expected_payload)

        # act
        response = email_service().send_user_resend_invite_email()

        # assert
        email_service().send_email.assert_called_once_with(expected_payload)
        assert response == expected_payload

    @pytest.fixture
    def test_send_give_submitted_for_approval_email_init(self, fakers, mocker):
        mocker.patch.object(account_approval_repository(), 'get_approver', return_value='approver')
        mocker.patch.object(user_repository(), 'get_usernames_by_role', side_effect=[['approver1', 'approver2'], ])
        instance = fakers.instance_settings.generate_single()
        locale = fakers.locale.generate_single()
        order = fakers.order.generate_single()
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        symbol = locale['settings']['symbol']
        payload = {
            'tos': ['approver'],
            'ccs': [order['createdBy']],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_SUBMITTED_FOR_APPROVAL.value,
                'data': {
                    'giveId': order['giveId'],
                    'customerName': order['customerName'],
                    'grandTotal': format_currency(symbol, order['grandTotal']),
                    'quoteNumber': order['quoteNumber'],
                    'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details',
                    'showErrorMessage': False
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        return instance, order, payload

    def test_send_give_submitted_for_approval_email(self, test_send_give_submitted_for_approval_email_init):
        # arrange
        instance, order, payload = test_send_give_submitted_for_approval_email_init

        # act
        response = email_service().send_give_submitted_for_approval_email(instance, order)

        # assert
        account_approval_repository().get_approver.assert_called_once_with(order['account']['_id'], order['grandTotal'])
        user_repository().get_usernames_by_role.assert_not_called()
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_give_submitted_for_approval_email_no_single_approver(self, test_send_give_submitted_for_approval_email_init):
        # arrange
        account_approval_repository().get_approver.return_value = None
        instance, order, payload = test_send_give_submitted_for_approval_email_init
        payload['tos'] = ['approver1', 'approver2']

        # act
        response = email_service().send_give_submitted_for_approval_email(instance, order)

        # assert
        account_approval_repository().get_approver.assert_called_once_with(order['account']['_id'], order['grandTotal'])
        user_repository().get_usernames_by_role.assert_called_once_with(
            order['account']['_id'], [UserRole.APPROVER])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_give_submitted_for_approval_email_no_approver_users(self, test_send_give_submitted_for_approval_email_init):
        # arrange
        account_approval_repository().get_approver.return_value = None
        user_repository().get_usernames_by_role.side_effect = [[], ['org_admin']]
        instance, order, payload = test_send_give_submitted_for_approval_email_init
        givewith_email = instance['settings']['givewithEmail']
        payload['tos'] = ['org_admin']
        payload['template']['data']['showErrorMessage'] = True

        # act
        response = email_service().send_give_submitted_for_approval_email(instance, order)

        # assert
        account_approval_repository().get_approver.assert_called_once_with(order['account']['_id'], order['grandTotal'])
        user_repository().get_usernames_by_role.assert_has_calls([
            call(order['account']['_id'], [UserRole.APPROVER]),
            call(order['account']['_id'], [UserRole.ORG_ADMIN])
        ])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_give_approved_email_init(self, fakers, mocker):
        mocker.patch.object(user_repository(), 'get_usernames_by_role', side_effect=[['transactor'], ])
        locale = fakers.locale.generate_single()
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        cause_area = fakers.cause_area.generate_single()
        order = fakers.order.generate_single()
        order['comments'].append({'comment': 'Approved!', 'newStatus': OrderStatus.APPROVED.value})
        givewith_email = instance['settings']['givewithEmail']
        symbol = locale['settings']['symbol']
        payload = {
            'tos': ['transactor', order['createdBy']],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_APPROVED.value,
                'data': {
                    'giveId': order['giveId'],
                    'grandTotal': format_currency(symbol, order['grandTotal']),
                    'quoteNumber': order.get('quoteNumber'),
                    'customerName': order['customerName'],
                    'approvalComment': 'Approved!',
                    'causeAreaTooltip': cause_area['tooltip'],
                    'clientName': account['company']['name'],
                    'sageCustomerId': account.get('sageCustomerId'),
                    'showErrorMessage': False
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        return instance, order, account, cause_area, payload

    def test_send_give_approved_email(self, test_send_give_approved_email_init):
        # arrange
        instance, order, account, cause_area, payload = test_send_give_approved_email_init

        # act
        response = email_service().send_give_approved_email(instance, order, account, cause_area)

        # assert
        user_repository().get_usernames_by_role.assert_called_once_with(order['account']['_id'], [UserRole.TRANSACTOR])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_give_approved_email_no_transactors(self, test_send_give_approved_email_init):
        # arrange
        user_repository().get_usernames_by_role.side_effect = [[], ['org_admin']]
        instance, order, account, cause_area, payload = test_send_give_approved_email_init
        payload['tos'] = ['org_admin', order['createdBy']]
        payload['template']['data']['showErrorMessage'] = True

        # act
        response = email_service().send_give_approved_email(instance, order, account, cause_area)

        # assert
        user_repository().get_usernames_by_role.assert_has_calls([
            call(order['account']['_id'], [UserRole.TRANSACTOR]),
            call(order['account']['_id'], [UserRole.ORG_ADMIN])
        ])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_give_denied_email_init(self, fakers, mocker):
        instance = fakers.instance_settings.generate_single()
        locale = fakers.locale.generate_single()
        order = fakers.order.generate_single()
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        symbol = locale['settings']['symbol']
        payload = {
            'tos': [order['createdBy']],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_DENIED.value,
                'data': {
                    'giveId': order['giveId'],
                    'customerName': order['customerName'],
                    'grandTotal': format_currency(symbol, order['grandTotal']),
                    'quoteNumber': order.get('quoteNumber'),
                    'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        return instance, order, payload

    def test_send_give_denied_email(self, test_send_give_denied_email_init):
        # arrange
        instance, order, payload = test_send_give_denied_email_init

        # act
        response = email_service().send_give_denied_email(instance, order)

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_give_financial_hold_email_init(self, fakers, mocker):
        mocker.patch.object(user_repository(), 'get_usernames_by_role', side_effect=[['finance'], ])
        locale = fakers.locale.generate_single()
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        order = fakers.order.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        symbol = locale['settings']['symbol']
        payload = {
            'tos': ['finance'],
            'ccs': [order['createdBy']],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_FINANCIAL_HOLD.value,
                'data': {
                    'giveId': order['giveId'],
                    'customerName': order['customerName'],
                    'grandTotal': format_currency(symbol, order['grandTotal']),
                    'quoteNumber': order.get('quoteNumber'),
                    'clientName': account['company']['name'],
                    'sageCustomerId': account.get('sageCustomerId'),
                    'showErrorMessage': False
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        return instance, order, account, payload

    def test_send_give_financial_hold_email(self, test_send_give_financial_hold_email_init):
        # arrange
        instance, order, account, payload = test_send_give_financial_hold_email_init

        # act
        response = email_service().send_give_financial_hold_email(instance, order, account)

        # assert
        user_repository().get_usernames_by_role.assert_called_once_with(order['account']['_id'], [UserRole.FINANCE])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_give_financial_hold_email_no_finance_users(self, test_send_give_financial_hold_email_init):
        # arrange
        user_repository().get_usernames_by_role.side_effect = [[], ['org_admin']]
        instance, order, account, payload = test_send_give_financial_hold_email_init
        payload['tos'] = ['org_admin']
        payload['template']['data']['showErrorMessage'] = True

        # act
        response = email_service().send_give_financial_hold_email(instance, order, account)

        # assert
        user_repository().get_usernames_by_role.assert_has_calls([
            call(order['account']['_id'], [UserRole.FINANCE]),
            call(order['account']['_id'], [UserRole.ORG_ADMIN])
        ])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_give_completed_won_email_init(self, fakers, mocker):
        locale = fakers.locale.generate_single()
        instance = fakers.instance_settings.generate_single()
        account = fakers.account.generate_single()
        order = fakers.order.generate_single()
        cause_area = fakers.cause_area.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']
        symbol = locale['settings']['symbol']
        payload = {
            'tos': [order['createdBy']],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_COMPLETED_WON.value,
                'data': {
                    'giveId': order['giveId'],
                    'causeAreaImageUrl': f'{portal_url}{cause_area["detailImageName"]}',
                    'grandTotal': format_currency(symbol, order['grandTotal']),
                    'quoteNumber': order.get('quoteNumber'),
                    'customerName': order['customerName'],
                    'causeAreaTooltip': cause_area['tooltip'],
                    'clientName': account['company']['name'],
                    'sageCustomerId': account.get('sageCustomerId')
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        return instance, order, account, cause_area, payload

    def test_send_give_completed_won_email(self, test_send_give_completed_won_email_init):
        # arrange
        instance, order, account, cause_area, payload = test_send_give_completed_won_email_init

        # act
        response = email_service().send_give_completed_won_email(instance, order, account, cause_area)

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_give_completed_won_email_custom_tos(self, test_send_give_completed_won_email_init):
        # arrange
        instance, order, account, cause_area, payload = test_send_give_completed_won_email_init
        payload['tos'] = ['test1', 'test2']

        # act
        response = email_service().send_give_completed_won_email(instance, order, account, cause_area, payload['tos'])

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    def test_send_give_completed_won_shared(self, fakers, mocker, ):
        # arrange
        instance = fakers.instance_settings.generate_single()
        order = fakers.order.generate_single()
        order['sharedWith'] = {
            '_id': ObjectId(),
            'name':  "Shared With Name"
        }
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']

        payload = {
            'tos': ['test'],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_SHARED.value,
                'data': {
                    'Subject': f"{order['account']['name']}'s Give has successfully been completed",
                    'Message': f"{order['account']['name']} has successfully completed a Give",
                    'CustomerSharedWithName': order['sharedWith']['name'],
                    'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)

        # act
        email_service().send_give_completed_won_shared_email(instance, order, payload['tos'])

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert payload == payload

    def test_send_give_shared_email(self, fakers, mocker, ):
        # arrange
        instance = fakers.instance_settings.generate_single()
        order = fakers.order.generate_single()
        order['sharedWith'] = {
            '_id': ObjectId(),
            'name':  "Shared With Name"
        }
        givewith_email = instance['settings']['givewithEmail']
        portal_url = instance['settings']['portalUrl']

        payload = {
            'tos': ['test'],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_SHARED.value,
                'data': {
                    'Subject': f"{order['account']['name']}'s Give is ready to be reviewed",
                    'Message': f"{order['account']['name']} has shared a Give with you to be reviewed.",
                    'CustomerSharedWithName': order['sharedWith']['name'],
                    'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)

        # act
        email_service().send_give_approved_shared_email(instance, order, payload['tos'])

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert payload == payload

    @pytest.fixture
    def test_send_give_abandoned_lost_email_init(self, fakers, mocker):
        instance = fakers.instance_settings.generate_single()
        locale = fakers.locale.generate_single()
        order = fakers.order.generate_single()
        portal_url = instance['settings']['portalUrl']
        givewith_email = instance['settings']['givewithEmail']
        symbol = locale['settings']['symbol']
        payload = {
            'tos': [order['createdBy']],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_GIVES_ABANDONED_LOST.value,
                'data': {
                    'giveId': order['giveId'],
                    'grandTotal': format_currency(symbol, order['grandTotal']),
                    'quoteNumber': order.get('quoteNumber'),
                    'customerName': order['customerName'],
                    'giveDetailsUrl': f'{portal_url}/app/give/{order["_id"]}/details'
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        return instance, order, payload

    def test_send_give_abandoned_lost_email(self, test_send_give_abandoned_lost_email_init):
        # arrange
        instance, order, payload = test_send_give_abandoned_lost_email_init

        # act
        response = email_service().send_give_abandoned_lost_email(instance, order)

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_balance_deposit_to_account_email_init(self, fakers, mocker):
        mocker.patch.object(user_repository(), 'get_usernames_by_role', return_value=['finance'])
        account = fakers.account.generate_single()

        instance = fakers.instance_settings.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        login_url = instance['settings']['loginUrl']

        payload = {
            'tos': ['finance'],
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_BALANCE_DEPOSIT_TO_ACCOUNT.value,
                'data': {
                    'clientName': account['company']['name'],
                    'sageCustomerId': account.get('sageCustomerId', ''),
                    'loginUrl': login_url
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        return instance, account, payload

    def test_send_balance_deposit_to_account_email(self, test_send_balance_deposit_to_account_email_init):
        # arrange
        instance, account, payload = test_send_balance_deposit_to_account_email_init

        # act
        response = email_service().send_balance_deposit_to_account_email(instance, account)

        # assert
        user_repository().get_usernames_by_role.assert_called_once_with(account['_id'], [UserRole.FINANCE])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_role_update_email_init(self, fakers, mocker):
        mocker.patch.object(user_repository(), 'get_usernames_by_role', return_value=['gw_finance'])
        instance = fakers.instance_settings.generate_single()
        user = fakers.user.generate_single()
        updated_user = user.copy()
        now = datetime.now().strftime('%Y/%m/%d %I:%M:%S')
        givewith_email = instance['settings']['givewithEmail']
        payload = {
            'tos': [givewith_email],
            'ccs': [],
            'bccs': [],
            'template': {
                'id': EmailTemplateId.PORTAL_ROLES_UPDATED.value,
                'data': {
                    'userName': user['name'] if user['name'] else user['first_name']+" "+user['last_name'],
                    'userEmail': user['username'],
                    'currentRoles': [ROLES_TO_STRING[role] for role in updated_user['roles']],
                    'previousRoles': [ROLES_TO_STRING[role] for role in user['roles']] if user['roles'] else 'N/A',
                    'assigner': 'admin@givewith.com',
                    'timeStamp': now
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        return instance, user, updated_user, payload

    def test_send_role_update_email(self, test_send_role_update_email_init):
        # arrange
        instance, user, updated_user, payload = test_send_role_update_email_init

        # act
        response = email_service().send_role_update_email(instance, user, updated_user, 'admin@givewith.com')

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_client_payment_failed_email_init(self, mocker, fakers):
        account = fakers.account.generate_single()
        tos = ['org_admin', 'finance']
        mocker.patch.object(user_repository(), 'get_usernames_by_role', return_value=tos)
        instance = fakers.instance_settings.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        payload = {
            'tos': tos,
            'ccs': [],
            'bccs': [givewith_email],
            'template': {
                'id': EmailTemplateId.PORTAL_PAYMENT_FAILED_CLIENT.value,
                'data': {
                    'customerName': account['company']['name'],
                    'sageCustomerId': account.get('sageCustomerId', '')
                }
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        return account, instance, payload

    def test_send_client_payment_failed_email(self, test_send_client_payment_failed_email_init):
        # arrange
        account, instance, payload = test_send_client_payment_failed_email_init

        # act
        response = email_service().send_client_payment_failed_email(instance, account)

        # assert
        user_repository().get_usernames_by_role.assert_called_once_with(account['_id'], [UserRole.ORG_ADMIN, UserRole.FINANCE])
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload

    @pytest.fixture
    def test_send_generic_notification_init(self, mocker, fakers):
        instance = fakers.instance_settings.generate_single()
        givewith_email = instance['settings']['givewithEmail']
        args = {
            'subject': 'Subject',
            'message': 'Message',
            'data': {
                'id1': 'ID1',
                'id2': 'ID2'
            }
        }
        payload = {
            'tos': [givewith_email],
            'ccs': [],
            'bccs': [],
            'template': {
                'id': EmailTemplateId.PORTAL_GENERIC_NOTIFICATION.value,
                'data': args
            }
        }
        mocker.patch.object(email_service(), 'send_email', return_value=payload)
        return instance, args, payload

    def test_send_generic_notification(self, test_send_generic_notification_init):
        # arrange
        instance, args, payload = test_send_generic_notification_init

        # act
        response = email_service().send_generic_notification(instance, **args)

        # assert
        email_service().send_email.assert_called_once_with(payload)
        assert response == payload


class TestEmailService_Integration:
    pytestmark = pytest.mark.integration

    @pytest.mark.skip
    def test_send_email(self, fakers):
        '''Integration Test: valid email address must be provided'''
        instance = fakers.instance_settings.generate_single()
        login_url = instance['settings']['loginUrl']

        payload = {
            "tos": [""],
            "ccs": [],
            "bccs": [],
            "template": {
                "id": "d-346bb8bd80bd4facbd983a43043f73e5",
                "data": {
                    "register-url": login_url + "/sign_up?code=abc123&email=test@givewith.com"
                }
            }
        }

        assert len(payload["tos"]) > 0
        assert payload["tos"][0] != ""

        response = email_service().send_email(payload)

        assert response.status_code == 202
