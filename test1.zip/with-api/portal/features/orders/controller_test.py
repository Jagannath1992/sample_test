import pytest
import re
from copy import deepcopy
from flask import request
from bson import ObjectId
from werkzeug.exceptions import InternalServerError
from portal.conftest import get_account_id_from_header, get_user_from_header
from portal.features.orders.controller import OrderById, send_completed_notification
from portal.features.orders.schema import OrderRequest, OrderSearchResponse, OrderResponse
from portal.shared.dates import get_formatted_utc_string
from portal.shared.enums import AccountType, UserRole, OrderStatus
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import locale_repository, account_approval_repository, account_repository, instance_settings_repository, sku_repository, order_repository, cause_area_repository, user_repository
from portal.shared.services import email_service, order_service, stripe_service


class TestOrderResource:
    def test_post(self, client, givewith_header, fakers, mocker, frozen_utcnow):
        order = fakers.order.generate_single()
        order['status'] = OrderStatus.PENDING_APPROVAL.value
        expected = deepcopy(order)
        order.pop('_id')
        expected['approvers'] = []

        order_request_validation_mocks(mocker, fakers)
        mocker.patch.object(account_approval_repository(), 'get_single', return_value={'levels': []})
        mocker.patch.object(order_repository(), 'exists', return_value=True)
        mocker.patch.object(account_repository(), 'get_next_give_id', return_value=1)
        mocker.patch.object(order_repository(), 'insert', return_value=expected)
        mocker.patch.object(order_service(), 'send_notifications')

        request = OrderRequest().dump(order)

        response = client.post('/orders', json=request, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == OrderResponse().dump(expected)
        account_repository().get_next_give_id.assert_called_once_with(order['account']['_id'])
        order_repository().insert.assert_called_once_with(
            {**OrderRequest().load(request), 'giveId': 1, 'comments': [{'comment': 'New Give',
                                                                        'newStatus': OrderStatus.PENDING_APPROVAL.value,
                                                                        'timestamp': frozen_utcnow,
                                                                        'user': 'givewith_user@example.com'}]},
            'givewith_user@example.com'
        )
        order_service().send_notifications.assert_called_once_with(expected)

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.SALES]],
        indirect=True
    )
    def test_post_role_permissions(self, client, custom_auth_header):
        request = {}
        response = client.post('/orders', json=request, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_search(self, client, givewith_header, fakers, mocker):
        orders = fakers.order.generate_many(3)
        account = fakers.approval.generate_single()
        mocker.patch.object(order_repository(), 'get_page', return_value=(3, orders))
        mocker.patch.object(account_approval_repository(), 'get_single', return_value=account)

        expected = OrderSearchResponse().dump({
            'totalCount': 3,
            'results': orders
        })

        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10,
            'accountId': get_account_id_from_header(givewith_header)
        }

        response = client.get('/orders', query_string=query_params, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == expected

    def test_gid_search(self, client, givewith_header, fakers, mocker):
        orders = fakers.order.generate_many(25)
        account = fakers.approval.generate_single()
        filtered_orders = [order for order in orders if re.search('^1', str(order['giveId']))]
        mocker.patch.object(order_repository(), 'get_page', return_value=(11, filtered_orders))
        mocker.patch.object(account_approval_repository(), 'get_single', return_value=account)
        expected = OrderSearchResponse().dump({
            'totalCount': 11,
            'results': filtered_orders
        })

        query_params = {
            'giveId': 1,
            'orderBy': 'id',
            'offset': 0,
            'count': 5,
            'accountId': get_account_id_from_header(givewith_header)
        }

        response = client.get('/orders', query_string=query_params, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES],
        indirect=True
    )
    def test_search_account_permission(self, client, custom_auth_header):
        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10,
            'accountId': ObjectId()
        }

        response = client.get('orders', query_string=query_params, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}


class TestOrderById:
    def test_put(self, client, givewith_header, fakers, mocker):
        # arrange
        order_request_validation_mocks(mocker, fakers)
        order = fakers.order.generate_single()
        mocker.patch.object(order_repository(), 'exists', return_value=True)
        mocker.patch.object(order_repository(), 'get_single', return_value=order)
        mocker.patch.object(order_repository(), 'update', return_value=order)
        mocker.patch.object(order_service(), 'send_notifications')

        request = OrderRequest().dump({**order, 'status': OrderStatus.APPROVED.value})

        # act
        response = client.put(f'orders/{order["_id"]}', json=request, headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.json == OrderResponse().dump(order)
        order_repository().update.assert_called_once_with(order, by='givewith_user@example.com')
        order_service().send_notifications.assert_called_once_with(order)

    def test_patch(self, client, givewith_header, fakers, mocker):
        order_request_validation_mocks(mocker, fakers)
        order = fakers.order.generate_single()
        mocker.patch.object(order_repository(), 'exists', return_value=True)
        mocker.patch.object(order_repository(), 'patch', return_value=order)
        mocker.patch.object(order_repository(), 'get_single', return_value=order)
        mocker.patch.object(order_service(), 'send_notifications')

        request = {
            'status': OrderStatus.APPROVED.value
        }
        response = client.patch(f'orders/{order["_id"]}', json=request, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == OrderResponse().dump(order)
        order_repository().exists.assert_called_once_with(str(order["_id"]))
        order_service().send_notifications.assert_called_once_with(order)

    def test_patch_add_comment(self, client, givewith_header, fakers, frozen_utcnow, mocker):
        order = fakers.order.insert_single({'comments': []})
        mocker.patch.object(order_service(), 'send_notifications')

        request = {
            'status': 'denied',
            'comments': [{
                'comment': 'a new comment'
            }]
        }

        response = client.patch(f'orders/{order["_id"]}', json=request, headers=givewith_header)
        assert response.json['comments'] == [{
            'comment': 'a new comment',
            'user': 'givewith_user@example.com',
            'timestamp': get_formatted_utc_string(frozen_utcnow),
            'oldStatus': 'pending approval',
            'newStatus': 'denied'
        }]

        request = {
            'comments': [{'comment': 'a second comment'}],
            'status': 'draft'
        }
        response = client.patch(f'orders/{order["_id"]}', json=request, headers=givewith_header)
        assert response.json['comments'] == [{
            'comment': 'a new comment',
            'user': 'givewith_user@example.com',
            'timestamp': get_formatted_utc_string(frozen_utcnow),
            'oldStatus': 'pending approval',
            'newStatus': 'denied'
        }, {
            'comment': 'a second comment',
            'user': 'givewith_user@example.com',
            'timestamp': get_formatted_utc_string(frozen_utcnow),
            'oldStatus': 'denied',
            'newStatus': 'draft'
        }]
        order_service().send_notifications.assert_called()

    def test_delete(self, client, givewith_header, mocker):
        order_repo = order_repository()
        order_id = ObjectId()
        mocker.patch.object(order_repo, 'exists', return_value=True)
        mocker.patch.object(order_repo, 'delete', return_value=True)

        response = client.delete(f'orders/{order_id}', headers=givewith_header)

        assert response.status_code == 200
        order_repo.exists.assert_called_once_with(str(order_id))
        order_repo.delete.assert_called_once_with(str(order_id), by='givewith_user@example.com')

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.ORG_ADMIN, UserRole.SALES]],
        indirect=True
    )
    def test_delete_role_permissions(self, client, custom_auth_header):
        response = client.delete(f'orders/{ObjectId()}', headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_delete_404(self, client, givewith_header, mocker):
        order_repo = order_repository()
        order_id = ObjectId()
        mocker.patch.object(order_repo, 'exists', return_value=False)

        response = client.delete(f'orders/{order_id}', headers=givewith_header)

        assert response.status_code == 404
        order_repo.exists.assert_called_once_with(str(order_id))

    def test_get(self, client, givewith_header, fakers, mocker):
        # arrange
        order_repo = order_repository()
        order = fakers.order.generate_single()
        mocker.patch.object(order_repo, 'get_single_by_filter', return_value=order)
        expected = OrderResponse().dump(order)

        # act
        response = client.get(f'orders/{order["_id"]}', headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected
        order_repo.get_single_by_filter.assert_called_once_with({'_id': order['_id']})

    def test_get_404(self, client, givewith_header, mocker):
        # arrange
        order_repo = order_repository()
        order_id = ObjectId()
        mocker.patch.object(order_repo, 'get_single_by_filter', return_value=None)

        # act
        response = client.get(f'orders/{order_id}', headers=givewith_header)

        # assert
        assert response.status_code == 404
        order_repo.get_single_by_filter.assert_called_once_with({'_id': order_id})

    @pytest.fixture
    def handle_completed_order_init(self, mocker, fakers):
        order = fakers.order.generate_single()
        mocker.patch.object(order_repository(), 'get_single', return_value=order)
        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        locale = fakers.locale.generate_single()
        mocker.patch.object(locale_repository(), 'get_single', return_value=locale)
        mocker.patch.object(stripe_service(), 'create_payment_intent')
        return order, account, instance, locale

    def test_handle_completed_order(self, handle_completed_order_init):
        # arrange
        order, account, instance, locale = handle_completed_order_init
        expected_order = deepcopy(order)
        expected_order['status'] = OrderStatus.PENDING_PAYMENT.value

        # act
        result = OrderById()._handle_completed_order(order['_id'], order, 'username')

        # assert
        order_repository().get_single.assert_called_once_with(order['_id'])
        account_repository().get_single.assert_called_once_with(order['account']['_id'])
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        locale_repository().get_single.assert_called_once_with(instance['settings']['locale']['_id'])
        stripe_service().create_payment_intent.assert_called_once_with(
            instance,
            account['stripe']['customerId'],
            account['stripe']['autopay']['paymentMethodId'],
            order['grandTotal'],
            order['_id'],
            locale['settings']['currency'],
            order['giveId'])
        assert result == expected_order

    def test_handle_completed_order_500_no_stripe(self, handle_completed_order_init):
        # arrange
        order, account, _, _ = handle_completed_order_init
        del account['stripe']
        account_repository().get_single.return_value = account

        # act
        with pytest.raises(InternalServerError) as error:
            OrderById()._handle_completed_order(order['_id'], order, 'username')

        # assert
        order_repository().get_single.assert_called_once_with(order['_id'])
        account_repository().get_single.asert_called_once_with(order['account']['_id'])
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        stripe_service().create_payment_intent.assert_not_called()
        assert error.value.description == 'Stripe is not set up for your account'

    def test_handle_completed_order_500_no_customer_id(self, handle_completed_order_init):
        # arrange
        order, account, _, _ = handle_completed_order_init
        del account['stripe']['customerId']
        account_repository().get_single.return_value = account

        # act
        with pytest.raises(InternalServerError) as error:
            OrderById()._handle_completed_order(order['_id'], order, 'username')

        # assert
        order_repository().get_single.assert_called_once_with(order['_id'])
        account_repository().get_single.asert_called_once_with(order['account']['_id'])
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        stripe_service().create_payment_intent.assert_not_called()
        assert error.value.description == 'Stripe is not set up for your account'

    def test_handle_completed_order_no_automatic_payment_method(self, handle_completed_order_init):
        # arrange
        order, account, _, _ = handle_completed_order_init
        del account['stripe']['autopay']['paymentMethodId']
        account_repository().get_single.return_value = account
        expected_order = deepcopy(order)
        expected_order['status'] = OrderStatus.FINANCIAL_HOLD.value

        # act
        result = OrderById()._handle_completed_order(order['_id'], order, 'username')

        # assert
        order_repository().get_single.assert_called_once_with(order['_id'])
        account_repository().get_single.asert_called_once_with(order['account']['_id'])
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        stripe_service().create_payment_intent.assert_not_called()
        assert result == expected_order


class TestApproval:
    def test_get_approvals(self, client, fakers, givewith_header):
        user = get_user_from_header(givewith_header)
        levels = [{
            'approver': {
                'username': user['username']
            },
            'amount': 10
        }]
        approval = fakers.approval.insert_single({'levels': levels})
        order = fakers.order.insert_single({'account': {'_id': approval['_id']}})

        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10,
            'accountId': approval['_id']
        }

        response = client.get(f'orders/approvals', query_string=query_params, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == {
            'results': [OrderResponse().dump(order)],
            'totalCount': 1
        }


class TestShareOrderById:
    @pytest.fixture
    def test_post_init(self, fakers, mocker):
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        procurement_account = fakers.account.generate_single({
            'type': AccountType.PROCUREMENT.value,
            'instance': {'_id': instance['_id']}
        })
        supplier_account = fakers.account.generate_single({
            'type': AccountType.SUPPLIER.value,
            'invitedBy': {'_id': procurement_account['_id']}
        })

        mocker.patch.object(
            account_repository(),
            'get_single_by_filter', lambda filters: supplier_account
            if filters['type'] == AccountType.SUPPLIER.value else procurement_account)

        order = fakers.order.generate_single({
            'status': OrderStatus.APPROVED.value
        })
        mocker.patch.object(order_repository(), 'get_single', return_value=order)
        mocker.patch.object(order_repository(), 'has_access', return_value=True)

        request = {
            'sharedWith': {
                '_id': procurement_account['_id'],
                '_type': 'account',
                'name': procurement_account['company']['name'],
            }
        }
        updated = {**order, **request}
        mocker.patch.object(order_repository(), 'patch', return_value=updated)
        mocker.patch.object(order_repository(), 'update', return_value=updated)
        mocker.patch.object(email_service(), 'send_give_approved_shared_email')

        return order, updated, request

    def test_post(self, client, test_post_init, givewith_header):
        # arrange
        order, updated, request = test_post_init
        user = get_user_from_header(givewith_header)
        expected = OrderResponse().dump(updated)

        with client:
            # act
            response = client.post(f'/orders/{order["_id"]}/share', headers=givewith_header)

            # assert
            assert response.status_code == 200
            assert response.json == expected
            order_repository().patch.assert_called_once_with(str(order["_id"]), request, user['username'])

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_allowed(self, client, test_post_init, custom_auth_header):
        # arrange
        order, updated, request = test_post_init
        user = get_user_from_header(custom_auth_header)
        expected = OrderResponse().dump(updated)

        with client:
            # act
            response = client.post(f'/orders/{order["_id"]}/share', headers=custom_auth_header)

            # assert
            assert response.status_code == 200
            assert response.json == expected
            order_repository().patch.assert_called_once_with(str(order["_id"]), request, user['username'])

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_post_status_not_allowed(self, client, test_post_init, custom_auth_header):
        # arrange
        order, _, _ = test_post_init
        order['status'] = OrderStatus.COMPLETED.value

        with client:
            # act
            response = client.post(f'/orders/{order["_id"]}/share', headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json == {'message': 'Give cannot be shared'}
            order_repository().patch.not_called()

    @pytest.mark.parametrize(
        'custom_auth_header', [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.FINANCE]],
        indirect=True)
    def test_post_role_not_allowed(self, client, test_post_init, custom_auth_header):
        # arrange
        order, _, _ = test_post_init

        with client:
            # act
            response = client.post(f'/orders/{order["_id"]}/share', headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json == {'message': 'You do not have permission to access this resource'}
            order_repository().patch.not_called()

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete_allowed(self, mocker, client, test_post_init, custom_auth_header):
        # arrange
        order, updated, _ = test_post_init
        order['sharedWith'] = updated.pop('sharedWith')
        user = get_user_from_header(custom_auth_header)
        expected = OrderResponse().dump(updated)

        with client:
            # act
            response = client.delete(f'/orders/{order["_id"]}/share', headers=custom_auth_header)

            # assert
            assert response.status_code == 200
            assert response.json == expected
            order_repository().update.assert_called_once_with(order, user['username'])

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.FINANCE], indirect=True)
    def test_delete_status_not_allowed(self, client, test_post_init, custom_auth_header):
        # arrange
        order, _, _ = test_post_init
        order['status'] = OrderStatus.COMPLETED.value

        with client:
            # act
            response = client.delete(f'/orders/{order["_id"]}/share', headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json == {'message': 'Give cannot be unshared'}
            order_repository().update.not_called()

    @pytest.mark.parametrize(
        'custom_auth_header', [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.FINANCE]],
        indirect=True)
    def test_delete_role_not_allowed(self, client, test_post_init, custom_auth_header):
        # arrange
        order, _, _ = test_post_init

        with client:
            # act
            response = client.delete(f'/orders/{order["_id"]}/share', headers=custom_auth_header)

            # assert
            assert response.status_code == 403
            assert response.json == {'message': 'You do not have permission to access this resource'}
            order_repository().update.not_called()


class TestOrderByIdResendNotificationsResource:
    @pytest.fixture
    def test_put_init(self, fakers, mocker):
        mocker.patch.object(order_repository(), 'has_access', return_value=True)
        order = fakers.order.generate_single()
        mocker.patch.object(order_repository(), 'get_single', return_value=order)
        send_completed_notification_mock = mocker.patch('portal.features.orders.controller.send_completed_notification')
        request_json = {
            'emailAddresses': [
                'test@example.com',
                'test2@example.com'
            ]
        }
        return order, send_completed_notification_mock, request_json

    def test_put_200_givewith(self, client, test_put_init, givewith_header):
        # arrange
        order, send_completed_notification_mock, request_json = test_put_init

        with client:
            # act
            response = client.put(f'/orders/{order["_id"]}/resend-notification', json=request_json, headers=givewith_header)

            # assert
            order_repository().has_access.assert_not_called()
            order_repository().get_single.assert_called_once_with(str(order['_id']))
            send_completed_notification_mock.assert_called_once_with(order, request.parsed_obj['emailAddresses'])
            assert response.status_code == 200
            assert not response.json

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.SALES, UserRole.FINANCE], indirect=True)
    def test_put_200(self, client, test_put_init, custom_auth_header):
        # arrange
        order, send_completed_notification_mock, request_json = test_put_init

        with client:
            # act
            response = client.put(f'/orders/{order["_id"]}/resend-notification', json=request_json, headers=custom_auth_header)

            # assert
            order_repository().has_access.assert_called_once_with(str(order['_id']), request.user['accountId'])
            order_repository().get_single.assert_called_once_with(str(order['_id']))
            send_completed_notification_mock.assert_called_once_with(order, request.parsed_obj['emailAddresses'])
            assert response.status_code == 200
            assert not response.json

    def test_put_400_invalid_id(self, client, test_put_init, givewith_header):
        # arrange
        _, send_completed_notification_mock, request_json = test_put_init

        with client:
            # act
            response = client.put('/orders/invalidid/resend-notification', json=request_json, headers=givewith_header)

            # assert
            order_repository().has_access.assert_not_called()
            order_repository().get_single.assert_not_called()
            send_completed_notification_mock.assert_not_called()
            assert response.status_code == 400
            assert response.json == {'message': 'Invalid id provided'}

    @pytest.mark.parametrize('custom_auth_header',
                             [r for r in UserRole
                              if r not in [UserRole.SUPER_ADMIN, UserRole.ORG_ADMIN, UserRole.SALES, UserRole.FINANCE]],
                             indirect=True)
    def test_put_403_no_access(self, client, test_put_init, custom_auth_header):
        # arrange
        order, send_completed_notification_mock, request_json = test_put_init

        with client:
            # act
            response = client.put(f'/orders/{order["_id"]}/resend-notification', json=request_json, headers=custom_auth_header)

            # assert
            order_repository().has_access.assert_not_called()
            order_repository().get_single.assert_not_called()
            send_completed_notification_mock.assert_not_called()
            assert response.status_code == 403
            assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_put_403_wrong_account(self, client, test_put_init, org_admin_header):
        # arrange
        order_repository().has_access.return_value = False
        order, send_completed_notification_mock, request_json = test_put_init

        with client:
            # act
            response = client.put(f'/orders/{order["_id"]}/resend-notification', json=request_json, headers=org_admin_header)

            # assert
            order_repository().has_access.assert_called_once_with(str(order['_id']), request.user['accountId'])
            order_repository().get_single.assert_not_called()
            send_completed_notification_mock.assert_not_called()
            assert response.status_code == 403
            assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_put_404(self, client, test_put_init, org_admin_header):
        # arrange
        order_repository().get_single.return_value = None
        order, send_completed_notification_mock, request_json = test_put_init

        with client:
            # act
            response = client.put(f'/orders/{order["_id"]}/resend-notification', json=request_json, headers=org_admin_header)

            # assert
            order_repository().has_access.assert_called_once_with(str(order['_id']), request.user['accountId'])
            order_repository().get_single.assert_called_once_with(str(order['_id']))
            send_completed_notification_mock.assert_not_called()
            assert response.status_code == 404
            assert response.json == {'message': 'Give not found'}


def test_send_completed_notification(fakers, mocker):
    # arrange
    order = fakers.order.generate_single()
    tos = ['email1@example.com', 'email2@example.com']
    account = fakers.account.generate_single()
    mocker.patch.object(account_repository(), 'get_single', return_value=account)
    instance = fakers.instance_settings.generate_single()
    mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
    cause_area = fakers.cause_area.generate_single()
    mocker.patch.object(cause_area_repository(), 'get_single', return_value=cause_area)
    mocker.patch.object(email_service(), 'send_give_completed_won_email')

    # act
    send_completed_notification(order, tos)

    # assert
    account_repository().get_single.assert_called_once_with(order['account']['_id'], {
        'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
    instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
    cause_area_repository().get_single.assert_called_once_with(order['causeArea']['_id'], {'tooltip': 1, 'detailImageName': 1})
    email_service().send_give_completed_won_email.assert_called_once_with(instance, order, account, cause_area, tos)


def order_request_validation_mocks(mocker, fakers):
    account = fakers.account.generate_single()
    mocker.patch.object(account_repository(), 'get_single', return_value=account)
    mocker.patch.object(account_repository(), 'exists', return_value=True)
    mocker.patch.object(account_repository(), 'patch', return_value=account)
    mocker.patch.object(sku_repository(), 'exists', return_value=True)
    mocker.patch.object(user_repository(), 'exists', return_value=True)
    mocker.patch.object(cause_area_repository(), 'exists', return_value=True)
    return account
