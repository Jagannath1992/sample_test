# -*- coding: utf-8 -*-
#
# brands/utils.py
#

import json
import pandas as pd
import sys
from datetime import datetime
from pymongo import UpdateOne

from bson import ObjectId
from bson.objectid import InvalidId

from matchmaking.dao.utils import get_documents
from ..programs import math_strength_rating
from ....mongodb import (expand_vocabulary_label, set_vocabulary, db, get_vocabulary_id_and_label, get_mm_brand,
                         create_ref, get_brand_csrhub_data, get_tvl_data, translate_to_topic,
                         get_vocabulary_label_v2, VOCAB_V1)
from ....models.models import v, schema_brand, MSCI_COLUMN_TRANSLATE_ADMIN
from ....utils import (check_is_objid, inject_key, natural_sort, dict_merge, MissingVocabularyError,
                       InvalidPayload, GivewithError)


def check_and_set_valid_for_dummy(brand):
    if not brand:
        return

    # This enable 'dummy' brands to be displayed
    if ('hasAnalysis' not in brand or brand['hasAnalysis'] is False) and 'name' in brand:
        brand['isValid'] = True

    return brand


def is_brand_verified_by_admin(brand):
    """
    Gets a brand from the DB and checks to see if a customer brand has been verified by an admin
    If pullFromDb is set to true, it will look up and pull the brand from the DB
    """
    if brand and brand.get('source', '').lower() == 'customer':
        if brand.get('verifiedByAdmin'):
            return True
        else:
            return False
    else:
        return True


def set_recommendations(brand):
    """
    Set programs as `ObjectId`s to be stored.
    :param brand:
    :return: None
    """
    recommendations = brand.get('recommendations', [])
    for recommendation in recommendations:
        programs = recommendation.get('programs', [])
        if programs:
            expanded_programs = [create_ref(program_id) for program_id in programs]
            if expanded_programs:
                recommendation['programs'] = expanded_programs


def set_custom_investor_metrics(brand):
    """
    Set program as `ObjectId`s to be stored.
    :param brand:
    :return: None
    """
    custom_investor_metrics = brand.get('customInvestorMetrics', [])
    for row in custom_investor_metrics:
        program_id = row.get('program', None)
        if program_id:
            row['program'] = create_ref(program_id)


def organize_nonprofits(programs):
    organized_nonprofits = {}

    settings = db().coll_settings.find_one(projection={'_id': False, 'screenOneMinimum': True})
    screen_one_minimum = settings.get('screenOneMinimum', 0)

    for program in programs:
        program = db().coll_programs.find_one(
            filter={'_id': program,
                    'isValid': True,
                    'isValidNonprofit': True,
                    'active': True,
                    '$or': [{'ignoreThreshold': True},
                            {'screenOneScore': {'$gte': screen_one_minimum}}]},
            projection={'nonprofit': True,
                        'slug': True,
                        'name': True,
                        'imageLandscape': True,
                        'imagePortrait': True,
                        'programStrength': True,
                        'secondaryImpacts': True,
                        'oneOrMorePartnerOrganizations': True,
                        'audienceAttribute': True,
                        'primaryOutcomeEffectiveness': True,
                        'dataMeasurementType': True,
                        'effectivenessRating': True,
                        'programApproach': True,
                        'screenOneScore': True,
                        'ignoreThreshold': True,
                        'isValid': True,
                        'isValidNonprofit': True,
                        'active': True,
                        'outputs': True})

        if program:
            program['screenOneMinimum'] = screen_one_minimum

            inject_key(program)
            math_strength_rating(program)
            expand_vocabulary_label(program)

            try:
                nonprofit = db().coll_nonprofits.find_one(
                    filter={'_id': program['nonprofit']},
                    projection={'slug': True,
                                'name': True,
                                'imageLandscape': True,
                                'imagePortrait': True,
                                'description': True})

                program.pop('nonprofit', None)
                if nonprofit:
                    if nonprofit['_id'] in organized_nonprofits:
                        nonprofit = organized_nonprofits[nonprofit['_id']]
                    else:
                        organized_nonprofits[nonprofit['_id']] = nonprofit
                        inject_key(nonprofit)

                    if 'programs' not in nonprofit:
                        nonprofit['programs'] = []

                    nonprofit['programs'].append(program)
            except KeyError:
                pass  # ignored

    return [nonprofit for k, nonprofit in organized_nonprofits.items()]


def transform_recommendations(recommendations):
    required_keys = ['issue', 'programs']
    transformed_recommendations = []
    for recommendation in recommendations:
        if required_keys in list(recommendation.keys()):
            recommendation['keyIssue'] = recommendation['issue']
            del recommendation['issue']

            nonprofits = organize_nonprofits(recommendation['programs'])

            if nonprofits:
                nonprofits.sort(key=lambda n: natural_sort(n.get('name', '')))
                recommendation['nonprofits'] = nonprofits
                del recommendation['programs']
                transformed_recommendations.append(recommendation)

    return transformed_recommendations


def add_recommendations(brand_obj):
    """
    :param brand_obj: Single document retrieved from coll_brands in Mongo.
    :return: Return the input parameter annotated with recommendations, hasAnalysis.
    """
    expand_vocabulary_label(brand_obj)

    try:
        recommendations = transform_recommendations(brand_obj['recommendations'])

        # keep recommendations key only if one recommendation has a project
        if recommendations:
            brand_obj['recommendations'] = recommendations
        else:
            del brand_obj['recommendations']
    except KeyError:
        pass  # ignored

    if 'hasAnalysis' not in brand_obj:
        brand_obj['hasAnalysis'] = False

    return brand_obj


def transform_brand(brand):
    inject_key(brand)

    if 'hasAnalysis' not in brand:
        brand['hasAnalysis'] = False

    brand['isValid'] = (brand.get('isValid', False)
                        and brand.get('isValidNonprofit', False)
                        and brand.get('isValidProgram', False))

    brand.pop('isValidNonprofit', None)
    brand.pop('isValidProgram', None)

    return check_and_set_valid_for_dummy(brand)


def translate_to_id(industry):
    try:
        ObjectId(industry)
    except InvalidId:
        industry = db().map_label_to_id.get(industry.lower())

    return industry


def get_brand_industry_id(brand):
    industry_id = brand.get('industry')
    msci_industry = brand.get('msci', {}).get('industry', '')
    if msci_industry:
        msci_industry = brand['msci'].pop('industry')
        if not industry_id:
            industry_id = msci_industry

    elif not industry_id and not msci_industry:
        industry_id = None

    if industry_id:
        industry_id = translate_to_id(industry_id)

    return industry_id


def clean_brand_themes(themes_list):
    cleaned_list = []
    for theme in themes_list:
        if 'relevancy' in theme:
            theme.pop('relevancy')
        cleaned_list.append(theme)
    return cleaned_list


def filter_themes(brand_themes_list, global_themes_list, filter_visible=False):
    global_themes = {item['theme']: item for item in global_themes_list}

    brand_themes_list = clean_brand_themes(brand_themes_list)
    brand_themes = {item['theme']: item for item in brand_themes_list}

    merged_themes = {}
    for theme in global_themes:
        merged_themes[theme] = {**global_themes[theme], **brand_themes.get(theme, {})}

    themes_list = [value for value in merged_themes.values()]
    if filter_visible:
        themes_list = list(filter(lambda x: x.get('visible'), themes_list))

    return themes_list


def reset_brand_themes(brand):

    global_themes_list = get_themes_by_industry(
        brand.get('industry'), include_id=False)

    return filter_themes([], global_themes_list)


def format_insights(brand):
    msci_obj = brand.get('msci', {})
    msci_issues_list = []

    global_themes_list = get_themes_by_industry(
        brand.get('industry'), include_id=False)
    brand_themes_list = brand.get('themes', [])

    themes_list = filter_themes(brand_themes_list, global_themes_list)

    custom_themes_list = brand.get('customThemes', [])

    csrhub_list = get_csrhub_for_brand(brand)

    if msci_obj:
        for issue_name in msci_obj.get('weights', {}):
            if issue_name in MSCI_COLUMN_TRANSLATE_ADMIN:
                weight = msci_obj.get('weights', {}).get(issue_name, 0)
                score = msci_obj.get('score', {}).get(issue_name, 0)
                if weight or score:
                    msci_insight = {
                        'issue': issue_name,
                        'score': score,
                        'quartile': msci_obj.get('quartile', {}).get(issue_name),
                        'weight': weight,
                        'title': msci_obj.get('title', ''),
                        'description': msci_obj.get('info', {}).get(issue_name, {}).get('description', '')
                    }

                    visible = msci_obj.get('info', {}).get(issue_name, {}).get('visible')
                    if visible is None:
                        visible = not visible and msci_insight['weight']
                    msci_insight['visible'] = visible

                    msci_issues_list.append(msci_insight)

    return {
        'msci': msci_issues_list,
        'themes': themes_list,
        'csrhub': csrhub_list,
        'customThemes': custom_themes_list,
    }


def format_nonprofits(nonprofits):
    base_obj = {
        'preferred': [],
        'blacklist': []
    }
    return nonprofits if nonprofits else base_obj


def convert_to_key_case(label):
    label = label.title()
    label = label.strip().replace(' ', '')
    label = label[0].lower() + label[1:] if label else ''
    return label


def get_esg_key(issue_label):

    issues = [
        'accessToCommunications',
        'accessToFinance',
        'carbonEmissions',
        'climateChangeVulnerability',
        'humanCapitalDevelopment',
        'responsibleInvestment',
    ]

    if issue_label in issues:
        return issue_label

    return convert_to_key_case(issue_label)


def unwrap_msci(brand, msci_data):
    insights = brand.get('insights', {})

    brand_msci = {
        'msciId': str(msci_data.get('msciId', f'MANUAL{brand["name"]}')),
        'issuerName': msci_data.get('issuerName', brand['name']),
        'industry': msci_data.get('industry', brand['industry']),
        'lastImported': msci_data.get('lastImported', datetime.utcnow()),
        'info': msci_data.get('info', {}),
        'weights': msci_data.get('weights', {}),
        'score': msci_data.get('score', {}),
        'quartile': msci_data.get('quartile', {}),
        'weights': msci_data.get('weights', {})
    }
    if insights:
        msci = insights.get('msci', [])
        for item in msci:
            esg_name = get_esg_key(item['esg'])
            brand_msci['info'][esg_name] = {
                'label': item['esg'],
                'description': item['description'],
                'visible': item['visible']
            }
            brand_msci['weights'][esg_name] = item['weight']
            brand_msci['score'][esg_name] = item['score']
            brand_msci['quartile'][esg_name] = item['quartile']
    return brand_msci


def unwrap_themes(brand):
    themes = brand.get('themes', [])
    return themes


def unwrap_custom_themes(brand):
    custom_themes = brand.get('customThemes', [])
    return custom_themes


def unwrap_nonprofits(nonprofits):
    blacklist = nonprofits.get('blacklist', [])
    preferred = nonprofits.get('preferred', [])
    return {
        'blacklist': [ObjectId(item) for item in blacklist],
        'preferred': [ObjectId(item) for item in preferred]
    }


def handle_industry(industry):
    label = ''

    if check_is_objid(industry):
        industry_objid = create_ref(industry)
        try:
            label = get_vocabulary_id_and_label(industry_objid)['label']
        except KeyError:
            return MissingVocabularyError('industry', industry)

    return label if label else industry


def from_be_to_ui(be_brand):
    raise NotImplementedError()


def from_ui_to_be(ui_brand, msci_data):
    # Convert issue to esg
    for insight_msci in ui_brand.get('insights', {}).get('msci', []):
        insight_msci['esg'] = insight_msci.pop('issue')

    # Validate issue labels with vocabulary
    ui_brand = set_vocabulary(ui_brand)

    nonprofits = format_nonprofits(ui_brand.pop('nonprofits', None))

    # Store these before expand_vocabulary_label(), because that method deletes them
    parents = ui_brand.pop('parent_brands', [])
    children = ui_brand.pop('child_brands', [])
    sasb = ui_brand.pop('sasb', {})
    nielsenDemographics = ui_brand.pop('nielsenDemographics', [])

    # store research corp commitments to keep ObjectIds becaause expand vocab removes them
    csrit = ui_brand.pop('researchCorpCommitments', None)

    # Return issues to label text
    # TODO: refactor method to eliminate side-effects
    # TODO: add the other fields instead of popping them off

    blacklist = {'impacts', 'preferredPrograms', 'topics'}
    ui_brand = expand_vocabulary_label(ui_brand, blacklist)

    if 'industry' in ui_brand:
        ui_brand['industry'] = handle_industry(ui_brand['industry'])

    if ui_brand.get('insights'):
        ui_brand['msci'] = unwrap_msci(ui_brand, msci_data)
        ui_brand['themes'] = unwrap_themes(ui_brand['insights'])
        ui_brand['customThemes'] = unwrap_custom_themes(ui_brand['insights'])
        ui_brand['csrhub'] = unwrap_csrhub(ui_brand['insights'])

        ui_brand.pop('insights')

    ui_brand['nonprofits'] = nonprofits

    # Puts SASB back on
    ui_brand['sasb'] = sasb
    ui_brand['nielsenDemographics'] = nielsenDemographics

    if csrit:
        ui_brand['researchCorpCommitments'] = csrit

    ui_brand['parent_brands'] = [ObjectId(p) for p in parents]
    ui_brand['child_brands'] = [ObjectId(c) for c in children]

    v.validate(ui_brand, schema_brand)
    if v.errors:
        raise InvalidPayload(v.errors)

    ui_brand['iname'] = ui_brand['name'].lower()
    ui_brand['searchString'] = create_search_string(ui_brand)

    return ui_brand

def format_sasb_to_ids(brand):
    sasb = brand.get('sasb', {}).get('categories', {}).get('tagged', {}).get('ids', [])
    sasb_id_list = []
    for item in sasb:
        try:
            sasb_id_list.append(ObjectId(item))
        except InvalidId:
            # TODO: find a better way to handle metrics
            # labels that are not mapped in this dict.
            _id = db().map_label_to_id.get(item.lower())
            if _id:
                sasb_id_list.append(_id)

    return sasb_id_list

def format_metrics_to_ids(brand, metric):
    metrics = brand.get(metric, [])
    metrics_id_list = []
    for item in metrics:
        try:
            ObjectId(item)
            metrics_id_list.append(item)
        except InvalidId:
            # TODO: find a better way to handle metrics
            # labels that are not mapped in this dict.
            _id = db().map_label_to_id.get(item.lower())
            if _id:
                metrics_id_list.append(_id)

    return metrics_id_list

def clean_brand(brand):
    brand.pop('iname', None)
    brand.pop('searchString', None)
    brand.pop('msci', None)
    brand.pop('customThemes', None)
    brand.pop('themes', None)
    brand.pop('csrhub', None)

    return brand


def include_theme_id(themes_list):
    for tdict in themes_list:
        theme, relevancies = tdict['theme'], tdict.get('relevancy', 0)
        theme_id = db().map_type_label_to_id.get(f'themes:{theme.lower()}')
        if theme_id:
            tdict['_id'] = str(theme_id)
    return themes_list


def get_themes_by_industry(industry, include_id=True, keep_zeros=False):
    try:
        industry_vocab = db().coll_vocabulary.find_one({'_id': ObjectId(industry)})
    except InvalidId:
        industry_vocab = None

    # Fallback, search by label
    if industry_vocab is None:
        industry_vocab = db().coll_vocabulary.find_one({'versions': VOCAB_V1, 'label': industry, 'type': 'industry'})
        if industry_vocab is None:
            return []

    raw_gics = db().coll_gics.find_one(filter={"type": "raw"})
    # TODO: we should store the raw_weights as separate documents for the query to be lighter
    df_themes = pd.DataFrame.from_dict(json.loads(raw_gics['dataframe']))
    df_themes.fillna(0, inplace=True)

    themes_for_industry = df_themes.loc[industry_vocab.get('label')]
    themes_list = [
        {'theme': t,
         'relevancy': r,
         'visible': True,
         'description': db().map_type_label_to_description.get(f'themes:{t.lower()}', '')}
        for t, r in themes_for_industry.items() if keep_zeros or r]

    if include_id:
        themes_list = include_theme_id(themes_list)

    return themes_list

def get_proposals_for_brand(brand):
    obj_id = brand['_id']
    projection = {
        'name': True,
        'fundingAmount': True,
        'nonprofitName': True,
        'programName': True,
        'client': True,
        'givewithCustomer': True,
        'givewithCustomerRole': True,
        'type': True
    }

    proposals_for_brand = list(db().coll_deals.find({'$or': [{'givewithCustomer': obj_id}, {'client': obj_id}]},
                                                    projection))

    for proposal in proposals_for_brand:
        is_client = proposal['client'] == obj_id
        role, partner_role = ('client', 'givewithCustomer') if is_client else ('givewithCustomer', 'client')

        partner_brand = get_mm_brand(proposal[partner_role])
        proposal['partnerBrand'] = partner_brand.get('name', '') if partner_brand else ''
        proposal['role'] = role

    return proposals_for_brand

def create_search_string(brand):
    # concact nameLabel to name if nameLabel exists - (space is appended to make the field a bit human readable)
    name_concat = brand['name'] + (brand.get('nameLabel', '') and (' ' + brand['nameLabel']))
    return name_concat.lower()

def get_related_brand_names(brand):
    parent_brand_names = []
    child_brand_names = []

    related_brand_list = list(db().coll_brands.find(
        filter={'_id': {'$in': brand.get('parent_brands', []) + brand.get('child_brands', [])}},
        projection={'_id': True, 'name': True}
    ))

    for related_brand in related_brand_list:
        if related_brand['_id'] in brand.get('parent_brands', []):
            parent_brand_names.append(related_brand)
        else:
            child_brand_names.append(related_brand)

    return (parent_brand_names, child_brand_names)

def update_brand_relations(brand, db_brand):
    brand_id = brand['_id']

    parent_brands = set(brand.get('parent_brands', []))
    child_brands = set(brand.get('child_brands', []))
    db_parent_brands = set(db_brand.get('parent_brands', []))
    db_child_brands = set(db_brand.get('child_brands', []))

    # Can't add itself
    parent_brands.discard(brand['_id'])
    child_brands.discard(brand['_id'])

    if not child_brands.isdisjoint(parent_brands):
        raise GivewithError('Cannot add a brand as both a child and parent')

    add_brand_relations(brand_id, parent_brands, child_brands, db_parent_brands, db_child_brands)
    remove_brand_relations(brand_id, parent_brands, child_brands, db_parent_brands, db_child_brands)


def add_brand_relations(brand_id, parent_brands, child_brands, db_parent_brands, db_child_brands):
    # If a brand was found in the request, but not in the db, add it
    for parent in parent_brands:
        if parent not in db_parent_brands:
            result = db().coll_brands.update_one({'_id': parent}, {'$addToSet': {'child_brands': brand_id}})
            if not result.matched_count:
                print('Parent brand not found: {0}'.format(str(parent)), file=sys.stderr)

    for child in child_brands:
        if child not in db_child_brands:
            result = db().coll_brands.update_one({'_id': child}, {'$addToSet': {'parent_brands': brand_id}})
            if not result.matched_count:
                print('Child brand not found: {0}'.format(str(child)), file=sys.stderr)


def remove_brand_relations(brand_id, parent_brands, child_brands, db_parent_brands, db_child_brands):
    # If a brand was found in the db, but not in the request, remove it
    for parent in db_parent_brands:
        if parent not in parent_brands:
            result = db().coll_brands.update_one({'_id': parent}, {'$pull': {'child_brands': brand_id}})
            if not result.matched_count:
                print('Parent brand not found: {0}'.format(str(parent)), file=sys.stderr)

    for child in db_child_brands:
        if child not in child_brands:
            result = db().coll_brands.update_one({'_id': child}, {'$pull': {'parent_brands': brand_id}})
            if not result.matched_count:
                print('Child brand not found: {0}'.format(str(child)), file=sys.stderr)


def format_csrhub_data(csrhub_data, include_topic=False):
    csrhub_causes = {
        'communityDevAndPhilanthropy': {
            'name': 'Community Development and Philanthropy',
            'key': 'Community Dev & Philanthropy Percentile Rank'},
        'humanRightsAndSupplyChain': {
            'name': 'Human Rights and Supply Chain',
            'key': 'Human Rights & Supply Chain Percentile Rank'},
        'diversityAndLaborRights': {
            'name': 'Diversity and Labor Rights',
            'key': 'Diversity & Labor Rights Percentile Rank'},
        'energyAndClimateChange': {
            'name': 'Energy and Climate Change',
            'key': 'Energy & Climate Change Percentile Rank'},
        'leadershipEthics': {
            'name': 'Leadership Ethics',
            'key': 'Leadership Ethics Percentile Rank'}
    }

    result = {}
    for key, cause in csrhub_causes.items():
        data_key = cause.get('key')
        if data_key in csrhub_data:
            data = {
                'label': cause.get('name'),
                'key': key,
                'percentileRank': csrhub_data.get(data_key),
                'visible': True,  # default visiblity is True, overwritten if visible is set in db
            }
            if include_topic:
                data['topic'] = translate_to_topic(_type='csrhub', label=cause.get('name'))

            result[key] = data

    return result


def unwrap_csrhub(brand):
    csrhub_data = brand.get('csrhub', [])
    omit_keys = set(['label', 'percentileRank', 'key'])
    result = dict()

    for data in csrhub_data:
        data_key = data.get('key')
        visible = data.pop('visible', None)  # visible is only saved if it is false

        temp_dict = {key: value for key, value in data.items() if value and key not in omit_keys}

        if temp_dict:
            result[data_key] = temp_dict

        if visible is False:
            result.setdefault(data_key, {}).update({'visible': visible})

    return result


def get_csrhub_for_brand(brand, include_topic=False):
    csrhub_data = get_brand_csrhub_data(brand)
    if not csrhub_data:
        return []

    result = dict_merge(format_csrhub_data(csrhub_data, include_topic), brand.get('csrhub', dict()))

    # return list of objects to front-end for easy rendering
    return list(result.values())


def wrap_csrit(brand):
    """ The following fields from csrit are merged onto brand with some transformations:
        nonprofits.nonGwPreferred is merged onto brand.nonprofits.non_gw_preferred
        nonprofits.preferred is merged onto brand.nonprofits.preferred
        sdgs is merged onto brand.sdg

        This function has no side effects
    """
    csrit_data = brand.get('researchCorpCommitments', {})
    result = {}

    if csrit_data:
        # MARK: Merge preferred non-profits
        csrit_gw_nonprofits = set(csrit_data.get('nonprofits', {}).get('preferred', []))
        gw_nonprofits = set(brand.get('nonprofits', {}).get('preferred', []))
        gw_nonprofits.update(csrit_gw_nonprofits)

        # Transform non_gw_preferred non-profits to list and merge
        csrit_non_gw_nonprofits = set(csrit_data.get('nonprofits', {}).get('nonGwPreferred', []))
        # non_gw_preferred_nonprofits is stored as a string, split into set, append and transform back into string
        # stored data could either be a comma separated string or a semi-colon separated string or a mix of both?
        non_gw_nonprofits_str = brand.get('nonprofits', {}).get('non_gw_preferred', '').replace(';', ',')
        non_gw_nonprofits = {x.strip() for x in non_gw_nonprofits_str.split(',') if x.strip()}
        non_gw_nonprofits.update(csrit_non_gw_nonprofits)

        result['nonprofits'] = {
            **brand.get('nonprofits', {}),
            'preferred': list(gw_nonprofits),
            'non_gw_preferred': ','.join(non_gw_nonprofits)
        }

        # MARK: Merge sdgs
        csrit_sdgs = set(csrit_data.get('sdgLabels', []))
        sdgs = set(brand.get('sdg', []))
        sdgs.update(csrit_sdgs)

        result['sdg'] = list(sdgs)

    return result

def unwrap_csrit(ui_brand, be_brand):
    """ Removes data merged onto the brand from csrit

    To prevent removing manually added data, only remove data that exist in csrit but doesn't exist in the be_document
    """
    csrit_data = be_brand.get('researchCorpCommitments', {})
    result = {}

    if csrit_data:
        # MARK: Transform preferred nonprofits
        csrit_gw_nonprofits = set(csrit_data.get('nonprofits', {}).get('preferred', []))
        ui_gw_nonprofits = set(ui_brand.get('nonprofits', {}).get('preferred', []))
        be_gw_nonprofits = set(be_brand.get('nonprofits', {}).get('preferred', []))

        # items to remove are nonprofits in csrit that weren't already in the be_brand
        gw_nonprofits = ui_gw_nonprofits - (csrit_gw_nonprofits.difference(be_gw_nonprofits))

        # MARK: Transform non_gw_prefereed nonprofits
        csrit_non_gw_nonprofits = set(csrit_data.get('nonprofits', {}).get('nonGwPreferred', []))
        ui_non_gw_nonprofits_str = ui_brand.get('nonprofits', {}).get('non_gw_preferred', '').replace(';', ',')
        be_non_gw_nonprofits_str = be_brand.get('nonprofits', {}).get('non_gw_preferred', '').replace(';', ',')
        ui_non_gw_nonprofits = {x.strip() for x in ui_non_gw_nonprofits_str.split(',') if x.strip()}
        be_non_gw_nonprofits = {x.strip() for x in be_non_gw_nonprofits_str.split(',') if x.strip()}
        # non-gw-preferred is stored as a string, split into set append preferred and transform back into string
        # stored data could either be a comma separated string or a semi-colon separated string
        non_gw_nonprofits = ui_non_gw_nonprofits - (csrit_non_gw_nonprofits.difference(be_non_gw_nonprofits))

        result['nonprofits'] = {
            **ui_brand.get('nonprofits', {}),
            'preferred': list(gw_nonprofits),
            'non_gw_preferred': ','.join(non_gw_nonprofits)
        }

        # MARK: Merge sdgs
        csrit_sdgs = set(csrit_data.get('sdgLabels', []))
        ui_sdgs = set(ui_brand.get('sdg', []))
        be_sdgs = set(be_brand.get('sdg', []))

        sdgs = ui_sdgs - (csrit_sdgs.difference(be_sdgs))
        result['sdg'] = list(sdgs)

    return result

def formatPreferredPrograms(preferredPrograms):
    selectedPrograms = preferredPrograms.get('selected')
    additionalPrograms = preferredPrograms.get('additional')

    # dedup additional programs if editing is false
    if preferredPrograms.get('editing') == False:
        for select in selectedPrograms:
            if select in additionalPrograms:
                additionalPrograms.remove(select)

    preferredPrograms['additional'] = additionalPrograms

    return preferredPrograms

def remove_blacklisted_nonprofit_programs_from_brand(brand):
    # Used to remove blacklisted nonprofit from client-data before saving
    blacklist_data = brand.get('nonprofits', {}).get('blacklist')

    if blacklist_data:
        nonprofit_blacklist = [ObjectId(nonprofit) for nonprofit in blacklist_data]
        nonprofit_programs = {
            str(program['_id']) for program in
            get_documents('mm_programs', {'nonprofit': {'$in': nonprofit_blacklist}}, projection={'_id': True})
        }

        for key in ['cart', 'selected', 'additional']:
            field = set(brand.get('preferredPrograms', {}).get(key, []))

            if field.intersection(nonprofit_programs):
                brand['preferredPrograms'][key] = list(field - nonprofit_programs)


def format_insights_tvl_data(tvl_data, visibility):
    tvl_list = []

    # lookup vocab for sasb
    lookup = db().coll_vocabulary.find({'type': 'sasb', 'camelCaseName': {'$in': list(visibility.keys())}})
    lookup_dict = {item.get('camelCaseName'): item for item in lookup}

    for category in visibility:
        tvl_obj = {}

        if visibility[category]:
            insight = tvl_data.get('insight', {})
            momentum = tvl_data.get('momentum', {})
            volume_ttmdaily = tvl_data.get('volume_ttmdaily', {})
            tags = tvl_data.get('sasb_tags', [])
            insight_data = insight.get(category, None)
            momentum_data = momentum.get(category, None)
            volume_ttmdaily = volume_ttmdaily.get(category, None)

            if insight_data:
                tvl_obj['insight'] = insight_data
            if momentum_data:
                tvl_obj['momentum'] = momentum_data
            if volume_ttmdaily:
                tvl_obj['volume_ttmdaily'] = volume_ttmdaily
            if category in tags:
                tvl_obj['materiality'] = True
            if tvl_obj:
                vocab = lookup_dict.get(category, {})
                tvl_obj.update({
                    'category': category,
                    'label': vocab.get('label'),
                    'topic': get_vocabulary_label_v2(vocab.get('topic'))
                })
                tvl_list.append(tvl_obj)

    last_updated = tvl_data.get('lastUpdated') if tvl_list else None
    return tvl_list, last_updated

def get_tvl(brand):
    sasb_ids = brand.get('sasb', {}).get('categories', {}).get('tagged', {}).get('ids', [])
    isin_id = brand.get('ISIN', '')
    tvl_data = get_tvl_data(isin_id, sasb_ids)
    return format_insights_tvl_data(tvl_data, brand.get('tvlVisibility', {}))


def get_gri():
    topic_gri = db().coll_vocabulary.find({'type': 'gri', 'topic': {'$exists': True}})
    return [{'label': x.get('label'), 'code': x.get('code'), 'topic': get_vocabulary_label_v2(x.get('topic'))}
            for x in topic_gri]


def get_display_name(brand):
    return brand.get('nameLabel') or brand.get('name')
