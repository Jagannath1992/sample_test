import json

def test_get_programs(client, admin_header):
    response = client.get('/admin/programs', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/admin/programs?sort=name asc&filter=isValid eq true', headers=admin_header)
    assert response.status_code == 200


def test_get_program(client, admin_header):
    response = client.get('/admin/programs', headers=admin_header)
    assert response.status_code == 200

    nonprofits = json.loads(response.data.decode())
    assert len(nonprofits) > 0

    response = client.get('/admin/programs/' + str(nonprofits[0]['_id']), headers=admin_header)
    assert response.status_code == 200



def test_validate(client, admin_header):
    response = client.post('/admin/program:validate?include_valid=true&include_invalid=true&include_diff=true', data=json.dumps({}),headers=admin_header)
    assert response.status_code == 200
