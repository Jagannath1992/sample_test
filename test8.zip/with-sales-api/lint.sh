#!/bin/bash

mkdir -p static
cd app
find . -iname "*.py" | xargs pylint --output-format=json > ../static/pylint.json
find . -iname "*.py" | xargs pylint | tail > ../static/pylint_score.txt

# https://radon.readthedocs.io/en/latest/intro.html
radon cc -j . > ../static/radon_cc.json
radon mi -j . > ../static/radon_mi.json
