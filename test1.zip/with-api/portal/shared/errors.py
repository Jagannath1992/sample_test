from enum import Enum
from typing import List


class GivewithError(Exception):
    def __init__(self, code: str, message: str):
        self.code = code
        self.message = message


class ExternalError(GivewithError):
    def __init__(self, code: str, message: str):
        super().__init__(code, message)


class GivewithException(Exception):
    def __init__(self, message: str, errors: List[GivewithError] = [], source: str = None):
        self.message = message
        self.errors = errors
        self.source = source
