from flask import jsonify, request

from matchmaking.controllers import admin_bp
from matchmaking.permission_decorator import require_admin_permission
from matchmaking.validation.award import validate_award
from matchmaking.dao.utils import add_document, get_documents, replace_document, get_document_by_id

"""
@api {get} /admin/award List awards
@apiName List awards
@apiGroup Award
@apiDescription list awards

@apiSuccessExample {json} Success list awards example:
{
    [
        "_id": "5efc9e39de06c4d5c3c23ae5",
        "name": "Grammy",
        'active': true,
        "url": "https://www.grammy.com/",
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z',
        "description": "The Grammy Award is an award presented by the Recording Academy to recognize Outstanding
            Achievement in the music industry" of the United States."
    ]
}
"""
@admin_bp.route('/award', methods=['GET'])
@require_admin_permission
def list_award():
    return jsonify(get_documents('award'))


"""
@api {post} /admin/award
@apiName Create a award
@apiGroup Award
@apiDescription Create a award

@apiParamExample {json} Create a award example:
{
    "name": "Grammy",
    "url": "https://www.grammy.com/",
    'active': true,
    "description": "The Grammy Award is an award presented by the Recording Academy to recognize Outstanding
        Achievement in the music industry" of the United States."
}

@apiSuccessExample {json} Success created award example:
{
    "_id": "5efc9e39de06c4d5c3c23ae5",
    "name": "Grammy",
    "url": "https://www.grammy.com/",
    'active': true,
    'createdAt': '2021-03-30 00:00:00.000Z',
    'lastUpdated': '2021-03-30 00:00:00.000Z',
    "description": "The Grammy Award is an award presented by the Recording Academy to recognize Outstanding
        Achievement in the music industry" of the United States."
}
"""
@admin_bp.route('/award', methods=['POST'])
@require_admin_permission
def add_award():
    award = request.json
    valid, errors = validate_award(award)
    if not valid:
        return jsonify(errors), 400

    return jsonify(add_document('award', award))


"""
@api {put} /admin/award/<award_id> Update award by id
@apiName Update awards
@apiGroup Award
@apiDescription Update awards

@apiSuccessExample {json} Success update awards example:
{
    [
        "_id": "5efc9e39de06c4d5c3c23ae5",
        "name": "Grammy",
        'active': true,
        "url": "https://www.grammy.com/",
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z',
        "description": "The Grammy Award is an award presented by the Recording Academy to recognize Outstanding
            Achievement in the music industry" of the United States."
    ]
}
"""
@admin_bp.route('/award/<_id>', methods=['PUT'])
@require_admin_permission
def update_award(_id):
    exist = get_document_by_id('award', _id)
    if not exist:
        return 'award not found', 404

    updated_award = request.json
    update = replace_document('award', _id, updated_award)
    return jsonify(update)


"""
@api {put} /admin/award/ Update award list
@apiName Update award list
@apiGroup Award
@apiDescription Update award list

@apiSuccessExample {json} Success update awards example:
{
    [
        "_id": "5efc9e39de06c4d5c3c23ae5",
        "name": "Grammy",
        'active': true,
        "url": "https://www.grammy.com/",
        'createdAt': '2021-03-30 00:00:00.000Z',
        'lastUpdated': '2021-03-30 00:00:00.000Z',
        "description": "The Grammy Award is an award presented by the Recording Academy to recognize Outstanding
            Achievement in the music industry" of the United States."
    ]
}
"""
@admin_bp.route('/award/', methods=['PUT'])
@require_admin_permission
def update_award_list():
    awards = request.json
    updated_awards = []
    for award in awards:
        # new award
        if '_id' not in award:
            updated_awards.append(add_document('award', award))

        # existing award
        else:
            _id = award['_id']
            updated_awards.append(replace_document('award', _id, award))

    return jsonify(updated_awards)

"""
@api {put} /admin/award/<award_id> Soft delete award by id
@apiName Delete awards
@apiGroup Award
@apiDescription Soft delete awards

"""
@admin_bp.route('/award/<_id>', methods=['DELETE'])
@require_admin_permission
def delete_award(_id):
    award = get_document_by_id('award', _id)
    if not award:
        return 'award not found', 404

    award['active'] = False
    update = replace_document('award', _id, award)
    return jsonify(update)
