from portal.shared.repository import DocumentRepository


class CauseAreaRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['cause_area'])


class SkuRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['sku'])
