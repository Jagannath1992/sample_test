from typing import List

from portal.shared.repositories import order_repository
from portal.shared.enums import OrderStatus


GROUP_BY_CURRENCY = {'currency': '$_id.currency'}
GROUP_BY_STATUS = {'status': '$comments.newStatus', 'currency': '$currency'}
GROUP_BY_CAUSE_AREA = {'causeArea': '$_id.causeArea', 'currency': '$_id.currency'}
GROUP_BY_CAUSE_AREA_STATUS = {'causeArea': '$causeArea.name', 'status': '$comments.newStatus', 'currency': '$currency'}


class TestOrderRepositoryWinRate:

    def test_win_rate_for_overview(self, init_test_data):
        # arrange
        us, _ = init_test_data
        group_by = [GROUP_BY_STATUS, GROUP_BY_CURRENCY]
        result_key = {'currency': 'USD'}
        # act
        results = order_repository().get_win_rate({}, group_by, False)
        actual_result = _get_result(results, **result_key, status=OrderStatus.PENDING_APPROVAL.value)
        # assert
        assert actual_result == 8

    def test_win_rate_for_details(self, init_test_data):
        # arrange
        us, _ = init_test_data
        group_by = [GROUP_BY_CAUSE_AREA_STATUS, GROUP_BY_CAUSE_AREA]
        result_key = {'causeArea': 'Cause area 2', 'currency': 'GBP'}
        # act
        results = order_repository().get_win_rate({}, group_by, False)
        actual_result = _get_result(results, **result_key, status=OrderStatus.COMPLETED.value)
        # assert
        assert actual_result == 2

    def test_win_rate_for_overview_using_filter(self, init_test_data):
        # arrange
        us, uk = init_test_data
        group_by = [GROUP_BY_STATUS, GROUP_BY_CURRENCY]
        filters = {
            'causeArea._id': {'$in': [uk['instance']['causeAreas'][1]['causeArea']['_id']]},
            'loc._id': {'$in': [uk['locale']['_id']]}
        }
        result_key = {'currency': 'GBP'}
        # act
        results = order_repository().get_win_rate(filters, group_by, False)
        actual_result = _get_result(results, **result_key, status=OrderStatus.APPROVED.value)
        # assert
        assert len(results) == 1
        assert actual_result == 4


def _get_result(results: List[dict], causeArea: str = None, status: str = None, currency: str = 'USD') -> int:
    for result in results:
        if result['_id']['currency'] == currency:
            if not causeArea or result['_id']['causeArea'] == causeArea:
                for count in result['counts']:
                    if count['status'] == status:
                        return count['count']
