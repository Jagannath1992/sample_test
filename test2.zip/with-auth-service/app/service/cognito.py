from botocore.exceptions import ClientError
from app.service import services

def authenticate_user(user_cognito_id, password):
    cognito_client = services.get('cognito_client')
    cognito_client_id = services.get('cognito_client_id')
    try:
        response = cognito_client.initiate_auth(
            ClientId=cognito_client_id,
            AuthFlow="USER_PASSWORD_AUTH",
            AuthParameters={
                "USERNAME": user_cognito_id,
                "PASSWORD": password
            }
        )
    except ClientError as e:
        raise Exception(e.response.get('Error', {}).get('Message', ''))

    return response


def authenticate_refresh_token(refresh_token):
    cognito_client = services.get('cognito_client')
    cognito_client_id = services.get('cognito_client_id')
    try:
        response = cognito_client.initiate_auth(
            ClientId=cognito_client_id,
            AuthFlow="REFRESH_TOKEN_AUTH",
            AuthParameters={
                "REFRESH_TOKEN": refresh_token
            }
        )
    except ClientError as e:
        raise Exception(e.response.get('Error', {}).get('Message', ''))

    return response


def change_password(challenge_name, session, username, new_password, given_name, family_name):
    cognito_client = services.get('cognito_client')
    cognito_client_id = services.get('cognito_client_id')
    try:
        response = cognito_client.respond_to_auth_challenge(
            ClientId=cognito_client_id,
            ChallengeName=challenge_name,
            Session=session,
            ChallengeResponses={
                "USERNAME": username,
                "NEW_PASSWORD": new_password,
                "userAttributes.given_name": given_name,
                "userAttributes.family_name": family_name
            }
        )
    except ClientError as e:
        raise Exception(e.response.get('Error', {}).get('Message', ''))

    return response
