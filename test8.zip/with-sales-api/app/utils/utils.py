import string
import secrets
import math
import urllib

from datetime import datetime, timedelta
from flask import current_app, send_file
from app.db.utils import get_document, get_document_by_id
from tempfile import TemporaryDirectory
from app.service.s3 import generate_signed_url

DEFAULT_GIVEWITH_FEE_PERCENTAGE = 15


def calculate_funding_percentage(brand):
    give_type = brand['givePercentageType']
    custom_give_percentage = brand.get('customGivePercentage')

    if give_type == 'custom':
        return custom_give_percentage

    else:
        return 2


def calculate_givewith_fee_percentage(deal):
    if deal.get('givewithFeePercentage'):
        return deal.get('givewithFeePercentage')

    customer_brand = get_document_by_id('mm_brands', deal.get('givewithCustomer'))
    return customer_brand.get('givewithFeePercentage', DEFAULT_GIVEWITH_FEE_PERCENTAGE)


def calculate_give_portion(give_percentage, budget, givewith_fee_percentage=DEFAULT_GIVEWITH_FEE_PERCENTAGE):
    gw_portion = round(budget * (give_percentage / 100), 2)
    # for example, givewith_fee_percentage is 15, so the funding_percent should be .85
    funding_percent = (100 - givewith_fee_percentage) / 100
    total_funding = round(gw_portion * funding_percent, 2)
    return gw_portion, total_funding


def generate_password():
    alphabet = string.ascii_letters + string.digits
    while True:
        password = ''.join(secrets.choice(alphabet) for i in range(10))
        if (any(c.islower() for c in password)
                and any(c.isupper() for c in password)
                and sum(c.isdigit() for c in password) >= 3):
            break

    return password


def init_deliverables():
    customer_deliverable_names = [
        'SocialMediaPosts',
        'PressRelease',
        'CSRHighlight',
        'ESGReportingGuide_CUSTOMER',
        'InvestorRelations',
        'FactSheet',
        'Infographic',
        'Photos',
        'LongFormVideo',
        'ShortFormVideo',
    ]

    client_deliverable_names = [
        'SocialMediaPosts',
        'PressRelease',
        'CSRHighlight',
        'ESGReportingGuide_CLIENT',
        'InvestorRelations',
        'FactSheet',
        'Infographic',
        'Photos',
        'LongFormVideo',
        'ShortFormVideo',
    ]

    customer_deliverables = []
    client_deliverables = []

    for name in customer_deliverable_names:
        deliverable = {
            'name': name,
            'display': False,
        }
        customer_deliverables.append(deliverable)

    for name in client_deliverable_names:
        deliverable = {
            'name': name,
            'display': False,
        }
        client_deliverables.append(deliverable)

    return {
        'givewithCustomer': {
            'deliverables': customer_deliverables
        },
        'client': {
            'deliverables': client_deliverables
        }
    }


def transform_outputs_to_commerce_outputs_v2(program, funding_amount, funding_currency):
    """ Calculate output values from output quantity, budget and proposal funding amount
        Each output_cost = program_budget / quantity, and hence output value = funding_amount / output_cost if
        the output scaleType is proportional
        Also, append outcomes to outputs to easy rendering by front-end
        NOTE: This function has side-effects (transforms outputs and removes outcomes)
    """
    outputs = program.get('outputs', [])
    for output in outputs:
        scale_type = get_document_by_id('mm_vocabulary', output.get('scaleType'))
        output['scaleType'] = scale_type.get('label', '')

    budget = program.get('budget')
    program_currency = program.get('currency') or 'USD'

    # if currencies aren't equal, convert as needed
    if (program_currency != funding_currency) and (funding_currency is not None):
        funding_amount = convert_to_usd(funding_amount, funding_currency)
        budget = convert_to_usd(budget, program_currency)

    if budget:
        for output in outputs:
            quantity = output.get('quantity', 0)
            if quantity and output.get('scaleType').lower() == 'proportional' and funding_amount:
                output_cost = budget / quantity
                output['value'] = math.floor(funding_amount / output_cost)
            else:
                output['value'] = quantity


def convert_to_usd(amount, symbol):
    rate = get_forex_rates().get(symbol)
    if rate and rate != 0:
        return amount / rate
    else:
        return 0


def get_forex_rates():
    """ Gets foreign exchange rates with a USD base
    NOTE: rates updated daily via a lambda function
    Data comes from https://ratesapi.io/
    """
    forex = get_document('forex', {})

    if not forex:
        current_app.logger.error('MissingForexError: No Foreign Exchange data found')
        return {}

    forex_date = datetime.strptime(forex['date'], '%Y-%m-%d')
    forex_date_age = datetime.utcnow() - forex_date

    if forex_date_age > timedelta(days=7):
        current_app.logger.error('ExpiredForexData: Foreign Exchange data is older than 7 days')
        return {}

    return forex['rates']


def esg_key_to_msci_column(esg_key):
    msci_column_map = {
        'carbonEmissions': 'Carbon Emissions',
        'climateChangeVulnerability': 'Climate Change Vulnerability',
        'humanCapitalDevelopment': 'Human Capital Development',
        'responsibleInvestment': 'Responsible Investment',
        'accessToCommunications': 'Access to Communications',
        'accessToFinance': 'Access to Finance',
    }

    return msci_column_map.get(esg_key, esg_key)


def get_file_from_url(url, filename, directory=''):
    """ Accepts full URL, filename and optionally, a specific directory.
        If directory not found, use another temporary directory.
        Save URL into a file to return.
    """
    with TemporaryDirectory() as tmpdirname:
        file_directory = directory or tmpdirname
        f, _ = urllib.request.urlretrieve(url, file_directory + '/' + filename)
        request = send_file(f, as_attachment=True)
        data = {'file': request, 'pathname': f}

    return data


def get_filtered_document(documents, filter_tags):
    '''
    Return document from simian_media coll in which all strings in filter_tags are found within the 'tags' field
    '''
    filter_tags = [tag.lower() for tag in filter_tags]

    for doc in documents:
        if doc.get('tags'):
            list_of_tags = doc.get('tags').split(',')
            list_of_tags = [tag.lower() for tag in list_of_tags]

            while '' in list_of_tags:
                list_of_tags.remove('')

            if all(tag.lower() in list_of_tags for tag in filter_tags):
                return doc

    return None


def get_assets(document):
    '''
    Returns signed url of media and thumbnail images from a simian_media document
    '''
    media = document.get('media_s3')
    thumbnail = document.get('thumbnail_s3')

    return {
        'media': generate_signed_url(media) if media else None,
        'thumbnail': generate_signed_url(thumbnail) if thumbnail else None
    }


def to_bool(value):
    return value.lower() in ('true', '1', 'yes') if type(value) == str else value
