from bson import ObjectId
from portal.testing.faker import DocumentFaker
from portal.shared.dates import get_utcnow


class LocaleFaker(DocumentFaker):
    def _generate_document(self, i):
        now = get_utcnow()
        return {
            '_id': ObjectId(),
            "name": "US",
            "description": "This is locale for the entirety of the United States",
            "settings": {
                "currency": "USD",
                "symbol": "$",
                "regionLabel": "State",
                "regions": ["Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware",
                            "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
                            "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska",
                            "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio",
                            "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas",
                            "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"],
            },
            "active": True,
            "createdBy": "admin@givewith.com",
            "createdAt": now,
            "lastUpdatedBy": "admin@givewith.com",
            "lastUpdated": now
        }
