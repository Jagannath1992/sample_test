from flask import request, send_file
from flask_restful import Resource, abort
from app.service.s3 import download_asset
from app.utils.auth import authenticate, can
from rbac_library.constants import Action


class Asset(Resource):
    @authenticate
    @can(Action.READ)
    def get(self):
        if 'name' not in request.args:
            abort(400, messsage='file name is required')

        name = request.args.get('name')
        file = download_asset(name)

        if file is None:
            abort(404, message='file not found')

        return send_file(file.name, as_attachment=True)

