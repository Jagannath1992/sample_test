import os
from pymongo import MongoClient

MONGO_URL = os.environ.get('MONGO_URL','mongodb://localhost:27017')
DB_NAME = os.environ.get('DB_NAME','givewith_staging')

try:	
	mongo_client = MongoClient(MONGO_URL)
	db = mongo_client[DB_NAME]	
	collection = db["mm_vocabulary"]
except Exception as err:
	print("Error occured while connecting to Mongo DB. ERROR-> ",str(err))

theme_object={
    'themes': {
       'Criminal justice' :'Restorative justice or criminal justice',
       "Economic empowerment":"Economic empowerment and workforce development",
       "Human rights and civic engagement": "Equity, human rights, and civic engagement",
       "LGBTQQIA+": "LGBTQ+",
    },
    'causes': {
        "Criminal justice":"Restorative justice or criminal justice",
    "Economic empowerment":"Economic empowerment and workforce development",
    "Human rights and civic engagement":"Equity, human rights, and civic engagement"
    }
    
}

vocab_types=list(theme_object.keys())
# print(vocab_types)

try:
	for vocab_type in vocab_types:
		labels = theme_object.get(vocab_type)
		for old_label in labels:
			# print("label : ",old_label,"        ","new label : ",labels[old_label])
			new_label = labels[old_label]
			query = {'$and': [{"type": vocab_type},{"label": old_label}] }
			newvalues = { "$set": { "label": new_label } }
			x = collection.update_many(query, newvalues)
			print(vocab_type," with label ",old_label,x.modified_count," documents updated.")
except Exception as err:
	print("Error occured while while updating the document in Mongo DB. ERROR-> ",str(err))