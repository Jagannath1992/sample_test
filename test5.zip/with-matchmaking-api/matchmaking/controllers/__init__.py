# -*- coding: utf-8 -*-

from flask_restx import Api
from flask import Blueprint

root_public_bp = Blueprint('root_public', __name__)
root_protected_bp = Blueprint('root', __name__)
public_bp = Blueprint('public', __name__)
admin_bp = Blueprint('admin', __name__)
dash_bp = Blueprint('dashboard', __name__)
secure_commerce_bp = Blueprint('secure_commerce', __name__)
survey_bp = Blueprint('survey', __name__)
mpa_bp = Blueprint('mpa', __name__)


@root_public_bp.route('/', endpoint='root')
def monitor():
    return 'ok'