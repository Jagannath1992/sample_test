from matchmaking.query_parser import *

def test_validate_parentheses():
    s = '((()))'
    valid, count =  validate_parentheses(s)
    assert valid
    assert count == 3

    s = '()()'
    valid, count = validate_parentheses(s)
    assert valid
    assert count == 2

    s = '('
    valid, count = validate_parentheses(s)
    assert not valid

    s = ')'
    valid, count = validate_parentheses(s)
    assert not valid

    s = ')('
    valid, count = validate_parentheses(s)
    assert not valid

    s = '(()'
    valid, count = validate_parentheses(s)
    assert not valid


def test_parse_filter_pair():
    args = ['a', 'eq', '1']
    assert parse_filter_pair(args, 0) == {'a': 1}

    args = ['a', 'ne', 'string']
    assert parse_filter_pair(args, 0) == {'a': {'$ne': 'string'}}


def test_parse_filter_and_only():
    args = ['a', 'eq', '1', 'and', 'b', 'gt', '2']
    assert parse_filter_and_only(args) == {'$and': [{'a': 1}, {'b': {'$gt': 2}}]}


def test_parse_filter_helper():
    args = ['a', 'eq', '1', 'and', 'b', 'gt', '2']
    assert parse_filter_helper(args) == {'$and': [{'a': 1}, {'b': {'$gt': 2}}]}

    args = ['a', 'eq', '1', 'and', 'b', 'gt', '2', 'or', 'c', 'ge', 'd']
    assert parse_filter_helper(args) == \
        {'$or':
            [
                {'$and':
                    [
                        {'a': 1},
                        {'b': {'$gt': 2}}
                    ]
                },
                {'$and':
                    [
                        {'c': {'$gte': 'd'}}
                    ]
                }
            ]
        }


def test_parse_filter_param():
    args = "a eq b"
    assert parse_filter_params(args) == {'$and': [{'a': 'b'}]}

    args = "a eq b and b eq c"
    assert parse_filter_params(args) == {'$and': [{'a': 'b'}, {'b': 'c'}]}

    args = "a eq b or b eq c and c eq d"
    assert parse_filter_params(args) == {'$or': [{'$and': [{'a': 'b'}]}, {'$and': [{'b':'c'}, {'c':'d'}]}]}

    args = "(a eq b or b eq c) and c eq d"
    assert parse_filter_params(args) == {'$and': [{'$or': [{'$and': [{'a': 'b'}]}, {'$and': [{'b': 'c'}]}]},{'c': 'd'}]}

    args = "(a eq b)"
    assert parse_filter_params(args) == {'$and': [{'$and': [{'a': 'b'}]}]}
