# -*- coding: utf-8 -*-
from enum import Enum, unique, auto
from bson import ObjectId
from bson.errors import InvalidId
from datetime import datetime, date
from cerberus import Validator
import dateutil.parser
from typing import List

class GivewithValidator(Validator):
    def _validate_type_object_id(self, value):
        if type(value) == ObjectId:
            return True


class RecommendationItem:
    """Object that represents a single program recommendation information."""

    def __init__(self, program_name, is_valid, score, id_, nonprofit, active, minimum_funding=None):
        self.program_name = program_name
        self.score = score
        self.id_ = id_
        self.nonprofit = nonprofit
        self.minimum_funding = minimum_funding
        self.is_valid = is_valid
        self.active = active
        # The fields below can be overridden later
        self.invalid_reasons = []
        self.match_type = 'MATCH'
        self.custom_match = None
        self.customer_preferred = False

    def __repr__(self):
        return f"RecommendationItem('{self.program_name}', {self.is_valid}, {self.score}, {self.id_}, '{self.nonprofit}', '{self.active}')"

    def __eq__(self, other):
        return (self.program_name == other.program_name
                and self.is_valid == other.is_valid
                and self.score == other.score
                and self.nonprofit == other.nonprofit
                and self.active == other.active
                and self.invalid_reasons == other.invalid_reasons
                and self.id_ == other.id_)

    def tojson(self):
        json = {'_id': self.id_,
                'name': self.program_name,
                'isValid': self.is_valid,
                'invalidReasons': self.invalid_reasons,
                'nonprofit': self.nonprofit,
                'match': self.score,
                'matchType': self.match_type,
                'customerPreferred': self.customer_preferred,
                'active': self.active,
                'minimumFunding': self.minimum_funding}

        if self.custom_match:
            json['customMatch'] = self.custom_match

        return json


@unique
class OrgType(Enum):
    """Enum representing the organization types a user can belong to

    NOTE: A user's organization type will be stored in the db as a lowercase
    string under the key orgType. hence, always compare orgType with
    OrgType.value rather than OrgType.name
    """
    BRAND = 'brand'
    NONPROFIT = 'nonprofit'

    def __str__(self):
        return self.value


@unique
class UserType(Enum):
    """Enum representing user types. Mostly used to to limit permissions if needed
    and for validation.

    NOTE: A user's type will be stored in the db as a lowercase string under
    the key type. Hence, always compare userType with UserType.value rather
    than UserType.name
    """
    ADMIN = 'admin'
    CLIENT = 'client'

    REOWNER = 're-owner'
    REMANAGER='re-manager'
    REVENDOR= 're-vendor'
    REMARQUEETENANT='re-marquee-tenant'
    RETENTANT='re-tenant'


    def __str__(self):
        return self.value


class Currency(Enum):
    USD = auto()
    GBP = auto()
    EUR = auto()

    def __str__(self):
        return self.name

class AllowedProposalTypes(Enum):
    """Enum representing which types of proposals a brand has access to.
    """
    NORMAL = 'normal'
    COVID = 'covid'

    def __str__(self):
        return self.value

class UserDepartmentType(Enum):
    """Enum representing a user's department type
    """
    PROCUREMENT = 'Procurement'
    SALES = 'Sales'
    CSR = 'CSR'
    MARKETING = 'Marketing'
    HR = 'HR'
    EXECUTIVE = 'Executive'
    OTHER = 'Other'

    def __str__(self):
        return self.value

@unique
class UserRole(Enum):
    """User Role for determining resource access"""
    IC = 'ic'
    MANAGER = 'manager'
    ADMIN = 'admin'
    SUPERUSER = 'superuser'

    def __repr__(self) -> str:
        return self.value

    __str__ = __repr__

@unique
class RBACGroup(Enum):
    """Basic RBAC groups for CRUD permissions"""
    READER = 'reader'
    CREATOR = 'creator'
    UPDATER = 'updater'
    DELETER = 'deleter'

    def __repr__(self) -> str:
        return self.value

    __str__ = __repr__

class DealPaymentMethods(Enum):
    """Enum representing a payment methods options
    """
    PAY_AS_YOU_GO = 'payAsYouGo'
    PRE_PAID = 'prePaid'

    def __str__(self):
        return self.value


def get_enum_members(enum_class: Enum) -> List[str]:
    return [str(member) for member in enum_class]


def to_number_without_commas(value):
    return float(value.strip().replace(',', '')) if type(value) == str else value


def to_number(value):
    if type(value) == str:
        return 0 if value == '' else float(value)

    return value


def to_integer(value):
    return int(value) if type(value) == str else value

def percentage_to_float(value):
    return to_integer(value) / 100

def to_number_or_string(value):
    try:
        return float(value)
    except ValueError:
        return value


def to_bool(value):
    return value.lower() in ('true', '1', 'yes') if type(value) == str else value


def to_object_id(value):
    return ObjectId(value)


def to_object_id_or_str(value):
    try:
        return ObjectId(value)
    except InvalidId:
        return value


def to_lower(string):
    return string.lower()


def to_datetime(date_string):
    from matchmaking.utils import GivewithError

    if isinstance(date_string, str):
        return dateutil.parser.parse(date_string)
    elif isinstance(date_string, date):
        return date_string
    else:
        raise GivewithError('Incorrectly formatted date')

type_datetime = ['datetime', 'string']
type_number = ['number', 'string']
type_object_id = ['object_id', 'string']

type_multiselect = ['dict']
type_file = ['dict', 'string']
type_multi_input = ['dict']

# special type_schemas for survey validator
def schema_multiselect(set_required=False, set_empty=True, norm_rules=None):
    """
    MultiSelect Schema for Nonprofit Forms
    NOTE: Pass norm_rules if using this for normalization only, for all instances, leave norm_rules empty
    norm_rules should set the type and coercer of the selected schema
    """
    if norm_rules:
        return [
            {
                'selected': {'type': 'list', 'schema': norm_rules},
                'NAValue': {'type': 'string'},
                'other': {'type': 'dict'},
                'groupOther': {'type': 'dict'}
            }
        ]

    return [
        {
            'selected': {'type': 'list', 'required': set_required, 'empty': set_empty, 'schema': {
                'type': type_object_id, 'required': set_required, 'empty': set_empty
            }},
            'NAValue': {'type': 'string'},
            'other': {'type': 'dict'},
            'groupOther': {'type': 'dict'}
        },
        {
            'selected': {'type': 'list'},
            'NAValue': {'type': 'string'},
            'other': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'selected': {'type': 'boolean', 'allowed': [True, set_required]},
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'groupOther': {'type': 'dict'}
        },
        {
            'selected': {'type': 'list'},
            'NAValue': {'type': 'string'},
            'groupOther': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'valueschema': {
                'type': 'dict', 'schema': {
                    'selected': {'type': 'boolean', 'allowed': [True, set_required]},
                    'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
                }
            }}
        }
    ]

def schema_multi_input(set_required=False, set_empty=True, norm_rules=None):
    # norm rules should set 'type' and 'coerce', use iff using for normalization
    if norm_rules:
        return {'quantity': norm_rules, 'description': {'type': 'string'}}

    return {
        'quantity': {'type': ['number', 'string'], 'required': set_required, 'empty': set_empty},
        'description': {'type': 'string', 'required': set_required, 'empty': set_empty}
    }

schema_file = lambda set_required=False, set_empty=True: {
    'name': {'type': 'string', 'required': set_required, 'empty': set_empty},
    'url': {'type': 'string', 'required': set_required, 'empty': set_empty, 'regex': REGEX_VALID_URL}
}

allowed_org_types = get_enum_members(OrgType)
allowed_user_types = get_enum_members(UserType)
allowed_user_roles = get_enum_members(UserRole) + get_enum_members(RBACGroup)
allowed_currency_types = get_enum_members(Currency)
allowed_proposal_access_types = get_enum_members(AllowedProposalTypes)
allowed_department_types = get_enum_members(UserDepartmentType)
allowed_payment_methods = get_enum_members(DealPaymentMethods)

REGEX_VALID_EMAIL = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
# URLs can either be of format https://path/to/file (PUBLIC) OR path/to/file (PRIVATE)
REGEX_VALID_URL = r'^(?:http(?:s)?://)?(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+$'
REGEX_VALID_DATE = r'^\d{4}-\d{1,2}-\d{1,2}$'

v = GivewithValidator(purge_unknown=True)


schema_location = {
    'type': 'dict',
    'schema': {
        'country': {'type': 'string'},
        'region': {'type': 'string'},
        'state': {'type': 'string'},
        'city': {'type': 'string'},
        'county': {'type': 'string'},
    }
}
schema_locations = {
    'type': 'list',
    'schema': schema_location
}


schema_nonprofit_csv = {
    'name': {'required': True, 'empty': False, 'type': 'string'},
    'url': {'empty': False, 'type': 'string', 'regex': REGEX_VALID_URL},
    'description': {'empty': False, 'type': 'string'},
    'descriptionLong': {'empty': False, 'type': 'string'},
    'impactsDescription': {'empty': False, 'type': 'string'},
    'impacts': {'empty': False, 'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'value': {'empty': False, 'type': ['number', 'string'], 'coerce': to_number_or_string},
        'label': {'empty': False, 'type': 'string'}
    }}}
}

"""
schema version #2 for nonprofit converted from naf
"""
schema_nonprofit_v2 = {
    '_id': {
        'type': type_object_id
    },
    'applicationFormName' : {
        'type': 'string',
        'required': True,
        'empty': False,
    },
    'givewithAdmin': {
        'type': type_object_id,
        'required': True,
        'empty': False,
        'coerce': to_object_id
    },
    'createdAt': {
        'type': type_datetime,
        'required': False,
    },
    'lastUpdated': {
        'type': type_datetime,
        'required': False,
    },
    'slug': {
        'type': 'string',
        'required': True,
        'empty': False,
    },
    'name': {
        'type': 'string',
        'required': True,
        'empty': False,
    },
    'general':{
        'type': 'dict',
        'required': True,
        'empty': False,
        'schema': {
            'name' :{
                'type': 'dict',
                'schema': {
                    'legalOrganizationName': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'publicOrganizationName': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    }
                }
            },
            'social' :{
                'type': 'dict',
                'required': False,
                'schema': {
                    'facebook': {
                        'type': 'string',
                    },
                    'instagram': {
                        'type': 'string'
                    },
                    'linkedIn': {
                        'type': 'string'
                    },
                    'twitter': {
                        'type': 'string'
                    },
                    'websiteURL': {
                        'type': 'string'
                    }
                }
            },
            'contact': {
                'type': 'dict',
                'required': True,
                'empty': False,
                'schema': {
                    'email': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'name': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'phone': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'professionalTitle': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                }
            },
            'location': {
                'type': 'dict',
                'required': True,
                'empty': False,
                'schema': {
                    'generalLocation': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'specificLocation': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'charityNumber': {
                        'type': 'string',
                        'required': False,
                    },
                    'otherId': {
                        'type': 'string',
                        'required': False,
                    },
                    'w9': {
                        'type': 'dict',
                        'required': False,
                        'schema': {
                            'name': {
                                'type': 'string',
                                'required': False,
                            },
                            'url': {
                                'type': 'string',
                                'required': False,
                            }
                        }
                    },
                    'taxId': {
                        'type': 'string',
                        'required': False,
                    },
                }
            },
            'missionAgreement': {
                'type': 'boolean',
                'required': True,
                'empty': False,
            }
        },
    },
    'overviewAndMission': {
        'type': 'dict',
        'required': True,
        'empty': False,
        'schema': {
            'causeAreas': {
                'type': 'dict',
                'required': True,
                'empty': False,
                'schema': {
                    'selected': {
                        'type': 'list',
                        'schema': {
                            'type': 'string'
                        }
                    },
                }
            },
            'lifetimeOutputs': {
                'type': 'list',
                'required': True,
                'empty': False,
                'schema': {
                    'type': 'dict',
                    'schema': {
                        'key': {
                            'type': 'string'
                        },
                        'output': {
                            'type': 'string'
                        },
                        'quantity': {
                            'type': type_number,
                            'coerce': to_number_or_string,
                        },
                    }
                }
            },
            'researchAndEvaluationFile': {
                'type': 'dict',
                'required': False,
                'schema': {
                    'name': {
                        'type': 'string'
                    },
                    'url': {
                        'type': 'string'
                    },
                }
            },
            'historyDescription': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'problemDescription': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'initiativesDescription': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'programLocations': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'researchAndEvaluation': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
        },
    },
    'operationalInformation': {
        'type': 'dict',
        'required': True,
        'empty': False,
        'schema': {
            'staff': {
                'type': 'dict',
                'schema': {
                    'fullTime': {
                        'type': type_number,
                        'required': True,
                        'empty': False,
                        'coerce': to_number,
                    },
                    'partTime': {
                        'type': type_number,
                        'required': True,
                        'empty': False,
                        'coerce': to_number,
                    },
                    'volunteers': {
                        'type': type_number,
                        'required': True,
                        'empty': False,
                        'coerce': to_number,
                    },
                }
            },
            'financialStatement': {
                'type': 'dict',
                'required': True,
                'empty': False,
                'schema': {
                    'website': {
                        'type': 'string'
                    },
                    'file': {
                        'type': 'dict',
                        'schema': {
                            'name': {
                                'type': 'string'
                            },
                            'url': {
                                'type': 'string'
                            },
                        }
                    },
                }
            },
            'partnershipsDescription': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'yearlyBudget': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'supportersAndPartners': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
        },
    },
    'review':{
        'type': 'dict',
        'required': True,
        'empty': False,
        'schema': {
            'email': {
                'type': 'string',
                'required': True,
                'empty': False,
            },
            'name': {
                'type': 'string',
                'required': True,
                'empty': False,
            }
        }
    },
    'notes': {
        'type': 'string',
        'required': False,
    },
    'videoFallback': {
        'type': 'string',
        'regex': REGEX_VALID_URL,
        'empty': True,

    },
    'vimeoId': {
        'type': 'string',
        'required': False,
    },
    'description': {
        'required': True,
        'empty': False,
        'type': 'string'
    },
    'descriptionShort': {
        'type': 'string'
    },
    'isValid': {
        'type': 'boolean',
        'coerce': to_bool,
        'required': True,
        'empty': False,
    },
    'deliverableRequirements': {
        'type': 'string',
        'required': False,
    },
    'videoDescription': {
        'type': 'string',
        'required': False,
    },
    'tax_id': {
        'type': 'string',
        'required': False,
    },
    'blacklist': {
        'type': 'dict',
        'schema': {
            'brands': {
                'type': 'list',
                'schema': {
                'type': 'dict',
                    'schema': {
                        '_id': {'type': type_object_id},
                        'name': {'type': 'string'}
                    }
                }
            },
            'industries': {
                'type': 'list',
                'schema': {
                    'type': type_object_id
                }
            }
        }
    },
    'mpa': {
        'type': 'dict',
        'schema': {
            'info': {
                'type': 'dict',
                'schema': {
                    'orgDescription': {
                        'type': 'string',
                    },
                    'name': {
                        'type': 'string',
                    },
                    'title': {
                        'type': 'string',
                    },
                    'email': {
                        'type': 'string',
                    },
                    'phone': {
                        'type': 'string',
                    },
                    'address': {
                        'type': 'string',
                    },
                    'city': {
                        'type': 'string',
                    },
                    'state': {
                        'type': 'string',
                    },
                    'zip': {
                        'type': 'string',
                    },
                },
            },

            'review': {
                'type': 'dict',
                'schema': {
                    'name': {
                        'type': 'string',
                    },
                    'email': {
                        'type': 'string',
                    }
                }
            },

            'status': {
                'type': 'string',
            },
            'effectiveDate': {
                'type': type_datetime,
            },
            'expirationDate': {
                'type': type_datetime,
            },
            'legalNotes': {
                'type': 'string',
            },
            'addendum': {
                'type': 'dict',
                'schema': {
                    'file': {
                        'type': 'string'
                    },
                    'url': {
                        'type': 'string'
                    }
                }
            },
        }
    }
}

"""
version #1 schema for nonprofit before naf released
"""
schema_nonprofit_v1 = {
    '_id': {
        'type': type_object_id
    },
    'applicationFormName' : {
        'type': 'string',
        'required': False,
    },
    'givewithAdmin': {
        'type': type_object_id,
        'required': True,
        'empty': False,
        'coerce': to_object_id
    },
    'createdAt': {
        'type': type_datetime,
        'required': False,
    },
    'lastUpdated': {
        'type': type_datetime,
        'required': False,
    },
    'slug': {
        'type': 'string',
        'required': True,
        'empty': False,
    },
    'name': {
        'type': 'string',
        'required': True,
        'empty': False,
    },
    'general':{
        'type': 'dict',
        'required': True,
        'schema': {
            'name' :{
                'type': 'dict',
                'schema': {
                    'legalOrganizationName': {
                        'type': 'string',
                        'required': False,
                    },
                    'publicOrganizationName': {
                        'type': 'string',
                        'required': False,
                    }
                }
            },
            'social' :{
                'type': 'dict',
                'required': True,
                'empty': False,
                'schema': {
                    'facebook': {
                        'type': 'string',
                        'required': False,
                    },
                    'instagram': {
                        'type': 'string',
                        'required': False,
                    },
                    'linkedIn': {
                        'type': 'string',
                        'required': False,
                    },
                    'twitter': {
                        'type': 'string',
                        'required': False,
                    },
                    'websiteURL': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    }
                }
            },
            'contact': {
                'type': 'dict',
                'required': False,
                'schema': {
                    'email': {
                        'type': 'string',
                        'required': False,
                    },
                    'name': {
                        'type': 'string',
                        'required': False,
                    },
                    'phone': {
                        'type': 'string',
                        'required': False,
                    },
                    'professionalTitle': {
                        'type': 'string',
                        'required': False,
                    },
                }
            },
            'location': {
                'type': 'dict',
                'required': True,
                'empty': False,
                'schema': {
                    'generalLocation': {
                        'type': 'string',
                        'required': True,
                        'empty': False,
                    },
                    'specificLocation': {
                        'type': 'string',
                        'required': False,
                    },
                    'charityNumber': {
                        'type': 'string',
                        'required': False,
                    },
                    'otherId': {
                        'type': 'string',
                        'required': False,
                    },
                    'w9': {
                        'type': 'dict',
                        'required': False,
                        'schema': {
                            'name': {
                                'type': 'string',
                                'required': False,
                            },
                            'url': {
                                'type': 'string',
                                'required': False,
                            }
                        }
                    },
                    'taxId': {
                        'type': 'string',
                        'required': False,
                    },
                }
            },
            'missionAgreement': {
                'type': 'boolean',
                'required': False,
            }
        },
    },
    'overviewAndMission': {
        'type': 'dict',
        'required': True,
        'empty': False,
        'schema': {
            'causeAreas': {
                'type': 'dict',
                'required': False,
                'schema': {
                    'selected': {
                        'type': 'list',
                        'schema': {
                            'type': 'string'
                        }
                    },
                }
            },
            'lifetimeOutputs': {
                'type': 'list',
                'required': True,
                'empty': False,
                'schema': {
                    'type': 'dict',
                    'schema': {
                        'key': {
                            'type': 'string'
                        },
                        'output': {
                            'type': 'string'
                        },
                        'quantity': {
                            'type': type_number,
                            'coerce': to_number_or_string,
                        },
                    }
                }
            },
            'researchAndEvaluationFile': {
                'type': 'dict',
                'required': False,
                'schema': {
                    'name': {
                        'type': 'string'
                    },
                    'url': {
                        'type': 'string'
                    },
                }
            },
            'historyDescription': {
                'type': 'string',
                'required': False,
            },
            'problemDescription': {
                'type': 'string',
                'required': False,
            },
            'initiativesDescription': {
                'type': 'string',
                'required': False,
            },
            'programLocations': {
                'type': 'string',
                'required': False,
            },
            'researchAndEvaluation': {
                'type': 'string',
                'required': False,
            },
        },
    },
    'operationalInformation': {
        'type': 'dict',
        'required': False,
        'schema': {
            'staff': {
                'type': 'dict',
                'schema': {
                    'fullTime': {
                        'type': type_number,
                        'required': True,
                        'empty': False,
                        'coerce': to_number,
                    },
                    'partTime': {
                        'type': type_number,
                        'required': True,
                        'empty': False,
                        'coerce': to_number,
                    },
                    'volunteers': {
                        'type': type_number,
                        'required': True,
                        'empty': False,
                        'coerce': to_number,
                    },
                }
            },
            'financialStatement': {
                'type': 'dict',
                'required': False,
                'schema': {
                    'website': {
                        'type': 'string'
                    },
                    'file': {
                        'type': 'dict',
                        'schema': {
                            'name': {
                                'type': 'string'
                            },
                            'url': {
                                'type': 'string'
                            },
                        }
                    },
                }
            },
            'partnershipsDescription': {
                'type': 'string',
                'required': False,
            },
            'yearlyBudget': {
                'type': 'string',
                'required': False,
            },
            'supportersAndPartners': {
                'type': 'string',
                'required': False,
            },
        },
    },
    'review':{
        'type': 'dict',
        'required': False,
        'schema': {
            'email': {
                'type': 'string',
                'required': False,
            },
            'name': {
                'type': 'string',
                'required': False,
            }
        }
    },
    'notes': {
        'type': 'string',
        'required': False,
    },
    'videoFallback': {
        'type': 'string',
        'regex': REGEX_VALID_URL,
        'empty': True,
    },
    'vimeoId': {
        'type': 'string',
        'required': False,
    },
    'description': {
        'required': True,
        'empty': False,
        'type': 'string'
    },
    'descriptionShort': {
        'type': 'string'
    },
    'isValid': {
        'type': 'boolean',
        'coerce': to_bool,
        'required': False,
    },
    'deliverableRequirements': {
        'type': 'string',
        'required': False,
    },
    'videoDescription': {
        'type': 'string',
        'required': False,
    },
    'tax_id': {
        'type': 'string',
        'required': False,
    },
    'blacklist': {
        'type': 'dict',
        'schema': {
            'brands': {
                'type': 'list',
                'schema': {
                'type': 'dict',
                    'schema': {
                        '_id': {'type': type_object_id},
                        'name': {'type': 'string'}
                    }
                }
            },
            'industries': {
                'type': 'list',
                'schema': {
                    'type': type_object_id
                }
            }
        }
    },
    'mpa': {
        'type': 'dict',
        'schema': {
            'info': {
                'type': 'dict',
                'schema': {
                    'orgDescription': {
                        'type': 'string',
                    },
                    'name': {
                        'type': 'string',
                    },
                    'title': {
                        'type': 'string',
                    },
                    'email': {
                        'type': 'string',
                    },
                    'phone': {
                        'type': 'string',
                    },
                    'address': {
                        'type': 'string',
                    },
                    'city': {
                        'type': 'string',
                    },
                    'state': {
                        'type': 'string',
                    },
                    'zip': {
                        'type': 'string',
                    },
                },
            },

            'review': {
                'type': 'dict',
                'schema': {
                    'name': {
                        'type': 'string',
                    },
                    'email': {
                        'type': 'string',
                    }
                }
            },

            'status': {
                'type': 'string',
            },
            'effectiveDate': {
                'type': type_datetime,
            },
            'expirationDate': {
                'type': type_datetime,
            },
            'legalNotes': {
                'type': 'string',
            },
            'addendum': {
                'type': 'dict',
                'schema': {
                    'file': {
                        'type': 'string'
                    },
                    'url': {
                        'type': 'string'
                    }
                }
            },
        }
    }
}

schema_program_csv = {
    'name': {'required': True, 'empty': False, 'type': 'string'},
    'nonprofit': {'type': type_object_id},
    'causes': {'type': 'list', 'schema': {'type': type_object_id}},
    'interventions': {'type': 'list', 'schema': {'type': type_object_id}},
    'description': {'type': 'string' },
    'descriptionLong': {'type': 'string'},
    'effectivenessRating': {'type': type_number, 'coerce': to_number, 'min': 0, 'max': 100},
    'forestProtection': {'type': 'boolean', 'default': False, 'coerce': to_bool},
    'animalHabitat': {'type': type_object_id},
    'budget': {'type': type_number, 'coerce': to_number},
    'additionalValueFields': {'type': 'dict', 'schema': {
        'volunteerValueFields': {'type': 'dict', 'schema': {
            'hours': {'type': type_number, 'coerce': to_number, 'min': 0}
        }},
        'savingsBeneficiary': {'type': type_number, 'coerce': to_number, 'min': 0},
        'savingsSociety': {'type': type_number, 'coerce': to_number, 'min': 0},
        'contributionsCash': {'type': type_number, 'coerce': to_number, 'min': 0},
        'contributionsInKind': {'type': type_number, 'coerce': to_number, 'min': 0},
    }},
    'outputs': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'order': {'type': type_number, 'coerce': to_number},
        'label': {'type': 'string'},
        'scaleType': {'type': type_object_id},
        'cost': {'type': type_number, 'coerce': to_number},
        'quantity': {'type': type_number, 'coerce': to_number},
        'valueFifty': {'type': type_number, 'coerce': to_number},
        'valueOneHundred': {'type': type_number, 'coerce': to_number},
        'valueTwoHundredFifty': {'type': type_number, 'coerce': to_number},
        'valueFiveHundred': {'type': type_number, 'coerce': to_number},
    }}},
    'dataMeasurementType': {'type': type_object_id},
    'primaryImpact': {'type': type_object_id},
    'audienceAge': {'type': 'list', 'schema': {'type': type_object_id}},
    'audienceGender': {'type': 'list', 'schema': {'type': type_object_id}},
    'audienceAttribute': {'type': 'list', 'schema': {'type': type_object_id}},
    'secondaryImpacts': {'type': 'list', 'schema': {'type': type_object_id}},
    'primaryOutcomeEffectiveness': {'type': type_object_id},
    'programActivityEffectiveness': {'type': type_object_id},
    'programApproach': {'type': 'list', 'schema': {'type': type_object_id}},
    'isOngoingProgram': {'type': 'boolean', 'coerce': to_bool},
    'programDensity': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    'oneOrMorePartnerOrganizations': {'type': 'boolean', 'coerce': to_bool},
}


schema_program = {
    '_id': {'type': type_object_id},
    'slug': {'type': 'string'},
    'name': {'required': True, 'empty': False, 'type': 'string', 'maxlength': 100},
    'nonprofit': {'required': True, 'type': type_object_id},
    'causes': {'required': True, 'empty': False, 'type': 'list', 'schema': {'type': type_object_id}},
    'themes': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id}},
    }},
    'interventions': {'type': 'list', 'schema': {'type': type_object_id}},
    'screenOneScore': {'type': 'integer', 'default': 0, 'min': 0, 'max': 100},
    'ignoreThreshold': {'type': 'boolean', 'default': False, 'coerce': to_bool},
    'description': {'required': True, 'empty': False, 'type': 'string' },
    'effectivenessRating': {'type': type_number, 'coerce': to_number, 'min': 0, 'max': 100},  # 'required': True,
    'budget': {'required': True, 'empty': False, 'type': type_number, 'coerce': to_number},
    'additionalValueFields': {'required': True, 'type': 'dict', 'schema': {
        'volunteerValueFields': {'type': 'dict', 'schema': {
            'hours': {'required': True, 'empty': False, 'type': type_number, 'coerce': to_number, 'min': 0}
        }},
        'savingsBeneficiary': {'required': True, 'empty': False, 'type': type_number, 'coerce': to_number, 'min': 0},
        'savingsSociety': {'required': True, 'empty': False, 'type': type_number, 'coerce': to_number, 'min': 0},
        'contributionsCash': {'required': True, 'empty': False, 'type': type_number, 'coerce': to_number, 'min': 0},
        'contributionsInKind': {'required': True, 'empty': False, 'type': type_number, 'coerce': to_number, 'min': 0},
    }},
    'funded': {'type': 'string'},
    'fundedBrandRef': {'type': 'string'},
    'forestProtection': {'type': 'boolean', 'default': False, 'coerce': to_bool},
    'animalHabitat': {'type': type_object_id},
    'imageLandscape': {'required': True, 'type': 'string', 'regex': REGEX_VALID_URL},
    'imagePortrait': {'required': True, 'type': 'string', 'regex': REGEX_VALID_URL},
    'programNameTitleCase': {'type': 'string'},
    'programNameLowerCase': {'type': 'string'},
    'outputs': {'required': True, 'empty': False, 'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'order': {'type': type_number, 'coerce': to_number},
        'label': {'required': True, 'type': 'string'},
        'scaleType': {'type': type_object_id},
        'cost': {'required': True, 'type': type_number, 'coerce': to_number},
        'quantity': {'required': True, 'type': ['number', 'string'], 'coerce': to_number_or_string},
        'valueFifty': {'type': type_number, 'coerce': to_number},
        'valueOneHundred': {'type': type_number, 'coerce': to_number},
        'valueTwoHundredFifty': {'type': type_number, 'coerce': to_number},
        'valueFiveHundred': {'type': type_number, 'coerce': to_number},
    }}},
    'outputNotes': {'type': 'string'},
    'customOutputs': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'cost': {'type': type_number, 'coerce': to_number},
        'scaleType': {'type': type_object_id},
        'description': {'type': 'string'},
        'quantity': {'type': type_number, 'coerce': to_number},
        'value': {'type': type_number, 'coerce': to_number},
        'valueFifty': {'type': type_number, 'coerce': to_number},
        'valueOneHundred': {'type': type_number, 'coerce': to_number},
        'valueTwoHundredFifty': {'type': type_number, 'coerce': to_number},
        'valueFiveHundred': {'type': type_number, 'coerce': to_number},
        'staticValue': {'type': 'string'},
    }}},
    'primaryImpact': {'required': True, 'type': type_object_id},
    'secondaryImpacts': {'type': 'list', 'schema': {'type': type_object_id}},
    'impactMultiple': {'type': type_number, 'coerce': to_number},
    'impactMultipleVisibility': {'type': 'boolean', 'coerce': to_bool},
    'oneOrMorePartnerOrganizations': {'type': 'boolean', 'coerce': to_bool},
    'sdg': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id}},
    }},
    'gri': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id}},
    }},
    'cdp': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id}},
    }},
    'esg': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'issue': {'type': type_object_id}
        }}}
    }},
    'csrhub': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id}},
    }},
    'themes': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id}}
    }},
    'sasb': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}}
    }},
    'deliverables': {'type': 'dict', 'empty': False, 'schema': {
        'longVideo': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'shortVideo': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'photoGallery': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'investorCommunications': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'pressRelease': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'sustainabilityReporting': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'employeeCommunications': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'programFactSheet': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'socialMediaPosts': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'csrReportHighlight': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'infographic': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'additional': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'all': {'type': 'string', 'regex': REGEX_VALID_URL},
    }},
    'sampleDeliverables': {'type': 'dict', 'empty': False, 'schema': {
        'SocialMediaPosts': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'Infographic': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'PressRelease': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'CSRHighlight': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'ESGReportingGuide': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'InvestorRelations': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'FactSheet': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
    }},
    'minimumFunding': {'type': type_number, 'coerce': to_number, 'required': False},
    'altLicensing': {'type': 'string', 'required': False},
    'audienceAge': {'type': 'list', 'schema': {'type': type_object_id}},
    'audienceGender': {'type': 'list', 'schema': {'type': type_object_id}},
    'audienceAttribute': {'type': 'list', 'schema': {'type': type_object_id}},
    'primaryOutcomeEffectiveness': {'type': type_object_id},
    'dataMeasurementType': {'type': type_object_id},
    'isOngoingProgram': {'type': 'boolean', 'coerce': to_bool},
    'programDensity': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    'programActivityEffectiveness': {'type': type_object_id},
    'programApproach': {'type': 'list', 'schema': {'type': type_object_id}},
    'notes': {'type': 'string'},
    'active': {'type': 'boolean', 'default': False, 'coerce': to_bool},
    'isValid': {'type': 'boolean', 'coerce': to_bool},
    'isValidNonprofit': {'type': 'boolean', 'coerce': to_bool},
    'createdAt': {'type': type_datetime},
    'lastUpdated': {'type': type_datetime},
    'locations': schema_locations,
    'watermarkToggle': {'type': 'boolean'},
}

schema_program_v2 = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'slug': {'type': 'string'},
    'givewithAdmin': {'type': type_object_id, 'empty': False, 'coerce': to_object_id},
    'name': {'type': 'string', 'required': True, 'empty': False, 'maxlength': 100},
    'notes': {'type': 'string'},
    'submissionFormId': {'type': type_object_id, 'coerce': to_object_id},
    'nonprofit': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'currency': {'type': 'string', 'empty': False, 'allowed': allowed_currency_types},
    'version': {'type': type_number, 'coerce': to_number},
    'active': {'type': 'boolean', 'coerce': to_bool},
    'ignoreThreshold': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    'minimumFunding': {'type': type_number, 'coerce': to_number_without_commas},
    'impactMultiple': {'type': type_number, 'coerce': to_number},
    'impactMultipleVisibility': {'type': 'boolean', 'coerce': to_bool},
    'imageLandscape': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_URL},
    'imagePortrait': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_URL},
    'previewImage': {'type': 'string', 'regex': REGEX_VALID_URL},
    'vimeoID': {'type': 'string'},
    'isValid': {'type': 'boolean', 'coerce': to_bool},
    'isValidNonprofit': {'type': 'boolean', 'coerce': to_bool},
    'deliverables': {'type': 'dict', 'empty': False, 'schema': {
        'longVideo': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'shortVideo': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'photoGallery': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'investorCommunications': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'pressRelease': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'sustainabilityReporting': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'employeeCommunications': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'programFactSheet': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'socialMediaPosts': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'csrReportHighlight': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'infographic': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'additional': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'all': {'type': 'string', 'regex': REGEX_VALID_URL},
    }},
    'sampleDeliverables': {'type': 'dict', 'empty': False, 'schema': {
        'SocialMediaPosts': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'Infographic': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'PressRelease': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'CSRHighlight': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'ESGReportingGuide': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'InvestorRelations': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
        'FactSheet': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_URL},
    }},
    'altLicensing': {'type': 'string'},
    'description': {'type': 'string', 'required': True, 'empty': False},
    'causes': {'type': 'list', 'schema': {
        'type': type_object_id, 'coerce': to_object_id
    }},
    'audienceAge': {'type': 'list', 'schema': {
        'type': type_object_id, 'coerce': to_object_id_or_str
    }},
    'audienceAttribute': {'type': 'list', 'required': True, 'empty': False, 'schema': {
        'type': type_object_id, 'coerce': to_object_id_or_str
    }},
    'primaryImpact': {'type': 'list', 'schema': {
        'type': type_object_id, 'coerce': to_object_id
    }},
    'secondaryImpacts': {'type': 'list', 'required': True, 'empty': False, 'schema': {
        'type': type_object_id, 'coerce': to_object_id_or_str
    }},
    'programApproach': {'type': 'list', 'required': True, 'empty': False, 'schema': {
        'type': type_object_id, 'coerce': to_object_id_or_str
    }},
    'dataMeasurementType': {'type': type_object_id, 'coerce': to_object_id},
    'dataDescription': {'type': 'list', 'schema': {
        'type': type_object_id, 'coerce': to_object_id_or_str
    }},
    'approach': {'type': 'list', 'schema':  {'type': 'dict', 'schema': {
         '_id': {'type': type_object_id, 'coerce': to_object_id},
        'evidenceScore': {'type': type_number},
        'conversionRateId': {'type': type_object_id, 'coerce': to_object_id},
        'echoOutput': {'type': type_number, 'coerce': to_integer},
    }}},
    'participants': {'type': type_number, 'coerce': to_integer},
    'evidenceDescription': {'type': 'list', 'required': True, 'empty': False, 'schema': {
        'type': type_object_id, 'coerce': to_object_id_or_str
    }},
    'programNameTitleCase': {'type': 'string'},
    'programNameLowerCase': {'type': 'string'},
    'outputs': {'type': 'list', 'required': True, 'empty': False, 'schema': {'type': 'dict', 'schema': {
        'quantity': {'required': True, 'type': ['number', 'string'], 'coerce': to_number_or_string},
        'description': {'type': 'string', 'required': True},
        'scaleType': {'type': type_object_id, 'coerce': to_object_id},
        'verb': {'type': 'string'},
        'targetPlural': {'type': 'string'},
        'targetSingular': {'type': 'string'}
    }}},
    'outcomes': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'quantity': {'type': ['number', 'string'], 'required': True, 'coerce': to_number_or_string},
        'description': {'type': 'string', 'required': True},
    }}},
    'approachDuration': {'type': type_object_id, 'coerce': to_object_id},
    'nonprofitPartners': {'type': 'boolean', 'required': True, 'empty': False, 'coerce': to_bool},
    'budget': {'type': type_number, 'required': True, 'empty': False, 'coerce': to_number_without_commas},
    'cashContributions': {'type': type_number, 'coerce': to_number_without_commas},
    'inKindContributions': {'type': type_number, 'coerce': to_number_without_commas},
    'General': {'type': 'dict', 'schema': {
        'contact': {'type': 'dict', 'schema': {
            'name': {'type': 'string'},
            'email': {'type': 'string'},
            'phone': {'type': 'string'}
        }},
        'name': {'type': 'dict', 'schema': {
            'internalProgramName': {'type': 'string'}
        }},
        'description': {'type': 'dict', 'schema': {
            'optional': {'type': 'string'},
        }}
    }},
    'ImpactAndScope': {'type': 'dict', 'schema': {
        'protectAndEnhanceForest': {'type': 'dict', 'schema': {
            'value': {'type': 'boolean', 'coerce': to_bool},
        }},
        'animalHabitat': {'type': 'dict', 'schema': {
            'value': {'type': type_object_id, 'coerce': to_object_id},
        }},
        'targetAttributes': {'type': 'dict', 'schema': {
            'optional': {'type': 'string'}
        }},
        'regions': {'type': 'dict', 'schema': {
            'value': {'type': type_multiselect, 'anyof_schema': schema_multiselect()},
        }},
        'countries': {'type': 'dict', 'schema': {
            'value': {'type': type_multiselect, 'anyof_schema': schema_multiselect()},
        }},
        'states': {'type': 'dict', 'schema': {
            'value': {'type': type_multiselect, 'anyof_schema': schema_multiselect()},
        }},
        'cities': {'type': 'dict', 'schema': {
            'value': {'type': type_multiselect, 'anyof_schema': schema_multiselect()},
        }},
        'additionalLocationDetails': {'type': 'dict', 'schema': {
            'value': {'type': 'string'}
        }}
    }},
    'StrategiesAndApproaches': {'type': 'dict', 'schema': {
        'activities': {'type': 'dict', 'schema': {'value': {'type': 'string'}}},
        'activitiesFrequency': {'type': 'dict', 'schema': {
            'value': {'type': 'string'}
        }},
        'outputs': {'type': 'dict', 'schema': {
            'optional': {'type': 'string'}
        }},
        'outcomes': {'type': 'dict', 'schema': {
            'optional': {'type': 'string'}
        }},
        'resultsMeasurement': {'type': 'dict', 'schema': {
            'optional': {'type': 'string'}
        }},
    }},
    'ResearchAndEvaluation': {'type': 'dict', 'schema': {
        'researchFile': {'type': 'dict', 'schema': {
            'value': {'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_URL},
            }}
        }},
        'studyDescription': {'type': 'dict', 'schema': {
            'value': {
                'type': 'dict', 'schema': {
                    'selected': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id_or_str}},
                    'other': {'type': 'dict', 'schema': {'value': {'type': 'string'}}}
                }
            }
        }},
        'evidenceDescription': {'type': 'dict', 'schema': {
            'value': {'type': 'dict', 'schema': {'other': {'type': 'dict', 'schema': {'value': {'type': 'string'}}}}}
        }},
        'dataDescription': {'type': 'dict', 'schema': {
            'value': {'type': 'dict', 'schema': {'other': {'type': 'dict', 'schema': {'value': {'type': 'string'}}}}}
        }},
        'outcomeDescription': {'type': 'dict', 'schema': {
            'value': {
                'type': 'dict', 'schema': {
                    'selected': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id_or_str}},
                    'other': {'type': 'dict', 'schema': {'value': {'type': 'string'}}}
                }
            }
        }},
        'strength': {'type': 'dict', 'schema': {
            'value': {
                'type': 'dict', 'schema': {
                    'selected': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id_or_str}},
                }
            }
        }},
    }},
    'Finance': {'type': 'dict', 'schema': {
        'budgetFile': {'type': 'dict', 'schema': {
            'value': {'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_URL},
            }}
        }},
    }},
    'Content': {'type': 'dict', 'schema': {
        'filmLocation': {'type': 'dict', 'schema': {'value': {'type': 'string'}}},
        'assets': {'type': 'dict', 'schema': {
            'value': {'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_URL},
            }}
        }},
    }},
    'sdg': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
    }},
    'gri': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
    }},
    'cdp': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
    }},
    'esg': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'issue': {'type': type_object_id, 'coerce': to_object_id}
        }}}
    }},
    'csrhub': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
    }},
    'themes': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}}
    }},
    'sasb': {'type': 'dict', 'schema': {
        'isCustom': {'type': 'boolean', 'required': True, 'default': False, 'coerce': to_bool},
        'data': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}}
    }},
    'createdAt': {'type': type_datetime},
    'lastUpdated': {'type': type_datetime},
    'watermarkToggle': {'type': 'boolean'},
}

msci_csv_columns = (
    'msciId',
    'name',
    'industryName',
    'carbonEmissions_weight',
    'climateChangeVulnerability_weight',
    'humanCapitalDevelopment_weight',
    'responsibleInvestment_weight',
    'accessToCommunications_weight',
    'accessToFinance_weight')

schema_msci_csv = {
    'msciId': {'type': 'string', 'required': True, 'empty': False},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'industryName': {'type': 'string', 'required': True, 'empty': False},
    'carbonEmissions_weight': {'type': 'float', 'required': True, 'empty': False},
    'climateChangeVulnerability_weight': {'type': 'float', 'required': True, 'empty': False},
    'humanCapitalDevelopment_weight': {'type': 'float', 'required': True, 'empty': False},
    'responsibleInvestment_weight': {'type': 'float', 'required': True, 'empty': False},
    'accessToCommunications_weight': {'type': 'float', 'required': True, 'empty': False},
    'accessToFinance_weight': {'type': 'float', 'required': True, 'empty': False}
}

schema_recommendation = {
    'program': {'type': 'string'},
    'score': {'type': 'float'}
}

schema_brand_ui = {
    '_id': {'type': type_object_id},
    'slug': {'type': 'string'},
    'subdomain': {'type': 'string'},
    'source': {'type': 'string'},
    'name': {'type': 'string', 'required': True, 'empty': False, },
    'nameLabel': {'type': 'string'},
    'allowedProposalTypes': {'type': 'list', 'schema': {'type': 'string', 'allowed': allowed_proposal_access_types}},
    'paymentType': {'type': 'string', 'required': False},
    'splitGiveAmount': {'type': 'boolean'},
    'hasAnalysis': {'type': 'boolean', 'default': False, 'coerce': to_bool},
    'industry': {'type': 'string', 'required': True, 'empty': False},
    'notes': {'type': 'string'},
    'awards': {
        'type': 'list',
        'schema': {
            'type': 'dict',
            'schema': {
                'award_id': {
                    'type': type_object_id,
                    'coerce': to_object_id
                },
                'year': {
                    'type': 'list',
                    'schema': {
                        'type': 'integer', 'coerce': to_integer
                    }
                }
            }
        }
    },
    'ISIN': {'type': 'string'},
    'sdg': {'type': 'list', 'schema': {'type': type_object_id}},
    'gri': {'type': 'list', 'schema': {'type': type_object_id}},
    'cdp': {'type': 'list', 'schema': {'type': type_object_id}},
    'impacts': {'type': 'list', 'schema': {'type': type_object_id}},
    'sasbVisibility': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    'tvlVisibility': {'type': 'dict', 'schema': {
        'accessAndAffordability': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'businessEthicsAndTransparencyOfPayments': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'humanRightsAndCommunityRelations': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'biodiversityImpacts': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'gHGEmissions': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    }},
    'sasb': {'type': 'dict', 'schema': {
        'sector': {'type': 'string'},
        'industry': {'type': 'string'},
        'industry_code': {'type': 'string'},
        'disclosure_topics': {'type': 'list', 'schema': {'type': 'string'}},
        'sustainability_dimensions': {'type': 'list', 'schema': {'type': 'string'}},
        'categories': {'type': 'dict', 'schema': {
            'all_labels': {'type': 'list', 'schema': {'type': 'string'}},
            'tagged': {'type': 'dict', 'schema': {
                'ids': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
                'labels': {'type': 'list', 'schema': {'type': 'string'}},
            }}
        }},
    }},
    'researchCorpCommitments': {'type': 'dict', 'required': False, 'schema': {
        'brandName': {'type': 'string'},
        'researchId': {'type': 'integer', 'coerce': to_integer},
        'noData': {'type': 'boolean', 'coerce': to_bool},
        'researchProgramSummary': {'type': 'string'},
        'impactSummary': {'type': 'list', 'schema': {'type': 'string'}},
        'sources': {'type': 'list', 'schema': {'type': 'string'}},
        'sourceYears': {'type': 'list', 'schema': {'type': 'string'}},
        'sdgs': {'type': 'list', 'schema': {'type': 'string'}},
        'sdgLabels': {'type': 'list', 'schema': {'type': 'string'}},
        'nonprofits': {'type': 'dict', 'schema': {
            'preferred': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
            'nonGwPreferred': {'type': 'list', 'schema': {'type': 'string'}}
        }},
        'locationSummary': {'type': 'dict', 'schema': {
            'continents': {'type': 'list', 'schema': {'type': 'string'}},
            'countries': {'type': 'list', 'schema': {'type': 'string'}},
            'states': {'type': 'list', 'schema': {'type': 'string'}},
            'cities': {'type': 'list', 'schema': {'type': 'string'}},
            'otherCities': {'type': 'list', 'schema': {'type': 'string'}},
        }},
        'themes': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'theme': {'type': 'string'},
            'themeVisibility': {'type': 'boolean', 'coerce': to_bool},
            'researchThemeExternal': {'type': 'string'},
            'narrative': {'type': 'string'},
            'impacts' : {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
            'researchThemeNotes': {'type': 'string'},
            'themeRelevance': {'type': 'integer', 'coerce': to_integer},
            'themePrograms': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
                'goalName': {'type': 'string'},
                'researchProgramDescription': {'type': 'string'},
                'relevancies': {'type': 'list', 'schema': {'type': 'string'}},
                'investmentTypes': {'type': 'list', 'schema': {'type': 'string'}},
                'partnershipTypes': {'type': 'list', 'schema': {'type': 'string'}},
                'partnershipDurations': {'type': 'list', 'schema': {'type': 'string'}},
                'initiativeStrategies': {'type': 'list', 'schema': {'type': 'string'}},
                'programImpacts': {'type': 'list', 'schema': {'type': 'string'}},
                'taxIds': {'type': 'list', 'schema': {'type': 'string'}},
                'otherTaxIds': {'type': 'list', 'schema': {'type': 'string'}},
                'nonprofitNames': {'type': 'list', 'schema': {'type': 'string'}},
                'otherNonprofitNames': {'type': 'list', 'schema': {'type': 'string'}},
                'location': schema_location,
                'reviewed': {'type': 'boolean', 'coerce': to_bool},
            }}}
        }}}
    }},
    'insights': {
        'type': 'dict',
        'schema': {
            'msci': {
                'type': 'list',
                'schema': {
                    'type': 'dict',
                    'schema': {
                        'description': {'type': 'string'},
                        'issue': {'type': 'string'},
                        'title': {'type': 'string'},
                        'quartile': {'type': 'float', 'coerce': to_number},
                        'score': {'type': 'float', 'coerce': to_number},
                        'weight': {'type': 'float', 'coerce': to_number},
                        'visible': {'type': 'boolean', 'coerce': to_bool}
                    }
                }
            },
            'themes': {
                'type': 'list',
                'schema': {
                    'type': 'dict',
                    'schema': {
                        'theme': {'type': 'string'},
                        'customRelevancy': {'type': 'integer', 'coerce': to_integer},
                        'relevancy': {'type': 'integer', 'coerce': to_integer},
                        'description': {'type': 'string'},
                        'visible': {'type': 'boolean', 'coerce': to_bool}
                    }
                }
            },
            'customThemes': {
                'type': 'list',
                'schema': {
                    'type': 'dict',
                    'schema': {
                        'theme': {'type': 'string'},
                        'customRelevancy': {'type': 'integer', 'coerce': to_integer},
                        'relevancy': {'type': 'integer', 'coerce': to_integer, 'required': True},
                        'impacts': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
                        'description': {'type': 'string'},
                        'visible': {'type': 'boolean', 'coerce': to_bool}
                    }
                }
            },
            'csrhub': {
                'type': 'list',
                'schema': {
                    'type': 'dict',
                    'schema': {
                        'key': {'type': 'string', 'required': True},
                        'label': {'type': 'string'},
                        'percentileRank': {'type': type_number, 'coerce': to_number},
                        'visible': {'type': 'boolean', 'coerce': to_bool},
                        'description': {'type': 'string'}
                    }
                }
            }
        }
    },
    'nonprofits': {
        'type': 'dict',
        'schema': {
            'preferred': {'type': 'list', 'schema': {'type': type_object_id}},
            'blacklist': {'type': 'list', 'schema': {'type': type_object_id}},
            'non_gw_preferred': {'type': 'string'}
        }
    },
    'isValid': {'type': 'boolean', 'coerce': to_bool},
    'isValidNonprofit': {'type': 'boolean', 'coerce': to_bool},
    'isValidProgram': {'type': 'boolean', 'coerce': to_bool},
    'createdAt': {'type': type_datetime},
    'lastUpdated': {'nullable': True, 'type': type_datetime},
    'lastUpdatedBy': {'type': 'dict', 'schema': {
        '_id': {'type': type_object_id},
        'name': {'type': 'string'},
        'username': {'type': 'string'}
    }},
    'nielsen_company': {'type': 'string', 'required': False, 'empty': False},
    'nielsen_industry': {'type': 'string', 'required': False, 'empty': False},
    'nielsen_selected_themes': {'type': 'list', 'required': False, 'empty': True, 'schema': {'type': 'string'}},
    'locations': schema_locations,
    'nielsenDemographics': {'type': 'list', 'required': False,  'schema': {
        'type': 'dict',
        'schema': {
            'description': {'type': 'string'},
            'age': {'type': 'list', 'schema': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}}},
            'employment_status': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'household_income': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'household_size_index': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'age_presence_of_children_index': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'race_ethnicity_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'nielsen_county_size_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'census_division_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'spectra_lifestyle_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'spectra_behavior_stage_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'gender': {'type': 'list', 'schema': {'type': 'string'}},
            'visibility': {'type': 'boolean','required': False, 'coerce': to_bool},
            'selected_themes': {'type': 'list', 'required': False, 'empty': True, 'schema': {'type': 'dict', 'schema': { 'valueId': {'type': 'string'},
            'valuePercentage': {'type': 'float', 'coerce': to_number}}}}
        }
    }},
    'verifiedByAdmin': {'type': 'boolean', 'required': False, 'coerce': to_bool},
    'child_brands': {'type': 'list', 'schema': {'type': 'string'}},
    'parent_brands': {'type': 'list', 'schema': {'type': 'string'}},
    'preferredPrograms': {'type': 'dict', 'schema' : {
        'password': {'type': 'string'},
        'editing': {'type': 'boolean', 'required': True, 'empty': False },
        'cart': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id }},
        'selected': {'type': 'list', 'schema': { 'type': type_object_id, 'coerce': to_object_id }},
        'additional': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id }}
    }},
    'topics': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'topic': {'type': type_object_id, 'required': True, 'coerce': to_object_id},
        'score': {'type': type_number, 'coerce': to_number},
        'label': {'type': 'string'}
    }}},
    'givePercentageType': {'type': 'string', 'allowed': ['default', 'custom', 'graduated']},
    'givePercentageCurrency': {'type': 'string', 'allowed': allowed_currency_types},
    'customGivePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    'graduatedGivePercentages': {'type': 'list', 'schema':
        {'type': 'dict', 'schema': {
            'from': {'type': type_number, 'coerce': to_number},
            'to': {'type': type_number, 'coerce': to_number, 'empty': True},
            'givePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    }}},
    'paymentOption': {'type': 'string', 'allowed': allowed_payment_methods},
    'prePaidAmount': {'type': type_number, 'coerce': to_number},
    'givewithFeePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    'isPilot': {'type': 'boolean'},
    'featureFlags': {'type': 'dict', 'schema': {
        'editableDeals': {'type': 'boolean', 'coerce': to_bool},
        'rbac': {'type': 'boolean', 'coerce': to_bool},
    }},
    'customWrittenSummary': {'type': type_file, 'schema': schema_file()},
    'customCopy': {'type': 'dict', 'schema': {
        'buyerLandingPage': {'type': 'string'},
        'supplierProposalPage': {'type': 'string'}
    }},
    'proposalOptions': {'type': 'dict', 'schema': {
        'type': {'type': 'dict', 'schema': {
            'label': {'type': 'string'},
            'options': {'type': 'list', 'schema': {'type': 'string'}},
        }},
        'category': {'type': 'dict', 'schema': {
            'label': {'type': 'string'},
            'options': {'type': 'list', 'schema': {'type': 'string'}},
        }},
        'department': {'type': 'dict', 'schema': {
            'label': {'type': 'string'},
            'options': {'type': 'list', 'schema': {'type': 'string'}},
        }},
    }},
    'selectedUserRoutes': {'type': 'list', 'schema': {'type': 'string'}},
    'dealConfig': {'type': 'dict', 'schema': {
        'create': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'fieldKey': {'type': 'string' },
            'required': {'type': 'boolean', 'coerce': to_bool},
            'label': {'type': 'string' },
            'path': {'type': 'string' },
            'type': {'type': 'string' },
            'options': {'type': 'list', 'schema': { 'type': 'string'}},
        }}},
        'general': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'fieldKey': {'type': 'string' },
            'required': {'type': 'boolean', 'coerce': to_bool},
            'label': {'type': 'string' },
            'path': {'type': 'string' },
            'type': {'type': 'string' },
            'options': {'type': 'list', 'schema': { 'type': 'string'}},
        }}},
        'funding': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'fieldKey': {'type': 'string' },
            'required': {'type': 'boolean', 'coerce': to_bool},
            'label': {'type': 'string' },
            'path': {'type': 'string' },
            'type': {'type': 'string' },
            'options': {'type': 'list', 'schema': { 'type': 'string'}},
        }}},
    }},
    'allowMultipleSelectedPrograms': {'type': 'boolean'},
    'outreachMaterials': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'display': {'type': 'boolean', 'coerce': to_bool},
        'name': {'type': 'string'},
        'description': {'type': 'string'},
        'fileName': {'type': 'string'},
        'url': {'type': 'string'},
        'key': {'type': 'string'},
    }}},
}

schema_brand = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'slug': {'type': 'string'},
    'minimumFunding': {'type': 'integer', 'coerce': to_integer},
    'subdomain': {'type': 'string'},
    'source': {'type': 'string'},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'nameLabel': {'type': 'string'},
    'searchString': {'type': 'string'},
    'iname': {'type': 'string'},
    'ISIN': {'type': 'string'},
    'paymentType': {'type': 'string', 'required': False},
    'allowedProposalTypes': {'type': 'list', 'schema': {'type': 'string', 'allowed': allowed_proposal_access_types}},
    'splitGiveAmount': {'type': 'boolean'},
    'hasAnalysis': {'type': 'boolean', 'default': False, 'coerce': to_bool},
    'industry': {'type': 'string', 'empty': False},
    'notes': {'type': 'string'},
    'customThemesNotes': {'type': 'string'},
    'givewithManager': {'type': type_object_id, 'empty': False, 'coerce': to_object_id},
    'sdg': {'type': 'list', 'schema': {'type': type_object_id}},
    'gri': {'type': 'list', 'schema': {'type': type_object_id}},
    'cdp': {'type': 'list', 'schema': {'type': type_object_id}},
    'impacts': {'type': 'list', 'schema': {'type': type_object_id}},
    'sasbVisibility': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    'awards': {
        'type': 'list',
        'schema': {
            'type': 'dict',
            'schema': {
                'award_id': {
                    'type': type_object_id,
                    'coerce': to_object_id
                },
                'year': {
                    'type': 'list',
                    'schema': {
                        'type': 'integer', 'coerce': to_integer
                    }
                }
            }
        }
    },
    'tvlVisibility': {'type': 'dict', 'schema': {
        'accessAndAffordability': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'businessEthicsAndTransparencyOfPayments': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'humanRightsAndCommunityRelations': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'biodiversityImpacts': {'type': 'boolean', 'default': True, 'coerce': to_bool},
        'gHGEmissions': {'type': 'boolean', 'default': True, 'coerce': to_bool},
    }},
    'sasb': {'type': 'dict', 'schema': {
        'sector': {'type': 'string'},
        'industry': {'type': 'string'},
        'industry_code': {'type': 'string'},
        'disclosure_topics': {'type': 'list', 'schema': {'type': 'string'}},
        'sustainability_dimensions': {'type': 'list', 'schema': {'type': 'string'}},
        'categories': {'type': 'dict', 'schema': {
            'all_labels': {'type': 'list', 'schema': {'type': 'string'}},
            'tagged': {'type': 'dict', 'schema': {
                'ids': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
                'labels': {'type': 'list', 'schema': {'type': 'string'}}
            }}
        }},
    }},
    'msci': {
        'type': 'dict', 'schema': {
            'msciId': {'required': True, 'empty': False, 'type': 'string'},
            'issuerName': {'required': True, 'empty': False, 'type': 'string'},
            'industry': {'required': True, 'empty': False, 'type': 'string'},
            'lastImported': {'type': type_datetime},
            'weights': {'type': 'dict', 'schema': {
                'carbonEmissions': {'type': 'float'},
                'climateChangeVulnerability': {'type': 'float'},
                'humanCapitalDevelopment': {'type': 'float'},
                'responsibleInvestment': {'type': 'float'},
                'accessToCommunications': {'type': 'float'},
                'accessToFinance': {'type': 'float'},
            }},
            'score': {'type': 'dict', 'schema': {
                'carbonEmissions': {'type': 'float'},
                'climateChangeVulnerability': {'type': 'float'},
                'humanCapitalDevelopment': {'type': 'float'},
                'responsibleInvestment': {'type': 'float'},
                'accessToCommunications': {'type': 'float'},
                'accessToFinance': {'type': 'float'},
            }},
            'quartile': {'type': 'dict', 'schema': {
                'carbonEmissions': {'type': 'float'},
                'climateChangeVulnerability': {'type': 'float'},
                'humanCapitalDevelopment': {'type': 'float'},
                'responsibleInvestment': {'type': 'float'},
                'accessToCommunications': {'type': 'float'},
                'accessToFinance': {'type': 'float'},
            }}
        }
    },
    'themes': {
        'type': 'list',
        'empty': True,
        'schema': {
            'type': 'dict',
            'schema': {
                'theme': {'type': 'string'},
                'customRelevancy': {'type': 'integer', 'coerce': to_integer},
                'relevancy': {'type': 'integer', 'coerce': to_integer},
                'description': {'type': 'string'},
                'visible': {'type': 'boolean', 'coerce': to_bool}
            }
        }
    },
    'customThemes': {
        'type': 'list',
        'empty': True,
        'schema': {
            'type': 'dict',
            'schema': {
                'theme': {'type': 'string'},
                'customRelevancy': {'type': 'integer', 'coerce': to_integer},
                'relevancy': {'type': 'integer', 'coerce': to_integer, 'required': True},
                'description': {'type': 'string'},
                'notes': {'type': 'string'},
                'source': {'type': 'string'},
                'impacts': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
                'sourceLink': {'type': 'string', 'regex': REGEX_VALID_URL},
                'visible': {'type': 'boolean', 'coerce': to_bool}
            }
        }
    },
    'researchCorpCommitments': {'type': 'dict', 'required': False, 'schema': {
        'brandName': {'type': 'string'},
        'researchId': {'type': 'integer', 'coerce': to_integer},
        'noData': {'type': 'boolean', 'coerce': to_bool},
        'researchProgramSummary': {'type': 'string'},
        'impactSummary': {'type': 'list', 'schema': {'type': 'string'}},
        'sources': {'type': 'list', 'schema': {'type': 'string'}},
        'sourceYears': {'type': 'list', 'schema': {'type': 'string'}},
        'sdgs': {'type': 'list', 'schema': {'type': 'string'}},
        'sdgLabels': {'type': 'list', 'schema': {'type': 'string'}},
        'nonprofits': {'type': 'dict', 'schema': {
            'preferred': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
            'nonGwPreferred': {'type': 'list', 'schema': {'type': 'string'}}
        }},
        'locationSummary': {'type': 'dict', 'schema': {
            'continents': {'type': 'list', 'schema': {'type': 'string'}},
            'countries': {'type': 'list', 'schema': {'type': 'string'}},
            'states': {'type': 'list', 'schema': {'type': 'string'}},
            'cities': {'type': 'list', 'schema': {'type': 'string'}},
            'otherCities': {'type': 'list', 'schema': {'type': 'string'}},
        }},
        'themes': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'theme': {'type': 'string'},
            'themeVisibility': {'type': 'boolean', 'coerce': to_bool},
            'researchThemeExternal': {'type': 'string'},
            'narrative': {'type': 'string'},
            'impacts' : {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}},
            'researchThemeNotes': {'type': 'string'},
            'themeRelevance': {'type': 'integer', 'coerce': to_integer},
            'themePrograms': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
                'goalName': {'type': 'string'},
                'researchProgramDescription': {'type': 'string'},
                'relevancies': {'type': 'list', 'schema': {'type': 'string'}},
                'investmentTypes': {'type': 'list', 'schema': {'type': 'string'}},
                'partnershipTypes': {'type': 'list', 'schema': {'type': 'string'}},
                'partnershipDurations': {'type': 'list', 'schema': {'type': 'string'}},
                'initiativeStrategies': {'type': 'list', 'schema': {'type': 'string'}},
                'programImpacts': {'type': 'list', 'schema': {'type': 'string'}},
                'taxIds': {'type': 'list', 'schema': {'type': 'string'}},
                'otherTaxIds': {'type': 'list', 'schema': {'type': 'string'}},
                'nonprofitNames': {'type': 'list', 'schema': {'type': 'string'}},
                'otherNonprofitNames': {'type': 'list', 'schema': {'type': 'string'}},
                'location': schema_location,
                'reviewed': {'type': 'boolean', 'coerce': to_bool},
            }}}
        }}}
    }},
    'nonprofits': {
        'type': 'dict',
        'schema': {
            'preferred': {'type': 'list', 'schema': {'type': type_object_id}},
            'blacklist': {'type': 'list', 'schema': {'type': type_object_id}},
            'non_gw_preferred': {'type': 'string'},
            'non_gw_blacklist': {'type': 'string'},
        }
    },
    'isValid': {'type': 'boolean', 'coerce': to_bool},
    'isValidNonprofit': {'type': 'boolean', 'coerce': to_bool},
    'isValidProgram': {'type': 'boolean', 'coerce': to_bool},
    'locations': schema_locations,
    'createdAt': {'type': type_datetime},
    'lastUpdated': {'nullable': True, 'type': type_datetime},
    'lastUpdatedBy': {'type': 'dict', 'schema': {
        '_id': {'type': type_object_id},
        'name': {'type': 'string'},
        'username': {'type': 'string'}
    }},
    'hide_nielsen_customer_research': {'type': 'boolean', 'coerce': to_bool},
    'nielsen_company': {'type': 'string', 'required': False, 'empty': False},
    'nielsen_industry': {'type': 'string', 'required': False, 'empty': False},
    'nielsen_selected_themes': {'type': 'list', 'required': False, 'empty': True, 'schema': {'type': 'string'}},
    'verifiedByAdmin': {'type': type_datetime, 'required': False, 'empty': False},
    'child_brands': {'type': 'list', 'schema': {'type': type_object_id}},
    'parent_brands': {'type': 'list', 'schema': {'type': type_object_id}},
    'givePercentageType': {'type': 'string', 'allowed': ['default', 'custom', 'graduated']},
    'givePercentageCurrency': {'type': 'string', 'allowed': allowed_currency_types},
    'customGivePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    'graduatedGivePercentages': {'type': 'list', 'schema':
        {'type': 'dict', 'schema': {
            'from': {'type': type_number, 'coerce': to_number},
            'to': {'type': type_number, 'coerce': to_number, 'empty': True},
            'givePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    }}},
    'nielsenDemographics': {'type': 'list', 'required': False,  'schema': {
        'type': 'dict',
        'schema': {
            'description': {'type': 'string'},
            'age': {'type': 'list', 'schema': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}}},
            'employment_status': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'household_income': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'hispanic_index': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'household_size_index': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'age_presence_of_children_index': {'type': 'list', 'schema': {'type': ['integer', 'list']}},
            'race_ethnicity_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'nielsen_county_size_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'census_division_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'spectra_lifestyle_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'spectra_behavior_stage_index': {'type': 'list', 'schema': {'type': 'integer', 'coerce': to_integer}},
            'gender': {'type': 'list', 'schema': {'type': 'string'}},
            'visibility': {'type': 'boolean','required': False, 'coerce': to_bool},
            'selected_themes': {'type': 'list', 'required': False, 'empty': True, 'schema': {'type': 'dict',
            'schema': { 'valueId': {'type': 'string'}, 'valuePercentage': {'type': 'float', 'coerce': to_number}}}}
        }
    }},
    'csrhub': {'type': 'dict', 'schema': {
        'communityDevAndPhilanthropy': {'type': 'dict', 'empty': False, 'schema': {
            'visible': {'type': 'boolean', 'coerce': to_bool},
            'description': {'type': 'string'}
        }},
        'humanRightsAndSupplyChain': {'type': 'dict', 'empty': False, 'schema': {
            'visible': {'type': 'boolean', 'coerce': to_bool},
            'description': {'type': 'string'}
        }},
        'diversityAndLaborRights': {'type': 'dict', 'empty': False, 'schema': {
            'visible': {'type': 'boolean', 'coerce': to_bool},
            'description': {'type': 'string'}
        }},
        'energyAndClimateChange': {'type': 'dict', 'empty': False, 'schema': {
            'visible': {'type': 'boolean', 'coerce': to_bool},
            'description': {'type': 'string'}
        }},
        'leadershipEthics': {'type': 'dict', 'empty': False, 'schema': {
            'visible': {'type': 'boolean', 'coerce': to_bool},
            'description': {'type': 'string'}
        }}
    }},
    'preferredPrograms': {'type': 'dict', 'schema' : {
        'password': {'type': 'string'},
        'editing': {'type': 'boolean', 'required': True, 'empty': False },
        'cart': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id }},
        'selected': {'type': 'list', 'schema': { 'type': type_object_id, 'coerce': to_object_id }},
        'additional': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id }}
    }},
    'topics': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'topic': {'type': type_object_id, 'required': True, 'coerce': to_object_id},
        'score': {'type': type_number, 'coerce': to_number},
        'label': {'type': 'string'}
    }}},
    'paymentOption': {'type': 'string', 'allowed': allowed_payment_methods},
    'prePaidAmount': {'type': type_number, 'coerce': to_number},
    'givewithFeePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    'isPilot': {'type': 'boolean'},
    'featureFlags': {'type': 'dict', 'schema': {
        'editableDeals': {'type': 'boolean', 'coerce': to_bool},
        'rbac': {'type': 'boolean', 'coerce': to_bool},
    }},
    'customWrittenSummary': {'type': type_file, 'schema': schema_file()},
    'customCopy': {'type': 'dict', 'schema': {
        'buyerLandingPage': {'type': 'string'},
        'supplierProposalPage': {'type': 'string'}
    }},
    'proposalOptions': {'type': 'dict', 'schema': {
        'type': {'type': 'dict', 'schema': {
            'label': {'type': 'string'},
            'options': {'type': 'list', 'schema': {'type': 'string'}},
        }},
        'category': {'type': 'dict', 'schema': {
            'label': {'type': 'string'},
            'options': {'type': 'list', 'schema': {'type': 'string'}},
        }},
        'department': {'type': 'dict', 'schema': {
            'label': {'type': 'string'},
            'options': {'type': 'list', 'schema': {'type': 'string'}},
        }},
    }},
    'selectedUserRoutes': {'type': 'list', 'schema': {'type': 'string'}},
    'dealConfig': {'type': 'dict', 'schema': {
        'create': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'fieldKey': {'type': 'string' },
            'required': {'type': 'boolean', 'coerce': to_bool},
            'label': {'type': 'string' },
            'path': {'type': 'string' },
            'type': {'type': 'string' },
            'options': {'type': 'list', 'schema': { 'type': 'string'}},
        }}},
        'general': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'fieldKey': {'type': 'string' },
            'required': {'type': 'boolean', 'coerce': to_bool},
            'label': {'type': 'string' },
            'path': {'type': 'string' },
            'type': {'type': 'string' },
            'options': {'type': 'list', 'schema': { 'type': 'string'}},
        }}},
        'funding': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
            'fieldKey': {'type': 'string' },
            'required': {'type': 'boolean', 'coerce': to_bool},
            'label': {'type': 'string' },
            'path': {'type': 'string' },
            'type': {'type': 'string' },
            'options': {'type': 'list', 'schema': { 'type': 'string'}},
        }}},
    }},
    'allowMultipleSelectedPrograms': {'type': 'boolean'},
    'outreachMaterials': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'display': {'type': 'boolean', 'coerce': to_bool},
        'name': {'type': 'string'},
        'description': {'type': 'string'},
        'fileName': {'type': 'string'},
        'url': {'type': 'string'},
        'key': {'type': 'string'},
    }}},
}

schema_survey = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'nonprofit': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'submissionFormName': {'type': 'string', 'required': True, 'empty': False},
    'nonprofitSlug': {'type': 'string'},
    'slug': {'type': 'string'},
    'editing': {'type': 'boolean', 'default': True},
    'lastUpdated': {'type': type_datetime},
    'createdAt': {'type': type_datetime},
    'givewithAdmin': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'status': {'type': 'string', 'empty': False},
    'percentComplete': {'type': 'float', 'coerce': to_number},
    'Finance': {'type': 'dict', 'empty': False, 'schema': {
        'currency': {'type': 'string', 'empty': False, 'required': True, 'allowed': allowed_currency_types}
    }}
}

schema_funding_form = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'slug': {'type': 'string'},
    'createdAt': {'type': type_datetime, 'coerce': to_datetime},
    'lastUpdated': {'type': type_datetime},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'givewithAdmin': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'effectiveDate': {'type': type_datetime, 'coerce': to_datetime},
    'deal': {'type': type_object_id, 'coerce': to_object_id, 'required': True, 'empty': False},
    'additionalTerms': {'type': 'string'},
    'notes': {'type': 'string'},
    'externalNotes': {'type': 'string'},
    'program': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'nonprofit': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'nonprofitSlug': {'type': 'string'},
    'givewithCustomer': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'client': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'editing': {'type': 'boolean', 'required': True, 'empty': False, 'coerce': to_bool},
    'status': {'type': 'string', 'required': True, 'empty': False},
    'fundingOpportunityStatus': {'type': 'string', 'required': True, 'empty': False},
    'fundingOpportunityName': {'type': 'string', 'required': True, 'empty': False},
    'signature': {'type': 'dict', 'empty': False, 'schema': {
        'name': {'type': 'string', 'empty': False, 'required': True},
        'email': {'type': 'string', 'empty': False, 'required': True, 'regex': REGEX_VALID_EMAIL},
        'date': {'type': type_datetime, 'empty': False, 'required': True, 'coerce': to_datetime}
    }},
    'percentComplete': {'type': 'float', 'required': True, 'empty': False, 'coerce': to_number},
    'docExport': {'type': type_file, 'schema': schema_file()},
    'legalApproved': {'type': type_file, 'schema': schema_file()},
    'fullyExecuted': {'type': type_file, 'schema': schema_file()},
    'deliverables': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
        'name': {'type': 'string', 'required': True, 'empty': False},
        'url': {'type': 'string'},
    }}},
    'programNameTitleCase': {'type': 'string'},
    'programNameLowerCase': {'type': 'string'},
    'objects': {'type': 'list', 'schema':  {'type': 'dict', 'schema': {
        'quantity': {'type': type_number, 'required': True, 'empty': False, 'coerce': to_number},
        'description': {'type': 'string', 'required': True, 'empty': False},
        'verb': {'type': 'string'},
        'targetPlural': {'type': 'string'},
        'targetSingular': {'type': 'string'}
    }}},
    'programDescription': {'type': 'string'},
    'outputsAdditionalDetails': {'type': 'string'},
    'outcomesAdditionalDetails': {'type': 'string'},
}

schema_completion_form = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'slug': {'type': 'string'},
    'createdAt': {'type': type_datetime},
    'lastUpdated': {'type': type_datetime},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'givewithAdmin': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'dueDate': {'type': type_datetime, 'coerce': to_datetime},
    'fundingForm': {'type': type_object_id, 'coerce': to_object_id, 'required': True, 'empty': False},
    'deal': {'type': type_object_id, 'coerce': to_object_id, 'required': True, 'empty': False},
    'notes': {'type': 'string'},
    'program': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'nonprofit': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'nonprofitSlug': {'type': 'string'},
    'givewithCustomer': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'client': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'editing': {'type': 'boolean', 'required': True, 'empty': False, 'coerce': to_bool},
    'status': {'type': 'string', 'required': True, 'empty': False},
    'percentComplete': {'type': 'float', 'required': True, 'empty': False, 'coerce': to_number},
    'signature': {'type': 'dict', 'empty': False, 'schema': {
        'name': {'type': 'string', 'empty': False, 'required': True},
        'email': {'type': 'string', 'empty': False, 'required': True, 'regex': REGEX_VALID_EMAIL},
        'date': {'type': type_datetime, 'empty': False, 'required': True}
    }},
}

schema_contact = {
    '_id': {'type': type_object_id},
    'name': {'type': 'string'},
    'email': {'type': 'string', 'regex': REGEX_VALID_EMAIL},
    'phone': {'type': 'string'},
    'brand': {'type': 'string'},
    'brandRef': {'type': type_object_id},
    'role': {'type': 'string'},
    'budget': {'type': type_number, 'coerce': to_number},
    'info': {'type': 'string'},
    'programRefs': {'type': 'list', 'schema': {'type': type_object_id}},
    'createdAt': {'type': type_datetime},
    'lastUpdated': {'type': type_datetime}
}

schema_settings = {
    'csv': {'required': True, 'empty': False, 'type': 'dict', 'schema': {
        'msciLastUpdated': {'type': type_datetime},
        'themesLastUpdated': {'type': type_datetime},
    }},
    'recommendationSettings': {'required': True, 'empty': False, 'type': 'dict', 'schema': {
        'keyIssues': {'type': 'integer', 'min': 0, 'empty': False},
        'themes': {'type': 'integer', 'min': 0, 'empty': False},
        'recommendations': {'type': 'integer', 'min': 1, 'empty': False},
    }},
    'defaultsSettings': {'required': True, 'empty': False, 'type': 'dict', 'schema': {
        'volunteerRate': {'type': 'integer', 'min': 1, 'empty': False},
    }},
    'scoringSettings': {'required': True, 'empty': False, 'type': 'dict', 'schema': {
        'minimumHigh': {'type': 'integer', 'min': 1, 'empty': False},
        'maximumLow': {'type': 'integer', 'min': 1, 'empty': False},
        'screenOneMinimum': {'type': 'integer', 'min': 1, 'empty': False},
    }},
    'contentSettings': {'required': True, 'empty': False, 'type': 'list', 'schema': {
        'type': 'dict', 'schema': {
            'title': {'type': 'string', 'required': True, 'empty': False},
            'value': {'type': 'string', 'required': True, 'empty': False},
            'key': {'type': 'string', 'required': True, 'empty': False},
            'description': {'type': 'string', 'required': True, 'empty': False}
        }
    }},
}

schema_api_configs = {
    'logLevel': {'type': 'string', 'required': True, 'empty': False, 'allowed': [
        'CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG'
    ]},
    'enableStackTrace': {'type': 'boolean', 'required': True, 'empty': False, 'coerce': to_bool},
    'enableMaintenanceMode': {'type': 'boolean', 'required': True, 'empty': False, 'coerce': to_bool},
    'msgMaintenanceMode': {'type': 'string', 'empty': False, 'default': 'Server under maintenance'}
}

APISchema_deal = {
    '_id': {'type': type_object_id},
    'altLicensingGivewithCustomer': {'type': 'string', 'required': False},
    'altLicensingClient': {'type': 'string', 'required': False},
    'slug': {'type': 'string'},
    'status': {'type': 'string', 'empty': False},
    'statusUpdatedAt': {'type': type_datetime, 'required': False, 'empty': False},
    'archived': {'type': 'boolean', 'coerce': to_bool},
    'confirmation': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'confirmedAt': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
        'confirmedBy': {'type': type_object_id, 'required': False, 'empty': False},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'clientConfirmation': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'confirmedAt': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
        'email': {'type': 'string', 'required': False, 'empty': False},
        'name': {'type': 'string'},
        'accountsPayable': {'type': 'dict', 'empty': False, 'schema': {
            'name': {'type': 'string'},
            'email': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_EMAIL}
        }},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'expectedClientToConfirm': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'confirmedAt': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
        'email': {'type': 'string', 'required': False, 'empty': False},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'selectedProgram': {'type': type_object_id},
    'selectedProgramMeta': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'selectedAt': {'type': type_datetime, 'required': False, 'empty': False},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'recommendedPercentages': {'type': 'dict'},
    'recommendedPercentagesDate': {'type': type_datetime},
    'selectedRecommendedPrograms': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        '_id': {'type': type_object_id, 'empty': False},
        'name': {'type': 'string', 'empty': False},
        'nonprofit': {'type': type_object_id, 'empty': False},
        'nonprofitName': {'type': 'string', 'empty': False},
        'match': {'type': type_number, 'coerce': to_number, 'empty': False},
        'matchType': {'type': 'string', 'empty': False, 'default': 'MATCH'},
        'customMatch': {'type': type_number, 'empty': False, 'coerce': to_number,
                        'min': 0, 'max': 100,
                        'dependencies': {'matchType': 'CUSTOM_MATCH'}},
        'customerPreferred': {'type': 'boolean', 'empty': False, 'coerce': to_bool},
    }}},
    'reference': {'type': type_number, 'coerce': to_number, 'empty': False},
    'currency': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_currency_types},
    'givePercent': {'type': type_number, 'coerce': to_number},
    'fundingAmount': {'type': type_number, 'coerce': to_number, 'empty': False},
    'givewithPortion': {'type': type_number, 'coerce': to_number, 'empty': False},
    'givewithFeePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    'name': {'type': 'string', 'empty': False, },
    'description': {'type': 'string', 'empty': False, },
    'manager': {'type': type_object_id, 'empty': False},
    'password': {'type': 'string', 'empty': False},
    'contacts': {'type': 'list', 'empty': False, 'schema': {'type': type_object_id}},
    'salesforceId': {'type': 'string', 'empty': False},
    'type': {'type': 'string', 'empty': False},
    'giveOption': {'type': 'string', 'empty': False},
    'splitGiveAmount': {'type': 'boolean', 'empty': False, 'coerce': to_bool},
    'note': {'type': 'string'},
    'deliverables': {'type': 'dict', 'empty': False, 'schema': {
        'givewithCustomer': {'type': 'dict', 'schema': {
            'deliverables': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
                'userSelections': {'type': 'dict'},
            }}},
            'custom': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
            }}},
        }},
        'client': {'type': 'dict', 'schema': {
            'deliverables': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
                'userSelections': {'type': 'dict'},
            }}},
            'custom': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
            }}},
        }},
    }},
    'givewithCustomerRole': {'type': 'string', 'empty': False},
    'client': {'type': 'string', 'required': True, 'empty': False},
    'givewithCustomer': {'type': 'string', 'required': True, 'empty': False},
    'totalBudget': {'type': type_number, 'coerce': to_number, 'empty': False},
    'customerNotes': {'type': 'string', 'required': False},
    'givewithCustomerUser': {'type': 'string', 'required': False, 'empty': True},
    'clientUser': {'type': 'string', 'required': False, 'empty': True},
    'givewithCustomerEmails': {'type': 'list', 'required': False, 'empty': True},
    'clientEmails': {'type': 'list', 'required': False, 'empty': True},
    'paymentOption': {'type': 'string', 'allowed': allowed_payment_methods},
    'paymentTerm': {'type': type_number, 'coerce': to_number},
    'paymentRequestDate': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
    'completionDate': {'type': type_datetime, 'coerce': to_datetime},
    'paymentStatus': {'type': 'string'},
    'sourcingEventType': {'type': 'string'},
    'category': {'type': 'string'},
    'department': {'type': 'string'},
    'actualizations': {'type': 'list', 'required': False, 'empty': True, 'schema': {'type': 'dict', 'schema': {
        'spend': {'type': type_number, 'empty': False, 'coerce': to_number_without_commas},
        'currency': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_currency_types},
        'date': {'type': 'dict', 'required': True, 'empty': False, 'schema': {

            'startDate': {'type': type_datetime, 'required': True, 'empty': False, 'coerce': to_datetime},
            'endDate': {'type': type_datetime, 'required': True, 'empty': False, 'coerce': to_datetime},
        }}
    }}}
}

DBSchema_deal = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'altLicensingGivewithCustomer': {'type': 'string', 'required': False},
    'altLicensingClient': {'type': 'string', 'required': False},
    'slug': {'type': 'string', 'required': True, 'empty': False},
    'status': {'type': 'string', 'required': True, 'empty': False},
    'statusUpdatedAt': {'type': type_datetime, 'required': False, 'empty': False},
    'archived': {'type': 'boolean', 'coerce': to_bool},
    'confirmation': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'confirmedAt': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
        'confirmedBy': {'type': type_object_id, 'required': False, 'empty': False, 'coerce': to_object_id},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'clientConfirmation': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'confirmedAt': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
        'email': {'type': 'string', 'required': False, 'empty': False},
        'name': {'type': 'string'},
        'accountsPayable': {'type': 'dict', 'empty': False, 'schema': {
            'name': {'type': 'string'},
            'email': {'type': 'string', 'empty': False, 'regex': REGEX_VALID_EMAIL}
        }},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'expectedClientToConfirm': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'confirmedAt': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
        'email': {'type': 'string', 'required': False, 'empty': False},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'selectedProgram': {'type': type_object_id, 'coerce': to_object_id},
    'selectedProgramMeta': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
        'selectedAt': {'type': type_datetime, 'required': False, 'empty': False},
        'notes': {'type': 'string', 'required': False, 'empty': True}
    }},
    'programName': {'type': 'string', 'empty': False, 'dependencies': 'selectedProgram'},
    'nonprofitName': {'type': 'string', 'empty': False, 'dependencies': 'selectedProgram'},
    'selectedRecommendedPrograms': {'type': 'list', 'schema': {'type': 'dict', 'schema': {
        '_id': {'type': type_object_id, 'empty': False, 'coerce': to_object_id},
        'name': {'type': 'string', 'empty': False},
        'nonprofit': {'type': type_object_id, 'empty': False, 'coerce': to_object_id},
        'nonprofitName': {'type': 'string', 'empty': False},
        'match': {'type': type_number, 'coerce': to_number, 'empty': False},
        'matchType': {'type': 'string', 'empty': False, 'default': 'MATCH'},
        'customMatch': {'type': type_number, 'empty': False, 'coerce': to_number,
                        'min': 0, 'max': 100,
                        'dependencies': {'matchType': 'CUSTOM_MATCH'}},
        'customerPreferred': {'type': 'boolean', 'empty': False, 'coerce': to_bool},
    }}},
    'recommendedPercentages': {'type': 'dict'},
    'recommendedPercentagesDate': {'type': type_datetime},
    'reference': {'type': type_number, 'coerce': to_number, 'empty': False},
    'givePercent': {'type': type_number, 'coerce': to_number},
    'fundingAmount': {'type': type_number, 'coerce': to_number, 'empty': False},
    'givewithPortion': {'type': type_number, 'coerce': to_number, 'empty': False},
    'givewithFeePercentage': {'type': type_number, 'allowed': range(0,101), 'coerce': to_number},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'description': {'type': 'string', 'required': True, 'empty': False},
    'manager': {'type': type_object_id, 'empty': False, 'coerce': to_object_id},
    'managerName': {'type': 'string', 'empty': False},
    'password': {'type': 'string', 'required': True, 'empty': False},
    'contacts': {'type': 'list', 'required': True, 'empty': False, 'schema': {'type': type_object_id}},
    'createdAt': {'type': type_datetime},
    'createdBy': {'type': type_object_id, 'coerce': to_object_id},
    'lastUpdated': {'type': type_datetime},
    'isValid': {'type': 'boolean', 'coerce': to_bool},
    'type': {'type': 'string', 'empty': False},
    'giveOption': {'type': 'string', 'empty': False},
    'splitGiveAmount': {'type': 'boolean', 'empty': False, 'coerce': to_bool},
    'salesforceId': {'type': 'string', 'empty': False},
    'note': {'type': 'string'},
    'deliverables': {'type': 'dict', 'empty': False, 'schema': {
        'givewithCustomer': {'type': 'dict', 'schema': {
            'deliverables': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
                'userSelections': {'type': 'dict'},
            }}},
            'custom': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
            }}},
        }},
        'client': {'type': 'dict', 'schema': {
            'deliverables': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
                'userSelections': {'type': 'dict'},
            }}},
            'custom': {'type': 'list', 'schema': { 'type': 'dict', 'schema': {
                'name': {'type': 'string', 'required': True, 'empty': False},
                'url': {'type': 'string'},
                'display': {'type': 'boolean', 'required': True, 'empty': False},
            }}},
        }},
    }},
    'contact': {'type': 'dict', 'empty': False, 'schema': {
        'name': {'type': 'string', 'empty': False},
        'role': {'type': 'string', 'empty': False},
        'email': {'type': 'string', 'empty': False},
        'phoneNumber': {'type': 'string', 'empty': False}
    }},
    'currency': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_currency_types},
    'totalBudget': {'type': type_number, 'coerce': to_number, 'required': True, 'empty': False},
    'customerNotes': {'type': 'string', 'required': False},
    'givewithCustomer': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'givewithCustomerRole': {'type': 'string', 'empty': False, 'coerce': to_lower},
    'givewithCustomerUser': {'type': 'string', 'required': False},
    'client': {'type': type_object_id, 'required': True, 'empty': False, 'coerce': to_object_id},
    'clientUser': {'type': 'string', 'required': False},
    'givewithCustomerEmails': {'type': 'list', 'required': False, 'empty': True},
    'clientEmails': {'type': 'list', 'required': False, 'empty': True},
    'preventUpdateEmail': {'type': 'boolean', 'required': False},
    'paymentOption': {'type': 'string', 'allowed': allowed_payment_methods},
    'paymentTerm': {'type': type_number, 'coerce': to_number},
    'paymentRequestDate': {'type': type_datetime, 'required': False, 'empty': False, 'coerce': to_datetime},
    'completionDate': {'type': type_datetime, 'coerce': to_datetime},
    'paymentStatus': {'type': 'string'},
    'sourcingEventType': {'type': 'string'},
    'category': {'type': 'string'},
    'department': {'type': 'string'},
    'isTest': {'type': 'boolean'},
    'actualizations': {'required': False, 'empty': True, 'type': 'list', 'schema': {'type': 'dict', 'schema': {
        'spend': {'type': type_number, 'empty': False, 'coerce': to_number_without_commas},
        'currency': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_currency_types},
        'date': {'type': 'dict', 'required': True, 'empty': False, 'schema': {

            'startDate': {'type': type_datetime, 'required': True, 'empty': False, 'coerce': to_datetime},
            'endDate': {'type': type_datetime, 'required': True, 'empty': False, 'coerce': to_datetime},
        }}
    }}}
}

actualization_schema = {'actualizations': DBSchema_deal['actualizations']}


schema_gics_csv = {
    'Arts and Culture': {'type': 'float', 'required': True, 'empty': False},
    'Disaster Relief': {'type': 'float', 'required': True, 'empty': False},
    'Diversity and Inclusion': {'type': 'float', 'required': True, 'empty': False},
    'Economic Development': {'type': 'float', 'required': True, 'empty': False},
    'Education': {'type': 'float', 'required': True, 'empty': False},
    'Environment': {'type': 'float', 'required': True, 'empty': False},
    'Food and Hunger': {'type': 'float', 'required': True, 'empty': False},
    'Health and Wellness': {'type': 'float', 'required': True, 'empty': False},
    'Housing and Homelessness': {'type': 'float', 'required': True, 'empty': False},
    'Justice': {'type': 'float', 'required': True, 'empty': False},
    'Aging populations': {'type': 'float', 'required': True, 'empty': False},
    'Animal Welfare': {'type': 'float', 'required': True, 'empty': False},
    'Youth Development': {'type': 'float', 'required': True, 'empty': False},
    'LGBTQ+': {'type': 'float', 'required': True, 'empty': False},
    'People living in poverty': {'type': 'float', 'required': True, 'empty': False},
    'People with disabilities': {'type': 'float', 'required': True, 'empty': False},
    'Veterans': {'type': 'float', 'required': True, 'empty': False},
    'Women and Girls': {'type': 'float', 'required': True, 'empty': False},
}

DBSchema_gics = {
    'code2': {'type': 'integer', 'required': True, 'empty': False},
    'sector': {'type': 'string', 'required': True, 'empty': False},
    'code4': {'type': 'integer', 'required': True, 'empty': False},
    'group': {'type': 'string', 'required': True, 'empty': False},
    'code6': {'type': 'integer', 'required': True, 'empty': False},
    'industry': {'type': 'string', 'required': True, 'empty': False},
    'code8': {'type': 'integer', 'required': True, 'empty': False},
    'subIndustry': {'type': 'string', 'required': True, 'empty': False},
    'subIndustryDescription': {'type': 'string', 'required': True, 'empty': False},
    'themes': {'type': 'dict', 'required': True, 'schema': {
        'artsAndCulture': {'type': 'integer', 'required': True, 'empty': False},
        'disasterRelief': {'type': 'integer', 'required': True, 'empty': False},
        'diversityAndInclusion': {'type': 'integer', 'required': True, 'empty': False},
        'economicDevelopment': {'type': 'integer', 'required': True, 'empty': False},
        'education': {'type': 'integer', 'required': True, 'empty': False},
        'environment': {'type': 'integer', 'required': True, 'empty': False},
        'foodAndHunger': {'type': 'integer', 'required': True, 'empty': False},
        'healthAndWellness': {'type': 'integer', 'required': True, 'empty': False},
        'housingAndHomelessness': {'type': 'integer', 'required': True, 'empty': False},
        'justice': {'type': 'integer', 'required': True, 'empty': False},
        'agingPopulations': {'type': 'integer', 'required': True, 'empty': False},
        'animalWelfare': {'type': 'integer', 'required': True, 'empty': False},
        'youthDevelopment': {'type': 'integer', 'required': True, 'empty': False},
        'lgbtq': {'type': 'integer', 'required': True, 'empty': False},
        'peopleLivingInPoverty': {'type': 'integer', 'required': True, 'empty': False},
        'peopleWithDisabilities': {'type': 'integer', 'required': True, 'empty': False},
        'veterans': {'type': 'integer', 'required': True, 'empty': False},
        'womenAndGirls': {'type': 'integer', 'required': True, 'empty': False},

    }},
    'totalWeight': {'type': 'integer', 'required': True, 'empty': False},
}

schema_user_api = {
    'orgType': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_org_types},
    'orgId': {'type': type_object_id, 'required': True, 'coerce': to_object_id},
    'name': {'type': 'string', 'required': False, 'empty': False},
    'first_name': {'type': 'string', 'required': True, 'empty': False},
    'last_name': {'type': 'string', 'required': True, 'empty': False},
    'active': {'type': 'boolean', 'coerce': to_bool},
    'company': {'type': 'string', 'required': False, 'empty': True},
    'title': {'type': 'string', 'required': False, 'empty': True},
    'notes': {'type': 'string', 'required': False, 'empty': True},
    'type': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_user_types},
    'cognito-id': {'type': 'string', 'required': False, 'empty': False},
    'username': {'type': 'string', 'required': True, 'empty': False},
    'departmentName': {'type': 'string'},
    'departmentType': {'type': 'string', 'allowed': allowed_department_types},
    'phoneNumber': {'type': 'string'},
    'businessAddress': {'type': 'string'},
}

schema_user = {
    '_id': {'type': type_object_id, 'coerce': to_object_id},
    'uuid': {'type': 'string'},
    'name': {'type': 'string', 'required': True, 'empty': False},
    'first_name': {'type': 'string', 'required': True, 'empty': False},
    'last_name': {'type': 'string', 'required': True, 'empty': False},
    'active': {'type': 'boolean', 'required': True, 'coerce': to_bool},
    'company': {'type': 'string', 'required': False, 'empty': True},
    'title': {'type': 'string', 'required': False, 'empty': True},
    'notes': {'type': 'string', 'required': False, 'empty': True},
    'cognito-id': {'type': 'string', 'required': True, 'empty': False},
    'type': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_user_types},
    'username': {'type': 'string', 'required': True, 'empty': False, 'coerce': to_lower},
    'orgType': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_org_types},
    'orgId': {'type': type_object_id, 'required': True, 'coerce': to_object_id},
    'roles': {'type': 'list', 'allowed': allowed_user_roles},
    'departmentName': {'type': 'string'},
    'departmentType': {'type': 'string', 'allowed': allowed_department_types},
    'phoneNumber': {'type': 'string'},
    'businessAddress': {'type': 'string'},
    'createdAt': {'type': type_datetime},
}

MSCI_COLUMN_TRANSLATE = {
    'carbonEmissions': 'Carbon Emissions',
    'climateChangeVulnerability': 'Climate Change Vulnerability',
    'humanCapitalDevelopment': 'Human Capital Development',
    'responsibleInvestment': 'Responsible Investment',
    'accessToCommunications': 'Access to Communications',
    'accessToFinance': 'Access to Finance',
}

MSCI_COLUMN_TRANSLATE_ADMIN = {
    **MSCI_COLUMN_TRANSLATE,
    'oppsGreenBuilding': 'Opportunities in Green Building',
}

PROGRAM_SURVEY_MAP = {
    'name': 'General.name.platformProgramName',
    'description': 'General.description.value',
    'audienceAge': 'ImpactAndScope.targetAge.value.selected',
    'audienceAttribute': 'ImpactAndScope.targetAttributes.value.selected',
    'causes': 'ImpactAndScope.causeAreas.value.selected',
    'primaryImpact': 'ImpactAndScope.primaryImpact.value.selected',
    'secondaryImpacts': 'ImpactAndScope.secondaryImpact.value.selected',
    'programApproach': 'StrategiesAndApproaches.strategies.value.selected',
    'approachDuration': 'StrategiesAndApproaches.approachDuration.value',
    'nonprofitPartners': 'StrategiesAndApproaches.nonprofitPartners.value',
    'dataMeasurementType': 'StrategiesAndApproaches.resultsMeasurement.value',
    'outputs': 'StrategiesAndApproaches.outputs.value',
    'outcomes': 'StrategiesAndApproaches.outcomes.value',
    'dataDescription': 'ResearchAndEvaluation.dataDescription.value.selected',
    'approach': 'ResearchAndEvaluation.researchApproaches.value.selected',
    'evidenceDescription': 'ResearchAndEvaluation.evidenceDescription.value.selected',
    'currency': 'Finance.currency',
    'budget': 'Finance.budget.value',
    'cashContributions': 'Finance.cashContributions.value',
    'inKindContributions': 'Finance.inKindContributions.value'
}

# -- Nonprofit Survey Models --------------------------------------------------
survey_model = lambda set_required=False, set_empty=True, dependencies={}, **kwargs: {
        'General': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'contact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'name': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'email': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'phone': {'type': 'string', 'required': set_required, 'empty': set_empty},
            }},
            'name': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'internalProgramName': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'platformProgramName': {'type': 'string', 'required': set_required, 'empty': set_empty},
            }},
            'description': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }}
        }},
        'ImpactAndScope': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'causeAreas': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                }
            }},
            'primaryImpact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                }
            }},
            'secondaryImpact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                }
            }},
            # these are optional question -> required if primaryImpact and secondaryImpact
            # has certain values determined by dependencies dict in survey_meta_data -> defaults to False
            'protectAndEnhanceForest': {
                'type': 'dict', 'required': dependencies.get('protectAndEnhanceForest', False),
                'empty': not dependencies.get('protectAndEnhanceForest', False),
                'schema': {
                    'value': {
                        'type': 'boolean', 'required': dependencies.get('protectAndEnhanceForest', False),
                        'empty': not dependencies.get('protectAndEnhanceForest', False)
                    }
                }
            },
            'animalHabitat': {
                'type': 'dict', 'required': dependencies.get('animalHabitat', False),
                'empty': not dependencies.get('animalHabitat', False),
                'schema': {
                    'value': {
                        'type': 'string', 'required': dependencies.get('animalHabitat', False),
                        'empty': not dependencies.get('animalHabitat', False)
                    }
                }
            },
            'targetAttributes': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                },
                'optional': {'type': 'string'}
            }},
            'targetAge': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                },
            }},
            'regions': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                },
            }},
            # Optional Location questions - behaves similar to earlier optional questions
            'countries': {
                'type': 'dict', 'required': dependencies.get('countries', False),
                'empty': not dependencies.get('countries', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('countries', False),
                        'empty': not dependencies.get('countries', False),
                        'anyof_schema': schema_multiselect(dependencies.get('countries', False),
                                                           not dependencies.get('countries', False))
                    }
                }
            },
            'states': {
                'type': 'dict', 'required': dependencies.get('states', False),
                'empty': not dependencies.get('states', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('states', False),
                        'empty': not dependencies.get('states', False),
                        'anyof_schema': schema_multiselect(dependencies.get('states', False),
                                                           not dependencies.get('states', False))
                    }
                }
            },
            'cities': {
                'type': 'dict', 'required': dependencies.get('cities', False),
                'empty': not dependencies.get('cities', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('cities', False),
                        'empty': not dependencies.get('cities', False),
                        'anyof_schema': schema_multiselect(dependencies.get('cities', False),
                                                           not dependencies.get('cities', False))
                    }
                }
            },
            'additionalLocationDetails': {'type': 'dict', 'schema': {
                'value': {'type': 'string'}
            }}
        }},
        'StrategiesAndApproaches': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'strategies': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                }
            }},
            'activities': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'approachDuration': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty, 'coerce': str}
            }},
            'activitiesFrequency': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'outputs': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'list', 'required': set_required, 'empty': set_empty, 'schema': {
                    'type': type_multi_input, 'required': set_required, 'empty': set_empty,
                    'schema': schema_multi_input(set_required, set_empty)
                }},
            }},
            'outcomes': {'type': 'dict', 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'list', 'schema': {
                    'type': type_multi_input, 'schema': schema_multi_input()
                }},
            }},
            'resultsMeasurement': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty, 'coerce': str},
                'optional': {'type': 'string'}
            }},
            'nonprofitPartners': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'boolean', 'required': set_required, 'empty': set_empty},
            }},
        }},
        'ResearchAndEvaluation': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'researchFile': {'type': 'dict', 'schema': {
                'value': {'type': type_file, 'schema': schema_file()}
            }},
            'evidenceDescription': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    'anyof_schema': schema_multiselect(set_required, set_empty)
                }
            }},
            'studyDescription': {
                'type': 'dict', 'required': dependencies.get('studyDescription', False),
                'empty': not dependencies.get('studyDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('studyDescription', False),
                        'empty': not dependencies.get('studyDescription', False),
                        'anyof_schema': schema_multiselect(dependencies.get('studyDescription', False),
                                                           not dependencies.get('studyDescription', False))
                    }
                }
            },
            'dataDescription': {
                'type': 'dict', 'required': dependencies.get('dataDescription', False),
                'empty': not dependencies.get('dataDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('dataDescription', False),
                        'empty': not dependencies.get('dataDescription', False),
                        'anyof_schema': schema_multiselect(dependencies.get('dataDescription', False),
                                                           not dependencies.get('dataDescription', False))
                    }
                }
            },
            'outcomeDescription': {
                'type': 'dict', 'required': dependencies.get('outcomeDescription', False),
                'empty': not dependencies.get('outcomeDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('outcomeDescription', False),
                        'empty': not dependencies.get('outcomeDescription', False),
                        'anyof_schema': schema_multiselect(dependencies.get('outcomeDescription', False),
                                                           not dependencies.get('outcomeDescription', False))
                    }
                }
            },
            'researchApproaches': {
                'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                    'value': {
                        'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                        'anyof_schema': schema_multiselect(set_required, set_empty)
                    }
                }
            },
            'environmentalOutputs': {
                'type': 'dict', 'required': dependencies.get('environmentalOutputs', False),
                'empty': not dependencies.get('environmentalOutputs', False),
                'schema': {
                    'value': {
                        'type': type_multiselect,
                        'required': dependencies.get('environmentalOutputs', False),
                        'empty': dependencies.get('environmentalOutputs', False),
                        'anyof_schema': schema_multiselect(dependencies.get('environmentalOutputs', False),
                                                           not dependencies.get('environmentalOutputs', False))
                    }
                }
            },
            'environmentalOutputValues': {
                'type': 'dict',
                'required': dependencies.get('environmentalOutputValues', False),
                'empty': not dependencies.get('environmentalOutputs', False),
                'schema': {
                    'optional': {'type': 'string'},
                    'value': {
                        'type': 'list',
                        'required': dependencies.get('environmentalOutputs', False),
                        'empty': not dependencies.get('environmentalOutputs', False),
                        'schema': {
                            'type': type_multi_input,
                            'required': dependencies.get('environmentalOutputs', False),
                            'empty': not dependencies.get('environmentalOutputs', False),
                            'schema': schema_multi_input(dependencies.get('environmentalOutputs', False),
                                                         not dependencies.get('environmentalOutputs', False))
                        }
                    },
                }
            },
            'strength': {
                'type': 'dict', 'required': dependencies.get('strength', False),
                'empty': not dependencies.get('strength', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('strength', False),
                        'empty': not dependencies.get('strength', False),
                        'anyof_schema': schema_multiselect(dependencies.get('strength', False),
                                                           not dependencies.get('strength', False))
                    }
                }
            },
        }},
        'Finance': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'currency': {'type': 'string', 'required': set_required, 'empty': set_empty,
                         'allowed': allowed_currency_types},
            'budget': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty, 'coerce': str}
            }},
            'budgetFile': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_file, 'required': set_required, 'empty': set_empty,
                    'schema': schema_file(set_required, set_empty)
                }
            }},
            'cashContributions': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty, 'coerce': str}
            }},
            'inKindContributions': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty, 'coerce': str}
            }},
        }},
        'Content': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'filmLocation': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'assets': {'type': 'dict', 'schema': {
                'value': {'type': type_file, 'schema': schema_file()}
            }},
        }},
    }

# -- Dashboard Models ----------------------------------------------------------
DASHBOARD_MODELS = {
    'user': {
        'patch': {
            'username': {'type': 'string', 'required': True, 'empty': False},
            'name': {'type': 'string', 'required': False, 'empty': False},
            'first_name': {'type': 'string', 'required': False, 'empty': False},
            'last_name': {'type': 'string', 'required': False, 'empty': False},
            'title': {'type': 'string', 'required': False, 'empty': True},
            'departmentName': {'type': 'string', 'required': False, 'empty': True},
            'departmentType': {'type': 'string', 'required': False, 'empty': True},
            'phoneNumber': {'type': 'string', 'required': False, 'empty': True},
            'businessAddress': {'type': 'string', 'required': False, 'empty': True},
        }
    },
    'proposal': {
        'get': {
            'id': {'type': 'string', 'required': True, 'empty': True}
        },
        'post': {
            'clientCompany': {'type': 'string', 'required': True, 'empty': False},
            'proposalName': {'type': 'string'},
            'type': {'type': 'string', 'empty': False, 'coerce': to_lower, 'allowed': ['enterprise', 'sales', 'covid']},
            'totalBudget': {'type': type_number, 'empty': False, 'coerce': to_number_without_commas},
            'totalFunding': {'type': 'string', 'empty': False},
            'givewithPortion': {'type': 'string', 'empty': False},
            'sapAssociation': {'type': 'boolean', 'empty': False, 'coerce': to_bool},
            'currency': {'type': 'string', 'required': True, 'empty': False, 'allowed': allowed_currency_types},
            'aribaRfpId': {'type': 'string', 'coerce': str},
            'selectedProgram': {'type': type_object_id, 'coerce': to_object_id},
            'givewithCustomerRole': {'type': 'string', 'empty': False},
            'sourcingEventType': {'type': 'string'},
            'category': {'type': 'string'},
            'department': {'type': 'string'},
            # COVID Fields
            'giveAmount': {'type': type_number, 'empty': False, 'coerce': to_number_without_commas},
            'giveOption': {'type': 'string', 'empty': False, 'coerce': to_lower, 'allowed': ['percentage', 'fixed']},
            'givePercent': {'type': type_number, 'empty': False, 'coerce': to_number},
            'clientEmail': {'type': 'string', 'empty': False}
        },
        'patch': {
            'id': {'type': 'string', 'required': True, 'empty': False},
            'proposalName': {'type': 'string', 'required': False, 'empty': False},
            'contact': {'type': 'dict', 'required': False, 'empty': False, 'schema': {
                'email': {'type': 'string', 'required': False, 'empty': False},
                'name': {'type': 'string', 'required': False, 'empty': False},
                'phoneNumber': {'type': 'string', 'required': False, 'empty': False},
                'role': {'type': 'string', 'required': False, 'empty': False}
            }},
            'description': {'type': 'string', 'required': False, 'empty': False},
            'fundingAmount': {'type': 'integer', 'required': False, 'empty': False},
            'manager': {'type': 'string', 'required': False, 'empty': False},
            'nonprofitName': {'type': 'string', 'required': False, 'empty': False},
            'programName': {'type': 'string', 'required': False, 'empty': False},
            'status': {'type': 'string', 'required': False, 'empty': False},
            'totalBudget': {'type': 'integer', 'required': False, 'empty': False},
            'sourcingEventType': {'type': 'string'},
            'category': {'type': 'string'},
            'department': {'type': 'string'}
        }
    }
}
# ------------------------------------------------------------------------------
