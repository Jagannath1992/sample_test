from cerberus import Validator

from matchmaking.models.mpa import patch_info_request_schema, patch_review_request_schema
from matchmaking.validation.utils import validate_object_id


"""
validate MPA patch request, return if the request is valid, and details of errors
"""
def validate_mpa_patch_request(npo_id, form_name, patch_request) -> (bool, []):
    validate_object_id(npo_id, 'mm_nonprofits')

    v = Validator()
    valid = False
    errors = []

    if form_name != 'info' and form_name != 'review':
        errors.append({'form_name': 'invalid form name. expect info, review. got ' + form_name})
        return False, errors

    if form_name == 'info':
        valid = v.validate(patch_request, patch_info_request_schema)
    elif form_name == 'review':
        valid = v.validate(patch_request, patch_review_request_schema)

    if not valid:
        errors.append(v.errors)

    return valid, errors
