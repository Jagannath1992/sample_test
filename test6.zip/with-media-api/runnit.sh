FLASK_APP=main.py FLASK_ENV=development flask run -p 7000
