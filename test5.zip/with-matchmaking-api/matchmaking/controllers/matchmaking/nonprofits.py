# -*- coding: utf-8 -*-
from flask import jsonify, request, current_app
from pymongo import ReturnDocument
from werkzeug.utils import secure_filename

from ...controllers import admin_bp
from ...models.models import v, schema_nonprofit_v1, schema_nonprofit_v2, to_bool
from ...mongodb import ObjectId, db
from ...s3 import upload_file, delete_file
from ...triggers import (remove_nonprofit_from_programs, set_children_and_grandchildren_is_valid_of_nonprofit,
                         remove_invalid_nonprofit_programs_from_deals,
                         remove_nonprofit_programs_from_blacklisted_brands)
from ...permission_decorator import require_admin_permission
from ...validation.utils import validate_object_id, validate_schema
from ...validation.nonprofit_form import completed_form_schema
from ...dao.utils import get_document_by_id, get_documents, update_document_by_id
from ...utils import (set_last_updated, EntityNotFound, UnsupportedPayload, GivewithError, ValidationError,
                      create_validation_error_response, clean_nonprofits, set_descendant_key, get_descendant_key,
                      pop_descendant_key)
from .mpa import set_progress

entity_name = 'nonprofit'
target_collection = 'mm_nonprofits'

name_map = {
    "Status": "Status",
    "Finished": "Finished",
    "Q1": "name",
    "Q4": "url",
    "Q19": "descriptionLong",
    "Q33": "description",
    "Q31_1": "impacts_0_label",
    "Q31_2": "impacts_0_value",
    "Q31_3": "impacts_1_label",
    "Q31_4": "impacts_1_value",
    "Q31_5": "impacts_2_label",
    "Q31_6": "impacts_2_value",
    "Q34": "impactsDescription"
}

field_to_column = {v: k for k, v in name_map.items()}


def _df_rows_to_dict_list(row, columns_prefix):
    columns = row.filter(regex='^{}_.*$'.format(columns_prefix)).index
    dict_list = []
    for i in range(0, columns.size // 2):
        dic = {}
        for col_name in row.filter(regex='^{}_{}.*$'.format(columns_prefix, i)).index:
            token = col_name.split('_')
            value = row[col_name]
            row.drop(index=col_name, inplace=True)
            if isinstance(value, str) and not value.strip():
                continue
            dic[token[2]] = value
        if dic:
            dict_list.append(dic)
    return dict_list



@admin_bp.route('/nonprofits', methods=['GET'])
@require_admin_permission
def admin_list_nonprofits():
    nonprofit_list = list(db().coll_nonprofits.find(request.filter_params).skip(request.skip).limit(request.page_size).sort(request.sort_params))

    # store in array once cursor can loop only once
    programs_count = list(db().coll_programs.aggregate([
        {'$match': {'nonprofit': {'$exists': True, '$ne': None}}},
        {'$group': {
            '_id': '$nonprofit',
            'count': {'$sum': 1}
        }}
    ]))

    def enhance_nonprofit(nonprofit_obj):
        for row in programs_count:
            if row['_id'] == nonprofit_obj['_id']:
                nonprofit_obj['programCount'] = row['count']

        if 'programCount' not in nonprofit_obj:
            nonprofit_obj['programCount'] = 0

        return nonprofit_obj

    return jsonify([enhance_nonprofit(nonprofit) for nonprofit in nonprofit_list])


"""
check or update nonprofit validity status
example: /admin/nonprofit:validate?include_invalid=true&include_diff=true&update_validity_status=true
"""
@admin_bp.route('/nonprofit:validate', methods=['POST'])
@require_admin_permission
def validate_nonprofits():
    results = {
        'invalid': [],
        'valid': [],
        'diff': [],
    }

    overwrite = request.args.get('update_validity_status') == 'true'
    include_diff = request.args.get('include_diff') == 'true'
    include_invalid = request.args.get('include_invalid') == 'true'
    include_valid = request.args.get('include_valid') == 'true'

    nonprofits = get_documents('mm_nonprofits')
    for npo in nonprofits:
        has_naf = len(npo.get('nonprofitSubmissionId', '')) != 0
        schema = schema_nonprofit_v2 if has_naf else schema_nonprofit_v1
        is_valid = v.validate(npo, schema)

        if include_valid and is_valid:
            results['valid'].append({'_id': npo['_id']})

        if include_invalid and not is_valid:
            results['invalid'].append({'_id': npo['_id'], 'details': v.errors})

        if is_valid != npo.get('isValid'):
            if include_diff:
                results['diff'].append({'_id': npo['_id'], 'previous': npo['isValid'], 'current': is_valid})

            if overwrite:
                update_document_by_id('mm_nonprofits', str(npo['_id']), {'isValid': is_valid})

                npo['isValid'] = is_valid
                set_children_and_grandchildren_is_valid_of_nonprofit(npo)

    return jsonify(results)


@admin_bp.route('/nonprofits/<id>', methods=['GET'])
@require_admin_permission
def get_nonprofit_by_id(id):
    validate_object_id(id, 'mm_nonprofits')
    nonprofit = get_document_by_id('mm_nonprofits', id)
    clean_nonprofits(nonprofit)
    set_progress(nonprofit.get('mpa', {}))

    # set default mpa status to signature pending
    if nonprofit.get('mpa') is None:
        nonprofit['mpa'] = {
            'status': 'SIGNATURE_PENDING',
        }

    return jsonify(nonprofit)


@admin_bp.route('/nonprofits/<id>', methods=['PATCH'])
@require_admin_permission
def patch_nonprofit(id):
    validate_object_id(id, 'mm_nonprofits')
    patch_request = request.get_json()
    if not patch_request:
        raise UnsupportedPayload()

    patch_request.pop('createdAt', None)
    updated_document = db().coll_nonprofits.find_one_and_update({'_id': ObjectId(id)},
                                                           {'$set': set_last_updated(patch_request)},
                                                           return_document=ReturnDocument.AFTER)

    schema_nonprofit = schema_nonprofit_v2
    if len(updated_document.get('nonprofitSubmissionId', '')) == 0:
        schema_nonprofit = schema_nonprofit_v1

    updated_document['name'] = updated_document['general']['name']['publicOrganizationName']
    updated_document['isValid'] = v.validate(updated_document, schema_nonprofit)
    updated_document = db().coll_nonprofits.find_one_and_update({'_id': ObjectId(id)},
                                                                {'$set': set_last_updated(updated_document)},
                                                                return_document=ReturnDocument.AFTER)

    set_children_and_grandchildren_is_valid_of_nonprofit(updated_document)
    clean_nonprofits(updated_document)

    return jsonify(updated_document)


@admin_bp.route('/nonprofits/<id>', methods=['PUT'])
@require_admin_permission
def update_nonprofit(id):
    validate_object_id(id, 'mm_nonprofits')
    put_request = request.get_json()
    if not put_request:
        raise UnsupportedPayload()

    errors = validate_schema(completed_form_schema, put_request)
    if len(errors) > 0:
        current_app.logger.warning('Nonprofit validation error: %s', v.errors)

    schema_nonprofit = schema_nonprofit_v2
    if len(put_request.get('nonprofitSubmissionId', '')) == 0:
        schema_nonprofit = schema_nonprofit_v1

    put_request['name'] = put_request['general']['name']['publicOrganizationName']
    put_request['_id'] = ObjectId(id)
    put_request['isValid'] = v.validate(put_request, schema_nonprofit)

    db().coll_nonprofits.replace_one(filter={'_id': ObjectId(id)}, replacement=set_last_updated(put_request))

    set_children_and_grandchildren_is_valid_of_nonprofit(put_request)
    remove_nonprofit_programs_from_blacklisted_brands(put_request)
    remove_invalid_nonprofit_programs_from_deals(put_request)

    clean_nonprofits(put_request)

    return jsonify(put_request)

@admin_bp.route('/nonprofits/<id>', methods=['DELETE'])
@require_admin_permission
def delete_nonprofit(id):
    validate_object_id(id, 'mm_nonprofits')

    deleted_document = db().coll_nonprofits.find_one_and_delete({'_id': ObjectId(id)})
    if not deleted_document:
        raise EntityNotFound(entity_name, id)

    deleted_document.update({'isValid': False})

    remove_nonprofit_from_programs(deleted_document)
    return jsonify(deleted_document)


# asset constants
GENERIC_UPLOADS = ['videoFallback']

@admin_bp.route('/nonprofits/<id>/upload', methods=['POST'])
@require_admin_permission
def nonprofit_upload_file(id):
    if 'file' not in request.files:
        return current_app.response_class(
            response="No file sent",
            status=400)  # Bad Request

    file = request.files['file']
    if file.name == '':
        return current_app.response_class(
            response="No file sent",
            status=400)  # Bad Request

    if 'field' not in request.form:
        return create_validation_error_response('field')

    field = request.form['field']
    is_public = to_bool(request.form['isPublic'])
    url = upload_file(file, 'nonprofits/%s/%s' % (id, secure_filename(file.filename)), is_public)

    db_document = db().coll_nonprofits.find_one({'_id': ObjectId(id)})

    # videoFallback only has the URL stored
    if field in GENERIC_UPLOADS:
        set_descendant_key(url, db_document, field)
    else: # structure of nonprofit submission fields are formatted with both name and url fields
        field_data = {'name': file.filename, 'url': url}
        set_descendant_key(field_data, db_document, field)

    schema_nonprofit = schema_nonprofit_v2
    if len(db_document.get('nonprofitSubmissionId', '')) == 0:
        schema_nonprofit = schema_nonprofit_v1

    db_document['isValid'] = v.validate(db_document, schema_nonprofit)

    if v.errors:
        current_app.logger.warning('Nonprofit validation error: %s', v.errors)

    # remove not mapped fields
    db_document = v.normalized(db_document, schema_nonprofit)
    if v.errors:
        raise ValidationError(v.errors)

    db().coll_nonprofits.update_one({'_id': ObjectId(id)},
                               {'$set': set_last_updated(db_document)})

    return jsonify(db_document)


@admin_bp.route('/nonprofits/<id>/<field>/<file_name>', methods=['DELETE'])
@require_admin_permission
def delete_nonprofit_asset(id, field, file_name):
    validate_object_id(id, 'mm_nonprofits')

    payload = request.get_json()
    is_public = to_bool(payload.get('isPublic'))

    document = db().coll_nonprofits.find_one({'_id': ObjectId(id)})

    # files are stored as {'name' : name, 'url': path_to_url}
    url_path = field if field in GENERIC_UPLOADS else f'{field}.url' 

    value = get_descendant_key(document, url_path, None)

    # check if requested field exits on document
    # and check if file_name is equivalent to what is stored in the DB
    if not value:
        raise GivewithError('Field {0} not found in document {1}'.format(url_path, id), code=404)
    elif not value.endswith(file_name):
        raise GivewithError('File {0} on document {1} is not on field {2}'.format(file_name, id, field))

    # tries to delete the file
    if not delete_file('nonprofits', id, file_name, is_public):
        raise GivewithError('Unable to delete {0} of document {1}'.format(file_name, id))

    schema_nonprofit = schema_nonprofit_v2
    if len(document.get('nonprofitSubmissionId', '')) == 0:
        schema_nonprofit = schema_nonprofit_v1

    pop_descendant_key(document, field, None)

    document['isValid'] = v.validate(document, schema_nonprofit, update=True)

    db().coll_nonprofits.replace_one(filter={'_id': ObjectId(id)}, replacement=set_last_updated(document))

    set_children_and_grandchildren_is_valid_of_nonprofit(document)

    return jsonify(document)


