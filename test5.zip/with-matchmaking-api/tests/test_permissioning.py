# pylint: disable-msg=redefined-outer-name
import json
from datetime import datetime, timedelta
from functools import partial
from typing import Dict, List

import jwt
import pytest
from bson import ObjectId
from flask import Blueprint, jsonify

from matchmaking.auth import authenticate_request
from matchmaking.models.models import RBACGroup as g
from matchmaking.permissioning.config import can, init_enforcer
from matchmaking.permissioning.constants import Action as a
from matchmaking.permissioning.policies import POLICY_DEFINITIONS, ROLE_DEFINITIONS, convert_groupings_to_role_defs

from .conftest import TOKEN_PRIVATE_KEY


# DEFINE TESTING ENDPOINTS
test_bp = Blueprint('rbac_test', __name__)
sample_response = {'success': 'ok'}


@test_bp.route('/', methods=['POST'])
@can(a.CREATE)
def create():
    return jsonify(sample_response)


@test_bp.route('/', methods=['GET'])
@can(a.READ)
def get():
    return jsonify(sample_response)


@test_bp.route('/', methods=['PUT'])
@can(a.UPDATE)
def edit():
    return jsonify(sample_response)


@test_bp.route('/', methods=['DELETE'])
@can(a.DELETE)
def delete():
    return jsonify(sample_response)


@pytest.fixture(scope='module')
def rbac_client(client):
    test_bp.before_request(partial(authenticate_request, client.application))
    client.application.register_blueprint(test_bp, url_prefix='/rbac_test')

    return client


class TestAccess:
    # test RBAC groups
    READ_ONLY, READ_UPDATE, MANAGE = 'read_only', 'read_update', 'manage'

    test_role_defs = convert_groupings_to_role_defs({
        READ_ONLY: (g.READER, ),
        READ_UPDATE: (g.READER, g.UPDATER),
        MANAGE: (g.READER, g.CREATOR, g.UPDATER, g.DELETER),
    })

    users_lookup = {
        READ_ONLY: {'_id': 0, 'roles': [READ_ONLY]},
        READ_UPDATE: {'_id': 1, 'roles': [READ_UPDATE]},
        MANAGE: {'_id': 2, 'roles': [MANAGE]},

        # hybrid-users
        'read_update_creator': {'_id': 3, 'roles': [READ_UPDATE, str(g.CREATOR)]},
        'superuser': {'_id': 4, 'roles': ['superuser']}
    }

    user_org_id = ObjectId()
    tokens = {} # populated during set-up


    @classmethod
    def get_cognito_id(cls, _id: int) -> str:
        return f'ada757d2-f4c9-416f-9c2b-ccbd94ef3017{_id}'


    def make_user(self, _id: int, roles: List) -> Dict:
        return {
            'name': 'Shanyan Jiang',
            'username': 'tech' + str(_id) +'@givewith.com',
            'cognito-id': self.get_cognito_id(_id),
            'orgId': self.user_org_id,
            'roles': roles,
        }


    def create_token(self, _id: int) -> str:
        now = datetime.now().timestamp()
        hour_later = (datetime.now() + timedelta(hours=1)).timestamp()

        claims = {
            'email': 'tech' + str(_id) +'@givewith.com',
            'sub': str(self.get_cognito_id(_id)),
            'event_id': '6e27b2d2-9b8d-425d-9c63-a060f512db5d',
            'token_use': 'access',
            'scope': 'impact',
            'auth_time': now,
            'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
            'exp': hour_later,
            'jti': 'b81e150e-4303-4663-ad46-c87adab94d63',
            'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
            'username': self.get_cognito_id(_id), # must match with user cognito id
            'orgId': str(self.user_org_id),
            'resource_ids': [
                '5c1415685b03bb0008c21b06'
            ]
        }

        return jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')


    @pytest.fixture(scope='class', autouse=True)
    def setup_test_users(self, test_db):
        # test brand
        test_db.mm_brands.insert_one({
            '_id': self.user_org_id,
            'name': 'Test brand',
            'featureFlags': {'rbac': True}
        })

        for user_label, user in self.users_lookup.items():
            test_db.user.insert_one(self.make_user(user['_id'], user['roles']))
            self.tokens[user_label] = self.create_token(user['_id'])

        yield
        for user in self.users_lookup.values():
            test_db.user.delete_one({'cognito-id': self.get_cognito_id(user['_id'])})

        test_db.mm_brands.delete_one({'_id': self.user_org_id})


    @pytest.fixture(scope='class', autouse=True)
    def setup_reinit_rbac_enforcer(self):
        init_enforcer(POLICY_DEFINITIONS + self.test_role_defs)

        yield
        init_enforcer(POLICY_DEFINITIONS + ROLE_DEFINITIONS)


    @pytest.mark.parametrize('user_type, expected_status_codes', [
        (READ_ONLY, {'get': 200, 'post': 403, 'put': 403, 'delete': 403}),
        (READ_UPDATE, {'get': 200, 'post': 403, 'put': 200, 'delete': 403}),
        (MANAGE, {'get': 200, 'post': 200, 'put': 200, 'delete': 200}),
        ('read_update_creator', {'get': 200, 'post': 200, 'put': 200, 'delete': 403}),
    ])
    @pytest.mark.parametrize('method', ['get', 'post', 'put', 'delete'])
    def test_user_access(self, rbac_client, user_type, method, expected_status_codes):
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': self.tokens[user_type],
            'Origin': 'https://impact.givewith.com',
        }
    
        response = getattr(rbac_client, method)(f'/rbac_test/', headers=headers)
        assert response.status_code == expected_status_codes[method]
    
        if response.status_code == 200:
            assert json.loads(response.data.decode()) == sample_response
    
    
    @pytest.mark.parametrize('method', ['get', 'post', 'put', 'delete'])
    def test_superuser_access(self, method, rbac_client):
        headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': self.tokens['superuser'],
            'Origin': 'https://impact.givewith.com',
        }
    
        response = getattr(rbac_client, method)(f'/rbac_test/', headers=headers)
        assert response.status_code == 200
        assert json.loads(response.data.decode()) == sample_response
