from flask import request
from bson import ObjectId
from flask_restx import Namespace, Resource
from flask_accepts import accepts, responds
from typing import Dict, List
from werkzeug.exceptions import NotFound, BadRequest, Forbidden

from portal.features.instances.schema import InstanceSettingsRequest, InstanceSettingsResponse, \
    InstanceSettingsSearchRequest, InstanceSettingsSearchResponse
from portal.shared.auth.requests import role_required, token_required
from portal.shared.enums import UserRole, InstanceStatus
from portal.shared.repositories import instance_settings_repository, account_repository
from portal.features.instances.validators import InstanceValidator
from portal.shared.auth.security import has_role
from portal.shared.constants import GIVEWITH_ROLES


namespace = Namespace('instance-settings', description='Instance related operations')


@namespace.route('')
@namespace.doc(responses={400: 'Bad Request'})
class InstanceSettings(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(query_params_schema=InstanceSettingsSearchRequest, api=namespace)
    @responds(schema=InstanceSettingsSearchResponse, api=namespace)
    def get(self):
        """Search Instance Settings"""
        params = request.parsed_query_params
        total_count, instances = instance_settings_repository().get_page(params)
        return {
            'totalCount': total_count,
            'results': instances
        }

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=InstanceSettingsRequest, api=namespace)
    @responds(schema=InstanceSettingsResponse, api=namespace)
    @namespace.response(502, 'An error occurred while attempting to create an instance')
    def post(self):
        """Create Instance Settings"""
        instance_request = request.parsed_obj
        validator = InstanceValidator(instance_request)
        validator.validate_instance_name()
        validator.validate_active_instance()
        instance = instance_settings_repository().insert(instance_request, request.user['username'])
        return instance


@namespace.route('/<id>')
@namespace.response(400, 'Bad Request')
@namespace.response(404, 'Instance not found')
class InstanceSettingsById(Resource):
    @token_required
    @responds(schema=InstanceSettingsResponse, api=namespace)
    def get(self, id: str):
        """Get Instance Settings by ID"""
        instance = self._get(id)
        return instance

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=InstanceSettingsRequest, api=namespace)
    @responds(schema=InstanceSettingsResponse, api=namespace)
    def put(self, id: str):
        """Update Instance Settings by ID"""
        instance = self._get(id)
        update = request.parsed_obj
        validator = InstanceValidator(update, instance)
        validator.validate_instance_name()
        validator.validate_active_instance(True)
        instance.update(update)
        instance = instance_settings_repository().update(instance, request.user['username'])
        return instance

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN])
    @accepts(schema=InstanceSettingsRequest(partial=True), api=namespace)
    @responds(schema=InstanceSettingsResponse, api=namespace)
    def patch(self, id: str):
        """Update Instance Settings from Partial"""
        instance = self._get(id)
        _validate_access(instance)
        update = self._validate_update_request(request.parsed_obj)
        validator = InstanceValidator(update, instance)
        validator.validate_instance_name()
        validator.validate_active_instance()
        # specify set_arrays=True to ensure arrays get updated correctly, e.g. skus, restrictedDomains
        instance = instance_settings_repository().patch(id, update, request.user['username'], set_arrays=True)
        return instance

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @responds(schema=InstanceSettingsResponse, api=namespace)
    def delete(self, id: str):
        """Deactivate Instance"""
        instance = self._get(id)
        update = {
            'status': InstanceStatus.INACTIVE.value
        }
        instance = instance_settings_repository().patch(id, update, request.user['username'])
        return instance

    def _get(self, id):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        instance = instance_settings_repository().get_single(id)
        if not instance:
            raise NotFound('Instance not found')
        return instance

    def _validate_update_request(self, params: Dict) -> Dict:
        '''org admin can only update restrictedDomains'''
        if has_role([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS], request.user):
            return params
        # Tuple of fields allowed for role to update, will also give access to all child fields if not listed out
        allowed_fields = tuple(_get_field_paths({
            'restrictedDomains': '1',
        }, []))
        fields = _get_field_paths(params, [])
        for field in fields:
            if not field.startswith(allowed_fields):
                raise Forbidden('You do not have permission to update this resource')
        return params


def _validate_access(instance):
    account = account_repository().get_single(request.user['accountId'])
    if not has_role(GIVEWITH_ROLES, request.user) and instance['_id'] != account['instance']['_id']:
        raise Forbidden('You do not have permission to access this resource')


def _get_field_paths(dic: dict, fields: list, parent_key='') -> List[str]:
    for key in dic:
        value = dic.get(key)
        if len(parent_key) > 0:
            key = parent_key + '.' + key
        if isinstance(value, dict):
            _get_field_paths(value, fields, key)
        else:
            fields.append(key)
    return fields
