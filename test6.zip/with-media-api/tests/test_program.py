import json

### GET HERO IMAGE FOR ONE PROGRAM ###
def test_program_hero_invalid_param(client, client_header):
    response = client.get('/program/not-a-slug-or-id/hero', headers=client_header)
    assert response.status_code == 404

def test_program_hero(client, admin_header, client_header, invalid_header):
    response = client.get('/program/5c387b71a08c41000a179495/hero', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/program/5c387b71a08c41000a179495/hero', headers=client_header)
    assert response.status_code == 200

    response = client.get('/program/5c387b71a08c41000a179495/hero', headers=invalid_header)
    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert 'imageLandscape' in data
    assert 'imagePortrait' in data

### GET LIST OF HERO IMAGES ###
def test_program_hero_list_wrong_body(client, client_header):
    response = client.post('/program/list-of-heros', data=json.dumps({'wrongField' : ['oops']}), headers=client_header)
    assert response.status_code == 404

def test_program_hero_list(client, admin_header, client_header, invalid_header):
    programs = {'_ids' : ['5c387b71a08c41000a179495', '5bf3201e0f36530008cffc46', '5b918c868553ef0007f76022']}

    response = client.post('/program/list-of-heros', data=json.dumps(programs), headers=admin_header)
    assert response.status_code == 200

    response = client.post('/program/list-of-heros', data=json.dumps(programs), headers=client_header)
    assert response.status_code == 200

    response = client.post('/program/list-of-heros', data=json.dumps(programs), headers=invalid_header)
    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert '5c387b71a08c41000a179495' in data
    assert 'imageLandscape' in data.get('5c387b71a08c41000a179495')
    assert 'imagePortrait' in data.get('5c387b71a08c41000a179495')
    assert '5bf3201e0f36530008cffc46' in data
    assert '5b918c868553ef0007f76022' in data

