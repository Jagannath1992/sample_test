from _decimal import Decimal
from datetime import datetime, date
from bson import ObjectId
from pymongo.cursor import Cursor
from flask.json import JSONEncoder


class CustomJSONEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        elif isinstance(obj, bytes):
            return str(obj, 'utf-8')
        elif isinstance(obj, Cursor):
            return [self.default(i) for i in obj]
        elif isinstance(obj, Decimal):
            return float(obj)
        elif isinstance(obj, (datetime, date)):
            return obj.strftime('%Y-%m-%dT%H:%M:%S.%fZ')
        return JSONEncoder.default(self, obj)
