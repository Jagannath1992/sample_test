from flask import request


def validate_sf_auth_payload():
    errs = []

    if not request.get_json():
        return ['invalid request']

    namespace = request.json.get('namespace')
    if not namespace:
        errs.append('namespace is required')
    else:
        if not isinstance(namespace, str):
            errs.append('invalid namespace')

    instance_url = request.json.get('instance_url')
    if not instance_url:
        errs.append('instance_url is required')
    else:
        if not isinstance(instance_url, str) or not instance_url.startswith('http'):
            errs.append('invalid instance_url')

    org_id = request.json.get('orgId')
    if not org_id:
        errs.append('orgId is required')
    else:
        if not isinstance(org_id, str):
            errs.append('invalid orgId')

    refresh_token = request.json.get('refreshToken')
    if not refresh_token:
        errs.append('refreshToken is required')
    else:
        if not isinstance(refresh_token, str):
            errs.append('invalid refreshToken')

    return errs
