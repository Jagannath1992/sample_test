from app.rest.cognito_authorize import *
from app.service.cognito import change_password

user_bp = Blueprint('user', __name__)
revoke_bp = Blueprint('revoke', __name__)

"""
@api {post} /user/change_password Change User Password
@apiName ChangePassword
@apiGroup User
@apiDescription Change user's password

@apiError 400 Bad request

@apiParam {String="NEW_PASSWORD_REQUIRED"} challenge_name challenge name
@apiParam {String} family_name the user's family name
@apiParam {String} given_name the user's given name
@apiParam {String} new-password the new password
@apiParam {String} session the session
@apiParam {String} username the user's username

@apiParamExample {json} Change password example:
{
    "challenge_name": "NEW_PASSWORD_REQUIRED"
    "family_name": "family"
    "given_name": "given"
    "new-password": "new password"
    "session": "O-zG3cpmXljNxQQegNC0rxQjXjrz5sPm7..."
    "username": "family.given@givewith.com"
}

@apiSuccessExample {json} Success change password response example:
{
    "expires":3600,
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZGE3NTdkMi1m...",
    "token_type":"Bearer"
    "refresh_token":"eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.r-Ss4DOOh0DAvdpLkIe1u6-...",
}

"""
@user_bp.route('/change_password', methods=['POST'])
def change_user_password():
    challenge_name = request.json.get('challenge_name')
    family_name = request.json.get('family_name')
    given_name = request.json.get('given_name')
    new_password = request.json.get('new-password')
    sessions = request.json.get('session')
    username = request.json.get('username')

    user = get_db().user.find_one({'username': username})
    if user is None:
        return error_response(404, 'username %s not found' % username)

    max_scope = get_max_scope(user, '')

    try:
        response = change_password(challenge_name, sessions, username, new_password, given_name, family_name)
        access_token = response['AuthenticationResult']['AccessToken']
        refresh_token = response['AuthenticationResult']['RefreshToken']

        payload = jwt.decode(access_token, verify=False)
        payload['scope'] = max_scope
        payload['resource_ids'] = [str(user.get('orgId', ""))]
        payload['version'] = version
        payload['user_id'] = str(user['_id'])
        payload['email'] = str(user['username'])

        user.pop('username', None)
        payload.update(user)
        payload.pop('phoneNumber', None)
        payload.pop('notes', None)
        payload.pop('businessAddress', None)
        payload.pop('password', None)

        access_token = jwt.encode(payload, PRIVATE_KEY, algorithm='HS256', json_encoder=JSONEncoder.CustomJSONEncoder)

        save_refresh_token(user, refresh_token, max_scope, payload)
        update_user_last_login(username)

        return {
            'token': access_token.decode(),
            'refresh_token': refresh_token,
            'token_type': 'Bearer',
            'ExpiresIn': 3600
        }
    except Exception as e:
        return error_response(401, str(e))


"""
@api {post} /revoke/user/:user_name Revoke User
@apiName RevokeUser
@apiGroup Revoke
@apiDescription Revoke refresh tokens assigned to user

@apiParam {user_name} user_name the name of the user.

@apiSuccess {String} deleteCount number of refresh token deleted.
@apiSuccessExample {json} Success revoke user response example:
{
    "deleteCount": 10
}
"""
@revoke_bp.route('/user/<user_name>', methods=['POST'])
def revoke_user(user_name):
    result = get_db().refresh_token_scope.delete_many({'username': user_name})
    return {'deleteCount': result.deleted_count}

"""
@api {post} /revoke/user-integration Revoke User Integration
@apiName RevokeUserIntegration
@apiGroup Revoke
@apiDescription Revoke refresh tokens on integrations

@apiParam {String} refresh_token - refresh Token used for the integration

@apiParamExample {json} Revoke User Integration Example:
{
    "refresh_token":"eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUlNBLU9BRVAifQ.r-Ss4DOOh0DAvdpLkIe1u6-...",
}

@apiSuccess {Boolean} success 
@apiSuccessExample {json} Success revoke user response example:
{
    "success": True
}
"""
@revoke_bp.route('/user-integration', methods=['POST'])
def revoke_user_integration():
    refresh_token = request.json.get('refresh_token')

    try:
        # Create Collection string to remove integration from
        integration_scope = get_db().refresh_token_scope_integrations.find_one()
        platform = integration_scope['platform']
        platform_collection = platform + '_auth_payload'
        # Remove from collection that the refresh token platform is associated with
        result_auth_revoke = get_db()[platform_collection].delete_many({'refreshToken': refresh_token})
        # Remove from main integration token scope collection
        result = get_db().refresh_token_scope_integrations.delete_many({'refresh_token': refresh_token})

        return {'success': True}
    except Exception as e:
        return error_response(401, str(e))