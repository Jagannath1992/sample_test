cd /home/ec2-user/deployment
./beforeinstall.sh
touch /home/ec2-user/.bashrc
cd /home/ec2-user/
chown -R ec2-user /home/ec2-user/.local/lib/python3.7/site-packages
export PATH=$PATH:/home/ec2-user/.local/bin
su ec2-user -c 'pip3 install pip-tools --user'
su ec2-user -c 'pip-sync requirements.txt --pip-args "--no-cache-dir"'
su ec2-user -c 'FLASK_DEBUG=1 FLASK_ENV=development FLASK_APP=main.py flask run -p 5051 --host=0.0.0.0'
tail -f /dev/null
