import pymongo
from datetime import datetime
"""
Update cause areas with Sage vendor IDs
"""
name = '20220623202116'
dependencies = ['20220619193209']


def upgrade(db: pymongo.database.Database):
    now = datetime.utcnow()

    db['cause_area'].find_one_and_update(
        {"name": "Plant a tree"},
        {"$set": {
            "partnerName": "Arbor Day Foundation",
            "sageVendorId": "V-585",
            "skuPrefix": "1289",
            "createdBy": "admin@givewith.com",
            "createdAt": now,
            "lastUpdatedBy": "admin@givewith.com",
            "lastUpdated": now
        }}
    )

    db['cause_area'].find_one_and_update(
        {"name": "Promote STEM education for girls"},
        {"$set": {
            "partnerName": "Techbridge Girls",
            "sageVendorId": "V-586",
            "skuPrefix": "1786",
            "createdBy": "admin@givewith.com",
            "createdAt": now,
            "lastUpdatedBy": "admin@givewith.com",
            "lastUpdated": now
        }}
    )

    db['cause_area'].find_one_and_update(
        {"name": "Fight child hunger"},
        {"$set": {
            "partnerName": "No Kid Hungry (Share our Strength)",
            "sageVendorId": "V-587",
            "skuPrefix": "1431",
            "createdBy": "admin@givewith.com",
            "createdAt": now,
            "lastUpdatedBy": "admin@givewith.com",
            "lastUpdated": now
        }}
    )

    db['cause_area'].find_one_and_update(
        {"name": "Make mental health screening available"},
        {"$set": {
            "partnerName": "Mental Health America",
            "sageVendorId": "V-588",
            "skuPrefix": "0172",
            "createdBy": "admin@givewith.com",
            "createdAt": now,
            "lastUpdatedBy": "admin@givewith.com",
            "lastUpdated": now
        }}
    )


def downgrade(db: pymongo.database.Database):
    pass
