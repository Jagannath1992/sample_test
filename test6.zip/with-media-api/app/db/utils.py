#pylint: disable=dangerous-default-value
from datetime import datetime

from bson.objectid import InvalidId, ObjectId
from pymongo import ReturnDocument

from .database import get_db

# keys that should never be changed
DEFAULT_BLACKLIST = ['createdAt', 'createdBy', 'slug', '_id']


def get_document(collection, query={}, **kwargs):
    '''
    Get a single document by query with optional kwargs
    '''
    return get_db()[collection].find_one(query, **kwargs)


def get_document_by_id(collection, document_id, **kwargs):
    '''
    Get a single document by ObjectId with optional kwargs
    '''
    if isinstance(document_id, str):
        try:
            document_id = ObjectId(document_id)
        except InvalidId:
            return None

    return get_db()[collection].find_one({'_id': document_id}, **kwargs)


def get_documents(collection, query={}, **kwargs):
    '''
    get all documents by query with optional kwargs
    '''
    return get_db()[collection].find(query, **kwargs)


def add_document(collection, document):
    '''
    add document to a collection
    '''
    document['_id'] = get_db()[collection].insert_one(document).inserted_id

    return document


def update_document_by_id(collection, _id, changes, blacklist=[], upsert=True):
    '''
    partially update document by id
    '''
    return update_document(collection, {'_id': ObjectId(_id)}, changes, blacklist, upsert)


def update_document(collection, find, updates, blacklist=[], upsert=True):
    '''
    partially update document
    '''
    if not updates.get('lastUpdated'):
        updates['lastUpdated'] = datetime.utcnow()
    updates = pop_blacklist_keys(updates, blacklist)

    return get_db()[collection].find_one_and_update(
        find, {'$set': updates}, upsert=upsert, return_document=ReturnDocument.AFTER
    )


def aggregate_on(collection, pipeline):
    '''
        Run an aggregation pipeline on a collection
    '''
    return get_db()[collection].aggregate(pipeline)


def pop_blacklist_keys(changes, blacklist=[]):
    '''
    Remove blacklist keys from changes dict
    '''
    blacklist += DEFAULT_BLACKLIST
    for key in changes.copy():
        if key in blacklist:
            changes.pop(key)

    return changes
