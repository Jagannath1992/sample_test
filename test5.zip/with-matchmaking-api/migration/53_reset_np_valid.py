from matchmaking import db

nonprofits = list(db().coll_nonprofits.find({}))

for nonprofit in nonprofits:
    if nonprofit.get('isValid', False) and len(nonprofit.get('description', '')) > 0:
        nonprofit['isValid'] = False

