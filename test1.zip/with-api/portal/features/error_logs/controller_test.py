import pytest
from portal.features.error_logs.schema import ErrorLogResponse, ErrorLogSearchResponse
from portal.shared.enums import UserRole
from portal.shared.repositories import error_log_repository


class TestErrorLog:
    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS], indirect=True)
    def test_get(self, client, custom_auth_header, mocker, fakers, frozen_utcnow):
        # arrange
        error_logs = fakers.error_log.generate_many(2)
        mocker.patch.object(error_log_repository(), 'get_page', return_value=(2, error_logs))
        expected = ErrorLogSearchResponse().dump({
            'totalCount': 2,
            'results': error_logs
        })

        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10
        }

        # act
        response = client.get('/error-logs', query_string=query_params, headers=custom_auth_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected


class TestErrorLogById:
    @pytest.fixture
    def test_by_id_init(self, fakers):
        error_log = fakers.error_log.generate_single()
        return error_log

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS], indirect=True)
    def test_get(self, client, custom_auth_header, test_by_id_init, mocker, frozen_utcnow):
        # arrange
        error_log = test_by_id_init
        error_log['createAt'] = frozen_utcnow
        mocker.patch.object(error_log_repository(), 'get_single', return_value=error_log)
        expected_error_log = {
            '_id': str(error_log['_id']),
            'createdBy': error_log['createdBy'],
            'createdAt': frozen_utcnow,
            'description': error_log['description'],  # internal
            'source': error_log['source'],
            'account': error_log['account'],
            'messages': error_log['messages'],       # 3rd party / web
            'order': error_log['order'],
            'transaction': error_log['transaction'],
            'isResolved': False,
            'resolvedBy': None,
            'resolvedAt': None
        }
        # act
        response = client.get('/error-logs/some_id', headers=custom_auth_header)

        # assert
        assert response.status_code == 200
        assert response.json == ErrorLogResponse().dump(expected_error_log)

    @pytest.mark.parametrize('custom_auth_header', [UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS], indirect=True)
    def test_patch(self, client, custom_auth_header, test_by_id_init, mocker, frozen_utcnow):
        # arrange
        error_log = test_by_id_init
        error_log['createAt'] = frozen_utcnow
        error_log.update({
            'isResolved': True,
            'resolvedBy':  'resolvedBy1@example.com',
            'resolvedAt': frozen_utcnow
        })
        mocker.patch.object(error_log_repository(), 'exists', return_value=True)
        mocker.patch.object(error_log_repository(), 'patch', return_value=error_log)
        request = {
            'isResolved': True,
            'resolvedBy':  'resolvedBy1@example.com',
            'resolvedAt': frozen_utcnow
        }

        # act
        response = client.patch(f'/error-logs/{error_log["_id"]}', json=request, headers=custom_auth_header)

        # assert
        assert response.status_code == 200
        assert response.json == ErrorLogResponse().dump(error_log)
