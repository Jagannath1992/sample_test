import json
import requests

from bson import ObjectId
from typing import Dict, Any
from werkzeug.exceptions import BadRequest, BadGateway

from portal.shared.email.validator import EmailValidator
from portal.shared.encoder import CustomJSONEncoder
from portal.shared.enums import AccountType, InstanceType, UserRole
from portal.shared.flags.service import FlagService
from portal.shared.repositories import user_repository, instance_settings_repository, account_approval_repository, account_repository
from portal.shared.constants import CUSTOMER_ROLES


class AuthService:
    def __init__(self, config: dict):
        self.base_url = config["base_url"]
        self.okta_endpoint = f'{self.base_url}/v1/okta/user'

    def create_user(self, payload, accountId: ObjectId, error_message: str, by: str = None):
        if by:
            payload['createdBy'] = by
            payload['lastUpdatedBy'] = by
        response = requests.post(
            self.okta_endpoint,
            json=json.loads(json.dumps(payload, cls=CustomJSONEncoder))
        )
        if response.status_code != 200:
            raise BadGateway(error_message)
        userId = response.json()['_id']
        user = user_repository().patch(userId, {'accountId': accountId})
        return user

    def update_user(self, user_id: int, payload, by: str = None):
        if by:
            payload['lastUpdatedBy'] = by
        return requests.put(
            f'{self.okta_endpoint}/{user_id}',
            json=json.loads(json.dumps(payload, cls=CustomJSONEncoder))
        )

    def resend_user_invite(self, payload):
        response = requests.post(
            f'{self.okta_endpoint}/resend-invite',
            json=json.loads(json.dumps(payload, cls=CustomJSONEncoder))
        )
        if response.status_code != 202:
            raise BadGateway('An error occurred while attempting to resend invite')
        return 'Success'


class RegistrationService:
    def __init__(self, flag_service: FlagService, auth_service: AuthService):
        self.flag_service = flag_service
        self.auth_service = auth_service

    def register_user(self, instance, account, user, by_username):
        restricted_domains = instance.get('restrictedDomains', [])
        # check for restricted domain
        if restricted_domains:
            email = EmailValidator().validate(user['username'])
            if email.domain not in restricted_domains:
                raise BadRequest('Restricted domain')

        # Check for duplicate company/domain
        if self._account_company_exists(user, account):
            raise BadRequest('An account already exists for this company')

        # Associate account to instance
        account['instance'] = {
            '_id': instance['_id'],
            '_type': 'instance_settings',
            'name': instance['name']
        }

        # Ensure correct account type
        if instance['type'] == InstanceType.PROCUREMENT.value and account['type'] == AccountType.DEFAULT.value:
            account['type'] = AccountType.PROCUREMENT.value

        # Create account record
        account = account_repository().insert(account, by_username)
        account_approval_repository().insert({'_id': account['_id'], 'levels': []}, by_username)

        if len(user.get('roles', [])) == 1 and UserRole.ORG_ADMIN.value in user['roles']:
            user['roles'] = CUSTOMER_ROLES

        try:
            # Create user record associated with account
            error_message = 'An error occurred while attempting to create the account'
            user = self.auth_service.create_user(user, account['_id'], error_message, by_username)
        except Exception as err:
            # Since we created an account, if we get a error we want to delete it
            account_repository().delete(account['_id'])
            account_approval_repository().delete(account['_id'])
            raise err

        return user, account

    def _account_company_exists(self, user: Dict[str, Any], account: Dict[str, Any]) -> bool:
        if self.flag_service.validate_domains():
            domain_exists = user_repository().domain_exists(user['username'])
            if domain_exists:
                return True
            company_exists = account_repository().company_exists(account['company']['name'])
            return company_exists
        return False
