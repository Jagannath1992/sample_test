from bson import ObjectId
from bson.errors import InvalidId

from ..mongodb import db
from ..utils import remove_none


def get_vocab_dict(value):
    try:
        return db().coll_vocabulary.find_one({'_id': ObjectId(value)}) or {}
    except InvalidId:
        return {}


def get_vocab_label(value):
    try:
        return get_vocab_dict(value).get('label', '').lower() or value
    except InvalidId:
        return value


def get_strength_keys(value):
    # returned value is expected to include None Values if selections do not have strengthKeys
    # expected to include duplicates as well
    if isinstance(value, list):
        return [get_vocab_dict(v).get('strengthKey') for v in value]
    else:
        return [get_vocab_dict(value).get('strengthKey')]


def get_valid_selection_count(selections):
    # Checks the selected options to ensure they are valid vocabularies
    return sum([1 if get_vocab_dict(selection) else 0 for selection in selections])


def calculate_program_strength_v2(program):
    strengths = set()

    # the following keys impact strength,
    # if the selected values for these keys have a strength, attached to it, the program should
    # be assigned the strength
    keys = [
        'causes',
        'programApproach',
        'evidenceDescription',
        'dataDescription'
    ]

    for key in keys:
        strength_keys = get_strength_keys(program.get(key))
        strengths.update(strength_keys)

    # other strengths are specified by different criteria

    # secondaryImpacts if program has 1 or more secondaryImpacts
    secondary_impacts = program.get('secondaryImpacts', [])
    if get_valid_selection_count(secondary_impacts) > 0:
        strengths.add('secondaryImpacts')

    # audienceAttribute if program has more than 1 audience selected
    audience_attributes = program.get('audienceAttribute', [])
    if get_valid_selection_count(audience_attributes) > 1:
        strengths.add('audienceAttribute')

    # oneOrMorePartnerOrganizations if answered yes/True to nonprofitPartners
    nonprofit_partners = program.get('nonprofitPartners')
    if nonprofit_partners is True:
        strengths.add('oneOrMorePartnerOrganizations')

    return remove_none(strengths)
