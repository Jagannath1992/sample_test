
# TAGGING PROGRAMS

<IMG SRC="./resources/tag.png" width=200>

"Tagging" is a bit of an incorrect and dated term for what we do here: this process is
more accurately referred to as __feature generation__, to pull us closer what we truly use it for, 
which is more akin to an Expert System for Recommendation with elements of Machine Learning, rather than 
the decidedly circa 2004-Web 2.0 implications of User Generated Content.  As an 
internal name, and it's historical usage, "tagging" is sufficient shorthand -- but for
public consumption I would argue using the term ends up selling us short. [@jnu 8.2019]



## Key Assumptions and Design Goals: 
* "Tagging" impacts non-profit programs in our system by taking data from a given non-profit program 
in `mm_programs` and correlates specific "tags"
in `mm_vocabulary` via `ObjectId`, based upon logic coded in this folder within this repo.
* This endpoints here are reachable only via internal services - not open on the public internet (if this
is *not true* at any  point, please add in auth to this endpoint or network level protections to this service).
* This implementation is focused on the following key design choices (esp. in response to the earlier 
_Google Sheets-to-Aggregations_ 
version from 2018 Work&Co):
  * We must be able to write code to embody the complex logic of our rules, and we must be able to 
  grow the complexity and detail of these rules to meet the needs of our Data and Social Impact teams, and,
  * This system must not rely on typo-prone, developer-keyed string matching -- that makes the entire system 
  too brittle and error prone, and,
  * We must be able to read these rules in a format with semantics as close as possible to English without 
  having to fuss with obscure `ObjectId` references, and,
  * Manual (human) validation of the rule implementation is very important, and verbose output of 
  rule-to-program logic must be available for review (_"why is this program tagged the way it is?"_), and,  
  * The level of abstraction originally designed in `mm_vocabulary` is fundamentally good, and with the addition of 
  versioning, can provide a framework for future growth and change, but,
  * The implementation of this vocabulary needs to be flexible to support edits (esp. renaming/additions) and rule changes, 
  at an anticipated rate of approximately every six to twelve months.
* Thus, the core design philosophy of this implementation embraces these features:
  * All `mm_vocabulary` objects are moved into run-time memory; and set as `CONSTANTS` in the code itself 
  (source: `constants/__init__.py`) as an auto-generated file (see endpoint: `/tagging/constants`), to take advantage 
  of IDE code completion. 
  * The vocabulary version (v1, v2, etc.) used for tagging is easily configurable, and more easily incremented as
  applied in tagging.
  * Errors in the code must not fail silently nor passively, we need to be aware when there are
  oddities in the process, and alerted appropriately.
  * Validating tag assignments and versioning is extensive, to best avoid errors with incorrect `ObjectId` references.
    * The validity of these constants can be:
        * Checked dynamically (see "What is this Validation thing?" to dynamically check - possible candidate for CI tests)
        * And also checked at run-time (see the `validate_terms` function which is called in the source for `utils.py` 
    for run-time checks - now setup to run in dev/staging only).


## Info about Tagging

Our Research and Social Impact teams develop rules that [look like this](https://docs.google.com/document/d/1nbfvNtGverNS-t0BtXlOIZayIRefwPUMhgT7ahwU1jY/edit).
As an example, here's the plain-language rule for SDG2 (version 2):

<IMG SRC="./resources/sdg2.png" width=591>

A rules document, like above, is then translated into code by a developer, and the same rule [looks like this](./sdg.py) 
in Python code (such as `sdg.py` or  `msci.py`, etc. -- I refer to this type of source file as *tagging_logic* 
file within this README):

<IMG SRC="./resources/sdg2_code.png" width=838>

## How to change tagging rules in an existing tagging logic file?

If you need to change the rules for a given datasource (such as `msci` or `sasb`, etc.), find that source file in this directory 
(`research_api/controllers/tagging/*.py`) and read the existing code, comparing it to the underlying rule set 
(found on Google Docs, for v2).  As noted above, you should rely __solely__ on 
constants for the terms and vocabulary you use to structure your rules -- the only strings defined in code
in a *tagging_logic* Python file should be for logging/debugging/exceptions.  

[Here is a screenshot](./resources/sasb.py) of the `sasb.py` source [as of 8/2019] taken in Pycharm (IDE) -- 
note that the green text is the only place we're actually adding strings in this source.  All the rules 
rely on `CONSTANTS` established in `research_api/controllers/tagging/constants/__init__.py`. _No manually added strings_!  
Instead, as a developer, you should rely on your IDE using auto-complete and auto-search to implement these 
constants into your code.

There are two important functions that are used in the rules:
 * `check_term`, which identifies a string (via a mapped constant, like `LOW_INCOME_POPULATIONS`) 
 and see if it's associated with this program (based on earlier processing of the program's metadata); 
    * multiple calls to `check_term` are used and paired with Python logic to continue if `True`.
    * ```python
        check_term(LOW_INCOME_POPULATIONS, VOCAB_AUDIENCES, tag_data) and ```

    * In this case, above, we're essentially saying (in code) "Look for the term 'Low Income Populations' in the Audience
    Attributes branch of the vocab data.  If this is present in this program, you can continue; but if not, you're done."
 * `add_feature`, which is triggered only when the rule conditions are met, apply a tag/feature to a non-profit program -- 
 in essence 'tagging' it for display on our platform and ingestion in our recommendation algorithm.  
 
 Outside of these functions in the rules, you're merely bound by the general control flow of Python syntax - thus 
 using parentheses, `or` and `and`, and all the other regular coding things you're used to.




## How to add a brand new source?

So, you've reviewed how to change the rules in an existing _tagging logic_ file, above -- it's not a giant leap
to author a new one.  There's really only a little bit more in one of these files, beyond the rules themselves --

<IMG SRC="./resources/sasb_annotated.png" width=400> 

The green and pink areas in this graphic show the limited areas beyond the rules -- and in these parts you could 
just about copy it verbatim (there are explanatory comments in this source example, too).  The local 
constant `_MY_SOURCE` needs to be set for your new datasource, and that should be mapped to a constant that maps the 
name of the datasource.  You'll also want to name the function something that fits your new datasource 
name (`tag_sasb` is the name of the function in this example; let's say you named your new function
   `tag_newdatasource`).  

If you just saved your new _tagging logic_ file to this directory, and let's say for example it's called `newdatasource.py`, 
you will also need to let the endpoint know that it exists so it can be called.   

In `__init__.py`, first import your new file and function at the very top. Based on our example thus far, you would then add
the following line:

```python
    from .newdatasource import tag_newdatasource
```
where `newdatasource.py` is your filename, and `tag_newdatasource` is the name of the function in that file.

Next, add in the new data source into the `TAG_TYPES` dict, where the key is the string name of the data source
(and also, the string that will be used in the endpoint request), and the value is the name of the function you just
added to the import.

```python
TAG_TYPES = {
    'CSR': tag_csrhub,
    'SASB': tag_sasb,
    'THEMES': tag_themes,
    'SDG': tag_sdg,
    'GRI': tag_gri,
    'MSCI': tag_msci
}
```


Remember how I said, rather casually, "You'll have to set the constant for `_MY_SOURCE`" without explaining where that
gets set?  Let's cover that now:

To match our paradigm thus far, you would be looking to set a value to `_MY_SOURCE` from a constant -- but we 
have a brand new data source named "Newdatasource", and thus we should expect to have `VOCAB_NEWDATASOURCE` available
as a constant.  But we don't -- it's new!  So what you could do (but you shouldn't) is to simply type that into the `constants/__init__.py`
file.  Why not?  Because we want to be able to dynamically generate/regenerate the constants as dynamic output from the 
`mm_vocabulary` collection.  So what to do?

First, add the new constant representing `newdatasource` into the file `utils.py`.  Look for the code that starts around:

```python
    constants_file = list()
    constants_file.append("## **** Loaded Vocabulary compatible with Version " + str(SELECTED_VOCABULARY_VERSION) + " ************")  # pylint: disable=line-too-long
    constants_file.append("VOCAB_CSRHUB = 'csrhub'")
```

and, you'll end up adding:

```python
    constants_file.append("VOCAB_NEWDATASOURCE = 'newdatasource'")
```

Note, then, that the string value here, `newdatasource`, is important as that will be the name of the dictionary that will 
be added to the program document after tagging.  Now you can hit the endpoint `tagging/constants` to regenerate 
all the constants at our disposal -- and copy the source of that view into the `constants/__init__.py` file.  (note: if you find
that the output of that file doesn't create valid Python constant names -- check out the note in the _miscellaneous addendum_
at the bottom of this document for how to tweak). 

To take advantage of the validation built into this repo, you should also add your new file name into the `__init__.py` 
file in this directory. Look for this code in the `validate` function:

```python
    result = dict()
    result["gri"] = validate_source("gri.py", vocabulary)
```

and your new file should get added, such that your new line looks like this:

```python
    result["newdatasource"] = validate_source("newdatasource.py", vocabulary)
```

When this is in place you can hit, via web or curl or otherwise, the endpoint `/tagging/validate`, which will confirm that
your constants are aligned with your vocab strings.  See **"What is this validation thing?"** to learn more about
what's going on here.

## How to test and debug?

First thing?  Just make sure that the endpoint `tagging/validate` returns happily.  A happy response should 
look something like this:

```python
{
  "csr_hub": "pass", 
  "gri": "pass", 
  "msci": "pass", 
  "sasb": "pass", 
  "sdg": "pass", 
  "themes": "pass"
}
```

In order to test - you can directly hit the tagging service and read the resulting JSON.  Note that the 
process will attempt to edit the relevant program directly in the database -- if it succeeds, your program will 
have new tags (congrats!).  Working on this locally, for example, and hitting a URL like this 
`http://localhost:5002/tagging/all/5b48c3ed2e9ec6001ae7aca6`, the result looks something like this:

```python
{
  "data": {
    "CSRHub": "complete", 
    "SASB": "complete", 
    "gri": "complete", 
    "msci": "complete", 
    "sdg": "complete", 
    "themes": "complete"
  }, 
  "status": "complete", 
  "status_code": 1
}
```

You can change `all` in the URL to be other values, such as `gri` or `msci`, to try processing it one-by-one.  And 
the final value in the URL is the `ObjectId` of a program (in the form of a 24-character hexadecimal string) -- so 
swap that to test, as well.

But, if something does go wrong and you don't get a happy message, but instead get an error or complaint -- 
let's talk about what happens:

* In `utils.py` there is a function called `critical_alert` which should be called 
when an exception is thrown in a _tagging logic_ file.  This will print all the
info that has been written into the `log` variable (which is a list that is used to accumulate messages throughout 
the process), and push it up to S3 (if you are in the right environment -- either, local or on staging).  
* If `critical_alert` is triggered, you can look in [this bucket on S3](https://s3.console.aws.amazon.com/s3/buckets/givewith-staging-logging-bucket/?region=us-east-1&tab=overview)
to find the file -- it should 
have a prefix of `TAGGING_ENVIRON` (where environ might be local or staging).  This
bucket has a 30 day expiry - so you will have ample time to dig into the
issue and review the output.
* Note, too, that `utils.py` has a call to `Cloudwatch` on error during tagging, called by `critical_alert`, 
so this can be tracked with an alarm to trigger PagerDuty or otherwise
proactively alert us to errors/exceptions as thrown by any of the _tagging logic_ files.

**So, what might go wrong?**  My best guess is that there
will be inconsistencies with vocabulary terms and IDs, resulting in reference errors. These might manifest as 
bugs in the UI (which is how we most often see them now), or result in curious results further down the data
pipeline, in recommendations.



## So you say you need to change the Vocabulary?

<IMG SRC="./resources/tomford.gif" width=275>

Before you do that - make sure you _really_ need to!  If it's just renaming a `label` or changing spelling or 
capitalization -- I would strongly suggest you consider the impact of just changing the string value of the label
and not create new `ObjectIds` and a new version number.  If you need to rename a `type`, you should
also first consider handling it in the display layer, alone, without necessitating a full
vocabulary change.  And even then, if you're still convinced you have to change the `type`, are you sure you can't just
rename the `type` in the collection?

But, if you're convinced you do need to change the vocabulary (even if you're just adding new stuff), here's what 
you'll want to do:
1) Change the `mm_vocabulary` collection (manually or via migration).  
2) Then, change `SELECTED_VOCABULARY_VERSION`, in `utils.py`.
3) Next regenerate the constants that exist in the `./constants/__init__.py`
by hitting the end point `/tagging/vocab` on this repo to regenerate the file.  The result will be a
whole bunch of text - `use the force: view source` - then copy that into `./constants/__init__.py` 
as the new set of vocab constants. 
  
  
  If vocabulary terms change you may
need to change the rules that exist in the _tagging logic_ files in this directory.
4) How to check if you need to do some updates? 
    * Hit `/tagging/validate`, and it will parse the python file source and lookup any bad constants (i.e. 
    stray, not-defined in the vocab collection, for this version).  If  this fails this means you might be 
    encountering some mismatches between the code -> constants -> vocabulary.
    * Check your IDE -- if your constants changed, then your IDE should be able to detect any mis-matches.  Pylint 
    is your friend.


***

### What is this Validation thing?

There is an endpoint here available at `/tagging/validate`.

You can see the route and processing is written in `research_api/controllers/tagging/__init__.py` 
and any new tagging logic (`X.py`) file (where 'X' is the name of a data source, like `gri.py`) needs to also be
added to the call in the `validate()` function in `__init__.py`.  

What does this endpoint do?  It validates, of course.  What does it validate?  It actually loads the python 
*source file* from the *file system*, then parses out the `check_term` function to see if the constant values for 
the strings are available in the main vocabulary object. [obviously, if the name or signature of `check_term` changes, 
this code will also need refactoring]

If any of the constants used in these two fields in the tagging logic python source is not 
found in the main `vocabulary` dictionary (which is dynamically built from the `mm_vocabulary` 
collection in the DB), the validation endpoint will return an error, such as:

```python
{"type": "ERROR", "message": "name 'SZWIMPROVE_ENERGY_EFFICIENCY' is not defined"}
```

but if it's all good - you will receive a message, which looks much more like:

```python
{
  "csr_hub": "pass", 
  "gri": "pass", 
  "msci": "pass", 
  "sasb": "pass", 
  "sdg": "pass", 
  "themes": "pass"
}
```


Running this validation endpoint should be a bit of a formality, a last check.  If you changed or wrote the tagging 
logic python code in an IDE, it should be pretty easy while developing to see when your constants are wrong.  But, 
perhaps you need to regenerate the constants file?  This is one of a few scenarios where this check should prove useful.

***

### Miscellaneous addendum

Not all `type` in `mm_vocabulary` makes it into this crazy code-contraption:

 * boolean 
 * studyEvidenceType 
 * approachDuration
 * studyDesignType
 * researchDataType 
 * effect 
 * strength 

You may find that you need to have these values in rules, they haven't been incorporated into rules up through version 2. 
 If you find that they are required for rules, you'll 
need to add them into the consideration set of exported `CONSTANTS`.  Note this block, below, in `utils.py`
is where the `CONSTANTS` are written to the screen with the `/tagging/constants` endpoint. 

```python
 for v in vocabulary:
        #print("\t" + v + "\t" + str(len(vocabulary[v])))
        if v in (VOCAB_APPROACHES,
                 VOCAB_AUDIENCES,
                 VOCAB_CSRHUB,
                 VOCAB_CAUSES,
                 VOCAB_IMPACTS,
                 VOCAB_GRI,
                 VOCAB_SASB,
                 VOCAB_SDGS,
                 VOCAB_ESG,
                 VOCAB_THEMES,
                 VOCAB_ANIMALHABITATS):
            t = vocabulary[v]
            for x in t:
                actual_string = str(t[x])
                vocab_string = actual_string.upper().replace("*", "").replace(":", "_").replace("(", "").replace(")", "").replace(" ", "_").replace("’", "").replace("&", "AND").replace(",", "_").replace("'", "_").replace("-", "_").replace("'", "").replace("+", "_").replace("/", "_")
                if vocab_string[0].isdigit():
                    vocab_string = "AGE_" + vocab_string
                if vocab_string not in did_already:
                    constants_file.append(vocab_string + " = \"" + actual_string + "\"")
                    did_already.append(vocab_string)
```

Make sure that your new `type` term is added to the list of exported terms at `if v in (VOCAB_APPROACHES...`.  

Also notable in this 
snippet is the first line that starts with `vocab_string` -- this is where we convert a regular string into an 
all-upper-case and Python-friendly constant value.  It's a gnarly chain of `replace` on the original string.  If you find that you
output from `/tagging/constants` spits out a constant name that isn't compatible with Python -- you can address by 
fixing the errant characters here.



