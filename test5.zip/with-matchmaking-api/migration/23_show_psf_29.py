from matchmaking import db

db().coll_survey_data.update_one({}, {
    '$unset': {
        'questionDependencies.researchApproaches': ''
    }
})
