sudo pkill gunicorn
