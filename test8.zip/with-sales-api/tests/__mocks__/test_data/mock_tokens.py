admin_token = {
    'sub': '5b38f270-675b-4588-ab14-98076eec1555',
    'event_id': 'da26e90e-2cf0-4732-90b2-50b361824757',
    'token_use': 'access',
    'scope': 'admin',
    'iss': 'https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
    'jti': '6729c94b-e601-4c87-bf2f-cbebd44cc421',
    'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
    'username': '5b38f270-675b-4588-ab14-98076eec1555',
    'resource_ids': [
        '5c1415685b03bb0008c21b06'
    ],
    'version': 1,
    'user_id': '5d1a3962d5b3a53c05437ede',
    'email': 'elizabeth.chan@givewith.com',
    '_id': '5d1a3962d5b3a53c05437ede',
    'active': True,
    'type': 'admin',
    'first_name': 'Elizabeth',
    'last_name': 'Chan',
    'orgId': '5c1415685b03bb0008c21b06',
    'orgType': 'brand',
    'name': 'Elizabeth Chan',
    'uuid': 'cfc92a74-f0b8-477e-a366-11303d10fcb2',
    'cognito-id': '5b38f270-675b-4588-ab14-98076eec1555',
    'departmentType': 'Sales',
    'title': 'test title123',
    'departmentName': 'test department name123',
    'last_login': 'Thu, 13 Aug 2020 17:22:41 GMT'
}


client_token = {
    'sub': '5b38f270-675b-4588-ab14-98076eec1555',
    'event_id': 'da26e90e-2cf0-4732-90b2-50b361824757',
    'token_use': 'access',
    'scope': 'admin',
    'iss': 'https: //cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7',
    'jti': '6729c94b-e601-4c87-bf2f-cbebd44cc421',
    'client_id': '1nmeh7a4rs6gs58d6uhmlq6dmo',
    'username': '5b38f270-675b-4588-ab14-98076eec1555',
    'resource_ids': [
        '5c1415685b03bb0008c21b06'
    ],
    'version': 1,
    'user_id': '5d1a3962d5b3a53c05437ede',
    'email': 'elizabeth.chan@givewith.com',
    '_id': '5d1a3962d5b3a53c05437ede',
    'active': True,
    'type': 'client',
    'first_name': 'Elizabeth',
    'last_name': 'Chan',
    'orgId': '5c1415685b03bb0008c21b06',
    'orgType': 'brand',
    'name': 'Elizabeth Chan',
    'uuid': 'cfc92a74-f0b8-477e-a366-11303d10fcb2',
    'cognito-id': '5b38f270-675b-4588-ab14-98076eec1555',
    'departmentType': 'Sales',
    'title': 'test title123',
    'departmentName': 'test department name123',
    'last_login': 'Thu, 13 Aug 2020 17: 22: 41 GMT'
}
