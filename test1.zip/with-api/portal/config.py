import os
import yaml

config = None
config_dir = 'config/'


def get_config():
    global config
    if config is None:
        env = os.environ.get('FLASK_ENV', 'development').lower()
        with open(config_dir + env + '.yml', 'r') as stream:
            config = yaml.safe_load(stream)
    return config
