from jsonschema import ValidationError
from marshmallow import fields, Schema, post_load, validate, validates

from portal.shared.custom_fields import FormattedDateTimeField, ObjectIdField
from portal.shared.schema import EntitySchema, OrderedSchema, SearchRequestSchema, \
    SearchResponseSchema
from werkzeug.exceptions import Forbidden, NotFound, BadRequest


class LocaleSettingsSchema(OrderedSchema):
    currency = fields.String(required=True)
    symbol = fields.String(required=True)
    regionLabel = fields.String()
    regions = fields.List(fields.String(required=True), required=True)

    @validates('regions')
    def validate_regions(self, value):
        if not value:
            raise ValidationError(f'At least one state/region is required.')


class LocaleSchema(EntitySchema):
    """Locale Model"""
    name = fields.String(required=True)
    description = fields.String()
    instanceCount = fields.Integer()
    settings = fields.Nested(LocaleSettingsSchema, required=True)
    active = fields.Boolean()


class LocaleSearchRequest(SearchRequestSchema):
    """Locale model for search request"""
    id = ObjectIdField(attribute='_id', allow_none=True)
    name = fields.String(allow_none=True)
    currency = fields.String(allow_none=True)
    description = fields.String(allow_none=True)
    active = fields.Boolean(allow_none=True)
    createdBy = fields.String(allow_none=True)
    createdAtFrom = fields.DateTime(allow_none=True)
    createdAtTo = fields.DateTime(allow_none=True)
    lastUpdatedFrom = fields.DateTime(allow_none=True)
    lastUpdatedTo = fields.DateTime(allow_none=True)
    lastUpdatedBy = fields.String(allow_none=True)

    class Meta:
        contains_fields = [
            'name', 'currency', 'description', 'createdBy', 'lastUpdatedBy']
        range_fields = ['createdAt', 'lastUpdated']

    def _convert_nested(self, key):
        if key == 'currency':
            return 'settings.currency'
        return key


class LocaleSearchResponse(SearchResponseSchema):
    results = fields.List(fields.Nested(LocaleSchema), required=True)


class LocaleRequest(LocaleSchema):
    """Request Model for POST/PUT locale requests"""
    class Meta:
        exclude = ('instanceCount', 'id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated')


class LocalePatchRequest(LocaleSchema):
    """Request Model for POST/PUT locale requests"""
    class Meta:
        exclude = ('name', 'instanceCount', 'id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated')


class LocaleResponse(LocaleSchema):
    """Response Model for GET/POST/PUT responses"""
    pass
