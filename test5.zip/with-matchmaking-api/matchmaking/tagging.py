# -*- coding: utf-8 -*-
from collections import defaultdict

import ast
from bson import ObjectId
from bson.errors import InvalidId
from flask import current_app
from .mongodb import db, create_ref, VOCAB_V1
import sys

def get_vocabulary_id(item):
    try:
        return ObjectId(item)
    except InvalidId:
        return None


# The dictionary below maps given the type of tag, which field should be lookup into the vocabulary collection
LOOKUP_FIELDS = {
    'sdg': 'code',
    'gri': 'code',
    'cdp': 'code',
    'esg': 'label',
    'sasb': 'label',
    'themes': 'label'
}


def auto_fill(program):
    map_rules = db().coll_tagging_rules.find_one(projection={'_id': False})
    tag_to_field = db().coll_tag_to_field.find_one(projection={'_id': 0})

    def lookup(grouping, vocabulary_label):
        try:
            if vocabulary_label.startswith('field='):
                _, name_and_value = vocabulary_label.split('=')
                field_name, field_value = name_and_value.split(':')
                return program[field_name] == ast.literal_eval(field_value)
            else:
                program_attr = program[grouping]
                if type(program_attr) == list:
                    program_labels = list(filter(None, [db().map_id_to_label.get(ObjectId(oid)) for oid in program_attr]))
                    program_labels = [i.lower() for i in program_labels]
                    exists = vocabulary_label in program_labels
                else:
                    program_label = db().map_id_to_label.get(ObjectId(program_attr)).lower()
                    exists = (vocabulary_label == program_label) if program_label else False
                return exists
        except KeyError:
            # Not all Program records on the database have all fields that are looked-up on them.
            pass
        except Exception as ex:
            current_app.logger.warning('Failed lookup {0} -> {1} with error: {2}'.format(grouping, vocabulary_label, str(ex)))

        return False

    valid_tags = defaultdict(list)

    for tag_name, rule in map_rules.items():
        matches = eval(rule, {'l': lookup, 'program': program}) # nosec pylint: disable=eval-used
        vocabulary_type = tag_to_field.get(tag_name, False)
        if not (vocabulary_type and matches):
            continue

        vocabulary_item = db().coll_vocabulary.find_one({'versions': VOCAB_V1, 'type': vocabulary_type,
                                                         LOOKUP_FIELDS[vocabulary_type]: tag_name})
        if vocabulary_item:
            valid_tags[vocabulary_type].append(vocabulary_item['_id'])

    # modifications begin here, where we add on new data sources that use a newer (post W&C) method of
    # "tagging" programs
    if "program_id" in program:

        # here are some helper methods that any new tagging logic can share:
        vocabulary = getVocabulary()
        document = db().coll_programs.find_one({"_id": ObjectId(program["program_id"])})
        stringed = stringifyDocumentVocabulary(document, vocabulary)

        # now we go and get the right tags for this program
        # based on the document itself

        # BEGIN CSRHUB
        csrhub = csrHubTags(vocabulary, document, stringed)

        # and we can add it into the response
        if "csrhub" in valid_tags:
            valid_tags.pop("csrhub")
        if "data" in csrhub:
            # and if we have it, we add it to the record
            tag_list = csrhub["data"]
            valid_tags["csrhub"] = tag_list
        # END CSRHUB

        # BEGIN SASB
        sasb = sasbTags(vocabulary, document, stringed)
        if "sasb" in valid_tags:
            valid_tags.pop("sasb")
        if "data" in sasb:
            tag_list = sasb["data"]
            valid_tags["sasb"] = tag_list
        # END SASB


    else:
        print("missing the program ID in the 'auto-fill' request; update source for admin-ui?", file=sys.stderr)

    return valid_tags


# this should be a call out to the Research/Data API, eventually, but for now we can just do the
# evaluation in this pass
def csrHubTags(vocabulary, document, stringed):

    # here's the logic for tagging programs with CSRHub "tags"
    try:
        # get rid of the node with data for this feature
        document = resetFeature(document, "csrhub")

        # Rule 1: Community Development and Philanthropy (always add)
        # print("  rule 1", file=sys.stderr)
        # everyone gets one
        addFeature(document, vocabulary, "csrhub", "Community Development and Philanthropy")

        # Rule 2 "Human Rights and Supply Chain"
        # print("  rule 2", file=sys.stderr)
        if checkTerm("Enhance land management and/or protection", "interventions", stringed, vocabulary) or \
            checkTerm("Enhance water management and/or protection", "interventions", stringed, vocabulary) or \
            checkTerm("Improve community environments or spaces", "interventions", stringed, vocabulary) or \
            checkTerm(
                "Provide support programs to maintain employment, housing, financial stability, and physical and mental health",
                "interventions", stringed, vocabulary):
            if checkTerm("Low-income populations", "audienceAttribute", stringed, vocabulary):
                addFeature(document, vocabulary, "csrhub", "Human Rights and Supply Chain")

        # Rule 3: "Diversity and Labor Rights"
        # print("  rule 3", file=sys.stderr)
        if checkTerm("Economic Development", "causes", stringed, vocabulary) or \
            checkTerm("Education", "causes", stringed, vocabulary) or \
            checkTerm("Human Rights/Civil Society", "causes", stringed, vocabulary):
            if checkTerm("Achieve equality/eliminate discrimination", "impacts", stringed, vocabulary) or \
                checkTerm("Increase access to and acquire employment", "impacts", stringed, vocabulary):
                if checkTerm("Enhance legal protections", "interventions", stringed, vocabulary) or \
                    checkTerm("Increase college readiness, access, persistence and completion", "interventions",
                              stringed, vocabulary) or \
                    checkTerm("Increase job placement/retention services", "interventions", stringed, vocabulary) or \
                    checkTerm("Promote job creation", "interventions", stringed, vocabulary) or \
                    checkTerm("Provide job/career readiness training", "interventions", stringed, vocabulary) or \
                    checkTerm("Provide STEM interest, proficiency and persistence programs", "interventions", stringed,
                              vocabulary) or \
                    checkTerm(
                        "Provide support programs to maintain employment, housing, financial stability, and physical and mental health",
                        "interventions", stringed, vocabulary):
                    if checkTerm("Female", "audienceGender", stringed, vocabulary) or \
                        checkTerm("Immigrants", "audienceAttribute", stringed, vocabulary) or \
                        checkTerm("LGBTQI+", "audienceAttribute", stringed, vocabulary) or \
                        checkTerm("Low-income populations", "audienceAttribute", stringed, vocabulary) or \
                        checkTerm("People with Disabilities", "audienceAttribute", stringed, vocabulary) or \
                        checkTerm("People with special needs", "audienceAttribute", stringed, vocabulary) or \
                        checkTerm("Refugees/displaced persons", "audienceAttribute", stringed, vocabulary):
                        addFeature(document, vocabulary, "csrhub", "Diversity and Labor Rights")

        # Rule 4: "Energy and Climate Change"
        # print("  rule 4", file=sys.stderr)
        if checkTerm("Environment", "causes", stringed, vocabulary):
            if checkTerm("Improve air quality", "impacts", stringed, vocabulary) or \
                checkTerm("Increase land protection", "impacts", stringed, vocabulary) or \
                checkTerm("Increase water protection", "impacts", stringed, vocabulary) or \
                checkTerm("Increase understanding of and commitment to reducing climate change", "impacts", stringed,
                          vocabulary) or \
                checkTerm("Protect endangered, vulnerable or threatened species", "impacts", stringed, vocabulary) or \
                checkTerm("Reduce carbon impact", "impacts", stringed, vocabulary):
                addFeature(document, vocabulary, "csrhub", "Energy and Climate Change")

        # Rule 5: "Leadership Ethics"
        # print("  rule 5", file=sys.stderr)
        # everyone gets one
        addFeature(document, vocabulary, "csrhub", "Leadership Ethics")

    except:
        print("Exception in processing document - using string that isn't in vocab? or excep saving document.", file=sys.stderr)

    # we actually have a full document now, which really we don't need...so we'll just return the relevant parts
    return document["csrhub"]


def sasbTags(vocabulary, document, stringed):
    try:
        # get rid of the node with data for this feature
        document = resetFeature(document, "sasb")

        # Rule 1: GHG Emissions
#        print("  rule 1")
        if checkTerm("Environment", "causes", stringed, vocabulary) and \
            (checkTerm("Improve air quality", "impacts", stringed, vocabulary) or \
             checkTerm("Increase land protection", "impacts", stringed, vocabulary) or \
             checkTerm("Increase water protection", "impacts", stringed, vocabulary) or \
             checkTerm("Increase understanding of and commitment to reducing climate change", "impacts", stringed,
                       vocabulary) or \
             checkTerm("Protect endangered, vulnerable or threatened species", "impacts", stringed, vocabulary) or \
             checkTerm("Reduce carbon impact", "impacts", stringed, vocabulary)):
            addFeature(document, vocabulary, "sasb", "GHG Emissions")

#        print("----")

        # Rule 2: Ecological Impacts
#        print("  rule 2")
        if checkTerm("Environment", "causes", stringed, vocabulary) and \
            (checkTerm("Increase land protection", "impacts", stringed, vocabulary) or \
             checkTerm("Increase water protection", "impacts", stringed, vocabulary) or \
             checkTerm("Protect endangered, vulnerable or threatened species", "impacts", stringed, vocabulary)):
            addFeature(document, vocabulary, "sasb", "Ecological Impacts")

#        print("----")

        # Rule 3: Human Rights & Community Relations
#        print("  rule 3")
        addFeature(document, vocabulary, "sasb", "Human Rights & Community Relations")

#        print("----")

        # Rule 4: Access and Affordability
#        print("  rule 4")
        if (checkTerm("Economic Development", "causes", stringed, vocabulary) or \
            checkTerm("Education", "causes", stringed, vocabulary) or \
            checkTerm("Food and Hunger", "causes", stringed, vocabulary) or \
            checkTerm("Housing and Homelessness", "causes", stringed, vocabulary) or \
            checkTerm("Public Health", "causes", stringed, vocabulary)) and \
            (checkTerm("Increase access to clean water", "impacts", stringed, vocabulary) or \
             checkTerm("Increase access to nutritious food", "impacts", stringed, vocabulary) or \
             checkTerm("Increase access to quality, affordable healthcare and services", "impacts", stringed,
                       vocabulary) or \
             checkTerm("Reduce homelessness", "impacts", stringed, vocabulary)) and \
            (checkTerm("Develop financial literacy and financial resilience", "programApproaches", stringed,
                       vocabulary) or \
             checkTerm("Develop skills to secure employment, housing and financial stability", "programApproaches",
                       stringed, vocabulary) or \
             checkTerm("Provide affordable housing", "programApproaches", stringed, vocabulary) or \
             checkTerm("Provide quality water", "programApproaches", stringed, vocabulary) or \
             checkTerm("Provide sufficient, affordable and nutritious foods", "programApproaches", stringed,
                       vocabulary) or \
             checkTerm(
                 "Provide support programs to maintain employment, housing, financial stability, and physical and mental health",
                 "programApproaches", stringed, vocabulary) or \
             checkTerm("Provide technology and connectivity", "programApproaches", stringed, vocabulary) or \
             checkTerm("Provide temporary housing", "programApproaches", stringed, vocabulary) or \
             checkTerm("Run patient and family support programs", "programApproaches", stringed, vocabulary) or \
             checkTerm("Run patient quality of life programs", "programApproaches", stringed, vocabulary)):
            addFeature(document, vocabulary, "sasb", "Access and Affordability")

#        print("----")

        # Rule 5: Business Ethics
#        print("  rule 5")
        addFeature(document, vocabulary, "sasb", "Business Ethics")

#        print("  Summary: " + ', '.join(document["sasb"]["strings"]))

    except:
        e = sys.exc_info()[0]
        print("Error: %s" % e)
        print("Exception in processing document - using string that isn't in vocab? or excep saving document.")

    return document["sasb"]


# ******************************************
# ***** UTILITY FUNCTIONS FOR TAGGING ******

# we'll load up all the objectIDs of the terms in the
# vocabulary.  this is a key/value of key/values, where they objectid/labels
# are nested in their distinct areas/topics.
# there is also a "inverted" dict which is label/objectid, instead of the other way
# for all the values
def getVocabulary():
    cursor = db().coll_vocabulary

    vocabulary = dict()
    csrhubs = dict()  # these are all key/value with objectID/label
    audiences = dict()
    interventions = dict()
    impacts = dict()
    industries = dict()
    researchTypes = dict()
    animalHabitats = dict()
    dataMeasurements = dict()
    themes = dict()
    effectiveness = dict()
    causes = dict()
    esgs = dict()
    sdgs = dict()
    cdps = dict()
    sasbs = dict()
    programApproaches = dict()
    scaleTypes = dict()
    gris = dict()

    inverted = dict()  # this one is keyed on label

    for document in cursor.find({'versions': VOCAB_V1}):
        t = document["type"]

        inverted[document["label"]] = document["_id"]

        if t == "csrhub":
            csrhubs[document["_id"]] = document["label"]

        if t == "interventions":
            interventions[document["_id"]] = document["label"]

        if t == "audience":
            audiences[document["_id"]] = document["label"]

        if t == "impact":
            impacts[document["_id"]] = document["label"]

        if t == "industry":
            industries[document["_id"]] = document["label"]

        if t == "researchType":
            researchTypes[document["_id"]] = document["label"]

        if t == "animalHabitats":
            animalHabitats[document["_id"]] = document["label"]

        if t == "dataMeasurement":
            dataMeasurements[document["_id"]] = document["label"]

        if t == "themes":
            themes[document["_id"]] = document["label"]

        if t == "effectiveness":
            effectiveness[document["_id"]] = document["label"]

        if t == "causes":
            causes[document["_id"]] = document["label"]

        if t == "esg":
            esgs[document["_id"]] = document["label"]

        if t == "sdg":
            sdgs[document["_id"]] = document["label"]

        if t == "cdp":
            cdps[document["_id"]] = document["label"]

        if t == "sasb":
            sasbs[document["_id"]] = document["label"]

        if t == "programApproach":
            programApproaches[document["_id"]] = document["label"]

        if t == "scaleType":
            scaleTypes[document["_id"]] = document["label"]

        if t == "gri":
            gris[document["_id"]] = document["label"]

    vocabulary["csrhub"] = csrhubs
    vocabulary["audiences"] = audiences
    vocabulary["interventions"] = interventions
    vocabulary["impacts"] = impacts
    vocabulary["industries"] = industries
    vocabulary["researchTypes"] = researchTypes
    vocabulary["animalHabitats"] = animalHabitats
    vocabulary["dataMeasurements"] = dataMeasurements
    vocabulary["themes"] = themes
    vocabulary["effectiveness"] = effectiveness
    vocabulary["causes"] = causes
    vocabulary["esg"] = esgs
    vocabulary["sdg"] = sdgs
    vocabulary["cdp"] = cdps
    vocabulary["sasb"] = sasbs
    vocabulary["programApproaches"] = programApproaches
    vocabulary["scaleType"] = scaleTypes
    vocabulary["gri"] = gris
    vocabulary["inverted"] = inverted

    # print("**** Loaded Vocabulary ****")
    # for v in vocabulary:
    #    print("\t" + v + "\t" + str(len(vocabulary[v])))
    return vocabulary


# this returns true or false if the given string is
# present in the "cleaned" (aka stringified, not objectids) representation
# of the program.  if the term is not spelled right or not in the
# vocabulary, it will throw a exception

def checkTerm(term, branch_name, cleaned, vocabulary):
    if term not in vocabulary["inverted"]:
        # print("can't find term: " + term + " in vocabulary", file=sys.stderr)
        raise Exception("no " + term)
    if branch_name in cleaned:
        if term in cleaned[branch_name]:
            # print("\tfound term " + term + " in " + branch_name, file=sys.stderr)
            return True
    return False


# this is a utility method mostly called by "stringifyDocumentVocabulary"
# that converts the objectID in a given field into it's label
def checkVocab(nameInDocument, nameInData, document, vocabulary):
    output = list()
    if nameInDocument in document:
        aa = document[nameInDocument]
        if isinstance(aa, list):
            for a in aa:
                if a in vocabulary[nameInData]:
                    name = vocabulary[nameInData][a]
                    # print("nameInData " + str(a))
                    output.append(name)
        else:
            if aa in vocabulary[nameInData]:
                name = vocabulary[nameInData][aa]
                # print("nameInData " + str(a))
                output.append(name)

    return output


# this takes in a given program document, and our overall vocabulary
# and then returns a simplified dictionary of all the labels
# (converting the objectIDs into the strings/labels they refer to)
def stringifyDocumentVocabulary(document, vocabulary):
    data = dict()
    data["audienceAge"] = checkVocab("audienceAge", "audiences", document, vocabulary)
    data["audienceAttribute"] = checkVocab("audienceAttribute", "audiences", document, vocabulary)
    data["audienceGender"] = checkVocab("audienceGender", "audiences", document, vocabulary)
    data["causes"] = checkVocab("causes", "causes", document, vocabulary)
    data["dataMeasurementType"] = checkVocab("dataMeasurementType", "dataMeasurements", document, vocabulary)
    data["interventions"] = checkVocab("interventions", "interventions", document, vocabulary)
    data["primaryImpact"] = checkVocab("primaryImpact", "impacts", document, vocabulary)
    data["secondaryImpacts"] = checkVocab("secondaryImpacts", "impacts", document, vocabulary)
    # merge them into a single list, too
    data["impacts"] = data["primaryImpact"] + data["secondaryImpacts"]
    data["programApproach"] = checkVocab("programApproach", "programApproaches", document, vocabulary)

    return data


# before you "tag" a program document, remove the old one.
def resetFeature(document, dataname):
    document.pop(dataname, None)
    return document


# if you have new tags - use this to pass the object ids into the
# right part of the doc
def addFeature(document, vocabulary, dataname, featureName):
    data = dict()
    if dataname in document:
        data = document[dataname]
    else:
        data = dict()
        data["isCustom"] = False
        data["data"] = list()
        data["strings"] = list()

    if featureName in data["strings"]:
        print('\talready include ' + featureName)
    else:
        oid = vocabulary["inverted"][featureName]
        data["data"].append(oid)
        data["strings"].append(featureName)
        print("\tadding " + str(oid) + "\t" + featureName)

    document[dataname] = data
