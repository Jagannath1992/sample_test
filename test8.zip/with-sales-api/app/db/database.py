from pymongo import MongoClient

db = None


def init_db(app, test_db=None):
    global db

    if test_db:
        db = test_db
        return

    config = app.config
    client = MongoClient(config['MONGO_URL'])
    db = client.get_database(config['MONGO_DATABASE'])


def get_db():
    return db
