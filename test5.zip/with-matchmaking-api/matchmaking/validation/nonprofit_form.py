from matchmaking.utils import UnsupportedPayload
from matchmaking.validation.utils import validate_object_id, validate_existence, validate_schema
from matchmaking.models.nonprofit_form import init_form_request_schema, completed_form_schema


""" 
validate init nonprofit form request:
1. ensure form application name exist and unique
2. ensure givewithAdmin ID exist and valid
"""
def validate_init_form_request(form):
    if not form:
        raise UnsupportedPayload()

    errors = validate_schema(init_form_request_schema, form)
    if len(errors) > 0:
        return errors

    if len(form['applicationFormName']) == 0:
        errors.append('application name is required')

    if validate_existence("applicationFormName", form['applicationFormName'], 'nonprofit_form'):
            errors.append('application name already exist')

    validate_object_id(form['givewithAdmin'], 'user')
    return errors


"""
validate completed nonprofit form for approval
"""
def validate_completed_form(form):
    errors = validate_schema(completed_form_schema, form)
    if len(errors) > 0:
        return errors

    # check conditional fields in location
    gl = form['general']['location']
    country = gl['generalLocation']

    if country == 'United States':
        if 'taxId' not in gl:
            errors.append('taxId is required')
        if 'w9' not in gl:
            errors.append('w9 id is required')
    elif country == 'United Kingdom':
        if 'charityNumber' not in gl:
            errors.append('charityNumber is required')
        if 'companyHouseNumber' not in gl:
            errors.append('companyHouseNumber is required')
    elif country == 'Other':
        if 'otherId' not in gl:
            errors.append('otherId is required')
    else:
        errors.append('invalid country. expect: United States, United Kingdom, Other. got ' + country)


    fs = form['operationalInformation']['financialStatement']
    file = fs.get('file', {})

    has_website = 'website' in fs and len(fs['website']) > 0
    has_file = 'url' in file and 'name' in file and len(file.get('url', '')) > 0 and len(file.get('name', '')) > 0

    if not has_file and not has_website:
        errors.append('incomplete financial statement. expect a file or website')

    return errors


"""
validate request for upload file
"""
def validate_file_upload(upload_request):
    errors = []
    if upload_request is None:
        errors.append('empty request')
        return errors

    if 'file' not in upload_request.files:
        errors.append('no file')
        return errors

    if 'path' not in upload_request.form:
        errors.append('path is required')

    file = upload_request.files['file']
    if not file:
        errors.append('file is required')

    return errors


"""
validate request for delete file
"""
def delete(upload_request):
    errors = []
    if upload_request is None:
        errors.append('empty request')
        return errors

    if 'file' not in upload_request.json:
        errors.append('no file')
        return errors

    if 'path' not in upload_request.form:
        errors.append('path is required')

    file = upload_request.files['file']
    if not file:
        errors.append('file is required')

    return errors






