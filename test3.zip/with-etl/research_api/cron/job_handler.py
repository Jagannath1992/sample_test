import requests
import json
import hashlib
import os

from os import path
from research_api.mongodb import get_mongo_db
from research_api.s3 import upload_file, delete_file
from research_api.slack import SimianSlack
from research_api.loggly import send_loggly

from research_api.utils import GivewithError
from research_api.loggly import get_logger
from requests.adapters import HTTPAdapter

def hello_world():
    print('hello world')


def simian():
    
    # print("Skip SIMIAN CMS sync for now")
    # return

    """
    Query simian media api. save meta data in simian_media collection, and store file to s3 {ENV}-simian-media bucket.
    Server IP must be added to simian white list.
    """
    simian_api = "https://givewith.gosimian.com/api/simian/get_media"
    payload = {
        'auth_token': os.environ.get('SIMIAN_TOKEN'),
        'output_format': 'json'
    }

    slack = SimianSlack()

    try:
        get_logger().info(f'Running endpoint {simian_api}')
        response = requests.post(simian_api, data=payload)

        get_logger().info(f'Response: {response.text}')

        text = json.loads(response.text)
        media_list = text["root"]["media"]
        get_logger().info(f'Total records in simian api response {len(media_list)}')
    except Exception as e:
        send_loggly('error query simian. token: ' + os.environ.get('SIMIAN_TOKEN') + '. details:' + str(e))
        slack.send_text('error query simian. token: ' + os.environ.get('SIMIAN_TOKEN') + '. details:' + str(e))
        raise GivewithError('error query simian. token: ' + os.environ.get('SIMIAN_TOKEN') + '. details:' + str(e))
    finally:
        response.close()

    slack.send_text('*Simian ingesting starting in ' + os.getenv('ENV') + ' *\n')

    media_id_set = set()  # a set contains media ids from simian
    delete_media_ids = []  # a list contains media ids will be deleted from db
    new_media = []
    bucket = os.getenv('ENV') + '-simian-media'

    for media in media_list:
        # check tags. content should only be pulled in from Simian if it has the tag “Final”.
        if 'Final' not in media.get('tags'):
            delete_media_ids.append(media.get('id'))  # add media id to delete_media_ids
            continue

        # add media_id to set
        media_id_set.add(media.get('id'))

        title = media.get('title')

        invalid_item = {
            'title': title,
            'media': media.get('media_file'),
            'thumbnail': media.get('thumbnail'),
        }

        # set nonprofit id and program id by name
        if len(media.get('credits')) > 0:
            nonprofit_name = media.get('credits', {}).get('npo_name', '').replace('NPO ', '', 1)
            nonprofit = get_mongo_db().mm_nonprofits.find_one({'name': nonprofit_name})

            if nonprofit is not None:
                media['credits']['npo_id'] = str(nonprofit.get('_id'))
            else:
                invalid_item['nonprofit_name'] = nonprofit_name

            program_name = media.get('credits', {}).get('program_name', '').replace('PRG ', '', 1)
            program = get_mongo_db().mm_programs.find_one({'name': program_name})

            if program is not None:
                media['credits']['program_id'] = str(program.get('_id'))
            else:
                invalid_item['program_name'] = program_name

        # generate md5
        md5 = hashlib.md5(json.dumps(media).encode("utf-8")).hexdigest()
        media['md5'] = md5

        # find media from db
        media_db = get_mongo_db().simian_media.find_one({'id': media.get('id')})

        # if md5 match, no action needed
        if media_db and media_db['md5'] == md5:
            continue

        # if media is new or media upload date has changed, upload to s3
        if media_db is None or media_db.get('upload_date') != media.get('upload_date'):
            new_media.append({'id': media.get('id'), 'title': media.get('title')})

            # media file
            media_file_url = media['media_file']
            split_arr = media_file_url.split('/')
            media_file_name = split_arr[len(split_arr) - 1]


            
            # TODO: MOVE INTO UTILS
            # NEW CODE FOR DOWNLODING SIMIAN MEDIA FILES
            get_logger().info(f'Downloading media files from {media_file_url}')
            timeout = 30  # ten sec.
            adapter = HTTPAdapter(max_retries=5)
            with requests.Session() as c:
                url = media_file_url
                adapter = adapter
                r = c.get(url, data = payload, headers=None, allow_redirects=True, timeout=timeout)
                open(media_file_name, 'wb').write(r.content)

            # OLD CODE FOR DOWNLOADING SIMIAN MEDIA FILES
            # r = requests.get(media_file_url, allow_redirects=True)
            # open(media_file_name, 'wb').write(r.content)

            
            get_logger().info(f'Uploading media files into {bucket}')
            s3_media_url = upload_file(bucket, media_file_name)
            media['media_s3'] = s3_media_url
            get_logger().info(f'S3 bucket uploaded medial url {s3_media_url}')

            # thumbnail
            thumbnail_url = media['thumbnail']
            split_arr = thumbnail_url.split('/')
            thumbnail_file_name = 'thumbnail_' + split_arr[len(split_arr) - 1]

            get_logger().info(f'Downloading thumbnail from {thumbnail_url}')
            r = requests.get(thumbnail_url, allow_redirects=True)
            open(thumbnail_file_name, 'wb').write(r.content)

            get_logger().info(f'Uplading thumbnail into S3 bucket {bucket}')
            s3_thumbnail_url = upload_file(bucket, thumbnail_file_name)
            media['thumbnail_s3'] = s3_thumbnail_url
            get_logger().info(f'S3 bucket uploaded thumbnail url {s3_thumbnail_url}')

            # delete files
            if path.exists(media_file_name):
                os.remove(media_file_name)

            if path.exists(thumbnail_file_name):
                os.remove(thumbnail_file_name)
        else:
            mongodb_media_s3 = media_db['media_s3']
            get_logger().info(f'Skip processing... Media file already exists in mongoDB {mongodb_media_s3}')
            media['media_s3'] = mongodb_media_s3
            media['thumbnail_s3'] = media_db['thumbnail_s3']

        # update db
        get_mongo_db().simian_media.replace_one({'id': media.get('id')}, media, upsert=True)

        if 'nonprofit_name' in invalid_item or 'program_name' in invalid_item:
            slack.send_invalid_item(invalid_item)



    # load all media ids from db
    get_logger().info(f'load all media ids from db and compare with simian CMS db')
    media_db = get_mongo_db().simian_media.find({}, {'id': 1})
    for m in media_db:
        if m.get('id') not in media_id_set:  # if not in media id set, add to delete_media_ids
            delete_media_ids.append(m.get('id'))

    get_logger().info(f'Total database/s3 media files to be deleted {len(delete_media_ids)}')


    get_logger().info(f'Start deleting media which are no longer valid from mongoDB and S3')

    delete_media_summary = []
    for media_id in delete_media_ids:
        delete_media = get_mongo_db().simian_media.find_one({'id': media_id})
        if delete_media is not None:
            delete_media_summary.append({'id': delete_media.get('id'), 'title': delete_media.get('title')})

            # delete files from s3
            s3_url = delete_media['media_s3']
            media_name = s3_url.split('/')[-1]
            delete_file(bucket, media_name)

            thumbnail_url = delete_media['thumbnail_s3']
            thumbnail_name = thumbnail_url.split('/')[-1]
            delete_file(bucket, thumbnail_name)

    get_mongo_db().simian_media.delete_many({'id': {'$in': delete_media_ids}})  # remove from db

    # send slack messages
    if len(new_media) == 0 and len(delete_media_summary) == 0:
        slack.send_text('no changes found')
    else:
        slack.send_text(f'new media: { str(new_media) }')
        slack.send_text(f'deleted media: { str(delete_media_summary) }')

    slack.send_text('End of simian ingestion...')
    get_logger().info(f'Finished deleting media which are no longer valid from mongoDB and S3')