from matchmaking import db

for brand in db().coll_brands.find({}):
    search_string = brand.get('name', '').lower()
    db().coll_brands.update_one({'_id': brand['_id']}, {'$set': {'searchString': search_string}})
