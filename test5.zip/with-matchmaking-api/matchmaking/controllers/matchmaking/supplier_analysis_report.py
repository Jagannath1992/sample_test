# pylint: disable=invalid-triple-quote
from datetime import datetime
from bson.objectid import ObjectId
from flask import jsonify, request

from matchmaking import auth, public_mm_bp
from matchmaking.controllers import admin_bp
from matchmaking.dao import supplier_analysis_report_dao
from matchmaking.mongodb import get_industry_display_map
from matchmaking.models.models import GivewithValidator
from matchmaking.models import supplier_analysis_report_model
from matchmaking.permission_decorator import require_admin_permission
from matchmaking.utils import GivewithError, InvalidPayload, UnsupportedPayload, ValidationError, DATETIME_FORMAT
from matchmaking.validation.utils import validate_existence, validate_existences, validate_object_id


v = GivewithValidator()
CLIENT_RETURN_FIELDS = [
    'brandName', 'name', 'category', 'status', 'suppliers', 'suppliersNotAnalyzed', 'topics', 'slug', 'customerStatus'
]


"""
@api {get} /admin/supplier-analysis-reports Get all Reports
@apiName List Reports
@apiGroup Supplier Analysis Reports - Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription List all supplier analysis reports

@apiParamExample {json} response example:
[
  {
    "_id": "5f9c279a7dfa2fc7e2579039",
    "brandName": "Dominion Energy, Inc.",
    "name": "Dominion Energy, Inc. Supplier Analysis October 2020",
    "status": "IN_PROGRESS"
  },
  {
    "_id": "5f9c27ae7dfa2fc7e257903b",
    "brandName": "Dominion Energy, Inc.",
    "name": "name was updated",
    "status": "COMPLETE",
    "suppliers": 3,
    "suppliersNotAnalyzed": 0
  },
]

@apiError 400 Bad request
@apiError 403 Insufficient permissions
"""
@admin_bp.route('/supplier-analysis-reports', methods=['GET'])
@require_admin_permission
def get_analysis_reports():
    return_fields = {'_id', 'name', 'brandName', 'status', 'suppliers', 'suppliersNotAnalyzed'}
    reports = supplier_analysis_report_dao.list_reports(return_fields)
    return jsonify(reports)


"""
@api {get} /admin/supplier-analysis-reports/:_id Get Reports
@apiName Get Report
@apiGroup Supplier Analysis Reports - Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Get supplier analysis report

@apiParam {String} _id the report id

@apiParamExample {json} response example:
{
  "_id": "5f9c27ae7dfa2fc7e257903b",
  "brandId": "5c1415685b03bb0008c21735",
  "brandName": "Dominion Energy, Inc.",
  "category": "Non IT",
  "createdAt": "2020-10-30T14:48:14.481000Z",
  "createdBy": "5cb0a76b28386f7c5d65c9de",
  "customerStatus": true,
  "lastUpdated": "2020-10-30T17:06:41.409000Z",
  "name": "name was updated",
  "password": "Z20Lhbe2WNl4",
  "slug": "OGD02bu92kH3pxR",
  "status": "COMPLETE",
  "suppliers": [
    {
      "_id": "5c1415685b03bb0008c2171b",
      "name": "SALLY BEAUTY HOLDINGS, INC."
    },
    {
      "_id": "5c1415685b03bb0008c21734",
      "name": "LOUISIANA-PACIFIC CORPORATION"
    },
    {
      "_id": "5c1415685b03bb0008c21735",
      "name": "Dominion Energy, Inc."
    }
  ],
  "suppliersNotAnalyzed": 0
}

@apiError 400 Bad request
@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@admin_bp.route('/supplier-analysis-reports/<_id>', methods=['GET'])
@require_admin_permission
def get_analysis_report_admin(_id):
    validate_object_id(_id, 'supplier_analysis_reports')

    _filter = {'_id': ObjectId(_id)}
    response = supplier_analysis_report_dao.get_report(_filter)
    return jsonify(response)


"""
@api {post} /admin/supplier-analysis-reports Create Report
@apiName Create Reports
@apiGroup Supplier Analysis Reports - Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Create a supplier analysis report

@apiParam {String} npo_id the nonprofit id
@apiParam {String} form_name section name

@apiParamExample {json} request example:
{
    "brandId": "5c1415685b03bb0008c21735",
    "customerStatus": true,
    "notes": "some notes"
}

@apiParamExample {json} response example:
{
  "_id": "5f9c5ef6fe66fb0a0e380286",
  "brandId": "5c1415685b03bb0008c21735",
  "brandName": "Dominion Energy, Inc.",
  "createdAt": "2020-10-30T18:44:06.717517Z",
  "createdBy": "5cb0a76b28386f7c5d65c9de",
  "customerStatus": true,
  "lastUpdated": "2020-10-30T18:44:06.717517Z",
  "name": "Dominion Energy, Inc. Supplier Analysis October 2020",
  "notes": "some notes",
  "password": "fs9D7Z1jGWz0",
  "slug": "Dw4JRyK5BTN2SST",
  "status": "IN_PROGRESS"
}

@apiError 400 Bad request
@apiError 403 Insufficient permissions
"""
@admin_bp.route('/supplier-analysis-reports', methods=['POST'])
@require_admin_permission
def create_analysis_report():
    report = request.get_json()
    if not report:
        raise UnsupportedPayload(None)

    if not v.validate(report, supplier_analysis_report_model.post_schema):
        raise InvalidPayload(v.errors)

    if not validate_existence('_id', ObjectId(report.get('brandId')), 'mm_brands'):
        raise GivewithError('brandId refers to a nonexistent brand')

    report = v.normalized(report, supplier_analysis_report_model.db_schema)
    if v.errors:
        raise ValidationError(v.errors)

    report = supplier_analysis_report_dao.add_report(report)

    return jsonify(report)


"""
@api {patch} /admin/supplier-analysis-reports/:_id Update Report
@apiName Update Report
@apiGroup Supplier Analysis Reports - Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Update supplier analysis report

@apiParam {String} _id the report id

@apiParamExample {json} request example:
{
    "customerStatus": true,
    "notes": "some notes",
    "suppliers": [
        "5c1415685b03bb0008c2171b"
    ]
}

@apiParamExample {json} response example:
{
  "_id": "5f9c27ae7dfa2fc7e257903b",
  "brandId": "5c1415685b03bb0008c21735",
  "brandName": "Dominion Energy, Inc.",
  "category": "Non IT",
  "createdAt": "2020-10-30T14:48:14.481000Z",
  "createdBy": "5cb0a76b28386f7c5d65c9de",
  "customerStatus": false,
  "lastUpdated": "2020-10-30T17:06:41.409000Z",
  "name": "name was updated",
  "password": "Z20Lhbe2WNl4",
  "slug": "OGD02bu92kH3pxR",
  "status": "COMPLETE",
  "suppliers": [
    {
      "_id": "5c1415685b03bb0008c2171b",
      "name": "SALLY BEAUTY HOLDINGS, INC."
    }
  ],
  "suppliersNotAnalyzed": 0
}

@apiError 400 Bad request
@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@admin_bp.route('/supplier-analysis-reports/<_id>', methods=['PATCH'])
@require_admin_permission
def patch_analysis_report_admin(_id):
    validate_object_id(_id, 'supplier_analysis_reports')

    report = request.get_json()
    if not report:
        raise UnsupportedPayload(None)

    if not v.validate(report, supplier_analysis_report_model.patch_schema_admin):
        raise InvalidPayload(v.errors)

    report = v.normalized(report, supplier_analysis_report_model.db_schema)
    if v.errors:
        raise ValidationError(v.errors)

    _filter = {'_id': ObjectId(_id)}
    report = supplier_analysis_report_dao.update_report(_filter, report)

    return jsonify(report)


"""
@api {delete} /admin/supplier-analysis-reports/:_id Delete Report
@apiName Delete Report
@apiGroup Supplier Analysis Reports - Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Delete supplier analysis report

@apiParam {String} _id the report id

@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@admin_bp.route('/supplier-analysis-reports/<_id>', methods=['DELETE'])
@require_admin_permission
def delete_analysis_report(_id):
    validate_object_id(_id, 'supplier_analysis_reports')

    supplier_analysis_report_dao.delete_report(_id)
    return '', 204


"""
@api {post} /matchmaking/supplier-analysis-reports/:slug/login Login to Report
@apiName Login to Report
@apiGroup Supplier Analysis Reports - Client
@apiVersion 0.1.0
@apiPermission token
@apiDescription Get a token for accessing a supplier analysis report by slug

@apiParam {String} slug - the report slug

@apiParamExample {json} request example:
{
  "password": "JRxFJKLmPoR",
}

@apiParamExample {json} response example:
{
  "token": "ABec32fBas/e32faAy6l32.b"
}

@apiError 400 Bad request
@apiError 401 Unauthorized
"""
@public_mm_bp.route('/supplier-analysis-reports/<slug>/login', methods=['POST'])
def deal_login(slug: str):
    document = request.get_json()
    if not document:
        raise UnsupportedPayload(None)

    password = document.get('password')
    if not password or not validate_existences({'slug': slug, 'password': password}, 'supplier_analysis_reports'):
        raise GivewithError(f'Invalid password for report with id {slug}', code=401)

    expires = (datetime.utcnow() + auth.TOKEN_VALIDITY).strftime(DATETIME_FORMAT)
    token = auth.create_token(f'{password}/password', slug, expires)

    return jsonify({'token': token})


"""
@api {get} /matchmaking/supplier-analysis-reports/:slug Get Report
@apiName Get Report
@apiGroup Supplier Analysis Reports - Client
@apiVersion 0.1.0
@apiPermission token
@apiDescription Get a report by slug

@apiParam {String} slug - the report slug

@apiParamExample {json} response example:
{
  "brandName": "Neon Therapeutics Inc",
  "category": "NON IT",
  "name": "My custom name",
  "slug": "1Qy4mXLrSJIpvb2",
  "status": "IN_PROGRESS",
  "topics": ["Education", "Environment"],
  "suppliers": [
    {
      "_id": "5c1415685b03bb0008c2171b",
      "name": "SALLY BEAUTY HOLDINGS, INC."
      "matchProportion": 0.7,
      "inProgress": true,
      "topics": {
          "Environment": 3
      }
    },
  ],
  "suppliersNotAnalyzed": 1
}

@apiError 401 Unauthorized
"""
@public_mm_bp.route('/supplier-analysis-reports/<slug>', methods=['GET'])
@auth.validate_token_against_collection('supplier_analysis_reports')
def get_analysis_report_client(slug):
    _filter = {'slug': slug}
    report = supplier_analysis_report_dao.get_report(_filter)
    report = supplier_analysis_report_dao.add_report_analysis(report, CLIENT_RETURN_FIELDS)

    return jsonify(report)


'''
@api {patch} /matchmaking/supplier-analysis-reports/:slug Update Report
@apiName Update Report
@apiGroup Supplier Analysis Reports - Client
@apiVersion 0.1.0
@apiPermission token
@apiDescription Update supplier analysis report

@apiParam {String} slug the report slug

@apiParamExample {json} request example:
{
  "name": "Dell 2020 report",
  "category": "Non IT"
  "suppliers": [
    "5c1415685b03bb0008c2171b"
  ]
}

@apiParamExample {json} response example:
{
  "name": "name was updated",
  "brandName": "Dominion Energy, Inc.",
  "category": "Non IT",
  "slug": "OGD02bu92kH3pxR",
  "status": "COMPLETE",
  "topics": ["Education", "Environment"],
  "suppliers": [
    {
      "_id": "5c1415685b03bb0008c2171b",
      "name": "SALLY BEAUTY HOLDINGS, INC."
      "matchProportion": 0.7,
      "inProgress": false,
      "topics": {
          "Environment": 3
      }
    },
  ],
  "suppliersNotAnalyzed": 0
}

@apiError 400 Bad request
@apiError 403 Insufficient permissions
@apiError 404 Not found
'''
@public_mm_bp.route('/supplier-analysis-reports/<slug>', methods=['PATCH'])
@auth.validate_token_against_collection('supplier_analysis_reports')
def patch_analysis_report_client(slug):
    report = request.get_json()
    if not report:
        raise UnsupportedPayload()

    if not v.validate(report, supplier_analysis_report_model.patch_schema_client):
        raise InvalidPayload(v.errors)

    report = v.normalized(report, supplier_analysis_report_model.db_schema)
    if v.errors:
        raise ValidationError(v.errors)

    _filter = {'slug': slug}
    report = supplier_analysis_report_dao.update_report(_filter, report)
    report = supplier_analysis_report_dao.add_report_analysis(report, CLIENT_RETURN_FIELDS)

    return jsonify(report)


"""
@api {get} /matchmaking/supplier-analysis-reports/industries Get Industries
@apiName Get Industries
@apiGroup Supplier Analysis Reports - Client
@apiVersion 0.1.0
@apiPermission token
@apiDescription Get industries

@apiParamExample {json} response example:
{
  "CPG (Consumer Packaged Goods)": [
    {
      "displayLabel": "Beverages",
      "subIndustry": "Soft Drinks"
    },
    {
      "displayLabel": "Food Products",
      "subIndustry": "Packaged Foods & Meats"
    },
  ],
  "Commercial & Professional Services": [
    {
      "displayLabel": "Commercial Services & Supplies",
      "subIndustry": "Diversified Support Services"
    },
    {
      "displayLabel": "Professional Services",
      "subIndustry": "Research & Consulting Services"
    }
  ]
}

@apiError 401 Unauthorized
"""
@public_mm_bp.route('/supplier-analysis-reports/industries', methods=['GET'])
@auth.validate_token_against_collection('supplier_analysis_reports')
def get_industries():
    return jsonify(get_industry_display_map())
