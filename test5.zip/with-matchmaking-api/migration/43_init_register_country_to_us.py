from matchmaking import db

# update registeredCountry for nonprofit
db().coll_nonprofits.update_many({'registeredCountry': ''}, {'$set': {'registeredCountry': 'US'}})

# update registeredCountry for recommended programs in deals
deals = list(db().coll_deals.find({'selectedRecommendedPrograms': {'$exists': True}}))
for deal in deals:
    for program in deal['selectedRecommendedPrograms']:
        if program.get('registeredCountry', '') == '':
            program['registeredCountry'] = 'US'

    db().coll_deals.update_one({'_id': deal['_id']}, {'$set': deal})
