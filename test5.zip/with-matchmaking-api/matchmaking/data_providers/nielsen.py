import pandas as pd

from bson import ObjectId
from flask import current_app

from ..mongodb import (filter_base_responses_by_company, filter_responses_by_company,
                       filter_base_responses_by_industry, filter_responses_by_industry,
                       get_nielsen_industry, get_vocabulary_label_v2)


def get_consumer_preferences_from_brand(brand, selected_themes=False):
    nielsen_company = brand.get('nielsen_company')

    if nielsen_company:
        nielsen_industry = ''
    else:
        # Fallback to industry if industryName isn't found
        industry = brand.get('industryName', brand.get('industry', ''))
        nielsen_industry = get_nielsen_industry(industry)

    if selected_themes:
        selected_themes = brand.get('nielsen_selected_themes')

    return get_consumer_preferences(nielsen_company, nielsen_industry, selected_themes=selected_themes)


def get_consumer_preferences(nielsen_company, nielsen_industry, selected_themes=[]):
    source = ''
    if nielsen_company:
        respondents = filter_base_responses_by_company(nielsen_company)
        responses = filter_responses_by_company(nielsen_company)
        source = 'company'

    elif nielsen_industry:
        respondents = filter_base_responses_by_industry(nielsen_industry)
        responses = filter_responses_by_industry(nielsen_industry)
        source = 'industry'

    else:
        return {}

    data = _calc_means_by_theme(respondents, responses)
    data = _filter_consumer_preferences(data, selected_themes)
    data = data.to_dict('index')

    return {
        'data': data,
        'source': source
    }


def get_target_demographics_from_brand(brand):
    """ Return's brands target demographics arranged by theme"""
    demographics = brand.get('nielsenDemographics', [])
    result = {}

    for demographic in demographics:
        if demographic.get('visibility', True):
            for theme in demographic.get('selected_themes', []):
                theme_id = theme.get('valueId')
                result.setdefault(theme_id, {}).setdefault('audiences', []).append({
                    'description': demographic.get('description', ''),
                    'percentage': float(theme.get('valuePercentage', 0))
                })

    return result


def _calc_means_by_theme(respondents, responses):
    # Get respondents and responses as dataframes, then combine them
    df = pd.DataFrame(respondents)
    df['theme_id'] = 'base'
    df = pd.DataFrame(responses).append(df)

    # Filter zero values because '0' is used as a non-answer in Nielsen
    _filter_purchase = df['likelihood_to_purchase'] > 0
    _filter_recommend = df['likelihood_to_recommend'] > 0
    df = df[_filter_purchase & _filter_recommend]

    # Set up a count column for the aggregation
    df['sample_size'] = 0

    # Group by theme and find means for likelihood to recommend/purchase per theme
    agg = {'likelihood_to_purchase': 'mean', 'likelihood_to_recommend': 'mean', 'sample_size': 'count'}
    agg_keys = list(agg.keys())
    df = df.groupby('theme_id')[agg_keys].agg(agg)

    # Find theme labels for their respective IDs
    _map = lambda x: 'base' if x == 'base' else get_vocabulary_label_v2(x)
    df = df.set_index(df.index.map(_map))

    return df.sort_index()


def _filter_consumer_preferences(nielsen_df, selected_themes=[], filter_negative=True):
    """
    Filter nielsen data by selected themes or, if not by selected themes,
    by themes whose value went down
    """
    if selected_themes:
        selected_themes.append('base')
        selected_themes = set(selected_themes)

        # Check if themes are valid because invalid themes will create rows filled with NaN's
        valid_selected_themes = set(nielsen_df.index.tolist()).intersection(selected_themes)
        invalid_selected_themes = selected_themes - valid_selected_themes
        if invalid_selected_themes:
            current_app.logger.warning(f'Invalid selected_themes {invalid_selected_themes}')

        nielsen_df = nielsen_df.loc[valid_selected_themes]

    elif filter_negative:
        base = nielsen_df.loc['base']
        _filter_purchase = nielsen_df['likelihood_to_purchase'] >= base['likelihood_to_purchase']
        _filter_recommend = nielsen_df['likelihood_to_recommend'] >= base['likelihood_to_recommend']
        nielsen_df = nielsen_df[_filter_purchase & _filter_recommend]

    return nielsen_df

