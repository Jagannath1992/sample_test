from bson import ObjectId
from portal.testing.faker import DocumentFaker
from portal.shared import dates
from portal.shared.enums import InstanceStatus, InstanceType


class InstanceSettingsFaker(DocumentFaker):
    def _generate_document(self, i):
        now = dates.get_utcnow()
        document = {
            '_id': ObjectId(),
            'name': f'Instance {i}',
            'description': f'Instance Settings {i}',
            'settings': {
                'locale': {
                    '_id': ObjectId(),
                    '_type': 'locale',
                    'name': 'US',
                },
                'loginUrl': 'http://localhost:8080',
                'portalUrl': 'https://localhost:8085',
                'givewithEmail': 'assist-test@givewith.com',
                'serviceFee': 0.18,
                'allowRegistration': True,
                'termsOfUseUrl': 'https://www.givewith.com/terms-of-use/',
                'cookiePolicyUrl': 'https://www.givewith.com/cookie-policy-eu/',
                'privacyPolicyUrl': 'https://www.givewith.com/privacy-policy/',
                'sage': {
                    'locationId':  '100',
                    'exchangeRate': 'Intacct Daily Rate',
                    'taxSolutionId': '',
                    'invoiceTaxDetailId': '',
                    'billTaxDetailId': '',
                    'accounts': {
                        'socialImpactPayable': '20020',
                        'socialImpactEnablement': '40010',
                        'subscriptionRevenue': '40000',
                        'transactionRevenue': '40005'
                    },
                    'departments': {
                        'sales': '1300',
                        'socialImpact': '600'
                    },
                    'products': {
                        'annualSubscription': 'Givewith for Sales - Annual Subscription',
                        'monthlySubscription': 'Givewith for Sales - Monthly Subscription',
                        'transaction': 'Givewith for Sales - Transaction'
                    }
                },
                'stripe': {
                    'trialPeriodDays': 30,
                    'currencyFactor': 0.01,
                    'prices': {
                        'monthly': {
                            'id': 'price_1KjQjAFpuAfBZp0KrlBgK1Qj',
                            'amount': 499.00,
                            'footer': None,
                            'enabled': True,
                        },
                        'annual': {
                            'id': 'price_1L2dc0FpuAfBZp0KsVPHLu2i',
                            'amount': 4999.00,
                            'footer': '$1000 savings',
                            'enabled': True,
                        },
                        'required': True,
                    },
                    'suppliers': {
                        'monthly': {
                            'id': 'price_1KjQjAFpuAfBZp0KrlBgK1Qj',
                            'amount': 499.00,
                            'footer': None,
                            'enabled': False,
                        },
                        'annual': {
                            'id': 'price_1L2dc0FpuAfBZp0KsVPHLu2i',
                            'amount': 4999.00,
                            'footer': '$1000 savings',
                            'enabled': False,
                        },
                        'required': False,
                    },
                }
            },
            'causeAreas': [{
                'causeArea': {
                    '_id': ObjectId(),
                    '_type': 'cause_area',
                    'name': f'causeArea name {i}'
                },
                'skus': [],
                'displayOrder': 1,
                'active': True,
                'impact': {
                    'unitPrice': 100,
                    'unitValue': 10,
                    'impactMeasurement': 'meals'
                },
                'assignedDate': now
            }],
            'skus': [100, 1000, 10000],
            'restrictedDomains': [],
            'status': InstanceStatus.ACTIVE.value,
            'type': InstanceType.DEFAULT.value,
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now,
        }
        return document
