from datetime import datetime, timedelta
import sys
from bson.errors import InvalidId
from flask import jsonify, request, Blueprint, current_app
from werkzeug.utils import secure_filename
from pymongo import DESCENDING
from os import environ

from matchmaking.controllers.dashboard.pilot_deal import download_pilot_deliverable
from matchmaking.service.email import NotificationEmail
from matchmaking.service.recommendations import get_deal_recommended_programs, select_programs, filter_selected_programs
from matchmaking.dao.utils import get_documents, get_document_by_id, update_document_by_id, get_document
from .utils import (get_brand_by_id, get_program_by_id, get_program_by_id_or_slug,
                    get_nonprofit_by_id, find_program_in_deals, get_related_qualified_programs,
                    get_user_by_id, get_gw_customer_and_client_names, lookup_by_field, lookup_by_fields,
                    transform_program, check_deal_is_valid, transform_programs, get_insights,
                    format_metric_fields, calculate_commerce_outputs, transform_outputs_to_commerce_outputs_v2,
                    annotate_nonprofits_with_programs, add_deliverables, get_deal_test_flag)
from ..matchmaking.brands.utils import is_brand_verified_by_admin
from ..matchmaking.programs import create_virtual_fields, math_strength_rating, append_virtual_fields_v2, filter_program
from ...validation.utils import validate_object_id, validate_existences
from ...auth import TOKEN_VALIDITY, create_token
from ...models.models import v, APISchema_deal, DBSchema_deal, Currency
from ...controllers import admin_bp
from ...mongodb import (ObjectId, expand_vocabulary_label, get_vocabulary_label_v2, get_recommendations_limit,
                        get_selected_recommended_programs, get_next_reference_value, get_vocabulary_v2,
                        get_tvl_data, db, copy_deliverables_and_licensing, get_deal, get_program)
from ...utils import (set_created_at, set_last_updated, is_deal_link_expired, EntityNotFound, UnsupportedId,
                      UnsupportedPayload, InvalidPayload, GivewithError, DATETIME_FORMAT, ValidationError, remove_none,
                      generate_secure_password, generate_random_slug, DealStatus, SurveyStatus)
from ...s3 import delete_file, save_custom_deliverable_to_s3

from ...utils import send_loggly, get_descendant_key, set_descendant_key
from ...permission_decorator import require_admin_permission
from ...util import audit_logger
from pymongo import ReturnDocument
from ..deliverables.deliverables import download_one_deliverable

COVID_ASSETS_PASSWORD = environ.get('COVID_ASSETS_PASSWORD', '')
DEFAULT_GIVEWITH_FEE_PERCENTAGE = 15

entity_name = 'deal'
target_collection = 'deals'

protected_commerce_bp = Blueprint('commerce', __name__)
public_commerce_bp = Blueprint('public_commerce', __name__)


# used in except blocks within try,except statements
def fill_selected_program_fields(document):
    try:
        try:
            program = get_program_by_id(document['selectedProgram'])
        except (EntityNotFound, InvalidId):
            program = None
        if not program:
            current_app.logger.warning("selectedProgram not found on DB, removing from deal")
            return document.pop('selectedProgram', None)

        document['programName'] = program['name']
        nonprofit = get_nonprofit_by_id(program['nonprofit'])
        if nonprofit:
            document['nonprofitName'] = nonprofit['name']

    except (KeyError, EntityNotFound):
        current_app.logger.warning("Error retrieving programName or nonprofitName for selectedProgram")

# Copied from Sales-api Modified the function from give_percentage to gw_portion 
def calculate_give_portion(gw_portion, budget, givewith_fee_percentage=DEFAULT_GIVEWITH_FEE_PERCENTAGE):
    # gw_portion is the same as impact incentive amount
    # gw_portion = round(budget * (give_percentage / 100), 2)
    # for example, givewith_fee_percentage is 15, so the funding_percent should be .85
    funding_percent = (100 - givewith_fee_percentage) / 100
    # total funding is the amount to the SIO
    total_funding = round(gw_portion * funding_percent, 2)
    return total_funding

# used on commerce side
def get_deal_program(deal, program, role, include_recs=True):
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit', 'invalid-slug')})

    try:

        if not deal:
            raise GivewithError('Deal not found')

        if not program:
            raise EntityNotFound('Program not found')

        if not role:
            raise EntityNotFound('Role not found')

        if nonprofit:
            program['nonprofit'] = nonprofit

        brand = get_brand_by_id(deal[role])
        customer_brand = brand if role == 'givewithCustomer'\
          else get_brand_by_id(deal['givewithCustomer'], projection=['isPilot', 'givePercentageCurrency'])

        should_replace_program_outputs = str(program['_id']) == str(deal.get('selectedProgram')) \
            and not customer_brand.get('isPilot') and DealStatus.get(deal.get('status')) == DealStatus.COMPLETE

        if should_replace_program_outputs:
            funding_form = get_document(
                'program_funding_forms',
                query={
                    'deal': ObjectId(deal['_id']),
                    'status': {'$in': [str(SurveyStatus.APPROVED), str(SurveyStatus.EXECUTED)]}
                },
                sort=[('lastUpdated', DESCENDING)],
                projection=['objects']
            )

            if funding_form:
                program['outputs'] = funding_form.get('objects', [])

        # Need to recompute fresh recommendations just for the related programs.
        recommended_programs = []
        if include_recs:
            has_percentages = bool(not deal.get('recommendedPercentages'))
            recommended_programs = get_deal_recommended_programs(deal, get_percentages=has_percentages)

        funding_currency = deal.get('currency') or customer_brand.get('givePercentageCurrency') or str(Currency.USD)
        funding_amount = deal.get('fundingAmount') or 50_000
        funding_amount_minus_scalewith_admin_fee = calculate_give_portion(funding_amount, deal.get('totalBudget', 0), deal.get('givewithFeePercentage', 15))
        return get_brand_program(brand, program, recommended_programs, funding_amount_minus_scalewith_admin_fee, funding_currency)

    except EntityNotFound as e:
        current_app.logger.error('Not found entity associated to deal: {0}'.format(e))
        raise e

def get_event_deal_program(deal, program):
    if not deal:
        raise GivewithError('Deal not found')

    if not program:
        raise EntityNotFound('Program not found')

    nonprofit = get_document_by_id('mm_nonprofits', program['nonprofit'], projection=[
        'name', 'overviewAndMission.lifetimeOutputs', 'general.social.websiteURL',
        'description', 'vimeoId', 'videoFallback'
    ])
    program['nonprofit'] = nonprofit

    funding_currency = deal.get('currency')
    if not funding_currency:
        event = get_document_by_id('event', deal['eventId'], projection=['customer'])
        customer_brand = get_document_by_id('mm_brands', event['customer'], projection=['givePercentageCurrency'])
        funding_currency = customer_brand.get('givePercentageCurrency') or str(Currency.USD)

    deal_selected_program = next(p for p in deal['selectedPrograms'] if p['programId'] == program['_id'])
    funding_amount = deal_selected_program.get('fundingAmount') or 50_000

    supplier = get_document_by_id('mm_brands', deal['supplier'])

    recommended_programs = [] # no recs required on pilot links
    return get_brand_program(supplier, program, recommended_programs, funding_amount, funding_currency)


def get_brand_program(brand, program, recommended_programs, funding_amount, funding_currency):
    """Merges a brand insights onto a program"""
    nonprofit = db().coll_nonprofits.find_one({'_id': program.get('nonprofit', 'invalid-slug')})

    if nonprofit:
        program['nonprofit'] = nonprofit

    # metric fields need to be calculated before program is manipulated
    metric_fields = format_metric_fields(brand, program)
    brand_sasb = brand.get('sasb', {}).get('categories', {}).get('tagged', {}).get('ids', [])
    program_sasb = program.get('sasb', {}).get('data', [])

    # only include overlap sasb
    overlap_sasb = []

    for sasb_id in brand_sasb:
        if ObjectId(sasb_id) in program_sasb:
            overlap_sasb.append(ObjectId(sasb_id))

    isin_id = brand.get('ISIN')
    program['tvl'] = get_tvl_data(isin_id, program_sasb).get('labels', [])

    program['sasb'] = overlap_sasb
    program['csrhub'] = program.get('csrhub', {}).get('data', {})
    program['topics'] = list({get_vocabulary_v2(_id).get('topic') for _id in program.get('themes', {}).get('data', [])})

    program_version = program.get('version')

    if program_version == 2:
        append_virtual_fields_v2(program)
        transform_outputs_to_commerce_outputs_v2(program.get('outputs', []),
                                                 program.get('budget'),
                                                 program.get('currency', str(Currency.USD)),
                                                 funding_amount,
                                                 funding_currency)
    else:
        math_strength_rating(program)
        create_virtual_fields(program)
        calculate_commerce_outputs(program, funding_amount)

    expand_vocabulary_label(program, version=program_version)

    program.update(metric_fields)

    if not program.get('impactMultipleVisibility', True):
        program.pop('impactMultiple', None)

    if recommended_programs:
        program['match'] = find_program_in_deals(program['name'], recommended_programs).get('match')

        program['related'] = [i for i in
                              get_related_qualified_programs(program.get(
                                  'nonprofit', {}).get('_id'), recommended_programs,
                                  funding_amount, funding_currency)
                              if i.get('slug') != program.get('slug')]

    program.update(
        db().coll_settings.find_one(
            {}, projection={'_id': False, 'contentSettings': True}))

    return filter_program(program)


##
# Admin Protected Endpoints
##
@admin_bp.route('/deals', methods=['GET'])
@require_admin_permission
def admin_list_deals():
    """ List all available Deals
    ---
    tags: ['Deal Admin']

    security:
      - GivewithAuth: []

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                type: object
                properties:
                  _id:
                    type: string
                  slug:
                    type: string
                  title:
                    type: string
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    def transform_deal(deal):
        names_dict = get_gw_customer_and_client_names(deal, separate_labels=True)
        deal.update(names_dict)
        return deal

    projection = {
        '_id': True,
        'givewithCustomer': True,
        'client': True,
        'reference': True,
        'name': True,
        'managerName': True,
        'lastUpdated': True,
        'status': True,
        'selectedProgram': True,
        'givewithCustomerRole': True,
        'slug': True,
        'statusUpdatedAt': True
    }

    deals = db().coll_deals.find(request.filter_params, projection=projection).skip(request.skip).limit(request.page_size).sort(request.sort_params)

    if (request.args.get('hasPFF')):
      deal_ids = [x['_id'] for x in deals]
      filtered_deals = [x['_id'] for x in db().coll_program_funding_forms.find({'deal': {'$in': deal_ids}, 'status': 'APPROVED'})]
      deals = [x for x in deals if x['_id'] in filtered_deals]

    return jsonify([transform_deal(deal) for deal in deals])


@admin_bp.route('/deals/<id>', methods=['GET'])
@require_admin_permission
def admin_get_deal_by_id(id):
    """ Fetch Deal data
    ---
    tags: ['Deal Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Deal'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    return admin_get_deal_by_id_handler(id)


def admin_get_deal_by_id_handler(id, include_recommendations=True):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deal = db().coll_deals.find_one({'_id': obj_id})
    if not deal:
        raise EntityNotFound(entity_name, id)

    is_covid = deal.get('type') == 'covid'

    has_percentages = bool(not deal.get('recommendedPercentages'))

    givewith_customer_id = deal.get('givewithCustomer')
    givewith_customer = get_document_by_id('mm_brands', givewith_customer_id)

    if not deal.get('paymentOption'):
        deal['paymentOption'] = givewith_customer.get('paymentOption')

    deal['customerProposalOptions'] = givewith_customer.get('proposalOptions', {})

    if include_recommendations:
        deal['recommendedPrograms'] = [] if is_covid else get_deal_recommended_programs(deal, include_invalid=True, get_percentages=has_percentages)

    # Always slice selectedRecommendations to ensure the limit isn't exceeded
    if deal.get('selectedRecommendedPrograms'):
        deal['selectedRecommendedPrograms'] = deal['selectedRecommendedPrograms'][0:get_recommendations_limit()]

    deal.update(get_gw_customer_and_client_names(deal))

    # Add givewith customer and client user's name
    if deal.get('givewithCustomerUser'):
        customer_user = get_user_by_id(deal['givewithCustomerUser'])
        if customer_user:
            deal['givewithCustomerUserName'] = customer_user.get('name')

    if deal.get('clientUser'):
        client_user = get_user_by_id(deal['clientUser'])
        if client_user:
            deal['clientUserName'] = client_user.get('name')

    client = get_brand_by_id(deal['client'])
    deal['clientIsVerified'] = is_brand_verified_by_admin(client)

    # Add the name of the name of the client who confirmed proposal
    if deal.get('confirmation') and deal.get('confirmation').get('confirmedBy'):
        deal['confirmation']['confirmedByName'] = get_user_by_id(deal['confirmation']['confirmedBy'])['name']

    deal['fundingForms'] = list(db().coll_program_funding_forms.find({'deal': obj_id}, projection={'name': True}))

    return jsonify(deal)


@admin_bp.route('/deals', methods=['POST'])
@require_admin_permission
def insert_deal():
    """ Create new Deal
    ---
    tags: ['Deal Admin']

    security:
      - GivewithAuth: []

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Deal'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Deal'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    # sales deal specific validation
    if document.get('type') == 'sales':
        sales_required_fields = ['givewithCustomer', 'givewithCustomerUser', 'givewithCustomerRole', 'client', 'currency']
        for f in sales_required_fields:
            if f not in document:
                raise GivewithError(f'{f} is required for sales deal', code=400)
    else:
        v.validate(document, APISchema_deal)
        if v.errors:
            current_app.logger.warning('Input Deal validation errors: {0}'.format(v.errors))
            raise InvalidPayload(v.errors)

    document.pop('_id', None)

    document['reference'] = get_next_reference_value('deals')

    document['slug'] = generate_random_slug()

    if 'password' not in document:
        document['password'] = generate_secure_password()

    document['createdBy'] = request.user['_id']

    givewith_customer_id = ObjectId(document['givewithCustomer'])
    givewith_customer = get_document_by_id('mm_brands', str(givewith_customer_id))
    givewith_customer_name = givewith_customer.get('nameLabel', givewith_customer.get('name', '-'))

    client_id = ObjectId(document['client'])
    client_brand = get_document_by_id('mm_brands', str(client_id))
    client_name = client_brand.get('nameLabel', client_brand.get('name', '-'))

    if len(document.get('name', '')) == 0:
        document['proposalName'] = f'{givewith_customer_name} w/ {client_name}'

    if 'totalBudget' in document:
        document['total_budget'] = float(document['totalBudget'])

    if 'manager' in document and 'managerName' not in document:
        document['managerName'] = lookup_by_field(document, 'manager', 'name', get_user_by_id)

    if 'status' not in document:
        document['status'] = str(DealStatus.PROGRAM_SELECTION_PENDING)

    if 'type' not in document:
        document['type'] = 'enterprise'

    if 'paymentOption' not in document:
        document['paymentOption'] = givewith_customer.get('paymentOption', 'payAsYouGo')

    ## COVID deals do not require recommendations / a selected program
    is_covid = document.get('type') == 'covid'

    recommended_programs = [] if is_covid else get_deal_recommended_programs(document, include_invalid=True)

    if 'selectedRecommendedPrograms' not in document:
        program_limit= None
        if document.get('type') == 'sales':
            program_limit = 3

        document['selectedRecommendedPrograms'] = select_programs(recommended_programs, limit=program_limit)

    if 'selectedProgram' in document:
        try:
            program = next(filter(lambda p: p['_id'] == document['selectedProgram'],
                                  document.get('selectedRecommendedPrograms', None)), None)
            document['programName'] = program['name']
            document['nonprofitName'] = program['nonprofitName']
        except (KeyError, TypeError):
            fill_selected_program_fields(document)

        # Add program selection date (while keeping existing sub fields)
        document.setdefault('selectedProgramMeta', {}).update({'selectedAt': datetime.utcnow()})
    elif not is_covid:
        deal_status = document.get('status')
        if DealStatus.get(deal_status) > DealStatus.PROGRAM_SELECTION_PENDING and \
          document.get('type') != 'real-estate-community-assets':
            raise GivewithError(f'Deal with {deal_status} status requires a selected program', code=400)

    # set status selection date
    document['statusUpdatedAt'] = datetime.utcnow()

    document['isValid'] = check_deal_is_valid(document)

    document['deliverables'] = add_deliverables()

    document['recommendedPercentages'] = {str(p['_id']): p['match'] for p in recommended_programs}

    document['recommendedPercentagesDate'] = datetime.utcnow()

    document = v.normalized(document, DBSchema_deal)

    # set isTest flag
    document['isTest'] = get_deal_test_flag(document)

    if v.errors:
        raise ValidationError(v.errors, code=400)
    document['_id'] = db().coll_deals.insert_one(set_created_at(document)).inserted_id

    # Audit log
    audit_logger.log('admin-matchmaking-api', str(request.user['_id']), 'proposal', str(document['_id']), 'create', '', '')

    # Add recommendations just for the response, not to the DB
    document['recommendedPrograms'] = recommended_programs

    names_dict = get_gw_customer_and_client_names(document)
    document.update(names_dict)

    customerBrand = document.get('givewithCustomer')

    if customerBrand:
        brand = get_brand_by_id(customerBrand, projection={'splitGiveAmount': True, 'proposalOptions': True})
        splitGiveAmount = brand.get('splitGiveAmount', False)
        document['splitGiveAmount'] = splitGiveAmount

        document['customerProposalOptions'] = brand.get('proposalOptions', {})

    if is_covid:
        document['confirmation'] = {}
        document['confirmation']['confirmedAt'] = datetime.utcnow()

    # Add givewith customer and client user's name
    if document.get('givewithCustomerUser'):
        document['givewithCustomerUserName'] = get_user_by_id(document['givewithCustomerUser'])['name']
        customer_emails = []
        customer_emails.append(get_user_by_id(document['givewithCustomerUser'])['username'])
        document['givewithCustomerEmails'] = customer_emails
    if document.get('clientUser'):
        document['clientUserName'] = get_user_by_id(document['clientUser'])['name']
        client_emails = []
        client_emails.append(get_user_by_id(document['clientUser'])['username'])
        document['clientEmails'] = client_emails

    # Add the name of the name of the client who confirmed proposal
    if document.get('confirmation') and document.get('confirmation').get('confirmedBy'):
        document['confirmation']['confirmedByName'] = get_user_by_id(document['confirmation']['confirmedBy'])['name']

    send_loggly("PROPOSAL: CREATE NEW PROPOSAL BY POST by " + str(request.user['_id']) + ": status: " + str(document.get('status', "No Status Change")))

    return jsonify(document)


@admin_bp.route('/deals/<id>', methods=['PUT'])
@require_admin_permission
def update_deal(id):
    """ Replace Deal data
    ---
    tags: ['Deal Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Deal'

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Deal'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    document.pop('_id', None)
    document.pop('reference', None)

    v.validate(document, APISchema_deal)
    if v.errors:
        current_app.logger.warning('Input Deal validation errors: {0}'.format(v.errors))
        raise InvalidPayload(v.errors)

    db_document = db().coll_deals.find_one({'_id': obj_id})
    if not db_document:
        raise EntityNotFound(entity_name, id)

    document['slug'] = db_document['slug']
    document['reference'] = db_document['reference']
    document['createdBy'] = db_document.get('createdBy', request.user['_id'])

    if 'totalBudget' in document and document['totalBudget']:
        document['total_budget'] = float(document['totalBudget'])

    if 'status' not in document:
        document['status'] = db_document['status']

    if 'manager' in document and 'managerName' not in document:
        document['managerName'] = lookup_by_field(document, 'manager', 'name', get_user_by_id)

    ## COVID deals do not require recommendations / a selected program
    is_covid = document.get('type') == 'covid'

    has_percentages = bool(not db_document.get('recommendedPercentages'))

    recommended_programs = [] if is_covid else get_deal_recommended_programs(document, include_invalid=True, get_percentages=has_percentages)

    if 'selectedRecommendedPrograms' not in document:
        # Reset recommendation when the field selectedRecommendedPrograms is absent
        document['selectedRecommendedPrograms'] = select_programs(recommended_programs)

    if 'selectedProgram' in document:
        try:
            program = next(filter(lambda p: p['_id'] == document['selectedProgram'],
                           document.get('selectedRecommendedPrograms', None)), None)
            document['programName'] = program['name']
            document['nonprofitName'] = program['nonprofitName']
        except (KeyError, TypeError):
            fill_selected_program_fields(document)

        # Add program selection date if new program selected (while keeping existing sub fields)
        if ObjectId(document.get('selectedProgram')) != db_document.get('selectedProgram'):
            document.setdefault('selectedProgramMeta', {}).update({'selectedAt': datetime.utcnow()})
        # ensure selectedAt is kept as datetime if no updates were made
        elif db_document.get('selectedProgramMeta', {}).get('selectedAt'):
            document.get('selectedProgramMeta', {})['selectedAt'] = db_document['selectedProgramMeta']['selectedAt']
    elif not is_covid:
        deal_status = document.get('status')
        if DealStatus.get(deal_status) > DealStatus.PROGRAM_SELECTION_PENDING and \
          document.get('type') != 'real-estate-community-assets':
            raise GivewithError(f'Deal with {deal_status} status requires a selected program', code=400)

    # set status selection date
    if document.get('status') != db_document.get('status'):
        document['statusUpdatedAt'] = datetime.utcnow()

        if 'selectedProgram' in document:
            try:
                # deal is moving from a status below PAYMENT_PENDING to a status >= payment_pending, copy deliverables
                db_document_status = DealStatus.get(db_document.get('status'))
                document_status = DealStatus.get(document.get('status'))

                if db_document_status < DealStatus.PAYMENT_PENDING and document_status >= DealStatus.PAYMENT_PENDING:
                    copy_deliverables_and_licensing(obj_id, document)

            except Exception as exz:
                print(exz, file=sys.stderr)  # errors shouldn't block, just move forward, will have to upload manually
    elif db_document.get('statusUpdatedAt'):
        document['statusUpdatedAt'] = db_document['statusUpdatedAt']

    document['isValid'] = check_deal_is_valid(document)

    document = v.normalized(document, DBSchema_deal)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    document['_id'] = obj_id
    if db_document.get('createdAt'):
        document['createdAt'] = db_document['createdAt']

    status = document.get('status')
    if DealStatus.get(status) < DealStatus.PAYMENT_PENDING and document.get('clientConfirmation'):
        document.pop('clientConfirmation', {})

    if 'isTest' not in document:
        document['isTest'] = get_deal_test_flag(document)

    db().coll_deals.replace_one(filter={'_id': obj_id}, replacement=set_last_updated(document))

    customer_brand = get_brand_by_id(document.get('givewithCustomer'), projection={'splitGiveAmount': True, 'proposalOptions': True})
    document['customerProposalOptions'] = customer_brand.get('proposalOptions', {})

    # Add recommendations just for the response, not to the DB
    document['recommendedPrograms'] = recommended_programs

    document.update(get_gw_customer_and_client_names(document))

    # Add givewith customer and client user's name
    if document.get('givewithCustomerUser'):
        document['givewithCustomerUserName'] = get_user_by_id(document['givewithCustomerUser'])['name']
    if document.get('clientUser'):
        document['clientUserName'] = get_user_by_id(document['clientUser'])['name']
    if document.get('givewithCustomerEmails'):
        document['givewithCustomerEmails'] = list(set(document['givewithCustomerEmails']))
    if document.get('clientEmails'):
        document['clientEmails'] = list(set(document['clientEmails']))

     # Add the name of the name of the client who confirmed proposal
    if document.get('confirmation') and document.get('confirmation').get('confirmedBy'):
        document['confirmation']['confirmedByName'] = get_user_by_id(document['confirmation']['confirmedBy'])['name']

    send_loggly("PROPOSAL: MODIFY DEAL BY PUT DEAL_ID:" + str(obj_id) + " edited by " + str(request.user['_id']) + ": status: " + str(document.get('status', "No Status Change")))
    audit_logger.log('admin-matchmaking-api', str(request.user['_id']), 'proposal', str(obj_id), 'update', 'PUT', '')

    if document.get('type') == 'sales':
        if DealStatus.get(status) == DealStatus.COMPLETE:
            NotificationEmail(objective='completed', roles=['customer', 'client'], data=document).send()

        return jsonify(document)

    if document.get('type') == 'real-estate' or document.get('type') == 'real-estate-community-assets':
        # if DealStatus.get(status) == DealStatus.COMPLETE:
            # NotificationEmail(objective='real_estate_completed', roles=['customer'], data=document).send()

        return jsonify(document)

    if status != db_document.get('status'):
        audit_logger.log('admin-matchmaking-api', str(request.user['_id']), 'proposal', str(obj_id), 'status', '', status)
        # only send emails if preventUpdateEmail flag is turned off
        if document.get('preventUpdateEmail') is not True:
            # notify customer and client when deal status changed.
            if DealStatus.get(status) == DealStatus.PROGRAM_SELECTION_PENDING:
                NotificationEmail(objective='program_selection_pending', roles=['customer'], data=document).send()
            elif DealStatus.get(status) == DealStatus.CONFIRMATION_PENDING:
                NotificationEmail(objective='program_selected', roles=['customer'], data=document).send()
            elif DealStatus.get(status) == DealStatus.COMPLETE:
                if document.get('type', '') == 'covid':
                    NotificationEmail(objective='covid_completed', roles=['customer', 'client'], data=document).send()
                else:
                    NotificationEmail(objective='completed', roles=['customer', 'client'], data=document).send()


    return jsonify(document)

@admin_bp.route('/deals/<id>/save-deliverable-to-deal', methods=['PATCH'])
@require_admin_permission
def get_deliverable_for_deal(id):
    validate_object_id(id, 'deals')
    obj_id = ObjectId(id)

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    asset_location = document.get('assetLocation')
    asset_type = document.get('assetType')

    if not asset_location or not asset_type:
      raise GivewithError('Asset location or asset type not specified')

    deal = get_deal(obj_id, projection={'selectedProgram': True, 'deliverables': True})
    if not deal:
        raise EntityNotFound(entity_name, id)

    program_deliverable_name_mapping = {
      'Photos': 'photoGallery',
      'LongFormVideo': 'longVideo',
      'ShortFormVideo': 'shortVideo',
    }

    url = ''
    if asset_location == 'fundingForm':
        funding_form_list = list(db().coll_program_funding_forms.find({'deal': obj_id}, projection={'deliverables': True})
                                                                .sort('_id', DESCENDING).limit(1))
        if funding_form_list:
            funding_form = funding_form_list[0]
            funding_form_deliverables = funding_form.get('deliverables')
            if funding_form_deliverables:
                for d in funding_form_deliverables:
                    if d.get('name') == asset_type:
                        url = d.get('url', '')
                        break;
            else:
                raise GivewithError('No funding form deliverables found')

        else:
          raise GivewithError('Funding form not found')
    elif asset_location == 'program':
        program = get_program(deal.get('selectedProgram'), projection={'deliverables': True})
        if program:
            program_deliverables = program.get('deliverables')
            if program_deliverables:
                for key in program_deliverables.keys():
                    if key == program_deliverable_name_mapping[asset_type]:
                        url = program_deliverables[key]
                        break;
            else:
                raise GivewithError('No program deliverables found')

        else:
          raise GivewithError('Selected program not found')


    if url:
        customer_deliverables = get_descendant_key(deal, 'deliverables.givewithCustomer.deliverables', [])
        client_deliverables = get_descendant_key(deal, 'deliverables.client.deliverables', [])

        for customer_deliv in customer_deliverables:
            if customer_deliv.get('name') == asset_type:
                customer_deliv['url'] = url

        for client_deliv in client_deliverables:
            if client_deliv.get('name') == asset_type:
                client_deliv['url'] = url

    else:
        raise GivewithError('No deliverable found')

    updated_document = update_document_by_id('deals', obj_id, set_last_updated(deal))

    return jsonify(updated_document)


@admin_bp.route('/deals/<id>', methods=['DELETE'])
@require_admin_permission
def delete_deal(id):
    """ Remove Deal
    ---
    tags: ['Deal Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Deal'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_deals.find_one_and_delete({'_id': obj_id})
    if not deleted_document:
        raise EntityNotFound(entity_name, id)

    send_loggly("PROPOSAL: DELETE DEAL " + str(obj_id) + " DELETED BY " + str(request.user['_id']))
    audit_logger.log('admin-matchmaking-api', str(request.user['_id']), 'proposal', str(obj_id), 'delete', '', '')

    return jsonify(deleted_document)

@admin_bp.route('/deals/<id>/percentage', methods=['POST'])
@require_admin_permission
def update_percentages(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    db_document = db().coll_deals.find_one({'_id': obj_id})
    if not db_document:
        raise EntityNotFound(entity_name, id)

    ## COVID deals do not require recommendations / a selected program
    is_covid = db_document.get('type') == 'covid'

    recommended_programs = [] if is_covid else get_deal_recommended_programs(db_document, include_invalid=True)
    selected_recommended_programs = db_document.get('selectedRecommendedPrograms', [])

    percentage_dict = {str(p['_id']): p['match'] for p in recommended_programs}

    recommended = list()

    ## only overwrite match percentages, not custom information in selected recommended
    ## removes programs that have been deleted (i.e not return in the algo)
    for p in selected_recommended_programs:
        program_id = str(p['_id'])
        new_percentage = percentage_dict.get(program_id)
        if program_id in percentage_dict:
            p['match'] = new_percentage
            recommended.append(p)

    updated_deal = db().coll_deals.find_one_and_update(filter={'_id': obj_id},
                                                                  update={
                                                                  '$set':{'selectedRecommendedPrograms': recommended,
                                                                  'recommendedPercentages': percentage_dict,
                                                                  'recommendedPercentagesDate': datetime.utcnow()
                                                                  }},
                                                                  return_document=ReturnDocument.AFTER)

    updated_deal['recommendedPrograms'] = recommended_programs

    return jsonify(updated_deal)


@admin_bp.route('/deals/<id>/<field>/<file_name>', methods=['DELETE'])
@require_admin_permission
def deal_delete_asset(id, field, file_name):
    """ Remove file from specific field of a Deal
    ---
    tags: ['Deal Admin']

    security:
      - GivewithAuth: []

    parameters:
      - name: id
        in: path
        required: true
        schema:
          type: string
      - name: field
        in: path
        required: true
        description: String separated by '_' with field name. e.g. seller_video, buyer_photoGallery
        schema:
          type: string
      - name: file_name
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Deal'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    fields = field.split('.')

    if len(fields) != 3 and fields[0] != 'deliverables':
        raise GivewithError("Attribute 'field' wrong format")

    document = db().coll_deals.find_one({'_id': obj_id})
    if not document:
        raise EntityNotFound(entity_name, id)

    # check if requested field exits on document
    if 'deliverables' not in document \
        or fields[1] not in document['deliverables'] \
            or fields[2] not in document['deliverables'][fields[1]]:
        raise GivewithError('Field deliverables.{1}.{2} not found in document {0}'.format(id, fields[1], fields[2]))
    elif not document['deliverables'][fields[1]][fields[2]].endswith(file_name):
        raise GivewithError('File {0} on document {1} is not on field {2}'
                            .format(file_name, id, field))

    # tries to delete the file
    if not delete_file('deals', id, file_name):
        raise GivewithError('Unable to delete {0} of document {1}'.format(file_name, id))

    del document['deliverables'][fields[1]][fields[2]]
    if not document['deliverables'][fields[1]]:
        del document['deliverables'][fields[1]]
        if not document['deliverables']:
            del document['deliverables']

    document['isValid'] = check_deal_is_valid(document)

    db().coll_deals.replace_one(filter={'_id': obj_id}, replacement=set_last_updated(document))

    return jsonify(document)

@admin_bp.route('/deals/<id>/custom-deliverable-upload', methods=['POST'])
@require_admin_permission
def deal_custom_deliverable_upload(id):

    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    if 'file' not in request.files:
        raise UnsupportedPayload()

    file = request.files['file']
    if file.name == '':
        raise UnsupportedPayload()

    index = request.form.get('index')
    deliverable_type = request.form.get('userType')

    url = save_custom_deliverable_to_s3(file, 'deliverables/%s/%s' % (id, secure_filename(file.filename)))
    deal = db().coll_deals.find_one({'_id': obj_id}, projection={'deliverables': True})

    field = 'deliverables.{0}.custom'.format(deliverable_type)
    custom_deliverables = get_descendant_key(deal, field, [])
    if custom_deliverables and len(custom_deliverables) - 1 >= int(index):
        custom_deliverables[int(index)]['url'] = url
    else:
        custom_deliverables.append({
          'url': url
        })

    set_descendant_key(custom_deliverables, deal, field)

    updated_document = db().coll_deals.find_one_and_update(filter={'_id': obj_id},
                                                                  update={'$set': set_last_updated(deal)},
                                                                  return_document=ReturnDocument.AFTER)

    updated_document['_id'] = obj_id

    return jsonify(updated_document)

##
# Commerce Protected Endpoints
##
@protected_commerce_bp.route('/deal/<slug>', methods=['GET'])
@protected_commerce_bp.route('/deal/<slug>/p/<program_slug>', methods=['GET'])
def get_deal_on_link(slug, program_slug=None):
    """ Fetch deal data
    ---
    tags: ['Commerce Secure']

    security:
      - CommerceAuth: []

    parameters:
      - name: slug
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/PublicDeal'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    query = {'slug': slug}
    pilot_proj = ['status', 'currency', 'eventId', 'selectedPrograms', 'supplier', 'slug', 'password']
    document = get_document('pilot_deal', query, projection=pilot_proj) or get_document('deals', query)

    if not document:
        raise EntityNotFound(entity_name, slug)

    if is_deal_link_expired(document):
        raise GivewithError('Link has expired', code=403)

    try:
        if 'eventId' in document:
            transform_event_deal_on_link(document, program_slug)
        else:
            transform_deal_on_link(document)
    except EntityNotFound as e:
        current_app.logger.error('Not found entity associated to deal: {0}'.format(e))
        raise e

    return jsonify(document)


def transform_event_deal_on_link(document, selected_program_slug):
    try:
        program_id = get_document('mm_programs', {'slug': selected_program_slug}, projection=['_id'])['_id']
        document_program = next(p for p in document.pop('selectedPrograms') if p['programId'] == program_id)
    except Exception:
        raise EntityNotFound('Program not found')

    event = get_document_by_id('event', document['eventId'], projection=['customer'])
    customer = get_document_by_id('mm_brands', event['customer'], projection=['name', 'nameLabel', 'customCopy'])
    client = get_document_by_id('mm_brands', document['supplier'], projection=['name', 'nameLabel'])

    document['givewithCustomerName'] = customer.get('nameLabel') or customer.get('name')
    document['clientName'] = client.get('nameLabel') or client.get('name')
    document['customCopy'] = customer.get('customCopy', {})
    document['isEventDeal'] = True

    document['selectedProgramSlug'] = selected_program_slug

    document['deliverables'] = {'custom': document_program.get('deliverables', [])}


def transform_deal_on_link(document):
    gw_customer_projection_fields = [
        'name', 'nameLabel', 'preferredPrograms', 'givePercentageType', 'customGivePercentage', 'isPilot', 'customCopy'
    ]
    gw_customer = lookup_by_fields(document, 'givewithCustomer', gw_customer_projection_fields, get_brand_by_id)
    client = lookup_by_fields(document, 'client', ['name', 'nameLabel', 'nonprofits', 'researchCorpCommitments'],
                              get_brand_by_id)

    document['givewithCustomerName'] = gw_customer.get('nameLabel') or gw_customer.get('name')
    document['clientName'] = client.get('nameLabel') or client.get('name')

    document['isPilot'] = gw_customer.get('isPilot', False)

    document['customCopy'] = gw_customer.get('customCopy', {})

    if 'manager' in document:
        document['managerEmail'] = lookup_by_field(document, 'manager', 'username', get_user_by_id)

    # COVID Proposals don't need to get recs / parse preferred programs
    is_covid = document.get('type') == 'covid'
    if not is_covid:
        # add preferred programs of givewithCustomer
        preferred_programs = gw_customer.get('preferredPrograms', {}).get('selected', [])
        if preferred_programs:
            programs = db().coll_programs.find({'_id': {'$in': preferred_programs}})
            programs_map = {str(program.get('_id')): program for  program in programs}
            has_percentages = bool(not document.get('recommendedPercentages'))
            recommended_programs = [p for p in get_deal_recommended_programs(document)
                                    if p.get('_id') in programs_map]

            document['preferredPrograms'] = transform_programs(recommended_programs, programs_map)

        additional_programs = gw_customer.get('preferredPrograms', {}).get('additional', [])
        if additional_programs:
            document['secondaryPreferredPrograms'] = additional_programs

    # add preferred nonprofits of client
    research_nonprofits = client.get('researchCorpCommitments', {}).get('nonprofits', {}).get('preferred', [])
    preferred_nonprofits = set(client.get('nonprofits', {}).get('preferred', []) + research_nonprofits)
    document['preferredNonprofits'] = annotate_nonprofits_with_programs(preferred_nonprofits)

    if document.get('selectedRecommendedPrograms'):
        document['selectedRecommendedPrograms'] = filter_selected_programs(document)

    document['programs'] = remove_none([transform_program(program)
                                        for program in document.pop('selectedRecommendedPrograms', [])])

    for program in document['programs']:
        funding_amount = document.get('fundingAmount', 0)
        funding_currency = document.get('currency') or str(Currency.USD)
        if program.get('version') == 2:
            transform_outputs_to_commerce_outputs_v2(program.get('outputs', []),
                                                     program.get('budget'),
                                                     program.get('currency', str(Currency.USD)),
                                                     funding_amount,
                                                     funding_currency)
        else:
            create_virtual_fields(program)
            calculate_commerce_outputs(program, funding_amount)

    # Adds analysis
    document['analysis'] = get_insights(document['client'])

    # send client deliverables only and alt licensing only at COMPLETE status
    deliverables = document.pop('deliverables', {}).get('client', {})
    alt_licensing = document.pop('altLicensingClient', '')
    if DealStatus.get(document['status']) == DealStatus.COMPLETE:
        document['deliverables'] = deliverables
        document['altLicensingClient'] = alt_licensing

    # discard GWCustomer altLicensing
    document.pop('altLicensingGivewithCustomer', None)

    # use this value on the FE if givewithPortion is not set and
    # therefore FE cannot calculate the give percent on the fly
    if gw_customer.get('givePercentageType') == 'default':
        document['customerGivewithPercent'] = 2
    elif gw_customer.get('givePercentageType') == 'custom':
        document['customerGivewithPercent'] = gw_customer.get('customGivePercentage')

    if document['status'] != str(DealStatus.PROGRAM_SELECTION_PENDING):
        try:
            selected_program_slug = lookup_by_field(document, 'selectedProgram', 'slug', get_program_by_id)
        except EntityNotFound:
            selected_program_slug = 'inexistent-slug-maybe-program-removed'
        document['selectedProgramSlug'] = selected_program_slug


@protected_commerce_bp.route('/deal/<slug>/program/<program_slug>', methods=['GET'])
def get_deal_program_protected_commerce(slug, program_slug):
    """ Fetch deal program details
    ---
    tags: ['Commerce Secure']

    security:
      - CommerceAuth: []

    parameters:
      - name: slug
        in: path
        required: true
        schema:
          type: string
      - name: program_slug
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/PublicDealProgram'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    query = {'slug': slug}
    deal_from_slug = get_document('pilot_deal', query) or get_document('deals', query)

    if deal_from_slug and is_deal_link_expired(deal_from_slug):
        raise GivewithError('Link has expired', code=403)

    program = get_program_by_id_or_slug(program_slug)

    if 'eventId' in deal_from_slug:
        response = get_event_deal_program(deal_from_slug, program)
    else:
        response = get_deal_program(deal_from_slug, program, 'client')

    return jsonify(response)


@protected_commerce_bp.route('/deal/<slug>/programs', methods=['GET'])
def get_deal_programs(slug):
    """ List all deal programs
    ---
    tags: ['Commerce Secure']

    security:
      - CommerceAuth: []

    parameters:
      - name: slug
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              type: array
              items:
                properties:
                  name:
                    type: string
                  slug:
                    type: string
                  nonprofit:
                    properties:
                      name:
                        type: string
                      slug:
                        type: string
                  outputs:
                    type: array
                    items:
                      properties:
                        label:
                          type: string
                        value:
                          type: integer
                  themes:
                    type: array
                    items:
                      $ref: '#/components/schemas/PublicVocabulary'
                  match:
                    type: integer
                  metricsCount:
                    type: integer
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """

    deal_from_slug = db().coll_deals.find_one({'slug': slug})
    if not deal_from_slug:
        raise EntityNotFound("deal")

    if is_deal_link_expired(deal_from_slug):
        raise GivewithError('Link has expired', code=403)

    projection = {
        'name': True, 'slug': True, 'nonprofit': True, 'imagePortrait': True,
        'imageLandscape': True, 'themes.data': True, 'csrhub.data': True,
        'sasb.data': True, 'sdg.data': True, 'gri.data': True, 'esg.data': True,
        'ImpactAndScope': True
    }
    programs = get_documents('mm_programs', {'isValid': True, 'isValidNonprofit': True, 'active': True},
                             projection=projection)


    programs_map = {str(program.get('_id')): program for program in programs}
    has_percentages = bool(not deal_from_slug.get('recommendedPercentages'))
    rec_programs = get_deal_recommended_programs(deal_from_slug, get_percentages=has_percentages)
    transformed_programs = transform_programs(rec_programs, programs_map)

    # rename ImpactAndScope to location
    for p in transformed_programs:
        p['location'] = p.get('ImpactAndScope', {})
        p.pop('ImpactAndScope', None)

    return jsonify(programs=transformed_programs)


@protected_commerce_bp.route('/deal/<slug>/programs/location', methods=['GET'])
def get_deal_programs_locations(slug):
    deal_from_slug = db().coll_deals.find_one({'slug': slug})
    if not deal_from_slug:
        raise EntityNotFound("deal")

    if is_deal_link_expired(deal_from_slug):
        raise GivewithError('Link has expired', code=403)

    programs = get_documents('mm_programs', {'isValid': True, 'isValidNonprofit': True, 'active': True})
    programs_map = {str(program.get('_id')): program for program in programs}
    has_percentages = bool(not deal_from_slug.get('recommendedPercentages'))
    rec_programs = get_deal_recommended_programs(deal_from_slug, get_percentages=has_percentages)
    transformed_programs = transform_programs(rec_programs, programs_map)

    locations = {
        'regions': set(),
        'countries': set(),
        'states': set(),
        'cities': set(),
    }

    location_key_path = {
        'regions': ['ImpactAndScope', 'regions', 'value', 'selected'],
        'countries': ['ImpactAndScope', 'countries', 'value', 'selected'],
        'states': ['ImpactAndScope', 'states', 'value', 'selected'],
        'cities': ['ImpactAndScope', 'cities', 'value', 'selected'],
    }

    for program in transformed_programs:
        for k in location_key_path:
            path = location_key_path[k]
            location_data = program

            for p in path:
                if p in location_data:
                    location_data = location_data[p]

            if not isinstance(location_data, list):
                continue

            for l in location_data:
                d = l.split(';')[-1]
                if d != 'N/A':
                    locations[k].add(d)

    for k in locations:
        locations[k] = list(locations[k])

    return jsonify(locations)

@protected_commerce_bp.route('/deal/<slug>/confirmation', methods=['POST'])
def deal_confirmation(slug: str):
    """ Confirm deal
    ---
    tags: ['Commerce Secure']

    security:
      - CommerceAuth: []

    parameters:
      - name: slug
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            properties:
              program:
                required: true
                type: string
              contact:
                properties:
                  name:
                    type: string
                  role:
                    type: string
                  email:
                    type: string
                    format: email
                  phoneNumber:
                    type: string
    responses:
      204:
        description: No content
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    deal = db().coll_deals.find_one(filter={"slug": slug})
    if not deal:
        raise EntityNotFound(entity_name, slug)

    payload = request.get_json()
    if not payload:
        raise UnsupportedPayload()

    program = get_program_by_id_or_slug(payload.get('program', None))

    deal['selectedProgram'] = program['_id']
    deal.setdefault('selectedProgramMeta', {}).update({'selectedAt': datetime.utcnow()})
    deal['programName'] = program['name']
    deal['contact'] = payload.get('contact', None)
    deal['status'] = str(DealStatus.CONFIRMATION_PENDING)
    deal['statusUpdatedAt'] = datetime.utcnow()

    if deal.get('contact'):
        deal.setdefault('clientEmails', []).append(deal.get('contact')['email'])
    deal['clientEmails'] = list(set(deal.get('clientEmails')))

    deal = v.normalized(deal, DBSchema_deal)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    # notify when a program is selected on deal proposal link.
    db().coll_deals.replace_one(filter={'_id': deal['_id']}, replacement=set_last_updated(deal))
    if deal.get('preventUpdateEmail') is not True:
        NotificationEmail(objective='program_selected', roles=['customer', 'client', 'manager'], data=deal).send()


    gw_customer_projection_fields = [
      'name',
      'nameLabel',
      'preferredPrograms',
      'givePercentageType',
      'customGivePercentage'
    ]
    gw_customer = lookup_by_fields(deal, 'givewithCustomer', gw_customer_projection_fields,
                                    get_brand_by_id)
    client = lookup_by_fields(deal, 'client', ['name', 'nameLabel', 'nonprofits', 'researchCorpCommitments'],
                              get_brand_by_id)

    deal['givewithCustomerName'] = gw_customer.get('nameLabel') or gw_customer.get('name')
    deal['clientName'] = client.get('nameLabel') or client.get('name')

    if 'manager' in deal:
        deal['managerEmail'] = lookup_by_field(deal, 'manager', 'username', get_user_by_id)

    # use this value on the FE if givewithPortion is not set and
    # therefore FE cannot calculate the give percent on the fly
    if gw_customer.get('givePercentageType') == 'default':
      deal['customerGivewithPercent'] = 2
    elif gw_customer.get('givePercentageType') == 'custom':
      deal['customerGivewithPercent'] = gw_customer.get('customGivePercentage')

    return jsonify(deal)

@protected_commerce_bp.route('/deal/<slug>/client-confirmation', methods=['POST'])
def client_confirmation(slug: str):
    deal = db().coll_deals.find_one(filter={'slug': slug})
    if not deal:
        raise EntityNotFound(entity_name, slug)

    payload = request.get_json()
    if not payload:
        raise UnsupportedPayload(None)

    try:
        updates = {
            'email': payload['clientConfirmationEmail'],
            'name': payload.get('clientConfirmationName', ''),
            'accountsPayable': {
                'name': payload.get('accountsPayableName', ''),
                'email': payload['accountsPayableEmail']
            },
            'confirmedAt': datetime.utcnow()
        }
    except KeyError as key:
        raise GivewithError(f'{key} field is missing')

    deal.setdefault('clientConfirmation', {}).update(updates)
    deal = v.normalized(deal, DBSchema_deal)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    db().coll_deals.replace_one(filter={'_id': deal['_id']}, replacement=set_last_updated(deal))

    if deal.get('type') != 'covid' and deal.get('preventUpdateEmail') is not True:
        NotificationEmail(objective='confirm_transaction', roles=['manager', 'customer'], data=deal).send()

    if deal.get('preventUpdateEmail') is not True:
        NotificationEmail(objective='client_accounts_payable', roles=['manager', 'customer'], data=deal).send()

    return get_deal_on_link(slug)

@protected_commerce_bp.route('/download_deliverables', methods=['GET'])
def download():
    filename = request.args.get('url')
    label = request.args.get('label')
    associated_id = filename.split('/')[-2]
    deal_slug = request.slug

    # validate user
    user_validated, program_name = validate_deal_link_user(deal_slug, filename, associated_id)

    if user_validated:
        return download_one_deliverable(filename, label, program_name)
    else:
        raise GivewithError('Insufficient permission', code=403)


@protected_commerce_bp.route('/downloads/<deal_slug>/program/<program_id>/deliverable/<key>', methods=['GET'])
def download_event_deal_deliverable(deal_slug, program_id, key):
    """
      Download Program Deliverable
    """
    deal = get_document('pilot_deal', {'slug': deal_slug})

    if not deal:
        raise EntityNotFound('deal')

    return download_pilot_deliverable(deal, program_id, key)

##
# Public Endpoints
##
@public_commerce_bp.route('/deal/<slug>/login', methods=['POST'])
def deal_login(slug: str):
    """ Deal login
    ---
    tags: ['Commerce Public']

    parameters:
      - name: slug
        in: path
        required: true
        schema:
          type: string

    requestBody:
      required: true
      content:
        application/json:
          schema:
            properties:
              password:
                type: string
                format: password
                description: Password to login on buyer context

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              properties:
                token:
                  type: string
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    field_name = 'password'
    password = request.json.get('password')
    isCovidAssets = request.json.get('isCovidAssets')

    if slug == 'covid-assets' and isCovidAssets and password == COVID_ASSETS_PASSWORD:
        password_field = '/'.join((password, field_name))
        expires = (datetime.utcnow() + TOKEN_VALIDITY).strftime(DATETIME_FORMAT)
        token = create_token(password_field, slug, expires)

        return jsonify({'token': token})

    query = {'slug': slug, field_name: password}
    deal_exists = validate_existences(query, 'pilot_deal') or validate_existences(query, 'deals')

    if not deal_exists:
        raise GivewithError('Invalid password for {0}'.format(slug), code=401)

    password_field = '/'.join((password, field_name))
    expires = (datetime.utcnow() + TOKEN_VALIDITY).strftime(DATETIME_FORMAT)
    token = create_token(password_field, slug, expires)

    return jsonify({'token': token})

@public_commerce_bp.route('/deal/<slug>/status-and-customer', methods=['GET'])
def deal_link_status_check_and_customer_name(slug: str):
    """ Check Deal Link Status
    ---
    tags: ['Commerce Public']

    parameters:
      - name: slug
        in: path
        required: true
        schema:
          type: string

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              properties:
                valid:
                  type: boolean
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    query = {'slug': slug}
    proj = ['status', 'eventId', 'givewithCustomer']
    deal = get_document('pilot_deal', query, projection=proj) or get_document('deals', query, projection=proj)

    if not deal:
        raise EntityNotFound(entity_name, slug)

    if 'eventId' in deal:
        event = get_document_by_id('event', deal['eventId'], projection=['customer'])
        customer = get_brand_by_id(event['customer'], projection=['name', 'nameLabel'])
    else:
        customer = get_brand_by_id(deal['givewithCustomer'], projection=['name', 'nameLabel'])

    return jsonify({
        'valid': not is_deal_link_expired(deal),
        'givewithCustomerName': customer.get('nameLabel') or customer.get('name')
    })

def validate_deal_link_user(deal_slug, filename, associated_id):
    '''
        Check if id within filename is associated with either client or customer of the deal
        param `filename` can either come from a funding form ( deliverables/<deal id>/item )
        or it can come from a program ( program/<program id>/item )
        @params:
        `user` --> user dict
        `filename` --> filename
        `associated_id` --> did the file originate from a funding form or a program?
    '''
    root_path = filename.split('/')[0]
    search_id = ObjectId(associated_id)

    if 'deliverables' == root_path:
        # check if slug and deal_id come from the same deal
        deal = db().coll_deals.find_one({'_id': search_id, 'slug': deal_slug}, projection={'_id': False, 'selectedProgram': True})
        if deal:
            program = get_program(deal.get('selectedProgram'), projection={'name' : True})
            return True, program.get('name')

    elif 'programs' == root_path:
        program = get_program(search_id, projection={'name': True})
        count = db().coll_deals.count({'selectedProgram': search_id, 'slug': deal_slug})
        return count == 1, program.get('name')

    return False, ''
