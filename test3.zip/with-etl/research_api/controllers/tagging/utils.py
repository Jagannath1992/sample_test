# pylint: disable=too-many-locals, too-many-branches, too-many-statements, line-too-long, missing-docstring, invalid-name
# pylint: disable=unused-wildcard-import, wildcard-import
import os
import uuid
import boto3
from bson.objectid import ObjectId
from botocore.exceptions import ClientError
from research_api.mongodb import db, get_mongo_db
from .constants import *

SELECTED_VOCABULARY_VERSION = 2


# we'll load up all the objectIDs of the terms in the vocabulary
# this is a key/value of key/values, where they objectid/labels
# are nested in their distinct areas/topics.
# there is also a "inverted" dict which is label/objectid, instead of the other way around,
# for all the values
def _vocab_alone(generate_constants):
    cursor = db().coll_vocabulary

    vocabulary = dict() # the master storage for all
    vocabulary[VOCAB_CSRHUB] = dict()  # these are all key/value with objectID/label
    vocabulary[VOCAB_AUDIENCES] = dict()
    vocabulary[VOCAB_APPROACHES] = dict()
    vocabulary[VOCAB_IMPACTS] = dict()
    vocabulary[VOCAB_INDUSTRIES] = dict()
    vocabulary[VOCAB_RESEARCHTYPES] = dict()
    vocabulary[VOCAB_ANIMALHABITATS] = dict()
    vocabulary[VOCAB_DATAMEASUREMENTTYPE] = dict()
    vocabulary[VOCAB_THEMES] = dict()
    vocabulary[VOCAB_EFFECTIVENESS] = dict()
    vocabulary[VOCAB_CAUSES] = dict()
    vocabulary[VOCAB_ESG] = dict()
    vocabulary[VOCAB_SDGS] = dict()
    vocabulary[VOCAB_CDP] = dict()
    vocabulary[VOCAB_PROGRAMAPPROACH] = dict()
    vocabulary[VOCAB_SCALETYPE] = dict()
    vocabulary[VOCAB_GRI] = dict()
    vocabulary[VOCAB_SASB] = dict()
    inverted = set()


    for document in cursor.find():
        t = document["type"]

        if is_safe_to_use(document):

            inverted.add(document["label"])

            # in this portion, it's critical that the strings for 't' (type)
            # are the same ones used in the DB
            if t in vocabulary:
                vocabulary[t][document["_id"]] = document["label"]
            #else:
            #    print("no " + t + " in vocabulary")

    vocabulary["inverted"] = inverted

    # This block so we can output a list of vocab terms to use as CONSTANTS.
    # This is output in dev, and used in constants:
    # (see constants/__init__.py)
    # the value for these should match the 'type' values in vocabs exactly
    constants_file = list()
    constants_file.append("## **** Loaded Vocabulary compatible with Version " + str(SELECTED_VOCABULARY_VERSION) + " ************")  # pylint: disable=line-too-long
    constants_file.append("VOCAB_CSRHUB = 'csrhub'")
    constants_file.append("VOCAB_AUDIENCES = 'audience'")
    constants_file.append("VOCAB_APPROACHES = 'approach'")
    constants_file.append("VOCAB_IMPACTS = 'impact'")
    constants_file.append("VOCAB_INDUSTRIES = 'industry'")
    constants_file.append("VOCAB_RESEARCHTYPES = 'researchType'")
    constants_file.append("VOCAB_ANIMALHABITATS = 'animalHabitats'")
    constants_file.append("VOCAB_DATAMEASUREMENTTYPE = 'dataMeasurement'")
    constants_file.append("VOCAB_THEMES = 'themes'")
    constants_file.append("VOCAB_EFFECTIVENESS = 'effectiveness'")
    constants_file.append("VOCAB_CAUSES = 'causes'")
    constants_file.append("VOCAB_ESG = 'esg'")
    constants_file.append("VOCAB_SDGS = 'sdg'")
    constants_file.append("VOCAB_CDP = 'cdp'")
    constants_file.append("VOCAB_PROGRAMAPPROACH = 'programApproach'")
    constants_file.append("VOCAB_SCALETYPE = 'scaleType'")
    constants_file.append("VOCAB_GRI = 'gri'")
    constants_file.append("VOCAB_SASB = 'sasb'")
    constants_file.append("VOCAB_SECONDARYIMPACTS = 'secondaryImpacts'")
    constants_file.append("VOCAB_PRIMARYIMPACT = 'primaryImpact'")

    did_already = list()
    for v in vocabulary:
        #print("\t" + v + "\t" + str(len(vocabulary[v])))
        if v in (VOCAB_APPROACHES,
                 VOCAB_AUDIENCES,
                 VOCAB_CSRHUB,
                 VOCAB_CAUSES,
                 VOCAB_IMPACTS,
                 VOCAB_GRI,
                 VOCAB_SASB,
                 VOCAB_SDGS,
                 VOCAB_ESG,
                 VOCAB_THEMES,
                 VOCAB_ANIMALHABITATS):
            t = vocabulary[v]
            for x in t:
                actual_string = str(t[x])
                vocab_string = actual_string.upper().replace("*", "").replace(":", "_").replace("(", "").replace(")", "").replace(" ", "_").replace("’", "").replace("&", "AND").replace(",", "_").replace("'", "_").replace("-", "_").replace("'", "").replace("+", "_").replace("/", "_")
                if vocab_string[0].isdigit():
                    vocab_string = "AGE_" + vocab_string
                if vocab_string not in did_already:
                    constants_file.append(vocab_string + " = \"" + actual_string + "\"")
                    did_already.append(vocab_string)
    constants_file.append("\nALL_CONSTANTS = list()")
    for x in did_already:
        constants_file.append("ALL_CONSTANTS.append(" + x + ")")
    if generate_constants:
        flatfile = '\n'.join(constants_file)
        return flatfile
    return vocabulary

def fetch_tagging_programs():
    myquery = {'$or':[{ 'sasb': { '$exists': False } },  { 'sdg' : { '$exists': False } },  { 'csrhub' : { '$exists': False } },   { 'themes' : { '$exists': False } }, { 'gri': { '$exists': False } },   { 'esg': { '$exists': False } } ]}
    programs = list(db().coll_programs.find(myquery, {'_id': 1} ))
    return programs

def init_vocabulary(program_id):

    vocabulary = _vocab_alone(False)
    program_document = db().coll_programs.find_one({"_id": ObjectId(program_id)})

    if program_document is None:
        raise Exception("Could not find a program with ID of " + str(program_id))

    return vocabulary, program_document

def init_tagging(document, vocabulary, log, source):
    stringed = stringify_document_vocabulary(document, vocabulary)
    log.append(document["name"] + "\t" + str(document["_id"]))
    log.append("STRINGED \t" + str(stringed))
    env = os.environ.get('ENV', 'none')

    if env != "prod":
        validate_terms(vocabulary)
    # move them into a master dict, just to clean up the actual tag files
    # so they can be a little more human readable
    tag_data = dict()
    tag_data["stringed"] = stringed
    tag_data["log"] = log
    tag_data["document"] = reset_feature(document, source, log)
    tag_data["vocabulary"] = vocabulary


    return tag_data




# this returns True/False
# if this is a record we can use based on the presense / accuracy of the versions list
def is_safe_to_use(document):
    # figure out if we have versioning in the vocabulary collection, if so, use it.
    # if a given record lacks versioning, it's also safe to use
    found_version = False
    found_match = False
    safe_to_use = False
    if "versions" in document:
        #print("found versions")
        found_version = True
        vlist = document["versions"]
        for j in list(vlist):
            if j == SELECTED_VOCABULARY_VERSION:  #if we have an explicit match, we're good
                found_match = True

    if not found_version:
        safe_to_use = True #if we didn't version the vocabulary, assume it's good to go
    elif found_version and found_match:
        safe_to_use = True #if we have a version, then we have to match our selected version
    else:
        safe_to_use = False

    return safe_to_use

def add_term_to_vocab(term, term_type):
    term_type = term_type.lower() if term_type != 'MSCI' else 'esg'
    new_term = db().coll_vocabulary.find_one_and_update({'label': term, "type": term_type.lower(), 'versions': {'$in': [2]}}, {'$set': {'label': term, "type": term_type, "versions": [2]}}, upsert=True)
    return new_term

def remove_term_from_vocab( term_type):
    db().coll_vocabulary.delete_many({'type': term_type.upper()})

def remove_program_tagging():
    fields_to_delete = ["themes", "sdg", "sasb",'esg', 'csrhub']

    # Use the $unset operator to delete the fields
    update = {field: "" for field in fields_to_delete}

    # Use update_many() to bulk update all documents in the collection
    db().coll_programs.update_many({}, {'$unset': update})

def confirm_vocab(term, branch_name, vocabulary):
    if term not in vocabulary["inverted"]:
        print("can't find term: " + term + " in vocabulary")
        raise Exception("no " + term + " in vocabulary - changes in "
                        + "Mongo not manifest in codebase? "
                        + "Ensure schema migration has occured.")

    if branch_name:
        if branch_name in vocabulary:
            if term not in vocabulary[branch_name].values():
                raise Exception("can't find " + term + " in " + branch_name
                                + " in vocabulary - possible issue with constants?")
        else:
            raise Exception("can't find " + branch_name
                            + " in vocabulary - possible issue with constants?")


# this returns true or false if the given string is
# present in the "cleaned" (aka stringified, not objectids) representation
# of the program.  if the term is not spelled right or not in the
# vocabulary, it will throw a exception

def check_term(term, branch_name, data):
    cleaned = data["stringed"]
    vocabulary = data["vocabulary"]
    confirm_vocab(term, branch_name, vocabulary)
    if branch_name in cleaned:
        if term in cleaned[branch_name]:
            return True
    return False


# this is a utility method mostly called by "stringifyDocumentVocabulary"
# that converts the objectID in a given field into it's label
def check_vocab(name_in_document, name_in_data, document, vocabulary):
    output = list()
    if name_in_document in document:
        aa = document[name_in_document]
        if isinstance(aa, list):
            for a in aa:
                if isinstance(a, dict):
                    a = a["_id"]
                if a in vocabulary[name_in_data]:
                    name = vocabulary[name_in_data][a]
                    # print("name_in_data " + str(a))
                    output.append(name)
        else:
            if aa in vocabulary[name_in_data]:
                name = vocabulary[name_in_data][aa]
                # print("name_in_data " + str(a))
                output.append(name)

    return output

# this is a utility method similar to check_vocab, but it digs into the ImpactAndScope dictionary
# that converts the objectID in a given field into it's label
def check_impactandscope_vocab(name_in_document, name_in_data, document, vocabulary):
    output = list()
    if "ImpactAndScope" in document:
        impactandscope = document["ImpactAndScope"]
        if name_in_document in impactandscope:
            aa = impactandscope[name_in_document]
            val = aa["value"]
            if val in vocabulary[name_in_data]:
                name = vocabulary[name_in_data][val]
                output.append(name)

    return output


# this takes in a given program document, and our overall vocabulary
# and then returns a simplified dictionary of all the labels
# (converting the objectIDs into the strings/labels they refer to).
#  **********************************************************************
#  Note: This is the function to look at *if/when* the location of these
#  fields move do to changes in the program object structure
def stringify_document_vocabulary(document, vocabulary):
    data = dict()

    age = check_vocab("audienceAge", VOCAB_AUDIENCES, document, vocabulary)
    attribute = check_vocab("audienceAttribute", VOCAB_AUDIENCES, document, vocabulary)
    gender = check_vocab("audienceGender", VOCAB_AUDIENCES, document, vocabulary)

    data[VOCAB_AUDIENCES] = age + attribute + gender

    data[VOCAB_CAUSES] = check_vocab("causes", VOCAB_CAUSES, document, vocabulary)
    data[VOCAB_DATAMEASUREMENTTYPE] = check_vocab("dataMeasurementType", VOCAB_DATAMEASUREMENTTYPE, document, vocabulary)  # pylint: disable=line-too-long
    data[VOCAB_APPROACHES] = check_vocab("approach", VOCAB_APPROACHES, document, vocabulary)
    data[VOCAB_PRIMARYIMPACT] = check_vocab("primaryImpact", VOCAB_IMPACTS, document, vocabulary)
    data[VOCAB_SECONDARYIMPACTS] = check_vocab("secondaryImpacts", VOCAB_IMPACTS, document, vocabulary)
    # merge them into a single list, too
    data[VOCAB_IMPACTS] = data[VOCAB_PRIMARYIMPACT] + data[VOCAB_SECONDARYIMPACTS]
    data[VOCAB_PROGRAMAPPROACH] = check_vocab("programApproach", VOCAB_PROGRAMAPPROACH, document, vocabulary)  # pylint: disable=line-too-long
    data[VOCAB_ANIMALHABITATS] = check_impactandscope_vocab("animalHabitat", VOCAB_ANIMALHABITATS, document, vocabulary)  # pylint: disable=line-too-long
    return data


# before you "tag" a program document, remove the old one.
#  **********************************************************************
#  Note: This is the function to look at *if/when* the location of these
#  fields move do to changes in the program object structure
def reset_feature(document, dataname, log):
    if dataname in document:
        old_data = document.pop(dataname, None)
        log.append("former data set for " + dataname)
        log.append(str(old_data))

    document[dataname] = dict()
    document[dataname]["strings"] = list()
    document[dataname]["data"] = list()

    return document


# if you have new tags - use this to pass the object ids into the
# right part of the doc
#  **********************************************************************
#  Note: This is the function to look at *if/when* the location of these
#  fields move do to changes in the program object structure
def add_feature(data_name, feature_name, tag_data):
    document = tag_data["document"]
    vocabulary = tag_data["vocabulary"]
    log = tag_data["log"]
    data = dict()
    if data_name in document:
        data = document[data_name]
    else:
        data = dict()
        data["isCustom"] = False
        data["data"] = list()
        data["strings"] = list()

    if feature_name in data["strings"]:
        print('\talready include ' + feature_name)
        log.append('\talready include ' + feature_name)
    else:
        oid = None
        for t in vocabulary[data_name]:
            if vocabulary[data_name][t] == feature_name:
                oid = ObjectId(str(t))
        data["strings"].append(feature_name)
        if data_name == VOCAB_ESG:
            # handle it a little differently, due to legacy issues
            tdict = dict()
            tdict["issue"] = oid
            data["data"].append(tdict)
        else:
            data["data"].append(oid)


        print("\tadding " + str(oid) + "\t" + feature_name)
        log.append("\tadding " + str(oid) + "\t" + feature_name)

    document[data_name] = data


# save the document back to the db
def save_program_document(document):
    collection = db().coll_programs
    findDict = dict()
    findDict["_id"] = document["_id"]
    currentDoc = collection.find_one(findDict)
    if currentDoc:
        collection.replace_one(currentDoc, document)
        print("\tsaved " + str(document["_id"]) + " to database")
    else:
        print("can't find a matching document object ID, fatal error")
        raise Exception("Can't find program document with id " + str(document["_id"]))


def critical_alert(eee, log_as_list_of_strings, msg_type):
    log_as_list_of_strings.append("CRITICAL ALERT - exception: " + str(eee))
    log_as_list_of_strings.append("Exception in processing document - using string that isn't in vocab? or excep saving document.")
    print("critical alert - Exception in processing document")

    filename = str(uuid.uuid4())

    with open("/tmp/" + filename, "w") as text_file:
        for b in log_as_list_of_strings:
            print(b, file=text_file)

    AWS_ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID', None)
    AWS_ACCESS_SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', None)

    if AWS_ACCESS_KEY is None or AWS_ACCESS_SECRET_KEY is None:
        print("can't send log of critical alert to S3, no AWS S3 credentials")
        return

    file = "/tmp/" + filename

    env = os.environ.get('ENV', 'none')
    key = "TAGGING_" + env.upper() + "_" + filename
    if env == "local":
        env = "staging"  # this is just for testing
    bucket = 'givewith-' + env + "-logging-bucket"

    if env in ("staging", "prod"):
        if upload_file(file, bucket, key, AWS_ACCESS_KEY, AWS_ACCESS_SECRET_KEY):
            print('Logging upload worked: check log at ' + str(bucket) + " " + filename)
        else:
            print('The logging upload failed...')
            print('Tried to write to ' + str(bucket) + " " + filename)
            return

    send_cloudwatch(msg_type, key)


def send_cloudwatch(name_of_error, filename):
    cloudwatch = boto3.client('cloudwatch')
    print(cloudwatch)

    # Put custom metrics
    cloudwatch.put_metric_data(
        MetricData=[
            {
                'MetricName': name_of_error,
                'Dimensions': [
                    {
                        'Name': 'Error',
                        'Value': filename
                    },
                ],
                'Unit': 'None',
                'Value': 1.0
            },
        ],
        Namespace='Tagging'
    )


def upload_file(file_name, bucket, object_name, aws_access_key_id, aws_secret_access_key):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = file_name

    # Upload the file
    s3_client = boto3.client(
        's3',
        aws_access_key_id=aws_access_key_id,
        aws_secret_access_key=aws_secret_access_key
    )

    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        print("excep in trying to upload error to S3")
        print(str(e))
        print(str(response))
        return False
    return True


def validate_terms(vocabulary):
    for t in ALL_CONSTANTS:
        try:
            confirm_vocab(t, None, vocabulary)
        except Exception as ohno:
            raise ohno
