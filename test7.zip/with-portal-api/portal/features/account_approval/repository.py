import pymongo
from bson import ObjectId, Regex
from re import escape, RegexFlag
from portal.shared.repository import DocumentRepository


class AccountApprovalRepository(DocumentRepository):
    def __init__(self, db):
        super().__init__(db, db['account_approval'])

    def get_approval_level(self, username: str, account_id: ObjectId):
        username_filter = Regex('^' + escape(username) + '$', RegexFlag.IGNORECASE)
        return self.collection.find_one({
            'levels.approver.username': username_filter,
            '_id': ObjectId(account_id)
        },
            projection={
            'levels': {
                '$elemMatch': {
                    'approver.username': username_filter
                }
            }
        })

    def get_approver(self, account_id, give_amount) -> str:
        approver = list(self.collection.aggregate([
            {'$unwind': '$levels'},
            {'$match': {'_id': ObjectId(account_id), 'levels.amount': {'$gte': give_amount}}},
            {'$sort': {'levels.amount': pymongo.ASCENDING}},
            {'$group': {'_id': None, 'approver': {'$first': '$levels.approver.username'}}},
            {'$project': {'_id': 0, 'approver': 1}}
        ]))
        if len(approver):
            return approver[0]['approver']
        return None
