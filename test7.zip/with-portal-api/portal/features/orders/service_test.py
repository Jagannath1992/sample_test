import pytest

from portal.features.orders.service import _populate_result_details, _calculate_win_rate
from portal.shared.enums import OrderStatus
from portal.shared.repositories import account_repository, cause_area_repository, instance_settings_repository
from portal.shared.services import email_service, order_service


class TestOrderService:

    def test_timestamp_comments(self, frozen_utcnow, fakers):
        order = fakers.order.insert_single()
        request = {
            'status': 'approved',
            'comments': [{'comment': 'a new comment'}]
        }

        response = order_service().timestamp_comments(request, 'username@example.com', order['_id'])

        assert len(response['comments']) == 1
        assert response['comments'] == [
            {
                'comment': 'a new comment',
                'user': 'username@example.com',
                'timestamp': frozen_utcnow,
                'oldStatus': 'pending approval',
                'newStatus': 'approved'
            }
        ]

    @pytest.fixture
    def test_send_notifications_init(self, fakers, mocker):
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        cause_area = fakers.cause_area.generate_single()
        mocker.patch.object(cause_area_repository(), 'get_single', return_value=cause_area)
        order = fakers.order.generate_single()
        mocker.patch.object(email_service(), 'send_give_submitted_for_approval_email')
        mocker.patch.object(email_service(), 'send_give_approved_email')
        mocker.patch.object(email_service(), 'send_give_denied_email')
        mocker.patch.object(email_service(), 'send_give_financial_hold_email')
        mocker.patch.object(email_service(), 'send_give_completed_won_email')
        mocker.patch.object(email_service(), 'send_give_abandoned_lost_email')
        return instance, order, account, cause_area

    def test_send_notifications_pending_approval(self, test_send_notifications_init):
        # arrange
        instance, order, account, _ = test_send_notifications_init
        order['status'] = OrderStatus.PENDING_APPROVAL.value

        # act
        order_service().send_notifications(order)

        # assert
        account_repository().get_single.assert_called_once_with(order['account']['_id'], {
            'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        cause_area_repository().get_single.assert_not_called()
        email_service().send_give_submitted_for_approval_email.assert_called_once_with(instance, order)
        email_service().send_give_approved_email.assert_not_called()
        email_service().send_give_denied_email.assert_not_called()
        email_service().send_give_financial_hold_email.assert_not_called()
        email_service().send_give_completed_won_email.assert_not_called()
        email_service().send_give_abandoned_lost_email.assert_not_called()

    def test_send_notifications_approved(self, test_send_notifications_init):
        # arrange
        instance, order, account, cause_area = test_send_notifications_init
        order['status'] = OrderStatus.APPROVED.value

        # act
        order_service().send_notifications(order)

        # assert
        account_repository().get_single.assert_called_once_with(order['account']['_id'], {
            'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        cause_area_repository().get_single.assert_called_once_with(order['causeArea']['_id'], {'tooltip': 1})
        email_service().send_give_submitted_for_approval_email.assert_not_called()
        email_service().send_give_approved_email.assert_called_once_with(instance, order, account, cause_area)
        email_service().send_give_denied_email.assert_not_called()
        email_service().send_give_financial_hold_email.assert_not_called()
        email_service().send_give_completed_won_email.assert_not_called()
        email_service().send_give_abandoned_lost_email.assert_not_called()

    def test_send_notifications_denied(self, test_send_notifications_init):
        # arrange
        instance, order, account, _ = test_send_notifications_init
        order['status'] = OrderStatus.DENIED.value

        # act
        order_service().send_notifications(order)

        # assert
        account_repository().get_single.assert_called_once_with(order['account']['_id'], {
            'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        cause_area_repository().get_single.assert_not_called()
        email_service().send_give_submitted_for_approval_email.assert_not_called()
        email_service().send_give_approved_email.assert_not_called()
        email_service().send_give_denied_email.assert_called_once_with(instance, order)
        email_service().send_give_financial_hold_email.assert_not_called()
        email_service().send_give_completed_won_email.assert_not_called()
        email_service().send_give_abandoned_lost_email.assert_not_called()

    def test_send_notifications_financial_hold(self, test_send_notifications_init):
        # arrange
        instance, order, account, _ = test_send_notifications_init
        order['status'] = OrderStatus.FINANCIAL_HOLD.value

        # act
        order_service().send_notifications(order)

        # assert
        account_repository().get_single.assert_called_once_with(order['account']['_id'], {
            'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        cause_area_repository().get_single.assert_not_called()
        email_service().send_give_submitted_for_approval_email.assert_not_called()
        email_service().send_give_approved_email.assert_not_called()
        email_service().send_give_denied_email.assert_not_called()
        email_service().send_give_financial_hold_email.assert_called_with(instance, order, account)
        email_service().send_give_completed_won_email.assert_not_called()
        email_service().send_give_abandoned_lost_email.assert_not_called()

    def test_send_notifications_completed(self, test_send_notifications_init):
        # arrange
        instance, order, account, cause_area = test_send_notifications_init
        order['status'] = OrderStatus.COMPLETED.value
        # act
        order_service().send_notifications(order)

        # assert
        account_repository().get_single.assert_called_once_with(order['account']['_id'], {
            'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        cause_area_repository().get_single.assert_called_once_with(
            order['causeArea']['_id'], {'tooltip': 1, 'detailImageName': 1})
        email_service().send_give_submitted_for_approval_email.assert_not_called()
        email_service().send_give_approved_email.assert_not_called()
        email_service().send_give_denied_email.assert_not_called()
        email_service().send_give_financial_hold_email.assert_not_called()
        email_service().send_give_completed_won_email.assert_called_with(instance, order, account, cause_area)
        email_service().send_give_abandoned_lost_email.assert_not_called()

    def test_send_notifications_abandoned(self, test_send_notifications_init):
        # arrange
        instance, order, account, _ = test_send_notifications_init
        order['status'] = OrderStatus.ABANDONED.value

        # act
        order_service().send_notifications(order)

        # assert
        account_repository().get_single.assert_called_once_with(order['account']['_id'], {
            'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
        instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
        cause_area_repository().get_single.assert_not_called()
        email_service().send_give_submitted_for_approval_email.assert_not_called()
        email_service().send_give_approved_email.assert_not_called()
        email_service().send_give_denied_email.assert_not_called()
        email_service().send_give_financial_hold_email.assert_not_called()
        email_service().send_give_completed_won_email.assert_not_called()
        email_service().send_give_abandoned_lost_email.assert_called_once_with(instance, order)

    def test_populate_result_details(self):
        '''
        This test is for controller _populate_result_details method for detail functionality, where a list of detail based on status is being returned
        for the cause area
        '''
        result = [
            {'_id': {'causeArea': 'cause_area_1', 'currency': 'USD'},
             'count': 1,
             'totalGiveAmount': 100.0,
             'avgGiveAmount': 99.99,
             'totalDealAmount': 100.0,
             'avgDealAmount': 100.0,
             'avgGivePercent': 100.0,
             'impact': 5,
             'impactMeasurement': 'Trees',
             'mostGives': 'test@givewith.com'},
            {'_id': {'causeArea': 'cause_area_2', 'currency': 'USD'},
             'count': 6,
             'totalGiveAmount': 5000.0,
             'avgGiveAmount': 899.99,
             'totalDealAmount': 4500,
             'avgDealAmount': 766.66,
             'avgGivePercent': 99,
             'impact': 22.0,
             'impactMeasurement': 'books',
             'mostGives': 'test@givewith.com'}]

        result_by_status = [
            {'_id': {'causeArea': 'cause_area_1', 'status': 'pending payment', 'currency': 'USD'},
             'count': 1,
             'totalGiveAmount': 100.0,
             'avgGiveAmount': 99.99,
             'totalDealAmount': 100.0,
             'avgDealAmount': 100.0,
             'avgGivePercent': 100.0,
             'impact': 0,
             'impactMeasurement': 'Trees',
             'mostGives': 'test@givewith.com'},
            {'_id': {'causeArea': 'cause_area_2', 'status': 'pending payment', 'currency': 'USD'},
             'count': 1,
             'totalGiveAmount': 100.50,
             'avgGiveAmount': 100.50,
             'totalDealAmount': 199.50,
             'avgDealAmount': 199.50,
             'avgGivePercent': 100.0,
             'impact': 2,
             'impactMeasurement': 'books',
             'mostGives': 'test@givewith.com'},
            {'_id': {'causeArea': 'cause_area_2', 'status': 'approved', 'currency': 'USD'},
             'count': 1,
             'totalGiveAmount': 5,
             'avgGiveAmount': 5,
             'totalDealAmount': 10,
             'avgDealAmount': 10,
             'avgGivePercent': 50,
             'impact': 22.0,
             'impactMeasurement': 'books',
             'mostGives': 'test1@givewith.com'},
            {'_id': {'causeArea': 'cause_area_2', 'status': 'pending approval', 'currency': 'USD'},
             'count': 4,
             'totalGiveAmount': 400,
             'avgGiveAmount': 250,
             'totalDealAmount': 200,
             'avgDealAmount': 200,
             'avgGivePercent': 50,
             'impact': 5,
             'impactMeasurement': 'books',
             'mostGives': 'test@givewith.com'}
        ]

        expected_cause_area_1_average_give_amount = 99.99
        expected_cause_area_2_pp_total_give_amount = 100.50
        expected_cause_area_2_pp_total_deal_amount = 199.50
        expected_cause_area_2_pp_count = 1
        expected_cause_area_2_deatil = 3

        _populate_result_details(result, result_by_status, False, False)

        for data in result:
            if data['_id']['causeArea'] == 'cause_area_2':
                actual_cause_area_2_deatil = len(data['details'])
        for data in result:
            if data['_id']['causeArea'] == 'cause_area_2':
                for detail in data['details']:
                    if detail['status'] == 'pending payment':
                        actual_cause_area_2_pp_total_give_amount = detail['totalGiveAmount']
                        actual_cause_area_2_pp_total_deal_amount = detail['totalDealAmount']
                        actual_cause_area_2_pp_count = detail['count']
        for data in result:
            if data['_id']['causeArea'] == 'cause_area_1':
                actual_cause_area_1_average_give_amount = data.get('avgGiveAmount', None)
                total_deal_amount_present = data.get("totalDealAmount", None)

        assert actual_cause_area_2_deatil == expected_cause_area_2_deatil
        assert actual_cause_area_2_pp_total_give_amount == expected_cause_area_2_pp_total_give_amount
        assert actual_cause_area_2_pp_total_deal_amount == expected_cause_area_2_pp_total_deal_amount
        assert actual_cause_area_2_pp_count == expected_cause_area_2_pp_count
        assert actual_cause_area_1_average_give_amount == expected_cause_area_1_average_give_amount
        assert total_deal_amount_present == None

    def test_win_rate_details(self):
        '''
        This test is for controller _calculate_win_rate method for details functionality
        '''
        result = [
            {'_id': {'causeArea': 'Cause Area 0', 'currency': 'USD'}},
            {'_id': {'causeArea': 'Cause Area 1', 'currency': 'USD'}}
        ]

        data = [
            {
                '_id': {'causeArea': 'Cause Area 0', 'currency': 'USD'},
                'counts': [{'status': 'approved', 'count': 2}, {'status': 'completed', 'count': 2}]
            },
            {
                '_id': {'causeArea': 'Cause Area 1', 'currency': 'USD'},
                'counts': [{'status': 'approved', 'count': 4}, {'status': 'completed', 'count': 2}]
            }
        ]

        _calculate_win_rate(result, data, False, False)

        for data in result:
            if data['_id']['causeArea'] == 'Cause Area 0':
                cause_area_0_win_rate = data['winRate']
            if data['_id']['causeArea'] == 'Cause Area 1':
                cause_area_1_win_rate = data['winRate']

        assert cause_area_0_win_rate == 100
        assert cause_area_1_win_rate == 50

    def test_win_rate_overview(self):
        '''
        This test is for controller _calculate_win_rate method for overview functionality which returns a single win rate.
        '''
        result = [
            {'_id': {'currency': 'USD'}}
        ]

        data = [
            {
                '_id': {'currency': 'USD'},
                'counts': [{'status': 'approved', 'count': 100}, {'status': 'completed', 'count': 33}]
            }
        ]

        _calculate_win_rate(result, data, True, False)

        assert result[0]['winRate'] == 33
