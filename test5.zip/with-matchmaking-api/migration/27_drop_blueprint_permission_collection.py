from matchmaking import db

db().coll_permission.drop()
