from bson import ObjectId
from portal.testing.faker import DocumentFaker
from portal.shared.dates import get_utcnow
from portal.shared.enums import AccountStatus, SubscriptionFrequency, AccountType


class AccountFaker(DocumentFaker):
    def _generate_document(self, i):
        now = get_utcnow()
        return {
            '_id': ObjectId(),
            'status': AccountStatus.ACTIVE.value,
            'type': AccountType.DEFAULT.value,
            'instance': {
                '_id': ObjectId(),
                '_type': 'instance_settings',
                'name': 'Givewith for Sales',
            },
            'industry': {
                'displayLabel': f'Display Label {i}',
                'subIndustry': f'Sub Industry {i}',
            },
            'company': {
                'name': f'Company name {i}',
                'address': {
                    'address1': f'Address1 {i}',
                    'address2': f'Address2 {i}',
                    'city': f'City {i}',
                    'stateProvince': f'State/Province {i}',
                    'postalCode': f'Postal code {i}',
                    'country': f'Country {i}'
                },
                'countryCode': f'Country code {i}',
                'phoneNumber': f'Phone number {i}',
                'website': f'www.example{i}.com',
            },
            'initialBalance': i,
            'currentBalance': i,
            'giveFields': {
                'customerName': {
                    'label': 'Sell to Customer Name',
                    'defaultValue': '',
                    'displayOrder': 0,
                    'required': True,
                    'custom': False,
                },
                'customerId': {
                    'label': 'Sell to Customer #',
                    'defaultValue': '',
                    'displayOrder': 1,
                    'required': False,
                    'custom': False,
                },
                'quoteNumber': {
                    'label': 'Quote #',
                    'defaultValue': '',
                    'displayOrder': 2,
                    'required': False,
                    'custom': False,
                },
                'quoteAmount': {
                    'label': 'Total Deal Value',
                    'defaultValue': None,
                    'displayOrder': 3,
                    'required': True,
                    'custom': False,
                },
                'description': {
                    'label': 'Description',
                    'defaultValue': '',
                    'displayOrder': 4,
                    'required': False,
                    'custom': False,
                },
                'customField1': {
                    'label': f'Custom Label 1 {i}',
                    'defaultValue': '',
                    'displayOrder': 5,
                    'required': False,
                    'custom': True,
                },
                'customField2': {
                    'label': f'Custom Label 2 {i}',
                    'defaultValue': '',
                    'displayOrder': 6,
                    'required': False,
                    'custom': True,
                },
                'customField3': {
                    'label': f'Custom Label 3 {i}',
                    'defaultValue': '',
                    'displayOrder': 7,
                    'required': False,
                    'custom': True,
                },
                'customField4': {
                    'label': f'Custom Label 4 {i}',
                    'defaultValue': '',
                    'displayOrder': 8,
                    'required': False,
                    'custom': True,
                },
            },
            'nextGiveId': 1,
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now,
            'subscriptionFrequency': SubscriptionFrequency.MONTHLY.value,
            'stripe': {
                'customerId': f'cus_{i}',
                'trialPeriodUsed': True,
                'subscription': {
                    'id': f'sub_{i}',
                    'canceledAt': None,
                    'cancelAt': None,
                    'currentPeriodStart': now,
                    'currentPeriodEnd': now,
                    'newFrequencyAtPeriodEnd': None
                },
                'autopay': {
                    'paymentMethodId': f'pm_{i}',
                    'enabledDate': now,
                    'pendingMicroDepositVerification': False
                }
            },
            'sageCustomerId': f'sage_{i}',
            'sageRecordNo': f'record_{i}',
        }
