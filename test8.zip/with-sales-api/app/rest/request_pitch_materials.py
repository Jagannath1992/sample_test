from flask import request
from flask_restful import Resource

from app.service.emails import request_pitch_material
from app.utils.auth import authenticate


class RequestPitchMaterials(Resource):
    @authenticate
    def post(self):
        """
        request pitch materials
        """
        req = request.get_json(force=True)
        message = req.get('message')
        response = request_pitch_material(message)
        return str(response.content), response.status_code
