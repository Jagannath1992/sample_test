import json

def test_pagination(client, admin_header):
    # without pagination
    response = client.get('/admin/deals', headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert len(deals) == 4

    # with pagination
    response = client.get('/admin/deals?page_num=1&page_size=1', headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert len(deals) == 1

    response = client.get('/admin/deals?page_num=2&page_size=2', headers=admin_header)
    assert response.status_code == 200

    deals = json.loads(response.data.decode())
    assert len(deals) == 2

