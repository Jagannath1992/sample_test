from unittest.mock import MagicMock

import pytest

from matchmaking.dao.supplier_analysis_report_dao import (
    calculate_topic_alignment_scores, convert_topic_fraction_to_score,
    remove_zero_topics, set_report_details, transfer_topic_scores)


@pytest.mark.parametrize('db_suppliers, supplier_ids, supplier_in_progress_expected_values', [
    (
        [],
        None,
        []
    ),
    (
        [{'_id': 'A', 'name': 'A', 'source': 'CUSTOMER'}, {'_id': 'B', 'name': 'B', 'source': 'MSCI'}],
        ['A', 'B'],
        [True, False]
    ),
    (
        [
            {'_id': 'A', 'name': 'A', 'source': 'CUSTOMER', 'verifiedByAdmin': None},
            {'_id': 'B', 'name': 'B', 'source': 'MSCI'}
        ],
        ['A', 'B'],
        [True, False]
    )
])
def test_set_report_status_in_progress(monkeypatch, db_suppliers, supplier_ids, supplier_in_progress_expected_values):
    mock_dao_utils = MagicMock() # Mock DB dao utils
    monkeypatch.setattr('matchmaking.dao.supplier_analysis_report_dao.utils', mock_dao_utils)
    mock_dao_utils.get_document_by_id.return_value = {'name': 'Q'}
    mock_dao_utils.get_documents.return_value = db_suppliers

    report = set_report_details({'brandId': 'B', 'suppliers': supplier_ids})
    assert report['status'] == 'IN_PROGRESS'

    for index, expected_value in enumerate(supplier_in_progress_expected_values):
        assert report['suppliers'][index]['inProgress'] == expected_value


@pytest.mark.parametrize('db_suppliers, supplier_ids', [
    (
        [{'_id': 'A', 'name': 'A'}, {'_id': 'B', 'name': 'B', 'source': 'MSCI'}],
        ['A', 'B']
    ),
    (
        [
            {'_id': 'A', 'name': 'A', 'source': 'MANUAL', 'verifiedByAdmin': True},
            {'_id': 'A', 'name': 'B', 'source': 'MSCI'}
        ],
        ['A', 'B']
    )
])
def test_set_report_status_complete(monkeypatch, db_suppliers, supplier_ids):
    mock_dao_utils = MagicMock() # Mock DB dao utils
    monkeypatch.setattr('matchmaking.dao.supplier_analysis_report_dao.utils', mock_dao_utils)
    mock_dao_utils.get_document_by_id.return_value = {'name': 'Q'}
    mock_dao_utils.get_documents.return_value = db_suppliers

    report = set_report_details({'brandId': 'B', 'suppliers': supplier_ids})
    assert report['status'] == 'COMPLETE'


@pytest.mark.parametrize('value, expected', [(0, 0), (0.2, 3), (-5, 0), (1, 3), (0.1, 1), (0.04, 0)])
def test_convert_topic_fraction_to_score(value, expected):
    assert convert_topic_fraction_to_score(value) == expected


@pytest.mark.parametrize('topics, expected', [
    (
        [{'score': 0.1, 'topic': '1'}, {'score': 0.4, 'topic': '2'}, {'score': 0.3, 'topic': '3'}],
        {'1': 2, '2': 3, '3': 3}
    ),
    (
        [{'score': 0, 'topic': '1'}, {'score': 0, 'topic': '2'}, {'score': 0, 'topic': '3'}],
        {'1': 0, '2': 0, '3': 0}
    ),
    (
        [{'score': 0, 'topic': '1'}, {'score': 0.05, 'topic': '2'}, {'score': 2, 'topic': '3'}],
        {'1': 0, '2': 0, '3': 3}
    ),
])
def test_calculate_topic_alignment_scores(topics, expected):
    result = calculate_topic_alignment_scores(topics)
    for key, value in result.items():
        assert value == expected[key]


@pytest.mark.parametrize('topics, expected', [
    ({'1': 0, '2': 3, '3': 1}, {'2': 3, '3': 1}),
    ({'1': 0, '2': 0, '3': 0}, {}),
    ({'1': 1, '2': 0, '3': 3}, {'1': 1, '3': 3}),
    ({'1': 0, '2': 3, '3': 0}, {'2': 3}),
])
def test_remove_zero_topics(topics, expected):
    result = remove_zero_topics(topics)

    assert result == expected


@pytest.mark.parametrize('topics_a, topics_b, expected', [
    (
        {'1': 0, '2': 3, '3': 2, '4': 1, '5': 2},
        {'1': 3, '3': 1, '4': 3, '5': 2},
        {'1': 0, '3': 1, '4': 1, '5': 2}
    ),
    (
        {'1': 2, '2': 1, '3': 0, '4': 2},
        {'1': 0, '2': 3, '3': 1, '4': 3, '5': 3},
        {'1': 0, '2': 1, '3': 0, '4': 2, '5': 0}
    )
])
def test_transfer_topic_scores(topics_a, topics_b, expected):
    assert transfer_topic_scores(topics_a, topics_b) == expected
