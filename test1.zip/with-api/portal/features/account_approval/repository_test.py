from bson import ObjectId
from portal.shared.repositories import account_approval_repository


class TestAccountApprovalRepository:
    def test_get_approval_level(self, repositories, fakers):
        approval_repo = repositories['account_approval']
        created = fakers.approval.insert_many(3)

        expected = created[2]
        assert len(expected['levels']) == 3

        results = approval_repo.get_approval_level('username4@example.com', expected['_id'])

        assert len(results['levels']) == 1
        assert results['levels'][0] == expected['levels'][2]

    def test_get_approval_level_regex_match(self, repositories, fakers):
        approval_repo = repositories['account_approval']
        created = fakers.approval.insert_many(3)

        expected = created[0]
        assert len(expected['levels']) == 3

        results = approval_repo.get_approval_level('uSeRnAmE1@example.com', expected['_id'])

        assert len(results['levels']) == 1
        assert results['levels'][0] == expected['levels'][1]

    def test_get_approver(self, fakers):
        # arrange
        approval = fakers.approval.insert_single()

        # act
        result = account_approval_repository().get_approver(approval['_id'], approval['levels'][1]['amount'])

        # assert
        assert result == approval['levels'][1]['approver']['username']

    def test_get_approver_no_approver(self, fakers):
        # arrange
        approval = fakers.approval.insert_single()

        # act
        result = account_approval_repository().get_approver(approval['_id'], 10000)

        # assert
        assert result == None

    def test_get_approver_no_approval_levels(self):
        # arrange

        # act
        result = account_approval_repository().get_approver(ObjectId(), 1)

        # assert
        assert result == None
