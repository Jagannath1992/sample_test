import string
from typing import Optional
from datetime import datetime, timedelta


def get_utcnow(delta: timedelta = None) -> datetime:
    return datetime.fromisoformat(get_utcnow_string(delta)[:-1])


def get_utcnow_string(delta: timedelta = None) -> string:
    # MongoDB rounds to nearest millisecond when saving datetime
    utcnow = datetime.utcnow()
    if delta:
        utcnow += delta
    return get_formatted_utc_string(utcnow)


def get_formatted_utc_string(datetime: datetime) -> string:
    datetime = datetime.replace(tzinfo=None)  # Don't want UTC offset in formatted string because we're adding Z instead
    return datetime.isoformat(timespec='milliseconds') + 'Z'


def get_utc_date_from_timestamp(timestamp: int) -> Optional[datetime]:
    if timestamp:
        return datetime.utcfromtimestamp(timestamp)
