import os
from flask import abort, jsonify, request, send_file
from urllib.request import urlparse
from bson.objectid import ObjectId

from app.constants import ENV, AWS_BUCKET_GREENLIST
from app.utils.auth import authenticate_user_or_deal, authenticate

from ..controllers import asset_bp

from app.utils.utils import get_now_time_string
from ..db.utils import get_document_by_id, update_document_by_id
from ..service import audit_logger
from ..service.s3 import does_file_exist, generate_signed_url, download_asset
from ..validation.utils import uri_validator, validate_object_id_with_collection
from ..utils.asset import get_deliverables_asset, get_simian_asset

VALID_PLATFORMS = ['share', 'impact', 'sales']

@asset_bp.route('/download', methods=['GET'])
@authenticate_user_or_deal
def download_asset_from_url():
    '''
    Generic endpoint to download file from any bucket.
    In some cases, this endpoint will return a zip file rather than a file
    if it comes from simian and there is a description associated in the DB.
    '''
    filename = request.args.get('url')
    platform = request.args.get('platform')

    if not filename:
        abort(404, description='No url provided')

    if not filename.startswith('deliverables') and not uri_validator(filename):
        abort(404, description='Not a valid url: ' + filename)

    if platform not in VALID_PLATFORMS:
        abort(404, description='Invalid platform type. Must be of type: ' + ', '.join(VALID_PLATFORMS))

    if not does_file_exist(filename):
        abort(404, description='File not found in bucket: ' + filename)

    if 'simian' in filename: # handle simian downloads
        asset = get_simian_asset(filename, request.user)
    elif filename.startswith('deliverables'): # handle auto generated deliverable downloads
        asset = get_deliverables_asset(filename, request.args.get('label', ''), request.user)
    else: # handles all else
        attached_filename = filename.rsplit('/', 1)[-1]

        downloaded_file = download_asset(filename)
        if not downloaded_file:
            abort(404, description='Error download file: ' + filename)

        asset = send_file(downloaded_file, as_attachment=True, attachment_filename=attached_filename)

        audit_logger.log(
            'media-api',
            str(request.user.get('_id', 'no known user associated with this download')),
            'asset',
            '', #should there be some id used for audit log here?
            'download',
            'GET',
            'filename : ' + filename
        )

    asset.headers['Access-Control-Expose-Headers'] = 'Content-Disposition' #explicitly expose header
    return asset


@asset_bp.route('/tokenize', methods=['POST'])
@authenticate
def tokenize_urls():
    '''
    Accepts a list of urls and tokenizes them
    '''
    data = request.get_json()

    tokenized_urls = []
    for url in data:
        try:
            parsed_url = urlparse(url)
            if parsed_url.netloc:
                bucket_name = parsed_url.netloc.split('.')[0]
                if bucket_name not in AWS_BUCKET_GREENLIST:
                    continue

                signed_url = generate_signed_url(url, bucket_name)
            else:
                if os.environ.get('ENV'):
                    signed_url = generate_signed_url(url, f'givewith-{ENV}-secure-upload')
                else:
                    signed_url = generate_signed_url(url, 'givewith-local-secure-upload')

            tokenized_urls.append(signed_url)
        except: # pylint: disable=bare-except
            continue

    return jsonify(tokenized_urls)
