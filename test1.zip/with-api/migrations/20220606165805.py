import pymongo
from datetime import datetime
"""
Create and populate default instance_settings
"""
name = '20220606165805'
dependencies = ['20220221181334']


def upgrade(db: pymongo.database.Database):
    now = datetime.utcnow()

    db['instance_settings'].insert_one({
        "name": "Givewith for Sales",
        "description": "Default application settings",
        'settings': {
            'locale': {
                '_id': '',
                '_type': 'locale',
                'name': 'US',
            },
            'loginUrl': 'https://login.givewith.com',
            'portalUrl': 'https://gooddeal.givewith.com',
            'givewithEmail': 'assist@givewith.com',
            'serviceFee': 0.18,
            'allowRegistration': True,
            'sage': {
                'exchangeRate': 'Intacct Daily Rate',
                'locationId':  '100',
                'accounts': {
                    'socialImpactPayable': '20020',
                    'socialImpactEnablement': '40010',
                    'subscriptionRevenue': '40000',
                    'transactionRevenue': '40005'
                },
                'departments': {
                    'sales': '1300',
                    'socialImpact': '600'
                },
                'products': {
                    'annualSubscription': 'Givewith for Sales - Annual Subscription',
                    'monthlySubscription': 'Givewith for Sales - Monthly Subscription',
                    'transaction': 'Givewith for Sales - Transaction'
                }
            },
            'stripe': {
                'trialPeriodDays': 30,
                'prices': {
                    'monthly': 'price_1KjQjAFpuAfBZp0KrlBgK1Qj',
                    'annual': 'price_1L2dc0FpuAfBZp0KsVPHLu2i'
                }
            }
        },
        "createdBy": "admin@givewith.com",
        "createdAt": now,
        "lastUpdatedBy": "admin@givewith.com",
        "lastUpdated": now
    })


def downgrade(db: pymongo.database.Database):
    db['instance_settings'].drop()
