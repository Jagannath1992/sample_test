import json
from typing import Dict
from os import environ

import pip._vendor.requests
from bson import ObjectId
from flask import request, Request
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from portal.features.users.controller import UserProfile
from portal.shared.database import get_db
from werkzeug.exceptions import Forbidden, NotFound, BadRequest

from portal.features.users.schema import UserMyProfileRequest, UserResponse, UserSearchRequest
from portal.features.account_approval.schema import AccountApprovalResponse, AccountApprovalRequest
from portal.shared.auth.requests import role_required, token_required

from portal.features.accounts.schema import IndustrySchema, PutAccountActivateRequest, AccountSearchResponse, AccountRequest, AccountResponse, AccountSearchRequest, RecommendationItem, \
    AccountAppSettingsResponse
from portal.shared.auth.requests import role_required, token_required, _get_account

from portal.shared.auth.security import has_role
from portal.shared.enums import AccountStatus, UserRole
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import account_repository, account_approval_repository, instance_settings_repository, user_repository
from portal.shared.services import email_service

namespace = Namespace('accounts', description='Account related operations')


def _validate_access(account_id: str):
    if not has_role(GIVEWITH_ROLES, request.user) and request.user['accountId'] != ObjectId(account_id):
        raise Forbidden('You do not have permission to access this resource')


@namespace.route('')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class Accounts(Resource):
    @role_required(roles=GIVEWITH_ROLES)
    @accepts(query_params_schema=AccountSearchRequest, api=namespace)
    @responds(schema=AccountSearchResponse, api=namespace)
    def get(self):
        filters = request.parsed_query_params
        total_count, accounts = account_repository().get_page(filters)
        return {
            'totalCount': total_count,
            'results': accounts
        }

    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=AccountRequest, api=namespace)
    @responds(schema=AccountResponse, api=namespace)
    def post(self):
        new_account = account_repository().insert(request.parsed_obj, request.user['username'])
        account_approval_repository().insert({'_id': new_account['_id'], 'levels': []}, request.user['username'])
        return new_account


@namespace.route('/<string:id>')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Account not found'
    }
)
class AccountById(Resource):
    @token_required
    @responds(schema=AccountResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')
        return account

    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE,
    ])
    @accepts(schema=AccountRequest, api=namespace)
    @responds(schema=AccountResponse, api=namespace)
    def put(self, id: str):
        """Update Account"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')

        update = self._restrict_instance_customer_id_type_and_status(request.parsed_obj)

        is_status_changed = False
        if 'status' in update:
            is_status_changed = (account['status'] == AccountStatus.ACTIVE.value and update['status'] != AccountStatus.ACTIVE.value) or (
                account['status'] != AccountStatus.ACTIVE.value and update['status'] == AccountStatus.ACTIVE.value)

        account.update(update)
        account = account_repository().update(account, by=request.user['username'])

        if is_status_changed:
            instance = instance_settings_repository().get_single(account['instance']['_id'])
            if account['status'] == AccountStatus.ACTIVE.value:
                pass  # email_service().send_account_activated_email(instance, account)
            else:
                email_service().send_account_deactivated_email(instance, account)
        return account

    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE
    ])
    @accepts(schema=AccountRequest(partial=True), api=namespace)
    @responds(schema=AccountResponse, api=namespace)
    def patch(self, id: str):
        """Update Account from Partial"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')

        update = self._restrict_instance_customer_id_type_and_status(request.parsed_obj)

        is_status_changed = False
        if 'status' in update:
            is_status_changed = (account['status'] == AccountStatus.ACTIVE.value and update['status'] != AccountStatus.ACTIVE.value) or (
                account['status'] != AccountStatus.ACTIVE.value and update['status'] == AccountStatus.ACTIVE.value)

        account.update(update)
        account = account_repository().update(account, request.user['username'])

        if is_status_changed:
            instance = instance_settings_repository().get_single(account['instance']['_id'])
            if account['status'] == AccountStatus.ACTIVE.value:
                pass  # email_service().send_account_activated_email(instance, account)
            else:
                email_service().send_account_deactivated_email(instance, account)
        return account

    def _restrict_instance_customer_id_type_and_status(self, params: Dict) -> Dict:
        '''only givewith admin can update instance, sageCustomerId, Type, or status'''
        if has_role([UserRole.SUPER_ADMIN, UserRole.GW_FINANCE, UserRole.GW_OPERATIONS], request.user):
            return params
        if 'instance' in params:
            params.pop('instance')
        if 'sageCustomerId' in params:
            params.pop('sageCustomerId')
        if 'status' in params:
            params.pop('status')
        if 'type' in params:
            params.pop('type')
        return params


@namespace.route('/<string:id>/approvals')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class AccountApproval(Resource):

    @token_required
    @responds(schema=AccountApprovalResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        approvals = account_approval_repository().get_single(id)
        return approvals

    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE
    ])
    @accepts(schema=AccountApprovalRequest, api=namespace)
    @responds(schema=AccountApprovalResponse, api=namespace)
    def put(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        approval = account_approval_repository().get_single(id)
        if approval is None:
            raise NotFound('Account not found')

        approval.update(request.parsed_obj)
        return account_approval_repository().update(approval, request.user['username'])


@namespace.route('/<string:id>/activate')
class AccountActivate(Resource):
    @role_required(roles=[
        UserRole.SUPER_ADMIN,
        UserRole.GW_FINANCE,
        UserRole.GW_OPERATIONS,
        UserRole.ORG_ADMIN,
        UserRole.FINANCE
    ])
    @accepts(schema=PutAccountActivateRequest, api=namespace)
    @namespace.response(404, 'Not Found')
    def put(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        account = account_repository().get_single(id)
        if account is None:
            raise NotFound('Account not found')
        if account['status'] != AccountStatus.PENDING.value:
            return Forbidden('Account is not pending')
        account['status'] = AccountStatus.ACTIVE.value
        account.update(request.parsed_obj)
        account['lastUpdatedBy'] = request.user['username']
        account = account_repository().update(account)
        # email_service().send_account_activated_email(account)
        return 200


@namespace.route('/<string:id>/app-settings')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Invalid id provided',
        403: 'You do not have permission to access this resource',
        404: 'Account not found'
    })
class AccountAppSettingsByID(Resource):
    @token_required
    @responds(schema=AccountAppSettingsResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')

        supplier_account = account_repository().get_single(request.user['accountId'])
        procurement_account = account_repository().get_single_by_filter(
            {'_id': ObjectId(id), 'instance._id': supplier_account['instance']['_id']})

        if procurement_account is None:
            raise NotFound('Account not found')
        if procurement_account['_id'] != supplier_account.get('invitedBy', {}).get('_id'):
            raise Forbidden('You do not have permission to access this resource')

        response = {
            'id': id,
            'procurement': procurement_account.get('procurement', {})
        }
        return response


@namespace.route('/industries')
@namespace.route('/industries/<string:action>')
class AccountIndustries(Resource):
    @responds(schema=IndustrySchema(many=True), api=namespace)
    def get(self, action: str = None):
        industries = account_repository().get_industries()
        industries = [{'name': i, 'items': industries[i]} for i in industries if i != '_id']

        if action == 'counts':
            counts = account_repository().get_industry_counts()
            for industry in industries:
                for subIndustry in industry['items']:
                    count = counts.get(subIndustry['subIndustry'], None)
                    subIndustry['count'] = count

        return industries

@namespace.route('/recommend')
class AccountRecommendations(Resource):
    def get(self):
        self.user = UserProfile.get(self)
        if not self.user:
            raise NotFound('User not found')

        userod = (self.user[0])
        id = userod["accountId"]

        account = AccountById.get(self, id=id)
        accountod = account[0]
        company = accountod["company"]["name"]

        db = get_db()
        brands = db['mm_brands']

        brand_data = dict()

        if(company):
            for brand in brands.find({"name": "Kezar Life Sciences Inc"}, {"id": 1}):
                brand_id = brand['_id']
                if(brand_id):
                    recommend_data = recommend(brand_id=brand_id)
                else:
                    print("Could not find a match")
        else:
            print("There was no company returned")

        return recommend_data

#portal api cannot talk to the matchmaking algo     
def recommend(brand_id:str):
    MM_ALGO_RESPONSE = {"brandID":"5c1415685b03bb0008c21c29","filter":{"filtered_num_output":22,"filtered_num_removed":81,"original_num":103,"reco_size":6},"meta":{"actual-weights":{"CONSUMER":0.25,"CSR":0.25,"RATING":0.35,"REPORTING":0.15},"recommendation-data-updated":"1668006002","requested-weights":{"CONSUMER":0.25,"CSR":0.25,"RATING":0.35,"REPORTING":0.15},"timing":"0.2555 seconds"},"recommendations":[{"orig_position":1,"orig_ranking":100.0,"position":1,"program-name":"Katarina's PGRM","programID":"5c387b71a08c41000a179495","ranking":100.0,"raw_score":29.185790465062023},{"orig_position":2,"orig_ranking":82.69768333620772,"position":2,"program-name":"Divert and reduce food waste through local stewardship","programID":"5c1bbfbd0d204e00094f3d89","ranking":97.23396221633689,"raw_score":24.135972577966097},{"orig_position":3,"orig_ranking":79.7785182512246,"position":3,"program-name":"Retrofit affordable housing properties","programID":"5c1bb5ba6bf7b30009fbb553","ranking":94.46792443267378,"raw_score":23.283991172933675},{"orig_position":8,"orig_ranking":73.16445248971583,"position":4,"program-name":"Promote sustainable growth in Nepal by increasing solar energy access","programID":"5c180eb90d204e00080cb429","ranking":91.70188664901067,"raw_score":21.353623798558317},{"orig_position":13,"orig_ranking":68.73266341508938,"position":5,"program-name":"Construct a tree nursery and park on vacant land in Detroit","programID":"5ba5596618149200071cc3a5","ranking":88.93584886534757,"raw_score":20.06017112538433},{"orig_position":15,"orig_ranking":67.62176985404068,"position":6,"program-name":"Eliminate inhumane practices in animal agriculture","programID":"5c0ae2090f36530008d4d041","ranking":86.16981108168446,"raw_score":19.73594805836679},{"orig_position":4,"orig_ranking":79.7785182512246,"position":7,"program-name":"Install solar for affordable housing properties","programID":"5c1bb47d6bf7b300084ac060","ranking":83.40377329802135,"raw_score":23.283991172933675},{"orig_position":5,"orig_ranking":77.82876613067793,"position":8,"program-name":"Broaden Mobile students' understanding of watersheds and water quality","programID":"5b7317fb936d7d0010822835","ranking":80.63773551435824,"raw_score":22.71494060444282},{"orig_position":6,"orig_ranking":77.82416446215169,"position":9,"program-name":"Remove trash and plastic pollution from waterways","programID":"5b71aab81b21cb00106d347f","ranking":77.87169773069513,"raw_score":22.713597571108853},{"orig_position":7,"orig_ranking":75.088201851767,"position":10,"program-name":"Empower Guatemalan women through clean cooking solutions","programID":"5c37744f6bf7b300084d983f","ranking":74.56769903887435,"raw_score":21.91508525643954},{"orig_position":9,"orig_ranking":73.16445248971583,"position":11,"program-name":"Promote sustainable growth in Mexico by increasing solar energy access ","programID":"5b47bcaa2e9ec60019e7ac98","ranking":72.33962216336893,"raw_score":21.353623798558317},{"orig_position":10,"orig_ranking":73.16445248971583,"position":12,"program-name":"Promote sustainable growth in Nicaragua by increasing solar energy","programID":"5c180ef85b03bb000926dacc","ranking":72.33962216336893,"raw_score":21.353623798558317},{"orig_position":11,"orig_ranking":70.67794137697517,"position":13,"program-name":"Reforest Madagascar by employing villagers","programID":"5ba3fd672c63670007fc28a8","ranking":69.45975744696031,"raw_score":20.627915875303344},{"orig_position":12,"orig_ranking":69.38555278085072,"position":14,"program-name":"Install solar for low-income families","programID":"5b48c3ed2e9ec6001ae7aca6","ranking":67.96291944820896,"raw_score":20.250722047644107},{"orig_position":14,"orig_ranking":67.74729956930751,"position":15,"program-name":"End cosmetic animal testing!","programID":"5c0ae1806d3c360008627006","ranking":66.0655027842367,"raw_score":19.77258489803596},{"orig_position":16,"orig_ranking":62.80217726382249,"position":16,"program-name":"Protect pollinators in parks","programID":"5c1914d85b03bb000926f6a3","ranking":60.338086899014826,"raw_score":18.329311863716054},{"orig_position":17,"orig_ranking":62.19734511329972,"position":17,"program-name":"Rehabilitate fire-damaged national forests in California","programID":"5b9fcd0185b04200070f3359","ranking":59.63757333174578,"raw_score":18.15278681959915},{"orig_position":18,"orig_ranking":57.254711685613785,"position":18,"program-name":"Restore the Lower Rio Grande Watershed in Texas","programID":"5ba3fc4f2c63670007fc2837","ranking":53.91304005232459,"raw_score":16.71024018393862},{"orig_position":19,"orig_ranking":56.56437710448466,"position":19,"program-name":"Connect people to local waterways","programID":"5b85fa64936d7d00108228ec","ranking":53.113497998189466,"raw_score":16.50876057958241},{"orig_position":20,"orig_ranking":55.91717256044944,"position":20,"program-name":"Courtney's program to test tagging","programID":"5c14265c6bf7b3000849f6e0","ranking":52.36390893698796,"raw_score":16.31986881747993},{"orig_position":21,"orig_ranking":50.43930383354008,"position":21,"program-name":"Build a diverse and inclusive solar workforce","programID":"5b47c90e2e9ec6001ae7ac9b","ranking":46.01946881487787,"raw_score":14.721109528893004},{"orig_position":22,"orig_ranking":46.759026069034775,"position":22,"program-name":"Advance education for girls in Pakistan","programID":"5beded370f36530008cef126","ranking":41.75698954170059,"raw_score":13.646991372012216},{"orig_position":23,"orig_ranking":46.62447698822378,"position":23,"program-name":"Solar Workforce Development & Diversity Program","programID":"5c1913935b03bb0008c2a7eb","ranking":41.60115547023099,"raw_score":13.607722159214054},{"orig_position":24,"orig_ranking":42.63982172268434,"position":24,"program-name":"Develop a reforestation training and research center in Nepal","programID":"5ba3fffd5d67100007023de7","ranking":36.98614769991353,"raw_score":12.444769022658651},{"orig_position":25,"orig_ranking":38.87387329119966,"position":25,"program-name":"Increase literacy rates among New York City youth","programID":"5b8961ef20cfe30007c324c5","ranking":32.62444508934559,"raw_score":11.345647204423242},{"orig_position":26,"orig_ranking":36.26220176233045,"position":26,"program-name":"Save threatened species in Vietnam","programID":"5c37713d0d204e00080fee72","ranking":29.599620205876896,"raw_score":10.583410224371793},{"orig_position":27,"orig_ranking":35.86290081611516,"position":27,"program-name":"Manage elephant populations in Africa humanely","programID":"5c3773250d204e00080feebb","ranking":29.1371518499778,"raw_score":10.466871086884387},{"orig_position":28,"orig_ranking":35.54409375728356,"position":28,"program-name":"Support expectant mothers with weekly home visits from a nurse","programID":"5ba4088218149200071c7d4f","ranking":28.767911111270966,"raw_score":10.373824726705971},{"orig_position":29,"orig_ranking":35.10860421041897,"position":29,"program-name":"Construct multipurpose fields for children in low-income communities","programID":"5ba1428a5d6710000701b05c","ranking":28.263529299360307,"raw_score":10.246723660060823},{"orig_position":30,"orig_ranking":35.009276743202435,"position":30,"program-name":"Help older adults improve their physical and financial well-being","programID":"5c083bd8d9d8f30008953cdd","ranking":28.14848872433877,"raw_score":10.217734153604752},{"orig_position":31,"orig_ranking":34.791489523660914,"position":31,"program-name":"Deliver life-skills curriculum to girls in Indonesia","programID":"5b47c91c2e9ec6001ae7ac9d","ranking":27.89624865751234,"raw_score":10.15417123204968},{"orig_position":32,"orig_ranking":34.633421865768476,"position":32,"program-name":"Enhance economic resilience of Jordanian women through skill development","programID":"5c1816b90d204e00080cb52c","ranking":27.713175487866202,"raw_score":10.108037936624163},{"orig_position":33,"orig_ranking":34.116431216906975,"position":33,"program-name":"Reduce chronic food insecurity","programID":"5b86c71efa8cf800104c3835","ranking":27.114399507843174,"raw_score":9.957150129123479},{"orig_position":34,"orig_ranking":33.85123837447307,"position":34,"program-name":"Renovate health and fitness spaces in at-risk communities","programID":"5bae390418149200071e8caa","ranking":26.80725448602675,"raw_score":9.879751501802378},{"orig_position":35,"orig_ranking":31.65423550412732,"position":35,"program-name":"Prevent homelessness and eviction for families, seniors and supportive populations","programID":"5b86d084fa8cf800104c3837","ranking":24.262696765879095,"raw_score":9.238538847551869},{"orig_position":36,"orig_ranking":31.230377034337323,"position":36,"program-name":"Keep older adults safe in their homes through home modifications  ","programID":"5bedecffd9d8f300088feaa8","ranking":23.77178600917882,"raw_score":9.114832402690542},{"orig_position":37,"orig_ranking":30.932523403663254,"position":37,"program-name":"Save the prairies by aiding prairie dogs","programID":"5c3772490d204e00080fee9b","ranking":23.42681342601308,"raw_score":9.027901466149428},{"orig_position":39,"orig_ranking":29.861112111209017,"position":38,"program-name":"Sponsor a Class of Women Survivors of War and Conflict","programID":"5c1d4ef56bf7b300084aebe5","ranking":22.185910233547627,"raw_score":8.715201611314722},{"orig_position":40,"orig_ranking":29.861112111209017,"position":39,"program-name":"Sponsor a class of women survivors of war and conflict in DRC","programID":"5c19248c0d204e00094ef629","ranking":22.185910233547627,"raw_score":8.715201611314722},{"orig_position":41,"orig_ranking":29.861112111209017,"position":40,"program-name":"Sponsor a class of women survivors of war and conflict in Afghanistan","programID":"5c19248a5b03bb000926f88a","ranking":22.185910233547627,"raw_score":8.715201611314722},{"orig_position":42,"orig_ranking":29.861112111209017,"position":41,"program-name":"Give women survivors of war and conflict resources and skills in Nigeria","programID":"5c1924896bf7b30009fb7038","ranking":22.185910233547627,"raw_score":8.715201611314722},{"orig_position":38,"orig_ranking":29.861112111209017,"position":42,"program-name":"Sponsor a class of women survivors of war and conflict","programID":"5c1921050d204e00094ef5ad","ranking":22.185910233547627,"raw_score":8.715201611314722},{"orig_position":44,"orig_ranking":29.67621579077627,"position":43,"program-name":"Teach young women of color key coding and tech skills","programID":"5bf3201e0f36530008cffc46","ranking":21.971764241325957,"raw_score":8.66123815865561},{"orig_position":45,"orig_ranking":29.67621579077627,"position":44,"program-name":"Teach young women of color in Oakland key coding skills","programID":"5bf320c60f36530008cffca4","ranking":21.971764241325957,"raw_score":8.66123815865561},{"orig_position":43,"orig_ranking":29.67621579077627,"position":45,"program-name":"Teach young women of color in New York City key coding skills","programID":"5bf57aa20f36530008d076c9","ranking":21.971764241325957,"raw_score":8.66123815865561},{"orig_position":46,"orig_ranking":29.45842857123475,"position":46,"program-name":"Introduce circuitry and electronics through arts-and-crafts activities","programID":"5c0ae4030f36530008d4d0e9","ranking":21.719524174499536,"raw_score":8.597675237100539},{"orig_position":47,"orig_ranking":29.45842857123475,"position":47,"program-name":"Advance young women of color in tech careers","programID":"5baa94e45d67100007039310","ranking":21.719524174499536,"raw_score":8.597675237100539},{"orig_position":48,"orig_ranking":29.391864239491834,"position":48,"program-name":"Respond to crisis by providing necessities","programID":"5c19128b0d204e00094ef3ed","ranking":21.64242969888046,"raw_score":8.578247910713582},{"orig_position":49,"orig_ranking":29.276914844560974,"position":49,"program-name":"Connect families to resources and networks to break poverty","programID":"5c17e3430d204e00080caed3","ranking":21.509295885426866,"raw_score":8.544699021168205},{"orig_position":50,"orig_ranking":29.174077019950317,"position":50,"program-name":"Increase physical activity and healthy food consumption for kids","programID":"5b86b8961b21cb00106d3557","ranking":21.39018963205403,"raw_score":8.51468498915851},{"orig_position":51,"orig_ranking":28.118876475831616,"position":51,"program-name":"Generate economic opportunities for underserved youth with free tech training","programID":"5baa95235d6710000703932c","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":53,"orig_ranking":28.118876475831616,"position":52,"program-name":"OH NO","programID":"5ba543fd5d67100007028007","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":55,"orig_ranking":28.118876475831616,"position":53,"program-name":"Transform educational spaces affected by natural disaster","programID":"5ba541f018149200071cbce1","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":56,"orig_ranking":28.118876475831616,"position":54,"program-name":"Teach the building blocks of socially responsible game design","programID":"5b85ee07936d7d00108228e9","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":58,"orig_ranking":28.118876475831616,"position":55,"program-name":"Pair low-income parents with coaches to achieve their goals","programID":"5c01b2b50f36530008d2f07d","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":59,"orig_ranking":28.118876475831616,"position":56,"program-name":"Improve work readiness skills and employee talent pipeline through job shadowing","programID":"5ba55c042c63670007fc71ce","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":60,"orig_ranking":28.118876475831616,"position":57,"program-name":"Create pathways to economic prosperity for veterans with free tech training","programID":"5baa95125d67100007039322","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":52,"orig_ranking":28.118876475831616,"position":58,"program-name":"Makeover community schools in New York City","programID":"5ba544965d67100007028069","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":54,"orig_ranking":28.118876475831616,"position":59,"program-name":"Enable young adults to transition to meaningful careers ","programID":"5c083c290f36530008d4439b","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":57,"orig_ranking":28.118876475831616,"position":60,"program-name":"Develop youth personal finance skills through an educational simulation","programID":"5ba55f202c63670007fc7286","ranking":20.168061647114854,"raw_score":8.206716369365832},{"orig_position":61,"orig_ranking":27.719575529616318,"position":61,"program-name":"Enable students to conduct technology projects that address a social need","programID":"5b85ebef936d7d00108228e5","ranking":19.705593291215756,"raw_score":8.090177231878425},{"orig_position":62,"orig_ranking":27.074732363767467,"position":62,"program-name":"Improve animal welfare in rural communities","programID":"5b91936820cfe30008d8cee7","ranking":18.9587391664021,"raw_score":7.901974656665507},{"orig_position":64,"orig_ranking":26.407473202057112,"position":63,"program-name":"Invest in Chicago youth through free arts education","programID":"5bd35fc70f36530008c99bef","ranking":18.185922947458277,"raw_score":7.707229795869793},{"orig_position":65,"orig_ranking":26.407473202057112,"position":64,"program-name":"Invest in Detroit youth through free arts education","programID":"5bd35fcdd9d8f300088a94cd","ranking":18.185922947458277,"raw_score":7.707229795869793},{"orig_position":66,"orig_ranking":26.407473202057112,"position":65,"program-name":"Invest in Miami youth through free arts education","programID":"5bd35fd00f36530008c99bfd","ranking":18.185922947458277,"raw_score":7.707229795869793},{"orig_position":67,"orig_ranking":26.407473202057112,"position":66,"program-name":"Invest in Los Angeles youth through free arts education","programID":"5bd35fd4d9d8f300088a94dd","ranking":18.185922947458277,"raw_score":7.707229795869793},{"orig_position":68,"orig_ranking":26.407473202057112,"position":67,"program-name":"Invest in New York youth through free arts education","programID":"5bd35fca6d3c360008573c18","ranking":18.185922947458277,"raw_score":7.707229795869793},{"orig_position":63,"orig_ranking":26.407473202057112,"position":68,"program-name":"Invest in Pittsburgh youth through free arts education","programID":"5bd35fd26d3c360008573c28","ranking":18.185922947458277,"raw_score":7.707229795869793},{"orig_position":69,"orig_ranking":26.182020140525303,"position":69,"program-name":"Vaccinate children around the world","programID":"5c1bb2f36bf7b30009fbb4f6","ranking":17.924804340835152,"raw_score":7.641429537734052},{"orig_position":70,"orig_ranking":26.01796206291414,"position":70,"program-name":"Reach at-risk veterans through peer support and resource navigation","programID":"5b86badbfa8cf800104c382f","ranking":17.734793097075432,"raw_score":7.5935478909614496},{"orig_position":71,"orig_ranking":25.520707026352042,"position":71,"program-name":"Provide lodging for veteran families","programID":"5b7ebaa4936d7d00108228b4","ranking":17.158874804366388,"raw_score":7.448420077913468},{"orig_position":72,"orig_ranking":24.015926035357904,"position":72,"program-name":"Create safe space for young Syrian refugees in Lebanon to cope with trauma","programID":"5b74898a936d7d001082284c","ranking":15.416044997702098,"raw_score":7.009237850923835},{"orig_position":73,"orig_ranking":23.460501053543748,"position":73,"program-name":"Pair at-risk youth with law enforcement for a life-skills mentoring program","programID":"5b76e540936d7d0010822874","ranking":14.772754565762122,"raw_score":6.847132679540946},{"orig_position":74,"orig_ranking":23.324900093459476,"position":74,"program-name":"Impact middle school-aged girls through female mentorship","programID":"5bae389118149200071e8c58","ranking":14.61570221298683,"raw_score":6.807556467462139},{"orig_position":75,"orig_ranking":22.571410897622904,"position":75,"program-name":"Respond to disasters with urgent needs and resources to rebuild","programID":"5bdcbcd0d9d8f300088c7787","ranking":13.743014800424612,"raw_score":6.587644689588396},{"orig_position":76,"orig_ranking":22.144354951315567,"position":76,"program-name":"Protect stray dogs through humane treatment","programID":"5b68b7df1b21cb00106d3439","ranking":13.248400742437385,"raw_score":6.463005035930548},{"orig_position":77,"orig_ranking":21.98534799805634,"position":77,"program-name":"Equip schools with after-school STEM activities","programID":"5ba141be18149200071bed5e","ranking":13.064239685602148,"raw_score":6.416597599727432},{"orig_position":78,"orig_ranking":21.27562101614146,"position":78,"program-name":"Tackle hunger, inactivity, and isolation for children living in poverty","programID":"5b870569fa8cf800104c383a","ranking":12.242237450009076,"raw_score":6.209458169911747},{"orig_position":79,"orig_ranking":19.66851199851587,"position":79,"program-name":"Fund scholarships for military children","programID":"5b772bed1b21cb00106d34d5","ranking":10.380891835438009,"raw_score":5.7404106994824255},{"orig_position":80,"orig_ranking":19.31423718356532,"position":80,"program-name":"Remove physical and social barriers to parks and recreation","programID":"5b85fdf5fa8cf800104c3828","ranking":9.970572519244108,"raw_score":5.637012794320471},{"orig_position":81,"orig_ranking":17.99522173479228,"position":81,"program-name":"Empower girls in the United Kingdom through sport and exercise","programID":"5bf5836ad9d8f30008917317","ranking":8.442895433123018,"raw_score":5.252047709239775},{"orig_position":82,"orig_ranking":17.810325414359532,"position":82,"program-name":"Inspire youth in El Salvador to become community leaders","programID":"5b47ae842e9ec6001ae7ac8b","ranking":8.228749440901348,"raw_score":5.198084256580663},{"orig_position":83,"orig_ranking":17.622251022543185,"position":83,"program-name":"Expand kids' access to basic needs items","programID":"5c180a446bf7b30009fb51bf","ranking":8.01092262232143,"raw_score":5.143193258666704},{"orig_position":84,"orig_ranking":17.59253819481802,"position":84,"program-name":"Prepare first generation students for college success","programID":"5b3fb58e437bf100197f2bba","ranking":7.9765093740749275,"raw_score":5.134521335025592},{"orig_position":85,"orig_ranking":17.451571669078483,"position":85,"program-name":"Train law enforcement and shelters in effective and humane handling of animals","programID":"5b76eb7a936d7d0010822878","ranking":7.813242650032605,"raw_score":5.093379140197373},{"orig_position":87,"orig_ranking":16.470773318956393,"position":86,"program-name":"Mobilize communities to support struggling young readers","programID":"5bc64cd3d9d8f3000887f38d","ranking":6.677286913516662,"raw_score":4.807125388845955},{"orig_position":88,"orig_ranking":16.470773318956393,"position":87,"program-name":"Diversify reading materials for children in need","programID":"5b918c868553ef0007f76022","ranking":6.677286913516662,"raw_score":4.807125388845955},{"orig_position":86,"orig_ranking":16.470773318956393,"position":88,"program-name":"Cultivate lifelong readers through tutoring","programID":"5bc64cb2d9d8f3000887f348","ranking":6.677286913516662,"raw_score":4.807125388845955},{"orig_position":89,"orig_ranking":16.437882419847625,"position":89,"program-name":"Jump-start healthy lifestyles for kids and families at risk of type 2 diabetes","programID":"5b8409ec1b21cb00106d353b","ranking":6.639192838911906,"raw_score":4.797525919949995},{"orig_position":90,"orig_ranking":16.252986099414876,"position":90,"program-name":"Replenish educational materials in disaster-affected communities","programID":"5c180bdd5b03bb000926da4b","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":93,"orig_ranking":16.252986099414876,"position":91,"program-name":"Prepare university students to teach music","programID":"5b85ea1dfa8cf800104c3823","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":95,"orig_ranking":16.252986099414876,"position":92,"program-name":"Provide educational opportunities to low-income youth outside of school","programID":"5b871e34936d7d00108228fb","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":97,"orig_ranking":16.252986099414876,"position":93,"program-name":"Guide New York City students to and through college","programID":"5c005e126d3c360008604b24","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":98,"orig_ranking":16.252986099414876,"position":94,"program-name":"Provide school supplies to children in need","programID":"5b857eac1b21cb00106d3549","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":99,"orig_ranking":16.252986099414876,"position":95,"program-name":"Place students in apprenticeship positions","programID":"5c1810af5b03bb0008c28c74","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":100,"orig_ranking":16.252986099414876,"position":96,"program-name":"Provide school supplies to students affected by natural disasters","programID":"5b86c6dafa8cf800104c3832","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":101,"orig_ranking":16.252986099414876,"position":97,"program-name":"Distribute books to struggling readers for home use","programID":"5bc64c830f36530008c6fa40","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":91,"orig_ranking":16.252986099414876,"position":98,"program-name":"Equip teachers with core school supplies","programID":"5b85e571fa8cf800104c3820","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":92,"orig_ranking":16.252986099414876,"position":99,"program-name":"Incorporate innovative music technology in classrooms","programID":"5b88185efa8cf800104c3847","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":94,"orig_ranking":16.252986099414876,"position":100,"program-name":"Unite teachers and experts to teach STEM","programID":"5c1811b16bf7b30009fb52df","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":96,"orig_ranking":16.252986099414876,"position":101,"program-name":"Enhance summer opportunities for youth in New York","programID":"5b6dfafdfa8cf800104c3750","ranking":6.425046846690237,"raw_score":4.743562467290883},{"orig_position":103,"orig_ranking":10.705520521206166,"position":102,"program-name":"Revitalize schools through mural painting","programID":"5c1814f66bf7b30009fb5346","ranking":0.0,"raw_score":3.1244907875134476},{"orig_position":102,"orig_ranking":10.705520521206166,"position":103,"program-name":"Paint murals to empower communities","programID":"5c1814375b03bb000926db6c","ranking":0.0,"raw_score":3.1244907875134476}],"weights":{"MSCI":0.175,"NIELSEN":0.25,"Researched_Corpcom":0.25,"SASB":0.15,"TVL":0.175}}
    db = get_db()
    programs = list(db['mm_programs'].find(filter={'nonprofit': {'$ne': None}},
                                        projection={'_id': True, 'name': True, 'isValid': True, 'active': True,
                                                    'nonprofit': True, 'minimumFunding': True,
                                                    'isValidNonprofit': True, 'ImpactAndScope': True}))
                                                        
    programs_dict = {
        d['name']: {
            'id': str(d['_id']),
            'nonprofit': str(d['nonprofit']),
            'minimumFunding': d.get('minimumFunding'),
            'isValid': d.get('isValid'),
            'isValidNonprofit': d.get('isValidNonprofit'),
            'active': d.get('active'),
        }
        for d in programs
    }

    id_to_name_dict = {str(d['_id']): d['name'] for d in programs}
    del programs

    try:
        # env = environ.get('ENV', 'local')
        # openshift_deploy = environ.get('OPENSHIFT_DEPLOY', 'False')
        # openshift_matchmaking_algo_url = environ.get('OPENSHIFT_MATCHMAKING_ALGO_URL', '')

        # algo_server = "internal-givewith-matchmaking-algo-1406367349.us-east-1.elb.amazonaws.com"
        # # algo_server = 'ec2-54-225-45-142.compute-1.amazonaws.com'
        # # if env == "staging":
        # #     algo_server = "internal-givewith-matchmaking-algo-1406367349.us-east-1.elb.amazonaws.com" # load balancer
        # # elif env == "production":
        # #     algo_server = "internal-givewith-matchmaking-algo-114916578.us-east-1.elb.amazonaws.com"
        # # elif env == "sandbox":
        # #     algo_server = "internal-algo-loadbalancer-310878003.us-east-1.elb.amazonaws.com"
        
        
        # uri = F'http://{algo_server}:5000/recommend/?id={brand_id}&RATING=0.35&REPORTING=0.15&CONSUMER=0.25&CSR=0.25'
        # print(uri)
        # if openshift_deploy == "True":
        #     algo_server = openshift_matchmaking_algo_url
        #     uri = F'http://{algo_server}:8080/recommend/?id={brand_id}&RATING=0.35&REPORTING=0.15&CONSUMER=0.25&CSR=0.25'

        # response = pip._vendor.requests.get(uri, timeout=5.0)
        # try:
        #     response = pip._vendor.requests.get(uri, timeout=5.0)
        # except:
        #     print("could not make a connection at this time")
        
        recommendation_data = MM_ALGO_RESPONSE
        recommendations = recommendation_data["recommendations"]
        recommendation_list = list()

        for r in recommendations:
            # current_app.logger.info(str(r))
            program_id = r["programID"]
            score = r["ranking"]
            # current_app.logger.info("ranking " + str(score))
            # current_app.logger.info("programID " + str(programID))
            if program_id in id_to_name_dict:
                program_name = id_to_name_dict[program_id]
                program = programs_dict[program_name]
                is_valid = all([program['isValid'], program['isValidNonprofit']])
                active = program['active']
                nonprofit = program['nonprofit']
                minimum_funding = program['minimumFunding']
                recommendation_list.append((program_name,
                                                              is_valid,
                                                              score,
                                                              program_id,
                                                              nonprofit,
                                                              active,
                                                              minimum_funding))
            else:
                log = f'''MM-algo, can't find program with id {program_id};
                      probable data-source alignment issue (db v. staging/local/prod)'''
                print(log)

        return recommendation_list

    except Exception as e:
        print("something went wrong ...")
        return list()
