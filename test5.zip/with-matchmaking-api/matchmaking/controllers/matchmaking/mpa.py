from flask import request, jsonify

from matchmaking.validation.mpa import validate_mpa_patch_request
from matchmaking.controllers import mpa_bp
from matchmaking.permission_decorator import require_nonprofit_permission
from matchmaking.utils import GivewithError
from matchmaking.dao import mpa_dao
from matchmaking.dao.utils import get_document_by_id
from matchmaking.models.models import GivewithValidator
from matchmaking.models.mpa import patch_review_request_schema, patch_info_request_schema

"""
@api {patch} /nonprofit/:npo_id/mpa/form_name Update MAP
@apiName UpdateMPA
@apiGroup MPA
@apiVersion 0.1.0
@apiPermission nonprofit
@apiDescription Update MAP by nonprofit id

@apiParam {String} npo_id the nonprofit id
@apiParam {String} form_name section name

@apiParamExample {json} info request example:
{
    "orgDescription": "organizational description",
    "name": "name",
    "title": "title",
    "email": "test@email.com",
    "phone": "(555) 555-1234",
    "address": "first line address",
    "city": "New York",
    "state": "NY",
    "zip": "10001",
}

@apiParamExample {json} review request example:
{
	"name": "name",
	"email": "test@email.com",
}

@apiError 400 Bad request
@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@mpa_bp.route('/nonprofit/<npo_id>/mpa/<form_name>', methods=['PATCH'])
@require_nonprofit_permission
def patch_mpa(npo_id, form_name):
    # validate request
    patch_request = request.json
    if patch_request is None:
        raise GivewithError('invalid request', code=400)

    is_valid, errors = validate_mpa_patch_request(npo_id, form_name, patch_request)
    if not is_valid:
        raise GivewithError('bad request: ' + ''.join(str(errors)), code=400)

    # normalize
    schema = (patch_review_request_schema if form_name == 'review' else patch_info_request_schema)
    v = GivewithValidator(schema, patch_request)
    patch_request = v.normalized(patch_request)

    # update
    mpa = mpa_dao.update_mpa(npo_id, form_name, patch_request)
    set_progress(mpa)
    return jsonify(mpa)


"""
@api {Get} /nonprofit/:npo_id/mpa Get MAP
@apiName GetMPA
@apiGroup MPA
@apiVersion 0.1.0
@apiPermission nonprofit
@apiDescription Get MPA

@apiParam {String} npo_id the nonprofit id

@apiParamExample {json} response example:
{
    "info": {
        "orgDescription": "organizational description",
        "name": "name",
        "title": "title",
        "email": "test@email.com",
        "phone": "(555) 555-1234",
        "address": "first line address",
        "city": "New York",
        "state": "NY",
        "zip": "10001",
    },
    "review": {
        "name": "reviewer",
        "email": "e@mail.com",
    }
    "status": "SIGNATURE_PENDING",
    "effectiveDate": date,
    "expirationDate": date,
    "addendum": {
        "file": "addendum_file.pdf",
        "url": "https://s3.amazonaws.com",
    },
    "legalNotes": "legal notes",
    "progress": {
        "info": {
            "complete": 10,
            "total": 10,
        }
    }
    "percentComplete": 100,
    "nonprofitPublicName": "nonprofit name"
}

@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@mpa_bp.route('/nonprofit/<npo_id>/mpa', methods=['GET'])
@require_nonprofit_permission
def get_mpa(npo_id):
    npo = get_document_by_id('mm_nonprofits', npo_id)

    mpa = npo.get('mpa', {})
    mpa['nonprofitPublicName'] = npo.get('name', '')

    set_progress(mpa)
    return jsonify(mpa)


"""
@api {post} /nonprofit/:npo_id/mpa:submit Submit MAP
@apiName SubmitMPA
@apiGroup MPA
@apiVersion 0.1.0
@apiPermission nonprofit
@apiDescription Submit

@apiParam {String} npo_id the nonprofit id


@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@mpa_bp.route('/nonprofit/<npo_id>/mpa:submit', methods=['POST'])
@require_nonprofit_permission
def submit_mpa(npo_id):
    mpa = get_document_by_id('mm_nonprofits', npo_id, projection={'mpa': True}).get('mpa', {})
    set_progress(mpa)
    if mpa['percentComplete'] != 100:
        raise GivewithError('Incomplete mpa', code=400)

    return jsonify(mpa_dao.submit_mpa(npo_id, mpa))


def set_progress(mpa):
    total = 0
    complete = 0
    optional_fields = ['title', 'phone']
    incomplete_fields = {'info': []}

    info = mpa.get('info', {})

    for key in patch_info_request_schema:
        if key not in optional_fields:
            total += 1
            if len(info.get(key, '')) > 0:
                complete += (1 if len(info.get(key, '')) > 0 else 0)
            else:
                incomplete_fields['info'].append(key)

    mpa['incompleteFields'] = incomplete_fields
    mpa['progress'] = {'info': {'complete': complete, 'total': total}}
    mpa['percentComplete'] = (float(complete/total) * 100)

