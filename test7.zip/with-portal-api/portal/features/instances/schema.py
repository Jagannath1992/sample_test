from marshmallow import fields, validate

from portal.shared.custom_fields import FormattedDateTimeField, ObjectIdField, OptionalUrl
from portal.shared.enums import InstanceStatus, InstanceType
from portal.shared.schema import EntitySchema, OrderedSchema, CauseAreaReferenceSchema, SearchRequestSchema, SearchResponseSchema, LocaleReferenceSchema


class SageProductsSchema(OrderedSchema):
    annualSubscription = fields.String()
    monthlySubscription = fields.String()
    transaction = fields.String()


class SageDepartmentsSchema(OrderedSchema):
    sales = fields.String()
    socialImpact = fields.String()


class SageAccountsSchema(OrderedSchema):
    socialImpactPayable = fields.String()
    socialImpactEnablement = fields.String()
    subscriptionRevenue = fields.String()
    transactionRevenue = fields.String()


class SageSchema(OrderedSchema):
    locationId = fields.String()
    exchangeRate = fields.String()
    taxSolutionId = fields.String()
    invoiceTaxDetailId = fields.String()
    billTaxDetailId = fields.String()
    accounts = fields.Nested(SageAccountsSchema, required=True)
    departments = fields.Nested(SageDepartmentsSchema, required=True)
    products = fields.Nested(SageProductsSchema, required=True)


class SubscriptionFrequencySchema(OrderedSchema):
    id = fields.String(required=True)
    amount = fields.Float(required=True)
    footer = fields.String(allow_none=True)
    enabled = fields.Boolean(load_default=False)


class StripePriceSchema(OrderedSchema):
    required = fields.Boolean(required=True)
    monthly = fields.Nested(SubscriptionFrequencySchema)
    annual = fields.Nested(SubscriptionFrequencySchema)


class StripeSchema(OrderedSchema):
    trialPeriodDays = fields.Integer(required=True)
    currencyFactor = fields.Float(required=True)
    prices = fields.Nested(StripePriceSchema)
    suppliers = fields.Nested(StripePriceSchema, allow_none=True)


class SettingsSchema(OrderedSchema):
    locale = fields.Nested(LocaleReferenceSchema, required=True)
    loginUrl = fields.Url(required=True)
    portalUrl = fields.Url(required=True)
    givewithEmail = fields.Email(required=True)
    serviceFee = fields.Float(required=True)
    allowRegistration = fields.Boolean(required=True)
    sage = fields.Nested(SageSchema, required=True)
    stripe = fields.Nested(StripeSchema, required=True)
    termsOfUseUrl = fields.Url()
    cookiePolicyUrl = fields.Url()
    privacyPolicyUrl = fields.Url()


class ImpactSchema(OrderedSchema):
    unitPrice = fields.Float(required=True)
    unitValue = fields.Float(required=True)
    impactMeasurement = fields.String(required=True)


class InstanceCauseAreaSchema(OrderedSchema):
    causeArea = fields.Nested(CauseAreaReferenceSchema, required=True)
    skus = fields.List(fields.Number)
    displayOrder = fields.Number(required=True)
    active = fields.Boolean(required=True)
    impact = fields.Nested(ImpactSchema, required=True)
    assignedDate = FormattedDateTimeField()


class InstanceSettingsSchema(EntitySchema):
    """Instance Settings model"""
    name = fields.String(required=True)
    description = fields.String(required=True)
    settings = fields.Nested(SettingsSchema, required=True)
    causeAreas = fields.List(fields.Nested(InstanceCauseAreaSchema))
    skus = fields.List(fields.Number)
    restrictedDomains = fields.List(fields.String(required=True))
    status = fields.String(required=True, validate=validate.OneOf([s.value for s in InstanceStatus]))
    type = fields.String(required=True, validate=validate.OneOf([s.value for s in InstanceType]))
    causeAreaCount = fields.Integer()


class InstanceSettingsRequest(InstanceSettingsSchema):
    """Request model for PUT Instance Settings requests"""
    class Meta:
        exclude = ('id', 'causeAreaCount', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated')


class InstanceSettingsResponse(InstanceSettingsSchema):
    """Response model for GET/POST/PUT Instance Settings responses"""
    pass


class InstanceSettingsSearchRequest(SearchRequestSchema):
    """Request model for GET Instance Settings search request"""

    id = ObjectIdField(attribute='_id', allow_none=True)
    name = fields.String(allow_none=True)
    description = fields.String(allow_none=True)
    locale = fields.String(allow_none=True)
    loginUrl = fields.Url(allow_none=True)
    portalUrl = fields.Url(allow_none=True)
    givewithEmail = fields.Email(allow_none=True)
    serviceFee = fields.Float(allow_none=True)
    allowRegistration = fields.Boolean(allow_none=True)
    exchangeRate = fields.String(allow_none=True)
    locationId = fields.String(allow_none=True)
    status = fields.String(allow_none=True)
    type = fields.String(allow_none=True)
    causeAreaId = ObjectIdField(allow_none=True)
    causeAreaCountFrom = fields.Integer(allow_none=True)
    causeAreaCountTo = fields.Integer(allow_none=True)
    createdBy = fields.String(allow_none=True)
    createdAtFrom = fields.DateTime(allow_none=True)
    createdAtTo = fields.DateTime(allow_none=True)
    lastUpdatedFrom = fields.DateTime(allow_none=True)
    lastUpdatedTo = fields.DateTime(allow_none=True)
    lastUpdatedBy = fields.String(allow_none=True)

    class Meta:
        contains_fields = [
            'name', 'description', 'locale', 'loginUrl', 'portalUrl', 'givewithEmail', 'exchangeRate', 'locationId',
            'monthly', 'annual', 'createdBy', 'lastUpdatedBy']
        range_fields = ['createdAt', 'lastUpdated', 'serviceFee', 'causeAreaCount']

    def _convert_nested(self, key):
        if key == 'locale':
            return 'settings.locale.name'
        elif key == 'loginUrl':
            return 'settings.loginUrl'
        elif key == 'portalUrl':
            return 'settings.portalUrl'
        elif key == 'givewithEmail':
            return 'settings.givewithEmail'
        elif key == 'serviceFee':
            return 'settings.serviceFee'
        elif key == 'allowRegistration':
            return 'settings.allowRegistration'
        elif key == 'exchangeRate':
            return 'settings.sage.exchangeRate'
        elif key == 'locationId':
            return 'settings.sage.locationId'
        elif key == 'monthly':
            return 'settings.stripe.prices.monthly'
        elif key == 'annual':
            return 'settings.stripe.prices.annual'
        elif key == 'causeAreaId':
            return 'causeAreas.causeArea._id'
        return key


class InstanceSettingsSearchResponse(SearchResponseSchema):
    """Response model for GET Instance Settings search response"""
    results = fields.List(fields.Nested(InstanceSettingsSchema, required=True))
