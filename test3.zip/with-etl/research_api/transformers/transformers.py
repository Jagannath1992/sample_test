import copy
import functools
import pandas as pd
import numpy as np

from datetime import datetime

from research_api.logger import log_exception, log_error, PipelineLogger
from research_api.models import MSCI_BASE_COLUMNS
from research_api.mongodb import *
from research_api.utils import *

from .nielsen import transform_nielsen
from .sasb import transform_sasb


def transform(dataset, data):
    if dataset == 'CSRIT':
        return _transform_csrit(data)

    elif dataset == 'MSCI':
        return _transform_msci(dataset, data)

    elif dataset == 'SASB':
        return transform_sasb(dataset, data)

    elif dataset == 'CSRHUB':
        return transform_csrhub(data)

    elif dataset == 'TVL':
        return _transform_tvl(data)

    elif dataset == 'NIELSEN':
        return transform_nielsen(data)

    else:
        raise DatasetNotFound()


def _merge_csrit_brand(brands, new_brand, summary_fields):
    """
    Merges a csrit brand object in to the overall brands object
    Acts like a recursive upsert

    Returns: void
    Side effects: the 'brands' object will be updated with data from the new_brand
    """
    brand_id = new_brand.pop('brandId')
    brand = brands.get(brand_id)

    # If we have not yet transformed any data for this brand, initialize the brand
    if not brand or brand.get('noData'):
        brands[brand_id] = new_brand
        return

    for field, default_type in summary_fields:
        new_data = new_brand.get('researchCorpCommitments', {}).pop(field, default_type())
        brand.get('researchCorpCommitments', {}).get(field, default_type()).update(new_data)

    themes = brand.get('researchCorpCommitments', {}).get('themes', {})
    new_themes = new_brand.get('researchCorpCommitments', {}).pop('themes', {})
    for new_theme, new_program in new_themes.items():
        if new_theme not in themes.keys():
            # If the new theme didn't previously exist, simply add it in
            themes[new_theme] = {'themePrograms': list()}

        # Add in the new program
        themes[new_theme].get('themePrograms', []).extend(new_program.get('themePrograms', []))


def _transform_csrit(data):
    csrit_data, narratives = data
    brands = {}

    # fields that should be combined and deduplicated at top level of researchCorpCommitments
    summary_fields = [('sources', set), ('sourceYears', set), ('sdgs', set), ('impactSummary', set),
                      ('continents', set), ('countries', set), ('states', set), ('cities', set),
                      ('otherCities', set), ('nonprofits', dict), ('otherNonprofits', dict)]
    for row in csrit_data:
        # merge row into brands
        _merge_csrit_brand(brands, _transform_csrit_row(row), summary_fields)

    # Post Processing
    narratives_lookup = _csrit_parse_narratives(narratives)
    for brand_id, brand in brands.items():
        commitments = brand.get('researchCorpCommitments', {})

        if commitments.get('noData'):
            continue

        # transform fields from set to list since mongo can't save sets
        for field, default_type in summary_fields:
            if default_type is set:
                commitments.update({field: list(commitments.get(field, []))})

        # transform locations into a singular object at top level
        location_keys = ['continents', 'countries', 'states', 'cities', 'otherCities']
        commitments['locationSummary'] = {key: commitments.pop(key, []) for key in location_keys}

        themes = commitments.pop('themes', {})
        commitments['themes'] = list()

        for theme_key, theme in themes.items():
            # Calculate max relevancy
            theme['themeRelevance'] = _get_max_relevancy(theme)
            theme['themeVisibility'] = True
            theme['theme'] = theme_key

            # Lookup narrative and update the theme
            theme_narrative_dict = narratives_lookup.get(theme_key.lower(), {}).get(brand_id, {})
            theme.update(theme_narrative_dict)

            # NOTE: This is done after transformation due to keep lookups fast
            commitments['themes'].append(theme)

    return brands


def _get_max_relevancy(theme):
    themePrograms = theme.get('themePrograms', [])

    relevancies = []
    for themeProgram in themePrograms:
        # Grab first letter off each relevancy
        relevancies.extend([int(x[:1]) for x in themeProgram.get('relevancies', []) if x != ''])

    if relevancies:
        return max(relevancies)
    else:
        return -1


def _transform_csrit_row(row):
    """ Transforms one row into a brand object """

    if row.get('noData', '').strip().lower() == 'no data':
        brand = {
            'brandId': row.pop('brandId', ''),
            'researchCorpCommitments': {
                'brandName': row.pop('brandName', ''),
                'researchId': row.pop('researchId', ''),
                'noData': True,
            }
        }

        return brand

    # minor cleanup - pop/discard unneeded values
    row.pop('_id', '')
    row.pop('noData', '')

    # Pull location data into it's own object
    row.get('cities', set()).discard('OTHER')  # minor cleanup - before adding location to theme
    location_keys = ['continents', 'countries', 'states', 'cities', 'otherCities']
    location = {key: list(row.get(key, [])) for key in location_keys}
    row['location'] = location

    # Extract tax ids from nonprofit names
    nonprofit_names = split_nonprofit_names(row.pop('nonprofitNames', []))
    other_nonprofit_names = split_nonprofit_names(row.pop('otherNonprofitNames', []))
    row['nonprofitNames'], row['taxIds'], row['nonprofits'] = nonprofit_names
    row['otherNonprofitNames'], row['otherTaxIds'], row['otherNonprofits'] = other_nonprofit_names

    # duplicate data to summarized on top level
    row['impactSummary'] = set(row.get('programImpacts', []))

    brand = {
        'brandId': row.pop('brandId', ''),
        'researchCorpCommitments': {
            'brandName': row.pop('brandName', ''),
            'researchId': row.pop('researchId', ''),
            'sdgs': row.pop('sdgs', set()),
            'sources': row.pop('sources', set()),
            'sourceYears': row.pop('sourceYears', set()),
            'impactSummary': row.pop('impactSummary'),
            'nonprofits': row.pop('nonprofits'),
            'otherNonprofits': row.pop('otherNonprofits'),
            'continents': row.pop('continents', set()),
            'countries': row.pop('countries', set()),
            'states': row.pop('states', set()),
            'cities': row.pop('cities', set()),
            'otherCities': row.pop('otherCities', set()),
            'themes': _csrit_unroll_themes(row)
        }
    }

    return brand


def _csrit_unroll_themes(row):
    """
    Unrolls a row by theme, creating duplicate rows that differ by theme

    Returns a 'themes' object
    """
    result = {}
    themes = row.pop('themes', [])
    for theme in themes:
        new_row = copy.deepcopy(row)
        result[theme] = {'themePrograms': [new_row]}

    return result


def _csrit_parse_narratives(narratives):
    """Parses narratives into an object that can be looked up by brand Id"""
    result = {}

    for row in narratives:
        brand_name = row.get('brandName', '')
        try:
            theme, impacts, narrative = row['themes'][0].lower(), row['programImpacts'], row['narrative']
            if theme and impacts:
                result.setdefault(theme, {})[row['brandId']] = {
                    'impacts': [get_vocabulary_id(impact, 'impact') for impact in impacts],
                    'narrative': narrative
                }
            else:
                PipelineLogger.get_instance('CSRIT').log_error(f'NARRATIVE - {brand_name} - Theme or impact missing')
        except Exception as e:
            PipelineLogger.get_instance('CSRIT').log_exception(f"NARRATIVE - {brand_name} - {e}")

    return result


def split_nonprofit_names(fields):
    """ Splits the nonprofit_name fields into nonprofit_names and tax_ids and a lookup dict """
    nonprofit_names = []
    tax_ids = []
    non_profits_dict = dict()

    for field in fields:
        name = field.strip()

        # skip if field is empty or other is referenced
        if not name or name.upper().startswith('OTHER'):
            continue

        tax_id = name  # set tax_id to name as fall_back for non_profits dictionary key

        # search for the last '(' and ')', some non-profit names could include ()
        open_paren = field.rfind('(')
        close_paren = field.rfind(')')

        if open_paren != -1 and close_paren != -1:
            raw_tax_id = field[open_paren + 1: close_paren]

            # tax_id can only contain digits and - and R, filter to remove any other text
            tax_id = ''.join(list(filter(_is_valid_tax_id_char, raw_tax_id)))

            if _is_valid_tax_id_length(tax_id):
                name = field[:open_paren].strip()  # redefine name as name with tax_id removed
                tax_ids.append(tax_id)
            else:
                tax_id = name  # set tax_id back to fallback if failed to validate it

        nonprofit_names.append(name)
        non_profits_dict[tax_id] = name

    return (nonprofit_names, tax_ids, non_profits_dict)


def _list(l):
    return l.split(';')


def _is_valid_tax_id_char(char):
    """ Check if character is a valid tax id character
    Valid tax id characters are digits, - and R (canada)
    """
    return char.isdigit() or char in {'-', 'R'}


def _is_valid_tax_id_length(tax_id):
    """ Tax id can either be a 6, 7, 10 or 15 digit string with the following constraints:
    US > EIN > 12-3456789 (9 characters, all numbers, hyphen after the first 2 characters)
    UK > Charity Number > 123456 OR 1234567 (either 6 or 7 characters, all numbers, no hyphen or formatting)
    Canada > Charitable Registration Number > 123456789RR0001 (9 digits, followed by RR, followed by 4 digits)

    NOTE: The only check made here is for the length of the tax_id field, enough for this implementation
    """
    allowed_lengths = {6, 7, 10, 15}
    return len(tax_id) in allowed_lengths


def _transform_msci(dataset, data):
    get_logger().info(f'Start transformation for {dataset}')
    documents = data.reset_index().to_dict('records')
    now = datetime.utcnow()

    transformed_data = []
    for doc in documents:
        msci_obj = _transform_msci_row(doc, now)
        transformed_data.append(msci_obj)

    transformed_df = pd.DataFrame(transformed_data)

    industry_averages = _get_msci_averages(transformed_df)

    get_logger().info(f'Finished transformation for {dataset}')
    return (transformed_df, industry_averages)


def _transform_msci_row(msci_obj, update_date):
    suffixes = {
        'weights': '_WEIGHT',
        'quartile': '_QUARTILE',
        'score': '_SCORE'
    }

    new_msci_obj = {
        'msciId': msci_obj['msciId'],
        'industry': msci_obj['esg_industry'],
        'ISIN': msci_obj['ISSUER_ISIN'],
        'issuerId': msci_obj['ISSUERID'],
        'issuerName': msci_obj['ISSUER_NAME'],
        'issuerCusip': msci_obj['ISSUER_CUSIP'],
        'issuerSedol': msci_obj['ISSUER_SEDOL'],
        'industryAdjustedScore': msci_obj['INDUSTRY_ADJUSTED_SCORE'],
        'ivaCompanyRating': msci_obj['IVA_COMPANY_RATING'],
        'lastImported': update_date,
    }

    for key, suffix in suffixes.items():
        mapped_weights = _map_column(msci_obj, suffix, field_name=key)
        new_msci_obj.update(mapped_weights)

    return new_msci_obj


def _map_column(obj, suffix, field_name=None):
    column = {}
    for col in MSCI_BASE_COLUMNS:
        mapped_field = col + suffix
        column_name = _get_msci_column_name(col, suffix)

        if field_name:
            # Initialize field if it's not in the column
            if field_name not in column:
                column[field_name] = {}

            column[field_name][column_name] = obj.get(mapped_field.upper(), 0)
        else:
            column[column_name] = obj.get(mapped_field, 0)

    return column


def _get_msci_column_name(col, suffix):
    col = col.replace(suffix, '')
    words = col.split('_')

    if len(words) == 1:
        return words[0]

    new_words = [words[0].lower()]
    for word in words[1:]:
        new_words.append(word[0].upper() + word[1:].lower())

    return ''.join(new_words)


def _get_msci_averages(df):
    df_ind = df.copy()
    df_ind = df_ind[['industry', 'industryAdjustedScore', 'score']]
    
    # Unpacks the 'score' column from a Series of dicts to columns in the df
    df_ind = pd.concat([df_ind.drop(['score'], axis=1), df_ind['score'].apply(pd.Series)], axis=1)
    df_ind.set_index('industry')

    df_ind = df_ind.replace(0, np.nan)
    df_ind = df_ind.groupby('industry').mean()
    df_ind = df_ind.replace(np.nan, 0)

    return df_ind


def _transform_tvl(data):
    score_type_keys = ['ISIN', 'companyName', 'TICKER', 'CUSIP', 'SEDOL', 'date']
    dataframes = pd.DataFrame(columns=score_type_keys)
    
    for tvl_file, df in data:
        if tvl_file == 'industries':
            new_df = df

            new_df.rename(columns={'Industry': 'sics_industry'}, inplace=True)
            new_df['Industry'] = new_df['sics_industry'].apply(
                lambda ind: get_gics_industry(ind, 'SASB')  # TVL uses sasb industries
            )

        else:
            score_type = tvl_file  # if tvl_file isn't industries, then it's the name of it's score_type
            new_df = _rename_columns_by_score_type(score_type, df)

        dataframes = pd.merge(dataframes, new_df, how='outer', sort=False)

    dataframes['lastUpdated'] = datetime.utcnow()
    return dataframes


def _rename_columns_by_score_type(score_type, df):
    """
    Most columns from TVL have their score type appended to the end

    This method removes the score type from the end and appends it in the beginning
    to better align with how we want the data stored (nested under score_type)
    """
    rename_fields = {}
    article_suffixes = ['ArticleVolumeDaily', 'ArticleVolumeTTM']

    # Check and remove score_type appended at the end of column names
    for column_name in df.columns:
        name = column_name.split('_')

        if len(name) > 1:
            new_name = f'{score_type}.{name[0]}'

            # Volume data contains a few columns with an 'article' suffix
            if name[1] in article_suffixes:
                new_name += '_article'

            rename_fields[column_name] = new_name

    return df.rename(columns=rename_fields)


def transform_csrhub(data):
    return data
    # drop not useful columns
    # data.rename(columns={'ratings':'csrhub', 'id': 'csrhubId'}, inplace=True)
    # data['industry'] = data['industries'].apply(lambda x: x[0] if (isinstance(x, list)) else 'N/A')
    # columns = ['name', 'namevariants','alias', 'aliasvariants', 'ISIN', 'ticker', 'industry', 'industries', 'country', 'csrhub', 'csrhubId', 'description', 'specialissuesall']
    # data_final =data[columns]
    # return data_final.to_dict('records')

def _csrit_header_filter(header):
    start = header.find('(')
    end = header.find(')')
    if start != -1 and end != -1:
        header = header[:start] + header[end+1:]

    return header
