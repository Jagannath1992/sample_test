from bson import ObjectId
from portal.shared.enums import UserRole
from portal.testing.faker import DocumentFaker
from portal.shared.dates import get_utcnow


class UserFaker(DocumentFaker):
    def _generate_document(self, i):
        now = get_utcnow()
        document = {
            '_id': ObjectId(),
            'accountId': ObjectId(),
            'oktaId': ObjectId(),
            'username': f'username{i}@example.com',
            'first_name': f'First name {i}',
            'last_name': f'Last name {i}',
            'title': f'Title {i}',
            'orgId': '',
            'orgName': '',
            'orgType': 'brand',
            'type': 'client',
            'departmentName': f'Department Name {i}',
            'departmentType': 'Portal',
            'phoneNumber': f'Phone Number {i}',
            'last_login': now,
            'active': True,
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now,
            'roles': [UserRole.ORG_ADMIN.value]
        }
        document['name'] = document['first_name'] + ' ' + document['last_name']
        return document
