from matchmaking import db

permissions = [
    {'blueprint': 'root', 'permitted_scope': ['admin'], 'enable': True, 'description': ''},
    {'blueprint': 'admin', 'permitted_scope': ['admin'], 'enable': True, 'description': ''},
    {'blueprint': 'campaigns', 'permitted_scope': ['admin'], 'enable': True, 'description': 'only admin can access campaign endpoints on admin platform'},
    {'blueprint': 'survey', 'permitted_scope': ['admin', 'psf'], 'enable': True, 'description': 'admin and nonprofit user can access proposal submission form endpoints'},
    {'blueprint': 'dashboard', 'permitted_scope': ['admin', 'impact'], 'enable': True, 'description': 'admin and brand user can access dashboard endpoints on impact platform'},
]

for p in permissions:
    db().coll_permission.insert_one(p)
