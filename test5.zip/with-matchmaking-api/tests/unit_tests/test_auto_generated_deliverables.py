import pytest
from bson import ObjectId
from unittest import mock
from matchmaking.controllers.deliverables.create_template_data.general_data import (__round_quantity, __remove_and_store_symbol, START, END,
make_program_impacts)
from matchmaking.controllers.deliverables.create_template_data.research_data import make_sasb_data, make_esg_data

@pytest.mark.parametrize('quantity, expected_value', [
    (
        0.75,
        0.75,
    ),
    (
       1000,
       1000
    ),
    (
        7.25,
        7
    )
])
def test_quantity_rounding(quantity, expected_value):
    quantity_less_than_one = quantity
    assert __round_quantity(quantity_less_than_one) == expected_value


@pytest.mark.parametrize('quantity, expected_quantity, expected_symbol_position, expected_symbol', [
    (
        '$200.0',
        200.0,
        START,
        '$'
    ),
    (
       '£100.25',
       100.25,
       START,
       '£'
    ),
    (
        '€300.75',
        300.75,
        START,
        '€'
    ),
    (
        '9%',
        9,
        END,
        '%'
    )
])
def test_quantity_with_symbol(quantity, expected_quantity, expected_symbol_position, expected_symbol):
    (output_quantity, symbol_position, symbol) = __remove_and_store_symbol(quantity)

    assert output_quantity == expected_quantity
    assert symbol_position == expected_symbol_position
    assert symbol == expected_symbol


@pytest.mark.parametrize('master_data, program_output, program_output_single_line', [
    (
        {
            'pff': {
                'objects': [
                    {
                        "description": "Beneficiaries directly served",
                        "quantity": 1000,
                        "verb": "directly serve",
                        "targetPlural": "beneficiaries",
                        "targetSingular": "beneficiary",

                    },
                    {
                        "description": "Alpacas flying",
                        "quantity": 1,
                        "verb": "flying",
                        "targetPlural": "alpacas",
                        "targetSingular": "alpaca"
                    },
                    {
                        "description": "Dogs sitting",
                        "quantity": 924,
                        "verb": "sitting",
                        "targetPlural": "dogs",
                        "targetSingular": "dog"
                    }
                ]
            }
        },
        ['directly serve 1,000 beneficiaries', 'flying 1 alpaca', 'sitting 924 dogs'],
        'directly serve 1,000 beneficiaries, flying 1 alpaca and sitting 924 dogs'
    ),
    (
        {
            'pff': {
                'objects': [
                    {
                        "description": "Alpacas flying",
                        "quantity": 1,
                        "verb": "flying",
                        "targetPlural": "alpacas",
                        "targetSingular": "alpaca"
                    },
                    {
                        "description": "Dogs sitting",
                        "quantity": 924,
                        "verb": "sitting",
                        "targetPlural": "dogs",
                        "targetSingular": "dog"
                    }
                ]
            }
        },
        ['flying 1 alpaca', 'sitting 924 dogs'],
        'flying 1 alpaca and sitting 924 dogs'
    ),
    (
        {
            'pff': {
                'objects': [
                    {
                        "description": "Alpacas flying",
                        "quantity": 1,
                        "verb": "flying",
                        "targetPlural": "alpacas",
                        "targetSingular": "alpaca"
                    },
                ]
            }
        },
        ['flying 1 alpaca'],
        'flying 1 alpaca'
    )
])
def test_program_impacts(monkeypatch, master_data, program_output, program_output_single_line):
    useful_data = dict()
    make_program_impacts(useful_data, master_data)

    assert useful_data['PROGRAM_OUTPUTS'] == program_output
    assert useful_data['PROGRAM_OUTPUTS_SINGLE_LINE'] == program_output_single_line


def test_sasb_data_overlap(monkeypatch):
    useful_data = dict()
    master_data = {
        'program': {
            'sasb': {
                'data': [ObjectId('5ced8752f231fc16de6d16a4'), ObjectId('5ced8752f231fc16de6d16a5'), ObjectId('5ced8752f231fc16de6d16a1')],
                'isCustom': False
            }
        },
        'customer': {
            'sasb': {
                'categories': {
                    'tagged': {
                        'ids': ['5ced8752f231fc16de6d16a1']
                    }
                }
            }
        },
        'client': {
            'sasb': {
                'categories': {
                    'tagged': {
                        'ids': ['5ced8752f231fc16de6d16a8']
                    }
                }
            }
        }
    }

    mock_sasb_data = mock.MagicMock()
    monkeypatch.setattr('matchmaking.controllers.deliverables.create_template_data.research_data.get_sasb_master', mock_sasb_data)
    mock_sasb_data.return_value = {
        "GHG Emissions": "SASB 110 - ",
        "Ecological Impacts": "SASB 160 - ",
        "Human Rights & Community Relations": "SASB 210 - ",
    }

    def mock_get_vocab_func(_id):
        mapping = {
            ObjectId('5ced8752f231fc16de6d16a4'): 'GHG Emissions',
            ObjectId('5ced8752f231fc16de6d16a5'): 'Ecological Impacts',
            ObjectId('5ced8752f231fc16de6d16a1'): 'Human Rights & Community Relations',
            ObjectId('5ced8752f231fc16de6d16a7'): 'Access and Affordability'
        }

        return mapping[_id]
    monkeypatch.setattr('matchmaking.controllers.deliverables.create_template_data.utils.get_vocabulary_label_v2', mock_get_vocab_func)

    make_sasb_data(useful_data, master_data)

    assert useful_data['SASB'] == ["SASB 110 - GHG Emissions", "SASB 160 - Ecological Impacts", "SASB 210 - Human Rights & Community Relations"]
    assert useful_data['SASB_CUSTOMER'] == ["SASB 210 - Human Rights & Community Relations"]
    assert useful_data['SASB_CLIENT'] == []


def test_esg_data_overlap(monkeypatch):
    useful_data = dict()
    master_data = {
        'program': {
            'esg': {
                'data': [
                    {
                        'issue': ObjectId('5a99921742073d0946343fdb')
                    },
                    {
                        'issue': ObjectId('5a99921742073d0946343fdd')
                    },
                    {
                        'issue': ObjectId('5a99921742073d0946343fe7')
                    },
                    {
                        'issue': ObjectId('5a99921742073d0946343ff4')
                    }
                ],
            },
        },
        'customer': {
            'msci': {
                'weights': {
                    'accessToCommunications': 0.0,
                    'accessToFinance': 11,
                    'carbonEmissions': 5,
                    'humanCapitalDevelopment': 21,
                    'climateChangeVulnerability': 0.0,
                    'responsibleInvestment': 0.0
                },
            }
        },
        'client': {
            'msci': {}
        }
    }

    def mock_get_vocab_func(_id):
        mapping = {
            ObjectId("5a99921742073d0946343fd3"): 'Access to Communications',
            ObjectId('5a99921742073d0946343fd4'): 'Access to Finance',
            ObjectId('5a99921742073d0946343fdb'): 'Carbon Emissions',
            ObjectId('5a99921742073d0946343fe7'): 'Human Capital Development',
            ObjectId('5a99921742073d0946343fdd'): 'Climate Change Vulnerability',
            ObjectId('5a99921742073d0946343ff4'): 'Responsible Investment',
        }

        return mapping[_id]
    monkeypatch.setattr('matchmaking.controllers.deliverables.create_template_data.utils.get_vocabulary_label_v2', mock_get_vocab_func)

    make_esg_data(useful_data, master_data)

    assert useful_data['ESG'] == ['Carbon Emissions', 'Climate Change Vulnerability', 'Human Capital Development', 'Responsible Investment']
    assert 'Carbon Emissions' in useful_data['ESG_CUSTOMER']
    assert 'Human Capital Development' in useful_data['ESG_CUSTOMER']
    assert useful_data['ESG_CLIENT'] == []