from marshmallow import Schema, fields

from portal.shared.custom_fields import ObjectIdField
from portal.shared.schema import AccountReferenceSchema, EntitySchema, OrderReferenceSchema, SearchRequestSchema, \
    SearchResponseSchema


class TransactionSageSchema(Schema):
    invoiceId = fields.String()
    invoiceRecordNo = fields.String()
    billRecordNumber = fields.String()
    billRecordNo = fields.String()


class TransactionStripeSchema(Schema):
    subscriptionId = fields.String()
    paymentIntentId = fields.String()
    invoiceId = fields.String()


class TransactionSchema(EntitySchema):
    """Transaction Model"""
    account = fields.Nested(AccountReferenceSchema, required=True)
    order = fields.Nested(OrderReferenceSchema)
    memo = fields.String(required=True)
    amount = fields.Float(required=True)
    startingBalance = fields.Float()
    endingBalance = fields.Float()
    currency = fields.String()
    sage = fields.Nested(TransactionSageSchema)
    stripe = fields.Nested(TransactionStripeSchema)


class TransactionRequest(TransactionSchema):
    """Request Model for POST Transaction request"""

    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy',
                   'lastUpdated', 'startingBalance', 'endingBalance', 'currency', 'sage', 'stripe')


class TransactionResponse(TransactionSchema):
    """Response Model for POST Transaction"""
    pass


class TransactionSearchRequest(SearchRequestSchema):
    """Request Model for GET Transaction request"""
    id = ObjectIdField(attribute='_id', allow_none=True)
    accountId = ObjectIdField(allow_none=True)
    createdAtFrom = fields.DateTime(allow_none=True)
    createdAtTo = fields.DateTime(allow_none=True)
    sageInvoiceId = fields.String(allow_none=True)
    memo = fields.String(allow_none=True)
    createdBy = fields.String(allow_none=True)
    amountFrom = fields.Float(allow_none=True)
    amountTo = fields.Float(allow_none=True)

    class Meta:
        contains_fields = ['sageInvoiceId', 'memo', 'createdBy']
        range_fields = ['createdAt', 'amount']

    def _convert_nested(self, key):
        if key == 'accountId':
            return 'account._id'
        return key


class TransactionSearchResponse(SearchResponseSchema):
    results = fields.List(fields.Nested(TransactionSchema))


class TransactionsMonthEndResponse(Schema):
    data = fields.Field()