import json
from faker import Faker
import pytest
from bson import ObjectId
from portal.features.instances.schema import InstanceSettingsSchema, InstanceSettingsSearchRequest
from portal.shared.dates import get_utcnow


class TestInstanceSettingsSearchRequest:

    def test_post_load_converts_fields(self):
        data = {
            'count': 10,
            'orderBy': 'name',
            'offset': 0
        }

        response = InstanceSettingsSearchRequest().load(data)

        assert response['orderBy'] == 'name'
