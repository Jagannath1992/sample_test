import requests

from flask import Blueprint, request
from os import environ

from app.db.database import get_db
from app.response import error_response
from app.validation.salesforce_auth_payload import validate_sf_auth_payload

salesforce_bp = Blueprint('sf', __name__)
PRIVATE_KEY = environ.get('PRIVATE_KEY', 'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl'
                                         '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')


"""
@api {post} /auth_payload Salesforce auth payload
@apiName Authorize
@apiGroup Authorize
@apiDescription Salesforce will create and transfer the auth payload of the relevant attributes to Givewith platform,
later we will use the payload to exchanged for a Access & Refresh token payload

@apiError 400 Bad request

@apiParam {Boolean} isSandbox Determines if this token belongs to login.salesforce (false), test.salesforce (true)
@apiParam {String} namespace Salesforce package namespace
@apiParam {String} instance_url The base URL of the customer's Salesforce org.
@apiParam {String} orgId The client's orgId
@apiParam {String} refreshToken The refresh token that will be passed to salesforce endpoint to obtain an access token.

@apiParamExample {json} Change password example:
{
    "isSandbox": true,
    "namespace": "isvqa",
    "instance_url": "https://appiphony.lightning.force.com",
    "orgId": "00D190000005ASg",
    "refreshToken": "5Aep861FCftfNVCpAwdlBpBMErWcMXsfcEkTFFlMartIwzLLfbQxns_JsieYhlbYTl9YHRGIkXhMc.kowlGSpwO"
}

"""
@salesforce_bp.route('/auth_payload', methods=['POST'])
def auth_payload():
    err = validate_sf_auth_payload()
    if err:
        return error_response(400, 'bad request', err)

    payload = request.get_json()
    get_db().salesforce_auth_payload.replace_one({'orgId': payload['orgId']}, payload, upsert=True)
    return 'success', 200,


@salesforce_bp.route('/access_token', methods=['GET'])
def access_token():
    payload = get_db().salesforce_auth_payload.find_one()
    if not payload:
        return error_response(400, 'auth payload not found')

    base_url = 'https://{env}.salesforce.com/services/oauth2/token?grant_type=refresh_token&client_id={client_id}&' \
               'client_secret={client_secret}&refresh_token={refreshToken}'

    if payload['isSandbox']:
        base_url = base_url.replace('{env}', 'test')
    else:
        base_url = base_url.replace('{env}', 'login')

    client_id = environ.get('sf_client_id', '3MVG9Nc1qcZ7BbZ1Hf40E0ajZzIqoT.MCP5LKsC0v6RVyiMxPV.'
                                            '2bK5nley9R0FPobpbw8orFZH4vWRGoFhAU')

    client_secret = environ.get('sf_client_secret', '073F39E1CE50640E00106498D8D1F2AE65C009931C4AF930A642DF03FB76B351')

    base_url = base_url.replace('{client_id}', client_id)
    base_url = base_url.replace('{client_secret}', client_secret)
    base_url = base_url.replace('{refreshToken}', payload['refreshToken'])

    r = requests.post(base_url)
    return r.json(), r.status_code


