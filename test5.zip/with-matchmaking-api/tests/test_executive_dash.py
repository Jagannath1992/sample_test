import json
import unittest.mock as mock
from matchmaking.service.email import NotificationEmail

def test_get_exec_dash_data(client, executive_client_header):
    response = client.get('/commerce/executive-dashboard', headers=executive_client_header)
    assert response.status_code == 200