from portal.shared.repositories import cause_area_repository, instance_settings_repository
from werkzeug.exceptions import BadRequest


class CauseAreaValidator:
    def __init__(self, cause_area_request: dict, prev_cause_area: dict = {}):
        self.cause_area_request = cause_area_request
        self.prev_cause_area = prev_cause_area

    def validate_cause_area_name(self):
        # Only validate if name is in the request
        if not 'name' in self.cause_area_request:
            return
        # Only validate if name is new/changed
        if self.cause_area_request.get('name') == self.prev_cause_area.get('name'):
            return

        if cause_area_repository().exists_by_filter({'name': self.cause_area_request['name']}):
            raise BadRequest(f'A cause area named {self.cause_area_request["name"]} already exists')

    def validate_cause_area_status(self):
        # Only validate if status is in the request
        if not 'active' in self.cause_area_request:
            return
        # Only validate if staus is changed
        if self.cause_area_request.get('active') == self.prev_cause_area.get('active'):
            return

        if self.cause_area_request.get('active') == False:
            instance_settings_repository().populate_cause_area_instance_counts([self.prev_cause_area])
            instance_cnt = self.prev_cause_area.pop('instanceCount', 0)
            if instance_cnt > 0:
                raise BadRequest('A cause area associated with an instance cannot be deactivated')

    def validate_image_names(self):
        if not self.cause_area_request.get('detailImageName', None):
            self.cause_area_request['detailImageName'] = self.cause_area_request['listImageName']
