from werkzeug.urls import url_encode
from flask import request
from flask import jsonify
from flask_restful import Resource, abort

from app.db.utils import get_document_by_id, list_documents
from app.validation.utils import validate_object_id
from app.utils import api
from app.utils.auth import authenticate


class Brand(Resource):
    @authenticate
    def get(self, brand_id):
        if not validate_object_id(brand_id, 'mm_brands'):
            abort(404, message='brand not found')

        return jsonify(get_document_by_id('mm_brands', brand_id))


class Brands(Resource):
    @authenticate
    def get(self):
        return jsonify(list_documents('mm_brands'))

    @authenticate
    def post(self):
        req = request.get_json(force=True)
        if 'name' not in req:
            abort(400, message='name is required')

        if 'industry' not in req:
            abort(400, message='industry is required')

        brand = {
            'name': req.get('name'),
            'industry': req.get('industry'),
            'source': 'CUSTOMER',
            'preferredPrograms': {
                'editing': False,
                'cart': [],
                'selected': [],
                'additional': []
            }

        }
        return api.post_mm_api('/admin/brands', brand)


class BrandSearch(Resource):
    @authenticate
    def get(self):
        query = url_encode({'query': request.args['q'], 'limit': 50, 'offset': 0, 'sasb': 'true', 'sales': 'true'})
        return api.get_mm_api(f'/matchmaking/brands/search?{query}')
