# -*- coding: utf-8 -*-
from bson import ObjectId
from bson.errors import InvalidId
from copy import deepcopy
from flask import jsonify, request, current_app
from pymongo import ReturnDocument
from pymongo.collation import Collation, CollationStrength
from ..commerce.deal import get_nonprofit_by_id
from ..commerce.utils import get_user_by_id
from ...controllers.commerce.data_triggers import trigger_program_tagging
from ...controllers import admin_bp
from ...models.models import v, PROGRAM_SURVEY_MAP, schema_program_v2, survey_model, schema_survey
from ...mongodb import db, create_ref, get_is_valid_nonprofit
from ...permission_decorator import require_admin_permission
from ...utils import (set_last_updated, set_created_at, get_locale_string, get_deep_diff, get_descendant_key,
                      EntityNotFound, GivewithError, UnsupportedId, UnsupportedPayload, ValidationError, send_loggly,
                      generate_random_slug, remove_empty, SurveyStatus, is_empty, convert_program_to_survey)


entity_name = 'survey'
target_collection = 'surveys'

class IdNone:
    id = None


@admin_bp.route('/surveys', methods=['GET'])
@require_admin_permission
def admin_list_surveys():
    surveys = list(db().coll_surveys.find(request.filter_params, projection={'_id': True,
                                                      'nonprofit': True,
                                                      'submissionFormName': True,
                                                      'nonprofitSlug': True,
                                                      'slug': True,
                                                      'status': True,
                                                      'percentComplete': True,
                                                      'editing': True,
                                                      'givewithAdmin': True,
                                                      }).skip(request.skip).limit(request.page_size)
                                                      .sort(request.sort_params)
                                                      .collation(Collation(locale=get_locale_string(), numericOrdering=True)))

    if not surveys:
        raise EntityNotFound(entity_name)

    for survey in surveys:
        survey['nonprofitName'] = get_nonprofit_by_id(survey.get('nonprofit', None)).get('general', {}).get('name', {}).get('publicOrganizationName', None)
        user = get_user_by_id(survey.get('givewithAdmin'))
        if user:
            full_name = user.get('first_name', '') + ' ' + user.get('last_name', '')
            survey['adminName'] = full_name.strip() or user.get('name', '')

    return jsonify({
        'surveys': surveys})

@admin_bp.route('/surveys', methods=['POST'])
@require_admin_permission
def insert_survey():
    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    document.pop('_id', None)
    document['slug'] = generate_random_slug()
    nonprofit_id = document['nonprofit']
    nonprofit = db().coll_nonprofits.find_one({'_id': ObjectId(nonprofit_id)})
    document['nonprofitSlug'] = nonprofit['slug']
    document['percentComplete'] = 0
    document['Finance'] = {}
    document['Finance']['currency'] = nonprofit['operationalInformation']['yearlyBudgetCurrency']

    if 'status' not in document:
        document['status'] = str(SurveyStatus.IN_PROGRESS)

    document['isValid'] = v.validate(document, schema_survey)

    if v.errors:
        current_app.logger.warning('Survey validation error: %s', v.errors)

    document = v.normalized(document, schema_survey)

    if v.errors:
        raise ValidationError(v.errors)

    inserted_id = db().coll_surveys.insert_one(set_created_at(document)).inserted_id
    document['_id'] = inserted_id


    return jsonify(document)


@admin_bp.route('/surveys/<id>', methods=['GET'])
@require_admin_permission
def admin_get_survey_by_id(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)
    survey = db().coll_surveys.find_one({'_id': obj_id})

    if not survey:
        raise EntityNotFound(entity_name, id)

    valid_status = v.validate(survey, schema_survey)
    if not valid_status and v.errors:
        survey['validation_errors'] = str(v.errors)

    survey['nonprofitName'] = get_nonprofit_by_id(survey.get('nonprofit')).get('general', {}).get('name', {}).get('publicOrganizationName', None)

    # if program associated with PSF and PSF in submitted status, find diff
    if survey['status'] == str(SurveyStatus.SUBMITTED) and survey.get('programId'):
        program = db().coll_programs.find_one({'_id': survey['programId']})

        if program:
            clean_survey = v.normalized(survey, survey_model())
            clean_program = v.normalized(convert_program_to_survey({}, program), survey_model())

            survey['diff'] = get_deep_diff(clean_program, clean_survey)


    return jsonify(survey)


@admin_bp.route('/surveys/<id>', methods=['PATCH'])
@require_admin_permission
def patch_survey(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    program_id = document.get('programId')

    v.validate(document, schema_survey)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    if document['editing'] and program_id and document['status'] == str(SurveyStatus.APPROVED):
        program_document = db().coll_programs.find_one({'_id': ObjectId(program_id)})
        if program_document:
            document = convert_program_to_survey(document, program_document)

            send_loggly(
                f'ADMIN-PSF: EDITING TOGGLED "ON" ON FORM WITH ID: {document.get("_id")} '
                f'BY USER WITH ID: {request.user.get("_id")}'
            )

    if document['editing'] and document['status'] != str(SurveyStatus.IN_PROGRESS):
        document['status'] = str(SurveyStatus.IN_PROGRESS)

    schema = {**schema_survey, **survey_model()}
    document = v.normalized(document, schema)
    updated_document = db().coll_surveys.find_one_and_update(filter={'_id': obj_id},
                                                             update={'$set': set_last_updated(document)},
                                                             return_document=ReturnDocument.AFTER)

    # consistency check because when nothing updates, query returns None
    if not updated_document:
        updated_document = document

    return jsonify(updated_document)


@admin_bp.route('/surveys/<id>', methods=['DELETE'])
@require_admin_permission
def delete_survey(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_surveys.find_one_and_delete({'_id': obj_id})

    # if form has program associated with it, remove association
    if deleted_document:
        send_loggly(
            f'ADMIN-PSF: FORM WITH ID: {deleted_document.get("_id")} DELETED '
            f'BY USER WITH ID: {request.user.get("_id")}'
        )

        program_id = deleted_document.get('programId')
        if program_id:
            db().coll_programs.find_one_and_update({'_id': program_id}, {'$unset': {'submissionFormId': ''}})

    return jsonify(deleted_document)


@admin_bp.route('/surveys/<id>', methods=['POST'])
@require_admin_permission
def convert_to_program(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    survey_document = db().coll_surveys.find_one({'_id': obj_id})

    if not survey_document:
        raise EntityNotFound(entity_name)

    status = survey_document.get('status')
    if status != str(SurveyStatus.SUBMITTED):
        raise GivewithError(f'Cannot create a program from a form with {status} status', code=400)

    # name/platform program name should be unique
    proposed_name = get_descendant_key(survey_document, PROGRAM_SURVEY_MAP['name'], None)
    collation = Collation(locale=get_locale_string(), strength=CollationStrength.PRIMARY) # case insensitive
    if db().coll_programs.count_documents({'name': proposed_name, 'submissionFormId': {'$ne': obj_id}},
                                          limit=1, collation=collation):
        raise GivewithError('A program with the same platform program name already exists')

    program_document = deepcopy(survey_document)

    program_document['submissionFormId'] = program_document.pop('_id')
    program_document['active'] = False
    program_document['version'] = 2

    # Set output values to proportional by default
    scale_id = db().map_label_to_id['proportional']
    outputs = get_descendant_key(program_document, 'StrategiesAndApproaches.outputs.value', [])
    for output in outputs:
        output.update({'scaleType': scale_id})

    # perform the field mappings using PROGRAM_SURVEY_MAP
    for program_key, survey_key in PROGRAM_SURVEY_MAP.items():
        data = get_descendant_key(program_document, survey_key, None)

        if not is_empty(data):
            program_document[program_key] = data

    # copy assets from old program if one exists
    asset_fields = {'imagePortrait': True, 'imageLandscape': True, 'previewImage': True, 'vimeoID': True, 'deliverables': True, '_id': False}
    program_assets = db().coll_programs.find_one(filter={'submissionFormId': obj_id}, projection=asset_fields)

    if program_assets:
        program_document.update(program_assets)

    approach_ids = program_document.pop('approach')
    program_document['approach'] = []
    for _id in approach_ids:
        program_document['approach'].append({'_id': _id})

    # normalize should remove unknown keys by default, therefore no need to pop the keys pulled
    program_document = v.normalized(program_document, schema_program_v2)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    remove_empty(program_document)

    # update = True to ignore required fields
    v.validate(program_document, schema_program_v2, update=True)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    program_document['isValid'] = True

    try:
        nonprofit_id = ObjectId(program_document['nonprofit'])
        program_document['nonprofit'] = create_ref(nonprofit_id)
        program_document['isValidNonprofit'] = get_is_valid_nonprofit([nonprofit_id])
    except KeyError:
        pass  # ignore

    inserted_document = db().coll_programs.find_one_and_replace(filter={'submissionFormId': obj_id},
                                                                replacement=set_created_at(program_document),
                                                                return_document=ReturnDocument.AFTER,
                                                                upsert=True)
    if not inserted_document:
        raise GivewithError(f'Unable to convert form with id {obj_id} to a program', code=500)

    send_loggly(
        f'ADMIN-PSF: FORM WITH ID: {inserted_document.get("_id")} APPROVED BY '
        f'BY USER WITH ID: {request.user.get("_id")}'
    )

    program_id = inserted_document.get('_id')

    try:
        trigger_program_tagging(program_id)
    except Exception as e:
        send_loggly('error tagging program: ' + str(e))

    survey_updates = {
        'programId': program_id,
        'status': str(SurveyStatus.APPROVED)
    }

    updated_document = db().coll_surveys.find_one_and_update(filter={'_id': obj_id},
                                                             update={'$set': set_last_updated(survey_updates)},
                                                             return_document=ReturnDocument.AFTER)


    if not updated_document:
        updated_document = survey_document
        current_app.logger.warning('Unable to update form with id %s', str(obj_id))

    return jsonify(updated_document)

