import traceback
import io
from typing import Union, Set, List, Dict

from flask import jsonify, request
from flask_restful import Resource, abort
from bson.objectid import ObjectId
from docxtpl import DocxTemplate, R
from zipfile import ZipFile
import pymongo


from app.db.utils import add_document, update_document_by_id, get_documents, list_documents, aggregate_on, get_document
from app.validation.utils import validate_object_id, is_uri_valid
from app.validation.deal import validate_create_deal_request, validate_confirmation_pending_deal_request, validate_payment_pending_deal_request
from app.utils.utils import *
from app.utils.auth import authenticate
from app.service.program_recommendation import select_programs, get_deal_recommended_programs
from app.utils.token import get_user_from_token, get_role_by_department
from app.service import emails
from app.service.slack import send_new_deal_message
from app.utils.singular_converter import form_program_output
from app.service.s3 import does_file_exist
from app.utils.vocabulary import translate_to_topic
from app.utils.brand import get_brand_topic_labels_with_industry_fallback


class Deal(Resource):
    @authenticate
    def get(self, deal_id):
        """
        get deal by id
        """
        if not validate_object_id(deal_id, 'deals'):
            abort(404, message='Deal not found')

        deal = get_document_by_id('deals', deal_id)
        if deal.get('archived', False):
            abort(404, message='Deal not found')

        # only users that belong to the brand that’s the gwCustomer on that deal have access
        user = get_user_from_token()
        if str(user.get('orgId')) != str(deal.get('givewithCustomer')):
            abort(403, message='insufficient permission')

        deal = set_deal_details(deal)
        return jsonify(deal)

    @authenticate
    def delete(self, deal_id):
        """
        soft delete deal by id
        """
        if not validate_object_id(deal_id, 'deals'):
            abort(404, message='Deal not found')

        update_document_by_id('deals', deal_id, {'archived': True})
        return '', 204

    @authenticate
    def patch(self, deal_id):
        """
        patch deal by id
        """
        if not validate_object_id(deal_id, 'deals'):
            abort(404, message='Deal not found')

        deal = get_document_by_id('deals', deal_id)
        update = request.get_json(force=True)
        if update is not None:
            unset_fields = {}

            if 'transactionAmount' in update:

                if update['transactionAmount']: # not falsy value (0, '', None)
                    transaction_amount = update['transactionAmount']
                    give_percent = deal.get('givePercent', 2)
                    givewith_fee_percentage = calculate_givewith_fee_percentage(deal)
                    gw_portion, total_funding = calculate_give_portion(give_percent, transaction_amount, givewith_fee_percentage)
                    update['fundingAmount'] = total_funding
                    update['givewithPortion'] = gw_portion
                    update['totalBudget'] = transaction_amount
                else:
                    update['totalBudget'] = update['fundingAmount'] = update['givewithPortion'] = 0

                update.pop('transactionAmount')

            if 'selectedProgram' in update:

                if update['selectedProgram'] == '':
                    unset_fields = {'selectedProgram': ''}
                    update.pop('selectedProgram')
                else:
                    if not validate_object_id(update['selectedProgram'], 'mm_programs'):
                        abort(400, message='Selected program not found')

                    update['selectedProgram'] = ObjectId(update['selectedProgram'])

            deal = update_document_by_id('deals', deal_id, update, unset=unset_fields)

        deal = set_deal_details(deal)
        return jsonify(deal)


class DealProgramInfo(Resource):
    @authenticate
    def get(self, brand_id, program_id, deal_id):
        """
        zip program images and program description
        """

        if not validate_object_id(brand_id, 'mm_brands'):
            abort(404, message='Client brand not found')

        if not validate_object_id(program_id, 'mm_programs'):
            abort(404, message='Program not found')

        brand = get_document_by_id('mm_brands', brand_id)

        program = get_document_by_id('mm_programs', program_id)
        form_program_output(program['outputs'])

        nonprofit = get_document_by_id('mm_nonprofits', program.get('nonprofit'), projection={'_id': False,
                                                                                              'name': True})

        if ObjectId.is_valid(deal_id):
            deal = get_document_by_id('deals', deal_id, projection={'_id': False,
                                                                    'fundingAmount': True,
                                                                    'currency': True})
        else:
            deal = {
                'currency': 'USD',
                'fundingAmount': 50000,
                'hasDefaultFundingAmount': True,
            }

        return zip_program_details(brand, program, nonprofit, deal)


def get_program_data(brand, program, nonprofit, deal):
    past_supported_nonprofits = get_nonprofits_supported_in_brand_past_deals(brand.get('_id'))
    is_prev_supported_nonprofit = False
    if program.get('nonprofit') in past_supported_nonprofits:
        is_prev_supported_nonprofit = True

    transform_outputs_to_commerce_outputs_v2(program, deal.get('fundingAmount'), deal.get('currency'))
    program_outputs = []
    has_non_proportional_output = False
    for output in program.get('outputs', []):
        if len(program_outputs) < 2 and float(output.get('value', 0)) > 0:
            value = str(output.get('value'))
            desc = output.get('description', '')

            if output.get('scaleType', '').lower() != 'proportional':
                value = value + '*'
                has_non_proportional_output = True

            program_outputs.append(
                {
                    'value': value,
                    'description': desc,
                }
            )

    program_description = program.get('description', '')
    while '<br/>' in program_description:
        program_description = program_description.replace('<br/>', '\n')

    brand_topics = get_brand_topic_labels_with_industry_fallback(brand)
    theme_ids = program.pop('themes', {}).get('data', [])
    program_topics = {translate_to_topic(theme_id).get('label') for theme_id in theme_ids}
    topics = [topic for topic in brand_topics if topic in program_topics]

    program_data = {
        'PROGRAM_NAME': program.get('name'),
        'NONPROFIT_NAME': nonprofit.get('name'),
        'PROGRAM_DESCRIPTION': R(program_description),
        'BRAND_NAME': brand.get('nameLabel', brand.get('name', '')),
        'PREVIOUSLY_SUPPORTED': is_prev_supported_nonprofit,
        'OUTPUTS': program_outputs,
        'IS_DEFAULT_FUNDING_AMOUNT': deal.get('hasDefaultFundingAmount'),
        'HAS_NON_PROPORTIONAL_OUTPUT': has_non_proportional_output,
        'TOPICS': topics,
    }

    return program_data


def get_program_hero_images(program):
    """
    Get hero images for a given program
    """
    query = {
        'credits.program_id': str(program.get('_id')),
        # decrease number of documents return to be filtered by type below
        '$text': {'$search': '"Photo" "Hero" Horizontal Vertical'}
    }

    projection = {
        '_id': True,
        'tags': True,
        'media_s3': True,
        'thumbnail_s3': True,
    }
    documents = list(get_documents('simian_media', query, projection=projection))

    landscape = None
    portrait = None

    if documents:
        filtered_landscape = get_filtered_document(documents, ['horizontal', 'photo', 'hero'])
        filtered_portrait = get_filtered_document(documents, ['vertical', 'photo', 'hero'])

        if filtered_landscape:
            landscape = get_assets(filtered_landscape)
        if filtered_portrait:
            portrait = get_assets(filtered_portrait)

    if landscape is None:
        landscape = {
            'media': program.get('imageLandscape', '')
        }
    if portrait is None:
        portrait = {
            'media': program.get('imagePortrait', '')
        }

    return landscape, portrait


def zip_program_details(brand, program, nonprofit, deal):
    program_data = get_program_data(brand, program, nonprofit, deal)

    # populate doc file
    doc = DocxTemplate('./app/templates/TEMPLATE_program_info.docx')
    try:
        doc.render(program_data, autoescape=True)
    except Exception as e:
        current_app.logger.error(f'Error creating program details zip file - {str(e)}')
        abort(404, message='Error creating program zip file')

    hyphenate_program_name = '-'.join(program.get('name').split(' '))

    # create temporary directory and save all files in that folder to be later zipped
    with TemporaryDirectory() as tmpdir:
        program_detail_path = tmpdir + '/' + hyphenate_program_name + 'description.docx'
        doc.save(program_detail_path)

        landscape, portrait = get_program_hero_images(program)

        landscape_path = get_file_from_url(landscape.get('media'), 'imageLandscape.jpg', tmpdir).get('pathname')
        portrait_path = get_file_from_url(portrait.get('media'), 'imagePortrait.jpg', tmpdir).get('pathname')

        file_dict = [
            {
                'path': program_detail_path,
                'filename': hyphenate_program_name + '-description.docx'
            },
            {
                'path': landscape_path,
                'filename': hyphenate_program_name + '-landscape.jpg'
            },
            {
                'path': portrait_path,
                'filename': hyphenate_program_name + '-portrait.jpg'
            },
        ]

        data = io.BytesIO()
        with ZipFile(data, 'w') as z:
            for f in file_dict:
                z.write(f.get('path'), f.get('filename'))
        data.seek(0)

        at_filename = hyphenate_program_name + '-details.zip'
        zip_file = send_file(data, mimetype='application/zip', as_attachment=True, attachment_filename=at_filename)
        zip_file.headers['Access-Control-Expose-Headers'] = 'Content-Disposition' #explicitly expose header

        return zip_file


class DealList(Resource):
    @authenticate
    def get(self):
        """
        get deals
        """
        user = get_user_from_token()

        deals_query = {'type': 'sales', 'givewithCustomer': user.get('orgId'), 'archived': {'$ne': True}}

        # filter by test flag
        if user['type'].lower() != 'admin':
            deals_query['isTest'] = False

        deals = list_documents('deals', {'filter': deals_query})

        for d in deals:
            if 'selectedProgram' in d:
                program_id = str(d.get('selectedProgram'))
                program = get_document_by_id('mm_programs', program_id, projection={'_id': True, 'imagePortrait': True})
                d['selectedProgram'] = program

                client_id = d.get('client')
                client_brand = get_document_by_id('mm_brands', client_id)
                d['clientName'] = client_brand.get('nameLabel') or client_brand.get('name')

        deals = sorted(deals, key=lambda k: k.get('createdAt', None), reverse=True)

        return jsonify(deals)

    @authenticate
    def post(self):
        """
        create deal
        """
        # validate request
        req = request.get_json(force=True)

        user = get_user_from_token()
        user_department = user.get('departmentType', 'Other')
        customer_role = get_role_by_department(user_department)

        user_brand = get_document_by_id('mm_brands', user.get('orgId'))

        validation_errors = validate_create_deal_request(req, user_brand.get('paymentOption', 'payAsYouGo'))
        if len(validation_errors) > 0:
            abort(400, message=str(validation_errors))

        # create deal
        _id = ObjectId()
        deal = {
            '_id': _id,
            'slug': str(_id),
            'type': 'sales',
            'name': req.get('name'),
            'client': ObjectId(req['companyId']),
            'givewithCustomer': user.get('orgId'),
            'givewithCustomerUser': str(user.get('_id')),
            'splitGiveAmount': user_brand.get('splitGiveAmount', False),
            'givePercent': calculate_funding_percentage(user_brand),
            'createdAt': datetime.utcnow(),
            'lastUpdated': datetime.utcnow(),
            'createdBy': user.get('_id'),
            'status': 'PROGRAM_SELECTION_PENDING',
            'password': generate_password(),
            'archived': False,
            'altLicensingGivewithCustomer': req.get('altLicensingGivewithCustomer'),
            'deliverables': init_deliverables(),
            'reference': 0,
            'isValid': True,  # required for deal link
            'givewithCustomerRole': customer_role,
            'givewithCustomerEmails': [user.get('username')],
            'paymentOption': user_brand.get('paymentOption'),
            'givewithFeePercentage': user_brand.get('givewithFeePercentage', DEFAULT_GIVEWITH_FEE_PERCENTAGE),
            'salesforceProposalId': req.get('salesforceProposalId', ''),
            'salesforceOpportunityId': req.get('salesforceOpportunityId', ''),
        }

        if req.get('selectedProgram'):
             deal['selectedProgram'] = ObjectId(req.get('selectedProgram'))
             deal['status'] = 'CONFIRMATION_PENDING'

        # set isTest flag
        deal['isTest'] = set_is_test_flag(deal)

        transaction_amount = req.get('transactionAmount', 0)
        funding_amount = req.get('fundingAmount', 0)

        # payAsYouGo payment option type
        if transaction_amount:
            give_percent = deal['givePercent']
            givewith_fee_percentage = calculate_givewith_fee_percentage(deal)
            gw_portion, total_funding = calculate_give_portion(give_percent, transaction_amount, givewith_fee_percentage)

            deal['fundingAmount'] = funding_amount if funding_amount else total_funding
            deal['givewithPortion'] = gw_portion
            deal['totalBudget'] = transaction_amount
        elif funding_amount: # prePaid payment option type
            deal['fundingAmount'] = funding_amount

        if 'currency' in req:
            deal['currency'] = req.get('currency')
        if deal['name'] is None:
            date_str = datetime.utcnow().strftime('%m %Y')
            client_brand = get_document_by_id('mm_brands', req['companyId'])
            client_brand_name = client_brand.get('nameLabel') if client_brand.get('nameLabel') else client_brand.get('name')
            deal['name'] = f'{client_brand_name} - {date_str}'

        # carry brand manager to deal
        if 'givewithManager' in user_brand:
            deal['manager'] = user_brand.get('givewithManager', '')

        # recommendation
        try:
            recommended_programs = get_deal_recommended_programs(deal)
            current_app.logger.info(f'get recommended programs {recommended_programs} from algo service')
            selected_programs = select_programs(recommended_programs, limit=12)
            if selected_programs:
                deal['selectedRecommendedPrograms'] = selected_programs
        except Exception as e:
            current_app.logger.error(f'Error creating recommended program {str(e)}')
            current_app.logger.error(str(traceback.format_exc()))

        add_document('deals', deal)

        # send email notification
        emails.new_deal(deal)

        # send slack notification
        send_new_deal_message(deal)
        return deal, 201

class ConfirmationPendingDeal(Resource):
    """
    change deal status to CONFIRMATION_PENDING
    """
    @authenticate
    def post(self, deal_id):
        req = request.get_json(force=True)
        validation_errors = validate_confirmation_pending_deal_request(req, deal_id)

        if len(validation_errors) > 0:
            abort(400, message=str(validation_errors))

        update = {
            'status': 'CONFIRMATION_PENDING',
            'selectedProgram': ObjectId(req.get('selectedProgram')),
            'statusUpdatedAt': datetime.utcnow()
        }

        deal = update_document_by_id('deals', deal_id, update)
        emails.program_selected(deal)

        deal = set_deal_details(deal)
        return deal


class PaymentPendingDeal(Resource):
    """
    change deal status to PAYMENT_PENDING
    """
    @authenticate
    def post(self, deal_id):
        req = request.get_json(force=True)
        validation_errors = validate_payment_pending_deal_request(req, deal_id)

        if len(validation_errors) > 0:
            abort(400, message=str(validation_errors))

        user = get_user_from_token()
        update = {
            'status': 'PAYMENT_PENDING',
            'confirmation': {
                'confirmedAt': datetime.utcnow(),
                'confirmedBy': user.get('_id'),
            },
            'statusUpdatedAt': datetime.utcnow()
        }

        if 'currency' in req:
            update['currency'] = req['currency']

        if 'transactionAmount' in req:
            deal = get_document_by_id('deals', deal_id, projection=['givePercent'])

            transaction_amount = req.get('transactionAmount')
            give_percent = deal.get('givePercent', 2)
            givewith_fee_percentage = calculate_givewith_fee_percentage(deal)
            gw_portion, total_funding = calculate_give_portion(give_percent, transaction_amount, givewith_fee_percentage)
            update['totalBudget'] = transaction_amount
            update['givewithPortion'] = gw_portion
            update['fundingAmount'] = total_funding

        if 'fundingAmount' in req:
            update['fundingAmount'] = req.get('fundingAmount')

        deal = update_document_by_id('deals', deal_id, update)

        deal = set_deal_details(deal)
        return deal


class PotentialDeal(Resource):
    """
       Get a potential deal data
       Primarily program recommendations for a potential deal between request user and client with client_id
       i.e what a deal between user and client_id would look like based on an estimated funding amount
    """
    @authenticate
    def get(self, client_id):
        if not validate_object_id(client_id, 'mm_brands'):
            abort(404, message='brand not found')

        user = get_user_from_token()
        potential_deal = {
            'givewithCustomer': user['orgId'],
            'client': client_id,
            # estimated potential funding info
            'currency': 'USD',
            'fundingAmount': 50000,
        }

        client_brand = get_document_by_id('mm_brands', client_id, projection=['topics', 'industry'])
        client_topics = get_brand_topic_labels_with_industry_fallback(client_brand)

        recommended_programs = select_programs(get_deal_recommended_programs(potential_deal), limit=6)
        potential_deal['recommendedPrograms'] = transform_recommended_programs(
            recommended_programs,
            **{'topics': client_topics, **potential_deal}
        )

        return potential_deal


PROGRAM_PROJECTION = {
    'imagePortrait': True,
    'outputs': True,
    'name': True,
    'nonprofit': True,
    'themes': True,
    'budget': True,
    'currency': True,
    'outcomes': True,
    'slug': True
}


def set_deal_details(deal):
    # add client brand industries
    client_id = deal.get('client')
    client_brand = get_document_by_id('mm_brands', client_id, projection=[
        'industry', 'name', 'nameLabel', 'source', 'topics'
    ])

    deal['industry'] = client_brand.get('industry')
    deal['clientName'] = client_brand.get('nameLabel') or client_brand.get('name')
    deal['clientSource'] = client_brand.get('source', '')

    # add customer
    user = get_user_from_token()
    customer = get_document_by_id('mm_brands', user.get('orgId'))
    deal['givewithCustomerName'] = customer.get('nameLabel') or customer.get('name')

    # get client brand topics
    client_topics = get_brand_topic_labels_with_industry_fallback(client_brand)
    deal['topics'] = client_topics

    # add details for recommended programs
    deal['selectedRecommendedPrograms'] = transform_recommended_programs(
        deal.get('selectedRecommendedPrograms', []),
        **deal,
    )

    # add details for selected program
    if 'selectedProgram' in deal:
        program_id = str(deal.get('selectedProgram'))

        program = get_document_by_id('mm_programs', program_id, projection=PROGRAM_PROJECTION)
        nonprofit = get_document_by_id('mm_nonprofits', str(program.get('nonprofit')))
        program['nonprofitName'] = nonprofit.get('name')

        # calculate outputs
        transform_outputs_to_commerce_outputs_v2(program, deal.get('fundingAmount'), deal.get('currency'))

        if deal.get('status') == 'COMPLETE':
            funding_form = get_document(
                'program_funding_forms',
                query={'deal': ObjectId(deal['_id']), 'status': {'$in': ['APPROVED', 'EXECUTED']}},
                sort=[('lastUpdated', pymongo.DESCENDING)],
                projection=['objects']
            )

            if funding_form:
                program['outputs'] = funding_form.get('objects', [])

        # set common topics with deal topics
        theme_ids = program.pop('themes', {}).get('data', [])
        program_topics = {translate_to_topic(theme_id).get('label') for theme_id in theme_ids}
        program['topics'] = [topic for topic in deal['topics'] if topic in program_topics]

        deal['selectedProgram'] = program

    # show assets if deal status is complete and assets are not expired
    if deal['status'] != 'COMPLETE':
        deal.pop('deliverables')

    elif deal['status'] == 'COMPLETE' and deal.get('statusUpdatedAt'):
        assets_expiration_date = deal['statusUpdatedAt'] + timedelta(days=365)
        if assets_expiration_date < datetime.utcnow():
            deal.pop('deliverables')
            deal['assetsExpiredOn'] = assets_expiration_date

    return deal


def transform_recommended_programs(programs: List[Dict], **kwargs) -> List[Dict]:
    client_brand_topics = kwargs.get('topics', [])
    funding_amount = kwargs.get('fundingAmount', 0)
    currency = kwargs.get('currency', 'USD')
    past_supported_nonprofits = get_nonprofits_supported_in_brand_past_deals(kwargs.get('client'))

    def _transform(_program):
        program = _program.copy()
        program.update(get_document_by_id('mm_programs', program.get('_id'), projection=PROGRAM_PROJECTION))

        if program.get('nonprofit') in past_supported_nonprofits:
            program['isPreviouslySupportedNonprofit'] = True

        if 'nonprofitName' not in program:
            nonprofit = get_document_by_id('mm_nonprofits', program.get('nonprofit'), projection={'name': True})
            program['nonprofitName'] = nonprofit and nonprofit['name']

        # get overlap topics between client brand and program only
        theme_ids = program.pop('themes', {}).get('data', [])
        program_topics = {translate_to_topic(theme_id).get('label') for theme_id in theme_ids}
        program['topics'] = [topic for topic in client_brand_topics if topic in program_topics]

        # calculate outputs
        transform_outputs_to_commerce_outputs_v2(program, funding_amount, currency)

        return program

    return list(map(_transform, programs))


def get_nonprofits_supported_in_brand_past_deals(brand_id: Union[ObjectId, str]) -> Set[ObjectId]:
    """Returns list of nonprofits brand_id has supported in past deals
    """
    brand_id = ObjectId(brand_id)
    pipeline = [
        {'$match': {'$or': [{'givewithCustomer': brand_id}, {'client': brand_id}], 'status': 'COMPLETE'}},
        {'$lookup': {'from': 'mm_programs', 'localField': 'selectedProgram', 'foreignField': '_id', 'as': 'program'}},
        {'$project': {'nonprofitId': {'$arrayElemAt': ['$program.nonprofit', 0]}}}
    ]

    return {item.get('nonprofitId') for item in aggregate_on('deals', pipeline)} # use set to de-duplicate


class SelectDealAsset(Resource):
    """
    save user asset selection on deal
    """
    @authenticate
    def post(self, deal_id):
        data = request.get_json()
        asset_type = data.get('type', '').lower()
        asset_url = data.get('url')

        valid_asset_types = {'photo', 'video'}
        if asset_type not in valid_asset_types:
            abort(400, description='Invalid type. Must be one of ' + ', '.join(valid_asset_types))

        if not (is_uri_valid(asset_url) and does_file_exist(asset_url)):
            abort(404, description=f'File not found: {asset_url}')

        validate_object_id(deal_id, 'deals')

        deliverables = get_document_by_id('deals', deal_id, projection={
            'deliverables.givewithCustomer.deliverables': True
        }).get('deliverables', {}).get('givewithCustomer', {}).get('deliverables', [])

        user_id = get_user_from_token().get('_id')
        for asset_item in deliverables:
            photo_match = asset_item['name'] == 'Photos' and asset_type == 'photo'
            video_match = asset_item['name'] == 'ShortFormVideo' and asset_type == 'video'

            if photo_match or video_match:
                asset_item.setdefault('userSelections', {}).update({str(user_id): asset_url})
                break

        update_document_by_id('deals', deal_id, {
            'deliverables.givewithCustomer.deliverables': deliverables
        }, upsert=False)

        return '', 204


def set_is_test_flag(deal):
    """
    When creating a deal, if the Givewith Customer User assigned to the deal is an Admin, set isTest flag to true.
    If the Givewith Customer User assigned to the deal is a Client (aka not an Admin), set isTest flag to false.
    :param deal:
    :return: isTest flag
    """
    if 'givewithCustomerUser' not in deal:
        return True

    if not ObjectId.is_valid(deal.get('givewithCustomerUser')):
        return True

    customer = get_document_by_id('user', deal['givewithCustomerUser'])
    return customer is None or customer.get('type', '') == 'admin'

