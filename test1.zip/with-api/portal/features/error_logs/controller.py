from flask import request
from flask_restx import Namespace, Resource
from flask_accepts import accepts, responds
from werkzeug.exceptions import NotFound
from portal.features.error_logs.schema import ErrorLogRequest, ErrorLogResponse, ErrorLogSearchRequest, ErrorLogSearchResponse
from portal.shared.auth.requests import role_required
from portal.shared.enums import UserRole
from portal.shared.repositories import error_log_repository

namespace = Namespace('error-logs', description='Error Logs related operations')


@namespace.route('')
class ErrorLog(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(query_params_schema=ErrorLogSearchRequest, api=namespace)
    @responds(schema=ErrorLogSearchResponse, api=namespace)
    def get(self):
        """Search Error Logs"""
        params = request.parsed_query_params
        totalCount, error_logs = error_log_repository().get_page(params)
        return {'totalCount': totalCount, 'results': error_logs}


@namespace.route('/<string:id>')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Error log not found'
    })
class ErrorLogById(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @responds(schema=ErrorLogResponse, api=namespace)
    def get(self, id: str):
        """Get Error Log by ID"""
        error_log = error_log_repository().get_single(id)
        if not error_log:
            raise NotFound('Error log not found')
        return error_log

    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS])
    @accepts(schema=ErrorLogRequest(partial=True), api=namespace)
    @responds(schema=ErrorLogResponse, api=namespace)
    def patch(self, id: str):
        self._validate_update(id)

        error_log = request.parsed_obj
        error_log_updated = error_log_repository().patch(id, error_log)
        return error_log_updated

    def _validate_update(self, error_log_id: str):
        if not error_log_repository().exists(error_log_id):
            raise NotFound('Error log not found')
