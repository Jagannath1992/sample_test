from matchmaking import db

db().coll_nonprofits.update_many({'registeredCountry': 'US'}, {'$set': {'registeredCountry': 'United States'}})

deals = list(db().coll_deals.find({'selectedRecommendedPrograms': {'$exists': True}}))
for deal in deals:
    for program in deal['selectedRecommendedPrograms']:
        if program.get('registeredCountry', 'US') == 'US':
            program['registeredCountry'] = 'United States'

    db().coll_deals.update_one({'_id': deal['_id']}, {'$set': deal})
