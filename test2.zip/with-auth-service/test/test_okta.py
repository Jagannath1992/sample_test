import json
import jwt


def test_auth(client, header, private_key):
    payload = {
        "grantType": "password",
        "username": "shanyan.jiang+20@givewith.com",
        "password": "TestPassword.123",
        "scope": "psf"
    }

    # test auth user
    response = client.post('/v1/okta/authorize', data=json.dumps(payload), headers=header)
    assert response.status_code == 200

    result = json.loads(response.data.decode())
    token = result.get('token')
    refresh_token = result.get('refresh_token')

    verify_token(token, private_key)

    # test refresh token in response is valid
    payload = {
        "grantType": "refresh_token",
        "refresh_token": refresh_token,
    }

    response = client.post('/v1/okta/authorize', data=json.dumps(payload), headers=header)
    assert response.status_code == 200

    result = json.loads(response.data.decode())
    new_token = result.get('access_token')
    verify_token(new_token, private_key)


def verify_token(token, private_key):
    payload = jwt.decode(token, private_key, algorithms='HS256')
    assert 'scope' in payload
    assert 'resource_ids' in payload
    assert 'version' in payload
    assert 'user_id' in payload
    assert 'subdomain' in payload
