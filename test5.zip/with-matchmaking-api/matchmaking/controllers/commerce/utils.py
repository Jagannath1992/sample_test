import math
from bson.errors import InvalidId
from matchmaking.util.forex import convert_to_usd
from ..matchmaking.brands.utils import (translate_to_id, get_themes_by_industry, filter_themes, get_csrhub_for_brand,
                                        get_tvl, get_gri)
from ...mongodb import (db, ObjectId, expand_vocabulary_label, is_brand_valid_for_deal, get_vocabulary_v2_by_type,
                        get_vocabulary, get_sdg_vocabulary_from_labels, get_nonprofit_names, translate_to_topic,
                        get_vocabulary_label_v2, get_vocabulary_v2, get_nonprofit)
from ...utils import EntityNotFound, GivewithError, natural_sort, get_descendant_key, dict_merge
from ...models.models import MSCI_COLUMN_TRANSLATE, Currency
from ...data_providers.nielsen import get_consumer_preferences_from_brand, get_target_demographics_from_brand

##### insights data source constants
CUSTOM = 'custom'
CSRIT = 'csrit'
BOTH = 'both'

#############  GETTERS  #############

def get_deal_test_flag(deal):
    """
    if the Givewith Customer User assigned to the deal is an Admin, set isTest: true on the deal, otherwise set to false (PLT-5591)
    """
    if 'givewithCustomerUser' not in deal:
        return True

    if not ObjectId.is_valid(deal.get('givewithCustomerUser')):
        return True

    customer = db().coll_user.find_one({'_id': ObjectId(deal.get('givewithCustomerUser'))})
    return customer is None or customer.get('type', '') == 'admin'


def get_brand_by_id(brand_id, **kwargs):
    brand = db().coll_brands.find_one(filter={'_id': ObjectId(brand_id)}, **kwargs)
    if not brand:
        raise EntityNotFound('brand', brand_id)

    return brand

def get_brand_by_name(brand_name, **kwargs):
    brand = db().coll_brands.find_one(filter={'name': brand_name}, **kwargs)
    if not brand:
        raise EntityNotFound('brand', brand_name)

    return brand

def get_brand_by_id_or_slug(id_or_slug, **kwargs):
    _filter = {}

    try:
        _filter['_id'] = ObjectId(id_or_slug)
    except InvalidId:
        _filter['slug'] = id_or_slug

    brand = db().coll_brands.find_one(filter=_filter, **kwargs)
    if not brand:
        raise EntityNotFound('brand', id_or_slug)

    return brand


def get_program_by_id(program_id, **kwargs):
    program = db().coll_programs.find_one(filter={'_id': ObjectId(program_id)}, **kwargs)
    if not program:
        raise EntityNotFound('program', program_id)

    return program


def get_program_by_id_or_slug(id_or_slug, **kwargs):
    _filter = {}

    try:
        _filter['_id'] = ObjectId(id_or_slug)
    except InvalidId:
        _filter['slug'] = id_or_slug

    program = db().coll_programs.find_one(filter=_filter, **kwargs)
    if not program:
        raise EntityNotFound('program', id_or_slug)

    return program


def get_nonprofit_by_id(nonprofit_id, **kwargs):
    nonprofit = db().coll_nonprofits.find_one(filter={'_id': ObjectId(nonprofit_id)}, **kwargs)
    if not nonprofit:
        raise EntityNotFound('nonprofit_id')

    return nonprofit


def find_program_in_deals(program_name, list_programs):
    for program in list_programs:
        if program['name'] == program_name:
            return program
    return {}

def is_program_funding_qualified(program_funding, program_currency, funding_amount, funding_currency):
    if program_funding:
        program_min_usd = convert_to_usd(program_funding, program_currency)
        funding_amount_usd = convert_to_usd(funding_amount, funding_currency)
        return program_min_usd <= funding_amount_usd

    return True

def get_related_qualified_programs(nonprofit_id, list_programs, funding_amount, funding_currency):
    related_programs = list(db().coll_programs.find(
        {'nonprofit': nonprofit_id,
         'isValid': True,
         'isValidNonprofit': True,
         'active': True},
        {'_id': False,
         'name': True,
         'imagePortrait': True,
         'slug': True,
         'minimumFunding': True,
         'currency': True}))

    if not related_programs:
        return []

    qualified_programs = [
        program for program in related_programs if is_program_funding_qualified(
            program.get('minimumFunding') or 0, program.get('currency') or 'USD',
            funding_amount, funding_currency)]

    for rel_program in qualified_programs:
        rec_program = find_program_in_deals(rel_program['name'], list_programs)
        rel_program['match'] = rec_program.get('match')

    return qualified_programs


def get_user_by_id(user_id, **kwargs):
    user = db().coll_user.find_one(filter={'_id': ObjectId(user_id)}, **kwargs)
    return user


def get_gw_customer_and_client_names(document, separate_labels=False):
    names_dict = {}

    gw_customer = lookup_by_fields(document, 'givewithCustomer', ['name', 'nameLabel'], get_brand_by_id)
    client = lookup_by_fields(document, 'client', ['name', 'nameLabel'], get_brand_by_id)
    if gw_customer:
        if separate_labels:
            names_dict['givewithCustomerNameLabel'] = gw_customer.get('nameLabel')
            names_dict['givewithCustomerName'] = gw_customer.get('name')
        else:
            names_dict['givewithCustomerName'] = gw_customer.get('nameLabel') or gw_customer.get('name')
    if client:
        if separate_labels:
            names_dict['clientNameLabel'] = client.get('nameLabel')
            names_dict['clientName'] = client.get('name')
        else:
            names_dict['clientName'] = client.get('nameLabel') or client.get('name')

    return names_dict

#############  END OF GETTERS  #############



#############  HELPERS  #############
def lookup_by_field(document, from_field, lookup_field, lookup_func):
    """
    Replace original objectId field from document with field value in lookup result
    This can trigger KeyError exception when from_field do not exists and when lookup_field do not exists
    on both cases we want to ignore error

    :param document: Base dict to replace field
    :param from_field: Field name to be replace
    :param lookup_field: Field name from lookup result to be placed on target field
    :param lookup_func: Function to lookup for result
    :return: lookup return
    """
    project_fields = {'_id': False, lookup_field: True}
    try:
        return lookup_func(document[from_field], **{'projection': project_fields})[lookup_field]
    except (KeyError, TypeError, GivewithError):
        pass


def lookup_by_fields(document, from_field, lookup_fields, lookup_func, exclude_id=True):
    project_fields = {'_id': False} if exclude_id else {}
    project_fields.update({key: True for key in lookup_fields})
    try:
        return lookup_func(
            document.get(from_field),
            **{'projection': project_fields})
    except (KeyError, GivewithError):
        return {}


def transform_program(program):
    try:
        original_program = get_program_by_id(program['_id'])
    except EntityNotFound:
        # If a program was erased from the DB and it has a dangling reference in the system
        # we should degrade gracefully ignoring the dangling reference at this point.
        return None

    program.update({
        'name': original_program['name'],
        'slug': original_program['slug'],
        'imagePortrait': original_program.get('imagePortrait'),
        'imageLandscape': original_program.get('imageLandscape'),
        'topics': list({translate_to_topic(_id=_id) for _id in original_program.get('themes', {}).get('data', [])})
    })

    return program


def check_deal_is_valid(document):
    is_gw_customer_valid_brand = is_brand_valid_for_deal(ObjectId(document.get('givewithCustomer', None)))
    is_client_valid_brand = is_brand_valid_for_deal(ObjectId(document.get('client', None)))

    has_funding_amount = bool(document.get('fundingAmount')) or (document.get('type') == 'sales')

    status = document.get('status')
    has_valid_status = status not in ['LOST', 'COMPLETED', None]

    return all([
        is_gw_customer_valid_brand, is_client_valid_brand,
        has_funding_amount, has_valid_status
    ])

def filter_zero_weights(esg_list):
    return [item for item in esg_list if item.get('weight', 0) > 0]


def filter_zero_relevancies(theme_list):
    return [item for item in theme_list if int(item.get('relevancy', 0) or item.get('themeRelevance', 0)) > 0]


def annotate_nonprofits_with_programs(nonprofit_ids):
    """Annotate which nonprofits have/do not have valid programs"""

    valid_nonprofit_ids = []
    for nonprofit_id in (nonprofit_ids or []):
        query = {'nonprofit': ObjectId(nonprofit_id), 'isValid': True, 'isValidNonprofit': True, 'active': True}
        nonprofit_name = get_nonprofit(ObjectId(nonprofit_id), projection={'name': True})
        valid_nonprofit_ids.append({
            'id': nonprofit_id,
            'name': nonprofit_name.get('name'),
            'validPrograms': db().coll_programs.find(query).count() > 0,
        })

    return valid_nonprofit_ids


def filter_esg(msci_data):
    if not msci_data:
        return []

    if msci_data.get('info'):
        visible_keys = [
            esg_key for esg_key in msci_data.get('info', {})
            if msci_data['info'][esg_key].get('visible')]
    else:
        visible_keys = [
            esg_key for esg_key in msci_data.get('score', {})
            if msci_data['score'].get(esg_key) or msci_data['weights'].get(esg_key)]

    # Filter to keys that have a translation.
    # The rest are not needed and are stored for future use
    visible_keys = [x for x in visible_keys if x in MSCI_COLUMN_TRANSLATE.keys()]

    return [format_msci(msci_data, esg_key) for esg_key in visible_keys]


def format_msci(msci_data, esg_key):
    esg_label = MSCI_COLUMN_TRANSLATE[esg_key]

    return {
        'issue': {
            '_id': translate_to_id(esg_label),
            'label': esg_label
        },
        'topic': translate_to_topic(_type='esg', label=esg_label),
        'score': msci_data.get('score', {}).get(esg_key, 0),
        'quartile': msci_data.get('quartile', {}).get(esg_key, 0),
        'weight': msci_data.get('weights', {}).get(esg_key, 0),
        'description': msci_data.get('info', {}).get(esg_key, {}).get('description', '')
    }


def get_insight_sasb(brand):
    if not brand.get('sasbVisibility', True):
        return None

    result = []
    for label in brand.get('sasb', {}).get('categories', {}).get('tagged', {}).get('labels', []):
        topic = translate_to_topic(_type='sasb', label=label)
        if topic:
            code = get_vocabulary_v2_by_type(_type='sasb', label=label).get('code')
            result.append({'label': label, 'code': code, 'topic': topic})

    return result


def format_insight_nielsen(nielsen_data, visible):
    if not visible:
        return None, None

    data = nielsen_data.get('data', {})
    base = {**data.pop('base', {}), 'source': nielsen_data.get('source')}

    result = []
    for key in data:
        result.append({**data[key], 'topic': translate_to_topic(_type='themes', label=key), 'label': key})

    return result, base


def format_insight_themes(theme_data):
    themes = []
    for theme in theme_data:
        if theme.get('themeVisibility', theme.get('visibility', True)):
            theme_vocab = get_vocabulary_v2_by_type(_type='themes', label=theme.get('theme'), match_lower=True)
            topic = theme_vocab.get('topic')
            if isinstance(topic, ObjectId):
                themes.append({
                    'label': theme_vocab.get('label'),
                    'topic': get_vocabulary_label_v2(topic),
                    'relevancy': theme.get('relevancy') or theme.get('themeRelevance'),
                    'narrative': theme.get('description') or theme.get('narrative'),
                    'source': theme.get('source'),
                    'impacts': [get_vocabulary_label_v2(x) for x in theme.get('impacts', [])],
                })
    return themes


def format_target_demographics(demographics_data):
    result = []
    for key in demographics_data:
        theme_vocab = get_vocabulary_v2(ObjectId(key))
        topic = theme_vocab.get('topic')

        if isinstance(topic, ObjectId):
            result.append({
                **demographics_data[key],
                'label': theme_vocab.get('label'),
                'topic': get_vocabulary_label_v2(topic),
            })

    return result


def get_insight_brand_themes(brand):
    """Get themes associated with a brand
        NOTE: Please read before making edits to this function
        (narratives as used here implies the theme's narrative/description key)

       themes = deduplicated array of the themes in researchCorpCommitments and customThemes matched by
       the theme label. Themes returned should either all have narratives or none should have a narrative, i.e
       if a brand has 10 themes and 5 out of 10 has a narrative, only surface the 5 with narratives.
       on the other hand, if a brand has 10 themes, each without a narrative, surface all 10 themes.

       themes in customThemes taken precedence over themes in researchCorpCommitments if the customTheme has a
       narrative
    """
    def split_themes_by_narrative(*themes):
        with_narratives = []
        without_narratives = []

        for theme in themes:
            if theme.get('description') or theme.get('narrative'):
                with_narratives.append(theme)
            else:
                without_narratives.append(theme)

        return with_narratives, without_narratives


    custom_themes = {theme['theme'].lower(): {**theme, 'source': CUSTOM} for theme in brand.get('customThemes', [])}
    research_themes = []

    # deduplicate and tag themes
    for research_theme in brand.get('researchCorpCommitments', {}).get('themes', []):
        theme = {**research_theme, 'source': CSRIT}
        theme_label = theme['theme'].lower()

        if theme_label in custom_themes:
            custom_theme = custom_themes.pop(theme_label)
            theme = {**custom_theme, 'source': BOTH} if custom_theme.get('description') else {**theme, 'source': BOTH}

        research_themes.append(theme)

    with_narratives, without_narratives = split_themes_by_narrative(*custom_themes.values(), *research_themes)

    return with_narratives or without_narratives


def get_insight_nonprofits(brand):
    research_nonprofits = brand.get('researchCorpCommitments', {}).get('nonprofits', {}).get('preferred', [])
    research_nonprofits_dict = {_id: CSRIT for _id in research_nonprofits}
    nonprofits_dict = {_id: CUSTOM for _id in brand.get('nonprofits', {}).get('preferred', [])}

    # deduplicate and re-tag as needed
    for key in nonprofits_dict:
        if key in research_nonprofits_dict:
            research_nonprofits_dict.pop(key)
            nonprofits_dict[key] = BOTH

    nonprofits_dict.update(research_nonprofits_dict)
    nonprofits = [{'label': x.get('name'), 'source': nonprofits_dict.get(x.get('id')), 'validPrograms': x.get('validPrograms')}
                  for x in annotate_nonprofits_with_programs(nonprofits_dict.keys())]
    return nonprofits


def _sort_natural(iterable):
    return list(sorted(iterable, key=lambda item: natural_sort(item['code'])))


def normalize_to_id(value, field_name):
    if isinstance(value, str):
        return db().map_type_label_to_id.get(f'{field_name}:{value.lower()}')
    return value


def format_metric_fields(brand_metrics, program_metrics):
    investor_reporting_fields = ['cdp', 'esg', 'gri', 'sdg']

    result_metrics = {}
    for field in investor_reporting_fields:
        brand_values = brand_metrics.get(field, {})
        program_values = program_metrics.get(field, {}).get('data', [])
        if field == 'esg':
            brand_msci = brand_metrics.get('msci', {})
            brand_values = filter_esg(brand_msci)
            brand_data = set(d['issue']['_id'] for d in brand_values if d.get('issue'))
            program_data = set(d.get('issue') for d in program_values if d.get('issue'))

            result_metrics[field] = [
                get_vocabulary(esg_id)
                for esg_id in list(brand_data & program_data)
            ]
        else:
            # this else statement surfaces sdgs and gris in the pdp that exist just on the program
            # NOT the overlap between brand and program
            program_data = {normalize_to_id(value, field) for value in program_values}
            result_metrics[field] = _sort_natural([get_vocabulary(_id) for _id in list(program_data)])

    return result_metrics

def math_output_values(program, funding_amount, field='outputs'):
    commerce_outputs = []
    for output in program.get(field, []):
        if 'value' in output or 'staticValue' in output:
            c_output = {
                'label': output.get('label', ''),
                'description': output.get('description', ''),
                'scaleType': output.get('scaleType', '')
            }

            expand_vocabulary_label(output)

            default_value = output.get('value', 0)

            if output['scaleType'].lower() == 'static':
                # TODO: one entry did not had valueFifty so I added a fallback that we need to check ??
                static_value = output.get('staticValue', None)
                c_output['value'] = static_value if static_value != None else output.get('valueFifty', default_value)
            elif output['scaleType'].lower() == 'proportional':
                try:
                    c_output['value'] = math.floor(funding_amount / output['value'])
                except ZeroDivisionError:
                    c_output['value'] = 0
            elif output['scaleType'].lower() == 'exponential':
                c_output['value'] = output.get('valueOneHundred', default_value)

            commerce_outputs.append(c_output)
    return commerce_outputs


def transform_custom_output(output):
    custom_output = {'isCustom': True, **output}

    if not custom_output.get('label', ''):
        custom_output['label'] = custom_output.pop('description', '')

    return custom_output


def calculate_commerce_outputs(program, funding_amount):
    outputs = math_output_values(
        program,
        funding_amount)

    customOutputs = math_output_values(
        program,
        funding_amount,
        field='customOutputs')

    # Merge customOutputs in outputs field
    outputs += [transform_custom_output(output) for output in customOutputs]
    program['outputs'] = outputs
    program.pop('customOutputs', '')


def transform_programs(programs, programs_map, invalid_reasons_to_include=set()):
    """Transform recommended programs by appending extra fields from the original program as well as the
    topic overlap and metric overlap between between the program and brand

    Also drops any invalid programs unless all of the program's invalid_reasons are in the parameter
    invalid_reasons_to_include
    """
    # fields for program
    program_fields = [
        'name',
        'slug',
        'nonprofit',
        'imagePortrait',
        'imageLandscape',
        'ImpactAndScope',
    ]

    transformed_programs = []
    for program in programs:
        p_dict = programs_map.get(program.get('_id'))

        if p_dict and (program['isValid'] or set(program['invalidReasons']).issubset(invalid_reasons_to_include)):
            # a shallow copy is okay since none of the existing fields are modified
            program_copy = {**program, **{field: p_dict[field] for field in program_fields if p_dict.get(field)}}

            program_copy['topics'] = list({translate_to_topic(_id=_id)
                                           for _id in p_dict.get('themes', {}).get('data', [])})

            sdg = []
            for _id in p_dict.get('sdg', {}).get('data', []):
                vocab = get_vocabulary_v2(_id)
                sdg.append({'code': vocab.get('code'), 'label': vocab.get('label'), '_id': _id})
            program_copy['sdg'] = sdg

            transformed_programs.append(program_copy)

    return transformed_programs

def transform_outputs_to_commerce_outputs_v2(outputs, budget, program_currency, funding_amount, funding_currency, isPFF=False):
    """ Calculate output values from output quantity, budget and proposal funding amount
        Each output_cost = program_budget / quantity, and hence output value = funding_amount / output_cost if
        the output scaleType is proportional
        Also, append outcomes to outputs to easy rendering by front-end
        NOTE: This function has side-effects (transforms outputs and removes outcomes)
    """

    # if currencies aren't equal, convert as needed
    if program_currency != funding_currency:
        funding_amount = convert_to_usd(funding_amount, funding_currency)
        budget = convert_to_usd(budget, program_currency)

    if budget:
        for output in outputs:
            expand_vocabulary_label(output, version=2)
            quantity = output.get('quantity', 0)

            if quantity and output.get('scaleType', '').lower() == 'proportional' and funding_amount:
                output_cost = budget / quantity
                output['value'] = math.floor(float(funding_amount) / float(output_cost))
                if isPFF:
                    output['quantity'] = math.floor(float(funding_amount) / float(output_cost))
            elif quantity: # value of static outputs is the quantity
                output['value'] = quantity


def slice_to_topics(data, data_type, label_param):
    result = {}
    for item in (data or []):
        topic = item.get('topic')
        label = get_descendant_key(item, label_param, '')
        if topic and isinstance(topic, list):
            for i in topic:
                result.setdefault(i, {}).setdefault(data_type, {}).update({label: item})
        elif topic:
            result.setdefault(topic, {}).setdefault(data_type, {}).update({label: item})

    return result


def get_brand_metrics(brand, include_meta=True):
    corp_comm = brand.get('researchCorpCommitments', {})

    msci_esg = filter_zero_weights(filter_esg(brand.get('msci', {})))
    sdg = get_sdg_vocabulary_from_labels(set(brand.get('sdg', []) + corp_comm.get('sdgLabels', [])))
    tvl, tvl_last_updated = get_tvl(brand)
    gri = get_gri()
    sasb = get_insight_sasb(brand)
    csrhub = [x for x in get_csrhub_for_brand(brand, include_topic=True) if isinstance(x, dict) and x.get('visible', True)]

    themes_by_industry = get_themes_by_industry(brand.get('industry'), include_id=True)
    global_themes = filter_themes(brand.get('themes', []), themes_by_industry, filter_visible=True)
    industry_themes = format_insight_themes(filter_zero_relevancies(global_themes))

    brand_themes = format_insight_themes(filter_zero_relevancies(get_insight_brand_themes(brand)))

    nonprofits = get_insight_nonprofits(brand)

    nielsen_visibility = not brand.get('hide_nielsen_customer_research')
    raw_consumer_pref = get_consumer_preferences_from_brand(brand, selected_themes=True)
    consumer_preferences, consumer_preferences_meta = format_insight_nielsen(raw_consumer_pref, nielsen_visibility)

    target_demographics = format_target_demographics(get_target_demographics_from_brand(brand))

    metrics = {
        'msci': msci_esg,
        'sdg': sdg,
        'industryInsights': industry_themes,
        'CSRCommitments': brand_themes,
        'tvl': tvl,
        'csrhub': csrhub,
        'gri': gri,
        'sasb': sasb,
        'targetAudiences': target_demographics,
        'consumerPreferences': consumer_preferences,
    }

    if include_meta:
        metrics['meta'] = {
            'consumerPreferences': consumer_preferences_meta,
            'nonprofits': nonprofits,
            'tvl': {'lastUpdated': tvl_last_updated}
        }

    return metrics

def get_insights(brand_or_id):
    if isinstance(brand_or_id, dict):
        brand = brand_or_id
    else:
        brand = get_brand_by_id(brand_or_id)

    metrics = get_brand_metrics(brand)

    ### Slice all the data to topics and merge onto insights_by_topics
    ordered_insights = {get_vocabulary_label_v2(ObjectId(topic_obj.get('topic'))): dict()
                        for topic_obj in brand.get('topics', [])}

    for key in metrics:
        if key != 'meta':
            label_key = 'issue.label' if key == 'msci' else 'label'
            dict_merge(ordered_insights, slice_to_topics(metrics[key], key, label_key), in_place=True)

    insights = {key: ordered_insights[key] for key in ordered_insights if ordered_insights[key]} # filter

    return {
        'insights': insights,
        'meta': {**metrics.get('meta', {}), 'topics': list(insights.keys())}
    }


def add_deliverables():
    customer_deliverable_names = [
        'SocialMediaPosts',
        'PressRelease',
        'CSRHighlight',
        'ESGReportingGuide_CUSTOMER',
        'InvestorRelations',
        'FactSheet',
        'Infographic',
        'Photos',
        'LongFormVideo',
        'ShortFormVideo',
    ]

    client_deliverable_names = [
        'SocialMediaPosts',
        'PressRelease',
        'CSRHighlight',
        'ESGReportingGuide_CLIENT',
        'InvestorRelations',
        'FactSheet',
        'Infographic',
        'Photos',
        'LongFormVideo',
        'ShortFormVideo',
    ]

    customer_deliverables = []
    client_deliverables = []

    for name in customer_deliverable_names:
        deliverable = {
            'name': name,
            'display': False,
        }
        customer_deliverables.append(deliverable)

    for name in client_deliverable_names:
        deliverable = {
            'name': name,
            'display': False,
        }
        client_deliverables.append(deliverable)

    return {
        'givewithCustomer': {
            'deliverables': customer_deliverables
        },
        'client': {
            'deliverables': client_deliverables
        }
    }

#############  END OF HELPERS  #############
