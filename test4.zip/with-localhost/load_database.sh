./read_local_envs.sh > env
source ./env
rm ./env

cd ../givewith-local-mongo
./export_data_from_staging.sh $STAGING_MONGO_PASS

