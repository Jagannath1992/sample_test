from pymongo import MongoClient

db = None

def initialize_db(app, test_db=None):
    global db

    if test_db is None:
        config = app.config
        client = MongoClient(config['MONGO_URL'])
        db = client.get_database(config['MONGO_DATABASE'])
    else:
        db = test_db


def get_db():
    return db
