import jwt
import functools
import werkzeug.exceptions as HTTPExceptions

from typing import Callable
from os import environ
from flask import request
from datetime import datetime
from flask_restful import abort
from keyczar import keyczar
from urllib.parse import urlparse

from app.db.utils import get_document_by_id, get_document, validate_existence
from config import send_loggly
from app.utils.utils import to_bool

from rbac_library.constants import Action
from rbac_library.enforcer import enforce


DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
TOKEN_PRIVATE_KEY = environ.get('TOKEN_PRIVATE_KEY',
                                'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl'
                                '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')
CRYPTER = keyczar.Crypter.Read('keys')


def _encrypt(raw):
    return CRYPTER.Encrypt(raw)


def _decrypt(encoded):
    return CRYPTER.Decrypt(encoded)


def create_keyczar_token(password_digest, uuid, expire_date):
    return _encrypt('/'.join((password_digest, uuid, expire_date)))


def authenticate(func):
    @functools.wraps(func)
    def wrapper(*args, **kws):
        token = request.headers.get('authorization')
        validate_jwt_token(token)
        return func(*args, **kws)

    return wrapper


def validate_token_against_collection(collection: str) -> Callable:
    """Returns a wrapper function that will validate
    a keyczar request token against the specified collection

    Args:
        collection (str): db collection name to validate token against

    Usage:
        validate_token_against_collection('supplier_analysis_reports')
        def put(slug):
            pass

        this will validate the Authorization token(from keyczar) against the specified collection
        using the `validate_keyczar_token` function
    """
    def _validate(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kws):
            request.slug = validate_keyczar_token(collection)
            return func(*args, **kws)

        return wrapper
    return _validate


def authenticate_with_one_of(*validators: Callable) -> Callable:
    """Authenticate request with one of several authentication wrappers.
    The first one to not throw an exception will be returned, otherwise the request will be aborted.
    Assumes that your authentication function can be used as a decorator and will throw an exception on errors

    Usage:
    @authenticate_with_one_of(authenticate, authenticate_with_keyczar_token...)
    def post(args):
      return True
    """
    def _authenticate(func):
        @functools.wraps(func)
        def wrapper(*args, **kws):
            for validator in validators:
                try:
                    return validator(func)(*args, **kws)
                except (HTTPExceptions.Unauthorized, HTTPExceptions.Forbidden): # 401, 403
                    continue

            abort(401)

        return wrapper
    return _authenticate


def validate_jwt_token(token):
    if token is None:
        abort(401, message='Token not found')
    try:
        claims = jwt.decode(token, TOKEN_PRIVATE_KEY, algorithms='HS256')
        user = get_document('user', {'username': claims['email']})
        if 'type' not in claims:
            user_type = user.get('type')
        else:
            user_type = claims['type']

        request.user = user
        if (user_type != 'admin') and (user_type != 'client'):
            abort(403, message='Admin user or client user only')

    except jwt.ExpiredSignatureError:
        abort(401, message='Expired token')
    except jwt.PyJWTError:
        abort(401, message='Invalid token')


def validate_keyczar_token(collection: str) -> str:
    """Decrypts a keyczar token and confirms that the slug and
    field_name(specified during the token creation phase)
    matches a valid entity in the specified `collection`

    Args:
        collection (str): db collection name

    Raises:
        GivewithError: Auth Error

    Returns:
        str: the decrypted slug
    """
    try:
        # decode the token
        token = request.headers['authorization']
        password, field_name, slug, expires = _decrypt(token).split('/')
    except KeyError:
        raise abort(403, message='Credentials not found')
    except Exception as e:
        send_loggly(f'Exception decrypting keyczar token: {e}')
        raise abort(401, message='Invalid Token')

    # prevent users logged in one link to access others
    current_slug = request.view_args.get('slug')
    if current_slug and current_slug != slug:
        raise abort(403, message='Invalid token for requested resource.')

    # validate expire date
    if datetime.utcnow() > datetime.strptime(expires, DATETIME_FORMAT):
        raise abort(401, message='Your token has expired.')

    # validate against specified collection
    if not validate_existence({'slug': slug, field_name: password}, collection):
        raise abort(403, message='Invalid token')

    return slug


def can(action: Action) -> Callable:
    """View Decorator to control access a resource

    Usage:
        @app.route('/', methods=['POST'])
        @can(Action.CREATE)
        def create_deals():
            return success, 200

    Args:
        action (Action): [The CRUD permission required to access the resource]
    """
    def rbac_validator(view_func: Callable) -> Callable:
        @functools.wraps(view_func)
        def v(*args, **kwargs):
            user_brand = get_document_by_id('mm_brands', request.user['orgId'], projection=['featureFlags.rbac'])
            user_brand_supports_rbac = user_brand.get('featureFlags', {}).get('rbac', False)

            hostname = urlparse(request.headers.get('Origin')).hostname or ''
            is_from_enforce_client = any(hostname.startswith(subdomain) for subdomain in ('metpolice', 'impact'))
            is_enforce_request = is_from_enforce_client or to_bool(request.headers.get('X-EnforcePermissions'))

            if user_brand_supports_rbac and is_enforce_request:
                if not enforce(str(action), request.user.get('roles', [])):
                    send_loggly(f'Unauthorized { action } at { str(request.path) } by { request.user["username"] }')
                    abort(403, message='You do not have the appropriate permission to perform this action.')

            return view_func(*args, **kwargs)

        return v
    return rbac_validator
