import pytest

from bson import ObjectId
from portal.features.suppliers.schema import SupplierSearchRequest


class TestSupplierSearchRequest:

    def test_post_load_converts_fields(self):
        data = {
            'count': 10,
            'orderBy': 'name',
            'offset': 0,
            'id': ObjectId(),
            'accountId': ObjectId(),
            'company': 'Company Name',
            'city': 'Address City',
            'state': 'Address State',
            'status': 'active',
            'type': 'default',
            'industry': 'test industry',
            'address': 'Address 1',
        }

        response = SupplierSearchRequest().load(data)

        assert response['company.name'].try_compile().match('Company Name')
        assert response['company.address.city'].try_compile().match('Address City')
        assert response['company.address.address1'].try_compile().match('Address 1')
        assert response['company.address.stateProvince'].try_compile().match('Address State')
        assert response['industry.displayLabel'].try_compile().match('test industry')
        assert response['accountId'] == data['accountId']
        assert response['_id'] == data['id']
