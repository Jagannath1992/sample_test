from faker import Faker
import pytest
from bson import ObjectId
from portal.features.locales.schema import LocaleSearchRequest, LocaleSchema
from portal.shared.dates import get_utcnow

from portal.features.accounts.schema import PutAccountActivateRequest, AccountSearchRequest


class TestLocaleSearchRequest:

    def test_post_load_converts_fields(self):
        data = {
            'count': 10,
            'orderBy': 'name',
            'offset': 0
        }

        response = LocaleSearchRequest().load(data)

        assert response['orderBy'] == 'name'


class TestLocaleSchema:

    def test_post_load_converts_fields(self, fakers):
        now = get_utcnow()
        data = fakers.locale.generate_new()
        response = LocaleSchema().load(data)
        assert response['name'] == data['name']
        assert response['settings']['regions'] == data['settings']['regions']
        assert type(response['settings']['regions']) == list
