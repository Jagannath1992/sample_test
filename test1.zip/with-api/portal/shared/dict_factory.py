def remove_none(data):
    return dict(x for x in data if x[1] is not None)
