# AIRFLOW DAGS
These are Airflow dags files. End of the day these files go into S3 bucket where AWS managed airflow can pick them up

In order to run these dags on local, you need to setup airflow on your local

# Some helpful links

https://airflow.apache.org/docs/apache-airflow/stable/howto/docker-compose/index.html

https://towardsdatascience.com/using-apache-airflow-dockeroperator-with-docker-compose-57d0217c8219

https://medium.com/@benjcabalonajr_56579/using-docker-operator-on-airflow-running-inside-a-docker-container-7df5286daaa5

https://onedevblog.com/how-to-fix-a-permission-denied-when-using-dockeroperator-in-airflow/


`
The default amount of memory available for Docker on macOS is often not enough to get Airflow up and running. If enough memory is not allocated, it might lead to the webserver continuously restarting. 
You should allocate at least 4GB memory for the Docker Engine (ideally 8GB).
You can check if you have enough memory by running this command:
docker run --rm "debian:bullseye-slim" bash -c 'numfmt --to iec $(echo $(($(getconf _PHYS_PAGES) * $(getconf PAGE_SIZE))))'
`

# BELOW ONLY APPLICABLE FOR LOCAL DEVELOPMENT
You need to pick up latest airflow docker-compose.yml file from airflow offical website and add below lines under "services" section

<pre>
docker-proxy:
    image: bobrik/socat
    command: "TCP4-LISTEN:2375,fork,reuseaddr UNIX-CONNECT:/var/run/docker.sock"
    ports:
      - "2376:2375"
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
</pre>

