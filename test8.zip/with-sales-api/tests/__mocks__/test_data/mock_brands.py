from bson.objectid import ObjectId

brands = [
    {
        '_id' : ObjectId('5fad58987cae51199d14525b'),
        'name' : 'daniel test brand',
        'source' : 'CUSTOMER',
        'preferredPrograms' : {
            'additional' : [],
            'cart' : [],
            'editing' : False,
            'selected' : []
        },
        'industry' : 'Biotechnology',
        'slug' : 'WSw6Wy8blZH1q0s',
        'isValidProgram' : False,
        'isValidNonprofit' : False,
        'hasAnalysis' : False,
        'sasbVisibility' : True,
        'nonprofits' : {
            'blacklist' : [],
            'preferred' : []
        },
        'sasb' : {},
        'nielsenDemographics' : [],
        'parent_brands' : [],
        'child_brands' : [],
        'iname' : 'daniel test brand',
        'searchString' : 'daniel test brand',
        'isValid' : True,
        'lastUpdatedBy' : {
            '_id' : ObjectId('5cb0a76b28386f7c5d65c9de'),
            'name' : 'Daniel Obeng',
            'username' : 'daniel.obeng@givewith.com'
        },
        'createdAt' : '2020-11-12T15:45:28.276Z',
        'lastUpdated' : '2020-11-12T15:46:17.154Z',
        'cdp' : [],
        'csrhub' : {},
        'customThemes' : [],
        'givePercentageCurrency' : 'USD',
        'givePercentageType' : 'default',
        'gri' : [],
        'hide_nielsen_customer_research' : False,
        'msci' : {
            'msciId' : 'MANUALdaniel test brand',
            'issuerName' : 'daniel test brand',
            'industry' : 'Packaged Foods & Meats',
            'lastImported' : '2020-11-12T15:46:14.091Z',
            'weights' : {},
            'score' : {},
            'quartile' : {}
        },
        'nielsen_selected_themes' : [],
        'sdg' : [],
        'themes' : [
            {
                'description' : '',
                'relevancy' : 20,
                'theme' : 'Animal welfare',
                'visible' : True
            },
            {
                'description' : '',
                'relevancy' : 20,
                'theme' : 'Environment',
                'visible' : True
            },
            {
                'description' : '',
                'relevancy' : 40,
                'theme' : 'Food and hunger',
                'visible' : True
            },
            {
                'description' : '',
                'relevancy' : 20,
                'theme' : 'Health and wellness',
                'visible' : True
            }
        ],
        'topics': [
            {
                "label" : "Animal welfare",
                "score" : 53.3218590801416,
                "topic" : ObjectId("5db31645c8beeecf128d7321")
            },
            {
                "label" : "Arts and culture",
                "score" : 43.234344,
                "topic" : ObjectId("5db31645c8beeecf128d7328")
            },
            {
                "label" : "Human rights and social justice",
                "score" : 26.3218590801416,
                "topic" : ObjectId("5db31645c8beeecf128d732b")
            },
        ],
        'verifiedByAdmin' : '2020-11-12T15:46:17.154Z'
    },
    {
        '_id' : ObjectId('5c1415685b03bb0008c21b06'),
        'name' : 'Elizabeth Brand',
        'source' : 'CUSTOMER',
        'preferredPrograms' : {
            'additional' : [],
            'cart' : [],
            'editing' : False,
            'selected' : []
        },
        'industry' : 'Biotechnology',
        'slug' : 'WSw6Wy8blZH1q0s',
        'isValidProgram' : False,
        'isValidNonprofit' : False,
        'hasAnalysis' : False,
        'sasbVisibility' : True,
        'nonprofits' : {
            'blacklist' : [],
            'preferred' : []
        },
        'sasb' : {},
        'nielsenDemographics' : [],
        'parent_brands' : [],
        'child_brands' : [],
        'iname' : 'daniel test brand',
        'searchString' : 'daniel test brand',
        'isValid' : True,
        'lastUpdatedBy' : {
            '_id' : ObjectId('5cb0a76b28386f7c5d65c9de'),
            'name' : 'Daniel Obeng',
            'username' : 'daniel.obeng@givewith.com'
        },
        'createdAt' : '2020-11-12T15:45:28.276Z',
        'lastUpdated' : '2020-11-12T15:46:17.154Z',
        'cdp' : [],
        'csrhub' : {},
        'customThemes' : [],
        'givePercentageCurrency' : 'USD',
        'givePercentageType' : 'default',
        'gri' : [],
        'hide_nielsen_customer_research' : False,
        'msci' : {
            'msciId' : 'MANUALdaniel test brand',
            'issuerName' : 'daniel test brand',
            'industry' : 'Packaged Foods & Meats',
            'lastImported' : '2020-11-12T15:46:14.091Z',
            'weights' : {},
            'score' : {},
            'quartile' : {}
        },
        'nielsen_selected_themes' : [],
        'sdg' : [],
        'themes' : [
            {
                'description' : '',
                'relevancy' : 20,
                'theme' : 'Animal welfare',
                'visible' : True
            },
            {
                'description' : '',
                'relevancy' : 20,
                'theme' : 'Environment',
                'visible' : True
            },
            {
                'description' : '',
                'relevancy' : 40,
                'theme' : 'Food and hunger',
                'visible' : True
            },
            {
                'description' : '',
                'relevancy' : 20,
                'theme' : 'Health and wellness',
                'visible' : True
            }
        ],
        'topics': [
            {
                "label" : "Animal welfare",
                "score" : 26.3218590801416,
                "topic" : ObjectId("5db31645c8beeecf128d7321")
            },
            {
                "label" : "Arts and culture",
                "score" : 26.3218590801416,
                "topic" : ObjectId("5db31645c8beeecf128d7328")
            },
            {
                "label" : "Human rights and social justice",
                "score" : 26.3218590801416,
                "topic" : ObjectId("5db31645c8beeecf128d732b")
            },
        ],
        'verifiedByAdmin' : '2020-11-12T15:46:17.154Z'
    }
]
