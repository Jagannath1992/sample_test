import jwt
import time
import copy
import re

from flask import jsonify, Blueprint, request
from os import environ
import os


from app.service import services
from app.response import error_response
from app.utils import JSONEncoder
from app.db.utils import get_document, update_document_by_id
from app.db.database import get_db
from app.validation.authorize import validate_login
from app.loggly import send_loggly
from app.rest.cognito_authorize import get_max_scope, validate_request_scope, \
    save_refresh_token, update_user_last_login
from datetime import datetime


okta_bp = Blueprint('okta', __name__)
PRIVATE_KEY = environ.get('PRIVATE_KEY', 'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl'
                                         '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9')
ENV = os.environ.get('ENV', '').lower()


env_to_subdomain_map = {
    "staging": "dev",
    "sandbox": "qa",
    "production": ""
}

department_type_to_application_map = {
    "Sales": "sellwith",
    "Procurement": "buywith"
}

USER_DEPT_TYPE = ["Sales","Procurement",'Portal']


"""
@api {post} /authorize Authorize User
@apiName Authorize
@apiGroup Authorize
@apiDescription Authorize a user or refresh token

@apiError 403 Insufficient permissions
@apiError 401 Incorrect username or password
@apiError 400 Bad request

@apiParam {String="password, refresh_token"} grantType the authorize grant type
@apiParam {String} username the user's name
@apiParam {String} password the user's password
@apiParam {String="admin, impact, psf"} scope the scope attempt to authorize
@apiParam {String} refresh_token the refresh token to authorize

@apiParamExample {json} Authenticate user example:
{
    "grantType": "password",
    "username": "user@givewith.com",
    "password": "test_password",
    "scope": "admin"
}

@apiParamExample {json} Authenticate refresh token example:
{
    "grantType": "refresh_token",
    "refresh_token": "eyJjdHkiOiJKV1QiLCJlbm....",
}

@apiSuccessExample {json} Success authorize user response example (without MFA):
{
    "expires": 3600,
    "refresh_token": "eyJjdHkiOiJKV1QiLCJlbmMiOiJBMjU2R0NNIiwiYWxnIjoiUl...",
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZGE3NTdkMi1m...",
    "token_type": "Bearer"
}

@apiSuccessExample {json} Success authorize user response example (with MFA):
{
    "username": "user@givewith.com"
    "state_token": "00rnP72tQQYuLE7eEtfez_sZN3Mb-pWouLiKpBm2EX",
    "pref_factor": "email"
}

@apiSuccessExample {json} Success authorize refresh token response example:
{
    "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZGE3NTdk...",
    "expires": 3600,
    "token_type": "Bearer"
}
"""
@okta_bp.route('/authorize', methods=['POST'])
def authorize():
    # validate request
    err = validate_login()
    if len(err) > 0:
        return error_response(400, 'bad request', err)
    
    grant_type = request.json.get('grantType')

    if grant_type in ["password","integration"]: 
        username = request.json.get('username')
        # load user from dbs
        user = get_db().user.find_one({'username': username})
                
        if user is None:
            return error_response(401, 'username %s not found' % username)
        
        if user.get('departmentType') in [None,'']:
            return error_response(401, 'The department of the user is blank.')
        
        if user.get('departmentType') not in USER_DEPT_TYPE:
            return error_response(401, 'The department of the user is not valid.') 

        sub_domain = get_sub_domain(user)
        
        # if sub_domain is None:
        #     return error_response(401, 'Sub-domain of the user must be scalewith.')
        
        if sub_domain=="UNDEFINED":
            return error_response(401, 'Sub-domain of the user is not defined in Instance settings.')

        if not user.get('active', False):
            return error_response(401, 'user %s is not active' % username)

    
    if grant_type == 'password':
        return authorize_user()

    if grant_type == 'refresh_token':
        return authorize_refresh_token()

    if grant_type == 'integration':
        return integrate_user()


def authorize_user():
    tokens = authorize_okta_user()

    if 'jwt_token' in tokens:
        user = tokens['user']
        username = tokens['username']
        jwt_token = tokens['jwt_token']
        refresh_token = tokens['refresh_token']
        max_scope = tokens['max_scope']

        save_refresh_token(user, refresh_token.decode(), max_scope, username)
        update_user_last_login(username)
        send_loggly("authorize_user: " + username + " SUCCESS")

        return jsonify({
            'token': jwt_token.decode(),
            'refresh_token': refresh_token.decode(),
            'token_type': 'Bearer',
            'ExpiresIn': 3600
        })
    
    if 'state_token' in tokens:
        return jsonify(tokens)
    
    
def authorize_refresh_token():
    refresh_token = str(request.json.get('refresh_token'))
    decoded_refresh_token = jwt.decode(refresh_token, PRIVATE_KEY, algorithms='HS256')
    if decoded_refresh_token["grant_type"] == 'integration':
        token_info = get_document('refresh_token_scope_integrations', {'refresh_token': refresh_token})
    else:
        token_info = get_document('refresh_token_scope', {'refresh_token': refresh_token})

    if token_info is None:
        return error_response(401, 'Invalid refresh token')

    user = get_document('user', {'username': token_info['username']})
    if user is None:
        return error_response(401, 'username %s not found' % token_info['username'])

    scope = token_info['scope']
    max_token = get_max_scope(user, scope)

    jwt_token = create_jwt_token(user, max_token)
    send_loggly("authorize_refresh_token " + user['username'] + " SUCCESS")

    return jsonify({
        'access_token': jwt_token.decode(),
        'token_type': 'Bearer',
        'expires': '3600'
    })

def integrate_user():
    tokens = authorize_okta_user()

    if 'jwt_token' in tokens:
        user = tokens['user']
        username = tokens['username']
        jwt_token = tokens['jwt_token']
        refresh_token = tokens['refresh_token']
        max_scope = tokens['max_scope']
        platform = request.json.get('platform')

        save_integration_refresh_token(user, refresh_token.decode(), max_scope, username, platform)
        send_loggly("integrate user " + username + "to platform " + platform + " SUCCESS")

        return jsonify({
            'token': jwt_token.decode(),
            'refresh_token': refresh_token.decode(),
            'token_type': 'Bearer',
            'ExpiresIn': 3600
        })
    
    if 'state_token' in tokens:
        return jsonify(tokens)

def create_jwt_token(user, max_scope):
    user_copy = copy.deepcopy(user)
    jwt_payload = {
        'token_use': 'access',
        'scope': max_scope,
        'auth_time': int(time.time()),
        'iat': int(time.time()),
        'iss': 'https://auth.givewith.com',
        'exp': int(time.time()) + 3600,
        'resource_ids': [str(user_copy['orgId'])],
        'version': 1.0,
        'user_id': str(user_copy['_id']),
        'email': str(user_copy['username']),
    }

    user_copy.pop('username', None)
    jwt_payload.update(user_copy)
    jwt_payload.pop('phoneNumber', None)
    jwt_payload.pop('notes', None)
    jwt_payload.pop('businessAddress', None)
    jwt_payload.pop('password', None)

    user_subdomain = get_sub_domain(jwt_payload)
    jwt_payload['subdomain'] = user_subdomain

    jwt_token = jwt.encode(jwt_payload, PRIVATE_KEY, algorithm='HS256', json_encoder=JSONEncoder.CustomJSONEncoder)
    return jwt_token

def create_refresh_token(user, max_scope):
    jwt_payload = {
        'token_use': 'refresh',
        'scope': max_scope,
        'auth_time': int(time.time()),
        'iat': int(time.time()),
        'iss': 'https://auth.givewith.com',
        'resource_ids': [str(user['orgId'])],
        'version': 1.0,
        'user_id': str(user['_id']),
        'email': str(user['username']),
        'subdomain': get_sub_domain(user),
        'grant_type': request.json.get('grantType')
    }

    refresh_token = jwt.encode(jwt_payload, PRIVATE_KEY, algorithm='HS256', json_encoder=JSONEncoder.CustomJSONEncoder)
    return refresh_token

def authorize_okta_user():
    """
    Authorize okta user
    """
    username = request.json.get('username')
    password = request.json.get('password')
    scope = request.json.get('scope')

    # check user
    user = get_document('user', {'username': username})
    if user is None:
        return 'username %s not found' % username, 401

    # check scope
    max_scope = get_max_scope(user, scope)
    if not validate_request_scope(user, scope):
        return error_response(403, 'insufficient permissions')

    # authenticate via okta service
    okta_service = services['okta']
    response = okta_service.authenticate(username, password)

    if response.status_code != 200:
        return response.json(), response.status_code

    # check if email was auto-enrolled upon log in
    check_email_factor(username)
    user = get_document('user', {'username': username})

    # if no MFA, generate auth tokens
    if 'sessionToken' in response.json():
        jwt_token = create_jwt_token(user, max_scope)
        refresh_token = create_refresh_token(user, max_scope)

        tokens = {
            'user': user,
            'username': username,
            'jwt_token': jwt_token,
            'refresh_token': refresh_token,
            'max_scope': max_scope
        }
    
    # if MFA enabled, tokens object contains info for MFA verification
    if 'stateToken' in response.json():
        # find user's active factors
        active_factors = []
        for factor in user['factors']:
            if factor['active'] is True:
                active_factors.append(factor)

        tokens = {
            'username': username,
            'state_token': response.json()['stateToken'],
            'pref_factor': get_preferred(user['factors']),
            'active_factors': active_factors
        }

    return tokens

def save_integration_refresh_token(user, refresh_token, scope, username, platform):
    get_db().refresh_token_scope_integrations.insert_one({'username': username, 'refresh_token': refresh_token,
                                             'scope': scope, 'resource_ids': [str(user['orgId'])],
                                             'platform': platform,
                                             'created_at': datetime.now()})


"""
@api {post} /authorize/mfa Verify MFA
@apiName Verify MFA
@apiGroup Okta
@apiDescription Verify MFA upon user login
                For sms/email, a challenge must be sent beforehand

@apiParamExample {json} Challenge example:
{
    "username": "user@givewith.com",
    "stateToken": "007ucIX7PATyn94hsHfOLVaXAmOBkKHWnOOLG43bsb",
    "method": "challenge"
}

@apiParamExample {json} Resend example:
{
    "username": "user@givewith.com",
    "stateToken": "007ucIX7PATyn94hsHfOLVaXAmOBkKHWnOOLG43bsb",
    "method": "resend"
}

@apiParamExample {json} Verify example:
{
    "username": "user@givewith.com",
    "stateToken": "007ucIX7PATyn94hsHfOLVaXAmOBkKHWnOOLG43bsb",
    "passcode": "175544",
    "method": "verify"
}
"""
@okta_bp.route('/authorize/mfa', methods=['POST'])
def mfa_verify():
    okta_service = services['okta']
    username = request.json.get('username')
    state_token = request.json.get('stateToken')
    method = request.json.get('method')
    factor_name = request.json.get('name')
    chosen_option = request.json.get('chosenOption')

    # look for user in DB
    user = get_document('user', {'username': username})
    if user is None:
        return 'user not found', 404
    
    # check whether the factor is being used for login or other operations
    if state_token is None:
        factor_id = None
        for factor in user['factors']:
            if chosen_option is not None and factor['name'] == chosen_option:
                factor_id = factor['id']
                break
            if factor['name'] == factor_name:
                factor_id = factor['id']
        
        if factor_id is None:
            return '%s factor not found' % factor_name, 404

        if method == 'challenge':
            response = okta_service.factor_verify(user['oktaId'], factor_id)
        elif method == 'verify':
            passcode = request.json.get('passcode')
            response = okta_service.factor_verify(user['oktaId'], factor_id, passcode)

        if response.status_code != 200:
            if response.status_code == 429 and response.json()['errorCode'] == 'E0000186':
                return 'SMS authentication currently unavaiable. ' \
                        'Please choose a different method from More Options.', response.status_code
            else:
                return response.json(), response.status_code
    
    else:
        # find preferred factor for MFA or default to given factor name
        if chosen_option is not None:
            factor = factor = get_preferred(user['factors'], default=chosen_option)
        elif factor_name is None:
            factor = get_preferred(user['factors'])
        else:
            factor = get_preferred(user['factors'], default=factor_name)

        if method == 'challenge':
            response = okta_service.mfa_verify(factor['id'], state_token)
        elif method == 'resend':
            response = okta_service.mfa_resend_verify(factor['id'], state_token)
        elif method == 'verify':
            passcode = request.json.get('passcode')
            response = okta_service.mfa_verify(factor['id'], state_token, passcode)

        if response.status_code != 200:
            if response.status_code == 429 and response.json()['errorCode'] == 'E0000186':
                return 'SMS authentication currently unavaiable. ' \
                        'Please choose a different method from More Options.', response.status_code
            else:
                return response.json(), response.status_code
        
        # generate auth and refresh tokens upon successful MFA verification
        if method == 'verify':
            scope = request.json.get('scope')
            max_scope = get_max_scope(user, scope)
            jwt_token = create_jwt_token(user, max_scope)
            refresh_token = create_refresh_token(user, max_scope)

            save_refresh_token(user, refresh_token.decode(), max_scope, username)
            update_user_last_login(username)
            send_loggly("authorize_user: " + username + " SUCCESS")

            tokens = {
                'token': jwt_token.decode(),
                'refresh_token': refresh_token.decode(),
                'token_type': 'Bearer',
                'ExpiresIn': 3600
            }

            return jsonify(tokens), 200

    return jsonify(response.json()), response.status_code

def get_preferred(factors, default=None):
    # Default to chosen factor if user has lost device
    if default is not None:
        for factor in factors:
            if factor['name'] == default:
                return factor

    # Check if user has set a preferred factor
    factor_types = {}
    for index, factor in enumerate(factors):
        if factor['preferred'] is True:
            return factor
        if factor['active'] is True:
            factor_types[factor['name']] = index
    
    # Choose available factor based on security level
    if 'GOOGLE' in factor_types:
        factor = factors[factor_types['GOOGLE']]
    elif 'OKTA' in factor_types:
        factor = factors[factor_types['OKTA']]
    elif 'sms' in factor_types:
        factor = factors[factor_types['sms']]
    elif 'email' in factor_types:
        factor = factors[factor_types['email']]

    return factor

def check_email_factor(username):
    """
    Check for the existence of email factor in DB and Okta and
    keep the DB factors list up to date with Okta's factors list
    """
    okta_service = services['okta']

    # look for user in DB
    user = get_document('user', {'username': username})
    if user is None:
        return 'user not found', 404

    for factor in user.get('factors', []):
        if factor['name'] == 'email':
            return

    okta_factors = okta_service.list_factors(user['oktaId'])
    for f in okta_factors.json():
        if f['factorType'] == 'email':
            email_factor = {
                'id': f['id'],
                'type': 'email',
                'provider': 'OKTA',
                'active': True,
                'name': 'email',
                'email': username,
                'preferred': True if len(okta_factors.json()) == 1 else False
            }

            factors_list = user.get('factors', []) + [email_factor]
            update_document_by_id('user', user['_id'], {'factors': factors_list})
            break

def get_sub_domain(jwt_payload):
    """
    Get brand sub domain from user
    """
    # get environment
    if not (ENV == 'staging' or ENV == 'production' or ENV == 'sandbox'):
        return ""

    department_type = jwt_payload['departmentType']
    if department_type in  ["Sales","Procurement"]:
        return combine_subdomain_application(env_to_subdomain_map.get(ENV), department_type_to_application_map.get(department_type))        
    elif department_type == 'Portal':
        portal_sub_domain = get_portal_user_subdomain(jwt_payload)
        return portal_sub_domain

def combine_subdomain_application(subdomain, application):
    # If subdomain since it could be empty for prod case.
    if subdomain:
        return f"{subdomain}.{application}"
    else:
        return application

def get_portal_user_subdomain(jwt_token):
    db = get_db()

    accountId = jwt_token['accountId']
    
    # Perform the lookup and join using MongoDB's aggregation pipeline
    result = db["account"].aggregate([
        # Lookup the account record by ObjectId
        {'$match': {'_id': accountId}},
        # Lookup the instance_settings record by joining on the instance._id field
        {'$lookup': {
            'from': 'instance_settings',
            'localField': 'instance._id',
            'foreignField': '_id',
            'as': 'instance_settings'
        }},
        # Unwind the instance_settings array
        {'$unwind': '$instance_settings'},
        # Project only the fields we care about
        {'$project': {'instance_settings': 1}}
    ])
    
    # Extract the instance settings record from the result
    instance_settings_record = result.next()['instance_settings']

    # extract domain from instance settings

    text = instance_settings_record.get('settings',{}).get('portalUrl')
    if ( text is not None and len(text) > 0 ) :
        match = re.search(r"https://(.+?)\.scalewith\.com", text)    
        portal_user_subdomain = None
        if match:
            portal_user_subdomain = match.group(1)
        return portal_user_subdomain
    else:
        portal_user_subdomain="UNDEFINED"
        return portal_user_subdomain


def get_user_platform(user):

    db = get_db()
    accountId = user['accountId']
    sellwith = 'SellWith'
    buywith = 'BuyWith'
    scalewith = 'ScaleWith'
    platform = ''
    localhost = 'localhost'

    # Perform the lookup and join using MongoDB's aggregation pipeline
    result = db["account"].aggregate([
        # Lookup the account record by ObjectId
        {'$match': {'_id': accountId}},
        # Lookup the instance_settings record by joining on the instance._id field
        {'$lookup': {
            'from': 'instance_settings',
            'localField': 'instance._id',
            'foreignField': '_id',
            'as': 'instance_settings'
        }},
        # Unwind the instance_settings array
        {'$unwind': '$instance_settings'},
        # Project only the fields we care about
        {'$project': {'instance_settings': 1}}
    ])

    # Extract the instance settings record from the result
    instance_settings_record = result.next()['instance_settings']
    text = instance_settings_record['settings']['portalUrl']
    # check to see if we are hitting localhost or valid portal url
    if localhost in text:
        platform = scalewith
    else:
        platform = sellwith if sellwith.lower() in text else buywith
    return platform
