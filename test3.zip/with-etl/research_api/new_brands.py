import concurrent.futures
from datetime import datetime
import Levenshtein
import pandas as pd
from pymongo import MongoClient, UpdateOne
from .mongodb import db
from .utils import DatasetNotFound, GivewithError, expand_dot_fields
from .loggly import get_logger

MIN_LEVENSHTEIN_DISTANCE = 3

def new_brand_discovery(dataset, data):
    """
    This is a "passthrough" method and does not manipulate data
    NOTE: No methods should cause side effects that manipulate
          the `data`  object

    Does not create new brands from Nielsen or CSRIT
    """

    if dataset == 'CSRIT' or dataset == 'NIELSEN':
        pass

    elif dataset == 'MSCI':
        _find_new_brands(dataset, data[0].to_dict('records'))

    elif dataset == 'SASB':
        _update_brands_multithreading(dataset, data)

    elif dataset == 'TVL':
        _find_new_brands(dataset, data.to_dict('records'))

    elif dataset == 'CSRHUB':
        _update_brands_multithreading(dataset, data)

    else:
        raise DatasetNotFound()

    return data

def _find_new_brands(dataset, brands):

    get_logger().info(f'Start finding new brands for {dataset}')
    projection = {'_id': True, 'name': True, 'ISIN': True}
    get_logger().info(f'Running mongoDb collection {db().coll_brands} query {projection} and trying to pull all records where ISIN is true')
    db_brands = pd.DataFrame(list(db().coll_brands.find(filter={}, projection=projection)))
    get_logger().info(f'Total number of query results {len(db_brands)}')
    
    get_logger().info(f'Creating new List to store brands which does not exists in DB')
    new_brands = []
    for brand in brands:
        if not _brand_exists(brand, db_brands) and _valid_brand(brand):
            new_brands.append(expand_dot_fields({
                'name': brand['name'],
                'ISIN': brand['ISIN'],
                'indusry': brand['industry']
            }))
    get_logger().info(f'Total new Brands discovered {len(new_brands)}')
    get_logger().info(f'Total new Brands discovered {len(new_brands)}')

    get_logger().info(f'Check if the new brands are duplicates')
    # Check if the new brands are duplictes
    for new_brand in new_brands:
        for brand in brands:
            distance = Levenshtein.distance(new_brand['name'], brand['name'])
            if distance <= MIN_LEVENSHTEIN_DISTANCE:
                new_brand['levenshteinCollision'] = brand['name']

    get_logger().info(f'Start inserting total {len(new_brands)} into new brands collection')

    output_new_brands(new_brands, dataset)
    get_logger().info(f'Finished inserting total {len(new_brands)} into new brands collection')

    get_logger().info(f'Finished finding new brands for {dataset}')
    return

def _update_brands_sasb(brands):
    for brand in brands:
        sasb = {
            'categories': brand.pop('categories',{}),
            'disclosure_topics': brand.pop('disclosure_topics', []),
            'sustainability_dimensions': brand.pop('sustainability_dimensions',[])
        }
        brand['sasb'] =sasb
        
        name = brand.get('name', '')
        ISIN = brand.get('ISIN', '')
        db().coll_brands.update_one({'$or': [{'ISIN': brand.get('ISIN')}, {'name': name}, {'iname': str(name).lower()},{'brandvariants': {'$in':[name] }}, {'ISIN': ISIN}]}, {'$set': brand, '$setOnInsert': {'source': 'sasb'}}, upsert=True)

def _update_brands_csrhub(brands):
    for brand in brands:
        insertBrand = {'name': brand.pop('name', ""), 'industry': brand.pop('industry', ""), 'source': 'CSRHUB'}
        brandvariants = brand.get('namevariants', [])
        db().coll_brands.update_one({'$or': [{'ISIN': brand.get('ISIN')},{'name': brand.get('name','')}, {'iname': str(brand.get('name','')).lower()},{'name': {'$in': brandvariants}}, {'iname': {'$in': brandvariants}}]}, {'$set': brand, '$setOnInsert': insertBrand}, upsert=True)
        
def _update_brands_multithreading(dataset, brands):
    indexes = len(brands)
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        for index in range(0, indexes, 1000):
            if dataset == "SASB":
                executor.submit(_update_brands_sasb,brands[index: index+1000])
            if dataset == 'CSRHUB':
                executor.submit(_update_brands_csrhub,brands[index: index+1000])
    return   


def _brand_exists(brand, brands):
    if ('_id' in brand and brand.get('_id') in brands._id.values
            or 'name' in brands and brand.get('name') in brands.name.values
            or 'ISIN' in brands and brand.get('ISIN') in brands.ISIN.values):
        return True

    return False


def _valid_brand(brand):
    return 'name' in brand and 'industry' in brand


def output_new_brands(new_brands, dataset):
    """ Save newly found brands to the new brands collection """
    if new_brands:
        db().coll_new_research_brands.insert({
            'date': datetime.utcnow(),
            'dataset': dataset,
            'brands': new_brands
        })
