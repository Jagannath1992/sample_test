# -*- coding: utf-8 -*-
import functools
from typing import Callable
import urllib
import json
import jwt

from flask import request
from datetime import datetime, timedelta
from os import environ
from keyczar import keyczar
from matchmaking.mongodb import db
from matchmaking.validation.utils import validate_existences
from matchmaking.models.models import v, schema_user

# Padding to support 16-byte block alignment
from .utils import DATETIME_FORMAT, GivewithError

KEYLOCATION = 'keys'
crypter = keyczar.Crypter.Read(KEYLOCATION)

TOKEN_VALIDITY = timedelta(days=7)

aws_region = environ.get('COGNITO_AWS_REGION', 'us-east-1')
userpool_id = environ.get('COGNITO_USERPOOL_ID', 'us-east-1_aHNsxROA7')

# load keys on start
keys_url = 'https://cognito-idp.{}.amazonaws.com/{}/.well-known/jwks.json'.format(aws_region, userpool_id)
KEY_RESPONSE = urllib.request.urlopen(keys_url) # nosec
keys = json.loads(KEY_RESPONSE.read())['keys'] # pylint: disable=invalid-name

TOKEN_PRIVATE_KEY = environ.get('TOKEN_PRIVATE_KEY', '') # CodeBuild tests need this setup on AWS Console to pass

def _encrypt(raw):
    return crypter.Encrypt(raw)


def _decrypt(encoded):
    return crypter.Decrypt(encoded)


def create_token(password_digest, uuid, expire_date):
    return _encrypt('/'.join((password_digest, uuid, expire_date)))


def authenticate_request(app):
    if request.method == 'OPTIONS':
        return

    token = request.headers.get('authorization', '')
    if token == '':   # nosec
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, TOKEN_PRIVATE_KEY, algorithms='HS256')
        if '_id' in claims:
            request.user = v.normalized(claims, schema_user)
            request.user['username'] = claims['email']
        else:
            request.user = db().coll_user.find_one({'username': claims['email']})
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401


def validate_token_against_collection(collection: str) -> Callable:
    """Returns a wrapper function that will validate
    a keyczar request token against the specified collection

    Args:
        collection (str): db collection name to validate token against

    Usage:
        @public_mm_bp.route('/supplier-analysis-reports/<slug>', methods=['GET'])
        validate_token_against_collection('deals')
        def endpoint(slug):
            pass

        this will validate the Authorization token(from keyczar) against the specified collection
        using the `validate_token` function
    """
    def _validate(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kws):
            request.slug = validate_token(collection)

            return func(*args, **kws)

        return wrapper

    return _validate


def authenticate_with_one_of(*validators: Callable) -> Callable:
    """Authenticate request with one of several authentication wrappers.
    The first one to not throw an exception will be returned, otherwise the request will be aborted.
    Assumes that your authentication function can be used as a decorator and will throw an exception on errors.

    Usage:
    @public_mm_bp.route('/')
    @authenticate_with_one_of(authenticate, authenticate_with_keyczar_token,...)
    def post(args):
      return True
    """
    def _authenticate(func):
        @functools.wraps(func)
        def wrapper(*args, **kws):
            for validator in validators:
                try:
                    return validator(func)(*args, **kws)
                except GivewithError as error:
                    if error.code not in {401, 403}: # catch auth errors only
                        raise error

            raise GivewithError('Invalid token', code=401)

        return wrapper
    return _authenticate


def secure_commerce(app):
    if request.method == 'OPTIONS':
        return

    try:
        request.slug = validate_token('pilot_deal')
    except GivewithError:
        request.slug = validate_token('deals')


def validate_token(collection: str) -> str:
    """Decrypts a keyczar token and confirms that the slug and
    field_name(specified during the token creation phase)
    matches a valid entity in the specified `collection`

    Args:
        collection (str): db collection name

    Raises:
        GivewithError: Auth Error

    Returns:
        str: the decrypted slug
    """
    try:
        # decode the token
        token = request.headers['authorization']
        password, field_name, slug, expires = _decrypt(token).split('/')
    except KeyError:
        raise GivewithError('Credentials not found', code=401)
    except Exception:
        raise GivewithError('Invalid Token', code=401)

    # prevent users logged in one link to access others
    current_slug = request.view_args.get('slug')
    if current_slug and current_slug != slug:
        raise GivewithError('Invalid token for requested resource.', code=401)

    # validate expire date
    if datetime.utcnow() > datetime.strptime(expires, DATETIME_FORMAT):
        raise GivewithError('Your token has expired.', code=401)

    # validate against specified collection
    if not validate_existences({'slug': slug, field_name: password}, collection):
        raise GivewithError('Invalid token', code=401)

    return slug


def get_cognito_id_from_token(token):
    claims = jwt.decode(token, verify=False)
    return claims.get('username', '')
