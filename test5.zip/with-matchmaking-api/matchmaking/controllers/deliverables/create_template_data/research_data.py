from bson import ObjectId
from matchmaking.models.models import MSCI_COLUMN_TRANSLATE_ADMIN
from .utils import clean, get_sdg_master, get_gri_master, get_sasb_master, get_strings, deduplicate_intersection
from ....utils import get_descendant_key

def make_research_data(useful_data, master_data):
    make_list_of_sdgs(useful_data, master_data)
    make_program_sdgs_sentence(useful_data) # relies on make_list_of_sdgs

    make_gri_data(useful_data, master_data)
    make_csrhub_data(useful_data, master_data)
    make_sasb_data(useful_data, master_data)
    make_esg_data(useful_data, master_data)


def make_list_of_sdgs(useful_data, master_data):
    if get_descendant_key(master_data, 'program.sdg.data', None) is None:
        useful_data['PROGRAM_SDGS'] = ['** MISSING PROGRAM SDG DATA **']
        return

    sdgs = list()
    sdg_master = get_sdg_master()

    for program_string in get_strings(master_data['program']['sdg']['data'], 'sdg'):
        if program_string in sdg_master.keys():
            sdgs.append(clean(sdg_master[program_string]))

    useful_data['PROGRAM_SDGS'] = sdgs


def make_program_sdgs_sentence(useful_data):
    sdgs = useful_data['PROGRAM_SDGS']
    useful_data['PROGRAM_SDGS_SENTENCE'] = ', '.join(sdgs)


def make_gri_data(useful_data, master_data):
    if get_descendant_key(master_data, 'program.gri.data', None) is None:
        useful_data['GRI'] = ['** MISSING PROGRAM GRI DATA **']
        return

    gri_outputs = list()
    gri_master = get_gri_master()

    useful_data['GRI'] = [clean(gri_master[str(program_gri)]) for program_gri in master_data['program']['gri']['data']]


def make_csrhub_data(useful_data, master_data):
    if get_descendant_key(master_data, 'program.csrhub.data', None) is None:
        useful_data['CSRHUB'] = ['** MISSING PROGRAM CSRHUB DATA **']
        return

    csrhub = list()
    useful_data['CSRHUB'] = [clean(csrhub_string) for csrhub_string in get_strings(master_data['program']['csrhub']['data'], 'csrhub')]


def make_sasb_data(useful_data, master_data):
    if get_descendant_key(master_data, 'program.sasb.data', None) is None:
        useful_data['SASB'] = ['** MISSING PROGRAM SASB DATA **']
        useful_data['SASB_CUSTOMER'] = ['** MISSING PROGRAM SASB DATA **']
        useful_data['SASB_CLIENT'] = ['** MISSING PROGRAM SASB DATA **']
        return

    sasb_client = list()
    sasb_customer = list()
    program_sasb_strings = list()

    sasb_master = get_sasb_master()
    customer_sasb = __get_brand_sasb_data(master_data, 'customer')
    client_sasb = __get_brand_sasb_data(master_data, 'client')

    program_sasb = master_data['program']['sasb']['data']
    customer_sasb_overlap = deduplicate_intersection(program_sasb, [ObjectId(_id) for _id in customer_sasb])
    client_sasb_overlap = deduplicate_intersection(program_sasb, [ObjectId(_id) for _id in client_sasb])

    for sasb_data in get_strings(program_sasb, 'sasb'):
        program_sasb_strings.append(clean(sasb_master[sasb_data] + sasb_data))

    for sasb_data in get_strings(customer_sasb_overlap, 'sasb'):
        sasb_customer.append(clean(sasb_master[sasb_data] + sasb_data))

    for sasb_data in get_strings(client_sasb_overlap, 'sasb'):
        sasb_client.append(clean(sasb_master[sasb_data] + sasb_data))

    useful_data['SASB'] = program_sasb_strings
    useful_data['SASB_CUSTOMER'] = sasb_customer
    useful_data['SASB_CLIENT'] = sasb_client


def __get_brand_sasb_data(master_data, type):
    brand_sasb = get_descendant_key(master_data, '{type}.sasb.categories.tagged.ids'.format(type=type), None)
    if brand_sasb is not None:
        return [ObjectId(sasb_id) for sasb_id in brand_sasb]

    brand_sasb_caps = get_descendant_key(master_data, '{type}.sasb.categories.tagged.ids'.format(type=type), None)
    if brand_sasb_caps is not None:
        return [ObjectId(sasb_id) for sasb_id in brand_sasb_caps]

    return []

# FYI: ESG data is the same as MSCI data
def make_esg_data(useful_data, master_data):
    if get_descendant_key(master_data, 'program.esg.data', None) is None:
        useful_data['ESG'] = ['** MISSING PROGRAM ESG/MSCI DATA **']
        useful_data['ESG_CUSTOMER'] = ['** MISSING PROGRAM ESG/MSCI DATA **']
        useful_data['ESG_CLIENT'] = ['** MISSING PROGRAM ESG/MSCI DATA **']
        return

    esg_client = list()
    esg_customer = list()
    program_esg = get_strings([data['issue'] for data in get_descendant_key(master_data, 'program.esg.data', [])], 'esg')
    master_data['program']['esg']['strings'] = program_esg

    customer_esg = [MSCI_COLUMN_TRANSLATE_ADMIN[data] for data in __get_brand_esg_data(master_data, 'customer')]
    client_esg = [MSCI_COLUMN_TRANSLATE_ADMIN[data] for data in __get_brand_esg_data(master_data, 'client')]

    useful_data['ESG'] = [clean(data) for data in program_esg]
    useful_data['ESG_CUSTOMER'] = [clean(data) for data in deduplicate_intersection(program_esg, customer_esg)]
    useful_data['ESG_CLIENT'] = [clean(data) for data in deduplicate_intersection(program_esg, client_esg)]

def __get_brand_esg_data(master_data, type):
    brand_sasb = get_descendant_key(master_data, '{type}.msci.weights'.format(type=type), None)

    if brand_sasb is None:
        return []

    sasb_data = []
    for key in brand_sasb:
        if key in MSCI_COLUMN_TRANSLATE_ADMIN and brand_sasb[key] > 0:
            sasb_data.append(key)

    return sasb_data
