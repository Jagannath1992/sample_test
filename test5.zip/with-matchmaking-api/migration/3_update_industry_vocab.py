from matchmaking import db

industries = [
    {
        "type" : "industry",
        "code" : "50203010",
        "label" : "Interactive Media & Services",
        "description" : "Companies engaging in content and information creation or distribution through proprietary platforms, where revenues are derived primarily through pay-per-click advertisements. Includes search engines, social media and networking platforms, online classifieds, and online review companies. Excludes companies operating online marketplaces classified in Internet & Direct Marketing Retail."
    },
    {
        "type" : "industry",
        "code" : "50202020",
        "label" : "Interactive Home Entertainment",
        "description" : "Producers of interactive gaming products, including mobile gaming applications. Also includes educational software used primarily in the home. Excludes online gambling companies classified in the Casinos & Gaming Sub-Industry."
    },
    {
        "type" : "industry",
        "code" : "45102030",
        "label" : "Internet Services & Infrastructure",
        "description" : "Companies providing services and infrastructure for the internet industry including data centers and cloud networking and storage infrastructure. Also includes companies providing web hosting services. Excludes companies classified in the Software Industry."
    }
]

result = db().coll_vocabulary.insert_many(industries)
