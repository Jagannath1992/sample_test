from datetime import datetime, timedelta
from app.db.utils import get_documents, get_document_by_id
from app.utils.utils import get_forex_rates


def get_customer_total_funding_for_nonprofit(customer_brand_id, nonprofit_id, from_date, to_date):
    '''
    Get funding to a nonprofit with nonprofit_id by a brand with customer_brand_id from from_date to to_date
    '''
    nonprofit_programs = get_documents('mm_programs', {'nonprofit': nonprofit_id}).distinct('_id')

    query = {
        'givewithCustomer': customer_brand_id,
        'selectedProgram': {'$in': nonprofit_programs},
        'status': 'COMPLETE',
        'createdAt': {'$gte': from_date, '$lte': to_date}
    }

    deals = get_documents('deals', query, projection={'currency': True, 'fundingAmount': True})

    rates = get_forex_rates()
    def convert_to_usd(amount, symbol):
        rate = rates.get(symbol)
        return amount / rate if rate else 0

    total = 0
    for deal in deals:
        total += convert_to_usd(deal.get('fundingAmount', 0), deal.get('currency', 'USD'))

    return total


def is_brand_eligible_for_nonprofit_premium_assets(brand_id, nonprofit_id):
    '''
    Check whether brand with brand_id is eligible to receive premium assets for program with program_id

    Brand is eligible for premium assets if its total funding to the nonprofit whose program
    matches the supplied program_id >= 250,000 over the course of the past 365 days
    (the past year counting from now)
    '''
    to_date = datetime.utcnow()
    from_date = to_date - timedelta(days=365)
    brand_funding_over_a_year = get_customer_total_funding_for_nonprofit(brand_id, nonprofit_id, from_date, to_date)

    return brand_funding_over_a_year >= 250000
