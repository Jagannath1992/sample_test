from marshmallow import fields, Schema, post_load, validate, validates_schema, ValidationError
from portal.shared.custom_fields import ObjectIdField
from portal.shared.schema import EntitySchema, SearchRequestSchema, SearchResponseSchema


class PreferredProgramSchema(Schema):
    additional = fields.List(ObjectIdField)
    cart = fields.List(ObjectIdField)
    editing = fields.Bool()
    password = fields.String()
    selected = fields.List(ObjectIdField)


class CSRHUBCategories(Schema):
    Community = fields.Float()
    Employees = fields.Float()
    Environment = fields.Float()
    Governance = fields.Float()


class CSRHUBSubCategories(Schema):
    CommunityDevPhilanthropy = fields.Float()
    HumanRightsSupplyChain = fields.Float()
    Product = fields.Float()
    CompensationBenefits = fields.Float()
    DiversityLaborRights = fields.Float()
    TrainingHealthSafety = fields.Float()
    EnergyClimateChange = fields.Float()
    EnvironmentPolicyReporting = fields.Float()
    ResourceManagement = fields.Float()
    Board = fields.Float()
    LeadershipEthics = fields.Float()
    TransparencyReporting = fields.Float()


class CSRHUBSchema(Schema):
    overall = fields.Float()
    categories = fields.Nested(CSRHUBCategories)
    subcategories = fields.Nested(CSRHUBSubCategories)
    status = fields.String()


class TaggedSchema(Schema):
    labels = fields.List(fields.String())
    ids = fields.List(fields.String())


class SasbCategorySchema(Schema):
    all_labels = fields.List(fields.String())
    Tagged = fields.Nested(TaggedSchema)
    sustainability_dimensions = fields.List(fields.String())


class MSCISubCategory(Schema):
    accessToCommunications = fields.Float()
    accessToFinance = fields.Float()
    accessToHlthcre = fields.Float()
    biodivLandUse = fields.Float()
    carbonEmissions = fields.Float()
    chemSafety = fields.Float()
    controvSrc = fields.Float()
    corpGovernance = fields.Float()
    energyEfficiency = fields.Float()
    environmentalPillar = fields.Float()
    eWaste = fields.Float()
    financingEnvImp = fields.Float()
    finProdSafety = fields.Float()
    governancePillar = fields.Float()
    hlthSafety = fields.Float()
    humanCapitalDevelopment = fields.Float()
    climateChangeVulnerability = fields.Float()
    insHlthDemoRisk = fields.Float()
    laborMgmt = fields.Float()
    oppsClnTech = fields.Float()
    oppsGreenBuilding = fields.Float()
    oppsNutriHlth = fields.Float()
    oppsRenewEnergy = fields.Float()
    packMatWaste = fields.Float()
    privacyDataSec = fields.Float()
    prodCarbFtprnt = fields.Float()
    prodSftyQuality = fields.Float()
    rawMatSrc = fields.Float()
    responsibleInvestment = fields.Float()
    socialPillar = fields.Float()
    supplyChainLab = fields.Float()
    toxicEmissWste = fields.Float()
    waterStress = fields.Float()


class MsciSchema(Schema):
    msciId = fields.String()
    weights = fields.Nested(MSCISubCategory)
    score = fields.Nested(MSCISubCategory)
    quartile = fields.Nested(MSCISubCategory)


class TaggedSchema(Schema):
    labels = fields.List(fields.String())
    ids = fields.List(fields.String())


class CategoriesSchema(Schema):
    all_labels = fields.List(fields.String())
    tagged = fields.Nested(TaggedSchema)


class SasbSchema(Schema):
    categories = fields.Nested(CategoriesSchema)
    disclosure_topics = fields.List(fields.String())
    sustainability_dimensions = fields.List(fields.String())


class CorpCommitmentsSchema(Schema):
    themes = fields.List(fields.String())


class CorporateEntitySchema(EntitySchema):
    """Corporate Entity Schema"""
    id = ObjectIdField()
    name = fields.String(required=True)
    industry = fields.String(required=True)
    ISIN = fields.String()
    sasb = fields.Nested(SasbSchema)
    preferredPrograms = fields.Nested(PreferredProgramSchema)
    csrhub = fields.Nested(CSRHUBSchema)
    nonprofits = fields.Nested(fields.List(ObjectIdField))
    msci = fields.Nested(fields.Nested(MsciSchema))
    corpCommitments = fields.Nested(CorpCommitmentsSchema)


class CorporateEntitySearchRequest(SearchRequestSchema):
    """Cor Filter model for search request"""
    pass

    # class Meta:
    #     contains_fields = ['name', 'iname', 'ISIN']


class BrandSearchResponse(SearchResponseSchema):
    results = fields.List(fields.Nested(CorporateEntitySchema), required=True)


class BrandRequest(CorporateEntitySchema):
    @validates_schema
    def validate_name(self, data, **kwards):
        if not data['name']:
            raise ValidationError('Invalid schema')


# class BrandResponse(CorporateEntitySchema):
#     pass


class RecommendedPrograms(Schema):
    percentage = fields.Float()
    score = fields.Float()
    supportedCauseByProgram = fields.String()
    programId = fields.String()
    orderBy = fields.Number()
    isPreferred = fields.Boolean()
    sioName = fields.String()
    programName = fields.String()


class BrandResponse(EntitySchema):
    name = fields.String(required=True)
    industry = fields.String(required=True)
    ISIN = fields.String()
    sasb = fields.Nested(SasbSchema)
    preferredPrograms = fields.Nested(PreferredProgramSchema)
    csrhub = fields.Nested(CSRHUBSchema)
    nonprofits = fields.Dict(keys=fields.Str(), values=fields.List(ObjectIdField))
    msci = fields.Nested(MsciSchema)
    corpCommitments = fields.Nested(CorpCommitmentsSchema)
    recommendedPrograms = fields.List(fields.Nested(RecommendedPrograms))
