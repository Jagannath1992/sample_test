from unittest import mock
import pytest

from app.utils.brand import get_brand_topic_labels_with_industry_fallback

class TestGetBrandTopicLabelsWithIndustryFallback():
    brand_without_topics = {
        'name': 'Test Brand',
        'industry': 'Technology',
    }

    brand_with_topics = {
        **brand_without_topics,
        'topics': [
            {'label': 'topicA', 'score': 5},
            {'label': 'topicB', 'score': 10},
            {'label': 'topicC', 'score': 0},
        ]
    }

    @classmethod
    @pytest.fixture()
    def mock_get_document(cls):
        return mock.MagicMock(return_value={
            '_id': 'test',
            'topics': [
                {'label': 'topicD', 'score': 9},
                {'label': 'topicE', 'score': 10}
            ]
        })

    def test_get_brand_topics(self):
        topics = get_brand_topic_labels_with_industry_fallback(self.brand_with_topics)
        assert topics == ['topicA', 'topicB']

    def test_get_brand_topics_with_limit(self):
        topics = get_brand_topic_labels_with_industry_fallback(self.brand_with_topics, limit=1)
        assert topics == ['topicA']

    def test_industry_fallback(self, mock_get_document, monkeypatch):
        monkeypatch.setattr('app.utils.brand.get_document', mock_get_document)

        topics = get_brand_topic_labels_with_industry_fallback(self.brand_without_topics)
        mock_get_document.assert_called_with(mock.ANY, {'industry_name': self.brand_without_topics['industry']})
        assert topics == ['topicD', 'topicE']

    def test_industry_fallback_with_limit(self, mock_get_document, monkeypatch):
        monkeypatch.setattr('app.utils.brand.get_document', mock_get_document)

        topics = get_brand_topic_labels_with_industry_fallback(self.brand_without_topics, limit=1)
        assert topics == ['topicD']
