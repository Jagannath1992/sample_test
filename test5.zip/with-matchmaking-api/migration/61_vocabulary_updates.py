from matchmaking import db

# change category of approach types in vocab from participant to environmental
db().coll_vocabulary.find_one_and_update(filter={'$and' : [{'label' : 'Enhance land management and/or protection'}, {'type' : 'approach'}]},
                                                       update={'$set' : {'category': 'environmental'}})


# add scc conversion to scc_conversion collection
scc = {
    "name" : "Number of smartphones charged",
    "value" : 0.00000784,
}

db().coll_program_scc_conversion.insert_one(scc)


# add new environmental approach to survey_data questionDependencies
survey_data = db().coll_survey_data.find_one({}, projection={'questionDependencies.environmentalOutputs': True})
environmentalOutputs = survey_data.get('questionDependencies').get('environmentalOutputs')

values = environmentalOutputs.get('values')

environmental_approach = db().coll_vocabulary.find_one({'label' : 'Enhance land management and/or protection', 'type': 'approach'}, projection={'label' : True})

values[str(environmental_approach.get('_id'))] = environmental_approach.get('label')

db().coll_survey_data.find_one_and_update({}, {
    '$set': {'questionDependencies.environmentalOutputs.values': values}
})

