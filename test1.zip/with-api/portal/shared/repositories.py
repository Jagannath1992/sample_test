from portal.features.account_approval.repository import AccountApprovalRepository
from portal.features.accounts.repository import AccountRepository
from portal.features.corporate_intelligence.repository import CorporateEntityRepository
from portal.features.instances.repository import InstanceSettingsRepository
from portal.features.orders.repository import OrderRepository
from portal.features.cause_areas.repository import CauseAreaRepository, SkuRepository
from portal.features.transactions.repository import TransactionRepository
from portal.features.users.repository import UserRepository
from portal.features.locales.repository import LocaleRepository
from portal.features.error_logs.respository import ErrorLogRepository, ErrorLogRepository

all_repositories = {}


def init_repositories(db):
    all_repositories['account'] = AccountRepository(db)
    all_repositories['mm_brands_copy'] = CorporateEntityRepository(db)
    all_repositories['user'] = UserRepository(db)
    all_repositories['order'] = OrderRepository(db)
    all_repositories['cause_area'] = CauseAreaRepository(db)
    all_repositories['sku'] = SkuRepository(db)
    all_repositories['account_approval'] = AccountApprovalRepository(db)
    all_repositories['transaction'] = TransactionRepository(db)
    all_repositories['instance_settings'] = InstanceSettingsRepository(db)
    all_repositories['locale'] = LocaleRepository(db)
    all_repositories['error_log'] = ErrorLogRepository(db)


def account_repository() -> AccountRepository:
    return all_repositories['account']


def user_repository() -> UserRepository:
    return all_repositories['user']


def order_repository() -> OrderRepository:
    return all_repositories['order']


def cause_area_repository() -> CauseAreaRepository:
    return all_repositories['cause_area']


def sku_repository() -> SkuRepository:
    return all_repositories['sku']


def account_approval_repository() -> AccountApprovalRepository:
    return all_repositories['account_approval']


def transaction_repository() -> TransactionRepository:
    return all_repositories['transaction']


def instance_settings_repository() -> InstanceSettingsRepository:
    return all_repositories['instance_settings']


def locale_repository() -> LocaleRepository:
    return all_repositories['locale']


def error_log_repository() -> ErrorLogRepository:
    return all_repositories['error_log']


def corporate_entities() -> CorporateEntityRepository:
    return all_repositories['mm_brands_copy']
