# with-etl
This repository contains all with platform ETL python jobs


# Prerequisite (Local environment)

> Rename template.user.env to user.env and set all required environment variables

> In user.env make sure you set correct values Example: ETL_SOURCE=MSCI

> These are the list of ETL sources ['SIMIAN', 'TAGGING', 'CSRIT', 'CSRHUB', 'MSCI', 'TVL', 'SASB', 'NIELSEN']


# Run using Docker Compose

`docker-compose --env-file user.env up`

# Run using python (3.8.10) environment

> Make sure you have python 3.8.10 version setup using pyenv

`python -m venv env`
`source env/bin/activate`
`python trigger_etl.py`

# ECS Operator in AWS airflow
https://medium.com/@sohflp/how-to-work-with-airflow-docker-operator-in-amazon-mwaa-5c6b7ad36976

# Connect to AWS Dev ECR and push images
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 932027492231.dkr.ecr.us-east-1.amazonaws.com

## If you buidling image on M1 chip
docker buildx build --platform=linux/arm64 -t 932027492231.dkr.ecr.us-east-1.amazonaws.com/with-etl:1.1 .

## Other than M1 Chip
docker build -t 932027492231.dkr.ecr.us-east-1.amazonaws.com/with-etl:1.1 .

docker push 932027492231.dkr.ecr.us-east-1.amazonaws.com/with-etl:1.1