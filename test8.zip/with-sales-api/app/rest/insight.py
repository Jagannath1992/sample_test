from audioop import reverse
from copy import deepcopy
from itertools import chain
from typing import List, Dict, Tuple
from flask_restful import Resource, abort
from bson.objectid import ObjectId

from app.db.utils import get_document, get_documents, get_document_by_id
from app.validation.utils import validate_object_id
from app.utils.auth import authenticate, authenticate_with_one_of, validate_token_against_collection
from app.utils.utils import esg_key_to_msci_column
from app.utils.brand import get_brand_topic_labels_with_industry_fallback

brandAwards = {
  'business round table': {
    'name': 'Business Roundtable Member',
    'description': """An association of the CEOs of America's leading companies.
      Their recent "Statement on the Purpose of a Corporation" goes beyond shareholder-value
      and incorporates customers, employees, suppliers, and the broader community as
      important stakeholders to a company.""",
    'url': 'https://opportunity.businessroundtable.org/ourcommitment',
  },
  'sustainable brands': {
    'name': 'Sustainable Brands Member',
    'description': """Leading peer-to-peer, learning and networking group designed to support
      brands in meeting their sustainability goals. Member companies have taken action on
      their commitments and transparently report their social and environmental impact.""",
    'url': 'https://sustainablebrands.com/participate/corporatemember/community',
  },
  'best corporate citizen': {
    'name': 'Named One of the 100 Best Corporate Citizens',
    'description': """3BL Media evaluates the largest public U.S. companies on ESG transparency
      and performance. The 100 Best Corporate Citizens ranking serves as a valuable
      benchmark for companies working to improve their ESG transparency and performance.""",
    'url': 'https://100best.3blmedia.com/about/',
  },
  're100': {
    'name': 'RE 100 Member',
    'description': """A global corporate leadership initiative bringing together influential
      businesses committed to accelerating change towards zero carbon grids, at global scale.
      Member companies have committed to the use of 100% renewable electricity in the shortest
      possible time frame.""",
    'url': 'http://www.there100.org/re100',
  },
  'cecp': {
    'name': 'CECP Member',
    'description': """A CEO-led coalition that believes that a company’s social
      strategy — how it engages with key stakeholders including employees,
      communities, investors, and customers — determines company success.""",
    'url': 'https://cecp.co/about/',
  },
  'unglobal compact': {
    'name': 'UN Global Compact Signatory',
    'description': """A voluntary initiative based on CEO commitments to implement
      universal sustainability principles and to take steps to support UN goals.""",
    'url': 'https://www.unglobalcompact.org/about',
  },
  'global green': {
    'name': 'Named one of the Global 500 Greenest Companies',
    'description': """One of the most recognized environmental performance assessments
      of the world’s largest publicly traded companies.""",
    'url': 'https://www.newsweek.com/top-500-global-companies-green-rankings-2017-18',
  },
  'human rights campaign': {
    'name': 'Human Rights Campaign Corporate Equality Index',
    'description': """Human Rights Campaign Foundation’s Corporate Equality Index is the
    national benchmarking tool on corporate policies and practices pertinent to lesbian,
    gay, bisexual, transgender and queer employees.""",
    'url': 'https://www.thehrcfoundation.org/professional-resources/corporate-equality-index-2020-1',
  },
  'diversityinc': {
    'name': 'Top 50 Companies for Corporate Diversity',
    'description': """The DiversityInc Top 50 Companies for Diversity process began in 2001
    and is the leading assessment of diversity management in corporate America.""",
    'url': 'https://www.diversityinc.com/diversityinc-top-50-lists-since-2001/',
  }
}

class Insight(Resource):
    @authenticate_with_one_of(authenticate, validate_token_against_collection('supplier_analysis_reports'))
    def get(self, brand_id):
        if not validate_object_id(brand_id, 'mm_brands'):
            abort(404, message='brand not found')

        brand_fields = [
            'name', 'nameLabel', 'industry', 'msci', 'topics', 'customThemes.theme', 'customThemes.description',
            'customThemes.visibility', 'researchCorpCommitments.themes.theme',
            'researchCorpCommitments.themes.narrative', 'researchCorpCommitments.themes.themeVisibility', 'awards'
        ]

        brand = get_document_by_id('mm_brands', brand_id, projection=brand_fields)

        with_narratives, without_narratives = get_brand_themes(brand)

        return {
            'name': brand.get('nameLabel') or brand.get('name'),
            'industry': brand.get('industry'),
            'narrative': with_narratives or without_narratives,
            'msci': filter_esg(brand),
            'topics': get_brand_topic_labels_with_industry_fallback(brand, limit=7),
            'reward': get_brand_reward(brand.get('_id'), brand.get('awards',[]))
        }


def get_brand_reward(brand_id, awards):
    # print("this is line 105", awards)
    rewards = get_documents('brand_reward', {'brand_id': brand_id})
    all_awards = []
    if awards:
        for award in awards:
            award_data = get_document_by_id('award', award['award_id'])
            d = deepcopy(award_data)
            d['year'] = award['year']
            d['year'].sort(reverse=True)
            d['brand_id'] = brand_id
            all_awards.append(d)

    # aggregate reward by year
    result = {}
    for r in rewards:
        if r.get('type') in result:
            result.get(r.get('type')).get('year').append(r.get('year'))
        else:
            result[r.get('type')] = {
                'brand_id': r.get('brand_id'),
                'year': [r.get('year')],
                'name': brandAwards.get(r.get('type'))['name'],
                'description': brandAwards.get(r.get('type'))['description'],
                'url': brandAwards.get(r.get('type'))['url']
            }
            result[r.get('type')]['year'].sort(reverse=True)
    all_awards = all_awards + list(result.values())
    def sorting_years(e):
        return e['year'][0]

    all_awards.sort(key=sorting_years, reverse=True)

    return all_awards


def get_brand_themes(brand: Dict) -> Tuple[List, List]:
    custom_themes = {
        theme['theme'].lower(): {**theme, 'source': 'custom'}
        for theme in brand.get('customThemes', [])
    }

    # deduplicate and tag themes
    research_themes = []
    for research_theme in brand.get('researchCorpCommitments', {}).get('themes', []):
        theme = {**research_theme, 'source': 'csrit'}
        theme_label = theme['theme'].lower()

        if theme_label in custom_themes:
            custom_theme = custom_themes.pop(theme_label)
            theme = {
                **custom_theme, 'source': 'both'
            } if custom_theme.get('description') else {**theme, 'source': 'both'}

        research_themes.append(theme)

    themes = [
        theme for theme in chain(custom_themes.values(), research_themes)
        if theme.get('themeVisibility', theme.get('visibility', True))
    ]

    return split_themes_by_narrative(themes)


def split_themes_by_narrative(themes: List) -> Tuple[List, List]:
    with_narratives = []
    without_narratives = []

    for theme in themes:
        if theme.get('description') or theme.get('narrative'):
            with_narratives.append(theme)
        else:
            without_narratives.append(theme)

    return with_narratives, without_narratives


def filter_esg(brand):
    msci = brand.get('msci')
    if not msci:
        return []

    esg_white_list = ['accessToCommunications', 'carbonEmissions', 'climateChangeVulnerability',
                      'humanCapitalDevelopment', 'responsibleInvestment', 'accessToFinance']

    visible_keys = [
        esg_key for esg_key in msci.get('score', {})
        if (msci['score'].get(esg_key) or msci['weights'].get(esg_key)) and (esg_key in esg_white_list)]

    industry = brand.get('industry')

    msci_data = list()
    for esg_key in visible_keys:
        msci_element = format_msci(msci, esg_key, industry)
        if msci_element is not None:
            msci_data.append(msci_element)

    return {
        'totalBrandAverage': brand.get('msci', {}).get('industryAdjustedScore', 0),
        'totalIndustryAverage': get_industry_average(industry),
        'data': msci_data,
    }


def get_industry_average(industry):
    total_industry_average = 0

    industry_average = get_document('msci_industry_averages', {'industry': industry})
    if industry_average is not None:
        total_industry_average = industry_average.get('industryAdjustedScore', 0)

    return total_industry_average


def format_msci(msci, esg_key, industry):
    msci_column = esg_key_to_msci_column(esg_key)

    average = 0
    msci_industry_averages = get_document('msci_industry_averages', {'industry': industry})
    if msci_industry_averages is not None:
        average = msci_industry_averages.get(msci_column, '')

    weights = msci.get('weights', {}).get(esg_key, 0)

    if weights > 0:
        return {
            'issue': {
                '_id': translate_to_id(msci_column),
                'label': msci_column
            },
            'topic': translate_to_topic(_type='esg', label=msci_column),
            'score': msci.get('score', {}).get(esg_key, 0),
            'quartile': msci.get('quartile', {}).get(esg_key, 0),
            'weight': msci.get('weights', {}).get(esg_key, 0),
            'description': msci.get('info', {}).get(esg_key, {}).get('description', ''),
            'average': average
        }
    else:
        return None


def translate_to_id(industry):
    if isinstance(industry, ObjectId):
        return industry

    vocabulary = get_document('mm_vocabulary', {'label:': industry.lower()})
    if vocabulary is not None:
        return vocabulary.get('_id')

    return None


def translate_to_topic(_id=None, _type=None, label=None):
    if not _id and not (_type and label):
        return None

    vocabulary = get_document('mm_vocabulary', _id)
    if isinstance(vocabulary.get('topic'), ObjectId):
        return vocabulary.get('topic')

    return None
