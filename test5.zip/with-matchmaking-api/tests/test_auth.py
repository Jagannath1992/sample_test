import random
import string
import jwt
import base64
import json
from datetime import datetime, timedelta

TOKEN_PRIVATE_KEY = 'Z3Huc7L2YuhwPIXQnDmZUBVoNqxTxmalRj9wj4o4l6THUhUKMkuemy6ok78k6SKl' \
                   '3wrzy7QZ7T3bpVfo11PN9bfVTXhrDyIay4RvE4yd25CxPgvg0nMvCy51W7cAcai9'

def test_admin_permission(client, admin_header, client_header, invalid_header):
    response = client.get('/admin/deals', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/admin/deals', headers=client_header)
    assert response.status_code == 403

    response = client.get('/admin/deals', headers=invalid_header)
    assert response.status_code == 401


def test_client_permission(client, admin_header, client_header, invalid_header):
    response = client.get('/dashboard/home', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/dashboard/home', headers=client_header)
    assert response.status_code == 200

    response = client.get('/dashboard/home', headers=invalid_header)
    assert response.status_code == 401


def test_encrypt_token_different_key(client):
    now = datetime.now().timestamp()
    hour_later = (datetime.now() + timedelta(hours=1)).timestamp()

    claims = {
        "sub": "ada757d2-f4c9-416f-9c2b-ccbd94ef3017",
        "event_id": "6e27b2d2-9b8d-425d-9c63-a060f512db5d",
        "token_use": "access",
        "scope": "admin",
        "auth_time": now,
        "iss": "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7",
        "exp": hour_later,
        "jti": "b81e150e-4303-4663-ad46-c87adab94d63",
        "client_id": "1nmeh7a4rs6gs58d6uhmlq6dmo",
        "username": "ada757d2-f4c9-416f-9c2b-ccbd94ef3017",
        "email": "shanyan.jiang@giveiwth.com",
        "resource_ids": [
            "5c1415685b03bb0008c21b06"
        ]
    }

    invalid_key = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(128)])

    assert len(invalid_key) == len(TOKEN_PRIVATE_KEY)
    assert invalid_key != TOKEN_PRIVATE_KEY

    invalid_token = jwt.encode(claims, invalid_key, algorithm='HS256')
    token = jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')

    # real token should pass
    response = client.get('/admin/deals', headers={
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': token,
    })
    assert response.status_code == 200

    # fake token should fail
    response = client.get('/admin/deals', headers={
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': invalid_token,
    })
    assert response.status_code == 401
    assert 'Invalid token' == response.data.decode()


def test_change_payload(client, client_token):
    claims = jwt.decode(client_token, verify=False)
    claims['scope'] = 'admin' # change scope to admin

    modified_token_body = base64.b64encode(json.dumps(claims).encode('utf-8'))

    arr = client_token.decode().split('.')
    modified_token = arr[0] + '.' + modified_token_body.decode('utf-8') + '.' + arr[2]

    response = client.get('/admin/deals', headers={
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': modified_token,
    })

    assert response.status_code == 401
    assert 'Invalid token' == response.data.decode()


def test_expired_token(client):
    now = datetime.now().timestamp()
    one_second_before = (datetime.now() - timedelta(seconds=1)).timestamp()

    claims = {
        "sub": "ada757d2-f4c9-416f-9c2b-ccbd94ef3017",
        "event_id": "6e27b2d2-9b8d-425d-9c63-a060f512db5d",
        "token_use": "access",
        "scope": "admin",
        "auth_time": now,
        "iss": "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_aHNsxROA7",
        "exp": one_second_before,
        "jti": "b81e150e-4303-4663-ad46-c87adab94d63",
        "client_id": "1nmeh7a4rs6gs58d6uhmlq6dmo",
        "username": "ada757d2-f4c9-416f-9c2b-ccbd94ef3017",
        "resource_ids": [
            "5c1415685b03bb0008c21b06"
        ]
    }

    token = jwt.encode(claims, TOKEN_PRIVATE_KEY, algorithm='HS256')

    response = client.get('/admin/deals', headers={
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': token,
    })

    assert response.status_code == 401
    assert 'Expired token' == response.data.decode()
