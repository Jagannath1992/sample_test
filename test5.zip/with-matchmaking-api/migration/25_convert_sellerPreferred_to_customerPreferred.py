from matchmaking import db

deal_data = list(db().coll_deals.find())

for deal in deal_data:
    deal_id = deal['_id']
    recommendedPrograms = deal.get('selectedRecommendedPrograms', [])
    for recommendedProgram in recommendedPrograms:
        if isinstance(recommendedProgram, dict):
            sellerPreferred = recommendedProgram.pop('sellerPreferred', None)
            if isinstance(sellerPreferred, bool):
                recommendedProgram['customerPreferred'] = sellerPreferred
        db().coll_deals.update_one({'_id': deal_id}, {'$set': {'selectedRecommendedPrograms': recommendedPrograms}})
