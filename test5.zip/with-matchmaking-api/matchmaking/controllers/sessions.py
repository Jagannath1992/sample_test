# -*- coding: utf-8 -*-
import hashlib

from datetime import datetime
from flask import jsonify, request, Blueprint, current_app
from ..auth import TOKEN_VALIDITY, DATETIME_FORMAT, create_token
from ..utils import GivewithError
from ..mongodb import db

sessions_bp = Blueprint('sessions', __name__)


@sessions_bp.route('/', methods=['OPTIONS'])
def create_session_options():
    return current_app.make_default_options_response()


@sessions_bp.route('/', methods=['POST'])
def create_session():
    """ Login user into the system
    ---
    tags: ['Authorization']

    requestBody:
      description: Login request
      required: true
      content:
        application/json:
          schema:
            $ref: '#/components/schemas/Login'

    responses:
      200:
        description: User details
        schema:
          $ref: '#/components/schemas/Auth'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    plain_password = request.json.get('password', 'missing_password')
    password_digest = hashlib.sha256(str.encode(plain_password)).hexdigest()
    query = {'username': request.json.get('username', 'missing_username'),
             'password': password_digest}
    user = db().coll_user.find_one(query)

    if user is not None:
        expires = (datetime.utcnow() + TOKEN_VALIDITY).strftime(DATETIME_FORMAT)
        token = create_token(password_digest, user['uuid'], expires)
        response = {"name": user.get('name', 'missing_name_in_db'),
                    "username": user.get('username', 'missing_name_in_db'),
                    "expires": expires,
                    "token": token}

        return jsonify(response)

    raise GivewithError('Invalid username or password', code=401)
