import json

def test_sales_user_subdomain(client, db, header):
    
    update_result = db.user.update_one({'username': 'jagannath.sahu@xoriant.com'},
                                       {'$set': {'departmentType': 'Sales'}})
    assert update_result.matched_count == 1

    payload = {
    "grantType": "password",
    "username": "jagannath.sahu@xoriant.com",
    "password": "Givewith@1"
    }   
    
    response = client.post('/v1/okta/authorize', data=json.dumps(payload), headers=header)
    print(response)
    assert response.status_code == 200

def test_procurement_user_subdomain(client, db, header):
    
    update_result = db.user.update_one({'username': 'jagannath.sahu@xoriant.com'},
                                       {'$set': {'departmentType': 'Procurement'}})
    assert update_result.matched_count == 1

    payload = {
    "grantType": "password",
    "username": "jagannath.sahu@xoriant.com",
    "password": "Givewith@1"
    } 

    response = client.post('/v1/okta/authorize', data=json.dumps(payload), headers=header)
    assert response.status_code == 200


def test_empty_department(client, db, header):

    update_result = db.user.update_one({'username': 'jagannath.sahu@xoriant.com'},
                                       {'$set': {'departmentType': ''}})
    assert update_result.matched_count == 1

    payload = {
    "grantType": "password",
    "username": "jagannath.sahu@xoriant.com",
    "password": "Givewith@1"
    } 
    
    response = client.post('/v1/okta/authorize', data=json.dumps(payload), headers=header)
    print("response---->",response)
    assert response.status_code == 401

# def test_portal_user_subdomain(client, db, header):
     
#     payload = {
#         "grantType": "password",
#         "username": "admin@givewith.com",
#         "password": "Qvz$8r=3z?"
#     }

#     response = client.post('/v1/okta/authorize', data=json.dumps(payload), headers=header)
#     print("response---->",response)
#     assert response.status_code == 200

