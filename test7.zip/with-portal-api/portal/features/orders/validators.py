from typing import Optional, List, Dict

from bson import ObjectId

from portal.shared.auth.security import has_role
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.enums import OrderStatus, UserRole
from portal.shared.repositories import order_repository


class StatusValidator:
    """
    A new Order can be Draft or Pending Approval
    A Draft can be Delete, Draft, Pending Approval
    A Pending can be Delete, Deny, Approve
    An Approve can be Abandon, Complete, or Financial Hold
    A Complete can be Rejected, Fulfilled
    Fulfilled cannot change
    Denied, Abandoned, or Rejected can be Delete or Draft
    Financial Hold can be Completed or Abandoned
    """
    valid_transitions = {

        OrderStatus.DRAFT.value: [OrderStatus.DRAFT, OrderStatus.DELETED, OrderStatus.PENDING_APPROVAL],
        OrderStatus.PENDING_APPROVAL.value: [OrderStatus.PENDING_APPROVAL, OrderStatus.DELETED, OrderStatus.DENIED, OrderStatus.APPROVED],
        OrderStatus.APPROVED.value: [OrderStatus.APPROVED, OrderStatus.ABANDONED, OrderStatus.COMPLETED, OrderStatus.FINANCIAL_HOLD],
        OrderStatus.DENIED.value: [OrderStatus.DENIED, OrderStatus.DELETED, OrderStatus.DRAFT],
        OrderStatus.COMPLETED.value: [OrderStatus.COMPLETED, OrderStatus.REJECTED, OrderStatus.FULFILLED],
        OrderStatus.ABANDONED.value: [OrderStatus.ABANDONED, OrderStatus.DELETED, OrderStatus.DRAFT],
        OrderStatus.FULFILLED.value: [OrderStatus.FULFILLED],
        OrderStatus.REJECTED.value: [OrderStatus.REJECTED, OrderStatus.DELETED, OrderStatus.DRAFT],
        OrderStatus.DELETED.value: [OrderStatus.DELETED, OrderStatus.DRAFT],
        OrderStatus.FINANCIAL_HOLD.value: [OrderStatus.COMPLETED, OrderStatus.ABANDONED],
        OrderStatus.PENDING_PAYMENT.value: [OrderStatus.COMPLETED, OrderStatus.FINANCIAL_HOLD],
    }

    def __init__(self, order_id: Optional[str], order_status: Optional[str],  user: Dict):
        if order_id:
            self.order_id = ObjectId(order_id)
        else:
            self.order_id = None

        self.status = order_status
        self.user = user

    def is_valid(self) -> bool:
        if not self.status:
            return True
        if not self.order_id:
            return self.status in [OrderStatus.PENDING_APPROVAL, OrderStatus.DRAFT]

        existing_order = order_repository().get_single(self.order_id)

        is_valid = self.status in self.valid_transitions[existing_order['status']]
        return is_valid

    def is_authorized(self) -> bool:
        if (
            self._is_transition_to(OrderStatus.DRAFT)
            or self._is_transition_to(OrderStatus.PENDING_APPROVAL)
            or self._is_transition_to(OrderStatus.DELETED)
        ):
            return has_role([UserRole.SUPER_ADMIN, UserRole.SALES], self.user)

        elif self._is_transition_to(OrderStatus.APPROVED) or self._is_transition_to(OrderStatus.DENIED):
            return has_role([UserRole.SUPER_ADMIN, UserRole.APPROVER], self.user)

        elif self._is_transition_to(OrderStatus.COMPLETED) or self._is_transition_to(OrderStatus.ABANDONED):
            allowed = [UserRole.SUPER_ADMIN, UserRole.TRANSACTOR]
            existing_order = order_repository().get_single(self.order_id)
            if existing_order['status'] == OrderStatus.FINANCIAL_HOLD:
                allowed.append(UserRole.FINANCE)
            return has_role(allowed, self.user)

        elif self._is_transition_to(OrderStatus.FINANCIAL_HOLD):
            allowed = [UserRole.SUPER_ADMIN, UserRole.TRANSACTOR]
            existing_order = order_repository().get_single(self.order_id)
            if existing_order['status'] == OrderStatus.PENDING_PAYMENT:
                allowed.append(UserRole.FINANCE)
            return has_role(allowed, self.user)

        elif self._is_transition_to(OrderStatus.PENDING_PAYMENT):
            return has_role([UserRole.SUPER_ADMIN, UserRole.FINANCE], self.user)

        elif self._is_transition_to(OrderStatus.FULFILLED) or self._is_transition_to(OrderStatus.REJECTED):
            return has_role(GIVEWITH_ROLES, self.user)

        return False

    def _is_transition_to(self, status: OrderStatus) -> bool:
        return self.status == status.value
