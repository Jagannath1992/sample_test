import json
import requests

from bson import json_util
from os import environ


class EmailService:
    def __init__(self):
        if 'EMAIL_SERVICE_URL' in environ:
            self.email_service_url = environ.get('EMAIL_SERVICE_URL')
        else:
            self.email_service_url = 'http://emailloadbalancer-1769123919.us-east-1.elb.amazonaws.com/email'

        env = environ.get('ENV', 'local')

        append_ocp_prefix = environ.get('APPEND_OCP_PREFIX', 'False')

        if env == 'sandbox':
            self.base_url = 'https://qa.login.scalewith.com'
        elif env == 'production':
            self.base_url = 'https://login.scalewith.com'
        else:
            self.base_url = 'https://dev.login.scalewith.com'

        if append_ocp_prefix == "True":
            if env == 'sandbox':
                self.base_url = 'https://login-ocp.givewithus.com'
            elif env == 'production':
                self.base_url = 'https://login-ocp.givewith.com'
            else:
                self.base_url = 'https://login-ocp.nohardstops.com'

    def send_user_activation_email(self, user_email, activation_code, app):
        payload = {
            'tos': [user_email],
            'template': {
                'id': 'd-346bb8bd80bd4facbd983a43043f73e5',
                'data': {
                    'register-url': self.base_url + '/sign_up?code=' + activation_code + "&email=" + user_email,
                    'app': app
                }
            }
        }

        return requests.post(self.email_service_url, json=json.loads(json_util.dumps(payload)), timeout=3)

    def send_supplier_invite_email(self, user_email, activation_code, customer_name, metadata):
        payload = {
            'tos': [user_email],
            'template': {
                'id': 'd-fe4aebeb741849bea11ecd52d0f69e3b',
                'data': {
                    **metadata,
                    'supplierFirstName': customer_name,
                    'register-url': self.base_url + '/sign_up?code=' + activation_code + "&email=" + user_email,
                }
            }
        }
        return requests.post(self.email_service_url, json=json.loads(json_util.dumps(payload)), timeout=3)

    def send_forget_password_email(self, user_email, reset_password_code, platform):
        reset_password_url = self.base_url + '/reset_password?code=' + \
            reset_password_code + "&email=" + user_email
        payload = {
            'tos': [user_email],
            'template': {
                'id': 'd-e4d42a9ec7d74fa4a443bdc64057f914',
                'data': {
                    'reset-password-url': reset_password_url,
                    'app': platform
                }
            }
        }

        return requests.post(self.email_service_url, json=json.loads(json_util.dumps(payload)), timeout=3)

    def send_migration_email(self, user_email, reset_password_code):
        reset_password_url = self.base_url + '/reset_password?code=' + \
            reset_password_code + "&email=" + user_email
        payload = {
            'tos': [user_email],
            'template': {
                'id': 'd-11fb174e77e5468f9061cae2b591a0c3',
                'data': {
                    'reset-password-url': reset_password_url
                }
            }
        }

        return requests.post(self.email_service_url, json=json.loads(json_util.dumps(payload)), timeout=3)
