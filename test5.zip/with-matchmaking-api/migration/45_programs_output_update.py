from matchmaking import db

default_scale_type = db().coll_vocabulary.find_one({'type': 'scaleType', 'label': 'Proportional'})
default_description = 'Beneficiaries directly served'

for program in db().coll_programs.find({}):
    outputs = program.get('outputs', [])
    outputs_set = {output.get('description', '').lower() for output in outputs}

    if default_description.lower() not in outputs_set:
        outputs.insert(0, {
            'quantity': 0,
            'description': default_description,
            'scaleType': default_scale_type['_id']
        })

    db().coll_programs.update_one({'_id': program['_id']}, {'$set': {'outputs': outputs}})
