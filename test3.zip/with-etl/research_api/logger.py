# in __init__, the werkzeug logger is set up. We should wrap that logger in here in case we want to change how we log in the future
# also, maybe that setup should take place here
from tempfile import TemporaryFile
from datetime import datetime

DEBUG = True

class PipelineLogger:
    "Singleton (sort of) Pipeline logger attached to a pipeline"

    class __impl:
        """ Implementation of the logger singleton """

        def __init__(self, dataset):
            self.dataset = dataset
            self.log_file = None

        def log_exception(self, msg):
            self._log(msg, prefix='[EXCEPTION] ')

        def log_info(self, msg):
            self._log(msg, prefix='[INFO] ')

        def log_error(self, msg):
            self._log(msg, prefix='[ERROR] ')

        def _log(self, msg, prefix=''):
            self.get_log_file().write(f'{prefix}{msg}\n')
            print(f'Source: {self.dataset} -- {msg}')

        def get_log_file(self):
            if not self.log_file:
                self.log_file = TemporaryFile(mode='w+')
            return self.log_file

        def flush(self):
            if self.log_file:
                from research_api.mongodb import db
                # prepare file for read and write contents to database
                self.log_file.seek(0)

                updates = {
                    'type': 'log',
                    'dataset': self.dataset.upper(),
                    'output': self.log_file.read(),
                    'lastRun': datetime.utcnow()
                }

                db().coll_meta.find_one_and_replace({
                    'type': 'log',
                    'dataset': self.dataset.upper()
                }, updates, upsert=True)

                self.log_file.close()
                self.log_file = None

    __instances = {}

    @classmethod
    def get_instance(cls, dataset):
        if dataset not in PipelineLogger.__instances:
            # Create a member instance
            cls.__instances[dataset] = PipelineLogger.__impl(dataset)
        return cls.__instances[dataset]


# TODO: Migrate all data paths to new PipeLine Logger
def log_exception(msg, dataset=''):
    _log(msg, dataset)

def log_info(msg, dataset=''):
    _log(msg, dataset)

def log_error(msg, dataset=''):
    _log(msg, dataset)

def _log(msg, dataset):
    if dataset:
        print(f'Source: {dataset} -- {msg}')
    else:
        print(msg)
