import os
import urllib
from tempfile import TemporaryDirectory, TemporaryFile
import boto3
import botocore
from flask import abort, send_file

from app.constants import ENV, AWS_BUCKET_GREENLIST

ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY')
s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

BUCKET_NAME = ENV + '-simian-media'

def get_bucket_name(url):
    parsed_url = urllib.request.urlparse(url)
    if parsed_url.netloc:
        bucket_name = parsed_url.netloc.split('.')[0]
        if bucket_name not in AWS_BUCKET_GREENLIST:
            abort(404, description='Bucket name: ' + bucket_name + ' is not valid')
    else:
        if os.environ.get('ENV'):
            bucket_name = f'givewith-{ENV}-secure-upload'
        else:
            bucket_name = 'givewith-local-secure-upload'

    return bucket_name

def download_asset(url):
    '''
    Download an asset
    '''
    bucket_name = get_bucket_name(url)

    if '.com' in url:
        file_path = url.split('.com/')[-1]
    else:
        file_path = url

    _fd = TemporaryFile()

    if _download(bucket_name, file_path, _fd):
        return _fd
    else:
        return None

def _download(bucket_name, file_name, _fd):
    '''
    Download helper
    '''
    try:
        s3.download_fileobj(bucket_name, file_name, _fd)
        _fd.seek(0)

        return True
    except botocore.exceptions.ClientError:
        return False


def generate_signed_url(file_name, bucket_name=BUCKET_NAME):
    '''
    Generate a signed url to display or download asset
    '''
    file_path = file_name.split('.com/')[-1]

    url = s3.generate_presigned_url(
        ClientMethod='get_object',
        Params={
            'Bucket': bucket_name,
            'Key': file_path,
        }
    )

    return url


def does_file_exist(url):
    '''
    Check if file exists in bucket. Accepts full or partial URL
    '''
    bucket_name = get_bucket_name(url)
    filename = url.rsplit('.com/', 1)[-1]

    response = s3.list_objects_v2(
        Bucket=bucket_name,
        Prefix=filename,
    )
    for obj in response.get('Contents', []):
        if obj['Key'] == filename:
            return obj['Size'] > 0


def get_file_from_url(url, filename, directory=''):
    """ Accepts full URL, filename and optionally, a specific directory.
        If directory not found, use another temporary directory.
        Save URL into a file to return.
    """
    with TemporaryDirectory() as tmpdirname:
        file_directory = directory or tmpdirname
        f, _ = urllib.request.urlretrieve(url, file_directory + '/' + filename)
        request = send_file(f, as_attachment=True)
        data = {'file': request, 'pathname': f}

    return data
