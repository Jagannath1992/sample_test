#pylint: disable-msg=invalid-name,invalid-string-quote,line-too-long
# -*- coding: utf-8 -*-
import time
import boto3
import os
import logging
import urllib
from flask import current_app, abort
from botocore.exceptions import ClientError
from werkzeug.utils import secure_filename
from flask import current_app

# read access key from environment vals explicitly
load_from_local_config = False
env_lc = os.environ.get('ENV', 'staging').lower()

AWS_BUCKET_GREENLIST = [
    f'{env_lc}-simian-media',
    f'share-actions-{env_lc}',
    f'givewith-{env_lc}-secure-upload',
    'givewith-local-secure-upload',
    'staging-simian-media',
]

try:
    ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID', 'None')
    SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', 'None')
    if ACCESS_KEY == 'None' or SECRET_KEY == 'None': #nosec
        load_from_local_config = True
except Exception as eee:
    load_from_local_config = True

if load_from_local_config:
    # if enviornment vals are not available, instantiate without them,
    # which then will try to read .aws/config in local directory (should work for local, non-docker, installs)
    s3 = boto3.client('s3')
    PRIVATE_BUCKET_NAME = 'givewith-local-secure-upload'
    PUBLIC_BUCKET_NAME = os.environ.get('S3_ASSETS_BUCKET', 'test-data-lake')

else:
    s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)
    PRIVATE_BUCKET_NAME = 'givewith-' + env_lc + '-secure-upload'
    PUBLIC_BUCKET_NAME = 'givewith-campaign-assets.' + env_lc

def get_cnd_url(filename, bucket_name=PUBLIC_BUCKET_NAME):
    return 'https://s3.amazonaws.com/{0}/{1}'.format(bucket_name, filename)


def upload_file(file, filename, is_public=False, custom_file_type=False):
    filename = "{0}_{2}.{1}".format(*filename.rsplit('.', 1) + [int(round(time.time() * 1000))])

    bucket_name = PUBLIC_BUCKET_NAME if is_public else PRIVATE_BUCKET_NAME
    file_privacy = 'public-read' if is_public else 'private'

    s3.upload_fileobj(file, bucket_name, filename,
                      ExtraArgs={'ACL': file_privacy, 'ContentType': custom_file_type or file.content_type})
    if is_public:
        return get_cnd_url(filename, bucket_name)
    else:
        return filename

def delete_file(entity, _id, filename, is_public=False):
    bucket_name = PUBLIC_BUCKET_NAME if is_public else PRIVATE_BUCKET_NAME

    try:
        response = s3.delete_object(Bucket=bucket_name, Key='%s/%s/%s' % (entity, _id, secure_filename(filename)))
        return response['ResponseMetadata']['HTTPStatusCode'] == 204
    except ClientError:
        current_app.logger.exception('Unable to delete S3 file')
        return False

def copy_file(source_filename, dest_filename, is_public=False):
    """Copies a File already uploaded to s3 to a new specified url

    Arguments:
        source_filename {string} -- source filename, format: /entity/_id/filename.ext
        dest_filename {string} -- destination filename, format: /entity/_id/filename.ext
    """
    bucket_name = PUBLIC_BUCKET_NAME if is_public else PRIVATE_BUCKET_NAME
    s3.copy_object(
        ACL='public-read' if is_public else 'private',
        Bucket=bucket_name,
        CopySource={'Bucket': bucket_name, 'Key': source_filename},
        Key=dest_filename
    )
    return get_cnd_url(dest_filename, bucket_name)


def download_file(source_file_key, _fd, is_public=False):
    bucket_name = PUBLIC_BUCKET_NAME if is_public else PRIVATE_BUCKET_NAME
    try:
        s3.download_fileobj(bucket_name, source_file_key, _fd)
        _fd.seek(0)
        return True
    except ClientError as error:
        current_app.logger.exception(error)
        return False

def save_deliverables_file_to_s3(filename, deal_id):
    file = open(filename, 'rb')
    unique = str(int(round(time.time() * 1000)))
    filename = filename.replace('/tmp/', 'deliverables/' + deal_id + '/' + unique + "_") # nosec
    bucket_name = PRIVATE_BUCKET_NAME
    msg = 'save_deliverables_file_to_s3 ' + bucket_name + ' ' + filename
    logging.getLogger('MM-API').info(msg)
    current_app.logger.info(msg)
    s3.upload_fileobj(file, bucket_name, filename,
                      ExtraArgs={'ACL': 'private', 'ContentType': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'})
    return filename

def save_custom_deliverable_to_s3(file, filename):
    bucket_name = PRIVATE_BUCKET_NAME
    s3.upload_fileobj(file, bucket_name, filename,
                      ExtraArgs={'ACL': 'private', 'ContentType': file.content_type})
    return filename


def download_deliverable(which_file, _fd):
    bucket_name = PRIVATE_BUCKET_NAME
    try:
        s3.download_fileobj(bucket_name, which_file, _fd)
        _fd.seek(0)

        return True
    except ClientError as error:
        current_app.logger.exception(error)
        return False

def load_file(key):
    return s3.get_object(Bucket=PUBLIC_BUCKET_NAME, Key=key)['Body']

def get_bucket_name_from_url(url):
    parsed_url = urllib.request.urlparse(url)
    if parsed_url.netloc:
        bucket_name = parsed_url.netloc.split('.')[0]
        if bucket_name not in AWS_BUCKET_GREENLIST:
            abort(404, description='Bucket name: ' + bucket_name + ' is not valid')
    else:
        env = os.environ.get('ENV')
        if env:
            bucket_name = f'givewith-{env}-secure-upload'
        else:
            bucket_name = 'givewith-local-secure-upload'

    return bucket_name

def does_file_exist(url):
    '''
    Check if file exists in bucket. Accepts full or partial URL
    '''
    bucket_name = get_bucket_name_from_url(url)
    filename = url.rsplit('.com/', 1)[-1]

    response = s3.list_objects_v2(
        Bucket=bucket_name,
        Prefix=filename,
    )

    for obj in response.get('Contents', []):
        if obj['Key'] == filename:
            return obj['Size'] > 0
