# TODO: Move all models dealing with nonprofits to this file
from .models import (type_multiselect, schema_multiselect, schema_file, type_file, type_multi_input, to_bool,
                     schema_multi_input, to_number_without_commas, type_object_id, to_object_id_or_str, to_object_id,
                     type_datetime, to_datetime, REGEX_VALID_EMAIL)

def validate_itemization(funding_amount, required):
    def validator(field, value, error):
        value_list = value.get('value', [])
        value_sum = round(sum([to_number_without_commas(v.get('quantity', 0)) for v in value_list]), 2)

        # validate if required or if a value has been entered and funding_amount > 0
        if (required or value_list) and funding_amount > 0 and value_sum != funding_amount:
            error(field, 'itemization quantities not equal to funding amount')

    return validator

# -- Nonprofit Survey Models --------------------------------------------------
def funding_form_model(set_required=False, set_empty=True, dependencies={}, is_normalization=False):
    # normalization rules if attempt to normalization
    def multi_select_schema_descriptor(set_req=False, set_emp=True):
        if is_normalization:
            norm_rules = {'type': type_object_id, 'coerce': to_object_id_or_str}
            return {'schema': schema_multiselect(set_req, set_emp, norm_rules)[0]}

        # contents of anyof_schema cannot be normalized according to cerberus docs
        return {'anyof_schema': schema_multiselect(set_req, set_emp)}

    def multi_input_schema_descriptor(set_req=False, set_emp=True):
        if is_normalization:
            norm_rules = {'type': 'number', 'coerce': to_number_without_commas}
            return {'schema': schema_multi_input(set_req, set_emp, norm_rules)}

        return {'schema': schema_multi_input(set_req, set_emp)}

    return {
        'Funding': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'programDate': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'start': {'type': type_datetime, 'required': set_required, 'empty': set_empty, 'coerce': to_datetime},
                'end': {'type': type_datetime, 'required': set_required, 'empty': set_empty, 'coerce': to_datetime}
            }},
            'location': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'itemization': {
                'type': 'dict', 'required': dependencies.get('itemization', False),
                'empty': not dependencies.get('itemization', False),
                'validator': validate_itemization(dependencies.get('fundingAmount', 0),
                                                  dependencies.get('itemization', False)),
                'schema': {
                    'value': {
                        'type': 'list', 'required': dependencies.get('itemization', False),
                        'empty': not dependencies.get('itemization', False),
                        'schema': {
                            'type': type_multi_input, 'required': dependencies.get('itemization', False),
                            'empty': not dependencies.get('itemization', False),
                            **multi_input_schema_descriptor(dependencies.get('itemization', False),
                                                            not dependencies.get('itemization', False))
                        }
                    },
                }
            },
        }},
        'General': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'contact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'name': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'email': {'type': 'string', 'required': set_required, 'empty': set_empty, 'regex': REGEX_VALID_EMAIL},
                'phone': {'type': 'string', 'required': set_required, 'empty': set_empty},
            }},
            'name': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'internalProgramName': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'platformProgramName': {'type': 'string', 'required': set_required, 'empty': set_empty},
            }},
            'description': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }}
        }},
        'ImpactAndScope': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'causeAreas': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'primaryImpact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'secondaryImpact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            # these are optional question -> required if primaryImpact and secondaryImpact
            # has certain values determined by dependencies dict in survey_meta_data -> defaults to False
            'protectAndEnhanceForest': {
                'type': 'dict', 'required': dependencies.get('protectAndEnhanceForest', False),
                'empty': not dependencies.get('protectAndEnhanceForest', False),
                'schema': {
                    'value': {
                        'type': 'boolean', 'required': dependencies.get('protectAndEnhanceForest', False),
                        'empty': not dependencies.get('protectAndEnhanceForest', False),
                        'coerce': to_bool
                    }
                }
            },
            'animalHabitat': {
                'type': 'dict', 'required': dependencies.get('animalHabitat', False),
                'empty': not dependencies.get('animalHabitat', False),
                'schema': {
                    'value': {
                        'type': type_object_id, 'required': dependencies.get('animalHabitat', False),
                        'empty': not dependencies.get('animalHabitat', False), 'coerce': to_object_id
                    }
                }
            },
            'targetAttributes': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                },
                'optional': {'type': 'string'}
            }},
            'targetAge': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                },
            }}
        }},
        'StrategiesAndApproaches': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'strategies': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'activities': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'approachDuration': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': type_object_id, 'required': set_required, 'empty': set_empty, 'coerce': to_object_id}
            }},
            'activitiesFrequency': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'outputs': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'list', 'required': set_required, 'empty': set_empty, 'schema': {
                    'type': type_multi_input, 'required': set_required, 'empty': set_empty,
                    **multi_input_schema_descriptor(set_required, set_empty)
                }},
            }},
            'outcomes': {'type': 'dict', 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'list', 'schema': {
                    'type': type_multi_input, 'schema': schema_multi_input()
                }},
            }},
            'resultsMeasurement': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': type_object_id, 'required': set_required, 'empty': set_empty, 'coerce': to_object_id},
                'optional': {'type': 'string'}
            }},
            'nonprofitPartners': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'boolean', 'required': set_required, 'empty': set_empty, 'coerce': to_bool},
            }},
        }},
        'ResearchAndEvaluation': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'researchFile': {'type': 'dict', 'schema': {
                'value': {'type': type_file, 'schema': schema_file()}
            }},
            'evidenceDescription': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'studyDescription': {
                'type': 'dict', 'required': dependencies.get('studyDescription', False),
                'empty': not dependencies.get('studyDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('studyDescription', False),
                        'empty': not dependencies.get('studyDescription', False),
                        **multi_select_schema_descriptor(dependencies.get('studyDescription', False),
                                                         not dependencies.get('studyDescription', False))
                    }
                }
            },
            'dataDescription': {
                'type': 'dict', 'required': dependencies.get('dataDescription', False),
                'empty': not dependencies.get('dataDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('dataDescription', False),
                        'empty': not dependencies.get('dataDescription', False),
                        **multi_select_schema_descriptor(dependencies.get('dataDescription', False),
                                                         not dependencies.get('dataDescription', False))
                    }
                }
            },
            'outcomeDescription': {
                'type': 'dict', 'required': dependencies.get('outcomeDescription', False),
                'empty': not dependencies.get('outcomeDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('outcomeDescription', False),
                        'empty': not dependencies.get('outcomeDescription', False),
                        **multi_select_schema_descriptor(dependencies.get('outcomeDescription', False),
                                                         not dependencies.get('outcomeDescription', False))
                    }
                }
            },
            'researchApproaches': {
                'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                    'value': {
                        'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                        **multi_select_schema_descriptor(set_required, set_empty)
                    }
                }
            },
            'strength': {
                'type': 'dict', 'required': dependencies.get('strength', False),
                'empty': not dependencies.get('strength', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('strength', False),
                        'empty': not dependencies.get('strength', False),
                        **multi_select_schema_descriptor(dependencies.get('strength', False),
                                                         not dependencies.get('strength', False))
                    }
                }
            },
        }}
    }

schema_funding_form_client = {
    'signature': {'type': 'dict', 'empty': False, 'schema': {
        'name': {'type': 'string', 'required': True, 'empty': False},
        'email': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_EMAIL},
    }},
}

# Program completion report - model
def completion_form_model(set_required=False, set_empty=True, dependencies={}, is_normalization=False):
    # normalization rules if attempt to normalization
    def multi_select_schema_descriptor(set_req=False, set_emp=True):
        if is_normalization:
            norm_rules = {'type': type_object_id, 'coerce': to_object_id_or_str}
            return {'schema': schema_multiselect(set_req, set_emp, norm_rules)[0]}

        # contents of anyof_schema cannot be normalized according to cerberus docs
        return {'anyof_schema': schema_multiselect(set_req, set_emp)}

    def multi_input_schema_descriptor(set_req=False, set_emp=True):
        if is_normalization:
            norm_rules = {'type': 'number', 'coerce': to_number_without_commas}
            return {'schema': schema_multi_input(set_req, set_emp, norm_rules)}

        return {'schema': schema_multi_input(set_req, set_emp)}

    return {
        'Funding': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'programDate': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'start': {'type': type_datetime, 'required': set_required, 'empty': set_empty, 'coerce': to_datetime},
                'end': {'type': type_datetime, 'required': set_required, 'empty': set_empty, 'coerce': to_datetime}
            }},
            'location': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'itemization': {
                'type': 'dict', 'required': dependencies.get('itemization', False),
                'empty': not dependencies.get('itemization', False),
                'validator': validate_itemization(dependencies.get('fundingAmount', 0),
                                                  dependencies.get('itemization', False)),
                'schema': {
                    'value': {
                        'type': 'list', 'required': dependencies.get('itemization', False),
                        'empty': not dependencies.get('itemization', False),
                        'schema': {
                            'type': type_multi_input, 'required': dependencies.get('itemization', False),
                            'empty': not dependencies.get('itemization', False),
                            **multi_input_schema_descriptor(dependencies.get('itemization', False),
                                                            not dependencies.get('itemization', False))
                        }
                    },
                }
            },
        }},
        'General': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'contact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'name': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'email': {'type': 'string', 'required': set_required, 'empty': set_empty, 'regex': REGEX_VALID_EMAIL},
                'phone': {'type': 'string', 'required': set_required, 'empty': set_empty},
            }},
            'name': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'internalProgramName': {'type': 'string', 'required': set_required, 'empty': set_empty},
                'platformProgramName': {'type': 'string', 'required': set_required, 'empty': set_empty},
            }},
            'description': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }}
        }},
        'ImpactAndScope': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'causeAreas': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'primaryImpact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'secondaryImpact': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            # these are optional question -> required if primaryImpact and secondaryImpact
            # has certain values determined by dependencies dict in survey_meta_data -> defaults to False
            'protectAndEnhanceForest': {
                'type': 'dict', 'required': dependencies.get('protectAndEnhanceForest', False),
                'empty': not dependencies.get('protectAndEnhanceForest', False),
                'schema': {
                    'value': {
                        'type': 'boolean', 'required': dependencies.get('protectAndEnhanceForest', False),
                        'empty': not dependencies.get('protectAndEnhanceForest', False),
                        'coerce': to_bool
                    }
                }
            },
            'animalHabitat': {
                'type': 'dict', 'required': dependencies.get('animalHabitat', False),
                'empty': not dependencies.get('animalHabitat', False),
                'schema': {
                    'value': {
                        'type': type_object_id, 'required': dependencies.get('animalHabitat', False),
                        'empty': not dependencies.get('animalHabitat', False), 'coerce': to_object_id
                    }
                }
            },
            'targetAttributes': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                },
                'optional': {'type': 'string'}
            }},
            'targetAge': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                },
            }}
        }},
        'StrategiesAndApproaches': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'strategies': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'activities': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'approachDuration': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': type_object_id, 'required': set_required, 'empty': set_empty, 'coerce': to_object_id}
            }},
            'activitiesFrequency': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'string', 'required': set_required, 'empty': set_empty}
            }},
            'outputs': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'list', 'required': set_required, 'empty': set_empty, 'schema': {
                    'type': type_multi_input, 'required': set_required, 'empty': set_empty,
                    **multi_input_schema_descriptor(set_required, set_empty)
                }},
            }},
            'outcomes': {'type': 'dict', 'schema': {
                'optional': {'type': 'string'},
                'value': {'type': 'list', 'schema': {
                    'type': type_multi_input, 'schema': schema_multi_input()
                }},
            }},
            'resultsMeasurement': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': type_object_id, 'required': set_required, 'empty': set_empty, 'coerce': to_object_id},
                'optional': {'type': 'string'}
            }},
            'nonprofitPartners': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {'type': 'boolean', 'required': set_required, 'empty': set_empty, 'coerce': to_bool},
            }},
        }},
        'ResearchAndEvaluation': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'researchFile': {'type': 'dict', 'schema': {
                'value': {'type': type_file, 'schema': schema_file()}
            }},
            'evidenceDescription': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                'value': {
                    'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                    **multi_select_schema_descriptor(set_required, set_empty)
                }
            }},
            'studyDescription': {
                'type': 'dict', 'required': dependencies.get('studyDescription', False),
                'empty': not dependencies.get('studyDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('studyDescription', False),
                        'empty': not dependencies.get('studyDescription', False),
                        **multi_select_schema_descriptor(dependencies.get('studyDescription', False),
                                                         not dependencies.get('studyDescription', False))
                    }
                }
            },
            'dataDescription': {
                'type': 'dict', 'required': dependencies.get('dataDescription', False),
                'empty': not dependencies.get('dataDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('dataDescription', False),
                        'empty': not dependencies.get('dataDescription', False),
                        **multi_select_schema_descriptor(dependencies.get('dataDescription', False),
                                                         not dependencies.get('dataDescription', False))
                    }
                }
            },
            'outcomeDescription': {
                'type': 'dict', 'required': dependencies.get('outcomeDescription', False),
                'empty': not dependencies.get('outcomeDescription', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('outcomeDescription', False),
                        'empty': not dependencies.get('outcomeDescription', False),
                        **multi_select_schema_descriptor(dependencies.get('outcomeDescription', False),
                                                         not dependencies.get('outcomeDescription', False))
                    }
                }
            },
            'researchApproaches': {
                'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
                    'value': {
                        'type': type_multiselect, 'required': set_required, 'empty': set_empty,
                        **multi_select_schema_descriptor(set_required, set_empty)
                    }
                }
            },
            'strength': {
                'type': 'dict', 'required': dependencies.get('strength', False),
                'empty': not dependencies.get('strength', False),
                'schema': {
                    'value': {
                        'type': type_multiselect, 'required': dependencies.get('strength', False),
                        'empty': not dependencies.get('strength', False),
                        **multi_select_schema_descriptor(dependencies.get('strength', False),
                                                         not dependencies.get('strength', False))
                    }
                }
            },
        }},
        'Completion': {'type': 'dict', 'required': set_required, 'empty': set_empty, 'schema': {
            'adjustments': {'type': 'string', 'required': set_required, 'empty': set_empty},
            'stories': {'type': 'string', 'required': set_required, 'empty': set_empty}
        }}
    }


schema_completion_form_client = {
    'signature': {'type': 'dict', 'empty': False, 'schema': {
        'name': {'type': 'string', 'required': True, 'empty': False},
        'email': {'type': 'string', 'required': True, 'empty': False, 'regex': REGEX_VALID_EMAIL}
    }},
}
