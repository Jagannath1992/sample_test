# -*- coding: utf-8 -*-
from copy import deepcopy
from bson.errors import InvalidId
from flask import jsonify, request, current_app
from pymongo import ReturnDocument
from pymongo.collation import Collation
from ...controllers import admin_bp
from ...models.models import v, schema_funding_form, Currency
from ...models.nonprofit import funding_form_model
from ...mongodb import ObjectId, get_nonprofit, db, get_deal, get_mm_brand, get_program, get_user, get_funding_form
from ...utils import (set_last_updated, set_created_at, get_locale_string, EntityNotFound, UnsupportedId, send_loggly,
                      UnsupportedPayload, ValidationError, SurveyStatus, generate_random_slug, GivewithError,
                      convert_program_to_survey, get_deep_diff, remove_empty, get_descendant_key)
from ...permission_decorator import require_admin_permission
from ..commerce.survey import calculate_progress, calculate_percent_complete
from ..commerce.utils import transform_outputs_to_commerce_outputs_v2
from ...s3 import delete_file, save_custom_deliverable_to_s3
from werkzeug.utils import secure_filename

ENTITY_NAME = 'funding_form'

##
# Protected Endpoints
##
@admin_bp.route('/funding-forms', methods=['GET'])
@require_admin_permission
def admin_list_funding_forms():
    """
    List all available Funding Forms

    """
    projection = {
        'name' : True,
        '_id': True,
        'status': True,
        'percentComplete': True,
        'program': True,
        'givewithCustomer': True,
        'client': True,
        'nonprofitName': True,
        'deal': True,
        'nonprofit': True,
        'givewithAdmin': True,
    }

    funding_forms = list(db().coll_program_funding_forms
                         .find(request.filter_params, projection=projection)
                         .skip(request.skip).limit(request.page_size)
                         .collation(Collation(locale=get_locale_string(), numericOrdering=True))
                         .sort(request.sort_params))

    for form in funding_forms:
        add_names_and_currency(form, False, True)

    return jsonify(funding_forms)


@admin_bp.route('/funding-forms/<id>', methods=['GET'])
@require_admin_permission
def get_funding_form_by_id(id):
    """
    Fetch Funding Form data

    """
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    funding_form = db().coll_program_funding_forms.find_one({'_id': obj_id})
    if not funding_form:
        raise EntityNotFound(ENTITY_NAME, id)

    funding_form = add_names_and_currency(funding_form, True, False)

    if funding_form['status'] == str(SurveyStatus.SUBMITTED):
        program = db().coll_programs.find_one({'_id': funding_form['program']})

        form_model = funding_form_model(is_normalization=True)
        clean_funding_form = v.normalized(funding_form, form_model)
        clean_program = v.normalized(convert_program_to_survey({}, program, stringify=False), form_model)

        funding_form['diff'] = get_deep_diff(clean_funding_form, clean_program)

    return jsonify(funding_form)

@admin_bp.route('/funding-forms', methods=['POST'])
@require_admin_permission
def insert_funding_form(funding_form=None):
    """
    Create new Funding Form

    """

    if funding_form:
        document = funding_form
    else:
        document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    document.pop('_id', None)

    document['slug'] = generate_random_slug()

    deal_id = document.get('deal')
    deal = get_deal(ObjectId(deal_id), projection={'selectedProgram': True,
                                                   'givewithCustomer': True,
                                                   'fundingAmount': True,
                                                   'currency': True,
                                                   'client': True})

    program_id = deal.get('selectedProgram')
    document['program'] = program_id
    program = get_program(program_id)

    document['objects'] = program.get('outputs', [])
    transform_outputs_to_commerce_outputs_v2(document['objects'],
                                             program.get('budget'),
                                             program.get('currency', str(Currency.USD)),
                                             deal.get('fundingAmount', 0),
                                             deal.get('currency', str(Currency.USD)),
                                             True)

    nonprofit_id = program.get('nonprofit')
    nonprofit = get_nonprofit(nonprofit_id, projection={'slug': True, 'givewithAdmin': True})
    document['nonprofitSlug'] = nonprofit.get('slug')
    document['nonprofit'] = nonprofit_id

    document['givewithCustomer'] = deal.get('givewithCustomer')
    document['client'] = deal.get('client')

    document['editing'] = True
    document['status'] = str(SurveyStatus.IN_PROGRESS)
    document['percentComplete'] = 0 # to pass validation, to be updated later

    document['givewithAdmin'] = nonprofit.get('givewithAdmin') or program.get('givewithAdmin') or document.get('userId')

    v.validate(document, schema_funding_form)
    if v.errors:
        raise ValidationError(v.errors)

    # only need existing program fields -> hence, blank copy of survey is passed
    # NOTE: program is modified by this function
    program_copy = convert_program_to_survey({}, program, stringify=False)

    form_model = funding_form_model(is_normalization=True)
    document.update(v.normalized(program_copy, form_model)) # normalize to keep only PFF form fields

    schema = {**schema_funding_form, **form_model}
    document = v.normalized(document, schema)
    if v.errors:
        raise ValidationError(v.errors)

    progress, incomplete_fields = calculate_progress('PFF', document)
    document['percentComplete'] = calculate_percent_complete(progress)

    inserted_id = db().coll_program_funding_forms.insert_one(set_created_at(document)).inserted_id
    document['_id'] = inserted_id

    return jsonify(document)


@admin_bp.route('/funding-forms/<id>', methods=['POST'])
@require_admin_permission
def approve_funding_form(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    funding_form = db().coll_program_funding_forms.find_one({'_id': obj_id})
    if not funding_form:
        raise EntityNotFound(ENTITY_NAME, id)

    status = funding_form.get('status')
    if status != str(SurveyStatus.SUBMITTED):
        raise GivewithError(f'Cannot approve funding form with {status} status', code=400)


    funding_form['status'] = str(SurveyStatus.APPROVED)
    funding_form['programDescription'] = funding_form['General']['description']['value']

    program = get_program(funding_form['program'], projection={'outputs': True, 'programNameTitleCase': True, 'programNameLowerCase': True})
    funding_form_outputs = get_descendant_key(funding_form, 'StrategiesAndApproaches.outputs.value', [])
    funding_form['objects'] = merge_output_values(funding_form_outputs, program.get('outputs'))
    funding_form['programNameTitleCase'] = program.get('programNameTitleCase', '')
    funding_form['programNameLowerCase'] = program.get('programNameLowerCase', '')

    updated_document = db().coll_program_funding_forms.find_one_and_update(filter={'_id': obj_id},
                                                                           return_document=ReturnDocument.AFTER,
                                                                           update={
                                                                               '$set': set_last_updated(funding_form)
                                                                           })

    if not updated_document:
        updated_document = funding_form
        current_app.logger.warning('Unable to update funding form with id %s', str(obj_id))

    send_loggly(
        f'ADMIN-PFF: FORM WITH ID: {updated_document.get("_id")} APPROVED '
        f'BY USER WITH ID: {request.user.get("_id")}'
    )

    updated_document = add_names_and_currency(updated_document, True, False)

    return jsonify(updated_document)

@admin_bp.route('/funding-forms/<id>', methods=['PUT'])
@require_admin_permission
def update_funding_form(id):

    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    document = request.get_json()

    if not document:
        raise UnsupportedPayload()

    # concat two objects together to validate/normalize
    validation_schema = {**schema_funding_form, **funding_form_model()}
    v.validate(document, validation_schema)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    if document['editing'] and document['status'] != str(SurveyStatus.IN_PROGRESS):
        document['status'] = str(SurveyStatus.IN_PROGRESS)

        send_loggly(
            f'ADMIN-PFF: EDITING TOGGLED "ON" ON FORM WITH ID: {document.get("_id")} '
            f'BY USER WITH ID: {request.user.get("_id")}'
        )

    normalization_schema = {**schema_funding_form, **funding_form_model(is_normalization=True)}
    document = v.normalized(document, normalization_schema)
    if v.errors:
        raise ValidationError(v.errors, code=400)

    remove_empty(document)

    document.pop('lastUpdated', None)
    document.pop('_id', None)

    updated_document = db().coll_program_funding_forms.find_one_and_update(filter={'_id': obj_id},
                                                                           update={'$set': set_last_updated(document)},
                                                                           return_document=ReturnDocument.AFTER)

    if not updated_document:
        updated_document = document
        current_app.logger.warning('Unable to update funding form with id %s', str(obj_id))

    updated_document['_id'] = obj_id

    updated_document = add_names_and_currency(updated_document, True, False)

    return jsonify(updated_document)


@admin_bp.route('/funding-forms/<id>/upload', methods=['POST'])
@require_admin_permission
def upload_deliverable_to_funding_form(id):

    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    if 'file' not in request.files:
        raise UnsupportedPayload()

    file = request.files['file']
    if file.name == '':
        raise UnsupportedPayload()

    path = request.form.get('field')
    deal_id = request.form.get('dealId')

    url = save_custom_deliverable_to_s3(file, 'deliverables/%s/%s' % (deal_id, secure_filename(file.filename)))
    funding_form = get_funding_form(obj_id, projection={'deliverables': True})

    deliverables = funding_form.get('deliverables')
    for index, d in enumerate(deliverables):
        if d['name'] == path:
            deliverables[index]['url'] = url

    funding_form['deliverables'] = deliverables

    updated_document = db().coll_program_funding_forms.find_one_and_update(filter={'_id': obj_id},
                                                                           update={'$set': set_last_updated(funding_form)},
                                                                           return_document=ReturnDocument.AFTER)

    updated_document['_id'] = obj_id

    return jsonify(updated_document)

@admin_bp.route('/funding-forms/<id>', methods=['DELETE'])
@require_admin_permission
def delete_funding_form(id):
    try:
        obj_id = ObjectId(id)
    except InvalidId:
        raise UnsupportedId(id)

    deleted_document = db().coll_program_funding_forms.find_one_and_delete({'_id': obj_id})

    send_loggly(
        f'ADMIN-PFF: FORM WITH ID: {deleted_document.get("_id")} DELETED '
        f'BY USER WITH ID: {request.user.get("_id")}'
    )

    return jsonify(deleted_document)


def add_names_and_currency(funding_form, get_currency=True, get_admin=False):
    # deal name
    deal_id = funding_form.get('deal')
    deal = get_deal(deal_id, projection={'name': True,
                                         'reference': True,
                                         'fundingAmount': True,
                                         'currency': True})
    if deal:
        funding_form['dealName'] = deal.get('name') or deal.get('reference')

        if get_currency:
            funding_form['fundingAmount'] = deal.get('fundingAmount')
            funding_form['currency'] = deal.get('currency')


        funding_form['fundingAmount'] = deal.get('fundingAmount')
        funding_form['currency'] = deal.get('currency')

    # program name
    program = get_program(funding_form.get('program'), projection={'name': True,
                                                                   'description': True})
    funding_form['programName'] = program.get('name')

    # nonprofit name
    nonprofit = get_nonprofit(funding_form.get('nonprofit'), projection={'name': True,
                                                                         'slug': True})
    funding_form['nonprofitName'] = nonprofit['name']

    # give with customer name
    customer = funding_form.get('givewithCustomer')
    givewith_customer_brand = get_mm_brand(customer, projection={'name': True, 'nameLabel': True})
    name = givewith_customer_brand.get('nameLabel') or givewith_customer_brand.get('name')
    funding_form['givewithCustomerName'] = name

    # client name
    client_brand = get_mm_brand(funding_form.get('client'), projection={'name': True,
                                                                        'nameLabel': True})
    client_name = client_brand.get('nameLabel') or client_brand.get('name')
    funding_form['clientName'] = client_name

    if get_admin:
        givewith_admin_id = funding_form.get('givewithAdmin')
        givewith_admin_object = get_user(givewith_admin_id, projection={'name': True}) or {}
        funding_form['givewithAdminName'] = givewith_admin_object.get('name', '')

    return funding_form


def merge_output_values(funding_form_outputs, program_outputs):
    final_outputs = []
    for (index, f_output) in enumerate(funding_form_outputs):
        if (len(program_outputs) > index):
            f_output['verb'] = program_outputs[index].get('verb', '')
            f_output['targetPlural'] = program_outputs[index].get('targetPlural', '')
            f_output['targetSingular'] = program_outputs[index].get('targetSingular', '')

        final_outputs.append(f_output)

    return final_outputs
