from matchmaking import db

db().coll_brands.update_many({}, {'$set': {'paymentOption': 'payAsYouGo'}})

