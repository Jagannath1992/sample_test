from marshmallow import fields, Schema, validate, post_load

from portal.shared.custom_fields import ObjectIdField
from portal.shared.schema import EntitySchema, SearchRequestBaseSchema, SearchRequestSchema, SearchResponseSchema, OrderedSchema


class CauseAreaSchema(EntitySchema):
    """Cause Area model"""
    name = fields.String(required=True)
    partnerName = fields.String(required=True)
    description = fields.String(required=True, validate=validate.Length(max=300))
    tooltip = fields.String(required=True)
    listImageName = fields.String(required=True)
    detailImageName = fields.String(allow_none=True)
    detailLinkText = fields.String(required=True)
    detailLinkUrl = fields.Url(required=True)
    sageVendorId = fields.String(required=True)
    skuPrefix = fields.String(required=True)
    active = fields.Boolean(required=True)
    instanceCount = fields.Integer()


class SkuSchema(Schema):  # TODO: EntitySchema
    """SKU model"""
    id = fields.String(attribute='_id')
    name = fields.String()
    description = fields.String()
    unitCost = fields.Number()
    currency = fields.String()


class CauseAreaRequest(CauseAreaSchema):
    """Request model for GET/POST/PUT Cause Area"""
    class Meta:
        exclude = ('instanceCount', 'id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated')


class CauseAreaResponse(CauseAreaSchema):
    """Response model for GET/POST/PUT Cause Area responses"""
    pass


class SkuResponse(SkuSchema):
    """Response model for GET/POST/PUT SKU responses"""
    pass


class CauseAreaSearchRequest(SearchRequestSchema):
    """Request model for cause area search"""
    id = ObjectIdField(attribute='_id', allow_none=True)
    accountId = ObjectIdField(allow_none=True)
    name = fields.String(allow_none=True)
    description = fields.String(allow_none=True)
    partnerName = fields.String(allow_none=True)
    tooltip = fields.String(allow_none=True)
    listImageName = fields.String(allow_none=True)
    detailImageName = fields.String(allow_none=True)
    detailLinkText = fields.String(allow_none=True)
    detailLinkUrl = fields.Url(allow_none=True)
    sageVendorId = fields.String(allow_none=True)
    skuPrefix = fields.String(allow_none=True)
    instanceCount = fields.Integer(allow_none=True)
    createdBy = fields.String(allow_none=True)
    createdAtFrom = fields.DateTime(allow_none=True)
    createdAtTo = fields.DateTime(allow_none=True)
    lastUpdatedFrom = fields.DateTime(allow_none=True)
    lastUpdatedTo = fields.DateTime(allow_none=True)
    lastUpdatedBy = fields.String(allow_none=True)
    active = fields.Boolean(allow_none=True)

    class Meta:
        contains_fields = ['name', 'description', 'partnerName', 'tooltip', 'listImageName',
                           'detailLinkText', 'detailLinkUrl', 'sageVendorId', 'skuPrefix', 'createdBy', 'lastUpdatedBy']
        range_fields = ['createdAt', 'lastUpdated', 'instanceCount']


class CauseAreaSearchResponse(SearchResponseSchema):
    """Response model for cause area search"""
    results = fields.List(fields.Nested(CauseAreaSchema), required=True)


class CauseAreaMetricsRequest(SearchRequestBaseSchema):
    """Cause Area Metrics"""
    lastUpdatedFrom = fields.DateTime(allow_none=True)
    lastUpdatedTo = fields.DateTime(allow_none=True)
    causeAreas = fields.List(ObjectIdField, allow_none=True)
    instances = fields.List(ObjectIdField, allow_none=True)
    instanceType = fields.String(allow_none=True)
    locales = fields.List(ObjectIdField, allow_none=True)
    industries = fields.List(fields.String, allow_none=True)
    accounts = fields.List(ObjectIdField, allow_none=True)
    accountType = fields.String(allow_none=True)
    active = fields.List(fields.Boolean, allow_none=True)

    class Meta:
        in_fields = ['causeAreas', 'locales', 'instances', 'industries', 'accounts', 'active']
        range_fields = ['lastUpdated']

    def _convert_nested(self, key):
        if key == 'causeAreas':
            return 'causeArea._id'
        if key == 'locales':
            return 'loc._id'
        if key == 'instances':
            return 'inst._id'
        if key == 'instanceType':
            return 'inst.type'
        if key == 'accounts':
            return 'account._id'
        if key == 'accountType':
            return 'acct.type'
        if key == 'industries':
            return 'acct.industry.subIndustry'
        if key == 'active':
            return 'ca.active'
        return key


class MetricsGroupKey(OrderedSchema):
    causeArea = fields.String()
    causeAreaUrl = fields.String()
    currency = fields.String()
    currencySymbol = fields.String()


class MetricsDetail(OrderedSchema):
    status = fields.String()
    totalDealAmount = fields.Number()
    totalGiveAmount = fields.Number()
    totalGivePercent = fields.Number()
    count = fields.Number()
    mostGives = fields.Email()


class MetricsResult(OrderedSchema):
    key = fields.Nested(MetricsGroupKey, attribute='_id')
    avgDealAmount = fields.Number()
    avgGiveAmount = fields.Number()
    avgGivePercent = fields.Number()
    winRate = fields.Number(default=0)
    impact = fields.Number()
    impactMeasurement = fields.String()
    details = fields.List(fields.Nested(MetricsDetail))


class MetricsCurrency(OrderedSchema):
    currency = fields.String()
    symbol = fields.String()


class CauseAreaMetricsResponse(OrderedSchema):
    """Response model for cause area metrics"""
    results = fields.List(fields.Nested(MetricsResult))
    currencies = fields.List(fields.Nested(MetricsCurrency))
