from bson import ObjectId

from portal.features.error_logs.schema import ErrorLogSearchRequest

class TestErrorLogSearchRequest:
    def test_load_error_log_ids(self):
        data = {
            'count': 10,
            'orderBy': 'decending',
            'offset': 0,
            'accountId': str(ObjectId()),
            'orderId': str(ObjectId()),
            'transactionId': str(ObjectId())
        }

        response = ErrorLogSearchRequest().load(data)

        assert not response.get('orderId')
        assert not response.get('accountId')
        assert not response.get('transactionId')
        assert response['account._id'] == ObjectId(data['accountId'])
        assert response['order._id'] == ObjectId(data['orderId'])
        assert response['transaction._id'] == ObjectId(data['transactionId'])
        assert response['orderBy'] == 'decending'


