import pytest
import pandas as pd
from portal.shared.repositories import account_repository, transaction_repository, order_repository, user_repository
from portal.shared.constants import MONTH_END_TABLE
from portal.shared.services import transaction_service

class TestTransactionsService:

    def test_monthly_reconciliation_data(self, fakers):
        orders = fakers.order.generate_many(3)
        test_table = MONTH_END_TABLE
        for counter in range(len(orders)):
            order = orders[counter]
            account = fakers.account.generate_single({'_id': order['account']['_id']})
            user = fakers.user.generate_single({'username':order.get('createdBy')})
            transaction = fakers.transaction.generate_single({'order._id':order.get('_id')})
            
            test_table['Givewith-Order-ID'][counter] = order.get('_id', '')
            if 'orderDate' in order:
                test_table['Date'][counter] = order.get('orderDate', '').strftime("%m/%d/%Y")
            else:
                test_table['Date'][counter] = order.get('createdAt','').strftime("%m/%d/%Y")
            if transaction:
                test_table['Transaction-ID'][counter] = transaction.get('_id', '')
                test_table['Transaction-Amount'][counter] = transaction.get('amount', '')
                sage = transaction.get('sage', {})
                # SAGE TRANSACTION INFORMATION
                test_table['Sage-Bill-Record-Number'][counter] = sage.get('billRecordNumber','')
                test_table['Sage-Bill-Record-No'][counter]= sage.get('billRecordNo','')
                test_table['Sage-Invoice-ID'][counter]=sage.get('invoiceId','')
                test_table['Sage-Invoice-Record-No'][counter]=sage.get('invoiceRecordNo','')
                test_table['Stripe-Payment-Intent-ID'][counter] = transaction.get('stripe', {}).get('paymentIntentId')
            test_table['Client-ID'][counter] = str(order.get('account', {}).get('_id', '')).strip()
            test_table['Customer-Name'][counter] = order.get('customer', {}).get('name', '') if 'customer' in order else order.get('customerName')
            if account:
                test_table['Client-Account-Name'][counter] = account.get('company',{}).get('name', '')
                test_table['Stripe-Subscription-ID'][counter] = account.get('stripe', {}).get('subscription', {}).get('id', '')
                test_table['Subscription-Term'][counter]=account.get('subscriptionFrequency', '')
                test_table['Sage-Customer-ID'][counter]=account.get('sageCustomerId','')
                stripe = account.get('stripe',{})
                test_table['Autopay'][counter] = True if stripe.get('autopay', {}).get('paymentMethodId', '') else False
                test_table['Stripe-Customer-ID'][counter] = stripe.get('customerId','')
                test_table['Stripe-Period-End'][counter] = stripe.get('subscription', {}).get('currentPeriodEnd','N/A')
                if test_table['Stripe-Period-End'][counter] != 'N/A':
                    test_table['Stripe-Period-End'][counter]= stripe.get('subscription', {}).get('currentPeriodEnd').strftime("%m/%d/%Y")
                test_table['Stripe-Period-Start'][counter] = stripe.get('subscription', {}).get('currentPeriodStart', 'N/A')
                if test_table['Stripe-Period-Start'][counter] != 'N/A':
                    test_table['Stripe-Period-Start'][counter]= stripe.get('subscription', {}).get('currentPeriodStart').strftime("%m/%d/%Y")
            test_table['Status'][counter] = order.get('status', '').strip()
            test_table['Give-Amount'][counter] = order.get('grandTotal', '')
            test_table['Social-Cause'][counter] = order.get('causeArea', {}).get('name', '').strip()
            test_table['User-Email'][counter] = order.get('createdBy', '').strip()
            test_table['Client-Name'][counter] = user.get('name','') if 'name' in user else user.get('displayName', '')

        data_frame = transaction_service().monthly_reconciliation_data()
        test_data_frame = pd.DataFrame(test_table)

        pd.testing.assert_frame_equal(data_frame, test_data_frame)