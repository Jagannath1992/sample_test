from pymongo.errors import OperationFailure
from matchmaking import db
import copy

# drop index
try:
    db().coll_nonprofits.drop_index('name_1')
except OperationFailure as e:
    pass


old_schema = {
    "_id" : "5b2bfca6e3dde1001ae17712",
    "createdAt" : "2018-06-21T19:29:42.706Z",
    "description" : "The Kids In Need Foundation’s mission is to ensure that every child is prepared to learn and succeed in the classroom by providing free school supplies nationally to students most in need. ",
    "givewithAdmin": "5b59e37227dec7de5faf63af",
    "impacts" : [
        {
            "label" : "million students aided by the Kids in Need Foundation last year.",
            "value" : 6.0
        },
        {
            "label" : "billion dollars in supplies have been distributed to kids in need.",
            "value" : 1.0
        },
        {
            "label" : "percent impact on class preparedness facilitated by supplies from the Kids in Need Foundation.",
            "value" : 94.0
        }
    ],
    "isValid" : True,
    "lastUpdated" : "2019-01-05T00:03:09.143Z",
    "name" : "Kids in Need Foundation ",
    "notes" : "Kids in Need Foundation partners with 40 locations across the country to help distribute much needed school supplies.",
    "slug" : "kids-in-need-foundation",
    "url" : "https://www.kinf.org",
    "videoFallback" : "https://s3.amazonaws.com/givewith-campaign-assets.production/nooldrofits/5b2bfca6e3dde1001ae17712/GW_Kids-In-Need_oldO_LND_1560x780_1545079311569.jpg",
    "vimeoId" : "309561480",
    "tax_id" : "31-1437587",
    "registeredCountry" : "United States"
}


new_schema = {
        "_id": "",
        "applicationFormName": '',
        "givewithAdmin": '',
        "slug": '',
        "editing": True,
        "status": '',
        "progress": {
            "general": {
                "complete": 0,
                "total": 0
            },
            "operationalInformation": {
                "complete": 0,
                "total": 0,
            },
            "overviewAndMission": {
                "complete": 0,
                "total": 0,
            }
        },
        "percentComplete": 0,
        "createdAt": '',
        "lastUpdated": '',
        "createdBy": '',
        "general": {
            "name": {
                "legalOrganizationName": '',
                "publicOrganizationName": '',
            },
            "social": {
                "facebook": "",
                "instagram": "",
                "linkedIn": "",
                "twitter": "",
                "websiteURL": ""
            },
            "contact": {
                "email": "",
                "name": "",
                "phone": "",
                "professionalTitle": ""
            },
            "location": {
                "generalLocation": "",
                "specificLocation": "",
                "w9": {
                    "name": "",
                    "url": ""
                },
                "taxId": ""
            },
            "missionAgreement": True
        },
        "overviewAndMission": {
            "historyDescription": "",
            "problemDescription": '',
            "causeAreas": {
                "selected": [

                ]
            },
            "initiativesDescription": "",
            "programLocations": "",
            "researchAndEvaluation": "",
            "researchAndEvaluationFile": {
                "name": "",
                "url": ""
            },
            "lifetimeOutputs": [
            ]
        },
        "operationalInformation": {
            "staff": {
                "fullTime": "",
                "partTime": "",
                "volunteers": ""
            },
            "partnershipsDescription": "",
            "yearlyBudget": "",
            "financialStatement": {
                "file": {
                    "name": "",
                    "url": ""
                },
                "website": ""
            },
            "supportersAndPartners": ""
        },
        "review": {
            "email": "",
            "name": ""
        }
    }


nonprofits = list(db().coll_nonprofits.find({}))

for old in nonprofits:
    new = copy.deepcopy(new_schema)

    new['_id'] = old['_id']
    new['createdAt'] = old.get('createdAt', '')
    new['lastUpdated'] = old.get('lastUpdated', '')
    new['notes'] = old.get('notes', '')
    new['slug'] = old.get('slug', '')
    new['videoFallback'] = old.get('videoFallback', '')
    new['vimeoId'] = old.get('vimeoId', '')
    new['description'] = old.get('description', '')
    new['descriptionShort'] = ''

    new['general']['name']['legalOrganizationName'] = old.get('name', '')
    new['general']['name']['publicOrganizationName'] = old.get('name', '')
    new['general']['social']['websiteURL'] = old.get('url', '')
    new['general']['location']['generalLocation'] = old.get('registeredCountry', '')
    new['general']['location']['taxId'] = old.get('tax_id', '')
    new['isValid'] = old.get('isValid', True)
    new['givewithAdmin'] = old.get('givewithAdmin', '')

    for impact in old.get('impacts', []):
        if 'label' in impact and 'value' in impact:
            lifetimeOutputs = {
                'output': impact['label'],
                'outputNumber': impact['value'],
            }
            new['overviewAndMission']['lifetimeOutputs'].append(lifetimeOutputs)

    db().coll_nonprofits.find_one_and_replace({'_id': old['_id']}, new)









