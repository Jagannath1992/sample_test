import json

def test_event(client, client_header, brand_id):
    payload = {
        'name': 'test event',
        'customer': str(brand_id)
    }

    # test post
    response = client.post('dashboard/event', data=json.dumps(payload), headers=client_header)
    assert response.status_code == 200

    event = json.loads(response.data.decode())
    brand_id = event['customer']
    event_id = event['_id']
    assert event['name'] == 'test event'
    assert event['customer'] == str(brand_id)

    # test get
    response = client.get('dashboard/event/brand/' + brand_id, headers=client_header)
    events = json.loads(response.data.decode())

    assert response.status_code == 200
    assert len(events) > 0

    # test put
    update_event = {
        'name': 'updated test event',
        'category': 'category',
        'type': 'type',
        'tcv': 'tcv',
    }

    response = client.put('/dashboard/event/' + event_id, data=json.dumps(update_event), headers=client_header)
    assert response.status_code == 200

    event = json.loads(response.data.decode())
    assert event['name'] == 'updated test event'

    # test get event by id
    response = client.get('dashboard/event/' + event_id, headers=client_header)
    assert response.status_code == 200

    # test delete event by id
    response = client.delete('dashboard/event/' + event_id, headers=client_header)
    assert response.status_code == 200

    # get event again, expect 404
    response = client.get('dashboard/event/' + event_id, headers=client_header)
    assert response.status_code == 404


def test_pilot_deal(client, client_header, brand_id, program_id):
    # create a event
    payload = {
        'name': 'test event',
        'customer': str(brand_id)
    }

    response = client.post('dashboard/event', data=json.dumps(payload), headers=client_header)
    event = json.loads(response.data.decode())
    event_id = event['_id']

    # add a deal to event
    deal = {
        'type': 'pilot-procurement',
        'supplier': str(brand_id),
        'estimatedContractValue': 0,
        'allocation': 0,
        'portion': 1000,
        'paymentOption': 'payAsYouGo',
        'totalBudget': 100,
        'givePercent': 10,
        'feePercentage': 15,
        'fundingAmount': 1000,
        'supplierName': 'supplier name',
        'contact': 'contact@customer.com',
        'fundingStatus': 'string field',
        'invoicingTerms': 'string field',
        'totalInvoicingAmount': 200,
        'selectedPrograms': [str(program_id)]
    }
    response = client.post('dashboard/event/' + event_id + '/deal', data=json.dumps(deal), headers=client_header)
    assert response.status_code == 200

    # verify deals count in event
    response = client.get('dashboard/event/' + event_id, headers=client_header)
    event = json.loads(response.data.decode())

    # assert password and slug
    assert event['deals'][0]['password']
    assert event['deals'][0]['slug']

    # update deal
    deal_id = event['deals'][0]['_id']
    new_portion_value = 91828112
    deal = {
        'type': 'pilot-procurement',
        'supplier': str(brand_id),
        'estimatedContractValue': 0,
        'allocation': 0,
        'portion': new_portion_value,
        'feePercentage': 15,
        'fundingAmount': 1000,
        'paymentOption': 'payAsYouGo',
        'totalBudget': 100,
        'givePercent': 10,
        'supplierName': 'supplier name',
        'contact': 'contact@customer.com',
        'fundingStatus': 'string field',
        'invoicingTerms': 'string field',
        'totalInvoicingAmount': 200,
        'selectedProgram': [{
            'programId': str(program_id),
            'funding': 1000,
            'fundingPeriod': 'string field',
            'progress': 20
        }]
    }
    response = client.put('dashboard/pilot_deal/' + deal_id, data=json.dumps(deal), headers=client_header)
    assert response.status_code == 200

    # verify updated result
    response = client.get('dashboard/event/' + event_id, headers=client_header)
    event = json.loads(response.data.decode())

    # delete pilot deal
    response = client.delete('dashboard/pilot_deal/' + deal_id, data=json.dumps(deal), headers=client_header)
    assert response.status_code == 200

    # verify delete result
    response = client.get('dashboard/event/' + event_id, headers=client_header)
    event = json.loads(response.data.decode())
    assert len(event['deals']) == 0
