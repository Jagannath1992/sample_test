import pymongo
from datetime import datetime
"""
Populate cause_area and sku collections
"""
name = '20220221181334'
dependencies = ['20220211035849']


def upgrade(db: pymongo.database.Database):
    causeAreaName = "Plant a tree"
    causeAreaId = db['cause_area'].insert_one({
        "name": causeAreaName,
        "description": "Trees help slow climate change, filter our air and water, foster biodiversity, and strengthen our communities. The Arbor Day Foundation plants trees in forests and communities across the nation and around the globe.",
        "tooltip": "Arbor Day Foundation - Tree planting",
        "listImageName": "/images/ArborDayFoundation.jpg",
        "detailImageName": "/images/ArborDayFoundation.jpg",
        "detailLinkText": "Learn about Partner & Program",
        "detailLinkUrl": "https://impact.givewith.com/program-preview/bYzcTEdmk7vUG67",
        "calculation": {
            "unitPrice": 1.0,
            "currency": "USD",
            "unitValue": 1,
            "uom": "trees",
        }
    }).inserted_id
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1289-00100",
        "description": "$100",
        "unitCost": 100.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1289-01000",
        "description": "$1,000",
        "unitCost": 1000.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1289-10000",
        "description": "$10,000",
        "unitCost": 10000.0,
        "currency": "USD",
    })

    causeAreaName = "Promote STEM education for girls"
    causeAreaId = db['cause_area'].insert_one({
        "name": causeAreaName,
        "description": "Techbridge Girls re-engineers the way girls from marginalized communities experience STEM by catalyzing out-of-school time (OST). It also transforms STEM educators and STEM professionals into equity educators and advocates through training and curricula that promote access, belonging and persistence.",
        "tooltip": "Techbridge Girls - STEM programming for girls",
        "listImageName": "/images/TechbridgeGirls.jpg",
        "detailImageName": "/images/TechbridgeGirls.jpg",
        "detailLinkText": "Learn about Partner & Program",
        "detailLinkUrl": "https://impact.givewith.com/program-preview/equip-girls-from-high-poverty-communities-to-pursue-stem-careers-and-achieve-economic-mobility",
        "calculation": {
            "unitPrice": 50.0,
            "currency": "USD",
            "unitValue": 1,
            "uom": "Virtual STEM programming for 1 BIPOC girl",
        }
    }).inserted_id
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1786-00100",
        "description": "$100",
        "unitCost": 100.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1786-01000",
        "description": "$1,000",
        "unitCost": 1000.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1786-10000",
        "description": "$10,000",
        "unitCost": 10000.0,
        "currency": "USD",
    })
    
    causeAreaName = "Fight child hunger"
    causeAreaId = db['cause_area'].insert_one({
        "name": causeAreaName,
        "description": "Today, 1 in 6 kids is at risk of hunger in America. No Kid Hungry connects vulnerable kids in communities around the country with the nutritious food they need to grow and thrive.",
        "tooltip": "No Kid Hungry (Share our Strength) - Meals for kids",
        "listImageName": "/images/NoKidHungry.jpg",
        "detailImageName": "/images/NoKidHungry.jpg",
        "detailLinkText": "Learn about Partner & Program",
        "detailLinkUrl": "https://impact.givewith.com/program-preview/hYOKMi3k76RcJIR",
        "calculation": {
            "unitPrice": 1.0,
            "currency": "USD",
            "unitValue": 10,
            "uom": "meals",
        }
    }).inserted_id
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1431-00100",
        "description": "$100",
        "unitCost": 100.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1431-01000",
        "description": "$1,000",
        "unitCost": 1000.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "1431-10000",
        "description": "$10,000",
        "unitCost": 10000.0,
        "currency": "USD",
    })
    
    causeAreaName = "Make mental health screening available"
    causeAreaId = db['cause_area'].insert_one({
        "name": causeAreaName,
        "description": "1 in 5 Americans is living with a mental health condition. Mental Health America Screening provides ten scientifically-validated mental health screens. The online tools are anonymous, confidential, and free for users searching for mental health answers for the first time.",
        "tooltip": "Mental Health America - Mental health screening",
        "listImageName": "/images/MentalHealthAmerica.jpg",
        "detailImageName": "/images/MentalHealthAmerica.jpg",
        "detailLinkText": "Learn about Partner & Program",
        "detailLinkUrl": "https://impact.givewith.com/program-preview/mha-screenings",
        "calculation": {
            "unitPrice": 5.0,
            "currency": "USD",
            "unitValue": 1,
            "uom": "screenings",
        }
    }).inserted_id
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "0172-00100",
        "description": "$100",
        "unitCost": 100.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "0172-01000",
        "description": "$1,000",
        "unitCost": 1000.0,
        "currency": "USD",
    })
    
    db["sku"].insert_one({
        "cause_area": {
            "_id": causeAreaId,
            "_type": "cause_area",
            "name": causeAreaName,
        },
        "name": "0172-10000",
        "description": "$10,000",
        "unitCost": 10000.0,
        "currency": "USD",
    })


def downgrade(db: pymongo.database.Database):
    db['cause_area'].drop()
    db['sku'].drop()
