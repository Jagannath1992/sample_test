
export AWS_DEFAULT_PROFILE=development
$(aws ecr get-login --region us-east-1 --no-include-email)


# PULL THE DOCKER CONTAINER FROM AWS ECR

docker pull 574088774664.dkr.ecr.us-east-1.amazonaws.com/givewith_amzlinux:latest



docker pull 574088774664.dkr.ecr.us-east-1.amazonaws.com/givewith_mongo:latest

docker pull 574088774664.dkr.ecr.us-east-1.amazonaws.com/givewith_cypress:latest
