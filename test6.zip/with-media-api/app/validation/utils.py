import urllib
from bson import ObjectId
from flask import abort
from ..db.database import get_db
from ..db.utils import get_document


def validate_with_collection(query: dict, collection_name: str) -> bool:
    '''
    Validate a generic query against a collection
    '''
    return get_db()[collection_name].count_documents(query) > 0


def validate_object_id_with_collection(document_id, collection_name) -> bool:
    '''
    Validate object id against a collection
    '''
    if not ObjectId.is_valid(document_id):
        return False

    count = get_db()[collection_name].count_documents({'_id': ObjectId(document_id)})
    return count > 0


def validate_slug_with_collection(slug, collection_name) -> bool:
    '''
    Validate slug against a collection
    '''
    count = get_db()[collection_name].count_documents({'slug': slug})
    return count > 0


def validate_slug_or_id_with_collection(id_or_slug, collection_name) -> {}:
    '''
    Validate string as either slug or id against a collection
    Returns key and slug if valid id_or_slug
    '''
    if ObjectId.is_valid(id_or_slug):
        _id = id_or_slug
        if not validate_object_id_with_collection(_id, collection_name):
            abort(404, description='_id not found in ' + collection_name + ': ' + _id)
        document = get_document(collection_name, {'_id': ObjectId(_id)}, projection={'_id': False, 'slug': True})
        slug = document.get('slug')
    else:
        slug = id_or_slug
        if not validate_slug_with_collection(slug, collection_name):
            abort(404, description='slug not found in ' + collection_name + ': ' + slug)

        document = get_document(collection_name, {'slug': slug}, projection={'_id': True})
        _id = document.get('_id')

    return (_id, slug)


def uri_validator(url):
    try:
        result = urllib.request.urlparse(url)
        return all([result.scheme, result.netloc, result.path])
    except:
        return False
