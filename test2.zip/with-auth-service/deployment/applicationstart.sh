source /home/ec2-user/.bashrc
source /home/ec2-user/.envs

cd /home/ec2-user

if [ $ENV == "staging" ]; then
    rm -f /var/log/gunicorn
    export FLASK_ENV=staging
    /usr/local/bin/gunicorn -w 2 --access-logfile - --capture-output --log-file /var/log/gunicorn --log-level=debug -b :5000 -t 600 main:app --daemon
elif [ $ENV == "sandbox" ]; then
    rm -f /var/log/gunicorn
    export FLASK_ENV=sandbox
    /usr/local/bin/gunicorn -w 2 --access-logfile - --capture-output --log-file /var/log/gunicorn --log-level=debug -b :5000 -t 600 main:app --daemon
else
    export FLASK_ENV=prod
    /usr/local/bin/gunicorn -w 2 --access-logfile - --capture-output --log-file /var/log/gunicorn --log-level=debug -b :5000 -t 600 main:app --daemon
fi
