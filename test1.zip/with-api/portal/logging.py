import logging
from logging.handlers import RotatingFileHandler, SysLogHandler
import os.path
from flask import current_app


def init_logging(app):
    if not app.config['config']['loggly']['enable']:
        return

    # default file logging
    formatter = logging.Formatter(
        "[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s")

    # check if we can write to portal.log at the system level - if not, just write it in the local dir
    file_path = app.config['config']['loggly']['file_path']
    if not os.path.isfile(file_path):
        file_path = './portal.log'

    handler = RotatingFileHandler(file_path, maxBytes=10000000, backupCount=5)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(formatter)
    app.logger.addHandler(handler)
    __init_loggly(app)


def __init_loggly(app):
    logger = logging.getLogger('PORTAL')  # set this value as per your repo/project
    logger.setLevel(logging.INFO)
    sys_path = app.config['config']['loggly']['sys_path']
    handler = SysLogHandler(sys_path)
    formatter = logging.Formatter(
        'Python: { "loggerName":"%(name)s", \
            "timestamp":"%(asctime)s", \
            "pathName":"%(pathname)s", \
            "logRecordCreationTime":"%(created)f", \
            "functionName":"%(funcName)s", \
            "levelNo":"%(levelno)s", \
            "lineNo":"%(lineno)d", \
            "time":"%(msecs)d", \
            "levelName":"%(levelname)s", \
            "message":"%(message)s"}'
    )
    handler.formatter = formatter
    logger.addHandler(handler)
    logger.info("Init logging on Portal")

def send_loggly(msg):
    if logging.getLogger('PORTAL'):
        logging.getLogger('PORTAL').info(msg)
    else:
        current_app.info("can't write to loggly")
