from bson import ObjectId
from portal.shared import dates
from portal.shared.enums import ErrorLogSourceType
from portal.testing.faker import DocumentFaker


class ErrorLogFaker(DocumentFaker):
    def _generate_document(self, i):
        now = dates.get_utcnow()
        return {
            '_id': ObjectId(),
            'description': 'Internal message',
            'source': ErrorLogSourceType.SAGE.value,
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'account': {
                '_id': ObjectId(),
                '_type': 'account',
                'name': f'Account {i}',
            },
            'order': {
                '_id': ObjectId(),
                '_type': 'order',
                'name': f'Order {i}',
            },
            'transaction': {
                '_id': ObjectId(),
                '_type': 'transaction',
                'name': f'transaction {i}',
            },
            'messages': [{
                'code': '500',
                'message': 'Internal server error'
            }],
            'isResolved': False,
            'resolvedBy': None,
            'resolvedAt': None
        }



