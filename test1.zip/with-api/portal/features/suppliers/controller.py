import os

from bson import ObjectId
from flask import request, Response
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from werkzeug.exceptions import Forbidden, HTTPException, NotFound, BadRequest, UnsupportedMediaType
from pandas import read_csv

from portal.features.suppliers.schema import SupplierMetricsRequest, SupplierMetricsResponse, SupplierSearchRequest, SupplierSearchResponse, \
    SupplierInviteRequest, SupplierInviteResponse, SupplierRequest, SupplierResponse, SupplierInviteCSVResponse, \
    SupplierResendInviteRequest, SupplierResendInviteResponse, SupplierAppSettingsResponse
from portal.shared.auth.requests import role_required, token_required
from portal.shared.auth.security import get_validated_account_id
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.enums import AccountType, UserRole, AccountStatus
from portal.shared.repositories import account_repository, user_repository, instance_settings_repository
from portal.shared.schema import AccountIdRequest
from portal.shared.services import order_service, registration_service, auth_service

namespace = Namespace('suppliers', description='Supplier related operations')


@namespace.route('')
@namespace.doc(
    responses={
        400: 'Bad Request',
        403: 'You do not have permission to access this resource',
    }
)
class Suppliers(Resource):
    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @accepts(query_params_schema=SupplierSearchRequest, api=namespace)
    @responds(schema=SupplierSearchResponse, api=namespace)
    def get(self):
        """Search Suppliers"""
        filters = request.parsed_query_params
        account = _get_procurement_account(filters.pop('accountId', ''))

        filters['invitedBy._id'] = account['_id']
        filters['instance._id'] = account['instance']['_id']
        filters['type'] = AccountType.SUPPLIER.value
        total_count, suppliers = account_repository().get_page(filters)

        user_filters = {
            'accountId': {'$in': [s['_id'] for s in suppliers]},
            'roles': {"$in": [UserRole.ORG_ADMIN.value]}
        }
        users = user_repository().get_many(user_filters)

        results = []
        for supplier in suppliers:
            result = {'account': supplier, 'user': None}
            results.append(result)
            for user in users:
                if supplier['_id'] == user['accountId']:
                    result['user'] = user
                    break

        return {
            'totalCount': total_count,
            'results': results
        }


@namespace.route('/<string:id>')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Supplier account not found',
        403: 'You do not have permission to access this resource'
    }
)
class SupplierById(Resource):
    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @accepts(query_params_schema=AccountIdRequest, api=namespace)
    @responds(schema=SupplierResponse, api=namespace)
    def get(self, id: str):
        """Get Supplier by ID"""
        filters = request.parsed_query_params
        account = _get_procurement_account(filters.pop('accountId', ''))
        supplier = _get_supplier_account(id, account)

        user_filters = {
            'accountId': supplier['_id'],
            'roles': UserRole.ORG_ADMIN.value
        }
        user = user_repository().get_single_by_filter(user_filters)

        return {
            'account': supplier,
            'user': user
        }

    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @accepts(schema=SupplierRequest(partial=True), api=namespace)
    @responds(schema=SupplierResponse, api=namespace)
    def patch(self, id: str):
        """Update Supplier from Partial"""
        update = request.parsed_obj
        account = _get_procurement_account(update.pop('accountId', ''))
        supplier = _get_supplier_account(id, account)

        supplier = account_repository().patch(supplier['_id'], update, request.user['username'])

        return {
            'account': supplier,
            'user': None
        }

    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @accepts(query_params_schema=AccountIdRequest, api=namespace)  # double check
    @responds(schema=SupplierResponse, api=namespace)  # double check
    def delete(self, id: str):
        """Deactivate Supplier"""
        filters = request.parsed_query_params
        account = _get_procurement_account(filters.pop('accountId', ''))
        supplier = _get_supplier_account(id, account)

        update = {
            'status': AccountStatus.INACTIVE.value
        }
        supplier = account_repository().patch(supplier['_id'], update, request.user['username'])

        return {
            'account': supplier,
            'user': None
        }


@namespace.route('/invite')
@namespace.doc(
    responses={
        400: 'Bad Request',
        403: 'You do not have permission to access this resource',
    }
)
class InviteSupplier(Resource):
    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @accepts(schema=SupplierInviteRequest, api=namespace)
    @responds(schema=SupplierInviteResponse, api=namespace)
    @namespace.response(404, 'Instance not found')
    @namespace.response(502, 'An error occurred while attempting to create the account')
    def post(self):
        """Invite Suppliers"""
        payload = request.parsed_obj
        procurement_account = _get_procurement_account(payload['accountId'])
        instance = instance_settings_repository().get_single(procurement_account['instance']['_id'])
        if not instance:
            raise NotFound('Instance not found')

        suppliers = []
        for supplier in payload['suppliers']:
            user = supplier['user']
            account = supplier['account']
            account['invitedBy'] = {
                '_id': procurement_account['_id'],
                '_type': 'account',
                'name': procurement_account['company']['name']
            }
            message = 'Success'
            user['metadata'] = {
                'supplierInvite': True,
                'supplierCompanyName': account['company']['name'],
                'procurementClientName': procurement_account['company']['name']
            }

            try:
                user, account = registration_service().register_user(
                    instance, account, user, request.user['username'])
            except HTTPException as err:
                user = supplier['user']
                message = err.description
            except Exception as err:
                user = supplier['user']
                message = err

            suppliers.append({
                'user': user,
                'message': message
            })

        return {
            'suppliers': suppliers
        }

    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @responds(schema=SupplierInviteCSVResponse, api=namespace)
    @namespace.response(400, 'No file was provided')
    @namespace.response(415, 'The server does not support the media type transmitted in the request.')
    def put(self):
        """Parse Suppliers CSV file"""

        allowed_extensions = ['.csv']

        if 'file' not in request.files or request.files['file'].filename == '':
            raise BadRequest('No file was provided')

        file = request.files['file']

        if os.path.splitext(file.filename)[1] not in allowed_extensions:
            raise UnsupportedMediaType

        dataFrame = read_csv(file.stream, header=None, keep_default_na=False)
        columns = []
        for i in dataFrame:
            columns.append(dataFrame[i].tolist())
        return {'columns': columns}


@namespace.route('/<string:id>/resend-invite')
@namespace.doc(
    responses={
        400: 'Bad Request',
        403: 'You do not have permission to access this resource',
        404: 'Supplier account not found',
        404: 'User not found',
        502: 'An error occurred while attempting to resend invite'
    }
)
class ReinviteSupplierById(Resource):
    @role_required(roles=GIVEWITH_ROLES + [UserRole.ORG_ADMIN])
    @accepts(schema=SupplierResendInviteRequest, api=namespace)
    @responds(schema=SupplierResendInviteResponse, api=namespace)
    def post(self, id: str):
        """Resend Supplier Invite"""
        filters = request.parsed_obj
        procurement_account = _get_procurement_account(filters.pop('accountId', ''))
        supplier_account = _get_supplier_account(id, procurement_account)
        user = user_repository().get_single_by_filter({'username': filters.pop('username', '')})

        if user is None:
            return NotFound('User not found')

        user['metadata'] = {
            'supplierInvite': True,
            'supplierCompanyName': supplier_account['company']['name'],
            'procurementClientName': procurement_account['company']['name']
        }

        response = auth_service().resend_user_invite(user)
        return {'message': response}


@namespace.route('/metrics/detail')
class SupplierMetricsDetail(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.FINANCE])
    @accepts(schema=SupplierMetricsRequest, api=namespace)
    @responds(schema=SupplierMetricsResponse, api=namespace)
    def post(self):
        '''Procurement metrics detail by Supplier'''
        filters = request.parsed_obj
        filters['sharedWith._id'] = get_validated_account_id(filters.get('sharedWith._id', ''), request)
        results, currencies = order_service().get_metrics(filters, True, True, True)
        summary = order_service().get_summary(results)
        return {
            'results': results,
            'summary': summary,
            'currencies': currencies
        }


@namespace.route('/metrics/cause-areas')
class SupplierMetricsCauseAreas(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.FINANCE])
    @accepts(schema=SupplierMetricsRequest, api=namespace)
    @responds(schema=SupplierMetricsResponse, api=namespace)
    def post(self):
        '''Procurement metrics detail by Cause Area'''
        filters = request.parsed_obj
        filters['sharedWith._id'] = get_validated_account_id(filters.get('sharedWith._id', ''), request)
        results, currencies = order_service().get_metrics(filters, False, False, True)
        return {
            'results': results,
            'currencies': currencies
        }


@namespace.route('/metrics/download')
class SupplierMetricsDownload(Resource):
    @role_required(roles=[UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.FINANCE])
    @accepts(schema=SupplierMetricsRequest, api=namespace)
    @responds(api=namespace)
    def post(self):
        '''Procurement metrics detail for download'''
        filters = request.parsed_obj
        filters['sharedWith._id'] = get_validated_account_id(filters.get('sharedWith._id', ''), request)
        results, _ = order_service().get_metrics(filters, True, True, True)

        data = order_service().flatten_metrics(results)
        filename = order_service().get_filename(filters, 'supplier-metrics')

        return Response(
            data.to_csv(index=False),
            mimetype="text/csv",
            headers={"content-disposition": f"attachment; filename='{filename}'"})

    
@namespace.route('/<string:id>/app-settings')
@namespace.doc(
    responses={
        400: 'Invalid id provided',
        403: 'You do not have permission to access this resource',
        404: 'Supplier account not found',
        404: 'Procurement account not found',
    })
class SupplierAppSettingsByID(Resource):
    @token_required
    @accepts(query_params_schema=AccountIdRequest, api=namespace)
    @responds(schema=SupplierAppSettingsResponse, api=namespace)
    def get(self, id: str):
        '''Get Supplier Settings by ID'''
        filters = request.parsed_query_params
        procurement_account = _get_procurement_account(filters.pop('accountId', ''))
        supplier_account = _get_supplier_account(id, procurement_account)

        response = {
            'id': supplier_account['_id'],
            'giveFields': supplier_account.get('giveFields', {})
        }
        return response


def _get_procurement_account(account_id):
    account_id = get_validated_account_id(account_id, request)
    account = account_repository().get_single(account_id)

    if account is None:
        raise NotFound('Procurement account not found')

    if account['type'] != AccountType.PROCUREMENT.value:
        raise Forbidden('You do not have permission to access this resource')

    return account


def _get_supplier_account(id, account):
    if not ObjectId.is_valid(id):
        raise BadRequest('Invalid id provided')

    supplier_filters = {
        '_id': ObjectId(id),
        'invitedBy._id': account['_id'],
        'instance._id': account['instance']['_id'],
        'type': AccountType.SUPPLIER.value,
    }
    supplier = account_repository().get_single_by_filter(supplier_filters)

    if supplier == None:
        raise NotFound('Supplier account not found')

    return supplier
