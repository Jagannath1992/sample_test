from matchmaking import db
from pymongo.errors import DuplicateKeyError



collections = [
    db().coll_brands,
    db().coll_nonprofits,
    db().coll_programs
]

for collection in collections:
    try:
        collection.drop_index({'name': 1})
    except TypeError as e:
        pass

    try:
        collection.create_index([('name', 1)], unique=True)
    except DuplicateKeyError as e:
        print('DuplicateKeyError: ' + str(collection.name))
        print(e)
