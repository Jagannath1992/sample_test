from numbers import Real


def format_zip_code(str):
    return f'{str[0:5]}-{str[5:len(str)]}' if str and len(str) > 5 else str


def format_phone_number(str):
    return f'({str[0:3]}) {str[3:6]}-{str[6:10]}' if str and len(str) == 10 else str


def format_currency(symbol, value) -> str:
    try:
        return f"{symbol}{value:,.2f}"
    except (TypeError, ValueError):
        return ''
