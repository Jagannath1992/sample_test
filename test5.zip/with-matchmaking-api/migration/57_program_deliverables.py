from matchmaking import db

for program in db().coll_programs.find({}):
    deliverables = program.get('deliverables', {})
    if deliverables:
        altered_deliverables = {}
        for key in deliverables.keys():
            url_prefix = 'https://s3.amazonaws.com/givewith-campaign-assets.staging/'
            if url_prefix in deliverables[key]:
                path = deliverables[key].replace(url_prefix, '')
                altered_deliverables[key] = path
            else:
                altered_deliverables[key] = deliverables[key]


        db().coll_programs.update_one({'_id': program['_id']}, {'$set': {'deliverables': altered_deliverables}})
