import pymongo
from datetime import datetime
"""
Initialize database
"""
name = '20220211022958'
dependencies = []


def upgrade(db: pymongo.database.Database):
    now = datetime.utcnow()

    accountId = db['account'].insert_one({
        "status": "active",
        "industry": {
            "displayLabel": "Internet Software & Services",
            "subIndustry": "Internet Software & Services",
        },
        "company": {
            "name": "Givewith",
            "address": {
                "address1": "919 Manhattan Ave",
                "address2": "Suite 100",
                "city": "Manhattan Beach",
                "stateProvince": "CA",
                "postalCode": "90266",
                "country": "United States",
            },
            "phoneNumber": "555-555-5555",
            "website": "https://www.givewith.com/",
        },
        "sageCustomerId": "",
        "currency": "USD",
        "customLabel1": "",
        "customLabel2": "",
        "customLabel3": "",
        "customLabel4": "",
        "createdBy": "admin@givewith.com",
        "createdAt": now,
        "lastUpdatedBy": "admin@givewith.com",
        "lastUpdated": now
    }).inserted_id

    db['account_approval'].insert_one({
        '_id': accountId,
        'levels': [],
        "createdBy": "admin@givewith.com",
        "createdAt": now,
        "lastUpdatedBy": "admin@givewith.com",
        "lastUpdated": now
    })

    db['user'].insert_one({
        "accountId": accountId,
        "oktaId": "00u3uw4vlxNfOTdtj5d7",
        "username": "admin@givewith.com",
        "name": "Givewith Admin",
        "first_name": "Givewith",
        "last_name": "Admin",
        "orgId": "",
        "orgName": "",
        "orgType": "brand",
        "type": "client",
        "departmentType": "Portal",
        "createdBy": "admin@givewith.com",
        "createdAt": now,
        "lastUpdatedBy": "admin@givewith.com",
        "lastUpdated": now,
        "last_login": now,
        "active": True,
        "roles": [
            "givewith"
        ]
    })

    # This collection will only be populated if it doesn't already exist
    if db['industry_display_map'].count() < 1:
        db['industry_display_map'].insert_one({
            "Commercial & Professional Services": [
                {
                    "displayLabel": "Commercial Services & Supplies",
                    "subIndustry": "Diversified Support Services"
                },
                {
                    "displayLabel": "Professional Services",
                    "subIndustry": "Research & Consulting Services"
                }
            ],
            "Consumer Goods & Services": [
                {
                    "displayLabel": "Hotels, Restaurants & Leisure",
                    "subIndustry": "Hotels, Resorts & Cruise Lines"
                },
                {
                    "displayLabel": "Household Durables (including Electronics, Appliances)",
                    "subIndustry": "Consumer Electronics"
                },
                {
                    "displayLabel": "Leisure Products",
                    "subIndustry": "Leisure Products"
                },
                {
                    "displayLabel": "Textiles, Apparel & Luxury Goods",
                    "subIndustry": "Apparel, Accessories & Luxury Goods"
                },
                {
                    "displayLabel": "Other (e.g. Education, Residential, Legal, Personal Services)",
                    "subIndustry": "Specialized Consumer Services"
                }
            ],
            "CPG (Consumer Packaged Goods)": [
                {
                    "displayLabel": "Beverages",
                    "subIndustry": "Soft Drinks"
                },
                {
                    "displayLabel": "Food Products",
                    "subIndustry": "Packaged Foods & Meats"
                },
                {
                    "displayLabel": "Household Products",
                    "subIndustry": "Household Products"
                },
                {
                    "displayLabel": "Personal Products",
                    "subIndustry": "Personal Products"
                },
                {
                    "displayLabel": "Tobacco",
                    "subIndustry": "Tobacco"
                }
            ],
            "Energy & Utilities": [
                {
                    "displayLabel": "Electric Utilities",
                    "subIndustry": "Electric Utilities"
                },
                {
                    "displayLabel": "Energy Equipment & Services",
                    "subIndustry": "Oil & Gas Equipment & Services"
                },
                {
                    "displayLabel": "Gas Utilities",
                    "subIndustry": "Gas Utilities"
                },
                {
                    "displayLabel": "Independent Power and Renewable Electricity Producers",
                    "subIndustry": "Renewable Electricity"
                },
                {
                    "displayLabel": "Multi-Utilities",
                    "subIndustry": "Multi-Utilities"
                },
                {
                    "displayLabel": "Oil, Gas & Consumable Fuels",
                    "subIndustry": "Integrated Oil & Gas"
                },
                {
                    "displayLabel": "Water Utilities",
                    "subIndustry": "Water Utilities"
                }
            ],
            "Finance": [
                {
                    "displayLabel": "Banks",
                    "subIndustry": "Diversified Banks"
                },
                {
                    "displayLabel": "Capital Markets",
                    "subIndustry": "Investment Banking & Brokerage"
                },
                {
                    "displayLabel": "Consumer Finance",
                    "subIndustry": "Consumer Finance"
                },
                {
                    "displayLabel": "Insurance",
                    "subIndustry": "Multi-line Insurance"
                },
                {
                    "displayLabel": "Mortgage Real Estate Investment Trusts (REITs)",
                    "subIndustry": "Mortgage REITs"
                },
                {
                    "displayLabel": "Thrifts & Mortgage Finance",
                    "subIndustry": "Thrifts & Mortgage Finance"
                },
                {
                    "displayLabel": "Other (Specialized or Multi-Sector Financial Services)",
                    "subIndustry": "Multi-Sector Holdings"
                }
            ],
            "Healthcare & Pharmaceuticals": [
                {
                    "displayLabel": "Biotechnology",
                    "subIndustry": "Biotechnology"
                },
                {
                    "displayLabel": "Health Care Equipment & Supplies",
                    "subIndustry": "Health Care Supplies"
                },
                {
                    "displayLabel": "Health Care Providers & Services",
                    "subIndustry": "Health Care Facilities"
                },
                {
                    "displayLabel": "Health Care Technology",
                    "subIndustry": "Health Care Technology"
                },
                {
                    "displayLabel": "Life Sciences Tools & Services",
                    "subIndustry": "Life Sciences Tools & Services"
                },
                {
                    "displayLabel": "Pharmaceuticals",
                    "subIndustry": "Pharmaceuticals"
                }
            ],
            "Materials & Industrials": [
                {
                    "displayLabel": "Aerospace & Defense",
                    "subIndustry": "Aerospace & Defense"
                },
                {
                    "displayLabel": "Building Products",
                    "subIndustry": "Building Products"
                },
                {
                    "displayLabel": "Chemicals",
                    "subIndustry": "Diversified Chemicals"
                },
                {
                    "displayLabel": "Construction & Engineering",
                    "subIndustry": "Construction & Engineering"
                },
                {
                    "displayLabel": "Construction Materials",
                    "subIndustry": "Construction Materials"
                },
                {
                    "displayLabel": "Containers & Packaging",
                    "subIndustry": "Metal & Glass Containers"
                },
                {
                    "displayLabel": "Electrical Equipment",
                    "subIndustry": "Electrical Components & Equipment"
                },
                {
                    "displayLabel": "Industrial Conglomerates",
                    "subIndustry": "Industrial Conglomerates"
                },
                {
                    "displayLabel": "Machinery",
                    "subIndustry": "Industrial Machinery"
                },
                {
                    "displayLabel": "Metals & Mining",
                    "subIndustry": "Diversified Metals & Mining"
                },
                {
                    "displayLabel": "Paper & Forest Products",
                    "subIndustry": "Paper Products"
                },
                {
                    "displayLabel": "Trading Companies & Distributors",
                    "subIndustry": "Trading Companies & Distributors"
                }
            ],
            "Media": [
                {
                    "displayLabel": "Media",
                    "subIndustry": "Advertising"
                }
            ],
            "Real Estate": [
                {
                    "displayLabel": "Equity Real Estate Investment Trusts (REITs)",
                    "subIndustry": "Diversified REITs"
                },
                {
                    "displayLabel": "Real Estate Management & Development",
                    "subIndustry": "Diversified Real Estate Activities"
                }
            ],
            "Retail": [
                {
                    "displayLabel": "Distributors",
                    "subIndustry": "Distributors"
                },
                {
                    "displayLabel": "Food & Staples Retailing ",
                    "subIndustry": "Food Retail"
                },
                {
                    "displayLabel": "Internet & Direct Marketing Retail",
                    "subIndustry": "Internet & Direct Marketing Retail"
                },
                {
                    "displayLabel": "Multiline Retail",
                    "subIndustry": "Department Stores"
                },
                {
                    "displayLabel": "Specialty Retail",
                    "subIndustry": "Specialty Stores"
                }
            ],
            "Technology": [
                {
                    "displayLabel": "Communications Equipment",
                    "subIndustry": "Communications Equipment"
                },
                {
                    "displayLabel": "Electronic Equipment, Instruments & Components",
                    "subIndustry": "Electronic Equipment & Instruments"
                },
                {
                    "displayLabel": "Internet Software & Services",
                    "subIndustry": "Internet Software & Services"
                },
                {
                    "displayLabel": "IT Services",
                    "subIndustry": "IT Consulting & Other Services"
                },
                {
                    "displayLabel": "Semiconductors & Semiconductor Equipment",
                    "subIndustry": "Semiconductors"
                },
                {
                    "displayLabel": "Software",
                    "subIndustry": "Application Software"
                },
                {
                    "displayLabel": "Technology Hardware, Storage & Peripherals",
                    "subIndustry": "Technology Hardware, Storage & Peripherals"
                }
            ],
            "Telecommunications": [
                {
                    "displayLabel": "Wireless Telecommunication Services",
                    "subIndustry": "Wireless Telecommunication Services"
                },
                {
                    "displayLabel": "Other (Alternative and Integrated Telecom)",
                    "subIndustry": "Integrated Telecommunication Services"
                }
            ],
            "Transportation": [
                {
                    "displayLabel": "Air Freight & Logistics",
                    "subIndustry": "Air Freight & Logistics"
                },
                {
                    "displayLabel": "Airlines",
                    "subIndustry": "Airlines"
                },
                {
                    "displayLabel": "Auto Components",
                    "subIndustry": "Auto Parts & Equipment"
                },
                {
                    "displayLabel": "Automobiles",
                    "subIndustry": "Automobile Manufacturers"
                },
                {
                    "displayLabel": "Marine",
                    "subIndustry": "Marine"
                },
                {
                    "displayLabel": "Road & Rail",
                    "subIndustry": "Railroads"
                },
                {
                    "displayLabel": "Transportation Infrastructure",
                    "subIndustry": "Highways & Railtracks"
                }
            ]
        })


def downgrade(db: pymongo.database.Database):
    pass
