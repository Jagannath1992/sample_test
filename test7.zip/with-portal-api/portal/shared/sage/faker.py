from bson import ObjectId
from portal.shared.sage.dates import get_sage_date
from portal.shared.sage.enums import SageCustomFieldName
from portal.shared.sage.models import SageBill, SageBillItem, SageBillItems, SageContact, SageCustomField, SageCustomFields, SageCustomer, SageInvoice, SageLegacyDate, SageInvoiceItems, SageLineItem, SageMailAddress


class SageFaker:

    def sage_contact(self):
        return SageContact(
            FIRSTNAME='Finance',
            LASTNAME='Example',
            COMPANYNAME='XYZ Korgi Corp',
            EMAIL1='test@example.com'
        )


    def sage_customer(self):
        return SageCustomer(
            NAME='XYZ Korgi Corp/LTD',
            DISPLAYCONTACT=SageContact(
                FIRSTNAME='Org Admin',
                LASTNAME='Example',
                COMPANYNAME='XYZ Korgi LTD',
                EMAIL1='test@example.com',
                MAILADDRESS=SageMailAddress(
                    ADDRESS1='1234 Main Street',
                    ADDRESS2='Suite 1',
                    CITY='San Diego',
                    STATE='CA',
                    ZIP='92121',
                    COUNTRY='United States'
                )
            ),
            GIVEWITH_ACCOUNT_ID=str(ObjectId()),
            STRIPE_CUSTOMER_ID='stripe_123'
        )


    def sage_bill(self):
        return SageBill(
            WHENCREATED=get_sage_date(),
            WHENPOSTED=get_sage_date(),
            WHENDUE=get_sage_date(),
            VENDORID='20082',
            RECORDID='123450-001',
            DESCRIPTION='Test Sage Create Bill with Custom fields',
            CURRENCY='USD',
            BASECURR='USD',
            APBILLITEMS=SageBillItems(
                APBILLITEM=[
                    SageBillItem(
                        ACCOUNTNO='60400',
                        TRX_AMOUNT=100.12,
                        LOCATIONID='100',
                        DEPARTMENTID='300',
                        GIVEWITH_ORDER_ID=str(ObjectId()),
                        GIVEWITH_TRANSACTION_ID='1234567890-gw-xact-id',
                        STRIPE_TRANSACTION_ID='909090-stripe-x-act-id',
                        PRODUCT_NAME='Givewith for Sales - Transaction'
                    )
                ]
            )
        )       

    def sage_custom_fields(self):
        return SageCustomFields(
            customfield=[
                SageCustomField(
                    customfieldname=SageCustomFieldName.GIVEWITH_ORDER_ID.value,
                    customfieldvalue=str(ObjectId())
                ),
                SageCustomField(
                    customfieldname=SageCustomFieldName.GIVEWITH_TRANSACTION_ID.value,
                    customfieldvalue='gw-x-actid'
                ),
                SageCustomField(
                    customfieldname=SageCustomFieldName.STRIPE_TRANSACTION_ID.value,
                    customfieldvalue='stripe-x-act-id'
                ),
                SageCustomField(
                    customfieldname=SageCustomFieldName.PRODUCT_NAME.value,
                    customfieldvalue='Givewith for Sales - Monthly Subscription'
                )
            ]
        )

    def sage_invoice(self):
        return SageInvoice(
            customerid='10000001',
            datecreated=SageLegacyDate(),
            dateposted=SageLegacyDate(),
            datedue=SageLegacyDate(),
            description='Testing Invoice with custom fields',
            basecurr='USD',
            currency='USD',
            exchratedate=SageLegacyDate(),
            exchratetype='Intacct Daily Rate',
            invoiceitems=SageInvoiceItems(
                lineitem=[
                    SageLineItem(
                        glaccountno='90000',
                        amount=170.00,
                        locationid=100,
                        departmentid='300',
                        customfields=SageFaker.sage_custom_fields(self)
                    )
                ]
            )
        )
