import pytest
from typing import List

from portal.shared.errors import GivewithError
from portal.shared.sage.faker import SageFaker
from portal.shared.sage.models import SageBill, SageBillItems, SageInvoice, SageInvoiceItems
from portal.shared.sage.validator import SageValidator


class TestSageValidator:

    @pytest.fixture
    def sage_contact(self):
        return SageFaker.sage_contact(self)

    @pytest.fixture
    def sage_customer(self):
        return SageFaker.sage_customer(self)

    @pytest.fixture
    def sage_bill(self):
        return SageFaker.sage_bill(self)

    @pytest.fixture
    def sage_invoice(self):
        return SageFaker.sage_invoice(self)

    # Invoice Tests
    def test_create_invoice_both_account_and_glno(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.invoiceitems.lineitem[0].accountlabel = '90000'
        sage_invoice.invoiceitems.lineitem[0].glaccountno = '60400'

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)
            
        #assert
        assert has_error("Either accountlabel or glaccountno is required for lineitem", error_list)

    def test_create_invoice_no_account_nor_glno(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.invoiceitems.lineitem[0].accountlabel = None
        sage_invoice.invoiceitems.lineitem[0].glaccountno = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("Either accountlabel or glaccountno is required for lineitem", error_list)

    def test_create_invoice_no_invoice_items(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.invoiceitems = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("invoiceitems is required", error_list)

    def test_create_invoice_empty_invoice_items(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.invoiceitems = SageInvoiceItems()

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("At least one lineitem is required", error_list)

    def test_create_invoice_no_customerid(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.customerid = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("customerid is required", error_list)

    def test_create_invoice_no_datecreated(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.datecreated = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("datecreated is required", error_list)

    def test_create_invoice_no_duedate(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.datedue = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("datedue is required", error_list)

    def test_create_invoice_no_currency(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.currency = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("currency is required", error_list)

    def test_create_invoice_no_base_currency(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.basecurr = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("basecurr is required", error_list)
       
    def test_create_invoice_no_exchratetype(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.exchratetype = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("exchratetype is required", error_list)

    def test_create_invoice_no_exchratedate(self, sage_invoice: SageInvoice):
        # arrange
        sage_invoice.exchratedate = None

        # act
        error_list = SageValidator.validate_create_invoice(self, sage_invoice)

        #assert
        assert has_error("exchratedate is required", error_list)

    # Bill Validation Tests   
    def test_create_bill_no_vendorid(self, sage_bill: SageBill):
        # arrange
        sage_bill.VENDORID = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("VENDORID is required", error_list)

    def test_create_bill_no_currency(self, sage_bill: SageBill):
        # arrange
        sage_bill.CURRENCY = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("CURRENCY is required", error_list)

    def test_create_bill_no_base_currency(self, sage_bill: SageBill):
        # arrange
        sage_bill.BASECURR = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("BASECURR is required", error_list)

    def test_create_bill_draft_no_when_created(self, sage_bill: SageBill):
        # arrange
        sage_bill.WHENCREATED = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("WHENCREATED is required", error_list)

    def test_create_bill_draft_no_when_due(self, sage_bill: SageBill):
        # arrange
        sage_bill.WHENDUE = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("WHENDUE is required", error_list)

    def test_create_bill_no_recordid(self, sage_bill: SageBill):
        # arrange
        sage_bill.RECORDID = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("RECORDID (bill number) is required", error_list)

    def test_create_bill_no_apbillitems(self, sage_bill: SageBill):
        # arrange
        sage_bill.APBILLITEMS = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("APBILLITEMS is required", error_list)

    def test_create_bill_empty_apbillitems(self, sage_bill: SageBill):
        # arrange
        sage_bill.APBILLITEMS = SageBillItems()

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("At least one APBILLITEM is required", error_list)

    def test_create_bill_no_apbillitem_accountno(self, sage_bill: SageBill):
        # arrange
        sage_bill.APBILLITEMS.APBILLITEM[0].ACCOUNTNO = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("ACCOUNTNO is required for APBILLITEM", error_list)

    def test_create_bill_no_apbillitem_departmentid(self, sage_bill: SageBill):
        # arrange
        sage_bill.APBILLITEMS.APBILLITEM[0].DEPARTMENTID = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("DEPARTMENTID is required for APBILLITEM", error_list)

    def test_create_bill_no_apbillitem_locationid(self, sage_bill: SageBill):
        # arrange
        sage_bill.APBILLITEMS.APBILLITEM[0].LOCATIONID = None

        # act
        error_list = SageValidator.validate_create_bill(self, sage_bill)

        #assert
        assert has_error("LOCATIONID is required for APBILLITEM", error_list)


def has_error(message: str, errors: List[GivewithError]) -> bool:
    for error in errors:
        if error.message == message:
            return True
    return False
