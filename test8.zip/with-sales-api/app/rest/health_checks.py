from flask_restful import Resource
from os import environ


class HealthCheck(Resource):
    def get(self):
        return {'status': 'ok','env': environ.get('ENV')}
