from matchmaking import db


survey_data = db().coll_survey_data.find_one({}, projection={'questionDependencies': True})
question_dependencies = survey_data.get('questionDependencies')

vocab_approaches = list(db().coll_vocabulary.find({'type' : 'approach', 'category' : {'$eq' : 'environmental'}}, projection={'label' : True}))

values = {}

for item in vocab_approaches:
    _id = str(item['_id'])
    values[_id] = item['label']

environmentalOutputs = {
    'operation' : 'in',
    'path' : 'ResearchAndEvaluation.environmentalOutputs.value',
    'keys' : [
        {
            'key' : 'ResearchAndEvaluation.researchApproaches.value',
        }
    ],
    'values' : values
}

question_dependencies['environmentalOutputs'] = environmentalOutputs


db().coll_survey_data.find_one_and_update({}, {
    '$set': {'questionDependencies': question_dependencies}
})

