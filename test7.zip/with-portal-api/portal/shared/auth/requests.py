from functools import wraps
from os import environ
from typing import List

import jwt
from flask import request
from werkzeug.exceptions import Unauthorized, Forbidden

from portal.shared.auth.model import v, schema_user
from portal.shared.auth.security import has_role
from portal.shared.enums import AccountStatus, UserRole
from portal.shared.repositories import account_repository, user_repository

TOKEN_PRIVATE_KEY = None  # CodeBuild tests need this setup on AWS Console to pass


def get_token_private_key():
    global TOKEN_PRIVATE_KEY
    if TOKEN_PRIVATE_KEY is None:
        TOKEN_PRIVATE_KEY = environ.get('TOKEN_PRIVATE_KEY', '')
    return TOKEN_PRIVATE_KEY


def authenticate_request():
    if request.method == 'OPTIONS':
        return

    token = request.headers.get('authorization', '')
    if token == '':   # nosec
        return 'Credentials not found', 401

    try:
        claims = jwt.decode(token, get_token_private_key(), algorithms='HS256')
        if '_id' in claims:
            request.user = v.normalized(claims, schema_user)
            request.user['username'] = claims['email']
        else:
            request.user = user_repository().get_by_username(claims['email'])

        account = _get_account(request.user['accountId'])
        if not account:
            return 'Invalid Account', 401
        status = account.get('status')
        if not status or status not in [
            AccountStatus.NEW.value,
            AccountStatus.PENDING.value,
            AccountStatus.PENDING_FINANCE.value,
            AccountStatus.PENDING_STRIPE.value,
            AccountStatus.ACTIVE.value
        ]:
            return 'Inactive Account', 401

        return 'OK', 200
    except jwt.ExpiredSignatureError:
        return 'Expired token', 401
    except jwt.PyJWTError:
        return 'Invalid token', 401


def _get_account(accountId):
    return account_repository().get_single(accountId, {'_id': 0, 'status': 1})


def token_required(f):
    f.__apidoc__['security'] = 'Bearer'
    f.__apidoc__['responses'][401] = ('Expired token', None, {})

    @wraps(f)
    def decorated(*args, **kwargs):
        msg, code = authenticate_request()
        if code == 401:
            raise Unauthorized(msg)
        return f(*args, **kwargs)

    return decorated


def role_required(roles: List[UserRole]):
    def decorator(f):
        f.__apidoc__['security'] = 'Bearer'
        responses = {
            401: ('Token is invalid or expired', None, {}),
            403: ('You do not have permission to access this resource', None, {})
        }
        if 'responses' in f.__apidoc__:
            f.__apidoc__['responses'].update(responses)
        else:
            f.__apidoc__['responses'] = responses

        @wraps(f)
        def decorated(*args, **kwargs):
            msg, code = authenticate_request()
            if code == 401:
                raise Unauthorized(msg)

            if not has_role(roles, request.user):
                raise Forbidden('You do not have permission to access this resource')

            return f(*args, **kwargs)

        return decorated
    return decorator
