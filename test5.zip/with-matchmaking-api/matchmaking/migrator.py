from matchmaking.mongodb import db
from datetime import datetime
import os
import pymongo
import traceback

migration_dir = './migration/'

def run_migration(app):
    """ this is the main function runs db migrations. It reads migration files from source,
        applies them in correct order to database and save the status.
    """
    app.logger.info('attempt to run migration')

    has_lock = _acquire_lock()
    if not has_lock:
        """" didn't get lock, bye """
        app.logger.info("didn't get migration lock, skip migrations")
        return True

    version_info = _get_version()
    if version_info["dirty"]:
        """ stop if previous migration field """
        app.logger.error("migration failed due to previous migration failure.")
        _release_lock()
        return False

    version = version_info["version"]

    """ a dictionary stores all migration files. Key is the version number value is the file name """
    migration_files = _load_migration_file(app, version)
    if migration_files is None:
        app.logger.error("migration failed due to invalid migration files")
        return False

    if len(migration_files) == 0:
        app.logger.info("didn't find new migration files, skip migration")
        return True

    while str(version + 1) in migration_files:
        """ to ensure run migration sequentially, only run the version that equals current version + 1 """
        version += 1

        dirty = _execute_migration(app, migration_dir + migration_files[str(version)])
        _set_version(version, dirty)

        app.logger.info(f'running migration {version}. dirty: {dirty}')

        if dirty:
            """ stop if migration failed """
            return False

    _release_lock()
    app.logger.info('migration complete')

    return True


def _acquire_lock():
    """ We need locking to make sure only one server is running the migration job, because we have multiple servers
        connect to a single database. If multiple servers run a migration file at same time
        we may have duplicate data or have race condition problem.

        I didn't find any way to get distributed lock for Mongodb nicely.
        My solution is create migration_lock collection, and insert a new document with _id:1.


        This will work because Mongodb uses locking and other concurrency control measures to prevent multiple clients from
        modifying the same piece of data simultaneously. and Mongodb not allowing 2 documents with the same ID to exist.

        So If insertion succeeds, you successfully acquired the lock. If insertion fails, you did not.
    """
    # noinspection PyBroadException
    try:
        db().coll_migration_lock.insert_one({"_id": 1, "locked": True, "created_at": datetime.now()})
    except pymongo.errors.DuplicateKeyError:
        return False
    return True


def _release_lock():
    """ To release the lock, simply delete (remove) the document. """
    db().coll_migration_lock.delete_many({})


def _load_migration_file(app, last_version):
    """ read migration files from ./migration directory """
    migration_file = {}
    with os.scandir(migration_dir) as files:
        for f in files:
            if f.is_file():
                name = f.name
                s = name.split("_")
                if len(s) > 0:
                    version = s[0]

                    if int(version) <= last_version:
                        """ skip old migration file """
                        continue

                    if version in migration_file:
                        """ migration file must be unique per version """
                        app.logger.error('Migration failed due to migration file conflict at version : ' + version)
                        return None

                    migration_file[version] = name

    return migration_file


def _get_version():
    """ Read current schema version from schema_version collection """
    return db().coll_schema_version.find_one()


def _execute_migration(app, file_name):
    dirty = False
    # noinspection PyBroadException
    try:
        exec(open(file_name).read()) # nosec pylint: disable=exec-used
    except Exception as e:
        dirty = True
        app.logger.error("Exception in migration " + file_name + " : " + str(traceback.format_exc()))
        app.logger.error({str(e)})
    finally:
        return dirty


def _set_version(version, dirty):
    """ Save migration version and status to schema_version collections """
    db().coll_schema_version.delete_many({})
    db().coll_schema_version.insert_one({"version": version, "dirty": dirty, "created_at": datetime.now()})
