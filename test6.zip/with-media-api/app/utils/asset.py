import io
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from docxtpl import DocxTemplate, R
from flask import abort, send_file
from werkzeug.utils import secure_filename
from bson.objectid import ObjectId

from ..db.utils import get_document, get_document_by_id
from ..service import audit_logger
from ..service.s3 import generate_signed_url, get_file_from_url, download_asset

def get_deliverables_asset(filename, label, user):
    '''
    Get auto-generated asset
    '''
    deal_id = filename.split('deliverables/')[1].split('/')[0]

    deal = get_document_by_id('deals', ObjectId(deal_id), projection={'selectedProgram': True})
    program = get_document_by_id('mm_programs', deal.get('selectedProgram'), projection={'name': True})
    if not program:
        abort(404, description='No program found with this id: ' + deal.get('selectedProgram'))

    asset_extension = filename.split('.')[-1]
    if label and program.get('name', ''):
        attachment_filename = secure_filename(program.get('name') + '-' + label + '.' + asset_extension)
    else:
        attachment_filename = secure_filename(filename.rsplit('/', 1)[-1])

    audit_logger.log(
        'media-api',
        str(user.get('_id', 'no user associated with this download')),
        'asset',
        deal_id,
        'download',
        'GET',
        'filename : ' + filename
    )

    return send_file(download_asset(filename), as_attachment=True, attachment_filename=attachment_filename)


def get_simian_asset(filename, user):
    '''
    Get simian asset
    '''
    simian = get_document('simian_media', {'media_s3': filename}, projection={'_id': True,
                                                                              'description': True,
                                                                              'credits': True})
    if not simian:
        abort(404, description='Simian document not found for corresponding filename: ' + filename)

    program_or_npo = simian.get('credits', {}).get('program_name') or simian.get('credits', {}).get('npo_name')
    split_name = '-'.join(program_or_npo.split(' '))
    asset_extension = filename.split('.')[-1]
    attached_filename = split_name + '.' + asset_extension
    asset = send_file(download_asset(filename), as_attachment=True, attachment_filename=attached_filename)

    # if description exists, send a zipped file of description in a word doc with the image
    if len(simian.get('description', '')) > 0:
        asset = create_asset_zip(filename, simian)

    audit_logger.log(
        'media-api',
        str(user.get('_id', 'no user associated with this download')),
        'asset',
        str(simian.get('_id')),
        'download',
        'GET',
        'filename : ' + filename
    )

    return asset

def create_asset_zip(filename, simian_doc):
    '''
    Create a zip file of simian asset (photo or video) with its corresponding description
    '''
    program_or_npo = simian_doc.get('credits', {}).get('program_name') or simian_doc.get('credits', {}).get('npo_name')
    asset_filename = '-'.join(program_or_npo.split(' '))

    # populate word document
    asset_data = {
        'NAME': program_or_npo,
        'DESCRIPTION': R(simian_doc.get('description')),
    }
    doc = DocxTemplate('./app/templates/TEMPLATE_asset_download.docx')
    try:
        doc.render(asset_data, autoescape=True)
    except Exception as e:
        abort(404, message='Error creating asset zip file')

    # create temporary directory and save all files in that folder to be later zipped
    with TemporaryDirectory() as tmpdirname:
        description = tmpdirname + '/description.docx'
        doc.save(description)

        asset_extension = filename.split('.')[-1]
        signed_filename = generate_signed_url(filename)
        asset_path = get_file_from_url(signed_filename, 'simian-asset.' + asset_extension, tmpdirname).get('pathname')

        file_dict = [
            {
                'path': description,
                'filename': asset_filename + '-description.docx'
            },
            {
                'path': asset_path,
                'filename': asset_filename + '.' + asset_extension
            }
        ]

        data = io.BytesIO()
        with ZipFile(data, 'w') as zipfile:
            for f in file_dict:
                zipfile.write(f.get('path'), f.get('filename'))
        data.seek(0)

        zip_filename = asset_filename + '.zip'
        zip_file = send_file(data, mimetype='application/zip', as_attachment=True, attachment_filename=zip_filename)
        zip_file.headers['Access-Control-Expose-Headers'] = 'Content-Disposition' #explicitly expose header

        return zip_file

