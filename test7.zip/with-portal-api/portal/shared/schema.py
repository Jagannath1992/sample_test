from bson import Regex
from marshmallow import fields, Schema, post_load, validates, ValidationError
from re import escape, RegexFlag

from portal.shared.custom_fields import FormattedDateTimeField, ObjectIdField
from portal.shared.repositories import account_repository, cause_area_repository, instance_settings_repository, order_repository, transaction_repository, user_repository, locale_repository


class OrderedSchema(Schema):
    class Meta:
        ordered = True


class EntitySchema(OrderedSchema):
    """Base model for all top-level entities"""
    id = ObjectIdField(attribute='_id')
    createdBy = fields.String()
    createdAt = FormattedDateTimeField()
    lastUpdatedBy = fields.String()
    lastUpdated = FormattedDateTimeField()

    def __init__(self, *args, **kwargs):
        super().__init__(**kwargs)
        if self.partial:
            self.update_required_fields(self.fields)

    def update_required_fields(self, dictionary):
        for k, v in dictionary.items():
            if v.required:
                dictionary[k].required = False
            if type(v) == fields.Nested:
                self.update_required_fields(dictionary[k].schema.fields)


class EntityRefSchema(OrderedSchema):
    id = ObjectIdField(attribute='_id', required=True)
    type = fields.String(attribute='_type', required=True)
    name = fields.String(required=True)


class AccountReferenceSchema(EntityRefSchema):
    type = fields.String(attribute='_type', load_default='account')

    @validates('id')
    def validate_id(self, value):
        if not account_repository().exists(value):
            raise ValidationError('Account does not exist')


class OrderReferenceSchema(EntityRefSchema):
    type = fields.String(attribute='_type', load_default='order')

    @validates('id')
    def validate_id(self, value):
        if not order_repository().exists(value):
            raise ValidationError('Order does not exist')


class CauseAreaReferenceSchema(EntityRefSchema):
    type = fields.String(attribute='_type', load_default='cause_area')

    @validates('id')
    def validate_id(self, value):
        if not cause_area_repository().exists(value):
            raise ValidationError('Cause Area does not exist')


class InstanceRefSchema(EntityRefSchema):
    type = fields.String(attribute='_type', load_default='instance_settings')

    @validates('id')
    def validate_id(self, value):
        if not instance_settings_repository().exists(value):
            raise ValidationError('Instance does not exist')


class LocaleReferenceSchema(EntityRefSchema):
    type = fields.String(attribute='_type', load_default='locale')

    @validates('id')
    def validate_id(self, value):
        if not locale_repository().exists(value):
            raise ValidationError('Locale does not exist')


class TransactionReferenceSchema(EntityRefSchema):
    type = fields.String(attribute='_type', load_default='transaction')

    @validates('id')
    def validate_id(self, value):
        if not transaction_repository().exists(value):
            raise ValidationError('Transaction does not exist')


class SearchRequestBaseSchema(OrderedSchema):
    """Base model for all search requests"""

    @post_load
    def post_load(self, data, **kwargs):
        meta = type(self).Meta
        for field in getattr(meta, 'contains_fields', []):
            if field in data and data[field]:
                data[field] = Regex(escape(data[field]), RegexFlag.IGNORECASE)
        for field in getattr(meta, 'starts_with_fields', []):
            if field in data and data[field]:
                data[field] = Regex('^'+escape(str(data[field])), RegexFlag.IGNORECASE)
        for field in getattr(meta, 'range_fields', []):
            rangeData = {}
            fromField = field + 'From'
            if fromField in data:
                rangeData['$gte'] = data.pop(fromField)
            toField = field + 'To'
            if toField in data:
                rangeData['$lte'] = data.pop(toField)
            if rangeData:
                data[field] = rangeData
        for field in getattr(meta, 'in_fields', []):
            if field in data and data[field]:
                data[field] = {'$in': data.pop(field)}
        order_by = data.get('orderBy', None)
        if order_by:
            data['orderBy'] = self._convert_nested(order_by)
        return {self._convert_nested(key): data[key] for key in data}

    def _convert_nested(self, key):
        return key


class SearchRequestSchema(SearchRequestBaseSchema):
    """Request model for all search requests"""
    offset = fields.Integer(required=True)
    count = fields.Integer(required=True)
    orderBy = fields.String(required=True)
    descending = fields.Boolean(load_default=False)


class SearchResponseSchema(OrderedSchema):
    """Response model for all search responses"""
    totalCount = fields.Integer(required=True)
    results = fields.List(fields.Nested(Schema, required=True))


class AddressSchema(OrderedSchema):
    address1 = fields.String(required=True)
    address2 = fields.String(allow_none=True)
    city = fields.String(required=True)
    stateProvince = fields.String(required=True)
    postalCode = fields.String(required=True)
    country = fields.String()


class BusinessSchema(OrderedSchema):
    name = fields.String(required=False)
    address = fields.Nested(AddressSchema, required=False)
    countryCode = fields.String()
    phoneNumber = fields.String(required=False)
    website = fields.String()


class SubIndustrySchema(OrderedSchema):
    displayLabel = fields.String(required=True)
    subIndustry = fields.String(required=True)
    count = fields.Integer()


class ApproverSchema(EntityRefSchema):
    """Information on the Approver for an Approval object"""
    username = fields.String(required=True)

    @validates('id')
    def validate_approver(self, value):
        if not user_repository().exists(value):
            raise ValidationError('Approving user does not exist')


class ApprovalLevelSchema(OrderedSchema):
    """A single Approval in the AccountApproval object"""
    approver = fields.Nested(ApproverSchema, required=True)
    amount = fields.Float(load_default=0.0)


class AccountIdRequest(Schema):
    """Request model for GET by Account ID requests"""
    accountId = ObjectIdField(allow_none=True)
