import boto3
import os
import botocore
import urllib
from flask_restful import abort

ACCESS_KEY = os.environ.get('AWS_ACCESS_KEY_ID', '')
SECRET_KEY = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
ENV = os.environ.get('ENV', 'staging').lower()
s3 = boto3.client('s3', aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY)

AWS_BUCKET_GREENLIST = [
    f'{ENV}-simian-media',
    f'givewith-{ENV}-secure-upload',
    'givewith-local-secure-upload',
    'staging-simian-media',
]

def download_asset(object_name):
    bucket_name = 'givewith-' + ENV + '-secure-upload'

    file_name = object_name.rsplit('/', 1)[-1]
    file = open('/tmp/' + file_name, 'w+b')

    try:
        _download(bucket_name, object_name, file)
    except botocore.exceptions.ClientError:
        os.remove(file.name)
        return None

    return file


def _download(bucket, object_name, file):
    s3.download_file(bucket, object_name, str(file.name))
    return file


def generate_signed_url(file_name):
    '''
    Generate a signed url to display or download asset
    '''
    parsed_url = urllib.request.urlparse(file_name)
    if parsed_url.netloc:
        bucket_name = parsed_url.netloc.split('.')[0]

        file_path = file_name.split('.com/')[-1]

        url = s3.generate_presigned_url(
            ClientMethod='get_object',
            Params={
                'Bucket': bucket_name,
                'Key': file_path,
            }
        )

        return url

    return None


def get_bucket_name_from_url(url):
    parsed_url = urllib.request.urlparse(url)
    if parsed_url.netloc:
        bucket_name = parsed_url.netloc.split('.')[0]
        if bucket_name not in AWS_BUCKET_GREENLIST:
            abort(404, description='Bucket name: ' + bucket_name + ' is not valid')
    else:
        if os.environ.get('ENV'):
            bucket_name = f'givewith-{ENV}-secure-upload'
        else:
            bucket_name = 'givewith-local-secure-upload'

    return bucket_name


def does_file_exist(url):
    '''
    Check if file exists in bucket. Accepts full or partial URL
    '''
    bucket_name = get_bucket_name_from_url(url)
    filename = url.rsplit('.com/', 1)[-1]

    response = s3.list_objects_v2(
        Bucket=bucket_name,
        Prefix=filename,
    )

    for obj in response.get('Contents', []):
        if obj['Key'] == filename:
            return obj['Size'] > 0
