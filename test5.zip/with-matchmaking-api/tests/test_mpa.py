import json


def test_get_mpa(client, nonprofit_header, nonprofit_id):
    response = client.get('/nonprofit/' + str(nonprofit_id) + '/mpa', headers=nonprofit_header)
    assert response.status_code == 200


def test_patch_mpa(client, nonprofit_header, nonprofit_id):
    nonprofit_id = str(nonprofit_id)
    patch_request = {
        "phone": "555-555-1234",
    }

    response = client.patch('/nonprofit/' + nonprofit_id + '/mpa/info',  data=json.dumps(patch_request), headers=nonprofit_header)
    assert response.status_code == 200

    response = client.get('/nonprofit/' + str(nonprofit_id) + '/mpa', headers=nonprofit_header)
    mpa = json.loads(response.data.decode())
    assert response.status_code == 200

    assert mpa['info']['phone'] == patch_request['phone']

    # test invalid phone
    patch_request = {
        "phone": "123 456. 7890",
    }

    response = client.patch('/nonprofit/' + nonprofit_id + '/mpa/info', data=json.dumps(patch_request), headers=nonprofit_header)
    assert response.status_code == 400


def test_submit_mpa(client, nonprofit_header, nonprofit_id):
    nonprofit_id = str(nonprofit_id)
    response = client.post('/nonprofit/' + nonprofit_id + '/mpa:submit', headers=nonprofit_header)

    # mpa is incomplete, expect failure
    assert response.status_code == 400

    # fill mpa
    patch_info_request = {
        "orgDescription": "organizational description",
        "name": "name",
        "title": "title",
        "email": "test@email.com",
        "phone": "111-222-3333",
        "address": "first line address",
        "city": "New York",
        "state": "NY",
        "zip": "10001",
    }

    response = client.patch('/nonprofit/' + nonprofit_id + '/mpa/info', data=json.dumps(patch_info_request),headers=nonprofit_header)
    assert response.status_code == 200

    patch_review_request = {
        "name": "name",
        "email": "test@email.com",
    }

    response = client.patch('/nonprofit/' + nonprofit_id + '/mpa/review', data=json.dumps(patch_review_request), headers=nonprofit_header)
    assert response.status_code == 200

    # submit it again, expect success
    response = client.post('/nonprofit/' + nonprofit_id + '/mpa:submit', headers=nonprofit_header)
    assert response.status_code == 200


def test_progress(client, nonprofit_header, nonprofit_id):
    nonprofit_id = str(nonprofit_id)
    patch_request = {
        "orgDescription": "",
        "name": "", # name is a required field, expect incomplete progress
        "title": "title",
        "email": "test@email.com",
        "phone": "555-555-1234",
        "address": "first line address",
        "city": "New York",
        "state": "NY",
        "zip": "10001",
    }

    response = client.patch('/nonprofit/' + nonprofit_id + '/mpa/info',  data=json.dumps(patch_request), headers=nonprofit_header)
    assert response.status_code == 200

    response = client.get('/nonprofit/' + str(nonprofit_id) + '/mpa', headers=nonprofit_header)
    assert response.status_code == 200

    mpa = json.loads(response.data.decode())
    assert int(mpa['percentComplete']) < 100

