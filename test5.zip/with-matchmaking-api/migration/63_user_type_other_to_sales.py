from matchmaking import db

db().coll_user.update_many({'departmentType': 'Other'}, {'$set': {'departmentType': 'Sales'}})
