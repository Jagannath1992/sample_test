from bson import ObjectId
from pymongo.database import Database

"""
Copy impact from instance cause areas to all orders
"""
name = '20220902204440'
dependencies = ['20220726224224']


def upgrade(db: Database):
    orders = db['order'].find({})
    accounts = {}
    instances = {}

    for order in orders:
        accountId = order['account']['_id']
        if accountId not in accounts:
            accounts[accountId] = db['account'].find_one({'_id':ObjectId(accountId)})
        account = accounts[accountId]

        instanceId = account['instance']['_id']
        if instanceId not in instances:
            instances[instanceId] = db['instance_settings'].find_one({'_id':ObjectId(instanceId)})
        instance = instances[instanceId]

        causeAreaId = order['causeArea']['_id']
        impacts = [ca['impact'] for ca in instance['causeAreas'] if str(ca['causeArea']['_id']) == str(causeAreaId)]
        
        if not impacts:
            continue

        impact = impacts[0]
        orderImpact = impact.copy()
        orderImpact['totalValue'] = impact['unitValue'] * order['grandTotal'] / impact['unitPrice']
        order['causeArea']['_id'] = ObjectId(causeAreaId)
        order['causeArea']['impact'] = orderImpact
        db['order'].replace_one({'_id': order['_id']}, order)

def downgrade(db: Database):
    pass
