import json
import pytest


# CUSTOMER
def test_deal_assets_customer(client, admin_header, client_header, invalid_header):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:customer', headers=admin_header)
    assert response.status_code == 200

    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:customer', headers=client_header)
    assert response.status_code == 200

    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:customer', headers=invalid_header)
    assert response.status_code == 401


def test_deal_assets_customer_complete_only(client, client_header):
    """ Only complete deals should return assets """
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c7/assets:customer', headers=client_header)
    assert response.status_code == 403


def test_deal_assets_customer_id_must_match_deal_customer(client, client_header):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c8/assets:customer', headers=client_header)
    assert response.status_code == 403

def test_deal_assets_return_data_customer(client, client_header):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:customer', headers=client_header)
    data = json.loads(response.data.decode())

    assert 'photo' in data
    assert 'video' in data

    assert len(data['photo']) == 1
    assert '4165image_1592342618.jpg' in data['photo'][0]['media']

    assert len(data['video']) == 1
    assert 'GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4' in data['video'][0]['media']


@pytest.mark.parametrize('department', ['Sales', 'Procurement'])
def test_deal_assets_recommended(client, department, client_header_with_dept):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:customer', headers=client_header_with_dept)
    data = json.loads(response.data.decode())

    if department == 'Sales':
        assert 'recommended' in data['video'][0]
        assert 'recommended' in data['photo'][0]

    elif department == 'Procurement':
        assert 'recommended' not in data['video'][0]
        assert 'recommended' in data['photo'][0]


def test_deal_assets_customer_get_all(client, client_header):
    response = client.get('/deal/all-customer-media-assets', headers=client_header)
    assert response.status_code == 200


def test_deal_assets_customer_all_contains_all_deal_assets(client, client_header, test_db, client_user):
    response = client.get('/deal/all-customer-media-assets', headers=client_header)
    response_data = json.loads(response.data.decode())

    complete_deals = test_db.deals.find({'status': 'COMPLETE', 'givewithCustomerUser': client_user['_id']},
                                        projection={'_id': True })

    for deal in complete_deals:
        assert str(deal['_id']) in response_data



# CLIENT
@pytest.mark.parametrize('slug, password', [('5da63623e3eb8a0b0b1dd9c6', 'D0cm14er6B')])
def test_deal_assets_client(client, deal_header):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:client', headers=deal_header)
    assert response.status_code == 200


@pytest.mark.parametrize('slug, password', [('5da63623e3eb8a0b0b1dd9c7', '1Z7rx46lckm0')])
def test_deal_assets_client_complete_only(client, deal_header):
    """ Only complete deals should return assets """
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c7/assets:client', headers=deal_header)
    assert response.status_code == 403


@pytest.mark.parametrize('slug, password', [('5da63623e3eb8a0b0b1dd9c6', 'D0cm14er6B')])
def test_deal_assets_slug_must_match_token_slug(client, deal_header):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c7/assets:client', headers=deal_header)
    assert response.status_code == 403


@pytest.mark.parametrize('slug, password', [('5da63623e3eb8a0b0b1dd9c6', 'D0cm14er6B')])
def test_deal_assets_return_data_client(client, deal_header):
    response = client.get('/deal/5da63623e3eb8a0b0b1dd9c6/assets:client', headers=deal_header)
    data = json.loads(response.data.decode())

    assert 'photo' in data
    assert 'video' in data

    assert '4165image_1592342618.jpg' in data['photo']['media']
    assert 'GW_FIRST-BOOK_STORIES-FOR-ALL_SHORT.mp4' in data['video']['media']
