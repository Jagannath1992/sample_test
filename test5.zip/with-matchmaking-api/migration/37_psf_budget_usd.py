from matchmaking import db

db().coll_surveys.update_many({}, {'$set': {'Finance.currency': 'USD'}})
