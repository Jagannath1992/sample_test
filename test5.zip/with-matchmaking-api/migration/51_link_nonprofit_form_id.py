from matchmaking import db

# map stores slug to object mapping
nonprofit_slug_map = {}
nonprofit_form_slug_map = {}

nonprofits = list(db().coll_nonprofits.find({}))
nonprofit_forms = list(db().coll_nonprofit_form.find({}))


for np in nonprofits:
    nonprofit_slug_map['slug'] = np

for npf in nonprofit_forms:
    nonprofit_form_slug_map['slug'] = npf


# set ids
for nonprofit in nonprofits:
    slug = nonprofit['slug']
    if slug in nonprofit_form_slug_map:
        form = nonprofit_form_slug_map.get(slug)

        nonprofit['nonprofitSubmissionId'] = form['_id']
        form['nonprofitId'] = nonprofit['_id']

        db().coll_nonprofits.find_one_and_replace({'_id': nonprofit['_id']}, nonprofit)
        db().coll_nonprofit_form.find_one_and_replace({'_id': form['_id']}, form)


