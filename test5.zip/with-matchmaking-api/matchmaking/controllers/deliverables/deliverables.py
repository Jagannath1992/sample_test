import os
from tempfile import TemporaryFile
from flask import request, jsonify, send_file
from docxtpl import DocxTemplate
from bson import ObjectId
from botocore.exceptions import ClientError
from werkzeug.utils import secure_filename
from matchmaking.permission_decorator import require_admin_permission
from .create_template_data.assign_values import make_template_data
from ...mongodb import get_deliverables_master_data, get_funding_form
from ...controllers import admin_bp
from ...utils import send_loggly
from ...s3 import save_deliverables_file_to_s3, download_deliverable

GENERATED_FILES = [
    'CSRHighlight',
    'ESGReportingGuide_CUSTOMER',
    'ESGReportingGuide_CLIENT',
    'FactSheet',
    'InvestorRelations',
    'PressRelease',
    'SocialMediaPosts'
]

@admin_bp.route('/deliverables/<pff_id>', methods=['GET'])
@require_admin_permission
def deliverables(pff_id):
    pff = get_funding_form(ObjectId(pff_id))
    send_loggly('deliverables: generation, received request for ' + str(pff_id))

    deal_id = str(pff['deal'])
    master_data = get_deliverables_master_data(deal_id) # get all the data (hence, master, the mongodb.py)

    # just to check - make sure the pff npo and the deal npo are the same
    master_data['pff'] = pff  # also add the pff itself to master data
    send_loggly('deliverables: made master_data')

    if master_data['master_data_status'] == 'complete':
        # get just the info we need, mapped to the keys we expect in the docs
        useful_data = __make_useful_data(master_data)

        # we'll generate the docx files and write them (or overwrite them) locally
        list_of_completed_files = dict()
        for filename in GENERATED_FILES:
            list_of_completed_files[filename] = __make_document(filename, deal_id, useful_data)

        list_of_s3_files = dict()
        for completed_file in list_of_completed_files:
            list_of_s3_files[completed_file] = save_deliverables_file_to_s3(list_of_completed_files[completed_file], deal_id)

        useful_data['completed_deliverables'] = list_of_s3_files

        return jsonify(useful_data)
    else:
        error_msg = dict()
        error_msg['type'] = 'ERROR'
        error_msg['message'] = master_data['master_data_status']

        send_loggly('deliverables: error in building master data')
        send_loggly(error_msg['message'])

        return jsonify(error_msg)

def __make_document(which_document, deal_id, useful_data):
    filepath = '/tmp/' + deal_id + '_' + which_document + '.docx'  # nosec
    doc = DocxTemplate('./matchmaking/controllers/deliverables/templates/TEMPLATE_' + which_document + '.docx')

    try:
        doc.render(useful_data)
    except Exception as e:
        send_loggly('error making document ' + which_document)
        send_loggly(e)

    doc.save(filepath)
    return filepath

def __make_useful_data(master_data):
    """
    This function takes in a dictionary with *everything* (master_data) and returns a dict with key/values that are used
    to directly replace terms in the templates. The KEYS that come out of useful data are clearly visible in the functions.

    Checkout `make_template_data.py` for these functions
    """
    useful_data = dict()
    make_template_data(useful_data, master_data)

    return useful_data


def download_one_deliverable(filename, label=None, program_name=None):
    _fd = TemporaryFile()
    attachment_filename = filename.rsplit('/', 1)[-1] # format: my_picture.jpg vs. the path/filename
    filename_type = attachment_filename.split('.')[-1]

    if label and program_name:
        attachment_filename = secure_filename(program_name + '/' + label + '.' + filename_type)

    filename = filename.rsplit('/', 1)[0] + '/' + secure_filename(filename.rsplit('/', 1)[-1])
    if download_deliverable(filename, _fd):
        response = send_file(_fd, as_attachment=True, attachment_filename=attachment_filename, cache_timeout=0)
        response.direct_passthrough = False
        return response

    send_loggly('deliverables: error with downloading ' + filename)
    return 'failed to download'

@admin_bp.route('/download_deliverables', methods=['GET'])
@require_admin_permission
def download():
    filename = request.args.get('url')
    return download_one_deliverable(filename)
