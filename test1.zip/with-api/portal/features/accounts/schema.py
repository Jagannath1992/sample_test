from marshmallow import fields, Schema, post_load, validate
from portal.shared.enums import AccountType, AccountStatus
from portal.shared.custom_fields import FormattedDateTimeField, ObjectIdField, OptionalUrl
from portal.shared.schema import AddressSchema, BusinessSchema, EntitySchema, InstanceRefSchema, OrderedSchema, SearchRequestSchema, SearchResponseSchema, SubIndustrySchema, AccountReferenceSchema


class IndustrySchema(Schema):
    name = fields.String()
    items = fields.List(fields.Nested(SubIndustrySchema))


class AccountStripeSubscriptionSchema(OrderedSchema):
    id = fields.String()
    canceledAt = FormattedDateTimeField()
    cancelAt = FormattedDateTimeField()
    currentPeriodStart = FormattedDateTimeField()
    currentPeriodEnd = FormattedDateTimeField()
    newFrequencyAtPeriodEnd = fields.String()


class AccountStripeAutopaySchema(OrderedSchema):
    paymentMethodId = fields.String()
    enabledDate = FormattedDateTimeField()
    pendingMicroDepositVerification = fields.Boolean()


class AccountStripeSchema(OrderedSchema):
    customerId = fields.String()
    trialPeriodUsed = fields.Boolean()
    subscription = fields.Nested(AccountStripeSubscriptionSchema)
    autopay = fields.Nested(AccountStripeAutopaySchema)


class AccountStringField(OrderedSchema):
    label = fields.String(required=True)
    defaultValue = fields.String(allow_none=True)
    displayOrder = fields.Integer(required=True)
    required = fields.Boolean(load_default=False)
    custom = fields.Boolean(load_default=False)


class AccountNumberField(AccountStringField):
    defaultValue = fields.Float(allow_none=True)


class AccountGiveFieldsSchema(OrderedSchema):
    customerName = fields.Nested(AccountStringField)
    customerId = fields.Nested(AccountStringField)
    quoteNumber = fields.Nested(AccountStringField)
    quoteAmount = fields.Nested(AccountNumberField)
    description = fields.Nested(AccountStringField)
    customField1 = fields.Nested(AccountStringField, allow_none=True)
    customField2 = fields.Nested(AccountStringField, allow_none=True)
    customField3 = fields.Nested(AccountStringField, allow_none=True)
    customField4 = fields.Nested(AccountStringField, allow_none=True)


class ProcurementSchema(OrderedSchema):
    supplierTermsOfUseText = fields.String(allow_none=True)
    supplierTermsOfUseUrl = OptionalUrl(allow_none=True)


class AccountSchema(EntitySchema):
    """Account Model"""
    status = fields.String(required=True, validate=validate.OneOf([s.value for s in AccountStatus]))
    type = fields.String(load_default=AccountType.DEFAULT.value,
                         validate=validate.OneOf([s.value for s in AccountType]))
    industry = fields.Nested(SubIndustrySchema, required=True)
    company = fields.Nested(BusinessSchema, attribute='company', required=True)
    sageCustomerId = fields.String()
    initialBalance = fields.Float()
    currentBalance = fields.Float()
    giveFields = fields.Nested(AccountGiveFieldsSchema)
    subscriptionFrequency = fields.String()
    stripe = fields.Nested(AccountStripeSchema)
    instance = fields.Nested(InstanceRefSchema, required=True)
    procurement = fields.Nested(ProcurementSchema)
    invitedBy = fields.Nested(AccountReferenceSchema, required=False)
    subscription = fields.String()


    def set_defaults(account: dict):
        account.update({
            'status': AccountStatus.NEW.value,
            'type': AccountType.DEFAULT.value,
            'giveFields': {
                'customerName': {
                    'label': 'Sell to Customer Name',
                    'defaultValue': '',
                    'displayOrder': 0,
                    'required': True,
                    'custom': False,
                },
                'customerId': {
                    'label': 'Sell to Customer #',
                    'defaultValue': '',
                    'displayOrder': 1,
                    'required': False,
                    'custom': False,
                },
                'quoteNumber': {
                    'label': 'Quote #',
                    'defaultValue': '',
                    'displayOrder': 2,
                    'required': False,
                    'custom': False,
                },
                'quoteAmount': {
                    'label': 'Total Deal Value',
                    'defaultValue': None,
                    'displayOrder': 3,
                    'required': True,
                    'custom': False,
                },
                'description': {
                    'label': 'Description',
                    'defaultValue': '',
                    'displayOrder': 4,
                    'required': False,
                    'custom': False,
                },
            }
        })


class AccountSearchRequest(SearchRequestSchema):
    """Account Filter model for search request"""
    accountId = ObjectIdField()
    sageCustomerId = fields.String()
    company = fields.String()
    city = fields.String()
    state = fields.String()
    status = fields.String()
    type = fields.String()
    industry = fields.String()
    address = fields.String()
    invitedBy = fields.String()
    instance = ObjectIdField()

    class Meta:
        contains_fields = ['company', 'city', 'state', 'industry', 'address', 'sageCustomerId', 'invitedBy']

    def _convert_nested(self, key):
        if key == 'company':
            return 'company.name'
        elif key == 'city':
            return 'company.address.city'
        elif key == 'state':
            return 'company.address.stateProvince'
        elif key == 'industry':
            return 'industry.displayLabel'
        elif key == 'address':
            return 'company.address.address1'
        elif key == 'accountId':
            return '_id'
        elif key == 'invitedBy':
            return 'invitedBy.name'
        elif key == 'instance':
            return 'instance._id'
        return key


class AccountSearchResponse(SearchResponseSchema):
    results = fields.List(fields.Nested(AccountSchema), required=True)


class AccountRequest(AccountSchema):
    """Request Model for POST/PUT Account requests"""
    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated',
                   'initialBalance', 'currentBalance', 'subscriptionFrequency', 'stripe')


class AccountResponse(AccountSchema):
    """Response Model for GET/POST/PUT responses"""
    pass


class AccountAppSettingsResponse(Schema):
    """Response Model for GET App Settings responses"""
    id = fields.String()
    procurement = fields.Nested(ProcurementSchema)


class PutAccountActivateRequest(Schema):
    name = fields.String(required=True)
    industry = fields.Nested(SubIndustrySchema, required=True)
    address = fields.Nested(AddressSchema, required=True)
    countryCode = fields.String(required=True)
    phoneNumber = fields.String(required=True)

    @post_load
    def post_load(self, data, **kwargs):
        data['company'] = {
            'name': data.pop('name'),
            'address': data.pop('address'),
            'countryCode': data.pop('countryCode'),
            'phoneNumber': data.pop('phoneNumber')
        }
        return data


class RecommendationItem:
    """Object that represents a single program recommendation information."""

    def __init__(self, program_name, is_valid, score, id_, nonprofit, active, minimum_funding=None):
        self.program_name = program_name
        self.score = score
        self.id_ = id_
        self.nonprofit = nonprofit
        self.minimum_funding = minimum_funding
        self.is_valid = is_valid
        self.active = active
        # The fields below can be overridden later
        self.invalid_reasons = []
        self.match_type = 'MATCH'
        self.custom_match = None
        self.customer_preferred = False

    def __repr__(self):
        return f"RecommendationItem('{self.program_name}', {self.is_valid}, {self.score}, {self.id_}, '{self.nonprofit}', '{self.active}')"

    def __eq__(self, other):
        return (self.program_name == other.program_name
                and self.is_valid == other.is_valid
                and self.score == other.score
                and self.nonprofit == other.nonprofit
                and self.active == other.active
                and self.invalid_reasons == other.invalid_reasons
                and self.id_ == other.id_)

    def tojson(self):
        json = {'_id': self.id_,
                'name': self.program_name,
                'isValid': self.is_valid,
                'invalidReasons': self.invalid_reasons,
                'nonprofit': self.nonprofit,
                'match': self.score,
                'matchType': self.match_type,
                'customerPreferred': self.customer_preferred,
                'active': self.active,
                'minimumFunding': self.minimum_funding}

        if self.custom_match:
            json['customMatch'] = self.custom_match

        return json

