import logging
import os
import time
import uuid
import requests
import xmltodict
import defusedxml.ElementTree as ET

from dataclasses import asdict, dataclass
from typing import Tuple

from portal.features.error_logs.service import ErrorLogService
from portal.shared import dict_factory
from portal.shared.enums import ErrorLogSourceType
from portal.shared.errors import GivewithException, ExternalError
from portal.shared.sage.dates import get_sage_date, get_sage_legacy_date
from portal.shared.sage.enums import SageCustomFieldName, SageObjectType
from portal.shared.sage.models import SageBill, SageBillItem, SageBillItems, SageBillResult, SageBillTaxEntries, SageBillTaxEntry, \
    SageContact, SageContactResult, SageCustomField, SageCustomFields, SageCustomer, SageCustomerResult, \
    SageInvoice, SageInvoiceBillResults, SageInvoiceItems, SageInvoiceResult, SageLineItem, SageTaxEntries, SageTaxEntry
from portal.shared.sage.validator import SageValidator


class SageService:
    def __init__(self, config: dict, error_log_service: ErrorLogService):
        self.endpoint_url = os.environ.get('SAGE_ENDPOINT_URL', config.get('endpoint_url'))
        self.company_id = os.environ.get('SAGE_COMPANY_ID', config.get('company_id'))
        self.sender_id = os.environ.get('SAGE_SENDER_ID')
        self.sender_password = os.environ.get('SAGE_SENDER_PASSWORD')
        self.user_id = os.environ.get('SAGE_USER_ID')
        self.user_password = os.environ.get('SAGE_USER_PASSWORD')
        self.error_log_service = error_log_service
        self.logger = logging.getLogger()

    def create_contact(self, account, contact: SageContact) -> SageContactResult:
        """Returns contactName, recordNo"""
        try:
            try:
                result = self._create_object(SageObjectType.CONTACT, contact)
                contact = result.find('data').find('contact')
                return SageContactResult(contact.findtext('RECORDNO'), contact.findtext('CONTACTNAME'))

            except ExternalError as error:
                # convert external errors to GivewithException for logging
                raise GivewithException("Error creating Sage contact", [error])
        
        except GivewithException as ex:
            # log GivewithException
            self._log_error_with_account(ex, account)
            raise ex

    def create_customer(self, account, customer: SageCustomer) -> SageCustomerResult:
        """Returns customerId, recordNo"""
        try:
            try:
                result = self._create_object(SageObjectType.CUSTOMER, customer)
                customer = result.find('data').find('customer')
                return SageCustomerResult(customer.findtext('RECORDNO'), customer.findtext('CUSTOMERID'))

            except ExternalError as error:
                # convert external errors to GivewithException for logging
                raise GivewithException("Error creating Sage customer", [error])
        
        except GivewithException as ex:
            # log GivewithException
            self._log_error_with_account(ex, account)
            raise ex

    def update_customer(self, account, customer: SageCustomer, sageRecordNo) -> SageCustomerResult:
        """Returns customerId, recordNo"""
        try:
            try:
                result = self._update_object(SageObjectType.CUSTOMER, customer, sageRecordNo)
                customer = result.find('data').find('customer')
                return SageCustomerResult(customer.findtext('RECORDNO'), customer.findtext('CUSTOMERID'))

            except ExternalError as error:
                # convert external errors to GivewithException for logging
                raise GivewithException("Error updating Sage customer", [error])
        
        except GivewithException as ex:
            # log GivewithException
            self._log_error_with_account(ex, account)
            raise ex

    def _create_object(self, object_type: SageObjectType, object: dataclass, location_id: str = None):
        session_id, endpoint = self._get_api_session(location_id)
        authentication = {'sessionid': session_id}
        function = {
            'create': {
                object_type.value: {
                    **asdict(object, dict_factory=dict_factory.remove_none)
                }
            }
        }
        result = self._get_sage_xml_result(authentication, function, endpoint)
        return result

    def _update_object(self, object_type: SageObjectType, object: dataclass, sageRecordNo, location_id: str = None):
        session_id, endpoint = self._get_api_session(location_id)
        authentication = {'sessionid': session_id}
        function = {
            'update': {
                object_type.value: {
                    'RECORDNO': sageRecordNo,
                    **asdict(object, dict_factory=dict_factory.remove_none)
                }
            }
        }
        result = self._get_sage_xml_result(authentication, function, endpoint)
        return result

    # if fields is '*' it returns all fields from the given sage recordno
    # othereise it's a string of comma separated fields
    def _get_object(self, object_type: SageObjectType, sageRecordNo, fields, location_id: str = None):
        session_id, endpoint = self._get_api_session(location_id)
        authentication = {'sessionid': session_id}
        function = {
            'read': {
                'object': object_type.value,
                'keys': sageRecordNo,
                'fields': fields
            }
        }
        result = self._get_sage_xml_result(authentication, function, endpoint)
        return result

    def _delete_object(self, object_type: SageObjectType, sageRecordNo, location_id: str = None):
        session_id, endpoint = self._get_api_session(location_id)
        authentication = {'sessionid': session_id}
        function = {
            'delete': {
                'object': object_type.value,
                'keys': sageRecordNo
            }
        }
        self._get_sage_xml_result(authentication, function, endpoint)

    def _get_api_session(self, location_id: str = None) -> Tuple[str, str]:
        authentication = {
            'login': {
                'userid': self.user_id,
                'companyid': self.company_id,
                'password': self.user_password
            }
        }
        function = {
            'getAPISession': {
                'locationid': location_id
            }
        }
        result = self._get_sage_xml_result(authentication, function, self.endpoint_url)
        data = result.find('data').find('api')
        return (data.findtext('sessionid'), data.findtext('endpoint'))
        
    def _get_sage_xml_result(self, authentication, function, endpoint):
        self.logger.info(f'generating Sage xml request: {function}')
        payload = self._generate_payload_xml(authentication, function)
        sage_response = requests.post(endpoint, payload, headers={'Content-Type': 'application/xml'})
        if sage_response.status_code != 200:
            raise ExternalError(sage_response.status_code, sage_response.text)
        response = ET.fromstring(sage_response.text)
        if response.find('control').findtext('status') != 'success':
            raise ExternalError(sage_response.status_code, sage_response.text)
        operation = response.find('operation')
        if operation.find('authentication').findtext('status') != 'success':
            raise ExternalError(sage_response.status_code, sage_response.text)
        result = operation.find('result')
        if result.findtext('status') != 'success':
            raise ExternalError(sage_response.status_code, sage_response.text)
        return result

    def _generate_payload_xml(self, authentication: dict, function: dict):
        dictionary = {
            'request': {
                'control': {
                    'senderid': self.sender_id,
                    'password': self.sender_password,
                    'controlid': time.time(),
                    'uniqueid': False,
                    'dtdversion': 3.0,
                    'includewhitespace': False
                },
                'operation': {
                    'authentication': {
                        **authentication
                    },
                    'content': {
                        'function': {
                            '@controlid': uuid.uuid4(),
                            **function
                        }
                    }
                }
            }
        }
        return xmltodict.unparse(dictionary, short_empty_elements=True)

    def _create_legacy_object(self, object, location_id: str = None):
        session_id, endpoint = self._get_api_session(location_id)
        authentication = {'sessionid': session_id}
        function = {
            'create_invoice': {
                **asdict(object, dict_factory=dict_factory.remove_none)
            }
        }
        result = self._get_sage_xml_result(authentication, function, endpoint)
        return result

    def _get_record_id(self, sage_record_no, sage_object_type: SageObjectType, location_id: str = None):
        """Returns recordId (invoice number or bill number)"""
        results = self._get_object(sage_object_type, sage_record_no, "RECORDID", location_id)
        data = results.find('data').find(sage_object_type.value).findtext('RECORDID')
        return data

    def _create_invoice(self, invoice: SageInvoice, location_id: str) -> SageInvoiceResult:
        errors = SageValidator.validate_create_invoice(self, invoice)
        if len(errors) > 0:
            raise GivewithException("Invalid Sage invoice, cannot create", errors)
        result = self._create_legacy_object(invoice, location_id)
        sage_record_no = result.findtext('key')
        if sage_record_no is None:
            raise GivewithException("Failed to create Sage invoice")
        sage_record_id = self._get_record_id(sage_record_no, SageObjectType.ARINVOICE, location_id)
        if sage_record_id is None:
            raise GivewithException("Failed to retrieve newly created Sage invoice")
        return SageInvoiceResult(sage_record_no, sage_record_id)

    def _create_bill(self, bill: SageBill, location_id: str) -> SageBillResult:
        errors = SageValidator.validate_create_bill(self, bill)
        if len(errors) > 0:
            raise GivewithException("Invalid Sage bill, cannot create", errors)
        result = self._create_object(SageObjectType.APBILL, bill, location_id)
        ap_bill = result.find('data').find('apbill')
        record_no = ap_bill.findtext('RECORDNO')
        if record_no is None:
            raise GivewithException("Failed to create Sage bill")
        record_id = self._get_record_id(record_no, SageObjectType.APBILL, location_id)
        if record_id is None:
            raise GivewithException("Failed to retrieve newly created Sage bill")
        return SageBillResult(record_no, record_id)

    def _create_invoice_with_settings(self, instance, account, transaction, account_number, department, product_name) -> SageInvoiceResult:
        '''Can create different types of invoices'''
        today = get_sage_legacy_date()
        location_id = instance['settings']['sage']['locationId']
        tax_solution_id = instance['settings']['sage'].get('taxSolutionId') or ''
        tax_detail_id = instance['settings']['sage'].get('invoiceTaxDetailId')

        invoice = SageInvoice(
            customerid=account['sageCustomerId'],
            datecreated=today,
            dateposted=today,
            datedue=today,
            description=transaction['memo'], 
            basecurr=transaction['currency'],
            currency=transaction['currency'],
            exchratedate=today,
            exchratetype=instance['settings']['sage']['exchangeRate'],
            taxsolutionid=tax_solution_id,
            invoiceitems=SageInvoiceItems(
                lineitem=[
                    SageLineItem(
                        glaccountno=account_number,
                        amount=transaction['amount'],
                        locationid=location_id,
                        departmentid=department,
                        customfields=SageCustomFields(
                            customfield=[
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.GIVEWITH_ORDER_ID.value,
                                    # subscription transaction won't have an order reference
                                    customfieldvalue=transaction.get('order',{}).get('_id','')
                                ),
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.GIVEWITH_TRANSACTION_ID.value,
                                    customfieldvalue=transaction['_id']
                                ),
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.STRIPE_TRANSACTION_ID.value,
                                    customfieldvalue=transaction['stripe']['paymentIntentId']
                                ),
                                SageCustomField(
                                    customfieldname=SageCustomFieldName.PRODUCT_NAME.value,
                                    customfieldvalue=product_name
                                )
                            ]
                        )
                    )
                ]
            )
        )

        if tax_solution_id and tax_detail_id:
            invoice.invoiceitems.lineitem[0].taxentries = SageTaxEntries(
                taxentry=[
                    SageTaxEntry(detailid = tax_detail_id)
                ]
            )

        result = self._create_invoice(invoice, location_id)
        return result

    def _create_bill_with_settings(self, instance, transaction, vendor_id, bill_id) -> SageBillResult:
        today = get_sage_date()
        location_id = instance['settings']['sage']['locationId']
        tax_solution_id = instance['settings']['sage'].get('taxSolutionId') or ''
        tax_detail_id = instance['settings']['sage'].get('billTaxDetailId')
        service_fee_factor = instance['settings']['serviceFee']
        service_fee_amount = transaction['amount'] * service_fee_factor
        bill_amount = transaction['amount'] - service_fee_amount

        bill = SageBill(
            WHENCREATED=today,
            WHENPOSTED=today,
            WHENDUE=today,
            VENDORID=vendor_id,
            RECORDID=bill_id,
            DESCRIPTION=transaction['memo'],
            CURRENCY=transaction['currency'],
            BASECURR=transaction['currency'],
            TAXSOLUTIONID=tax_solution_id,
            APBILLITEMS=SageBillItems(
                APBILLITEM=[
                    SageBillItem(
                        ACCOUNTNO=instance['settings']['sage']['accounts']['socialImpactEnablement'],
                        OFFSETGLACCOUNTNO=instance['settings']['sage']['accounts']['socialImpactPayable'],
                        TRX_AMOUNT=bill_amount,
                        LOCATIONID=location_id,
                        DEPARTMENTID=instance['settings']['sage']['departments']['socialImpact'],
                        GIVEWITH_ORDER_ID=transaction['order']['_id'],
                        GIVEWITH_TRANSACTION_ID=transaction['_id'],
                        STRIPE_TRANSACTION_ID=transaction['stripe']['paymentIntentId'],
                        PRODUCT_NAME=instance['settings']['sage']['products']['transaction']
                    )
                ]
            )
        )

        if tax_solution_id and tax_detail_id:
            bill.APBILLITEMS.APBILLITEM[0].TAXENTRIES = SageBillTaxEntries(
                TAXENTRY=[
                    SageBillTaxEntry(DETAILID = tax_detail_id)
                ]
            )

        result = self._create_bill(bill, location_id)
        return result

    def create_subscription_invoice(self, instance, account, transaction) -> SageInvoiceResult:
        try:
            try:
                frequency = account['subscriptionFrequency']
                product_name = instance['settings']['sage']['products'][f'{frequency}Subscription']

                result = self._create_invoice_with_settings(
                    instance,
                    account,
                    transaction,
                    instance['settings']['sage']['accounts']['subscriptionRevenue'],
                    instance['settings']['sage']['departments']['sales'],
                    product_name)
                return result

            except ExternalError as error:
                # convert external errors to GivewithException for logging
                raise GivewithException("Error creating Sage invoice", [error])
        
        except GivewithException as ex:
            # log GivewithException
            self._log_error_with_transaction(ex, transaction)
            raise ex
    
    def create_give_invoice_and_bill(self, instance, account, transaction, vendor_id) -> SageInvoiceBillResults:
        try:
            try:
                invoice_result = self._create_invoice_with_settings(
                    instance,
                    account,
                    transaction,
                    instance['settings']['sage']['accounts']['transactionRevenue'],
                    instance['settings']['sage']['departments']['sales'],
                    instance['settings']['sage']['products']['transaction'])

            except ExternalError as error:
                # convert external errors to GivewithException for logging
                raise GivewithException("Error creating Sage invoice", [error])

            try:
                bill_id = invoice_result.invoiceNumber.replace('INV', 'B').replace('IN', 'B')
                bill_result = self._create_bill_with_settings(instance, transaction, vendor_id, bill_id)
                if bill_result.recordNo is None:
                    # remove the associated invoice
                    location_id = instance['settings']['sage']['locationId']
                    self._delete_object(self, SageObjectType.ARINVOICE, invoice_result.recordNo, location_id)

                return SageInvoiceBillResults(invoice_result, bill_result)

            except ExternalError as error:
                # convert external errors to GivewithException for logging
                raise GivewithException("Error creating Sage bill", [error])
        
        except GivewithException as ex:
            # log GivewithException
            self._log_error_with_transaction(ex, transaction)
            raise ex

    def _log_error_with_account(self, ex: GivewithException, account):
        self._log_error(
            ex,
            {
                '_id': account['_id'],
                '_type': 'account',
                'name': account['company']['name'],
            },
        )

    def _log_error_with_transaction(self, ex: GivewithException, transaction):
        self._log_error(
            ex,
            transaction.get('account'),
            transaction.get('order'),
            {
                '_id': transaction['_id'],
                '_type': 'transaction',
                'name': transaction['memo'],
            },
        )

    def _log_error(self, ex: GivewithException, account, order = None, transaction = None):
        self.error_log_service.log(
            ex.message,
            ErrorLogSourceType.SAGE,
            "sage@givewith.com",
            account,
            [{'code':str(err.code), 'message':err.message} for err in ex.errors],
            order,
            transaction,
        )
