from ....utils import get_descendant_key
from .utils import clean
from .research_data import make_research_data
from .general_data import make_general_data

def make_simple_mappings(useful_data, master_data):
    # here are all the simple mappings
    useful_data['PROGRAM_NAME'] = clean(master_data['program']['name'])

    if 'programNameLowerCase' in master_data['pff']:
        useful_data['PROGRAM_NAME_LOWERCASE'] = clean(master_data['pff']['programNameLowerCase'])
    else:
        useful_data['PROGRAM_NAME_LOWERCASE'] = useful_data['PROGRAM_NAME'].lower()

    if 'programNameTitleCase' in master_data['pff']:
        useful_data['PROGRAM_TITLE'] = clean(master_data['pff']['programNameTitleCase'])
    else:
        useful_data['PROGRAM_TITLE'] = useful_data['PROGRAM_NAME'].title()

    if 'programDescription' in master_data['pff']:
        useful_data['PROGRAM_DESCRIPTION'] = clean(master_data['pff']['programDescription'])
    else:
        useful_data['PROGRAM_DESCRIPTION'] = clean(master_data['pff']['General']['description']['value'])

    if 'name' in master_data['nonprofit']:
        useful_data['NONPROFIT_NAME'] = clean(master_data['nonprofit']['name'])

    useful_data['NONPROFIT_DESCRIPTION'] = clean(master_data['nonprofit']['description'])

    short_nonprofit_description = clean(master_data['nonprofit']['descriptionShort'])
    if len(short_nonprofit_description.strip()) == 0:
        short_nonprofit_description = useful_data['NONPROFIT_DESCRIPTION'].split('.')[0]
    useful_data['NONPROFIT_DESCRIPTION_SHORT'] = short_nonprofit_description

    useful_data['CLIENT_NAME'] = clean(master_data['client']['name'])
    useful_data['DEAL_YEAR'] = master_data['deal']['createdAt'].strftime('%Y')
    useful_data['CUSTOMER_NAME'] = clean(master_data['customer']['name'])

    # will be dollars, and if not set to dollars, will be '€'
    CURRENCY_MAPPING = {
        'EUR': '€',
        'GBP': '£',
        'USD': '$'
    }
    funding_currency = '$'
    if 'currency' in master_data['deal']:
        funding_currency = CURRENCY_MAPPING[master_data['deal']['currency']]

    useful_data['FUNDING_AMOUNT'] = funding_currency + '{:,}'.format(master_data['deal']['fundingAmount'])

    useful_data['PROGRAM_URL'] = get_descendant_key(master_data,'nonprofit.general.social.websiteURL', '**ERROR MISSING NON PROFIT URL**')


def make_template_data(useful_data, master_data):
    # following functions must be in this order
    make_simple_mappings(useful_data, master_data)
    make_research_data(useful_data, master_data)
    make_general_data(useful_data, master_data)
