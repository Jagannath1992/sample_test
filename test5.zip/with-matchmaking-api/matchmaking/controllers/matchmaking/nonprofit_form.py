from ... import s3
from flask import request, jsonify
from werkzeug.utils import secure_filename

from ...validation.nonprofit_form import validate_init_form_request, validate_completed_form, validate_file_upload
from ...validation.utils import validate_object_id
from ...controllers import admin_bp, public_bp
from ...permission_decorator import require_admin_permission
from ...utils import GivewithError
from ...dao import nonprofit_form_dao, utils
from matchmaking.service.slack import send_si_platform_message


"""
@api {post} /admin/nonprofit-form:init Initialize nonprofit form
@apiName InitializedForm
@apiGroup NAF-Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Initialize a nonprofit form. Form status will set to Initialized.


@apiParam {String} applicationFormName the application form name
@apiParam {String} givewithAdmin manager user id

@apiError 403 Insufficient permissions
@apiError 400 Bad request

@apiParamExample {json} request example:
{
    "applicationFormName": "Plan International USA",
    "givewithAdmin": "5a611261d57e4529cd3a24eb",
}

@apiSuccessExample {json} response example:
{
    "_id": "5b295563e3dde1001ae176d7",
    "applicationFormName": "Plan International USA",
    "givewithAdmin": "5a611261d57e4529cd3a24eb",
    "percentage": 0,
    "edit": true,
    "createdAt": "2020-01-21T18:26:20.862362Z",
    "lastUpdated": "2020-01-21T18:26:20.862362Z",
    "createdBy": "5a611261d57e4529cd3a24eb",
    "slug": "plan-international-usa",
    "status": "initialized",
}
"""
@admin_bp.route('/nonprofit-form:init', methods=['POST'])
@require_admin_permission
def init_form():
    init_request = request.json
    errors = validate_init_form_request(init_request)
    if len(errors) > 0:
        raise GivewithError(errors, code=400)

    return jsonify(nonprofit_form_dao.add_form(init_request))



"""
@api {get} /admin/nonprofit-form/:form_id Get a nonprofit form
@apiName GetForm
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Get a nonprofit from by the id

@apiParam {String} form_id the nonprofit form id

@apiError 403 Insufficient permissions
@apiError 404 Not found

@apiSuccessExample {json} response example:
{
    "_id": "5b295563e3dde1001ae176d7",
    "applicationFormName": "Plan International USA",
    "givewithAdmin": "5a611261d57e4529cd3a24eb",
    "percentage": 0,
    "edit": true,
    "createdAt": "2020-01-21T18:26:20.862362Z",
    "lastUpdated": "2020-01-21T18:26:20.862362Z",
    "createdBy": "5a611261d57e4529cd3a24eb",
    "slug": "plan-international-usa",
    "status": "initialized",
}
"""
@admin_bp.route('/nonprofit-form/<form_id>', methods=['GET'])
@require_admin_permission
def get_form(form_id):
    validate_object_id(form_id, 'nonprofit_form')
    return jsonify(nonprofit_form_dao.get_form(form_id))



"""
@api {get} /admin/nonprofit-form List nonprofit forms
@apiName ListForms 
@apiGroup NAF-Admin
@apiPermission admin
@apiDescription List all nonprofit forms.
@apiVersion 0.1.0

@apiParam Filtering params
@apiParam Soring params
@apiParam Pagination params

@apiError 403 Insufficient permissions

@apiSuccessExample {json} response example:
[
    {
        "_id": "5b295563e3dde1001ae176d7",
        "applicationFormName": "Plan International USA",
        "givewithAdmin": "5a611261d57e4529cd3a24eb",
        "percentage": 0,
        "edit": true,
        "createdAt": "2020-01-21T18:26:20.862362Z",
        "lastUpdated": "2020-01-21T18:26:20.862362Z",
        "createdBy": "5a611261d57e4529cd3a24eb",
        "slug": "plan-international-usa",
        "status": "INITIALIZED",
    },
    {
        "_id": "5b295563e3dde1001ae176d9",
        "applicationFormName": "Australian animals protection society",
        "givewithAdmin": "5a611261d57e4529cd3a24eb",
        "percentage": 10,
        "edit": true,
        "createdAt": "2020-01-21T18:26:20.862362Z",
        "lastUpdated": "2020-01-21T18:26:20.862362Z",
        "createdBy": "5a611261d57e4529cd3a24eb",
        "slug": "plan-international-usa",
        "status": "IN_PROGRESS",
    },
]
"""
@admin_bp.route('/nonprofit-form', methods=['GET'])
@require_admin_permission
def list_forms():
    return jsonify(nonprofit_form_dao.list_forms())


"""
@api {delete} /admin/nonprofit-form/:form_id Delete a nonprofit form
@apiName DeleteForm
@apiVersion 0.1.0
@apiGroup NAF-Admin
@apiPermission admin
@apiDescription Hard delete a nonprofit from by id.

@apiParam {String} form_id the nonprofit form id

@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@admin_bp.route('/nonprofit-form/<form_id>', methods=['DELETE'])
@require_admin_permission
def delete_form(form_id):
    validate_object_id(form_id, 'nonprofit_form')
    nonprofit_form_dao.delete_form(form_id)
    return ''


"""
@api {patch} /admin/nonprofit-form/:form_id Update nonprofit form
@apiName UpdateForm
@apiGroup NAF-Admin
@apiVersion 0.1.0
@apiPermission admin
@apiDescription Update a nonprofit from by id.

@apiParam {String} form_id the nonprofit form id

@apiParamExample {json} request example:
{
    'general': {
        'name': {
            'legalOrganizationName': 'Plan International USA',
            'publicOrganizationName': 'Plan International USA',
        },
        'social': {
            'websiteURL': 'https://www.planusa.org',
            'facebook': 'https://www.facebook.com/planusa',
            'instagram': 'https://www.instagram.com/plan_usa/',
            'twitter': 'https://twitter.com/PlanUSA',
            'linkedIn': 'https://www.linkedin.com/company/plan-usa',
        },
        'contact': {
            'name': 'alice',
            'professionalTitle': 'manager',
            'email': 'alice@email.com',
            'phone': '111-222-333',
        },
        'location': {
            'generalLocation': 'US',
            'specificLocation': 'Plan International USA, 155 Plan Way, Warwick, RI 02886',
            'taxId': '111-11-111',
            'w9': 'TODO',
            'charityNumber': 'TODO',
            'companyHouseNumber': '155',
            'otherId': '',
        },
        'missionAgreement': false,
    },
    'overviewAndMission': {
        'historyDescription': 'Plan International USA was originally incorporated as Foster Parents Plan, Inc.',
        'problemDescription': 'Returning from a recent congressional delegation to El Salvador.',
        'causeAreas': ['TODO', 'TODD'],
        'initiativesDescription': 'TODO',
        'programLocations': 'Warwick',
        'researchAndEvaluation': 'TODO',
        'researchAndEvaluationFile': 's3:link',
        'lifetimeOutputs': [
            {
                'output': 'TODO',
                'outputNumber': 1,
            }
        ],
    },
    'operationalInformation': {
        'staff': {
            'fullTime': 10,
            'partTime':  15,
            'volunteers': 20,
        },
        'partnershipsDescription': 'description',
        'yearlyBudget': 1,
        'financialStatement': {
            'url': 'https://www.planusa.org/financial',
            'file': 's3:link/plan-usa',
        },
        'supportersAndPartners': 'TODO',
    },
    'review': {
        'name': 'alice',
        'email': 'alice@planusa.com',
        'agreement': true,
    }
}


@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@admin_bp.route('/nonprofit-form/<form_id>', methods=['PATCH'])
@require_admin_permission
def update_form(form_id):
    validate_object_id(form_id, 'nonprofit_form')

    update_request = request.json
    if update_request is None:
        raise GivewithError('bad request', code=400)

    flip = False
    if update_request.get('editing', False):
        form = utils.get_document_by_id('nonprofit_form', form_id)
        if not form['editing']:
            nonprofit_id = str(form.get('nonprofitId', ''))
            flip = len(nonprofit_id) > 0

    nonprofit_form_dao.update_form(form_id, update_request)

    if flip:
        form = utils.get_document_by_id('nonprofit_form', form_id)
        nonprofit_id = str(form.get('nonprofitId', ''))
        nonprofit = utils.get_document_by_id('mm_nonprofits', nonprofit_id)
        nonprofit['editing'] = True
        nonprofit_form_dao.update_form(form_id, nonprofit)

    return jsonify(nonprofit_form_dao.get_form(form_id))


"""
@api {post} /admin/nonprofit-form:approve/:form_id Approve nonprofit form
@apiName ApproveForm
@apiGroup NAF-Admin
@apiVersion 0.1.0
@apiDescription Approve a nonprofit form by id. Form status will be set to approved, and a copy will be add into nonprofit collection.

@apiParam {String} form_id the nonprofit form id

@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@admin_bp.route('/nonprofit-form:approve/<form_id>', methods=['POST'])
@require_admin_permission
def approve_form(form_id):
    validate_object_id(form_id, 'nonprofit_form')
    nonprofit_form_dao.approve_form(form_id)
    return jsonify(nonprofit_form_dao.get_form(form_id))


"""
@api {patch} /survey/nonprofit-form/:form_id Update nonprofit form
@apiName UpdateForm
@apiGroup NAF-Nonprofit
@apiVersion 0.1.0
@apiPermission public
@apiDescription Update a nonprofit from by the form id.

@apiParam {String} form_id the nonprofit form id

@apiParamExample {json} request example:
{
    'general': {
        'name': {
            'legalOrganizationName': 'Plan International USA',
            'publicOrganizationName': 'Plan International USA',
        }
    }
}

@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@public_bp.route('/nonprofit-form/<form_id>/<form_name>', methods=['PATCH'])
def patch_form(form_id, form_name):
    validate_object_id(form_id, 'nonprofit_form')

    patch_request = request.json
    if not patch_request:
        raise GivewithError('bad request', code=400)

    wrap_request = {
        form_name: patch_request
    }

    nonprofit_form_dao.update_form(form_id, wrap_request)
    return jsonify(nonprofit_form_dao.get_form(form_id))


"""
@api {post} /nonprofit-form:submit/:form_id Submit nonprofit form
@apiName SubmitForm
@apiGroup NAF-Nonprofit
@apiVersion 0.1.0
@apiPermission public
@apiDescription Submit a nonprofit form for approval. Form status will change to Submitted.

@apiParam {String} form_id the nonprofit form id

@apiError 403 Insufficient permissions
@apiError 404 Not found
"""
@public_bp.route('/nonprofit-form:submit/<form_id>', methods=['POST'])
def submit_form(form_id):
    validate_object_id(form_id, 'nonprofit_form')

    form = nonprofit_form_dao.get_form(form_id)
    errors = validate_completed_form(form)
    if len(errors) > 0:
        raise GivewithError('Unable to submit form for approval. details: %s' % errors, code=400)

    nonprofit_form_dao.submit_form(form_id)
    send_si_platform_message(True, 'NAF created successfully', {'id': form_id, 'name': form['applicationFormName']})
    return jsonify(nonprofit_form_dao.get_form(form_id))


"""
@api {get} /nonprofit-form/:form_id Get a nonprofit form
@apiName GetForm 
@apiGroup NAF-Nonprofit
@apiVersion 0.1.0
@apiPermission public
@apiDescription Get a nonprofit from by the id

@apiParam {String} form_id the nonprofit form id

@apiError 403 Insufficient permissions
@apiError 404 Not found

@apiSuccessExample {json} response example:
{
    "_id": "5b295563e3dde1001ae176d7",
    "applicationFormName": "Plan International USA",
    "givewithAdmin": "5a611261d57e4529cd3a24eb",
    "percentage": 0,
    "edit": true,
    "createdAt": "2020-01-21T18:26:20.862362Z",
    "lastUpdated": "2020-01-21T18:26:20.862362Z",
    "createdBy": "5a611261d57e4529cd3a24eb",
    "slug": "plan-international-usa",
    "status": "initialized",
}
"""
@public_bp.route('/nonprofit-form/<form_id>', methods=['GET'])
def get_form_by_nonprofit(form_id):
    validate_object_id(form_id, 'nonprofit_form')
    return jsonify(nonprofit_form_dao.get_form(form_id))


"""
@api {post} /nonprofit-form/:form_id/:form_name/file Upload file
@apiName UploadFile
@apiGroup NAF-Nonprofit
@apiVersion 0.1.0
@apiPermission public
@apiDescription Upload a file for nonprofit form

@apiParam {String} form_id the nonprofit form id
@apiParam {String="general", "operationalInformation"} form_name the first level key name
@apiParam {String} path the key name
@apiParam {File} file the upload file

@apiError 403 Insufficient permissions
@apiError 404 Not found

@apiSuccessExample {json} request example:
{
    "path": "location.w9.file",
    "file": "w9.pdf"
}
"""
@public_bp.route('/nonprofit-form/<form_id>/<form_name>/file', methods=['POST'])
def upload_file(form_id, form_name):
    validate_object_id(form_id, 'nonprofit_form')

    errors = validate_file_upload(request)
    if len(errors) > 0:
        raise GivewithError(errors, code=400)

    path = request.form['path']
    file = request.files['file']
    file_name = 'nonprofit_form/%s/%s' % (form_id, secure_filename(file.filename))
    url = s3.upload_file(file, file_name)

    # prepare new form
    form = nonprofit_form_dao.get_form(form_id)
    file_section = form

    path = form_name + '.' + path
    paths = path.split('.')
    for p in paths:
        if p not in file_section:
            file_section[p] = {}

        file_section = file_section.get(p)

    file_section['name'] = file.filename
    file_section['url'] = url

    return jsonify(nonprofit_form_dao.update_form(form_id, form))


"""
@api {delete} /nonprofit-form/:form_id/file Delete file
@apiName DeleteFile
@apiGroup NAF-Nonprofit
@apiVersion 0.1.0
@apiPermission public
@apiDescription Delete a file for nonprofit form

@apiParam {String} form_id the nonprofit form id
@apiParam {String="general", "operationalInformation"} form_name the first level key name
@apiParam {String} path the key name

@apiError 403 Insufficient permissions
@apiError 404 Not found

@apiSuccessExample {json} response example:
{
    "path": "location.w9",
}
"""
@public_bp.route('/nonprofit-form/<form_id>/<form_name>/file', methods=['DELETE'])
def delete_file(form_id, form_name):
    validate_object_id(form_id, 'nonprofit_form')

    if request.json is None or 'path' not in request.json:
        raise GivewithError('bad request', code=400)

    form = nonprofit_form_dao.get_form(form_id)
    file_section = form[form_name]

    path = request.json['path'].split('.')
    i = 0
    while i < len(path) - 1:
        file_section = file_section.get(path[i], {})
        i += 1

    file_section = file_section.pop(path.pop())

    if 'url' not in file_section:
        return jsonify(file_section)

    file_name = file_section['url'].split('/')[-1]
    s3.delete_file('nonprofit_form', form_id, file_name)

    return jsonify(nonprofit_form_dao.replace_form(form_id, form))


"""
@api {get} /nonprofit-form/vocabulary
@apiName Get Vocabulary
@apiGroup NAF-Nonprofit
@apiVersion 0.1.0
@apiPermission public
@apiDescription Get locations and causes for nonprofit form


@apiError 403 Insufficient permissions
@apiError 404 Not found

@apiSuccessExample {json} response example:
{
    'location': [
        {
            "_id" : ObjectId("5c9b9fdc2268f1807003b5c2"),
            "location_type" : [ 
                "Global Headquarters", 
                "Regional Headquarters", 
                "Factory or Industrial Facility", 
                "General Operations"
            ],
            "continental_region" : [ 
                "Europe", 
                "Asia", 
                "Australia", 
                "Africa", 
            ],
            "country" : {
                "AD" : "Andorra",
                "AE" : "United Arab Emirates",
                "AF" : "Afghanistan",
            },
            "regional_territory" : {
                "US" : [ 
                    "Pacific Northwest", 
                    "Midwest", 
                    "Northeast", 
                    "South/Southeast", 
                ]
            },
            "state" : {
                "US" : [ 
                    "Alabama", 
                    "Alaska", 
                    "Arizona", 
                    "Arkansas", 
                    "California", 
                    "Colorado", 
                    "Connecticut", 
                    "Delaware",
                ],
                "CA" : [ 
                    "Ontario", 
                    "British Columbia", 
                    "Alberta", 
                    "Nova Scotia"
                ]
            },
            "locationTree" : {
                "continents" : [ 
                    {
                        "name" : "Africa"
                    }, 
                ],
                "countries" : {
                    "Africa" : [ 
                        {
                            "name" : "Algeria"
                        }, 
                        {
                            "name" : "Angola"
                        },
                    ]
                },
                "cities" : {
                    "Algeria" : [
                        {
                            "name" : "Algiers"
                        },
                    ],
                }
            }
        }
    ],
    'causes': [
        {
            "_id" : ObjectId("5a99921742073d0946343faf"),
            "label" : "Arts & Culture",
            "type" : "causes",
            "icon" : "assets/causes/icons/art-culture.svg",
            "slug" : "arts-and-culture",
            "versions" : [ 
                1
            ]
        }, 
        {
            "_id" : ObjectId("5a99921742073d0946343fb1"),
            "label" : "Economic Development",
            "type" : "causes",
            "icon" : "assets/causes/icons/economic-development.svg",
            "slug" : "economic-development",
            "versions" : [ 
                1
            ]
        }
    ]
    
}
"""
@public_bp.route('/nonprofit-form/vocabulary', methods=['GET'])
def get_vocabulary():
    return jsonify(nonprofit_form_dao.get_vocabulary())
