import pytest
from bson import ObjectId
from portal.shared.repositories import instance_settings_repository
from portal.features.accounts.schema import PutAccountActivateRequest, AccountSearchRequest, AccountRequest
from marshmallow import ValidationError


class TestPutAccountActivateRequest():
    @pytest.fixture()
    def schema(self) -> PutAccountActivateRequest:
        return PutAccountActivateRequest()

    @pytest.fixture()
    def request_data(self):
        return {
            'name': 'Acme Corp',
            'industry': {
                'displayLabel': 'Make Things Industry',
                'subIndustry': 'Make Things',
            },
            'address': {
                'address1': '123 Main Street',
                'address2': '',
                'city': 'Anytown',
                'stateProvince': 'LA',
                'postalCode': '55555',
                'country': 'USA'
            },
            'countryCode': '+1',
            'phoneNumber': '555-555-5555'
        }

    def test_load(self, request_data, schema):
        # arrange
        address = request_data['address']
        expected = {
            'industry': request_data['industry'],
            'company': {
                'name': request_data['name'],
                'address': {
                    'address1': address['address1'],
                    'address2': address['address2'],
                    'city': address['city'],
                    'stateProvince': address['stateProvince'],
                    'postalCode': address['postalCode'],
                    'country': address['country'],
                },
                'countryCode': request_data['countryCode'],
                'phoneNumber': request_data['phoneNumber']
            }
        }

        # act
        actual = schema.load(request_data)

        # assert
        assert actual == expected


class TestAccountSearchRequest:

    def test_post_load_converts_fields(self):
        data = {
            'count': 10,
            'orderBy': 'name',
            'offset': 0,
            'company': 'Company Name',
            'city': 'Address City',
            'address': 'Address 1',
            'accountId': ObjectId()
        }

        response = AccountSearchRequest().load(data)

        assert response['company.name'].try_compile().match('Company Name')
        assert response['company.address.city'].try_compile().match('Address City')
        assert response['company.address.address1'].try_compile().match('Address 1')
        assert response['_id'] == data['accountId']

    def test_post_load_base_method(self):
        data = {
            'count': 10,
            'orderBy': 'name',
            'offset': 0,
            'company': 'Company'
        }

        response = AccountSearchRequest().load(data)

        assert response['company.name'].try_compile().match('Company Name')


class TestAccountRequest:
    @pytest.fixture
    def schema(self) -> AccountRequest:
        return AccountRequest()

    @pytest.fixture()
    def request_data(self, schema, mocker, fakers):
        mocker.patch.object(instance_settings_repository(), 'exists', return_value=True)
        account = fakers.account.generate_single()
        return schema.dump(account)

    def test_validate(self, request_data, schema):
        # act
        result = schema.validate(request_data)

        # assert
        assert not result

    def test_validate_blank_status(self, request_data, schema):
        # arrange
        request_data.update({'status': ''})

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'status': [
            'Must be one of: new, pending, pending stripe, pending finance, active, locked, inactive, deleted.']}

    def test_validate_bad_status(self, request_data, schema):
        # arrange
        request_data.update({'status': 'amazing'})

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'status': [
            'Must be one of: new, pending, pending stripe, pending finance, active, locked, inactive, deleted.']}

    def test_validate_null_status(self, request_data, schema):
        # arrange
        request_data.update({'status': None})

        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'status': ['Field may not be null.']}

    def test_validate_missing_status(self, request_data, schema):
        # arrange
        request_data.pop('status')
        # act
        with pytest.raises(ValidationError) as error:
            schema.load(request_data)

        # assert
        assert error.value.messages == {'status': ['Missing data for required field.']}
