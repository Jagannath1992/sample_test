# Research API utils
import random
import string
import secrets
import math

from enum import Enum
from itertools import filterfalse
from os import environ
from .logger import log_error
import constants
import json
import requests

class GivewithErrorType(str, Enum):
    ERROR = 'ERROR'
    MAINTENANCE = 'MAINTENANCE'
    SUCCESS = 'SUCCESS'

class GivewithError(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(args[0])
        self.code = kwargs.get('code', 400)
        self.type = kwargs.get('type', GivewithErrorType.ERROR)

class MaintenanceMode(GivewithError):
    def __init__(self, message):
        self.code = 503
        self.type = GivewithErrorType.MAINTENANCE
        self.message = message

    def __str__(self):
        return self.message

class ValidationError(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(args[0])
        self.code = kwargs.get('code', 400)

class GivewithLookupError(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(args[0])
        self.code = kwargs.get('code', 400)

class MissingFieldError(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(args[0])
        self.code = kwargs.get('code', 400)

class DatasetNotFound(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(args[0])
        self.code = kwargs.get('code', 400)

class PipelineError(Exception):
    def __init__(self, message, success, *args, **kwargs):
        self.code = 500
        self.type = kwargs.get('type', GivewithErrorType.ERROR)
        self.success = success
        self.message = message

    def __str__(self):
        return self.message


def is_volume_score_type(score_type):
    if score_type.startswith('volume_'):
        return score_type[7:]
    else:
        return False


def generate_random_slug(length=15):
    return generate_secure_random_string(length)


def generate_secure_random_string(length):
    """ From official python docs: https://docs.python.org/3/library/secrets.html """
    alphabet = string.ascii_letters + string.digits
    password = ''
    while True:
        password = ''.join(secrets.choice(alphabet) for i in range(length))
        if (any(c.islower() for c in password)
                and any(c.isupper() for c in password)
                and sum(c.isdigit() for c in password) >= 3):
            break

    return password


def expand_dot_fields(brand):
    """
    Expands a dict with dot notation
    to a nested dict

    eg:
        - {'top_key.nested_key': 'value'} -> {'top_key': {'nested_key': value}}

    Used for MongoDB as it seems to want either nesting OR dot notation, not a mix of both
    """
    fields_to_update = {}
    for key in list(brand.keys()):
        dot_index = key.find('.')

        if dot_index != -1:
            value = brand.pop(key)
            prefix = key[:dot_index]
            suffix = lowercase_first(key[dot_index+1:])

            if prefix in fields_to_update:
                fields_to_update[prefix][suffix] = value
            else:
                fields_to_update[prefix] = {suffix: value}

    brand.update(fields_to_update)
    return brand


def lowercase_first(string):
    if string != '':
        return string[0].lower() + string[1:]
    else:
        return string


def is_empty(value):
    if type(value) in (int, bool):
        return False
    if type(value) == str:
        return not value.strip()
    if type(value) == float:
        return math.isnan(value)

    return not value


def remove_empty(document):

    filtered = {key: value for key, value in document.items() if not is_empty(value)}

    document.clear()
    for key, value in filtered.items():
        if type(value) == list:
            if all(isinstance(n, dict) for n in value):
                value = [remove_empty(n) for n in value]
            else:
                value = list(filterfalse(is_empty, value))
        if type(value) == dict:
            value = remove_empty(value)

        if not is_empty(value):
            document[key] = value

    return document