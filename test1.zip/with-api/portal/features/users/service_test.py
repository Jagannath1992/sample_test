import json
import pytest
import requests
from werkzeug.exceptions import BadGateway
from portal.shared.encoder import CustomJSONEncoder
from portal.shared.repositories import user_repository
from portal.shared.services import auth_service
from portal.testing.mocks import MockResponse


class TestAuthService:
    @pytest.fixture
    def test_create_user_init(self, fakers, mocker):
        user = fakers.user.generate_single()
        mocker.patch.object(requests, 'post', return_value=MockResponse(
            data=json.loads(json.dumps(user, cls=CustomJSONEncoder))))
        mocker.patch.object(user_repository(), 'patch', return_value=user)
        account = fakers.account.generate_single()
        error_message = 'Error message'
        return user, account, error_message

    def test_create_user(self, test_create_user_init):
        # arrange
        user, account, error_message = test_create_user_init

        # act
        response = auth_service().create_user(user, account['_id'], error_message, user['username'])

        # assert
        requests.post.assert_called_once_with(
            f'{auth_service().base_url}/v1/okta/user',
            json=json.loads(json.dumps(user, cls=CustomJSONEncoder))
        )
        user_repository().patch.assert_called_once_with(str(user['_id']), {'accountId': account['_id']})
        assert response == user

    def test_create_user_exception(self, test_create_user_init):
        # arrange
        requests.post.return_value = MockResponse(500)
        user, account, error_message = test_create_user_init

        # act
        with pytest.raises(BadGateway) as error:
            auth_service().create_user(user, account['_id'], error_message, user['username'])

        # assert
        requests.post.assert_called_once_with(
            f'{auth_service().base_url}/v1/okta/user',
            json=json.loads(json.dumps(user, cls=CustomJSONEncoder))
        )
        user_repository().patch.assert_not_called()
        assert error.value.description == error_message


class TestAuthService_Integration:
    pytestmark = pytest.mark.integration

    @pytest.mark.skip
    def test_create_user(self, services):
        '''Integration Test: unique username must be provided'''

        auth_service = services["auth"]

        payload = {
            "username": "",
            "first_name": "Test",
            "last_name": "User",
            "orgId": "",
            "orgName": "Test Co.",
            "orgType": "brand",
            "type": "client",
            "departmentType": "Portal",
            "businessAddress": "123 N. Main St., Houston, TX 77002",
            "phoneNumber": "555-555-5555"
        }

        assert payload["username"] != ""

        response = auth_service.create_user(payload)

        assert response.status_code == 200
