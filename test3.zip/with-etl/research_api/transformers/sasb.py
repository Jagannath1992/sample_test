import logging
import research_api.mongodb as mongodb


# create some convenience objects
class sasb_company:
    def __init__(self, isin, name, sic_code, sic_string):
        self.ISIN = isin
        self.company_name = name
        self.sic_industry_code = sic_code
        self.sic_industry_name = sic_string
    
class sasb_industry:
    def __init__(self, industry_code, industry, sector):
        self.sector = sector
        self.industry = industry
        self.industry_code = industry_code
        self.disclosure_topics = set()
        self.sustainability_dimensions = set()
        self.gics = set()
# 65513
# ISINS = [brand.get('ISIN',"") for brand in brands]
#     names = [{ '$regexMatch': { 'input': "$name", 'regex': brand.get('name'), 'options': "i" } }for brand in brands]
#     query = {'$or': [{'ISIN': {'$in': ISINS}}, {'$expr': {'$or': names}}]}

def transform_sasb(dataset, data):
    # step1(data['sasb_mapping'])
    topics = _load_topics(data['sasb_topics_materiality_map'], dataset)
    vocab = mongodb.get_sasb_vocab()

    sasb_brands = _transform_sasb_brands(data['sasb_mapping'])

    brands = []
    for ISIN, brand in sasb_brands.items():
        industry_code = brand.sic_industry_code
        sasb_industry_data = topics.get(industry_code)
        brands.append(_get_sasb_dict(brand, sasb_industry_data, vocab))

    data = brands
    return data

        
def _get_sasb_dict(brand, _sasb_industry, vocab):
    """ Creates a SASB document to be appended to a brand in the database """
    data = dict()
    data["ISIN"] = brand.ISIN
    data["name"] = brand.company_name
    data["sector"] = str(_sasb_industry.sector)
    data["industry"] = str(_sasb_industry.industry)
    data["industry_code"] = str(_sasb_industry.industry_code)
    
    topics = list()
    for t in _sasb_industry.disclosure_topics:
        topics.append(t)
    data["disclosure_topics"] = topics
    
    sustain = list()
    for s in _sasb_industry.sustainability_dimensions:
        sustain.append(s)
    data["sustainability_dimensions"] = sustain
    
    gics_data = dict()
    gics_strings = list()
    gics_match = dict()
    gics_match_ids = list()
    gics_match_labels = list()
    for g in _sasb_industry.gics:
        gics_strings.append(g)
        if g in vocab:
            gics_match_ids.append(vocab[g])
            gics_match_labels.append(g)
            
    gics_data["all_labels"] = gics_strings
    gics_match["labels"] = gics_match_labels
    gics_match["ids"] = gics_match_ids
    gics_data["tagged"] = gics_match
    data["categories"] = gics_data
        
    return data


def _load_topics(sasb_topics_MM, dataset):
    topics = {}
    for _tuple in sasb_topics_MM.itertuples():
        row = _tuple[1:]

        sector = row[1]
        industry_code = row[2]
        industry_name = row[3]

        disclosure_topic = row[5]
        sustainability_dimension = row[6]
        gic = row[7]  # NOT gic like the industry

        if industry_code in topics:
            industry_data = topics[industry_code]
        else:
            industry_data = sasb_industry(industry_code, industry_name, sector)

        industry_data.disclosure_topics.add(disclosure_topic)
        industry_data.sustainability_dimensions.add(sustainability_dimension)
        industry_data.gics.add(gic)

        topics[industry_code] = industry_data

    print("I have " + str(len(topics)) + " topics loaded")
    return topics


def _transform_sasb_brands(sasb_mapping):
    """
    ISIN	Company	Country	SICS Codified Industry Code	SICS Codified Industry 	SICS Codified Sub-Sector Code	SICS Codifed Sub-Sector	SICS Codified Sector Code	Codified SICS Sector
    """
    brands = dict() #store brands, keyed by ISIN
    for row in sasb_mapping.itertuples():
        ISIN = row[1]
        company = row[2]
        sics_industry_code = row[5]
        sics_industry = row[6]
        brands[ISIN] = sasb_company(ISIN, company, sics_industry_code, sics_industry)

    return brands
