import requests
import os

from flask import request
from bson.json_util import dumps

PROPOSAL_URL = 'https://hooks.slack.com/services/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'
SI_PLATFORM_UPDATE_URL = 'https://hooks.slack.com/services/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'
NEW_BRAND_REQUEST_URL = 'https://hooks.slack.com/services/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'
ADMIN_URL = os.environ.get('ADMIN_URL', 'https://admin.nohardstops.com')
headers = {'Content-Type': 'application/json'}

# TODO: These call to slack is a little slow, would be nice to put it in a new thread
def send_proposal_message(success, proposal):
    data = {
        "text": "Proposal created " + _get_success_msg(success),
        "blocks":
            [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        'text': create_deal_slack_msg(proposal, request.user, _get_success_msg(success))
                    },
                },
            ]
    }

    return requests.post(PROPOSAL_URL, data=dumps(data), headers=headers)


def send_si_platform_message(success, msg, fields):
    """
    Monitoring nonprofit/program creation for the Social Impact team
    """
    env = os.environ['ENV']

    # Only send for PROD
    if not (env.lower() == 'production' or env.lower() == 'prod'):
        return

    data = {
        'pretext': '<!here> ' + _get_success_msg(success) + '\n' + msg,
        'color': '#DAF7A6' if success else '#C70039',
        'fields': [{'title': k, 'value': v} for k, v in fields.items()],
    }


    return requests.post(SI_PLATFORM_UPDATE_URL, data=dumps(data), headers=headers)


def send_new_brand_message(success, brand, from_sales=False):
    data = {
        'text': 'Brand creation ' + _get_success_msg(success),
        'blocks':
            [
                {
                    'type': 'section',
                    'text': {
                        'type': 'mrkdwn',
                        'text': create_brand_slack_msg(brand, getattr(request, 'user', {}), _get_success_msg(success),  from_sales)
                    },
                },
            ]
    }

    return requests.post(NEW_BRAND_REQUEST_URL, data=dumps(data), headers=headers)


def _get_success_msg(success):
    return 'SUCCESS' if success else 'FAILED'


def create_deal_slack_msg(deal, user, success):
    msg = '{0} a *{1}* deal <{2}|{3}> created {4} by *{5}* in *{6}*'
    at_here = '<!here>' if os.environ.get('ENV').lower().startswith('prod') else ''
    return msg.format(at_here, deal.get('type'), ADMIN_URL + '/#/deals/' + str(deal.get('_id')), deal.get('name'),
                      success, user.get('first_name') + ' ' + user.get('last_name'), os.environ.get('ENV'))


def create_brand_slack_msg(brand, user, success, from_sales):
    msg = '{0} a brand <{1}|{2}> created {3} by *{4}* in *{5}* {6}'
    at_here = '<!here>' if os.environ.get('ENV').lower().startswith('prod') else ''
    return msg.format(at_here, ADMIN_URL + '/#/brands/' + str(brand.get('_id')), brand.get('name'), success,
                      user.get('first_name', '_') + ' ' + user.get('last_name', '_'), os.environ.get('ENV'), 'from *Sales*' if from_sales else '')
