import pytest
from bson import ObjectId
from datetime import datetime
from flask import request

from portal.conftest import AuthHeaderUsername, get_account_id_from_header
from portal.features.accounts.schema import AccountRequest, AccountSearchResponse, AccountResponse
from portal.shared.enums import AccountStatus, UserRole, AccountType
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import account_repository, instance_settings_repository
from portal.shared.services import email_service


class TestAccountsResource:
    def test_create(self, client, givewith_header, fakers):
        instance = fakers.instance_settings.insert_single()
        account = fakers.account.generate_new()
        account['instance']['_id'] = instance['_id']
        new = AccountRequest().dump(account)
        assert account_repository().collection.count_documents({}) == 0

        response = client.post('/accounts', json=new, headers=givewith_header)

        assert response.status_code == 200
        assert account_repository().collection.count_documents({}) == 1

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in [UserRole.SUPER_ADMIN, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN]],
        indirect=True
    )
    def test_create_role_permissions(self, client, custom_auth_header, fakers):
        new = AccountRequest().dump(fakers.account.generate_new())

        response = client.post('/accounts', json=new, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_get_all(self, client, givewith_header, mocker, fakers):
        accounts = fakers.account.generate_many(3)
        account_id = get_account_id_from_header(givewith_header)
        mocker.patch.object(account_repository(), 'get_page', return_value=(3, accounts))
        expected = AccountSearchResponse().dump({
            'totalCount': 3,
            'results': accounts
        })

        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10,
            'accountId': account_id
        }

        response = client.get('/accounts', query_string=query_params, headers=givewith_header)

        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES],
        indirect=True
    )
    def test_search_role_permissions(self, client, custom_auth_header):
        account_id = get_account_id_from_header(custom_auth_header)
        query_params = {
            'orderBy': 'id',
            'offset': 0,
            'count': 10,
            'accountId': account_id
        }

        response = client.get('/accounts', query_string=query_params, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}


class TestAccountByIdResource:
    def test_get(self, client, givewith_header, mocker, fakers):
        # arrange
        mock_account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=mock_account)
        expected = AccountResponse().dump(mock_account)

        # act
        response = client.get(f'/accounts/{ObjectId()}', headers=givewith_header)

        # assert
        assert response.status_code == 200
        assert response.json == expected

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES],
        indirect=True
    )
    def test_get_account_permission(self, client, custom_auth_header):
        response = client.get(f'/accounts/{ObjectId()}', headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_get_404(self, mocker, client, givewith_header):
        # arrange
        mocker.patch.object(account_repository(), 'get_single', lambda id: None)

        # act
        response = client.get(f'/accounts/{ObjectId()}', headers=givewith_header)

        # assert
        assert response.status_code == 404

    def test_put(self, client, givewith_header, fakers, mocker):
        account = fakers.account.generate_single()
        assert account['status'] == AccountStatus.ACTIVE.value
        account['status'] = AccountStatus.LOCKED.value
        assert account['type'] == AccountType.DEFAULT.value
        account['type'] = AccountType.PROCUREMENT.value

        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        mocker.patch.object(account_repository(), 'update', return_value=account)
        mocker.patch.object(email_service(), 'send_account_activated_email')
        mocker.patch.object(email_service(), 'send_account_deactivated_email')
        mocker.patch.object(instance_settings_repository(), 'exists', return_value=True)
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)

        request_json = AccountRequest().dump(account)

        response = client.put(f'/accounts/{account["_id"]}', json=request_json, headers=givewith_header)

        assert response.status_code == 200
        assert response.json['type'] == AccountType.PROCUREMENT.value

        account_repository().get_single.assert_called_once_with(str(account['_id']))
        account_repository().update.assert_called_once_with(account, by='givewith_user@example.com')
        instance_settings_repository().get_single.assert_not_called()
        email_service().send_account_activated_email.assert_not_called()
        email_service().send_account_deactivated_email.assert_not_called()

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole
         if r not in [UserRole.SUPER_ADMIN, UserRole.GW_FINANCE, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.FINANCE]],
        indirect=True)
    def test_put_role_permissions(self, client, custom_auth_header, fakers):
        account = fakers.account.generate_single()
        response = client.put(f'/accounts/{ObjectId()}', json=AccountRequest().dump(account), headers=custom_auth_header)
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_put_account_permissions(self, client, custom_auth_header, fakers):
        instance = fakers.instance_settings.insert_single()
        account = fakers.account.generate_single()
        account['instance']['_id'] = instance['_id']
        response = client.put(f'/accounts/{ObjectId()}', json=AccountRequest().dump(account), headers=custom_auth_header)
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_put_customer_id_ignored(self, client, custom_auth_header, fakers, mocker):
        user_id = get_account_id_from_header(custom_auth_header)
        instance = fakers.instance_settings.insert_single()
        account = fakers.account.insert_single({'_id': ObjectId(user_id)})
        account['instance']['_id'] = instance['_id']
        mocker.patch.object(email_service(), 'send_account_activated_email')
        mocker.patch.object(email_service(), 'send_account_deactivated_email')
        sage_id = 'newId'

        request_json = AccountRequest().dump(account)
        request_json['sageCustomerId'] = sage_id

        response = client.put(f'accounts/{account["_id"]}', json=request_json, headers=custom_auth_header)

        assert response.json['sageCustomerId'] != sage_id
        email_service().send_account_activated_email.assert_not_called()
        email_service().send_account_deactivated_email.assert_not_called()

    def test_patch(self, mocker, fakers, client, givewith_header):
        # arrange
        instance = fakers.instance_settings.generate_single()
        mocker.patch.object(instance_settings_repository(), 'get_single', return_value=instance)
        account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=account)
        request_json = {'status': AccountStatus.LOCKED.value}
        parsed_obj = AccountRequest(partial=True).dump(request_json)
        expected_update = {**account, **parsed_obj}
        mocker.patch.object(account_repository(), 'update', return_value=expected_update)
        mocker.patch.object(email_service(), 'send_account_activated_email')
        mocker.patch.object(email_service(), 'send_account_deactivated_email')
        expected_response = AccountResponse().dump(expected_update)

        with client:
            # act
            response = client.patch(f'/accounts/{account["_id"]}', json=request_json, headers=givewith_header)

            # assert
            account_repository().get_single.assert_called_once_with(str(account['_id']))
            account_repository().update.assert_called_once_with(expected_update, request.user['username'])
            instance_settings_repository().get_single.assert_called_once_with(account['instance']['_id'])
            email_service().send_account_activated_email.assert_not_called()
            email_service().send_account_deactivated_email.assert_called_once_with(instance, expected_update)
            assert response.status_code == 200
            assert response.json == expected_response

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole
         if r not in [UserRole.SUPER_ADMIN, UserRole.GW_FINANCE, UserRole.GW_OPERATIONS, UserRole.ORG_ADMIN, UserRole.FINANCE]],
        indirect=True)
    def test_patch_role_permissions(self, client, custom_auth_header):
        patch_request = {'status': 'locked'}
        response = client.patch(f'accounts/{ObjectId()}', json=patch_request, headers=custom_auth_header)
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch_account_permissions(self, client, custom_auth_header):
        patch_request = {'status': 'locked'}
        response = client.patch(f'accounts/{ObjectId()}', json=patch_request, headers=custom_auth_header)
        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch_customer_id_ignored(self, client, custom_auth_header, fakers, mocker):
        user_id = get_account_id_from_header(custom_auth_header)
        account = fakers.account.insert_single({'_id': ObjectId(user_id)})
        mocker.patch.object(email_service(), 'send_account_activated_email')
        mocker.patch.object(email_service(), 'send_account_deactivated_email')
        sage_id = 'newId'

        response = client.patch(f'accounts/{account["_id"]}', json={'sageCustomerId': sage_id}, headers=custom_auth_header)

        assert response.json['sageCustomerId'] != sage_id
        email_service().send_account_activated_email.assert_not_called()
        email_service().send_account_deactivated_email.assert_not_called()

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch_type(self, client, custom_auth_header, fakers, mocker):
        user_id = get_account_id_from_header(custom_auth_header)
        account = fakers.account.insert_single({'_id': ObjectId(user_id)})
        type = AccountType.PROCUREMENT.value

        response = client.patch(f'accounts/{account["_id"]}', json={'type': type}, headers=custom_auth_header)

        assert response.json['type'] != type

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_patch_type_schema_error(self, client, custom_auth_header, fakers, mocker):
        user_id = get_account_id_from_header(custom_auth_header)
        account = fakers.account.insert_single({'_id': ObjectId(user_id)})
        type = 'random'

        response = client.patch(f'accounts/{account["_id"]}', json={'type': type}, headers=custom_auth_header)
        assert response.status_code == 400
        assert response.json == {'schema_errors': {'type': ['Must be one of: default, procurement, supplier.']}}


class TestAccountActivateResource:
    @pytest.fixture
    def activate_request(self):
        address = {
            'address1': '123 Main Street',
            'address2': '',
            'city': 'Anytown',
            'stateProvince': 'LA',
            'postalCode': '55555',
            'country': 'USA'
        }
        return {
            'name': 'Acme Corp',
            'industry': {
                'displayLabel': 'Make Things Industry',
                'subIndustry': 'Make Things'
            },
            'address': address,
            'countryCode': '+1',
            'phoneNumber': '555-555-5555'
        }

    @pytest.mark.parametrize(
        'custom_auth_header',
        [r for r in UserRole if r not in GIVEWITH_ROLES + [UserRole.ORG_ADMIN, UserRole.FINANCE]],
        indirect=True
    )
    def test_put_role_permissions(self, client, custom_auth_header, activate_request):
        response = client.put(f'accounts/{ObjectId()}/activate', json=activate_request, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    @pytest.mark.parametrize('custom_auth_header', [UserRole.ORG_ADMIN, UserRole.FINANCE], indirect=True)
    def test_put_bad_account_permissions(self, client, custom_auth_header, activate_request):
        response = client.put(f'accounts/{ObjectId()}/activate', json=activate_request, headers=custom_auth_header)

        assert response.status_code == 403
        assert response.json == {'message': 'You do not have permission to access this resource'}

    def test_put(self, client, givewith_header, mocker, activate_request):
        # arrange
        mock_account = {
            'status': AccountStatus.PENDING.value,
            'createdBy': 'user@example.com',
            'createdAt': datetime.utcnow(),
            'lastUpdatedBy': 'user@example.com'
        }
        mocker.patch.object(account_repository(), 'get_single', lambda id: mock_account)
        mocker.patch.object(account_repository(), 'update', lambda account: account)
        mocker.patch.object(email_service(), 'send_account_activated_email')
        address = activate_request['address']

        expected = {
            'status': AccountStatus.ACTIVE.value,
            'industry': activate_request['industry'],
            'company': {
                'name': activate_request['name'],
                'address': {
                    'address1': address['address1'],
                    'address2': address['address2'],
                    'city': address['city'],
                    'stateProvince': address['stateProvince'],
                    'postalCode': address['postalCode'],
                    'country': address['country']
                },
                'countryCode': activate_request['countryCode'],
                'phoneNumber': activate_request['phoneNumber']
            },
            'createdBy': mock_account['createdBy'],
            'createdAt': mock_account['createdAt'],
            'lastUpdatedBy': AuthHeaderUsername.GIVEWITH.value
        }

        # act
        response = client.put(
            '/accounts/' + str(ObjectId()) + '/activate',
            json=activate_request, headers=givewith_header)

        # assert
        email_service().send_account_activated_email.assert_not_called()
        assert response.status_code == 200
        assert mock_account == expected


class TestAccountAppSettingsByID:
    def test_get(self, client, givewith_header, mocker, fakers):
        # arrange
        procurement_account = fakers.account.generate_single()
        supplier_account = fakers.account.generate_single({'instance._id': procurement_account['instance']['_id']})
        supplier_account['invitedBy'] = {'_id': procurement_account['_id']}
        mocker.patch.object(account_repository(), 'get_single', return_value=supplier_account)
        procurement_account['procurement'] = {
            "supplierTermsOfUseText": "Supplier Terms Of Use",
            "supplierTermsOfUseUrl": "https://www.givewith.com/terms-of-use/"
        }
        mocker.patch.object(account_repository(), 'get_single_by_filter', return_value=procurement_account)

        # act
        response = client.get(f'/accounts/{procurement_account["_id"]}/app-settings', headers=givewith_header)
        expected_response = {
            'id': str(procurement_account["_id"]),
            'procurement': procurement_account['procurement']
        }        # assert
        assert response.status_code == 200
        assert response.json == expected_response

    def test_get_400(self, client, givewith_header, mocker, fakers):
        # arrange

        # act
        response = client.get(f'/accounts/12345/app-settings', headers=givewith_header)

        # assert
        assert response.status_code == 400
        assert response.json['message'] == 'Invalid id provided'

    def test_get_403(self, client, givewith_header, mocker, fakers):
        # arrange
        procurement_account = fakers.account.generate_single()
        supplier_account = fakers.account.generate_single({'instance._id': procurement_account['instance']['_id']})
        mocker.patch.object(account_repository(), 'get_single', return_value=supplier_account)
        procurement_account['procurement'] = {
            "supplierTermsOfUseText": "Supplier Terms Of Use",
            "supplierTermsOfUseUrl": "https://www.givewith.com/terms-of-use/"
        }
        mocker.patch.object(account_repository(), 'get_single_by_filter', return_value=procurement_account)

        # act
        response = client.get(f'/accounts/{procurement_account["_id"]}/app-settings', headers=givewith_header)
        # assert
        assert response.status_code == 403
        assert response.json['message'] == 'You do not have permission to access this resource'

    def test_get_404(self, client, givewith_header, mocker, fakers):
        # arrange
        supplier_account = fakers.account.generate_single()
        mocker.patch.object(account_repository(), 'get_single', return_value=supplier_account)

        # act
        response = client.get(f'/accounts/{supplier_account["_id"]}/app-settings', headers=givewith_header)
      # assert
        assert response.status_code == 404
        assert response.json['message'] == 'Account not found'


class TestAccountIndustriesResource:
    def test_get(self, mocker, client):
        # arrange
        industries = {
            '_id': str(ObjectId()),
            'Industry 1': [
                {
                    'displayLabel': 'Industry 1.1',
                    'subIndustry': 'Sub Industry 1.1'
                },
                {
                    'displayLabel': 'Industry 1.2',
                    'subIndustry': 'Sub Industry 1.2'
                }
            ],
            'Industry 2': [
                {
                    'displayLabel': 'Industry 2.1',
                    'subIndustry': 'Sub Industry 2.1'
                }
            ]
        }
        mocker.patch.object(account_repository(), 'get_industries', return_value=industries)
        expected = [
            {
                'name': 'Industry 1',
                'items': [
                    {
                        'displayLabel': 'Industry 1.1',
                        'subIndustry': 'Sub Industry 1.1'
                    },
                    {
                        'displayLabel': 'Industry 1.2',
                        'subIndustry': 'Sub Industry 1.2'
                    }
                ]
            },
            {
                'name': 'Industry 2',
                'items': [
                    {
                        'displayLabel': 'Industry 2.1',
                        'subIndustry': 'Sub Industry 2.1'
                    }
                ]
            }
        ]

        # act
        response = client.get('/accounts/industries')

        # assert
        assert response.status_code == 200
        assert response.json == expected
