# pylint: disable=redefined-outer-name
import json
import pytest


@pytest.fixture(scope='session')
def sample_token(test_db, default_header, client):
    brand = test_db.mm_brands.find_one({})
    slug, password = brand['slug'], brand['preferredPrograms']['password']

    response = client.post(f'/matchmaking/brand/{slug}/preferred-programs/login',
                           data=json.dumps({'password': password}), headers=default_header)
    return {
        'token': json.loads(response.data.decode())['token'],
        'slug': slug
    }


def test_login_preferred_programs_by_slug_success(client, test_db, default_header):
    brand = test_db.mm_brands.find_one({})
    slug, password = brand['slug'], brand['preferredPrograms']['password']

    response = client.post(f'/matchmaking/brand/{slug}/preferred-programs/login',
                           data=json.dumps({'password': password}), headers=default_header)

    assert response.status_code == 200

    token = json.loads(response.data.decode()).get('token')
    assert token is not None
    assert len(token) > 15


@pytest.mark.parametrize('password', [None, '', 'wrong-password'])
def test_login_preferred_programs_by_slug_failure(client, test_db, password, default_header):
    brand = test_db.mm_brands.find_one({})
    slug = brand['slug']

    response = client.post(f'/matchmaking/brand/{slug}/preferred-programs/login',
                           data=json.dumps({'password': password}), headers=default_header)

    assert 400 <= response.status_code <= 499


def test_get_preferred_programs_by_slug_no_auth(client, default_header, sample_token):
    slug = sample_token['token']
    response = client.get(f'/matchmaking/brand/{slug}/preferred-programs', headers=default_header)

    assert 400 <= response.status_code <= 499


def test_get_preferred_programs_by_slug(client, default_header, sample_token):
    token, slug = sample_token['token'], sample_token['slug']

    response = client.get(f'/matchmaking/brand/{slug}/preferred-programs',
                          headers={**default_header, 'Authorization': token})

    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert 'selected' in data
    assert 'cart' in data
    assert 'editing' in data
