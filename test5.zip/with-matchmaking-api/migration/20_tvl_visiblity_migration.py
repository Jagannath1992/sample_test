from matchmaking import db

tvlVisibilityObj = {'accessAndAffordabilityVisibility': True,
                    'businessEthicsAndTransparencyOfPaymentsVisibility': True,
                    'humanRightsAndCommunityRelationsVisibility': True,
                    'biodiversityImpactsVisibility': True,
                    'gHGEmissionsVisibility': True}

db().coll_brands.update_many({'tvlVisibility': {'$exists': True}}, {'$set': {'tvlVisibility': tvlVisibilityObj}})
