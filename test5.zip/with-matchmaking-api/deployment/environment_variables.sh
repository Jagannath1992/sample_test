#make sure to set ENV (staging or production) in the .bashrc
source /home/ec2-user/.bashrc
echo "I am functioning as"
whoami
echo "now adding environment variables for "
echo $ENV

if [ $ENV == "local" ]; then
  echo "its a local environ, so do something different"
else
  
  aws --region us-east-1 s3 cp s3://gwenv-distrib-$ENV/staging.bin /home/ec2-user/deployment/.
  aws --region us-east-1 s3 cp s3://gwenv-distrib-$ENV/sandbox.bin /home/ec2-user/deployment/.
  aws --region us-east-1 s3 cp s3://gwenv-distrib-$ENV/production.bin /home/ec2-user/deployment/.

  aws --region us-east-1 kms decrypt --ciphertext-blob fileb://$ENV.bin --output text --query Plaintext | base64 --decode | gunzip > /home/ec2-user/.envs
  echo "completed process - output?"
  tail /home/ec2-user/.envs 
fi
