# -*- coding: utf-8 -*-
from json import dumps

from flask import jsonify, request, current_app
from pymongo import UpdateOne

from ...controllers import admin_bp
from .programs import create_virtual_fields, math_screen_one_score
from ...models.models import v, schema_settings, schema_program
from ...mongodb import db
from ...utils import set_last_updated, ValidationError, GivewithError
from ...permission_decorator import require_admin_permission

target_collection = 'mm_settings'


def update_programs(settings):
    db_programs = db().coll_programs.find(projection={'additionalValueFields.contributionsCash': True,
                                                 'additionalValueFields.contributionsInKind': True,
                                                 'secondaryImpacts': True,
                                                 'interventions': True,
                                                 'oneOrMorePartnerOrganizations': True,
                                                 'audienceAge': True,
                                                 'audienceGender': True,
                                                 'audienceAttribute': True,
                                                 'programDensity': True,
                                                 'primaryOutcomeEffectiveness': True,
                                                 'dataMeasurementType': True,
                                                 'programActivityEffectiveness': True,
                                                 'effectivenessRating': True,
                                                 'programApproach': True,
                                                 'isOngoingProgram': True,
                                                 'screenOneScore': True})
    programs_to_update = []
    for program in db_programs:
        previous_screen_one_score = program['screenOneScore']

        create_virtual_fields(program, settings=settings)
        math_screen_one_score(program, settings=settings)

        if program['screenOneScore'] != previous_screen_one_score:
            program['isValid'] = v.validate(program, schema_program)
            program = v.normalized(program, schema_program)
            if v.errors:
                raise ValidationError(v.errors)

            programs_to_update.append(program)

    to_update = []
    for p in programs_to_update:
        to_update.append(UpdateOne(filter={'_id': p['_id']},
                                   update={'$set': set_last_updated({'screenOneScore': p['screenOneScore']})}))

    if to_update:
        db().coll_programs.bulk_write(to_update)


def validate_recommendation_weights(settings):
    recomm_settings = settings.get('recommendationSettings')
    weight_keys = ['keyIssues', 'themes']
    weight_sum = sum([recomm_settings[key] for key in recomm_settings if key in weight_keys])
    if weight_sum > 100:
        raise GivewithError("Recommendation weights shouldn't add up more than 100")
    elif weight_sum < 100:
        raise GivewithError("Recommendation weights dont't add up to 100")


##
# Protected Endpoints
##
@admin_bp.route('/settings', methods=['GET'])
@require_admin_permission
def admin_get_settings():
    """ Fetch current Settings
    ---
    tags: ['Admin Settings']

    security:
      - GivewithAuth: []

    responses:
      200:
        description: Success
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/Settings'
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    settings = db().coll_settings.find_one()

    if not settings:
        settings = v.normalized({}, schema_settings)
        if v.errors:
            raise ValidationError(v.errors)
    else:
        del settings['_id']

    return jsonify(settings)


@admin_bp.route('/settings', methods=['PUT'])
@require_admin_permission
def admin_update_settings():
    """ Save new Settings
    ---
    tags: ['Admin Settings']

    security:
      - GivewithAuth: []

    requestBody:
      description: New Settings
      required: true
      content:
        application/json:
          schema:
              $ref: '#/components/schemas/Settings'

    responses:
      204:
        description: No Content
      default:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ServerMessage'
    """
    new_settings = request.get_json()

    is_valid = v.validate(new_settings, schema_settings)
    if not is_valid:
        return current_app.response_class(
            response=dumps(v.errors),
            mimetype=current_app.config['JSONIFY_MIMETYPE'],
            status=400)  # Bad Request

    db_settings = db().coll_settings.find_one()
    new_settings = v.normalized(new_settings, schema_settings)
    if v.errors:
        raise ValidationError(v.errors)

    validate_recommendation_weights(new_settings)

    if db_settings:
        if new_settings['scoringSettings']['minimumHigh'] != db_settings['scoringSettings']['minimumHigh'] or \
           new_settings['scoringSettings']['maximumLow'] != db_settings['scoringSettings']['maximumLow']:
            update_programs(new_settings)

        db().coll_settings.update_one({'_id': db_settings['_id']}, {'$set': new_settings})
    else:
        db().coll_settings.insert_one(new_settings)
        update_programs(new_settings)
        del new_settings['_id']

    return jsonify(new_settings)
