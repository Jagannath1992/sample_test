from unittest.mock import MagicMock
from matchmaking.utils import parse_diff_strings, get_deep_diff, recursive_key_pull


def test_diff_string_parser():
    values = [
        'root[\'keyD\'][\'keyB\'][0]',
        'root[\'keyA\'][\'keyF\'][0][\'keyC\']',
        'root[\'keyD\'][\'keyE\'][0][\'keyF\'][1]',
        'root[\'keyD\'][\'keyE\'][0][\'keyF\'][1][\'keyR\']',
        'root[\'keyQ\'][\'keyR\']',
        'root[\'keyG\'][\'keyA\'][1][2]',
        'root[\'keyG\'][\'keyA\'][1][2][\'keyJ\']'
    ]

    expected_output = {
        'keyD.keyB',
        'keyD.keyB.0',
        'keyA.keyF',
        'keyA.keyF.0',
        'keyA.keyF.0.keyC',
        'keyD.keyE',
        'keyD.keyE.0',
        'keyD.keyE.0.keyF',
        'keyD.keyE.0.keyF.1',
        'keyD.keyE.0.keyF.1.keyR',
        'keyQ.keyR',
        'keyG.keyA',
        'keyG.keyA.1',
        'keyG.keyA.1.2',
        'keyG.keyA.1.2.keyJ',
    }

    result = parse_diff_strings(values)
    assert len(expected_output - result) == 0

def test_recursive_key_pull():
    values = {
        'root[\'keyA\'][\'keyB\']': {
            'name': {'selected': 5, 'removed': 10},
            'title': {'added': 'hello world'}
        },
        'root[\'keyC\'][\'keyD\']': {
            'string': {'other': {
                'kid': 5,
                'grown': 10,
            }},
        }
    }

    expected_output = [
        'root[\'keyA\'][\'keyB\'][\'name\'][\'selected\']',
        'root[\'keyA\'][\'keyB\'][\'name\'][\'removed\']',
        'root[\'keyA\'][\'keyB\'][\'title\'][\'added\']',
        'root[\'keyC\'][\'keyD\'][\'string\'][\'other\'][\'kid\']',
        'root[\'keyC\'][\'keyD\'][\'string\'][\'other\'][\'grown\']'
    ]

    actual_output = recursive_key_pull(values)

    assert sorted(actual_output) == sorted(expected_output)

def test_get_deep_diff(monkeypatch):
    deep_diff_return_value = {
        'values_changed': {
            'root[\'keyA\'][\'keyB\']': {'old_value': 55, 'new_value': 66},
            'root[\'keyA\'][\'keyP\'].__id': {'old_value': 59, 'new_value': 90}
        },
        'type_changes': {
            'root[\'keyC\'][\'keyQ\'][0]': {'old_type': str, 'new_type': int}
        },
        'iterable_item_removed': {
            'root[\'keyR\'][\'keyF\']': 'some_value',
        },
        'dictionary_item_added': {
            'root[\'keyJ\'][\'keyQ\']': {'value': 10}
        },
        'dictionary_item_removed': {
            'root[\'keyR\'][\'keyO\']': {'other_value': 10}
        }
    }

    diff_result = [
        'keyA.keyB',
        'keyC.keyQ',
        'keyC.keyQ.0',
        'keyR.keyF',
        'keyA.keyP',
        'keyR.keyO.other_value',
        'keyJ.keyQ.value'
    ]

    mock_deep_diff = MagicMock()
    mock_deep_diff.return_value.to_dict.return_value = deep_diff_return_value

    monkeypatch.setattr('matchmaking.utils.DeepDiff', mock_deep_diff)

    test_result = get_deep_diff({}, {})
    mock_deep_diff.assert_called_once()

    assert sorted(diff_result) == sorted(test_result)
