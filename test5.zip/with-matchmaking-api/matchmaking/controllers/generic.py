from tempfile import TemporaryFile
from flask import request, current_app, send_file
from matchmaking.permission_decorator import require_admin_permission
from matchmaking.utils import (ses_send_email, format_to_html, UnsupportedPayload, create_validation_error_response,
                               GivewithError)
from matchmaking.s3 import download_file
from matchmaking import public_mm_bp, admin_bp


CONTACT_US_ADDRESS = 'assist@givewith.com'


@public_mm_bp.route('/contact-us', methods=['POST'])
def contact_us():
    """Contact Givewith for help Endpoint

    Raises:
        UnsupportedPayload: request payload is missing required information

    Returns:
        response -- 204 OK - no data
    """
    fields = request.get_json()

    if not fields:
        raise UnsupportedPayload(None)

    # submitted fields
    name = fields.get('name', '').strip()
    email = fields.get('email', '').strip()
    message = fields.get('message', '').strip()
    app = fields.get('app', '').strip()

    if not name or not email or not message or not app:
        raise UnsupportedPayload(None)

    from_address = f'Givewith Customer <{CONTACT_US_ADDRESS}>'
    subject = f'{name} requesting assistance on {app}'

    formatted_name = f'<b>Name:</b> {name}'
    formatted_email = f'<b>Email:</b> {email}'
    formatted_msg = f'<b>Message:</b><br> {message}'

    html_message = format_to_html(formatted_name, formatted_email, formatted_msg)

    ses_send_email(from_address, [CONTACT_US_ADDRESS], subject, html_message, reply_to_addresses=[email])

    return current_app.response_class(status=204)


@admin_bp.route('/download-file', methods=['GET'])
@require_admin_permission
def download_s3_file():
    """Download a private file from s3"""
    url = request.args.get('url')

    if not url:
        return create_validation_error_response('url')

    filename = url.rsplit('/', 1)[-1] # format: my_picture.jpg

    # the file descriptor needs to be kept alive until flask successfully sends the response
    # at which point _fd should go out of scope and garbage collector should free the memory
    _fd = TemporaryFile()

    if download_file(url, _fd):
        response = send_file(_fd, as_attachment=True, attachment_filename=filename, cache_timeout=0)
        response.direct_passthrough = False
        return response
    else:
        raise GivewithError(f'Unable to download file with url: {url}')
