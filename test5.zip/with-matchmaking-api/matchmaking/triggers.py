# -*- coding: utf-8 -*-
from bson import ObjectId
from pymongo import UpdateOne

from matchmaking.dao.utils import get_documents, update_documents
from .models.models import v, schema_brand
from .mongodb import get_is_valid_program, get_is_valid_nonprofit, db, get_vocabulary_label_v2, get_brand_industry_id
from .utils import set_last_updated


def set_brand_parents_is_valid(brand):
    """
    Lookup for all parents and grandparents to figure its `isValid` situation.
    :param brand: brand dict representation
    :return: None
    """
    recommendations = brand.get('recommendations', [])
    program_ids = list(set([program for recommendation in recommendations
                            if recommendation.get('programs', None) is not None
                            for program in recommendation['programs']]))

    programs = db().coll_programs.find(filter={'_id': {'$in': program_ids}},
                                       projection={'nonprofit': True})

    nonprofit_ids = list(set([program['nonprofit'] for program in programs
                              if program.get('nonprofit', None) is not None]))

    brand.update({'isValidProgram': get_is_valid_program(program_ids),
                  'isValidNonprofit': get_is_valid_nonprofit(nonprofit_ids)})


def set_brands_is_valid_of_programs(programs):
    """
    Update validation flags (isValidProgram and isValidNonprofit) on brands related relationship to programs provided.
    :param programs: List of programs to fetch brands related
    :return: None
    """
    if not programs:
        return

    if type(programs) is not list:
        programs = [programs]

    to_update = []
    for brand in db().coll_brands.find(filter={'recommendations.programs': {'$in': programs}}):
        set_brand_parents_is_valid(brand)

        # ensure to update only isValid fields
        del brand['recommendations']

        to_update.append(UpdateOne(filter={'_id': brand['_id']},
                                   update={'$set': set_last_updated(brand)}))

    if to_update:
        db().coll_brands.bulk_write(to_update)


def remove_program_from_brands(programs):
    """
    Remove program relationships of brands
    :param programs:
    :return:
    """
    if not programs:
        return

    if type(programs) is not list:
        programs = [programs]

    to_update = []
    for brand in db().coll_brands.find(filter={'$or': [{'recommendations.programs': {'$in': programs}},
                                       {'customInvestorMetrics.program': {'$in': programs}}]}):

        recommendations = []
        for recommendation in brand.get('recommendations', []):
            rec_programs = [p for p in recommendation.get('programs', []) if p not in programs]

            # if no program is available, remove key from recommendation
            if rec_programs:
                recommendation['programs'] = rec_programs
                recommendations.append(recommendation)

        custom_investor_metrics = [cim for cim in brand.get('customInvestorMetrics', [])
                                   if cim.get('program', None) is not None and cim['program'] not in programs]

        brand.update({'recommendations': recommendations,
                      'customInvestorMetrics': custom_investor_metrics})

        # re-check isValid integrity
        brand['isValid'] = v.validate(brand, schema_brand)
        to_update.append(UpdateOne(filter={'_id': brand['_id']},
                                   update={'$set': set_last_updated(brand)}))

    if to_update:
        db().coll_brands.bulk_write(to_update)


def set_children_and_grandchildren_is_valid_of_nonprofit(nonprofit):
    """
    Update validation flags on programs and brands related to that nonprofit.
    :param nonprofit: Nonprofit to find programs and brands
    :return: None
    """
    db().coll_programs.update_many(filter={'nonprofit': nonprofit['_id']},
                                   update={'$set': set_last_updated({'isValidNonprofit': nonprofit['isValid']})})
    programs = [program['_id'] for program in db().coll_programs.find(filter={'nonprofit': ObjectId(nonprofit['_id'])},
                                                                      projection={'_id': True})]
    set_brands_is_valid_of_programs(programs)


def remove_nonprofit_from_programs(document):
    """
    Remove nonprofit relationship of programs and define them as isValid = false
    :param document:
    :return:
    """
    to_update = []
    programs = []
    for program in db().coll_programs.find({'nonprofit': document['_id']}):
        del program['nonprofit']

        # sets program validation flags to false once nonprofit is required
        program.update({'isValid': False,
                        'isValidNonprofit': False})
        to_update.append(UpdateOne(filter={'_id': program['_id']},
                                   update={'$set': set_last_updated(program),
                                           '$unset': {'nonprofit': ''}}))
        programs.append(program['_id'])

    if to_update:
        db().coll_programs.bulk_write(to_update)

    set_brands_is_valid_of_programs(programs)


def remove_blacklisted_nonprofit_programs_from_associated_deals(brand):
    blacklist_data = brand.get('nonprofits', {}).get('blacklist')

    if blacklist_data:
        nonprofit_blacklist = [ObjectId(nonprofit) for nonprofit in blacklist_data]
        nonprofit_programs = {
            program['_id'] for program in
            get_documents('mm_programs', {'nonprofit': {'$in': nonprofit_blacklist}}, projection={'_id': True})
        }

        query = {'$and': [
            {'$or': [{'givewithCustomer': brand['_id']}, {'client': brand['_id']}]},
            {'selectedRecommendedPrograms': {'$elemMatch': {'_id': {'$in': list(nonprofit_programs)}}}}
        ]}

        to_update = []
        for deal in get_documents('deals', query, projection={'selectedRecommendedPrograms': True}):
            deal['selectedRecommendedPrograms'] = [
                program for program in deal['selectedRecommendedPrograms'] if program['_id'] not in nonprofit_programs
            ]

            to_update.append({'filter': {'_id': deal['_id']}, 'updates': deal})

        if to_update:
            update_documents('deals', to_update, upsert=False)


def remove_nonprofit_programs_from_blacklisted_brands(document):
    # NOTE: If ever supported by mongo, refactor to query mongo to return all documents where there is an overlap
    # between its preferred programs and the blacklisted brand
    # Please use this function sparingly if possible
    nonprofit_programs = [
        program['_id'] for program in
        get_documents('mm_programs', {'nonprofit': document['_id']}, projection={'_id': True})
    ]

    blacklisted_brands = [ObjectId(brand['_id']) for brand in document.get('blacklist', {}).get('brands', [])]
    blacklisted_industries = [
        get_vocabulary_label_v2(ObjectId(vocab)) for vocab in document.get('blacklist', {}).get('industries', [])
    ]
    brands_to_update = []

    if blacklisted_brands:
        query = {
            '$and': [
                {'_id': {'$in': blacklisted_brands}},
                {'$or': [
                    {'preferredPrograms.selected': {'$in': nonprofit_programs}},
                    {'preferredPrograms.cart': {'$in': nonprofit_programs}},
                    {'preferredPrograms.additional': {'$in': nonprofit_programs}}
                ]}
            ]
        }
        brands_to_update.extend([
            brand for brand in get_documents('mm_brands', query, projection={'preferredPrograms': True})
        ])

    if blacklisted_industries:
        query = {
            '$and':[
                {'$or': [
                    {'industry': {'$in': blacklisted_industries}},
                    {'msci.industry': {'$in': blacklisted_industries}}
                ]},
                {'$or': [
                    {'preferredPrograms.selected': {'$in': nonprofit_programs}},
                    {'preferredPrograms.cart': {'$in': nonprofit_programs}},
                    {'preferredPrograms.additional': {'$in': nonprofit_programs}}
                ]}
            ]
        }
        brands_to_update.extend([
            brand for brand in get_documents('mm_brands', query, projection={'preferredPrograms': True})
        ])

    if brands_to_update:
        to_update = []
        nonprofit_programs_set = set(nonprofit_programs)

        for brand in brands_to_update:
            modified = False
            for field in ['selected', 'cart', 'additional']:
                field_values = set(brand.get('preferredPrograms', {}).get(field, []))
                if field_values:
                    new_values = field_values - nonprofit_programs_set # set substraction
                    if new_values != field_values:
                        brand['preferredPrograms'][field] = list(new_values)
                        modified = True

            if modified:
                to_update.append({'filter': {'_id': brand['_id']}, 'updates': brand})

        if to_update:
            update_documents('mm_brands', to_update, upsert=False)


def remove_invalid_nonprofit_programs_from_deals(document):
    nonprofit_programs = {
        program['_id'] for program in
        get_documents('mm_programs', {'nonprofit': document['_id']}, projection={'_id': True})
    }

    blacklisted_brands = {ObjectId(brand['_id']) for brand in document.get('blacklist', {}).get('brands', [])}
    blacklisted_industries = {ObjectId(industry) for industry in document.get('blacklist', {}).get('industries', [])}

    # query to pull all programs rather than using an aggregation to pull only programs
    # whose brands are blacklisted or brand's industries are blacklisted
    query = {'selectedRecommendedPrograms': {'$elemMatch': {'_id': {'$in': list(nonprofit_programs)}}}}
    projection = {'selectedRecommendedPrograms': True, 'givewithCustomer': True, 'client': True}

    if blacklisted_brands or blacklisted_industries:
        to_update = []

        for deal in get_documents('deals', query, projection=projection):
            gw_customer, client = deal.get('givewithCustomer'), deal.get('client')
            customer_industry, client_industry = get_brand_industry_id(gw_customer), get_brand_industry_id(client)

            should_remove = any([
                gw_customer in blacklisted_brands,
                client in blacklisted_brands,
                customer_industry in blacklisted_industries,
                client_industry in blacklisted_industries
            ])

            if should_remove:
                deal['selectedRecommendedPrograms'] = [
                    program for program in deal['selectedRecommendedPrograms']
                    if program['_id'] not in nonprofit_programs
                ]

                to_update.append({'filter': {'_id': deal['_id']}, 'updates': deal})

        if to_update:
            update_documents('deals', to_update, upsert=False)
