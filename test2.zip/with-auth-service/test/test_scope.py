import json
import jwt


def test_admin_scope(client, db, header):
    # set user type to admin
    update_result = db.user.update_one({'username': 'shanyan.jiang+delta@givewith.com'}, {'$set': {'type': 'admin'}})
    assert update_result.matched_count == 1

    # should pass all
    request_scope = ['admin', 'psf', 'impact']
    expected_status_code = [200, 200, 200]
    expected_token_scope = ['admin', 'admin', 'admin']

    for i in range(len(request_scope)):
        # test scope in token
        payload = {
            "grantType": "password",
            "username": "shanyan.jiang+delta@givewith.com",
            "password": "TestPassword123",
            "scope": request_scope[i]
        }

        response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
        assert response.status_code == expected_status_code[i]

        result = json.loads(response.data.decode())
        token = result.get('token')
        refresh_token = result.get('refresh_token')

        if expected_status_code[i] == 200:
            token_payload = jwt.decode(token, verify=False)
            assert token_payload.get('scope') == expected_token_scope[i]

            # test scope in new token
            payload = {
                "grantType": "refresh_token",
                "refresh_token": refresh_token,
            }

            response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
            assert response.status_code == 200

            result = json.loads(response.data.decode())
            new_token = result.get('access_token')
            new_token_payload = jwt.decode(new_token, verify=False)
            assert new_token_payload.get('scope') == expected_token_scope[i]


def test_impact_scope(client, db, header):
    # set user type to client, and orgType to brand
    update_result = db.user.update_one({'username': 'shanyan.jiang+delta@givewith.com'},
                                       {'$set': {'type': 'client', 'orgType': 'brand'}})
    assert update_result.matched_count == 1

    # should fail at admin and psf
    test_scopes = ['admin', 'psf', 'impact']
    expected_status_code = [403, 403, 200]
    expected_token_scope = ['', '', 'impact']

    for i in range(len(test_scopes)):
        payload = {
            "grantType": "password",
            "username": "shanyan.jiang+delta@givewith.com",
            "password": "TestPassword123",
            "scope": test_scopes[i]
        }

        response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
        assert response.status_code == expected_status_code[i]

        result = json.loads(response.data.decode())
        token = result.get('token')
        refresh_token = result.get('refresh_token')

        if expected_status_code[i] == 200:
            token_payload = jwt.decode(token, verify=False)
            assert token_payload.get('scope') == expected_token_scope[i]

            # test scope in new token
            payload = {
                "grantType": "refresh_token",
                "refresh_token": refresh_token,
            }

            response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
            assert response.status_code == 200

            result = json.loads(response.data.decode())
            new_token = result.get('access_token')
            new_token_payload = jwt.decode(new_token, verify=False)
            assert new_token_payload.get('scope') == expected_token_scope[i]


def test_nonprofit_scope(client, db, header):
    # set user type to client, and orgType to nonprofit
    update_result = db.user.update_one({'username': 'shanyan.jiang+delta@givewith.com'},
                                       {'$set': {'type': 'client', 'orgType': 'nonprofit'}})
    assert update_result.matched_count == 1

    # should fail at admin and impact
    test_scopes = ['admin', 'psf', 'impact']
    expected_status_code = [403, 200, 200]
    expected_token_scope = ['', 'psf', 'impact']

    for i in range(len(test_scopes)):
        payload = {
            "grantType": "password",
            "username": "shanyan.jiang+delta@givewith.com",
            "password": "TestPassword123",
            "scope": test_scopes[i]
        }

        response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
        assert response.status_code == expected_status_code[i]

        result = json.loads(response.data.decode())
        token = result.get('token')
        refresh_token = result.get('refresh_token')

        if expected_status_code[i] == 200:
            token_payload = jwt.decode(token, verify=False)
            assert token_payload.get('scope') == expected_token_scope[i]

            # test scope in new token
            payload = {
                "grantType": "refresh_token",
                "refresh_token": refresh_token,
            }

            response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
            assert response.status_code == 200

            result = json.loads(response.data.decode())
            new_token = result.get('access_token')
            new_token_payload = jwt.decode(new_token, verify=False)
            assert new_token_payload.get('scope') == expected_token_scope[i]


def test_sales_scope(client, db, header):
    # set user type to client, and orgType to nonprofit
    update_result = db.user.update_one({'username': 'shanyan.jiang+delta@givewith.com'},
                                       {'$set': {'type': 'client', 'departmentType': 'Sales'}})
    assert update_result.matched_count == 1

    payload = {
        "grantType": "password",
        "username": "shanyan.jiang+delta@givewith.com",
        "password": "TestPassword123",
        "scope": 'sales'
    }

    response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
    assert response.status_code == 200