from flask import jsonify, abort
from bson import ObjectId

from ..controllers import nonprofit_bp

from ..validation.utils import validate_slug_with_collection, validate_slug_or_id_with_collection
from ..validation.utils import validate_slug_or_id_with_collection, validate_object_id_with_collection

from ..db.utils import get_document_by_id, get_documents, get_document
from ..utils.utils import get_assets, get_filtered_document
from ..constants import default_media_projection

@nonprofit_bp.route('/<string:program_slug>/overview-video', methods=['GET'])
def get_public_nonprofit_overview_video(program_slug):
    '''
    Query the simian-media collection to return the appropriate nonprofit fallback image.

    The logic for returning this image is as follows:
    1) Check for nonprofit overview video from simian-media
    2) If it doesn't exist, return `vimeoID`,
    3) If vimeoID doesn't exist, return Nonprofit fallback image from simian-media
    4) If nonprofit fallback image from simian-media doesn't exist, return existing `videoFallback`

    overview video: tags in document must include --> Video, NPO Overview
    nonprofit fallback image: tags in document must include --> Photo, NPO Generic
    '''

    # if ID is passed, get slug, and override function parameter
    program_id, program_slug = validate_slug_or_id_with_collection(program_slug, 'mm_programs')

    if not validate_slug_with_collection(str(program_slug), 'mm_programs'):
        abort(404, description='Program slug not found: ' + program_slug)


    program = get_document('mm_programs', {'slug': program_slug}, projection={'_id': False, 'nonprofit': True})
    nonprofit_id = program.get('nonprofit')

    documents = list(get_documents('simian_media', {'credits.npo_id': str(nonprofit_id)},
                                   projection=default_media_projection))

    # step 1
    video_document = get_filtered_document(documents, ['video', 'npo overview'])

    overview = {}
    if video_document:
        overview = {
            **get_assets(video_document),
            'type': 'overviewVideo',
        }
    else:
        nonprofit = get_document_by_id('mm_nonprofits', ObjectId(nonprofit_id), projection={'vimeoID': True,
                                                                                            'videoFallback': True})

        # step 2
        vimeo_id = nonprofit.get('vimeoID', None)
        if vimeo_id:
            overview = {
                'media': vimeo_id,
                'type': 'vimeoID',
            }
        else:
            # step 3
            fallback_document = get_filtered_document(documents, ['photo', 'npo generic'])

            if fallback_document:
                overview = {
                    **get_assets(fallback_document),
                    'type': 'fallbackPhoto',
                }
            else:
                # step 4
                video_fallback = nonprofit.get('videoFallback', None)
                if video_fallback:
                    overview = {
                        'media': video_fallback,
                        'type': 'fallbackVideo',
                    }

    return jsonify(overview)
