# -*- coding: utf-8 -*-
from matchmaking import create_app

app = create_app()
