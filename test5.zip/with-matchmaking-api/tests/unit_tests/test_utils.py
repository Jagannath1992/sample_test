from bson.objectid import ObjectId
from matchmaking.utils import replace_object_ids

def test_string_to_object_id():
    json = {
        'key1' : '607097683808bac977ccce43',
        'key2': 1,
        'key3': '1',
        'key4': True,
        'key5': ['607097683808bac977ccce43', 1.1]
    }

    result = replace_object_ids(json)
    assert result == {
        'key1' : ObjectId('607097683808bac977ccce43'),
        'key2': 1,
        'key3': '1',
        'key4': True,
        'key5': [ObjectId('607097683808bac977ccce43'), 1.1]
    }
