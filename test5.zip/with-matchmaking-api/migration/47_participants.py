from matchmaking import db

for program in db().coll_programs.find({}):
    participants = program.get('participants', '')
    if participants:
        db().coll_programs.update_one({'_id': program['_id']}, {'$set': {'participants': int(program['participants'])}})
