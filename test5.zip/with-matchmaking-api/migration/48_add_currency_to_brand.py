from matchmaking import db

db().coll_brands.update_many(filter={'givePercentageCurrency':{'$exists': False}}, update={'$set': {'givePercentageCurrency': 'USD'}})
