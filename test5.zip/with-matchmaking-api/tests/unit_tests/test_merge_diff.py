from matchmaking.dao.utils import merge_diff

def test_merge_diff():
    # replace
    source = {
        'a' : 1
    }

    change = {
        'a' : 2
    }

    source = merge_diff(source, change)
    assert source['a'] == 2

    # merge
    source = {
        'a' : 1
    }

    change = {
        'b' : 2
    }

    source = merge_diff(source, change)
    assert source['a'] == 1
    assert source['b'] == 2

