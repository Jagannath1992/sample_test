yum -y groupinstall "Development Tools"
yum -y install gcc
yum -y install python3
yum -y install python3-devel.x86_64
pip3 install gunicorn

# install datadog agent on amazon-linux
DD_AGENT_MAJOR_VERSION=7 DD_API_KEY=5aab45d79cb31e889f479b0cb956b2a9 DD_EXPVAR_PORT=5010 DD_SITE="datadoghq.com" bash -c "$(curl -L https://s3.amazonaws.com/dd-agent/scripts/install_script.sh)"