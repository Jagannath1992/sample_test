import json

def test_create_award(client, admin_header):
    # test add award
    award = {
        "name": "Grammy",
        "url": "https://www.grammy.com/",
    }

    response = client.post('/admin/award/', data=json.dumps(award), headers=admin_header)
    assert response.status_code == 200

    # test update award
    award = json.loads(response.data.decode())
    update = {
        "name": "New name",
        "url": "https://www.grammy.com/",
    }

    response = client.put('/admin/award/' + str(award['_id']), data=json.dumps(update), headers=admin_header)
    assert response.status_code == 200

    updated_award = json.loads(response.data.decode())
    assert updated_award['name'] == 'New name'

    # validate count
    response = client.get('/admin/award', headers=admin_header)
    assert response.status_code == 200

    awards = json.loads(response.data.decode())
    assert len(awards) == 1

    # test delete awards
    response = client.delete('/admin/award/' + award['_id'], headers=admin_header)
    assert response.status_code == 200


def test_award_list(client, admin_header):
    response = client.get('/admin/award', headers=admin_header)
    awards = json.loads(response.data.decode())
    count = len(awards)

    # test update award list
    new_award = {
        'name': 'Grammy',
        'url': 'https://www.grammy.com/',
    }
    awards[0]['name'] = 'updated name'
    awards.append(new_award)

    response = client.put('/admin/award', data=json.dumps(awards), headers=admin_header)
    assert response.status_code == 200

    # validate result from endpoint
    awards = json.loads(response.data.decode())

    assert response.status_code == 200
    assert len(awards) == count + 1

    assert awards[0]['name'] == 'updated name'
    assert awards[1]['name'] == 'Grammy'

    response = client.get('/admin/award', headers=admin_header)
    # validate result from GET
    awards_from_get = json.loads(response.data.decode())

    assert response.status_code == 200
    assert len(awards_from_get) == count + 1

    assert awards_from_get[0]['name'] == 'updated name'
    assert awards_from_get[1]['name'] == 'Grammy'
