from datetime import datetime
from flask import request
from bson.objectid import ObjectId
from pymongo import ReturnDocument, UpdateOne
from ..mongodb import raw_db


"""
keys should never be changed.
"""
default_blacklist = ['createdAt', 'createdBy', 'slug', '_id']

def get_document_by_id(collection, document_id, **kwargs):
    """
    get a single document by query
    """
    if isinstance(document_id, str):
        try:
            document_id = ObjectId(document_id)
        except InvalidId:
            return None

    return raw_db()[collection].find_one({'_id': document_id}, **kwargs)


def add_document(collection, document):
    """
    set default fields.
    """
    now = datetime.utcnow()
    document['createdAt'] = now
    document['lastUpdated'] = now
    document['createdBy'] = str(request.user.get('_id'))

    document['_id'] = str(raw_db()[collection].insert_one(document).inserted_id)
    return document


def get_documents(collection, query={}, **kwargs):
    """
    get a list of documents by query
    """
    return list(raw_db()[collection].find(query, **kwargs))


def get_documents_cursor(collection, query={}, **kwargs):
    """
    get a cursor of documents by query
    """
    return raw_db()[collection].find(query, **kwargs)


def get_document(collection, query={}, **kwargs):
    """
    get a single document by query
    """
    return raw_db()[collection].find_one(query, **kwargs)


def replace_document(collection, document_id, new_document):
    """
    get replace a single document in collection by id
    """
    if not isinstance(document_id, ObjectId):
        document_id = ObjectId(document_id)

    new_document['lastUpdated'] = datetime.utcnow()
    existing_document = raw_db()[collection].find_one({'_id': document_id})
    for key in default_blacklist:
        if key in existing_document:
            new_document[key] = existing_document[key]

    return raw_db()[collection].find_one_and_replace({'_id': document_id}, new_document, return_document=ReturnDocument.AFTER)


def list_documents(collection, projection=None):
    """
    get all documents from collection with filtering, sorting, pagination
    """
    return list(raw_db()[collection].find(request.filter_params, projection=projection)\
        .skip(request.skip).limit(request.page_size).sort(request.sort_params))


def get_document_by_id(collection, _id, **kwargs):
    """
    get document from collection by id.
    """
    if not isinstance(_id, ObjectId):
        _id = ObjectId(_id)

    return raw_db()[collection].find_one({'_id': ObjectId(_id)}, **kwargs)


def hard_delete_document_by_id(collection, _id):
    """
    delete document by id
    """
    raw_db()[collection].delete_one({'_id': ObjectId(_id)})


def update_document_by_id(collection, _id, changes, blacklist=[], upsert=True, deletions=[]):
    """
    partially update document by id
    """
    return update_document(collection, {'_id': ObjectId(_id)}, changes, blacklist, upsert, deletions)


def update_document(collection, find, updates, blacklist=[], upsert=True, deletions=[]):
    """
    partially update document by id
    """
    updates['lastUpdated'] = datetime.utcnow()
    updates = pop_blacklist_keys(updates, blacklist)

    changes = {'$set': build_update_query(updates)}
    if deletions:
        changes['$unset'] = build_delete_query(deletions)

    return raw_db()[collection].find_one_and_update(
        find, changes, upsert=upsert, return_document=ReturnDocument.AFTER
    )


def update_documents(collection, updates_list, blacklist=[], upsert=True):
    """
    update multiple documents
    updates_list: list of updates of format [{'filter': {'_id': id}, 'updates': document}]
    """
    update_queries = []
    last_updated = datetime.utcnow()

    for document in updates_list:
        updates = document['updates']
        updates['lastUpdated'] = last_updated
        updates = pop_blacklist_keys(updates, blacklist)

        update_queries.append(UpdateOne(filter=document['filter'], update={'$set': updates}, upsert=upsert))

    raw_db()[collection].bulk_write(update_queries)


def pop_blacklist_keys(changes, blacklist=[]):
    blacklist += default_blacklist
    for key in changes.copy():
        if key in blacklist:
            changes.pop(key)

    return changes

"""
build a dot separated update query for nested partial update request.
db.coll.update({'_id': 'id'}, {'$set': {'general.social.facebook': facebook.com/gw, 'general.location.city': 'new york'}})
"""
def build_update_query(document):
    query = {}
    build_update_query_helper(document, '', query)
    return query

def build_delete_query(fields):
    query = {field: '' for field in fields}
    return query

def build_update_query_helper(document, parent_key, query):
    for key in document:
        value = document.get(key)

        if len(parent_key) > 0:
            key = parent_key + '.' + key

        if isinstance(value, dict):
            build_update_query_helper(value, key, query)
        else:
            query[key] = value


def merge_diff(source, change):
    for key, value in change.items():
        if isinstance(value, dict):
            if key not in source:
                source[key] = {}

            source[key] = merge_diff(source[key], change[key])
        else:
            source[key] = change[key]

    return source
