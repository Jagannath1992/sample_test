from datetime import datetime
from typing import List

from portal.shared.repositories import order_repository
from portal.shared.enums import OrderStatus


GROUP_BY_CURRENCY          = {'currency': '$currency'}
GROUP_BY_CAUSE_AREA        = {'causeArea': '$causeArea.name', 'currency': '$currency'}
GROUP_BY_CAUSE_AREA_STATUS = {'causeArea': '$causeArea.name', 'status': '$status', 'currency': '$currency'}


class TestOrderRepositoryMetrics:

    def test_get_metrics_by_cause_area(self, init_test_data):
        # arrange
        us, _ = init_test_data
        filters = {
            'loc._id': {'$in': [us['locale']['_id']]},
            'lastUpdated': {'$gte': datetime.fromisoformat('2022-05-01')},
        }
        expected_result = {
            '_id': {'causeArea': 'Cause area 1', 'currency': 'USD'},
            # 'count': 2,
            # 'totalGiveAmount': 1100.0,
            'avgGiveAmount': 550.0,
            # 'totalDealAmount': 7000.0,
            'avgDealAmount': 3500.0,
            'avgGivePercent': 15.0,
            'impact': 110.0,
            'impactMeasurement': 'meals',
        }
        # act
        results = order_repository().get_metrics(filters, GROUP_BY_CAUSE_AREA, False)
        actual_result = _get_result(results, **expected_result['_id'])
        # assert
        assert len(results) == len(us['instance']['causeAreas'])
        assert actual_result == expected_result

    def test_get_metrics_by_cause_area_status(self, init_test_data):
        # arrange
        us, _ = init_test_data
        filters = {
            'loc._id': {'$in': [us['locale']['_id']]}
        }
        expected_result = {
            '_id': {'causeArea': 'Cause area 1', 'status': OrderStatus.PENDING_APPROVAL.value, 'currency': 'USD'},
            'count': 2,
            'totalGiveAmount': 550.0,
            # 'avgGiveAmount': 275.0,
            'totalDealAmount': 2500.0,
            # 'avgDealAmount': 1250.0,
            # 'avgGivePercent': 20.0,
            # 'impact': 55.0,
            # 'impactMeasurement': 'meals',
        }
        # act
        results = order_repository().get_metrics_by_status(filters, GROUP_BY_CAUSE_AREA_STATUS, False)
        actual_result = _get_result(results, **expected_result['_id'])
        # assert
        assert actual_result == expected_result

    def test_get_metrics_match_not_found(self, init_test_data):
        # arrange
        us, _ = init_test_data
        filters = {
            'loc._id': {'$in': [us['instance']['_id']]}
        }
        # act
        results = order_repository().get_metrics(filters, GROUP_BY_CAUSE_AREA_STATUS, False)
        # assert
        assert len(results) == 0

    def test_get_metrics_multi_currency(self, init_test_data):
        # arrange
        _, _ = init_test_data
        expected_result = {
            '_id': {'causeArea': 'Cause area 2', 'status': OrderStatus.APPROVED.value, 'currency': 'GBP'},
            'count': 2,
            'totalGiveAmount': 900.0,
            # 'avgGiveAmount': 450.0,
            'totalDealAmount': 4500.0,
            # 'avgDealAmount': 2250.0,
            # 'avgGivePercent': 20.0,
            # 'impact': 90.0,
            # 'impactMeasurement': 'meals'
        }
        # act
        results = order_repository().get_metrics_by_status({}, GROUP_BY_CAUSE_AREA_STATUS, False)
        actual_result = _get_result(results, **expected_result['_id'])
        currencies = _get_currencies(results)
        # assert
        assert len(currencies) == 2  # make sure there are 2 currencies in the results
        assert actual_result == expected_result

    def test_get_metrics_filter_by_cause_area(self, init_test_data):
        # arrange
        us, _ = init_test_data
        filters = {
            'causeArea._id': {'$in': [us['instance']['causeAreas'][1]['causeArea']['_id']]}
        }
        expected_result = {
            '_id': {'causeArea': 'Cause area 2', 'currency': 'GBP'},
            # 'count': 6,
            # 'totalGiveAmount': 2550.0,
            'avgGiveAmount': 500.0,
            # 'totalDealAmount': 14000.0,
            'avgDealAmount': 2875.0,
            'avgGivePercent': 17.5,
            'impact': 200.0,
            'impactMeasurement':'meals'
        }
        # act
        results = order_repository().get_metrics(filters, GROUP_BY_CAUSE_AREA, False)
        actual_result = _get_result(results, **expected_result['_id'])
        # assert
        assert actual_result == expected_result

    def test_get_metrics_filter_by_cause_area_overview(self, init_test_data):
        # arrange
        us, _ = init_test_data
        filters = {
            'causeArea._id': {'$in': [us['instance']['causeAreas'][0]['causeArea']['_id']]}
        }
        expected_result = {
            '_id': {'currency': 'GBP'},
            # 'count': 6,
            # 'totalGiveAmount': 2550.0,
            'avgGiveAmount': 500.0,
            # 'totalDealAmount': 14000.0,
            'avgDealAmount': 2875.0,
            'avgGivePercent': 17.5,
            'impact': 200.0,
            'impactMeasurement': 'meals'
        }
        # act
        results = order_repository().get_metrics(filters, GROUP_BY_CURRENCY, False)
        actual_result = _get_result(results, **expected_result['_id'])
        # assert
        assert actual_result == expected_result

    def test_get_metrics_multiple_filters(self, init_test_data):
        # arrange
        us, _ = init_test_data
        filters = {
            'causeArea._id': {'$in': [us['instance']['causeAreas'][0]['causeArea']['_id']]},
            'acct.instance._id': {'$in': [us['account']['instance']['_id']]}
        }
        expected_result = {
            '_id': {'currency': 'USD'},
            # 'count': 6,
            # 'totalGiveAmount': 2550.0,
            'avgGiveAmount': 500.0,
            # 'totalDealAmount': 14000.0,
            'avgDealAmount': 2875.0,
            'avgGivePercent': 17.5,
            'impact': 200.0,
            'impactMeasurement': 'meals'
        }
        # act
        results = order_repository().get_metrics(filters, GROUP_BY_CURRENCY, False)
        actual_result = _get_result(results, **expected_result['_id'])
        # assert
        assert actual_result == expected_result


def _get_result(results: List[dict], causeArea: dict = None, status: str = None, currency: str = 'USD') -> dict:
    for result in results:
        if result['_id']['currency'] == currency:
            if not causeArea or result['_id']['causeArea'] == causeArea:
                if not status or result['_id']['status'] == status:
                    return result


def _get_currencies(results: List[dict]) -> list:
    currencies = []
    for result in results:
        currency = result['_id']['currency']
        if currency not in currencies:
            currencies.append(currency)
    return currencies
