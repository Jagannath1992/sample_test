from bson import ObjectId

from portal.shared.dates import get_utcnow
from portal.shared.enums import OrderStatus, AccountType
from portal.testing.faker import DocumentFaker


class OrderFaker(DocumentFaker):
    def _generate_document(self, i):
        now = get_utcnow()
        return {
            '_id': ObjectId(),
            'account': {
                '_id': ObjectId(),
                '_type': 'account',
                'name': f'Account {i}'
            },
            'causeArea': {
                '_id': ObjectId(),
                '_type': 'cause_area',
                'name': f'Cause area {i}',
                'impact': {
                    'unitPrice': 100,
                    'unitValue': 10,
                    'impactMeasurement': 'meals',
                    'totalValue': 50.00
                },
            },
            'status': OrderStatus.PENDING_APPROVAL.value,
            'giveId': i,
            'customerId': ObjectId(),
            'customerName': f'customer {i}',
            'quoteNumber': f'quote {i}',
            'quoteAmount': i,
            'description': 'Description for the Order',
            'detail': [
                {
                    'skuId': str(ObjectId()),
                    'skuName': f'Sku Name {i}',
                    'qty': i,
                    'unitCost': float(i),
                    'totalCost': float(i)
                } for r in range(1, 2)
            ],
            'comments': [
                {'comment': 'New Give', 'newStatus': OrderStatus.PENDING_APPROVAL.value}
            ],
            'grandTotal': float(i),
            'currency': 'USD',
            'customField1': f'CustomField1 {i}',
            'customField2': f'CustomField2 {i}',
            'customField3': f'CustomField3 {i}',
            'customField4': f'CustomField4 {i}',
            'createdBy': f'createdBy{i}@example.com',
            'createdAt': now,
            'lastUpdatedBy': f'lastUpdatedBy{i}@example.com',
            'lastUpdated': now
        }
