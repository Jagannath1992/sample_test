from datetime import datetime
from dateutil.relativedelta import relativedelta

from matchmaking.dao.utils import update_document_by_id


def update_mpa(npo_id, form_name, patch_request):
    update = {
        'mpa': {
            form_name: patch_request,
            'status': 'SIGNATURE_PENDING'
        }
    }
    return update_document_by_id('mm_nonprofits', npo_id, update, upsert=False).get('mpa', {})


def submit_mpa(npo_id, mpa):
    mpa['effectiveDate'] = datetime.utcnow()
    mpa['expirationDate'] = datetime.utcnow() + relativedelta(years=6)
    mpa['status'] = 'EXECUTED'

    return update_document_by_id('mm_nonprofits', npo_id, {'mpa': mpa}, upsert=False).get('mpa', {})
