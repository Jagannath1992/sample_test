#!/bin/bash
gunicorn flask_app:app -w 2 -b :8080 --log-level=debug