from matchmaking.query_parser import parse_pagination_params

def test_pagination():
    page_size, skip = parse_pagination_params('5', '3')
    assert page_size == 5
    assert skip == 10

    page_size, skip = parse_pagination_params('a', '3')
    assert page_size == 50
    assert skip == 0
