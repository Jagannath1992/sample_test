from flask import Blueprint

root_bp = Blueprint('root_bp', __name__)
program_bp = Blueprint('program_bp', __name__)
nonprofit_bp = Blueprint('nonprofit_bp', __name__)
asset_bp = Blueprint('asset_bp', __name__)
preview_assets_bp = Blueprint('preview_assets_bp', __name__)
deal_bp = Blueprint('deal_bp', __name__)
