import requests
import pytest
from os import environ
from bson.json_util import dumps


@pytest.mark.skip(reason="this test case will send a real message to slack channel, remove annotation to see message")
def test_deal_slack_message():
    ADMIN_URL = 'https://admin.nohardstops.com'
    PROPOSAL_URL = 'https://hooks.slack.com/services/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'
    headers = {'Content-Type': 'application/json'}

    user = {
        'first_name': 'Shanyan',
        'last_name': 'Jiang'
    }

    proposal = {
        '_id': '5d38b1e9c603cd0f36953d07',
        'fundingAmount': 7000,
        'name': 'test_other_brand_creation',
        'status': 'PROGRAM_SELECTION_PENDING',
        'totalBudget': 500000,
        'currency': 'USD',
        'givewithCustomerRole': 'supplier',
        'managerName': 'Elizabeth Chan',
        'selectedRecommendedPrograms': [],
        'isValid': True,
        'clientEmails': [],
        'givewithCustomerEmails': [
            'daniel.obeng@givewith.com'
        ],
        'archived': False,
        'type': 'covid'
    }

    data = {
        "text": "Proposal created successfully in Production",
        "blocks":
            [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        'text': create_deal_slack_msg(proposal, user, ADMIN_URL)
                    },
                },
            ]
    }

    r = requests.post(PROPOSAL_URL, data=dumps(data), headers=headers)
    assert r.status_code == 200


def create_deal_slack_msg(deal, user, ADMIN_URL):
    msg = '{0} a *{1}* deal <{2}|{3}> has been created by *{4}* in *{5}*'
    return msg.format('', deal.get('type'), ADMIN_URL + '/#/deals/' + str(deal.get('_id')), deal.get('name'), user.get('first_name') + ' ' + user.get('last_name'), environ.get('ENV'))
