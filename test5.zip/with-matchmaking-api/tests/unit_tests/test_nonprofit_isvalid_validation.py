from matchmaking.models import models
from bson import ObjectId

def test_validate_nonprofit_v2():
    nonprofit = {
        "_id" : ObjectId("5e4c5657dba98318dffdf4ba"),
        "applicationFormName" : "Courtney's cookie cakes",
        "editing" : False,
        "general" : {
            "contact" : {
                "email" : "ccohen01@gmail.com",
                "name" : "Courtney Cohen",
                "phone" : "555555555",
                "professionalTitle" : "Title"
            },
            "location" : {
                "generalLocation" : "United States",
                "specificLocation" : "Alabama",
                "taxId" : "11-1111111",
                "w9" : {
                    "name" : "duck_1581713631746.png",
                    "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e4c559e1a55e25dc0cfcb51/duck_1581713631746_1582061009143.png"
                }
            },
            "missionAgreement" : True,
            "name" : {
                "legalOrganizationName" : "Courtney's cookie cakes inc",
                "publicOrganizationName" : "Courtney's cookie cakes"
            },
            "social" : {
                "facebook" : "facebook",
                "instagram" : "insta",
                "websiteURL" : "www.cookiecakesyum.com"
            }
        },
        "givewithAdmin" : "5dd44741559d45f9b83d1cba",
        "isValid" : False,
        "lastUpdated" : "2020-02-19T20:10:05.500Z",
        "name" : "Courtney's cookie cakes",
        "nonprofitSubmissionId" : ObjectId("5e4c559e1a55e25dc0cfcb51"),
        "operationalInformation" : {
            "financialStatement" : {
                "file" : {
                    "name" : "duck_1581713631746.png",
                    "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e4c559e1a55e25dc0cfcb51/duck_1581713631746_1582061098500.png"
                }
            },
            "partnershipsDescription" : "test",
            "staff" : {
                "fullTime" : "",
                "partTime" : "1",
                "volunteers" : 2
            },
            "supportersAndPartners" : "test",
            "yearlyBudget" : "500000"
        },
        "overviewAndMission" : {
            "causeAreas" : {
                "selected" : [
                    "5a99921742073d0946343fb2"
                ]
            },
            "historyDescription" : "test",
            "initiativesDescription" : "test",
            "lifetimeOutputs" : [
                {
                    "output" : "cookies",
                    "quantity" : "5",
                    "key" : "1582061145217"
                },
                {
                    "output": "cookies",
                    "quantity": 100,
                    "key": "1582061145217"
                },
                {
                    "output": "cookies",
                    "quantity": "5%",
                    "key": "1582061145217"
                },
                {
                    "output": "cookies",
                    "quantity": "$500",
                    "key": "1582061145217"
                }
            ],
            "problemDescription" : "test",
            "programLocations" : "test",
            "researchAndEvaluation" : "test",
            "researchAndEvaluationFile" : {
                "name" : "Designing_Distributed_Systems.pdf",
                "url" : "https://s3.amazonaws.com/givewith-staging-secure-upload/nonprofit_form/5e4c559e1a55e25dc0cfcb51/Designing_Distributed_Systems_1582142964076.pdf"
            }
        },
        "percentComplete" : 100,
        "progress" : {
            "general" : {
                "complete" : 12,
                "total" : 12
            },
            "operationalInformation" : {
                "complete" : 6,
                "total" : 6
            },
            "overviewAndMission" : {
                "complete" : 7,
                "total" : 7
            }
        },
        "review" : {
            "email" : "1@1.com",
            "name" : "1"
        },
        "slug" : "5e4c559e1a55e25dc0cfcb51",
        "description" : "test",
        "nonprofitId" : "5e4c5657dba98318dffdf4ba",
        "videoFallback": "",
    }
    v = models.GivewithValidator(purge_unknown=True)
    is_valid = v.validate(nonprofit, models.schema_nonprofit_v2)
    assert is_valid

    # researchAndEvaluationFile is optional
    nonprofit.get('overviewAndMission').pop('researchAndEvaluationFile')
    v = models.GivewithValidator(purge_unknown=True)
    is_valid = v.validate(nonprofit, models.schema_nonprofit_v2)
    assert is_valid

    # description is required
    nonprofit.pop('description')
    is_valid = v.validate(nonprofit, models.schema_nonprofit_v2)
    assert not is_valid


def test_validate_nonprofit_v1():
    nonprofit = {
        "_id" : ObjectId("5b2bf32ee3dde1001ae17701"),
        "applicationFormName" : "",
        "createdAt" : "2018-06-21T18:49:18.579000Z",
        "createdBy" : "",
        "description" : "GRID’s unique, people-first model, is putting money back into families’ pockets, increasing housing affordability and reducing the energy cost burden for affordable housing providers. GRID is working across the United States and internationally to make renewable energy technology and job training accessible to underserved communities. description here",
        "descriptionShort" : "GRID!",
        "editing" : True,
        "general" : {
            "contact" : {
                "email" : "",
                "name" : "",
                "phone" : "",
                "professionalTitle" : ""
            },
            "location" : {
                "generalLocation" : "United States",
                "specificLocation" : "",
                "taxId" : "26-0043353",
                "w9" : {
                    "name" : "",
                    "url" : ""
                }
            },
            "missionAgreement" : True,
            "name" : {
                "legalOrganizationName" : "GRID Alternatives",
                "publicOrganizationName" : "GRID Alternatives"
            },
            "social" : {
                "facebook" : "",
                "instagram" : "",
                "linkedIn" : "",
                "twitter" : "",
                "websiteURL" : "https://gridalternatives.org"
            }
        },
        "givewithAdmin" : "5d1510d6d5b3a5330a3d0467",
        "isValid" : False,
        "lastUpdated" : "2020-02-20T15:44:06.624Z",
        "name" : "GRID Alternatives",
        "notes" : "",
        "operationalInformation" : {
            "financialStatement" : {
                "file" : {
                    "name" : "",
                    "url" : ""
                },
                "website" : ""
            },
            "partnershipsDescription" : "",
            "staff" : {
                "fullTime" : "",
                "partTime" : "",
                "volunteers" : ""
            },
            "supportersAndPartners" : "",
            "yearlyBudget" : ""
        },
        "overviewAndMission" : {
            "causeAreas" : {
                "selected" : []
            },
            "historyDescription" : "",
            "initiativesDescription" : "",
            "lifetimeOutputs" : [
                {
                    "key" : "1582209450196",
                    "output" : "Percent of household electricity costs reduced",
                    "quantity" : 90
                },
                {
                    "key" : "1582209450196",
                    "output" : "Systems installed",
                    "quantity" : '30%'
                },
                {
                    "key" : "1582209450196",
                    "output" : "Tons of greenhouse gas emissions prevented",
                    "quantity" : '$100'
                }
            ],
            "problemDescription" : "",
            "programLocations" : "",
            "researchAndEvaluation" : "",
            "researchAndEvaluationFile" : {
                "name" : "",
                "url" : ""
            }
        },
        "percentComplete" : 0,
        "progress" : {
            "general" : {
                "complete" : 0,
                "total" : 0
            },
            "operationalInformation" : {
                "complete" : 0,
                "total" : 0
            },
            "overviewAndMission" : {
                "complete" : 0,
                "total" : 0
            }
        },
        "review" : {
            "email" : "",
            "name" : ""
        },
        "slug" : "grid-alternatives",
        "status" : "",
        "videoFallback" : "",
        "vimeoId" : ""
    }

    v = models.GivewithValidator(purge_unknown=True)
    is_valid = v.validate(nonprofit, models.schema_nonprofit_v1)
    assert is_valid

