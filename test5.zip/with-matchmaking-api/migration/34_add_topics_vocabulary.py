# pylint: disable=invalid-name
from pymongo import ReturnDocument
from matchmaking import db

vocabulary = [
    {'label': 'Education', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Environment', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Veterans', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Diversity and inclusion', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Food and hunger', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Animal welfare', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Women and girls', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Health and wellness', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Disaster relief', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Aging populations', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'People with disabilities', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Housing and homelessness', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Arts and culture', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Poverty alleviation', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'LGBTQ+', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Human rights and social justice', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Immigrants and refugees', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Indigenous peoples', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'People of color', 'type': 'topic', 'versions': [1, 2]},
    {'label': 'Responsible business', 'type': 'topic', 'versions': [1, 2]},
]

# TVL isn't included since TVL maps to SASB
data = [
    ('esg', 'Carbon Emissions', 'Environment'),
    ('esg', 'Climate Change Vulnerability', 'Environment'),
    ('esg', 'Human Capital Development', 'Diversity and inclusion'),
    ('esg', 'Access to Finance', 'Poverty alleviation'),
    ('esg', 'Access to Communications', 'Poverty alleviation'),
    ('esg', 'Responsible Investment', 'Responsible business'),
    ('csrhub', 'Diversity and Labor Rights', 'Diversity and inclusion'),
    ('csrhub', 'Community Development and Philanthropy', 'Poverty alleviation'),
    ('csrhub', 'Human Rights and Supply Chain', 'Human rights and social justice'),
    ('csrhub', 'Leadership Ethics', 'Responsible business'),
    ('csrhub', 'Energy and Climate Change', 'Environment'),
    ('sdg', 'No poverty', 'Poverty alleviation'),
    ('sdg', 'Zero hunger', 'Food and hunger'),
    ('sdg', 'Clean water and sanitation', 'Food and hunger'),
    ('sdg', 'Industry, innovation and infrastructure', 'Responsible business'),
    ('sdg', 'Responsible consumption and production', 'Environment'),
    ('sdg', 'Peace, justice and strong institutions', 'Responsible business'),
    ('sdg', 'Partnerships for the goals', 'Responsible business'),
    ('sdg', 'Good health and well-being', 'Health and wellness'),
    ('sdg', 'Quality education', 'Education'),
    ('sdg', 'Gender equality', 'Women and girls'),
    ('sdg', 'Decent work and economic growth', 'Poverty alleviation'),
    ('sdg', 'Reduce inequalities', 'Diversity and inclusion'),
    ('sdg', 'Life below water', 'Animal welfare'),
    ('sdg', 'Life on land', 'Animal welfare'),
    ('sdg', 'Affordable and clean energy', 'Environment'),
    ('sdg', 'Sustainable cities and communities', 'Environment'),
    ('sdg', 'Climate action', 'Environment'),
    # ('TVL', 'Ecological Impacts', 'Animal welfare'),
    # ('TVL', 'Access and Affordability', 'Poverty alleviation'),
    # ('TVL', 'Human Rights and Community Development', 'Human rights and social justice'),
    # ('TVL', 'GHG Emissions', 'Environment'),
    # ('TVL', 'Business Ethics', 'Responsible business'),
    ('sasb', 'Access and Affordability', 'Poverty alleviation'),
    ('sasb', 'Business Ethics', 'Responsible business'),
    ('sasb', 'Human Rights & Community Relations', 'Human rights and social justice'),
    ('sasb', 'Ecological Impacts', 'Animal welfare'),
    ('sasb', 'GHG Emissions', 'Environment'),
    ('gri', 'Community Investment', 'Poverty alleviation'),
    ('gri', 'Climate Change Mitigation', 'Environment'),
    ('gri', 'Infrastructure Investment', 'Poverty alleviation'),
    ('gri', 'Positive Economic Impacts in the Community', 'Poverty alleviation'),
    ('gri', 'External Energy Consumption', 'Environment'),
    ('gri', 'Significant impacts of activities, products, and services on biodiversity', 'Animal welfare'),
    ('gri', 'Habitats protected or restore', 'Animal welfare'),
    ('gri', 'Other indirect (Scope 3) GHG emissions', 'Environment'),
    ('gri', 'Reduction of GHG emissions', 'Environment'),
    ('gri', 'Local Community Engagement', 'Poverty alleviation'),
    ('themes', 'Education', 'Education'),
    ('themes', 'Environment', 'Environment'),
    ('themes', 'Veterans', 'Veterans'),
    ('themes', 'Diversity and inclusion', 'Diversity and inclusion'),
    ('themes', 'Food and hunger', 'Food and hunger'),
    ('themes', 'Animal welfare', 'Animal welfare'),
    ('themes', 'Economic empowerment', 'Poverty alleviation'),
    ('themes', 'Criminal justice', 'Human rights and social justice'),
    ('themes', 'Youth development', 'Education'),
    ('themes', 'Women and girls', 'Women and girls'),
    ('themes', 'Health and wellness', 'Health and wellness'),
    ('themes', 'Disaster response, relief and recovery', 'Disaster relief'),
    ('themes', 'Aging populations', 'Aging populations'),
    ('themes', 'People with disabilities/disabled persons', 'People with disabilities'),
    ('themes', 'Housing and homelessness', 'Housing and homelessness'),
    ('themes', 'Arts and culture', 'Arts and culture'),
    ('themes', 'Poverty alleviation', 'Poverty alleviation'),
    ('themes', 'LGBTQQIA+', 'LGBTQ+'),
    ('themes', 'Human rights and civic engagement', 'Human rights and social justice'),
    ('themes', 'Immigrants', 'Immigrants and refugees'),
    ('themes', 'Indigenous peoples', 'Indigenous peoples'),
    ('themes', 'People of color', 'People of color'),
    ('themes', 'Refugees', 'Immigrants and refugees'),
]

def get_topic_id(label):
    vocab = db().coll_vocabulary.find_one({'type': 'topic', 'label': label})
    return vocab['_id']

##### ------- Inject new vocabulary ----- ######
# to allow for re-runs, only re-inject if topics do not exist in vocabulary
if not db().coll_vocabulary.find_one({'type': 'topic'}):
    db().coll_vocabulary.insert_many(vocabulary)


##### ---- Associate existing vocabulary with topics ----- #############3
for vocab_tuple in data:
    vocab_type = vocab_tuple[0]
    vocab_label = vocab_tuple[1]
    topic_label = vocab_tuple[2]

    topic_id = get_topic_id(topic_label)
    updated_vocab = db().coll_vocabulary.find_one_and_update({'type': vocab_type, 'label': vocab_label},
                                                             {'$set': {'topic': topic_id}},
                                                             return_document=ReturnDocument.AFTER)

    if not updated_vocab or not updated_vocab.get('topic'):
        print(f'Error adding topic to vocabulary: {vocab_type} - {vocab_label}')
