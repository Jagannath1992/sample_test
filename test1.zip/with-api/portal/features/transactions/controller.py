from flask import request, Response
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from werkzeug.exceptions import NotFound

from portal.features.transactions.schema import TransactionRequest, TransactionResponse, TransactionSearchRequest, \
    TransactionSearchResponse, TransactionsMonthEndResponse
from portal.shared.auth.requests import role_required
from portal.shared.auth.security import get_validated_account_id
from portal.shared.enums import UserRole
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import account_repository, instance_settings_repository, transaction_repository, locale_repository
from portal.shared.services import email_service, transaction_service

namespace = Namespace('transactions', description='Transaction related operations')


@namespace.route('')
@namespace.response(400, 'Bad request')
class Transactions(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_FINANCE])
    @accepts(schema=TransactionRequest, api=namespace)
    @responds(schema=TransactionResponse, api=namespace)
    def post(self):
        transaction = request.parsed_obj
        transaction['account']['_id'] = get_validated_account_id(transaction['account']['_id'], request)

        account = account_repository().get_single(
            transaction['account']['_id'],
            {'initialBalance': 1, 'currentBalance': 1, 'instance._id':1})
        amount = transaction['amount']

        if 'initialBalance' not in account:
            transaction['startingBalance'] = 0.0
            transaction['endingBalance'] = amount
            account['initialBalance'] = amount
            account['currentBalance'] = amount
        else:
            currentBalance = account['currentBalance']
            transaction['startingBalance'] = currentBalance
            endingBalance = currentBalance + amount
            transaction['endingBalance'] = endingBalance
            account['currentBalance'] = endingBalance

        instance = instance_settings_repository().get_single(account['instance']['_id'])
        locale_id = instance['settings']['locale']['_id']
        locale = locale_repository().get_single(locale_id)
        transaction['currency'] = locale['settings']['currency']
        new_transaction = transaction_repository().insert(transaction, request.user['username'])
        account = account_repository().patch(transaction['account']['_id'], account)
        if amount > 0:
            email_service().send_balance_deposit_to_account_email(instance, account)
        return new_transaction

    @role_required(GIVEWITH_ROLES + [UserRole.FINANCE, UserRole.EXECUTIVE])
    @accepts(query_params_schema=TransactionSearchRequest, api=namespace)
    @responds(schema=TransactionSearchResponse, api=namespace)
    def get(self):
        """Search Transactions"""
        params = request.parsed_query_params
        params['account._id'] = get_validated_account_id(params.get('account._id'), request)
        total_count, transactions = transaction_repository().get_page(params)
        return {'totalCount': total_count, 'results': transactions}


@namespace.route('/monthly-recon')
@namespace.doc(
    responses={
        400: 'Bad Request'
    })
class OrdersMonthReconciliation(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.GW_FINANCE])
    @responds(schema=TransactionsMonthEndResponse, api=namespace)
    def get(self):
        data = transaction_service().monthly_reconciliation_data()
        return Response(data.to_csv(), mimetype="text/csv", headers={"Content-disposition":"attachment; filename='month-end-reconciliation.csv"})