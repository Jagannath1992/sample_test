from matchmaking import db

deals = list(db().coll_deals.find())
for deal in deals:
    deliverables = deal.get('deliverables')
    if deliverables:
        customer_deliv = deliverables['givewithCustomer']['deliverables']
        client_deliv = deliverables['client']['deliverables']

        for item in customer_deliv:
            if item['name'] == 'InvestorsRelations':
                item['name'] = 'InvestorRelations'

        for item in client_deliv:
            if item['name'] == 'InvestorsRelations':
                item['name'] = 'InvestorRelations'

        db().coll_deals.update_one({'_id' : deal.get('_id')}, {'$set': {'deliverables.givewithCustomer.deliverables': customer_deliv,
                                                                    'deliverables.client.deliverables': client_deliv}})
