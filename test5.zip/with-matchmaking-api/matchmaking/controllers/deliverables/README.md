
# Deliverables

<IMG SRC="../../../resources/deliverables.png" width=250>

What happens here?  This code is responsible for making the "deliverables" -- the documentation that is 
available to the customer and client upon completion of their Givewith proposal. 

The primary endpoint is at:
`https://<MM-API in some environment>/admin/deliverables/<pff_id>`

The response is a JSON object which includes the debugging key/value information for a deal,
and a `completed_deliverables` dict at the top level, which will have a list of resulting deliverables with the keys:
* CSRHighlight
* ESGReportingGuide_CUSTOMER
* ESGReportingGuide_CLIENT
* FactSheet
* InvestorRelations
* PressRelease
* SocialMediaPosts


In the `templates` directory (`/matchmaking/controllers/deliverables/templates`), there are
Word docs (as `.docx` filetypes), which are setup to consume variables passed to it through the Python templating 
engine (<A HREF="https://docxtpl.readthedocs.io/en/latest/">`python-docx-template`</A> based on `Jinja`).  

The templating is actually quite easy and intuitive:
<IMG SRC="../../../resources/example_deliverables.png" border=1>

In the example snippet, above, note that `{{ NONPROFIT_NAME }}` (replaced values are always within double curly brackets,
and written in all caps by way of our convention) will then be replaced by the value that
this endpoint receives from numerous data sources (the deal record, the PFF record, as well as
brand records).  

### How to fix existing deliverables?

If you want to change the template, get the current `docx` from the matching deliverable from this repo and edit the document
content and layout as needed.  If you're looking to change the variables that are
dynamically placed in the document, you can take a look at the what the endpoint (noted above) returns, as that includes
all of the data that is also passed to the Jinja engine.

Then return the Word doc to the repo and deploy appropriately.  


### How to add new deliverables?

Similarly, if you want to create new Word deliverables, you can add the templates, then look at the line in 
`deliverables.py` that looks like:

        list_of_completed_files['SocialPosts'] = __make_document('SocialPosts', deal_id, useful_data)
       
        
 and add a new one with your new document information.  That's really about all you need to do to add a new document 
 *if you don't need new dynamic data*.
 
 ### Ok, but I DO need new dynamic data.
 
 This, too, is not *that* crazy. 
 
 You can also see in `deliverables.py` that `useful_data`, which is the same data you see in the JSON that returns
 from the endpoint is where all the variables are passed to the template.  You simply need to get more data into 
 that dictionary.  
 
 One way, which is the way it currently works, is that the endpoint goes and gets all the data for multiple
 objects in a `master_data` dict which as all of the objects (and data) needed to pass to the template.  The current 
 code manipulates this data and outputs just what it needs, with a matching ALL CAPS key, into `useful_data`.
 
