from matchmaking import db

db().coll_user.update_many({'departmentType': {'$exists' : False}}, {'$set': {'departmentType': 'Other'}})
