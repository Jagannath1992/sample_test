from bson import ObjectId
from flask import jsonify, request
import jwt
from pymongo import ReturnDocument
from werkzeug.utils import secure_filename
from datetime import datetime

from matchmaking.util.forex import convert_to_usd
from ...s3 import upload_file, delete_file
from ...mongodb import (db, get_survey_by_slug, update_survey, get_survey_metadata, get_location_data, get_user,
                        get_deal, expand_vocabulary_label)
from ...utils import (UnsupportedPayload, GivewithError, EntityNotFound, set_last_updated, SurveyStatus, send_loggly,
                      InvalidPayload, get_descendant_key, pop_descendant_key, set_descendant_key, ValidationError)
from .utils import get_gw_customer_and_client_names, get_program_by_id, get_nonprofit_by_id
from matchmaking.service.slack import send_si_platform_message
from ...controllers import survey_bp
from ...models.models import survey_model, GivewithValidator, to_bool, Currency
from ...models.nonprofit import (funding_form_model, schema_funding_form_client, completion_form_model,
                                 schema_completion_form_client)
from ...controllers.vocabulary import get_vocabulary
from ...permission_decorator import require_nonprofit_permission

entity_names = {
    'PFF': 'program-funding-form',
    'PCF': 'program-completion-form',
    'PSF': 'survey'
}

form_models = {
    'PFF': funding_form_model,
    'PSF': survey_model,
    'PCF': completion_form_model
}

v = GivewithValidator(allow_unknown=False)

# minimum funding amount (USD) required for PFF itemization question dependency
MIN_FUNDING_AMOUNT = 25000


"""
@api {get} /:form_type/:nonprofit_slug/:slug Get Form
@apiName GetForm
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription get a nonprofit form

@apiParam {String=PCF,PSF,PFF} form_type the nonprofit form type
@apiParam {String} nonprofit_slug the nonprofit slug/unique identifier
@apiParam {String} slug the form slug/unique identifier

@apiParam (Query String) {Boolean} [isWelcome] append welcome metadata
@apiParam (Query String) {Boolean} [isReview] append review metadata

@apiSuccessExample {json} response example:
{
    "_id": "5e2f0eaba83264bd927c5b41",
    "editing": true,
    "name": "testing UK",
    "nonprofit": "5b29101ce3dde10019e1773c",
    "nonprofitSlug": "volunteers-of-america",
    "slug": "Ib4pnuQz8a5zXCp",
    "status": "IN_PROGRESS"
    "Funding": {
        "programDate": {
            "end": "2020-10-01T00:00:00.000000Z",
            "start": "2020-01-01T00:00:00.000000Z"
        }
    },
    "General": {
        "contact": {
            "email": "test@test.com",
            "name": "test",
            "phone": "123447866"
        },
    },
    "percentComplete": 10.0,
    "progress": {
        "Funding": {
            "complete": 1,
            "total": 3
        },
        "General": {
            "complete": 1,
            "total": 3
        },
    },
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('<form_type>/<nonprofit_slug>/<slug>', methods=['GET'])
@require_nonprofit_permission
def get_survey_data_dispatch(form_type, nonprofit_slug, slug):
    if not check_nonprofit_permission(nonprofit_slug):
        raise GivewithError('Insufficient permission. User does not have the same nonprofit org id', code=403)

    result = get_survey_data(form_type.upper(), nonprofit_slug, slug)
    return jsonify(result)


"""
@api {patch} /:form_type/:nonprofit_slug/:slug/:form_name Update Form
@apiName UpdateFormSection
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription updates a section of a nonprofit form

@apiParam {String=PCF,PSF,PFF} form_type the nonprofit form type
@apiParam {String} nonprofit_slug the nonprofit slug/unique identifier
@apiParam {String} slug the form slug/unique identifier
@apiParam {String} form_name the form section to save the data to

@apiParamExample {json} request example:
{
    "programDate": {
        "end": "2020-10-01T00:00:00.000000Z",
    }
}

@apiSuccessExample {json} response example:
{
    "_id": "5e2f0eaba83264bd927c5b41",
    "editing": true,
    "name": "testing UK",
    "nonprofit": "5b29101ce3dde10019e1773c",
    "nonprofitSlug": "volunteers-of-america",
    "slug": "Ib4pnuQz8a5zXCp",
    "status": "IN_PROGRESS"
    "Funding": {
        "programDate": {
            "end": "2020-10-01T00:00:00.000000Z",
            "start": "2020-01-01T00:00:00.000000Z"
        }
    },
    "General": {
        "contact": {
            "email": "test@test.com",
            "name": "test",
            "phone": "123447866"
        },
    },
    "percentComplete": 10.0,
    "progress": {
        "Funding": {
            "complete": 1,
            "total": 3
        },
        "General": {
            "complete": 1,
            "total": 3
        },
    },
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/<form_type>/<nonprofit_slug>/<slug>/<form_name>', methods=['PATCH'])
@require_nonprofit_permission
def update_survey_data_dispatch(form_type, nonprofit_slug, slug, form_name):
    if not check_nonprofit_permission(nonprofit_slug):
        raise GivewithError('Insufficient permission. User does not have the same nonprofit org id', code=403)

    result = update_survey_data(form_type.upper(), nonprofit_slug, slug, form_name)
    return jsonify(result)


"""
@api {post} /:form_type/:nonprofit_slug/:slug/ Submit Form
@apiName SubmitForm
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription submit a nonprofit form

@apiParam {String=PCF,PSF,PFF} form_type the nonprofit form type
@apiParam {String} nonprofit_slug the nonprofit slug/unique identifier
@apiParam {String} slug the form slug/unique identifier

@apiParamExample {json} request example:
{
    "signature": {
        "name": "Michael from Givewith",
        "email": "michaelfromgivewith@givewith.com"
    }
}

@apiSuccessExample {json} response example:
{
    "_id": "5e2f0eaba83264bd927c5b41",
    "editing": false,
    "name": "testing UK",
    "nonprofit": "5b29101ce3dde10019e1773c",
    "nonprofitSlug": "volunteers-of-america",
    "slug": "Ib4pnuQz8a5zXCp",
    "status": "SUBMITTED"
    "Funding": {
        "programDate": {
            "end": "2020-10-01T00:00:00.000000Z",
            "start": "2020-01-01T00:00:00.000000Z"
        }
    },
    "General": {
        "contact": {
            "email": "test@test.com",
            "name": "test",
            "phone": "123447866"
        },
    },
    "percentComplete": 100.0,
    "signature": {
        "name": "Michael from Givewith",
        "email": "michaelfromgivewith@givewith.com"
    }
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/<form_type>/<nonprofit_slug>/<slug>', methods=['POST'])
@require_nonprofit_permission
def submit_survey_dispatch(form_type, nonprofit_slug, slug):
    if not check_nonprofit_permission(nonprofit_slug):
        raise GivewithError('Insufficient permission. User does not have the same nonprofit org id', code=403)

    result = submit_survey(form_type.upper(), nonprofit_slug, slug)
    return jsonify(result)


"""
@api {post} /:form_type/:nonprofit_slug/:slug/sign Sign Form
@apiName SignForm
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription submit form signature

@apiParam {String=PFF} form_type the nonprofit form type
@apiParam {String} nonprofit_slug the nonprofit slug/unique identifier
@apiParam {String} slug the form slug/unique identifier

@apiParamExample {json} request example:
{
    "signature": {
        "name": "Michael from Givewith",
        "email": "michaelfromgivewith@givewith.com"
    }
}

@apiSuccessExample {json} response example:
{
    "_id": "5e2f0eaba83264bd927c5b41",
    "editing": false,
    "name": "testing UK",
    "nonprofit": "5b29101ce3dde10019e1773c",
    "nonprofitSlug": "volunteers-of-america",
    "slug": "Ib4pnuQz8a5zXCp",
    "status": "EXECUTED"
    "Funding": {
        "programDate": {
            "end": "2020-10-01T00:00:00.000000Z",
            "start": "2020-01-01T00:00:00.000000Z"
        }
    },
    "General": {
        "contact": {
            "email": "test@test.com",
            "name": "test",
            "phone": "123447866"
        },
    },
    "percentComplete": 100.0,
    "signature": {
        "name": "Michael from Givewith",
        "email": "michaelfromgivewith@givewith.com"
    }
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/<form_type>/<nonprofit_slug>/<slug>/sign', methods=['POST'])
@require_nonprofit_permission
def submit_signature_dispatch(form_type, nonprofit_slug, slug):
    if not check_nonprofit_permission(nonprofit_slug):
        raise GivewithError('Insufficient permission. User does not have the same nonprofit org id', code=403)

    result = submit_signature(form_type.upper(), nonprofit_slug, slug)
    return jsonify(result)


"""
@api {post} /:form_type/:nonprofit_slug/:slug/:form_name/upload Upload File to Form
@apiName UploadFileToForm
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription upload a file to a nonprofit form

@apiParam {String=PFF,PCF,PSF} form_type the nonprofit form type
@apiParam {String} nonprofit_slug the nonprofit slug/unique identifier
@apiParam {String} slug the form slug/unique identifier
@apiParam {String} form_name the form section to save the data to

@apiParam (Files) {FileObject} file file stream object
@apiParam (Files) {FileObject} file[stream] file stream
@apiParam (Files) {FileObject} file[filename] filename

@apiParam (Form) {Object} path the path to save upload url to

@apiParamExample {Form} path-example:
{
    "path": "budgetFile.value"
}

@apiSuccessExample {json} response example:
{
    "_id": "5e2f0eaba83264bd927c5b41",
    "editing": true,
    "name": "testing UK",
    "nonprofit": "5b29101ce3dde10019e1773c",
    "nonprofitSlug": "volunteers-of-america",
    "slug": "Ib4pnuQz8a5zXCp",
    "status": "IN_PROGRESS"
    "Finance": {
        "budgetFile": {
            "value": {
                "name": "filename",
                "url": "file.pdf"
            }
        }
    },
    "percentComplete": 10.0,
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/<form_type>/<nonprofit_slug>/<slug>/<form_name>/upload', methods=['POST'])
@require_nonprofit_permission
def upload_survey_file_dispatch(form_type, nonprofit_slug, slug, form_name):
    if not check_nonprofit_permission(nonprofit_slug):
        raise GivewithError('Insufficient permission. User does not have the same nonprofit org id', code=403)

    result = upload_survey_file(form_type.upper(), nonprofit_slug, slug, form_name)
    return jsonify(result)


"""
@api {delete} /:form_type/:nonprofit_slug/:slug/:form_name/:file_name Delete File from Form
@apiName DeleteFileFromForm
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription deletes files from nonprofit form

@apiParam {String=PFF,PCF,PSF} form_type the nonprofit form type
@apiParam {String} nonprofit_slug the nonprofit slug/unique identifier
@apiParam {String} slug the form slug/unique identifier
@apiParam {String} form_name the form section to delete file from
@apiParam {String} file_name the filename of the file to be deleted

@apiParamExample {json} request example:
{
    "path": "budgetFile.value"
}

@apiSuccessExample {json} response example:
{
    "_id": "5e2f0eaba83264bd927c5b41",
    "editing": true,
    "name": "testing UK",
    "nonprofit": "5b29101ce3dde10019e1773c",
    "nonprofitSlug": "volunteers-of-america",
    "slug": "Ib4pnuQz8a5zXCp",
    "status": "IN_PROGRESS"
    "Finance": {
        "budgetFile": {
            "value": ''
        }
    },
    "percentComplete": 8.0,
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/<form_type>/<nonprofit_slug>/<slug>/<form_name>/<file_name>', methods=['DELETE'])
@require_nonprofit_permission
def delete_survey_file_dispatch(form_type, nonprofit_slug, slug, form_name, file_name):
    if not check_nonprofit_permission(nonprofit_slug):
        raise GivewithError('Insufficient permission. User does not have the same nonprofit org id', code=403)

    result = delete_survey_file(form_type.upper(), nonprofit_slug, slug, form_name, file_name)
    return jsonify(result)


"""
@api {get} /vocabulary/v2 Get Form Vocabulary
@apiName GetFormVocabulary
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription get vocabulary for nonprofit form

@apiSuccessExample {json} response example:
{
    "animalHabitats": [
        {
            "_id": "5d44b3b4d5b3a55e9e513d26",
            "label": "Both land and water",
            "versions": [2]
        },
        {
            "_id": "5d44b3b4d5b3a55e9e513d24",
            "label": "Land",
            "versions": [2]
        }
    ],
    "approach": [
        {
            "_id": "5d44b3b4d5b3a55e9e513cfa",
            "category": "participant",
            "causeId": "5d44b3b4d5b3a55e9e513ccf",
            "label": "Create access to resources and/or public benefits",
            "value": 23750,
            "versions": [2]
        },
        {
        "_id": "5d44b3b4d5b3a55e9e513cfb",
        "category": "participant",
        "causeId": "5d44b3b4d5b3a55e9e513cce",
        "label": "Create policy change",
        "value": 0,
        "versions": [2]
        }
    ]
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/vocabulary/v2', methods=['GET'])
@require_nonprofit_permission
def list_vocabulary_v2_dispatch():
    result = get_transformed_vocabulary()
    return jsonify(result)


"""
@api {get} /locations Get Form Location Data
@apiName GetFormLocations
@apiGroup Nonprofit-Form
@apiVersion 0.1.0
@apiPermission client
@apiDescription get location data for nonprofit form

@apiSuccessExample {json} response example:
{
    "countries": {
        "Africa": [
            {"name": "Algeria"},
            {"name": "Angola"}
        ]
    },
    "cities": {
        "Afghanistan": [
            {"name": "Baghdad"},
            {"name": "Kabul"}
        ]
    },
    "continents": [
        {"name": "Africa"},
        {"name": "Europe"}
    ]
}

@apiError 403 Insufficient permissions
@apiError 400 Bad request
"""
@survey_bp.route('/locations', methods=['GET'])
@require_nonprofit_permission
def get_locations():
    location_data = get_location_data()
    return jsonify(location_data.get('locationTree'))


def get_survey_data(form_type, nonprofit_slug, slug):
    document = get_survey_by_slug(form_type, nonprofit_slug, slug)

    if not document:
        entity_name = entity_names.get(form_type)
        raise EntityNotFound(entity_name, slug)

    if form_type in ['PFF', 'PCF']:
        funding = get_associated_deal_funding(document)
        document.update(funding)

        if to_bool(request.args.get('isReview')):
            review_fields = get_review_fields(document, funding)
            document.update(review_fields)

    if form_type == 'PFF':
        if to_bool(request.args.get('isWelcome')):
            welcome_fields = pff_get_welcome_fields(document)
            document.update(welcome_fields)

    progress, incomplete_fields = calculate_progress(form_type, document)
    document['progress'] = progress
    document['incompleteFields'] = incomplete_fields

    document['optionals'] = get_optionals(form_type, document)

    return document


def update_survey_data(form_type, nonprofit_slug, slug, form_name):
    document = request.get_json()

    if not document:
        raise UnsupportedPayload(None)

    db_document = get_survey_by_slug(form_type, nonprofit_slug, slug)
    if 'name' in document.keys():
        internalProgramName = document['name']['internalProgramName']
        platformProgramName = document['name']['platformProgramName']
        internalProgramName_exists = db().coll_surveys.find_one({'General.name.internalProgramName':internalProgramName })
        platformProgramName_exists = db().coll_surveys.find_one({'General.name.platformProgramName':platformProgramName })
        if internalProgramName_exists:
            raise GivewithError('A program with the same Internal program name already exists',code=409)
        if platformProgramName_exists:
            raise GivewithError('A program with the same Platform program name already exists',code=409)
    if not db_document:
        entity_name = entity_names.get(form_type)
        raise EntityNotFound(entity_name, slug)

    if not db_document.get('editing'):
        raise GivewithError('Editing is disabled on this form', code=400)

    validate(form_type, form_name, document)

    if form_type in ['PFF', 'PCF']:
        document = normalize(form_type, form_name, document)

    db_document.setdefault(form_name, {}).update(document)

    updated_document = save_survey(form_type, db_document)
    return updated_document


def submit_signature(form_type, nonprofit_slug, slug):
    if form_type != 'PFF':
        raise GivewithError('only a PFF can be signed')

    document = request.get_json()
    if not document:
        raise UnsupportedPayload()

    v.validate(document, schema_funding_form_client)
    if v.errors:
        raise InvalidPayload(v.errors)

    db_document = get_survey_by_slug(form_type, nonprofit_slug, slug)

    if not db_document:
        entity_name = entity_names.get(form_type)
        raise EntityNotFound(entity_name, slug)

    progress, incomplete_fields = calculate_progress(form_type, db_document)

    if calculate_percent_complete(progress) < 100:
        raise GivewithError('Cannot sign a partially filled form')

    if db_document.get('status') != str(SurveyStatus.APPROVED):
        raise GivewithError('Cannot sign a form that isn\'t approved')

    document = {
        '_id': db_document['_id'], # for lookup purposes only
        'status': str(SurveyStatus.EXECUTED),
        'signature': {
            **document['signature'],
            'date': datetime.utcnow()
        }
    }

    updated_document = update_survey(form_type, set_last_updated(document))

    send_loggly(
        f'NONPROFIT-{form_type}: SUBMIT SIGNATURE ON FORM WITH ID: {db_document.get("_id")} '
        f'BY USER WITH ID: {request.user.get("_id")}'
    )

    updated_document['incompleteFields'] = incomplete_fields

    return updated_document


def submit_survey(form_type, nonprofit_slug, slug):
    db_document = get_survey_by_slug(form_type, nonprofit_slug, slug)

    if not db_document:
        entity_name = entity_names.get(form_type)
        raise EntityNotFound(entity_name, slug)

    progress, incomplete_fields = calculate_progress(form_type, db_document)

    if calculate_percent_complete(progress) < 100:
        raise GivewithError('Cannot submit a partially filled form')

    if not db_document.get('editing'):
        raise GivewithError('Editing is disabled on this form', code=400)

    # if program associated with survey, deactivate program on submit
    program_id = db_document.get('programId')
    if form_type == 'PSF' and program_id:
        program_updates = {'active': False}
        updated_program = db().coll_programs.find_one_and_update(filter={'_id': ObjectId(program_id)},
                                                                 update={'$set': set_last_updated(program_updates)},
                                                                 return_document=ReturnDocument.AFTER)
        if not updated_program:
            send_loggly(
                f'NONPROFIT-{form_type}: ERROR UPDATING ASSOCIATED PROGRAM WITH ID: {program_id} '
                f'ON SUBMIT FORM WITH ID: {db_document.get("_id")} '
                f'BY USER WITH ID: {request.user.get("_id")}'
            )

    if form_type == 'PCF':
        document = request.get_json()
        if not document:
            raise UnsupportedPayload()

        v.validate(document, schema_completion_form_client)
        if v.errors:
            raise InvalidPayload(v.errors)

        updates = {
            'signature': {
                **document['signature'],
                'date': datetime.utcnow()
            }
        }
        db_document.update(updates)

    db_document['editing'] = False
    db_document['status'] = str(SurveyStatus.SUBMITTED)

    updated_document = save_survey(form_type, db_document, progress)

    if updated_document:
        send_loggly(
            f'NONPROFIT-{form_type}: FORM WITH ID: {db_document.get("_id")} SUBMITTED '
            f'BY USER WITH ID: {request.user.get("_id")}'
        )

        try:
            user = request.user
            slack_obj = {
                'id': str(updated_document.get('_id')),
                'form name': updated_document.get('submissionFormName') or updated_document.get('name'),
                'by': user.get('first_name') + ' ' + user.get('last_name')
            }
            send_si_platform_message(True, f'{form_type} submitted', slack_obj)
        except Exception as slack_error:
            send_loggly(
                f'NONPROFIT-{form_type}: ERROR SENDING SLACK MESSAGE: {slack_error} '
                f'ON SUBMIT FORM WITH ID: {db_document.get("_id")} '
                f'BY USER WITH ID: {request.user.get("_id")}'
            )

    updated_document['nonprofit'] = get_nonprofit_by_id(updated_document.get('nonprofit'), projection={'mpa.effectiveDate': True})
    updated_document['incompleteFields'] = incomplete_fields

    return updated_document


def upload_survey_file(form_type, nonprofit_slug, slug, form_name):
    if 'file' not in request.files:
        raise UnsupportedPayload()

    file = request.files['file']

    if 'path' not in request.form:
        raise UnsupportedPayload()

    fields = request.form['path'].split('.')

    if len(fields) != 2:
        raise GivewithError('Attribute \'path\' has wrong format')

    db_document = get_survey_by_slug(form_type, nonprofit_slug, slug)
    entity_name = entity_names.get(form_type)

    if not db_document:
        raise EntityNotFound(entity_name, slug)

    if not db_document.get('editing'):
        raise GivewithError('Editing is disabled on this form', code=400)

    # Makes sure each level of the file path is secure in case they're attached to user input
    # any point
    file_path = '/'.join([secure_filename(x) for x in (entity_name, slug, file.filename)])
    url = upload_file(file, file_path)

    document = {
        fields[0]: {
            fields[1]: {'name': file.filename, 'url': url}
        }
    }

    db_document.setdefault(form_name, {}).update(document)

    updated_document = save_survey(form_type, db_document)
    return updated_document


def delete_survey_file(form_type, nonprofit_slug, slug, form_name, file_name):
    payload = request.get_json()

    if not payload or not file_name:
        raise UnsupportedPayload(None)

    if 'path' not in payload:
        raise UnsupportedPayload()

    db_document = get_survey_by_slug(form_type, nonprofit_slug, slug)
    entity_name = entity_names.get(form_type)

    if not db_document:
        raise EntityNotFound(entity_name, slug)

    if not db_document.get('editing'):
        raise GivewithError('Editing is disabled on this form', code=400)

    if not delete_file(entity_name, slug, file_name):
        raise GivewithError(f'Unable to delete {file_name}')

    path = payload['path']

    pop_descendant_key(db_document.get(form_name, {}), path, None, 0)

    updated_document = save_survey(form_type, db_document)

    set_descendant_key('', updated_document.get(form_name, {}), path)

    return updated_document


def save_survey(form_type, document, progress=None):
    incomplete_fields = {}
    if progress is None:
        progress, incomplete_fields = calculate_progress(form_type, document)

    # remove answers to questions no longer relevant
    remove_stale_fields(form_type, document)

    document['percentComplete'] = calculate_percent_complete(progress)
    updated_document = update_survey(form_type, set_last_updated(document))

    updated_document['progress'] = progress
    updated_document['optionals'] = get_optionals(form_type, document)

    if form_type in ['PFF', 'PCF']:
        funding = get_associated_deal_funding(updated_document)
        updated_document.update(funding)

    updated_document['incompleteFields'] = incomplete_fields
    return updated_document


def validate(form_type, form_name, data):
    schema = form_models[form_type]()

    v.validate({form_name: data}, schema)
    if v.errors:
        raise InvalidPayload(v.errors)


def normalize(form_type, form_name, data):
    schema = form_models[form_type](is_normalization=True)

    document = v.normalized({form_name: data}, schema)[form_name]
    if v.errors:
        raise ValidationError(v.errors, code=400)

    return document


def remove_stale_fields(form_type, document):
    # if a field is no longer relevant, remove the answers from the document
    dependencies = get_dependencies(form_type, document)

    for key, value in get_survey_metadata().get('questionDependencies', {}).items():
        # key can either not exist, be False, or be True -> pop when key doesn't exist or is False
        if dependencies.get(key, False) is False:
            path = value['path']
            send_loggly(
                f'NONPROFIT-{form_type}: {path} IMPLICITLY REMOVED '
                f'FROM FORM WITH ID {document.get("_id")} ON EDIT '
                f'BY USER WITH ID {request.user.get("_id")}'
            )
            pop_descendant_key(document, path, default_value=None, pop_level=1)


def get_transformed_vocabulary():
    survey_vocabulary = [
        'animalHabitats', 'audience', 'studyEvidenceType',
        'studyDesignType', 'researchDataType', 'effect', 'approach',
        'impact', 'strength', 'programApproach', 'approachDuration',
        'dataMeasurement', 'causes'
    ]

    vocabulary = get_vocabulary(version='2', types_query={'type': {'$in': survey_vocabulary}})

    survey_meta = get_survey_metadata()

    # Append tooltips from survey_data
    for key, vocabulary_ext in survey_meta.get('vocabularyExtensions', {}).items():
        vocabulary_items = vocabulary.get(key, [])

        for item in vocabulary_items:
            item_id = str(item.get('_id'))
            extensions = vocabulary_ext.get(item_id, {})
            extensions.pop('label', None) # so as to not overwrite existing label key
            item.update(extensions)

    # append dependencies to vocabulary
    vocabulary['dependencies'] = survey_meta.get('questionDependencies')

    # add SCC Conversions to vocabulary for PSF
    scc_conversion = list(db().coll_program_scc_conversion.find())
    for item in scc_conversion:
        item['label'] = item['name']
    vocabulary['sccConversion'] = scc_conversion

    return vocabulary

def calculate_progress(form_type, document):
    model = form_models[form_type]
    schema = model(set_required=True, set_empty=False, dependencies=get_dependencies(form_type, document))

    # build progress dictionary
    progress = {}

    # incomplete_fields includes all the paths for which the field is not filled/empty
    incomplete_fields = {}

    for form_key, fields in schema.items():

        count = 0
        for field_name, attributes in fields.get('schema', {}).items():

            # fields with custom validations are required if custom validator fails for the field
            has_error = False
            def validation_error(*_):
                nonlocal has_error
                has_error = True

            # if validator exist for the field, call validator, if error, validation_error function should run
            if 'validator' in attributes:
                attributes['validator']('_', document.get(form_key, {}).get(field_name, {}), validation_error)

            if attributes.get('required') or has_error:
                count += 1

        progress[form_key] = {
            'complete': 0,
            'total': count
        }

        incomplete_fields[form_key] = []


    if document:
        _v = GivewithValidator(allow_unknown=True)
        _v.validate(document, schema)

        for key in progress:

            error_fields = _v.errors.get(key)
            required_count = progress[key]['total']
            error_count = 0

            if error_fields:
                error_list = error_fields[0]
                if isinstance(error_list, dict):
                    error_count = len(error_list)
                else: # field doesn't exist at all
                    error_count = required_count

            progress[key]['complete'] = max(progress[key]['total'] - error_count, 0)

            if error_fields:
                error_list = error_fields[0]

                if isinstance(error_list, dict):
                    for error_key in error_list:
                        path = error_key
                        nested_error_list = error_list[error_key][0]

                        if isinstance(nested_error_list, dict):
                            for dict_key in nested_error_list:
                                path = path + '.' + dict_key

                        incomplete_fields[key].append(path)
                else:
                    incomplete_fields[key] = 'empty'

    return (progress, incomplete_fields)


def get_optionals(form_type, document):
    """ Return a dictionary describing form keys that are optional """
    optionals = {}

    # itemization optional if USD_funding < min_funding_amount
    if form_type in ['PFF', 'PCF']:
        _, usd_funding_amount = get_associated_funding_amount(document)
        if usd_funding_amount < MIN_FUNDING_AMOUNT:
            optionals['itemization'] = True

    return optionals


def get_dependencies(form_type, document):
    question_dependencies = get_survey_metadata().get('questionDependencies', {})
    dependencies = {}

    # require itemization for PFF if funding_amount >= MIN_FUNDING (with currency conversion)
    if form_type in ['PFF', 'PCF']:
        funding_amount, usd_funding_amount = get_associated_funding_amount(document)

        dependencies['fundingAmount'] = funding_amount

        if usd_funding_amount >= MIN_FUNDING_AMOUNT:
            dependencies['itemization'] = True

    # build a dict to set dependent keys to True if the value is filled out
    # and matches the values
    for key, dependency_dict in question_dependencies.items():
        for key_item in dependency_dict.get('keys', []):
            form_value = get_descendant_key(document, key_item.get('key'), {}).get('selected', [])

            # operation specifies what operation to run for that set of keys
            # in: any of the form_values is in values, nin: none of the form_values are in values
            operation = dependency_dict.get('operation')
            for item in form_value:
                if item in dependency_dict.get('values', {}):
                    dependencies[key] = (not operation == 'nin') # False if operation == 'nin' else True
                elif operation == 'nin':
                    dependencies[key] = dependencies.get(key) is not False

    return dependencies


def calculate_percent_complete(progress):
    complete = total = 0
    for value in progress.values():
        complete += value.get('complete', 0)
        total += value.get('total', 0)

    return (complete / total) * 100


def pff_get_welcome_fields(document):
    """ Gets extra fields required for welcome page """
    result = {}

    admin_user = get_user(document.get('givewithAdmin'), projection={'username': True})
    result['givewithManagerEmail'] = admin_user and admin_user.get('username')

    names_dict = get_gw_customer_and_client_names(document)
    result.update(names_dict)

    program = get_program_by_id(document.get('program'), projection={'General.name': True, 'name': True})
    result['programName'] = get_descendant_key(program, 'General.name.internalProgramName', None) or program['name']

    return result


def get_review_fields(document, funding):
    result = {}

    nonprofit_fields = {
        'name': True, 'general.location.generalLocation': True, 'general.location.specificLocation': True,
        'general.name.legalOrganizationName': True, 'general.location.charityNumber': True,
        'general.location.companyHouseNumber': True, 'mpa.effectiveDate': True
    }
    result['nonprofit'] = get_nonprofit_by_id(document.get('nonprofit'), projection=nonprofit_fields)

    program = get_program_by_id(document.get('program'), projection={
        'budget': True, 'currency': True, 'outputs': True
    })

    # calculate fundingPerBudget for Outputs
    program_currency = program.get('currency') or str(Currency.USD)
    funding_currency = funding.get('currency') or str(Currency.USD)
    funding_amount = funding.get('fundingAmount', 0)
    program_budget = program.get('budget', 0)

    if program_currency != funding_currency:
        funding_amount = convert_to_usd(funding_amount, funding_currency)
        program_budget = convert_to_usd(program_budget, program_currency)

    result['fundingPerBudget'] = funding_amount / program_budget
    result['programOutputsLookup'] = {output.get('description', '').strip().lower() :
                                      expand_vocabulary_label(output, version=2)
                                      for output in program.get('outputs', [])}

    admin_email = get_user(ObjectId(document['givewithAdmin']), projection={'username': True}).get('username')
    result['givewithAdminEmail'] = admin_email

    return result


def get_associated_deal_funding(document):
    """ Gets Funding amount dictionary of PFF (includes currency and fundingAmount) """
    deal = get_deal(document.get('deal'), projection={'currency': True, 'fundingAmount': True, '_id': False})
    return deal


def get_associated_funding_amount(document):
    funding_dict = get_associated_deal_funding(document)

    funding_amount = funding_dict.get('fundingAmount', 0)
    funding_currency = funding_dict.get('currency', str(Currency.USD))

    return funding_amount, convert_to_usd(funding_amount, funding_currency)


def check_nonprofit_permission(nonprofit_slug):
    claims = jwt.decode(request.headers['authorization'], verify=False)

    if claims['scope'] == 'psf':
        resource_ids = claims.get('resource_ids', [])
        nonprofit = db().coll_nonprofits.find_one({'slug': nonprofit_slug})
        if nonprofit is not None:
            return str(nonprofit.get('_id', '')) in resource_ids

    return True
