source /home/ec2-user/.bashrc
source /home/ec2-user/.envs
echo $VARIABLES_VERSION > /tmp/variables_version

cd /home/ec2-user/dist
chown ec2-user /var/log/gunicorn
su ec2-user -c '/usr/local/bin/gunicorn -w 2 --access-logfile - --capture-output --log-file /var/log/gunicorn --log-level=debug -b :7000 -t 600 flask_app:app --daemon'
