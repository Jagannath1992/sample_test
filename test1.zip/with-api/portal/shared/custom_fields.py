from bson import ObjectId
from bson.errors import InvalidId
from click import DateTime
from marshmallow import ValidationError, fields as m_fields
from flask_restx import fields as fr_fields
from flask_accepts import utils

from portal.shared.dates import get_formatted_utc_string


class LoweredString(m_fields.String):
    def _deserialize(self, value, attr, data, **kwargs):
        if hasattr(value, 'lower'):
            value = value.lower()
        return super()._deserialize(value, attr, data, **kwargs)


utils.type_map[LoweredString] = utils.make_type_mapper(fr_fields.String)


class ObjectIdField(m_fields.Field):
    def _serialize(self, value: ObjectId, attr, obj, **kwargs):
        return str(value)

    def _deserialize(self, value: str, attr, data, **kwargs):
        try:
            return ObjectId(value)
        except InvalidId as error:
            raise ValidationError("Invalid ObjectId supplied") from error


utils.type_map[ObjectIdField] = utils.make_type_mapper(fr_fields.String)


class FormattedDateTimeField(m_fields.DateTime):
    def _serialize(self, value: DateTime, attr, obj, **kwargs):
        if value:
            return get_formatted_utc_string(value)


utils.type_map[FormattedDateTimeField] = utils.make_type_mapper(fr_fields.String)


class OptionalUrl(m_fields.Url):
    def _deserialize(self, value, attr, data, **kwargs):
        if not value:
            value = ""
        return super()._deserialize(value, attr, data, **kwargs)

    def _validate(self, value):
        if value:
            super()._validate(value)


utils.type_map[OptionalUrl] = utils.make_type_mapper(fr_fields.Url)
