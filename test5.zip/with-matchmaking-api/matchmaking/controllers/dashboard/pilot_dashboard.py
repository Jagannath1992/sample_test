from tempfile import TemporaryFile

from flask import request, send_file, jsonify
from werkzeug.utils import secure_filename
from pymongo import DESCENDING

from matchmaking.permission_decorator import require_client_permission
from matchmaking.controllers import dash_bp
from matchmaking.dao.utils import get_document_by_id, get_documents_cursor
from matchmaking.s3 import download_file
from matchmaking.models.models import Currency


@dash_bp.route('/pilot/home', methods=['GET'])
@require_client_permission
def list_proposals_dispatch():
    """PILOT: List Proposals
    """
    user = request.user
    brand_id = user['orgId']
    result = filter_proposals_by_test_flag(brand_id, user)
    return jsonify(result)


@dash_bp.route('/pilot/summary_doc', methods=['GET'])
@require_client_permission
def download_summary_doc_dispatch():
    """Download brand summary doc or custom Summary Doc
    """
    brand_id = request.user['orgId']
    return download_summary_doc(brand_id)


def filter_proposals_by_test_flag(brand_id, user):
    def _transform(proposal):
        selected_program = get_document_by_id('mm_programs', proposal.get('selectedProgram'), projection=['name'])
        owner = get_document_by_id('user', proposal.get('givewithCustomerUser'), projection=['name'])
        partner = get_document_by_id('mm_brands', proposal.get('client'), projection=['name', 'nameLabel'])

        deal_query = {
            '_id': proposal.get('_id'),
            'slug': proposal.get('slug'),
            'program': selected_program,
            'name': proposal.get('name', ''),
            'currency': proposal.get('currency', str(Currency.USD)),
            'givewithPortion': proposal.get('givewithPortion', 0),
            'owner': owner.get('name', '') if owner else '',
            'status': proposal.get('status'),
            'partnerBrand': (partner.get('nameLabel') or partner.get('name', '')) if partner else '-',
            'paymentStatus': proposal.get('paymentStatus', ''),
            'createdAt': proposal.get('createdAt', ''),
            'type': proposal.get('sourcingEventType', ''),
            'category': proposal.get('category', ''),
            'department': proposal.get('department', '')
        }

        return deal_query

    query = {'givewithCustomer': brand_id, 'archived': {'$ne': True}, 'type': 'enterprise'}
    if user['type'].lower() != 'admin':
        query['isTest'] = False

    documents = get_documents_cursor('deals', query).sort('createdAt', DESCENDING)

    return list(map(_transform, documents))


def download_summary_doc(brand_id):
    summary_doc = get_document_by_id(
        'mm_brands', brand_id, projection=['customWrittenSummary']
    ).get('customWrittenSummary')

    if summary_doc:
        attachment_filename, url = summary_doc.get('name'), summary_doc.get('url')
        filename = url.rsplit('/', 1)[0] + '/' + secure_filename(url.rsplit('/', 1)[-1])
    else:
        filename = 'globals/Sourcing_Written_Summary.docx'
        attachment_filename = 'Sourcing_Written_Summary.docx'

    file = TemporaryFile()
    download_file(filename, file)
    response = send_file(file, as_attachment=True, attachment_filename=attachment_filename, cache_timeout=0)

    return response
