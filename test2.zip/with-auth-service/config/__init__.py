import os
import yaml

from app.s3 import download_file

config_dir = 'config/'


def init_config(app):
    env = os.environ.get('FLASK_ENV', 'local').lower()
    with open(config_dir + env + '.yml', 'r') as stream:
        app.config['config'] = yaml.safe_load(stream)
        
    if env == 'prod' or env == 'sandbox':
        app.config['config']['db']['mongodb']['uri'] = os.environ.get('MONGO_URL', '')

    elif env == 'docker':
        app.config['config']['db']['mongodb']['uri'] = "mongodb://gw_mongo_local:27017/givewith-local"

    elif env == 'development':
        url = os.environ.get('MONGO_URL', '')
        if url:
            app.config['config']['db']['mongodb']['uri'] = url

    # store saml credentials
    credential_config = app.config['config']['saml']['credentials']

    try:
        app.config['certificate'] = download_file(credential_config['bucket'], credential_config['certificate'])
        app.config['csr'] = download_file(credential_config['bucket'], credential_config['csr'])
        app.config['private_key'] = download_file(credential_config['bucket'], credential_config['private_key'])
    except RuntimeError:
        pass
