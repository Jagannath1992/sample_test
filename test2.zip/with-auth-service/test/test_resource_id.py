import json
import jwt
from bson import ObjectId


def test_resource_id(client, db, header):
    random_id = ObjectId()
    update_result = db.user.update_one({'username': 'shanyan.jiang+delta@givewith.com'},
                                       {'$set': {'type': 'admin', 'orgId': random_id}})

    assert update_result.matched_count == 1
    assert update_result.modified_count == 1

    # test resource id in token
    payload = {
        "grantType": "password",
        "username": "shanyan.jiang+delta@givewith.com",
        "password": "TestPassword123",
        "scope": 'admin'
    }

    response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
    assert response.status_code == 200

    result = json.loads(response.data.decode())
    token = result.get('token')
    refresh_token = result.get('refresh_token')

    token_payload = jwt.decode(token, verify=False)
    assert token_payload.get('resource_ids')[0] == str(random_id)

    # test resource id in new token
    payload = {
        "grantType": "refresh_token",
        "refresh_token": refresh_token,
    }

    response = client.post('/v1/authorize', data=json.dumps(payload), headers=header)
    assert response.status_code == 200

    result = json.loads(response.data.decode())
    new_token = result.get('access_token')

    new_token_payload = jwt.decode(new_token, verify=False)
    assert new_token_payload.get('resource_ids')[0] == str(random_id)
