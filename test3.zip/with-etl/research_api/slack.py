import requests
import os
import sys
from json import dumps
from os import environ, path
import socket

# getting the name of the directory
# where the this file is present.
current = os.path.dirname(os.path.realpath(__file__))
 
# Getting the parent directory name
# where the current directory is present.
parent = os.path.dirname(current)
 
# adding the parent directory to
# the sys.path.
sys.path.append(parent)

# THIS IMPORT FROM PARENT DIRECTORY, ABOVE 3 LINES OF CODE IS IMPORTANT
import constants

def get_text_block(text):
    return {
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    'text': HOST_NAME + ": "+ text,
                },
            },
        ]
    }

ENABLE_SLACK_ALERTS = environ.get(constants.ENABLE_SLACK_ALERTS)
HOST_NAME = socket.gethostname()

class SimianSlack:
    simian_channel_web_hook = environ.get(constants.AIRFLOW_ALERTS_SLACK_URL)
    header = {'Content-Type': 'application/json'}

    def send_text(self, text):
        if ENABLE_SLACK_ALERTS != 'true':
            return

        data = get_text_block(text)
        return requests.post(self.simian_channel_web_hook, data=dumps(data), headers=self.header)

    def send_success_message(self, items):
        if ENABLE_SLACK_ALERTS != 'true':
            return

        text = '*List of valid items:*\n\n'
        for item in items:
            title = item.get('title')
            text = f'{ text }\n*{ title }* processed successfully.'

        data = get_text_block(text)

        return requests.post(self.simian_channel_web_hook, data=dumps(data), headers=self.header)

    def send_invalid_item(self, item):
        if ENABLE_SLACK_ALERTS != 'true':
            return

        title = item.get('title')
        media = item.get('media')
        thumbnail = item.get('thumbnail')
        text = f'*{ title }*\nmedia url: { media }\n thumbnail url: { thumbnail }'

        nonprofit_name = item.get('nonprofit_name')
        if nonprofit_name:
            text = f'{ text }\ninvalid nonprofit name: { nonprofit_name }'

        program_name = item.get('program_name')
        if program_name:
            text = f'{ text}\ninvalid program name: { program_name }'

        data = get_text_block(text)

        return requests.post(self.simian_channel_web_hook, data=dumps(data), headers=self.header)