import json

def test_root(client):
    response = client.get("/")
    assert response.status_code == 200

    result = json.loads(response.data.decode())
    assert "status" in result
    assert result["status"] == "ok"
