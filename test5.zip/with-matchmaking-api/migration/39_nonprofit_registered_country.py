from matchmaking import db

db().coll_nonprofits.update_many({}, {'$set': {'registeredCountry': ""}})
