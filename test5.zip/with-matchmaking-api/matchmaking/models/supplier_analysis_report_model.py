from matchmaking.models.models import type_object_id, to_object_id, to_bool

db_schema = {
    '_id': {'type': type_object_id, 'readonly': True},
    'name': {'type': 'string'},
    'category': {'type': 'string'},
    'password': {'type': 'string', 'readonly': True},
    'slug': {'type': 'string', 'readonly': True},
    'customerStatus': {'type': 'boolean', 'coerce': to_bool},
    'notes': {'type': 'string'},
    'brandId': {'type': type_object_id, 'coerce': to_object_id},
    'suppliers': {'type': 'list', 'schema': {'type': type_object_id, 'coerce': to_object_id}}
}

post_schema = {
    'name': {'type': 'string'},
    'category': {'type': 'string'},
    'customerStatus': {'type': 'boolean'},
    'notes': {'type': 'string'},
    'brandId': {'type': type_object_id, 'required': True},
    'suppliers': {'type': 'list', 'schema': {'type': type_object_id}}
}

patch_schema_admin = {
    'name': {'type': 'string'},
    'category': {'type': 'string'},
    'customerStatus': {'type': 'boolean'},
    'notes': {'type': 'string'},
    'suppliers': {'type': 'list', 'schema': {'type': type_object_id}}
}

patch_schema_client = {
    'name': {'type': 'string'},
    'category': {'type': 'string'},
    'suppliers': {'type': 'list', 'schema': {'type': type_object_id}}
}
