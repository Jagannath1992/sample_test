# -*- coding: utf-8 -*-
import re

from bson import ObjectId

from .mongodb import db

score_map = {
    'researchType': {
        'research validated': 10,
        'evidence based': 10,
        'generally accepted': 5
    },
    'dataMeasurement': {
        'quantitatively': 10
    },
    'programApproach': {
        'changing behavior (train; mentor)': 10,
        'building capacity (strengthen institutions, programs or systems)': 10,
        'increasing awareness (advocate; lobby)': 5,
        'research': 5,
    }
}


def get_score_map_key(value):
    if type(value) == ObjectId:
        value = db().map_id_to_label.get(value, "").lower()
    elif re.match(r'^(?=[a-f\d]{24}$)(\d+[a-f]|[a-f]+\d)', value):
        value = db().map_id_to_label.get(ObjectId(value), "").lower()
    return value


def rule_secondary_impacts(program, *args, **kw):
    score = 0
    if program.get('secondaryImpacts', []):
        score = 5
    return score


def rule_interventions(program, *args, **kw):
    score = 0
    interventions = program.get('interventions', [])
    if interventions is not None and len(interventions) > 1:
        score = 5
    return score


def rule_one_or_more_partner_organizations(program, *args, **kw):
    score = 0
    if program.get('oneOrMorePartnerOrganizations', False):
        score = 5
    return score


def rule_audience_age(program, *args, **kw):
    score = 0
    if program.get('audienceAge', []):
        score = 5
    return score


def rule_audience_gender(program, *args, **kw):
    score = 0
    if program.get('audienceGender', []):
        score = 5
    return score


def rule_audience_attributes(program, *args, **kw):
    score = 0
    if program.get('audienceAttribute', []):
        score = 5
    return score


def rule_audience_attributes_parent_guardians(program, *args, **kw):
    score = 5
    value = program.get('audienceAttribute', [])
    if not value or (len(value) == 1 and get_score_map_key(value[0]) == 'parents/guardians'):
        score = 0
    return score


def rule_program_density(program, *args, **kw):
    score = 0
    if not program.get('programDensity', True):
        score = 5
    return score


def rule_primary_outcome_effectiveness(program, *args, **kw):
    score = 0
    value = program.get('primaryOutcomeEffectiveness')
    if value:
        score = score_map['researchType'].get(get_score_map_key(value), 0)
    return score


def rule_data_measurement_type(program, *args, **kw):
    score = 0
    value = program.get('dataMeasurementType')
    if value:
        score = score_map['dataMeasurement'].get(get_score_map_key(value), 0)
    return score


def rule_program_activity_effectiveness(program, *args, **kw):
    score = 0
    value = program.get('programActivityEffectiveness')
    if value:
        score = score_map['researchType'].get(get_score_map_key(value), 0)
    return score


def rule_effectiveness_rating(program, *args, **kw):
    score = 0

    settings = kw.get('settings', None)
    if not settings:
        settings = db().coll_settings.find_one()

    effectiveness_rating = float(program.get('effectivenessRating', 0))
    if effectiveness_rating > settings['scoringSettings']['minimumHigh']:
        score = 10
    elif effectiveness_rating >= settings['scoringSettings']['maximumLow']:
        score = 5
    return score


def rule_program_approach(program, *args, **kw):
    score = 0
    values = program.get('programApproach')
    if values:
        if type(values) != list:
            values = [values]
        score = max(score_map['programApproach'].get(get_score_map_key(v), 0) for v in values)
    return score


def rule_is_ongoing_program(program, *args, **kw):
    score = 0
    if program.get('isOngoingProgram', False):
        score = 10
    return score


def rule_partner_value(program, *args, **kw):
    score = 0
    if program.get('partnerValue', False):
        score = 10
    return score
