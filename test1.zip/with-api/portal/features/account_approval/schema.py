
from marshmallow import fields, validates, ValidationError

from portal.shared.repositories import account_repository
from portal.shared.schema import EntitySchema, ApprovalLevelSchema


class AccountApprovalSchema(EntitySchema):
    """Account Approval Schema is 1:1 with Account"""
    levels = fields.List(fields.Nested(ApprovalLevelSchema), required=True)


class AccountApprovalRequest(AccountApprovalSchema):

    @validates('id')
    def validate_relations(self, value):
        if not account_repository().exists(value):
            raise ValidationError('Account does not exist')


class AccountApprovalResponse(AccountApprovalSchema):
    pass
