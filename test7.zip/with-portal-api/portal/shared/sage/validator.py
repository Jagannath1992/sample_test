from typing import List

from portal.shared.errors import GivewithError
from portal.shared.sage.models import SageBill, SageInvoice


class SageValidator:
    '''
    Validators for SAGE APIs 
    Create Invoice and Bill
    '''

    def validate_create_invoice(self, invoice: SageInvoice) -> List[GivewithError]:
        errors = list()
        
        if not invoice.customerid :
            errors.append(GivewithError(9100, "customerid is required"))
        if not invoice.datecreated:
            errors.append(GivewithError(9101, "datecreated is required"))
        if not invoice.datedue:
            errors.append(GivewithError(9102, "datedue is required"))
        if not invoice.exchratetype:
            errors.append(GivewithError(9103, "exchratetype is required"))
        if not invoice.exchratedate:
            errors.append(GivewithError(9104, "exchratedate is required"))
        if not invoice.basecurr:
            errors.append(GivewithError(9105, "basecurr is required"))
        if not invoice.currency:
            errors.append(GivewithError(9106, "currency is required"))

        if not invoice.invoiceitems:
            errors.append(GivewithError(9150, "invoiceitems is required"))
        elif not invoice.invoiceitems.lineitem or len(invoice.invoiceitems.lineitem) < 1:
            errors.append(GivewithError(9151, "At least one lineitem is required"))
        else:
            for lineitem in invoice.invoiceitems.lineitem:
                if (not lineitem.accountlabel and not lineitem.glaccountno) or (lineitem.accountlabel and lineitem.glaccountno):
                    errors.append(GivewithError(9152, "Either accountlabel or glaccountno is required for lineitem"))

        return errors

    def validate_create_bill(self, bill: SageBill) -> List[GivewithError]:
        errors = list()

        if not bill.VENDORID:
            errors.append(GivewithError(9200, "VENDORID is required"))
        if not bill.RECORDID:
            errors.append(GivewithError(9201, "RECORDID (bill number) is required"))
        if not bill.CURRENCY:
            errors.append(GivewithError(9202, "CURRENCY is required"))
        if not bill.BASECURR:
            errors.append(GivewithError(9203, "BASECURR is required"))
        if not bill.WHENCREATED and bill.ACTION == 'Submit':
            errors.append(GivewithError(9204, "WHENCREATED is required"))
        if not bill.WHENDUE and bill.ACTION == 'Submit':
            errors.append(GivewithError(9204, "WHENDUE is required"))

        if not bill.APBILLITEMS:
            errors.append(GivewithError(9250, "APBILLITEMS is required"))
        elif not bill.APBILLITEMS.APBILLITEM or len(bill.APBILLITEMS.APBILLITEM) < 1:
            errors.append(GivewithError(9251, "At least one APBILLITEM is required"))
        else:
            for billitem in bill.APBILLITEMS.APBILLITEM:
                if not billitem.ACCOUNTNO:
                    errors.append(GivewithError(9252, "ACCOUNTNO is required for APBILLITEM"))
                if not billitem.DEPARTMENTID:
                    errors.append(GivewithError(9253, "DEPARTMENTID is required for APBILLITEM"))
                if not billitem.LOCATIONID:
                    errors.append(GivewithError(9254, "LOCATIONID is required for APBILLITEM"))

        return errors
