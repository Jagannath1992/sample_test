from re import RegexFlag
from bson import Regex, ObjectId
from portal.shared.enums import UserRole
from portal.shared.repositories import user_repository


class TestUserRepository:
    def test_domain_exists(self, fakers):
        existing = fakers.user.insert_single()
        user_repo = user_repository()

        assert user_repo.domain_exists(existing['username'])
        assert not user_repo.domain_exists('tester@doesntexist.com')

    def test_username_exists(self, fakers):
        # arrange
        user = fakers.user.insert_single()

        # act
        true_result = user_repository().username_exists(user['username'].upper())
        false_result = user_repository().username_exists('not_a_user')

        # assert
        assert true_result == True
        assert false_result == False

    def test_has_access(self, fakers):
        # arrange
        user = fakers.user.insert_single()

        # act
        true_result = user_repository().has_access(user['_id'], user['accountId'])
        false_result = user_repository().has_access(user['_id'], ObjectId())

        # assert
        assert true_result == True
        assert false_result == False

    def test_get_username_by_role(self, fakers):
        # arrange
        accountId = ObjectId()
        approver_user = fakers.user.insert_single({'roles': [UserRole.APPROVER], 'accountId': accountId})
        fakers.user.insert_single({'roles': [UserRole.EXECUTIVE], 'accountId': accountId})
        finance_user = fakers.user.insert_single({'roles': [UserRole.FINANCE], 'accountId': accountId})
        fakers.user.insert_single({'roles': [UserRole.FINANCE]})

        # act
        result = user_repository().get_usernames_by_role(accountId, [UserRole.APPROVER, UserRole.FINANCE])

        # assert
        assert result == [approver_user['username'], finance_user['username']]

    def test_get_username_by_role_no_users(self, fakers):
        # arrange
        accountId = ObjectId()
        fakers.user.insert_single({'roles': [UserRole.APPROVER], 'accountId': accountId, 'active': False})
        fakers.user.insert_single({'roles': [UserRole.FINANCE], 'accountId': accountId, 'active': False})

        # act
        result = user_repository().get_usernames_by_role(accountId, [UserRole.APPROVER, UserRole.FINANCE])

        # assert
        assert result == []


def test_get_by_username(fakers, repositories):
    # arrange
    expectedUser = fakers.user.insert_many(2)[0]

    # act
    actual = repositories['user'].get_by_username(expectedUser["username"])

    # assert
    assert actual == expectedUser


def test_blocked_domains(db, repositories):
    # arrange
    expected = {'domains': ['domain1.com', 'domain2.com']}
    db.blocked_domains.insert_one(expected)

    # act
    actual = repositories['user'].get_blocked_domains()

    # assert
    assert actual == expected


def test_get_page_ascending(db, repositories):
    # arrange
    users = [
        {
            'username': 'user1@domain.org',
            'first_name': 'User',
            'last_name': 'A',
            'title': 'User',
            'departmentName': 'User Department',
            'phone_number': '000-00-0000'
        },
        {
            'username': 'user2@domain.org',
            'first_name': 'User',
            'last_name': 'B',
            'title': 'User',
            'departmentName': 'User Department',
            'phone_number': '000-00-0000'
        },
        {
            'username': 'user3@domain.org',
            'first_name': 'User',
            'last_name': 'C',
            'title': 'User',
            'departmentName': 'User Department',
            'phone_number': '000-00-0000'
        },
        {
            'username': 'admin4@domain.org',
            'first_name': 'Admin',
            'last_name': 'D',
            'title': 'Admin',
            'departmentName': 'Admin Department',
            'phone_number': '000-00-0000'
        }
    ]
    db.user.insert_many(users)

    # act
    filters = {
        'first_name': 'User',
        'offset': 1,
        'count': 2,
        'orderBy': 'last_name',
        'descending': False
    }
    actual = repositories['user'].get_page(filters)

    # assert
    assert len(actual)
    actual_total_count, actual_results = actual
    assert actual_total_count == 3
    assert len(actual_results) == 2
    assert actual_results[0]['last_name'] == 'B'
    assert actual_results[1]['last_name'] == 'C'


def test_get_page_descending(db, repositories):
    # arrange

    users = [
        {
            'username': 'Admin1@domain.org',
            'first_name': 'Admin',
            'last_name': 'A',
            'title': 'Admin',
            'departmentName': 'Admin Department',
            'phone_number': '000-00-0000'
        },
        {
            'username': 'User2@domain.org',
            'first_name': 'User',
            'last_name': 'B',
            'title': 'User',
            'departmentName': 'User Department',
            'phone_number': '000-00-0000'
        },
        {
            'username': 'user3@domain.org',
            'first_name': 'User',
            'last_name': 'C',
            'title': 'User',
            'departmentName': 'User Department',
            'phone_number': '000-00-0000'
        },
        {
            'username': 'user4@domain.org',
            'first_name': 'User',
            'last_name': 'D',
            'title': 'User',
            'departmentName': 'User Department',
            'phone_number': '000-00-0000'
        }
    ]
    db.user.insert_many(users)

    # act
    filters = {
        'username': Regex('USER', RegexFlag.IGNORECASE),
        'offset': 1,
        'count': 3,
        'orderBy': 'last_name',
        'descending': True
    }
    actual = repositories['user'].get_page(filters)

    # assert
    assert len(actual)
    actual_total_count, actual_results = actual
    assert actual_total_count == 3
    assert len(actual_results) == 2
    assert actual_results[0]['last_name'] == 'C'
    assert actual_results[1]['last_name'] == 'B'
