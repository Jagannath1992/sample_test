from portal.shared.repositories import instance_settings_repository
from werkzeug.exceptions import BadRequest
from portal.shared.enums import InstanceStatus
from collections import namedtuple


class InstanceValidator:
    ValidationField = namedtuple('ValidationField', 'name error_message')
    fields = [
        ValidationField('causeAreas', 'At least one cause area is required'),
        ValidationField('skus', 'At least one SKU is required'),
        ValidationField('settings.termsOfUseUrl', 'Terms of use URL is required'),
        ValidationField('settings.cookiePolicyUrl', 'Cookie policy URL is required'),
        ValidationField('settings.privacyPolicyUrl', 'Privacy policy URL is required'),
    ]

    def __init__(self, instance_request: dict, prev_instance: dict = {}):
        self.instance_request = instance_request
        self.prev_instance = prev_instance

    def validate_instance_name(self):
        # Only validate if name is in the request
        if not 'name' in self.instance_request:
            return
        # Only validate if name is new/changed
        if self.instance_request.get('name') == self.prev_instance.get('name'):
            return

        if instance_settings_repository().exists_by_filter({'name': self.instance_request['name']}):
            raise BadRequest(f'An instance named {self.instance_request["name"]} already exists')

    def validate_active_instance(self, update: bool = False):
        # Only validate if status is in the request
        if not 'status' in self.instance_request:
            return
        # Only validate active instance settings
        if self.instance_request.get('status') != InstanceStatus.ACTIVE:
            return

        if not self.prev_instance or update:
            # for POST request, previous instance does not exists, hence instance_request (payload) should have "causeAreas" and "skus" in it
            # for PUT request (update) instance_request (payload) should have "causeAreas" and "skus" in it, as it will replace the existing value
            for field in InstanceValidator.fields:
                if self._is_missing(self.instance_request, field.name):
                    raise BadRequest(field.error_message)
        else:
            # for PATCH request, previous instance exists and if status change to "active" is requested,
            # then we need to make sure that either new instance_request (payload) or previous_instance has "causeAreas" and "skus" in it
            for field in InstanceValidator.fields:
                if self._is_missing(self.instance_request, field.name):
                    if self._is_missing(self.prev_instance, field.name):
                        raise BadRequest(field.error_message)
    
    def _is_missing(self, instance: dict, path: str):
        fields = path.split('.')
        value = instance

        for field in fields:
            if not field in value or not value.get(field):
                return True
            value = value.get(field)
            
        return False
