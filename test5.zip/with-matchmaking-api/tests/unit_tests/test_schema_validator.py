from matchmaking.validation.utils import *
from datetime import datetime
from bson.objectid import ObjectId

def test_validate_basic():
    schema = {
        'name': str,
        'age': int,
    }

    alice = {
        'name': 'alice',
        'age': 30,
    }

    bob = {
        'name': 'alice',
        'age': '30',
    }

    errors = validate_schema(schema, alice)
    assert len(errors) == 0

    errors = validate_schema(schema, bob)
    assert len(errors) == 1


def test_validate_list():
    schema = {
        'range1': [str],
        'range2': [int],
    }

    list1 = {
        'range1': ['a', 'b', 'c'],
        'range2': [1, 2, 3],
    }

    list2 = {
        'range1': 1,
        'range2': ['a', 2, 3],
    }

    errors = validate_schema(schema, list1)
    assert len(errors) == 0

    errors = validate_schema(schema, list2)
    assert len(errors) == 2


def test_validate_dict():
    schema = {
        'nest': {
            'a': int,
        }
    }

    dict1 = {
        'nest': {
            'a': 1,
        }
    }

    dict2 = {
        'nest': {
            'a': '1',
        }
    }

    errors = validate_schema(schema, dict1)
    assert len(errors) == 0

    errors = validate_schema(schema, dict2)
    assert len(errors) == 1


def test_validate_full():
    schema = {
        'name': str,
        'age': int,
        'job': {
            'title': str,
            'responsibilities': [str],
            'security_clearance': {
                'level': int,
                'range': [{
                    'start': float,
                    'end': float,
                }]
            }
        }
    }

    alice = {
        'name': 'alice',
        'age': 30,
        'job': {
            'title': 'engineer',
            'responsibilities': ['testing', 'coding'],
            'security_clearance': {
                'level': 1,
                'range': [
                    {
                        'start': 1.0,
                        'end': 2.0,
                    },
                    {
                        'start': 2.1,
                        'end': 2.0,
                    },
                ],
            }
        }
    }

    bob = {
        'name': 'bob',
        'age': '30',
        'job': {
            'title': 'engineer',
            'responsibilities': ['testing', 'coding'],
            'security_clearance': 1,
        }
    }

    errors = validate_schema(schema, alice)
    assert len(errors) == 0

    errors = validate_schema(schema, bob)
    assert len(errors) == 2


def test_object_id():
    schema = {
        '_id': ObjectId
    }

    doc = {
        '_id': ObjectId('5a591f5f0274390001bfbbe5')
    }

    assert len(validate_schema(schema, doc)) == 0


def test_datetime():
    schema = {
        'createdAt': datetime
    }

    doc = {
        'createdAt': datetime.now()
    }

    assert len(validate_schema(schema, doc)) == 0
