# pylint: disable=line-too-long, missing-docstring, invalid-name, wildcard-import, unused-wildcard-import
# pylint: disable=too-many-branches, too-many-statements, too-many-boolean-expressions
from .utils import check_term, add_feature, save_program_document, \
    SELECTED_VOCABULARY_VERSION, critical_alert, init_tagging
from .constants import * # pylint: disable=unused-import

def tag_gri(document, vocabulary):
    # here is where we're modifying data on records
    # what's our general approach?  well - let's load up the mm_vocabulary object into this hash named vocabulary
    # then we pass that and the given document (program record) together to output a stringified - meaning: readable
    # version of the document.

    log = list()
    _MY_SOURCE = VOCAB_GRI  # set this up for each data source!

    try:

        tag_data = init_tagging(document, vocabulary, log, _MY_SOURCE)


        # NOW START TURNING THE RULES INTO CODE

        # Rule 201-1: Community Investment
        log.append("  rule 201-1")
        add_feature(_MY_SOURCE, ECONOMIC_PERFORMANCE, tag_data)
        log.append("----")

        # 201-2 Financial implications and other risks and opportunities due to climate change
        log.append("  rule 201-2")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data)) or \
                    (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, CLIMATE_CHANGE_MITIGATION, tag_data)

        log.append("----")

        # GRI 203-1: Infrastructure investment and services supported.
        log.append("  rule 203-1")
        add_feature(_MY_SOURCE, INFRASTRUCTURE_INVESTMENT, tag_data)

        log.append("----")

        # GRI 203-2: Significant indirect economic impacts
        log.append("  rule 203-2")
        # any cause - do we have to check that a cause exists?
        if (check_term(ACHIEVE_FINANCIAL_STABILITY, VOCAB_IMPACTS, tag_data) or \
            check_term(INCREASE_ACCESS_TO_AND_ACQUIRE_EMPLOYMENT, VOCAB_IMPACTS, tag_data) or \
            check_term(PROMOTE_ECONOMIC_GROWTH, VOCAB_IMPACTS, tag_data) or \
            check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data)) and \
                (check_term(DEVELOP_SKILLS_TO_SECURE_EMPLOYMENT__HOUSING_AND_FINANCIAL_STABILITY, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_BUSINESS_AND_ENTERPRISE_DEVELOPMENT, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROMOTE_JOB_CREATION, VOCAB_APPROACHES, tag_data) or \
                 check_term(INCREASE_JOB_PLACEMENT_RETENTION_SERVICES, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_JOB_CAREER_READINESS_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_ENTREPRENEURSHIP_TRAINING, VOCAB_APPROACHES, tag_data) or \
                 check_term(CREATE_ACCESS_TO_RESOURCES_AND_OR_PUBLIC_BENEFITS, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_SUPPORT_PROGRAMS_TO_MAINTAIN_EMPLOYMENT__HOUSING__FINANCIAL_STABILITY__AND_PHYSICAL_AND_MENTAL_HEALTH, VOCAB_APPROACHES, tag_data) or \
                 check_term(PROVIDE_TECHNOLOGY_LITERACY_TRAINING, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, POSITIVE_ECONOMIC_IMPACTS_IN_THE_COMMUNITY, tag_data)

        log.append("----")

        # 302-2 Energy consumption outside the organization
        log.append("  rule 302-2")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(ENHANCE_PHYSICAL_COMMUNITY_INFRASTRUCTURE, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_WATER_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data) or \
                     check_term(ENHANCE_LAND_MANAGEMENT_AND_OR_PROTECTION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, EXTERNAL_ENERGY_CONSUMPTION, tag_data)

        log.append("----")

        # 304-2 Biodiversity
        log.append("  rule 304-2")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ANIMAL_WELFARE, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, SIGNIFICANT_IMPACTS_OF_ACTIVITIES__PRODUCTS__AND_SERVICES_ON_BIODIVERSITY, tag_data)

        log.append("----")

        # 304-3 Biodiversity
        log.append("  rule 304-2")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ANIMAL_WELFARE, VOCAB_IMPACTS, tag_data) or \
                 check_term(PROTECT_ENDANGERED__VULNERABLE__OR_THREATENED_SPECIES, VOCAB_IMPACTS, tag_data)):
            add_feature(_MY_SOURCE, HABITATS_PROTECTED_OR_RESTORE, tag_data)

        log.append("----")

        # 305-3 Other indirect (Scope 3) GHG emissions
        log.append("  rule 305-3")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_LANDS, VOCAB_IMPACTS, tag_data) or \
                 check_term(INCREASE_PROTECTION_OF_PUBLIC_WATERS, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(CREATE_POLICY_CHANGE, VOCAB_APPROACHES, tag_data) or \
                     check_term(PASS_LEGISLATION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, OTHER_INDIRECT_SCOPE_3_GHG_EMISSIONS, tag_data)

        log.append("----")

        # 305-5 Reduction of GHG emissions
        log.append("  rule 305-5")
        if check_term(ENVIRONMENT, VOCAB_CAUSES, tag_data) and \
                (check_term(INCREASE_UNDERSTANDING_OF_AND_COMMITMENT_TO_REDUCING_CLIMATE_CHANGE, VOCAB_IMPACTS, tag_data) or \
                 check_term(REDUCE_CARBON_AND_GREENHOUSE_GAS_IMPACT, VOCAB_IMPACTS, tag_data) or \
                 check_term(IMPROVE_AIR_QUALITY, VOCAB_IMPACTS, tag_data)) and \
                    (check_term(REDUCE_POLLUTION_CLEAN_OR_REHABILITATE_THE_ENVIRONMENT, VOCAB_APPROACHES, tag_data) or \
                     check_term(IMPROVE_ENERGY_EFFICIENCY, VOCAB_APPROACHES, tag_data) or \
                     check_term(INCREASE_USE_OF_RENEWABLE_ENERGY, VOCAB_APPROACHES, tag_data) or \
                     check_term(REDUCE_GREENHOUSE_GASES, VOCAB_APPROACHES, tag_data) or \
                     check_term(CREATE_POLICY_CHANGE, VOCAB_APPROACHES, tag_data) or \
                     check_term(PASS_LEGISLATION, VOCAB_APPROACHES, tag_data)):
            add_feature(_MY_SOURCE, REDUCTION_OF_GHG_EMISSIONS, tag_data)

        log.append("----")

        # GRI 413 - 1: Operations with local community engagement, impact assessments, and development programs
        log.append("  rule 413-1")
        add_feature(_MY_SOURCE, LOCAL_COMMUNITY_ENGAGEMENT, tag_data)

        # do this when it's complete
        log.append("  Summary: " + ', '.join(document[_MY_SOURCE]["strings"]))

        # now put the version number into the same object
        document[_MY_SOURCE]["tagging-version"] = SELECTED_VOCABULARY_VERSION

        # cool!  save that object back and go!
        save_program_document(document)

    except Exception as eee:
        critical_alert(eee, log, "vocab_error_in_tagging")
        raise eee

    return log
