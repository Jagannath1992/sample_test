from flask import current_app
from signxml import XMLSigner
from defusedxml import lxml

import datetime
import uuid


def create_idp_metadata(app_config, idp_name):
    """
    :param app_config: application config
    :param idp_name: the idp name
    :return: the metadate for the idp. None if idp not found in yml config file.
    """
    idp_config = app_config['config']['saml']['idp'].get(idp_name)
    if idp_config is None:
        return None

    certificate_file = app_config['certificate']

    # read idp metadata template
    metadata = get_idp_metadata_template()

    # update macros
    two_days_later = (datetime.datetime.utcnow() + datetime.timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%S.%f%Z")
    metadata_values = {
        'valid-until': two_days_later,
        'entity-id': idp_config.get('entity_id'),
        'sign-on-service': idp_config.get('sign_on_endpoint'),
        'certificate': get_certificate_content(certificate_file),
    }

    for key in metadata_values.keys():
        metadata = metadata.replace('{{' + key + '}}', metadata_values.get(key))

    return metadata


def create_assertion_response(user, app_config):
    golden_config = app_config['config']['saml']['sp']['golden']
    certificate_file = app_config['certificate']
    private_key = app_config['private_key']

    assertion_template = get_assertion_template()

    # create assertion
    now = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f%Z")
    ten_minutes_later = (datetime.datetime.utcnow() + datetime.timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%S.%f%Z")

    # set permission
    # The relevant options for permission are owner, admin, write or read.
    user_type_permission_map = {
        'admin': 'admin',
        're-owner': 'owner',
        're-manager': 'write',
    }
    permission = user_type_permission_map.get(user['type'], 'read')

    assertion_values = {
        'assertion_id': str(uuid.uuid4()),
        'issuer': golden_config['issuer'],
        'issue_instant': now,
        'recipient': golden_config['consume_service_endpoint'],
        'not_before': now,
        'not_on_or_after': ten_minutes_later,
        'auth_instant': now,
        'session_index': str(uuid.uuid4()),
        'org_id': str(user.get('orgId')),
        'email': user.get('username'),
        'first_name':  user.get('first_name'),
        'last_name': user.get('last_name'),
        'role': permission,
        'audience': golden_config['metadata'],
    }

    for key in assertion_values.keys():
        assertion_template = assertion_template.replace('{{' + key + '}}', assertion_values.get(key))

    # create saml response
    response_template = get_response_template()

    response_values = {
        'response_id': str(uuid.uuid4()),
        'issuer': golden_config['issuer'],
        'signed_assertion': assertion_template,
        'issue_instant': now,
        'destination': golden_config['consume_service_endpoint'],
    }

    for key in response_values.keys():
        response_template = response_template.replace('{{' + key + '}}', response_values.get(key))

    # sign response
    signer = XMLSigner(signature_algorithm=golden_config['signature_algo'], c14n_algorithm=golden_config['c14n_algo'])
    response_root = lxml.fromstring(response_template)
    signed_response = signer.sign(response_root, key=read_file_bytes(private_key), cert=read_file_bytes(certificate_file))
    signed_response = lxml.tostring(signed_response).decode('utf-8')

    return signed_response


def get_certificate_content(certificate):
    """
    :param certificate:
    :return: certificate content without header and footer
    """
    file = open(certificate.name, 'r')
    lines = file.readlines()[1:-1]
    certificate_str = ''
    for l in lines:
        certificate_str += l.strip()

    return certificate_str


def read_file_bytes(file):
    f = open(file.name, 'r')
    return f.read()


def get_idp_metadata_template():
    return read_xml_file('./saml_template/idp/givewith/metadata.xml')


def get_assertion_template():
    return read_xml_file('./saml_template/idp/givewith/assertion.xml')


def get_response_template():
    return read_xml_file('./saml_template/idp/givewith/saml_response.xml')


def read_xml_file(path):
    with current_app.open_resource(path, 'r') as file:
        return file.read().replace('\n', '')
