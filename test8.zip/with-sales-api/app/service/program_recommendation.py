import json
import requests

from collections import defaultdict
from copy import copy
from os import environ

from requests.exceptions import ConnectTimeout, ReadTimeout
from bson.objectid import ObjectId
from flask import current_app

from app.db.utils import get_document_by_id, get_documents, get_document


def recommend(brand_id: str):
    """
        This is where recommendations occur
        The input is a brand name, such as 'AMERICAN EXPRESS COMPANY'
        And the output is a JSON file:

        Which is an array like this (with all the programs, here's two):
        [
            RecommendationItem(
                'Improve work readiness skills and employee talent pipeline through job shadowing',
                80.50871356508749,
                5ba55c042c63670007fc71ce,
                '5b30ec95e3dde10019e177d3',
                False
            ),
            RecommendationItem(
                'Enable young adults to transition to meaningful careers',
                80.50871356508749,
                5c083c290f36530008d4439b,
                '5b30f0b0e3dde1001ae17758',
                False
            )
        ]

        Where 'RecommendationItem' has
            ProgramName
            Score
            ProgramID
            NonProfitID

        there is now a new remote api call to load recommendations from an ALGO API server
        which will manage the base ETL for our recommendations engine, as well as the math and in-memory
        storage of all the values for calculation of the response.  if this connection fails, an empty list is returned
     """
    current_app.logger.info("recommend function in utils: " + brand_id)
    programs = get_documents('mm_programs', {'nonprofit': {'$ne': None}})

    programs_dict = {
        d['name']: {
            'id': str(d['_id']),
            'nonprofit': str(d['nonprofit']),
            'minimumFunding': d.get('minimumFunding'),
            'isValid': d.get('isValid'),
            'isValidNonprofit': d.get('isValidNonprofit'),
            'active': d.get('active'),
        }
        for d in programs
    }

    id_to_name_dict = {str(d['_id']): d['name'] for d in programs}
    del programs

    try:
        # weights per datasource are currently hardcoded here
        # adding new datasources (like MSCI, etc.) are will also need to be coordinated here
        # initial spec for weights from data/research team:
        # MSCI 2 Industry 1, Corp Commitment 2, preferred NPO 3

        env = environ.get('ENV', 'local')
        openshift_deploy = environ.get('OPENSHIFT_DEPLOY', 'False')
        openshift_matchmaking_algo_url = environ.get('OPENSHIFT_MATCHMAKING_ALGO_URL', '')

        algo_server = "gw_matchmaking_algo"
        if env == "staging":
            # algo_server = "internal-givewith-matchmaking-algo-1406367349.us-east-1.elb.amazonaws.com" # load balancer
            algo_server = '172.17.10.148'
        elif env == "production":
            algo_server = "internal-givewith-matchmaking-algo-114916578.us-east-1.elb.amazonaws.com"
        elif env == "sandbox":
            algo_server = "internal-algo-loadbalancer-310878003.us-east-1.elb.amazonaws.com"
	
        uri = F'http://{algo_server}:5000/recommend/?id={brand_id}&RATING=0.35&REPORTING=0.15&CONSUMER=0.25&CSR=0.25'

        if openshift_deploy == "True":
            algo_server = openshift_matchmaking_algo_url
            uri = F'http://{algo_server}:8080/recommend/?id={brand_id}&RATING=0.35&REPORTING=0.15&CONSUMER=0.25&CSR=0.25'
        
        try:
            response = requests.get(uri, timeout=15.0)
        except ConnectTimeout as connex:
            current_app.logger.error('cannot connect to ' + str(uri) + ' due to Connect Timeout ' + str(connex))
            return list()
        except ReadTimeout as readex:
            current_app.logger.error('cannot connect to ' + str(uri) + ' due to Read Timeout ' + str(readex))
            return list()

        recommendation_data = json.loads(response.text)
        recommendations = recommendation_data["recommendations"]
        recommendation_list = list()

        for r in recommendations:
            program_id = r["programID"]
            score = r["ranking"]

            if program_id in id_to_name_dict:
                program_name = id_to_name_dict[program_id]
                program = programs_dict[program_name]
                is_valid = all([program['isValid'], program['isValidNonprofit']])
                active = program['active']
                nonprofit = program['nonprofit']
                minimum_funding = program['minimumFunding']
                recommendation_list.append(RecommendationItem(program_name,
                                                              is_valid,
                                                              score,
                                                              program_id,
                                                              nonprofit,
                                                              active,
                                                              minimum_funding))
            else:
                log = f'''MM-algo, can't find program with id {program_id};
                      probable data-source alignment issue (db v. staging/local/prod)'''
                current_app.logger.info(log)

        return recommendation_list

    except Exception as e:
        current_app.logger.info("recommend function - exception " + str(e))
        return list()


def get_deal_recommended_programs(deal, include_invalid=False, nonprofit_map=None):
    """Get list of recommendations

    Arguments:
        deal {dict} -- the deal to make recommendations for
        include_invalid (boolean) -- include invalid programs
        nonprofit_map {dict} -- array of nonprofits with blacklists, defaults to none

    Returns:
         Array of programs
    """

    client, gw_customer = str(deal['client']), str(deal['givewithCustomer'])
    deal_info = {
        'gw_customer': gw_customer,
        'client': client,
        'gw_customer_industry': str(get_brand_industry_id(gw_customer)),
        'client_industry': str(get_brand_industry_id(client)),
        'funding_amount': float(deal.get('fundingAmount', 0)),
        'selected_program_id': str(deal.get('selectedProgram')),
        'blacklisted_nonprofits': get_blacklist_nonprofits_for_both_brands(deal),
    }

    programs = annotate_recommended_programs(recommend(client), deal_info,
                                             get_validity=get_program_validity_deal, nonprofit_map=nonprofit_map)
    return [transform_recommended_program(p) for p in programs if p.is_valid or include_invalid]


def get_brand_recommended_programs(brand, include_invalid=False, nonprofit_map=None):
    """ Similar to get_deal_recommended_programs but runs on just one brand """

    brand_id_str = str(brand['_id'])
    industry = brand.get('industry')
    brand_info = {
        '_id': brand_id_str,
        'industry': str(industry if isinstance(industry, ObjectId) else get_brand_industry_id(brand)),
        'blacklisted_nonprofits': get_blacklist_nonprofit_for_brand(brand)
    }

    # call the recommend function and pass its output to the annotate function
    programs = annotate_recommended_programs(recommend(brand_id_str), brand_info,
                                             get_validity=get_program_validity_brand, nonprofit_map=nonprofit_map)
    return [transform_recommended_program(p) for p in programs if p.is_valid or include_invalid]


def transform_recommended_program(recommended_item):
    """ Add more details to recommended program

    Arguments:
        recommended_item {dict} -- individual recommended program

    Returns:
        Dict -- dictionary of program with more details (themes, nonprofitName, match %, etc...)

    Example:
      *recommended_item:
        RecommendationItem(
          'Provide educational opportunities to low-income youth outside of school',
          True,
          69.79460759924365,
          5b871e34936d7d00108228fb,
          '5b32a1f9ee979d00190eb1c7')
      *returns:
          {
          '_id': '5b871e34936d7d00108228fb',
          'name': 'Provide educational opportunities to low-income youth outside of school',
          'isValid': True,
          'invalidReasons': [],
          'nonprofit': '5b32a1f9ee979d00190eb1c7',
          'match': 70,
          'matchType': 'MATCH',
          'customerPreferred': False,
          'minimumFunding': None,
          'themes': ['Education', 'Poverty Alleviation', 'Youth Development'],
          'nonprofitName': 'Mercy Housing '
          }

    """
    recommended_item.score = round(float(recommended_item.score))
    program_dict = recommended_item.tojson()
    try:
        themes = get_program_themes_by_id(recommended_item.id_)
        if themes:
            program_dict['themes'] = [get_vocabulary_label_v2(_id) for _id in themes]

    except:
        current_app.logger.warning(f'Error retrieving themes for recommended program {recommended_item.id_}')

    try:
        nonprofit = get_nonprofit(recommended_item.nonprofit)
        if nonprofit:
            program_dict['nonprofitName'] = nonprofit.get('name', '')
            program_dict['registeredCountry'] = get_descendant_key(nonprofit, 'general.location.generalLocation', '')
    except:
        current_app.logger.warning(f'Error retrieving nonprofit for recommended program {recommended_item.id_}')

    return program_dict


def annotate_recommended_programs(programs, info_dict, get_validity, nonprofit_map=None):
    """Annotates recommended programs by adding invalid_reasons and modifying is_valid

        programs {dict} - list of recommended programs
        info_dict {dict} - the info_dictionary to pass to the get_validity function
        get_validity {func} - get the validity info of the program (reasons why a program is invalid)
        nonprofit_map { dict } - array of nonprofits with blacklists
    """
    # create nonprofit map if it isn't passed
    if nonprofit_map is None:
        nonprofit_map = get_nonprofits_with_blacklists()

    annotated_programs = []

    for program in programs:
        program_copy = copy(program)
        invalid_reasons = get_validity(program_copy.tojson(), info_dict, nonprofit_map)

        # if invalid_reasons isn't empty, program is invalid due to the reasons specified in the list
        if invalid_reasons:
            program_copy.is_valid = False
            program_copy.invalid_reasons = invalid_reasons

        annotated_programs.append(program_copy)

    return annotated_programs


def select_programs(programs_list, limit=None):
    """ Selects valid programs with highest match % from programs_list such that no nonprofit is repeated
    Accomplishes this by organizing program list by nonprofits and sorting them by recommendation value

    Arguments:
        programs_list [array] - array of programs
        limit # - limit of how many programs to choose (set in mm_settings in recommendationSettings.recommendations)

    Returns:
        Array - based off of the limit, it'll return how many programs you can choose

    """
    if not programs_list:
        return []

    max_selections = limit or get_recommendations_limit()
    if len(programs_list) < max_selections: 
        max_selections = len(programs_list)
    np_group = defaultdict(list)

    # Group programs by nonprofit, omit nonprofits blacklisted for any reason, or is invalid
    for program in programs_list:
        if program.get('isValid'):
            np_group[program['nonprofit']].append(program)

    # Sort every group of nonprofits by its value
    sorted_np_group = {k: list(sorted(v, key=lambda k: k['match'], reverse=True)) for k, v in np_group.items()}

    count = 0
    selected = []
    while count < max_selections:
        # Sort programs by highest score
        top_values = [safe_pop(v, 0) for k, v in sorted_np_group.items()]
        top_values = [program for program in top_values if program is not None]
        top_values.sort(key=lambda k: k['match'], reverse=True)

        selected.extend(top_values)
        count += len(top_values)

    return selected[:max_selections]


def filter_selected_programs(deal, deal_info=None, nonprofit_map=None):
    """Filters selected programs to remove invalid programs

    Arguments:
        deal {dict} -- deal dictionary
        deal_info {dict} -- information about the deal, defaults to none
        nonprofit_map {dict} -- array of nonprofits with blacklists, defaults to none

    Returns:
        Array - a array that contains programs that are eligible for the deal.
    """
    gw_customer, client = deal['givewithCustomer'], deal['client']

    if deal_info is None:
        deal_info = {
            'gw_customer': gw_customer,
            'client': client,
            'gw_customer_industry': str(get_brand_industry_id(gw_customer)),
            'client_industry': str(get_brand_industry_id(client)),
            'funding_amount': float(deal.get('fundingAmount', 0)),
            'selected_program_id': str(deal.get('selectedProgram')),
            'blacklisted_nonprofits': get_blacklist_nonprofits_for_both_brands(deal),
        }

    if nonprofit_map is None:
        nonprofit_map = get_nonprofits_with_blacklists()

    id_to_program_dict = {
        program.get('_id'): program for program in deal.get('selectedRecommendedPrograms', [])
    }

    # pop programs that are invalid: programs that no longer meet the minimum funding requirement or whose nonprofits
    # have blacklisted brands or industries are discarded
    for full_program in get_selected_recommended_programs(deal):
        program = id_to_program_dict.get(full_program.get('_id'))

        if program:
            program['minimumFunding'] = full_program.get('minimumFunding')
            program['active'] = full_program.get('active')
            program['isValid'] = all(
                [
                    full_program['isValid'],
                    full_program['isValidNonprofit'],
                    full_program['active']
                 ]
            )

            invalid_reasons = get_program_validity_deal(program, deal_info, nonprofit_map)

            if invalid_reasons:
                id_to_program_dict.pop(program.get('_id'), None)

    return list(id_to_program_dict.values())


def get_program_validity_deal(recommended_item, deal_info, nonprofits):
    """Given a Recommended Item, and proposal info, determine if the program is a valid recommendation for the deal

    A program is invalid if one of the following is true:
    1. The program has required fields missing or has an invalid nonprofit: PROGRAM_INVALID
    2. One or more of the Brands associated with the proposal is blacklisted by the nonprofit: BRAND_BLACKLISTED
    3. One of more of the industries associated with the proposal is blacklisted by the nonprofit: INDUSTRY_BLACKLISTED
    4. Nonprofit associated with the program is blacklisted by the brand: NONPROFIT_BLACKLISTED
    5. The proposal's minimum funding does not meet the program's required minimum funding: FUNDING_NOT_MET
    5. The program is inactive: PROGRAM_INACTIVE

    Arguments:
        recommended_item {dict} -- recommended program dictionary
        deal_info {dict} -- custom dictionary containing truncated info regarding the proposal
        nonprofits {dict} -- A map of nonprofit ids to nonprofits (preferably only nonprofits with blacklists)

    Returns:
        Tuple(boolean, string, dict) -- Tuple containing whether program is a valid recommendation and
        why if it is not valid and details
    """
    recommended_nonprofit = str(recommended_item.get('nonprofit'))
    invalid_reasons = []

    # if program has already been selected, it is a valid program even if the program's minimum funding
    # isn't met or nonprofit has blacklisted the brand or industry
    if deal_info.get('selected_program_id') != recommended_item.get('id_'):
        # --- CRITERIA: PROGRAM IS INVALID DUE TO INVALID FIELDS, INVALID NONPROFIT -- #
        # NOTE: This field is set on the recommended_item in the recommend function
        if not recommended_item.get('isValid'):
            invalid_reasons.append('PROGRAM_INVALID')

        # --- CRITERIA: PROGRAM IS INACTIVE (ACTIVE = FALSE) -- #
        if not recommended_item.get('active'):
            invalid_reasons.append('PROGRAM_INACTIVE')

        # ------------ CRITERIA: MINIMUM FUNDING OF PROGRAM ----------- #
        minimum_funding = recommended_item.get('minimumFunding')
        if minimum_funding and deal_info.get('funding_amount') < minimum_funding:
            invalid_reasons.append('FUNDING_NOT_MET')

        # ------------- CRITERIA: NONPROFIT BLACKLISTS ANY OF BRAND OR BRAND'S INDUSTRY ---- #
        if nonprofits.get(recommended_nonprofit):
            blacklisted_brands = nonprofits.get(recommended_nonprofit, {}).get('blacklisted_brands', set())
            if deal_info.get('gw_customer') in blacklisted_brands or deal_info.get('client') in blacklisted_brands:
                invalid_reasons.append('BRAND_BLACKLISTED')

            blacklisted_industries = nonprofits.get(recommended_nonprofit, {}).get('blacklisted_industries', set())
            if deal_info.get('gw_customer_industry') in blacklisted_industries or \
                deal_info.get('client_industry') in blacklisted_industries:
                invalid_reasons.append('INDUSTRY_BLACKLISTED')

        # ---------- CRITERIA: ANY OF BRAND BLACKLISTS NONPROFIT --------- #
        blacklisted_nonprofits = deal_info.get('blacklisted_nonprofits', set())
        if recommended_nonprofit in blacklisted_nonprofits:
            invalid_reasons.append('NONPROFIT_BLACKLISTED')

    return invalid_reasons


def get_program_validity_brand(recommended_item, brand_info, nonprofits):
    """Similar to get_program_validity_deal but uses info of one brand"""
    invalid_reasons = []
    recommended_nonprofit = str(recommended_item.get('nonprofit'))

    # --- CRITERIA: PROGRAM IS INVALID DUE TO INVALID FIELDS, INVALID NONPROFIT, OR ACTIVE = FALSE -- #
    # NOTE: This field is set on the recommended_item in the recommend function
    if not recommended_item.get('isValid'):
        invalid_reasons.append('PROGRAM_INVALID')

    # ------------- CRITERIA: NONPROFIT BLACKLISTS ANY OF BRAND OR BRAND'S INDUSTRY ---- #
    if nonprofits.get(recommended_nonprofit):
        blacklisted_brands = nonprofits.get(recommended_nonprofit, {}).get('blacklisted_brands', set())
        if brand_info.get('_id') in blacklisted_brands:
            invalid_reasons.append('BRAND_BLACKLISTED')

        blacklisted_industries = nonprofits.get(recommended_nonprofit, {}).get('blacklisted_industries', set())
        if brand_info.get('industry') in blacklisted_industries:
            invalid_reasons.append('INDUSTRY_BLACKLISTED')

    # ---------- CRITERIA: ANY OF BRAND BLACKLISTS NONPROFIT --------- #
    blacklisted_nonprofits = brand_info.get('blacklisted_nonprofits', set())
    if recommended_nonprofit in blacklisted_nonprofits:
        invalid_reasons.append('NONPROFIT_BLACKLISTED')

    return invalid_reasons


def get_blacklist_nonprofits_for_both_brands(deal):
    client = get_mm_brand(deal['client'], projection={'nonprofits': True})
    gw_customer = get_mm_brand(deal['givewithCustomer'], projection={'nonprofits': True})

    return get_blacklist_nonprofit_for_brand(client) | get_blacklist_nonprofit_for_brand(gw_customer)


# helper function for get_blacklist_nonprofits_for_both_brands
def get_blacklist_nonprofit_for_brand(brand):
    if brand:
        return {str(_id) for _id in brand.get('nonprofits', {}).get('blacklist', [])}
    else:
        return set()


# get all blacklisted brands from a nonprofit
def get_blacklisted_brands_for_nonprofit(nonprofit):
    if nonprofit:
        return {str(brand['_id']) for brand in nonprofit.get('blacklist', {}).get('brands', [])}
    else:
        return set()


# get all blacklisted industries from a nonprofit
def get_blacklisted_industries_for_nonprofit(nonprofit):
    if nonprofit:
        return {industry for industry in nonprofit.get('blacklist', {}).get('industries', [])}
    else:
        return set()


# get all nonprofits that have a blacklist
def get_nonprofits_with_blacklists():
    nonprofits = get_documents('mm_nonprofits', {'blacklist': {'$exists': True}})
    return {
        str(nonprofit.get('_id')): {
            'blacklisted_industries': get_blacklisted_industries_for_nonprofit(nonprofit),
            'blacklisted_brands': get_blacklisted_brands_for_nonprofit(nonprofit),
        } for nonprofit in nonprofits
    }


def get_recommendations_limit():
    settings = get_document('mm_settings')
    return settings.get('recommendationSettings', {}).get('recommendations', 6) if settings else 6


def get_brand_industry_id(brand_or_id):
    if isinstance(brand_or_id, dict):
        brand = brand_or_id
    else:
        brand = get_mm_brand(brand_or_id, projection={'industry': True, 'msci.industry': True})

    industry_name = brand.get('msci', {}).get('industry') or brand.get('industry')
    return get_document('mm_vocabulary', {'label': industry_name})


def get_mm_brand(brand_id, **kwargs):
    if brand_id:
        return get_document_by_id('mm_brands', brand_id)
    else:
        return {}


def get_nonprofit(nonprofit_id, **kwargs):
    if nonprofit_id:
        return get_document_by_id('mm_nonprofits', nonprofit_id)
    else:
        raise Exception('nonprofit', nonprofit_id)


def get_selected_recommended_programs(deal):
    """Queries the DB for Selected Recommended Programs of a deal

    Arguments:
        deal { dictionary } -- deal dictionary
    """
    db_query = {'_id': {'$in': [ program.get('_id') for program in deal.get('selectedRecommendedPrograms', [])]}}
    return get_documents('mm_programs', db_query)


def get_program_themes_by_id(program_id):
    program = get_document_by_id('mm_programs', program_id)

    if not program:
        raise Exception('program', program_id)

    return program.get('themes', {}).get('data', [])


def safe_pop(array, index=-1, default=None):
    try:
        return array.pop(index)
    except IndexError:
        return default


def get_descendant_key(dict_item, desc_str, default_value):
    """
    Get a descendant key of a dictionary using a dot separated string
    """
    arr = desc_str.split('.')

    while arr and dict_item:
        dict_item = dict_item.get(arr.pop(0), None)

    return dict_item if dict_item is not None else default_value


def get_vocabulary_label_v2(vocab_id):
    return get_document_by_id('mm_vocabulary', vocab_id).get('label')


class RecommendationItem:
    """Object that represents a single program recommendation information."""

    def __init__(self, program_name, is_valid, score, id_, nonprofit, active, minimum_funding=None):
        self.program_name = program_name
        self.score = score
        self.id_ = id_
        self.nonprofit = nonprofit
        self.minimum_funding = minimum_funding
        self.is_valid = is_valid
        self.active = active
        # The fields below can be overridden later
        self.invalid_reasons = []
        self.match_type = 'MATCH'
        self.custom_match = None
        self.customer_preferred = False

    def __repr__(self):
        return f"RecommendationItem('{self.program_name}', {self.is_valid}, {self.score}, {self.id_}, '{self.nonprofit}', '{self.active}')"

    def __eq__(self, other):
        return (self.program_name == other.program_name
                and self.is_valid == other.is_valid
                and self.score == other.score
                and self.nonprofit == other.nonprofit
                and self.active == other.active
                and self.invalid_reasons == other.invalid_reasons
                and self.id_ == other.id_)

    def tojson(self):
        json = {'_id': self.id_,
                'name': self.program_name,
                'isValid': self.is_valid,
                'invalidReasons': self.invalid_reasons,
                'nonprofit': self.nonprofit,
                'match': self.score,
                'matchType': self.match_type,
                'customerPreferred': self.customer_preferred,
                'active': self.active,
                'minimumFunding': self.minimum_funding}

        if self.custom_match:
            json['customMatch'] = self.custom_match

        return json
