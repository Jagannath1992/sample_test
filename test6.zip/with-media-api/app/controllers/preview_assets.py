from flask import jsonify, abort

from ..controllers import preview_assets_bp

from ..validation.utils import validate_slug_with_collection, validate_slug_or_id_with_collection
from ..db.utils import get_documents, get_document
from ..utils.utils import add_assets_to_documents, get_assets
from ..constants import default_media_projection


@preview_assets_bp.route('/<string:program_slug>', methods=['GET'])
def get_preview_assets(program_slug):
    '''
    On each Program Detail Page, there is an assets preview module that includes videos and photos.
    This endpoint surfaces the content that is related to the program id or the program's nonprofit id.

    Video must include
    - Program id or Nonprofit id
    - tags -> :30 and NPO Montage and Video
    If no video is found, return nothing.

    Photo must include
    - Program id or Nonprofit id
    - tags -> Beneficiary Profile and Photo
    If no photo is found, return previewImage from program.
    '''

    # if ID is passed, get slug, and override function parameter
    program_id, program_slug = validate_slug_or_id_with_collection(program_slug, 'mm_programs')


    if not validate_slug_with_collection(program_slug, 'mm_programs'):
        abort(404, description='Program slug not found mm_programs: ' + program_slug)

    program = get_document('mm_programs', {'slug': program_slug},
                           projection={'nonprofit': True, 'previewImage': True})

    nonprofit_id = program.get('nonprofit')

    video_query = {
        '$or': [
            {'credits.program_id' : str(program.get('_id'))},
            {'credits.npo_id' : str(nonprofit_id)}
        ],
        '$text': {'$search' : '":30" \"NPO Montage\" "Video"'}
    }
    video = get_document('simian_media', video_query, projection=default_media_projection)

    photo_query = {
        '$or': [
            {'credits.program_id' : str(program.get('_id'))},
            {'credits.npo_id' : str(nonprofit_id)}
        ],
        '$text': {'$search' : '\"Beneficiary Profile\" "Photo"'}
    }
    photo = get_document('simian_media', photo_query, projection=default_media_projection)

    if video:
        video_data = get_assets(video)
    else:
        video_data = {}

    if photo:
        photo_data = get_assets(photo)
    else:
        photo_data = {
            'previewImage': program.get('previewImage', '')
        }

    data = {
        'video': video_data,
        'photo': photo_data
    }

    return jsonify(data)


@preview_assets_bp.route('/<string:program_slug>/all', methods=['GET'])
def get_all_preview_assets(program_slug):
    '''
    On each Program Detail Page, there is an assets preview module that includes videos and photos.
    This endpoint surfaces the content that is related to the program id or the program's nonprofit id
    '''
    if not validate_slug_with_collection(program_slug, 'mm_programs'):
        abort(404, description='Program slug not found mm_programs: ' + program_slug)

    program = get_document('mm_programs', {'slug': program_slug},
                           projection={'nonprofit': True, 'previewImage': True})

    nonprofit_id = program.get('nonprofit')

    data = {
        'videos': get_video_assets(program, nonprofit_id),
        'photos': get_photo_assets(program, nonprofit_id)
    }

    return jsonify(data)


def get_video_assets(program, nonprofit_id):
    '''
    In the video section of the preview module, all videos related to the program should be able to be played.
    If no videos are found, return nothing.

    Documents must include either
    - Program id
    - tags -> 'Video'
    OR
    - Nonprofit id
    - tags -> NPO Generic OR NPO Montage
    '''

    program_query = {
        'credits.program_id': str(program.get('_id')),
        '$text' : {'$search' : 'Video'}
    }
    filtered_program_documents = list(get_documents('simian_media', program_query, projection=default_media_projection))

    npo_query = {
        'credits.npo_id': str(nonprofit_id),
        '$text' : {'$search' : 'Video \'NPO Generic\' \'NPO Montage\''},
    }
    filtered_npo_documents = list(get_documents('simian_media', npo_query, projection=default_media_projection))

    if filtered_program_documents or filtered_npo_documents:
        data = add_assets_to_documents(filtered_program_documents) + add_assets_to_documents(filtered_npo_documents)
    else:
        data = {}

    return data


def get_photo_assets(program, nonprofit_id):
    '''
    In the photo section of the preview module, all photos related to the program should be shown.
    If no photos are found, return previewImage from program.

    Documents must include either
    - Program id
    - tags -> 'Photo' OR 'Digital poster'
    OR
    - Nonprofit id
    - tags -> 'Photo' and 'NPO Generic' OR 'Digital Poster' and 'NPO Generic'
    '''

    program_query = {
        'credits.program_id': str(program.get('_id')),
        '$text' : {'$search' : 'Photo \'Digital Poster\''}
    }

    filtered_program_documents = list(get_documents('simian_media', program_query, projection=default_media_projection))

    npo_query = {
        'credits.npo_id': str(nonprofit_id),
        '$or': [
            {'$and' : [{'tags' : {'$regex' : 'Photo'}}, {'tags' : {'$regex' : 'NPO Generic'}}]},
            {'$and' : [{'tags' : {'$regex' : 'Digital Poster'}}, {'tags' : {'$regex' : 'NPO Generic'}}]},
        ]
    }

    filtered_npo_documents = list(get_documents('simian_media', npo_query, projection=default_media_projection))

    if filtered_npo_documents or filtered_npo_documents:
        data = add_assets_to_documents(filtered_program_documents) + add_assets_to_documents(filtered_npo_documents)
    else:
        data = {
            'previewImage': program.get('previewImage', '')
        }

    return data
