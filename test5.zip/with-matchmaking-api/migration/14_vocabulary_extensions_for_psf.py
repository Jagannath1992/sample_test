from matchmaking import db

impact_to_tootlip_map = {
    'Enhance physical community infrastructure': 'This program enhances infrastructure, such as bridges, roads, community centers, and schools.',
    'Reduce hunger and malnutrition': 'This program directly provides food to people for survival.',
    'Increase access to nutritious food': 'This program provides accessibility that leads to improved nutrition and health.',
    'Increase sustainable food systems': 'This program enhances the food system to increase accessibility, affordability, and sustainability.',
    'Increase sustainable water systems': 'This program enhances the water system to increase accessibility, affordability, and sustainability.',
    'Achieve equality/eliminate discrimination': 'This program increases opportunities for marginalized populations, advances human rights, or provides sensitivity training.',
}

program_approach_to_tooltip_map = {
    'Transactional (purchase a product; pay for a service)': 'Examples include providing a product or service, or distributing goods.',
    'Increasing awareness (advocate; lobby)': 'Examples include advocacy work, lobbying, and awareness campaigns.',
    'Building capacity (strengthen institutions, programs or systems)': 'Examples include training or mentoring.',
    'Changing behavior (train; mentor)': 'Examples include strengthening institutions, programs or systems to ensure long-term sustainability.',
    'Research': 'Examples include conducting or funding research.'
}

approach_to_tooltip_map = {
    'Promote business and enterprise development': 'This program provides increased access to capital for those looking to create small businesses.',
    'Promote job creation': 'This program provides economic development opportunities.',
    'Enhance water management and/or protection': 'This program improves water quality for drinking OR protects waterways from pollution',
    'Enhance land management and/or protection': 'This program protects land through sustainable land management practices.',
    'Provide potable water': 'This program provides drinkable water or access to drinkable water.',
    'Provide affordable housing': 'This program provides access to affordable housing for low-income populations through financial assistance or long-term low-cost housing.',
    'Provide temporary housing': 'This program provides temporary housing to beneficiaries in emergencies.'
}

approach_duration_to_tooltip_map = {
    'One-time': 'Examples include events, one day workshops, or one-time engagement.',
    'Ongoing': 'Examples include multiple training sessions, year-long mentoring, or weekly after-school programming.'
}

cause_area_map = {
    'AC' : 'Arts and culture',
    'CJ': 'Criminal justice',
    'EE': 'Economic empowerment',
    'E': 'Education',
    'EN': 'Environment',
    'FH': 'Food and hunger',
    'HH': 'Housing and homelessness',
    'HC': 'Human rights and civic engagement',
    'HW': 'Health and wellness',
    'DS': 'Disaster response, relief and recovery'
}

impact_cause_mapping = {
    'AC': {
        'Increase appreciation and support for the arts'
    },
    'CJ': {
        'Reduce criminal activity',
        'Reduce criminal recidivism',
    },
    'DS': {
        'Improve conditions after natural disasters and crises',
    },
    'EE': {
        'Achieve financial stability',
        'Increase access to and acquire employment',
        'Promote economic growth',
        'Enhance physical community infrastructure',
    },
    'E': {
        'Ensure 21st Century skills proficiency',
        'Increase access to quality education programs and services',
        'Improve academic achievement',
    },
    'EN': {
        'Increase understanding of and commitment to reducing climate change',
        'Reduce carbon and greenhouse gas impact',
        'Increase protection of public lands',
        'Increase protection of public waters',
        'Improve air quality',
        'Protect animal welfare',
        'Protect endangered, vulnerable, or threatened species',
        'Increase recycling and/or reduce waste',
    },
    'FH': {
        'Reduce hunger and malnutrition',
        'Increase access to nutritious food',
        'Increase access to potable water',
        'Increase sustainable food systems',
        'Increase sustainable water systems',
    },
    'HW': {
        'Reduce disease/improve health',
        'Increase access to quality, affordable healthcare and services',
        'Improve reproductive health',
        'Reduce risky and addictive behaviors',
        'Reduce trauma',
    },
    'HH': {
        'Reduce homelessness',
        'Increase amount and access to quality affordable housing',
    },
    'HC': {
        'Achieve equality/eliminate discrimination',
        'Increase peace through conflict resolution',
        'Increase civic participation',
    }
}

approach_cause_mapping = {
    'AC': {
        'Provide arts education',
        'Enhance support for and/or access to the arts',
    },
    'CJ': {
        'Provide transitional programs and services',
    },
    'EE': {
        'Develop skills to secure employment, housing and financial stability',
        'Develop financial literacy and financial resilience',
        'Promote business and enterprise development',
        'Promote job creation',
        'Increase job placement/retention services',
        'Provide job/career readiness training',
        'Provide entrepreneurship training',
        'Provide technology and connectivity',
        'Provide support programs to maintain employment, housing, financial stability, and physical and mental health',
        'Enhance skills for self sufficiency',
    },
    'E': {
        'Improve academic environments',
        'Enhance school readiness skills',
        'Provide high school completion support',
        'Increase college readiness, access, persistence and completion',
        'Increase access to literacy and numeracy programs',
        'Provide technology literacy training',
        'Provide STEM interest, proficiency and persistence programs',
        'Provide teacher effectiveness programs',
        'Enhance social and emotional learning and skills',
    },
    'EN': {
        'Reduce pollution/clean or rehabilitate the environment',
        'Improve community environments or spaces',
        'Improve energy efficiency',
        'Increase use of renewable energy',
        'Reduce greenhouse gases',
        'Implement infrastructure and transportation projects',
        'Enhance sustainable agriculture practices and programs',
        'Enhance water management and/or protection',
        'Enhance land management and/or protection',
        'Increase animal safety and wellness',
        'Preserve wildlife',
    },
    'FH': {
        'Provide healthy eating behavior and nutrition training',
        'Provide potable water',
        'Provide sufficient, affordable and nutritious foods',
    },
    'HH': {
        'Provide affordable housing',
        'Provide temporary housing',
    },
    'HW': {
        'Provide fitness programs',
        'Increase disease awareness',
        'Increase disease research',
        'Run infant health programs',
        'Provide maternal health programs',
        'Provide mental health programs',
        'Run patient and family support programs',
        'Run patient quality of life programs',
        'Provide sexual health training and programs',
        'Provide support for substance abuse and addictive behaviors',
        'Create access to resources and/or public benefits',
        'Provide case management',
    },
    'HC': {
        'Preserve traditional cultural practices',
        'Enhance legal protections',
        'Create policy change',
        'Pass legislation',
    }
}

question_dependencies = {
    'protectAndEnhanceForest': {
        'operation': 'in',
        'keys': [
            {'key': 'ImpactAndScope.primaryImpact.value', 'operator': 'in', 'descriptionSuffix': 'this program\'s primary targeted impact'},
            {'key': 'ImpactAndScope.secondaryImpact.value', 'operator': 'in', 'descriptionSuffix': 'a secondary impact of this program'},
        ],
        'values': ['Increase protection of public lands'],
    },
    'animalHabitat': {
        'operation': 'in', # any of the keys are in values
        'keys': [
            {'key': 'ImpactAndScope.primaryImpact.value', 'descriptionSuffix': 'this program\'s primary targeted impact'},
            {'key': 'ImpactAndScope.secondaryImpact.value', 'descriptionSuffix': 'a secondary impact of this program'},
        ],
        'values': ['Protect animal welfare', 'Protect endangered, vulnerable, or threatened species']
    },
    'countries': {
        'operation': 'nin',
        'keys': [
            {'key': 'ImpactAndScope.regions.value'},
        ],
        'values': ['N/A']
    },
    'states': {
        'operation': 'in',
        'keys': [
            {'key': 'ImpactAndScope.countries.value', 'descriptionSuffix': 'a country this program operates from. Please select all that apply'},
        ],
        'values': ['North America;United States', 'North America;Canada']
    },
    'cities': {
        'operation': 'nin', # all keys are not in values
        'keys': [
            {'key': 'ImpactAndScope.countries.value'},
        ],
        'values': ['N/A']
    },
}


VOCAB_V2 = {'$in': [2]}

########## ------- MAP TOOLTIPS --------- #################
impact_extensions = {}
for key, value in impact_to_tootlip_map.items():
    impact = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'impact', 'label': key})

    if impact is not None:
        impact_id = str(impact['_id'])
        impact_extensions[impact_id] = {'label': key, 'tooltip': value}

program_approach_extensions = {}
for key, value in program_approach_to_tooltip_map.items():
    program_approach = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'programApproach', 'label': key})

    if program_approach is not None:
        program_approach_id = str(program_approach['_id'])
        program_approach_extensions[program_approach_id] = {'label': key, 'tooltip': value}

approach_extensions = {}
for key, value in approach_to_tooltip_map.items():
    approach = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'approach', 'label': key})
    if approach is not None:
        approach_id = str(approach['_id'])
        approach_extensions[approach_id] = {'label': key, 'tooltip': value}

approach_duration_extensions = {}
for key, value in approach_duration_to_tooltip_map.items():
    approach_duration = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'approachDuration', 'label': key})

    if approach_duration is not None:
        approach_duration_id = str(approach_duration['_id'])
        approach_duration_extensions[approach_duration_id] = {'label': key, 'tooltip': value}

################# ------------ MAP cause areas ---------- #################
for key, value in cause_area_map.items():
    cause = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'causes', 'label': value})
    if cause is None:
        continue

    cause_id = cause['_id']

    approaches = approach_cause_mapping.get(key, [])
    impacts = impact_cause_mapping.get(key, [])

    for impact in impacts:
        db_impact = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'impact', 'label': impact})
        label = db_impact.get('label')
        db_impact_id = str(db_impact.get('_id'))
        impact_extensions.setdefault(db_impact_id, {}).update({'label': label, 'causeId': cause_id})

    for approach in approaches:
        db_approach = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'approach', 'label': approach})
        label = db_approach.get('label')
        db_approach_id = str(db_approach.get('_id'))
        approach_extensions.setdefault(db_approach_id, {}).update({'label': label, 'causeId': cause_id})


################### ------ Map questions dependent on impacts -------- ######################
for key, item_dict in question_dependencies.items():
    values_dict = {}
    for value in item_dict['values']:
        impact = db().coll_vocabulary.find_one({'versions': VOCAB_V2, 'type': 'impact', 'label': value})

        if impact:
            label = impact.get('label')
            impact_id = str(impact.get('_id'))
            values_dict[impact_id] = label
        else:
            values_dict[value] = value

    question_dependencies[key]['values'] = values_dict

################## ----------- SAVE to database ----------- ###################3
db().coll_survey_data.find_one_and_replace({}, {
    'vocabularyExtensions': {
        'impact': impact_extensions,
        'programApproach': program_approach_extensions,
        'approach': approach_extensions,
        'approachDuration': approach_duration_extensions
    },
    'questionDependencies': question_dependencies
}, upsert=True)
