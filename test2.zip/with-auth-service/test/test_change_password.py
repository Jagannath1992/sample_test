import json

# TODO: need figure out how to create new user on cognito, for now just make sure we are not getting 500 error


def test_change_password(client, header):
    payload = {
        "challenge_name": "NEW_PASSWORD_REQUIRED",
        "family_name": "family name",
        "given_name": "given name",
        "new-password": "new password",
        "session": "O-zG3cpmXljNxQQegNC0rxQjXjrz5sPm7...",
        "username": "test.user@givewith.com",
    }
    response = client.post('/v1/user/change_password', data=json.dumps(payload), headers=header)
    assert response.status_code != 500

