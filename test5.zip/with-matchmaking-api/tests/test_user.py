import json
from datetime import datetime
from bson import ObjectId
from matchmaking.controllers.users import get_user_emails_in_deals, remove_user_emails_in_deals

def test_get_users(client, admin_header):
    response = client.get('/admin/users', headers=admin_header)
    assert response.status_code == 200


def test_get_user_by_id(client, user_id, admin_header):
    response = client.get('/admin/users/' + str(user_id) , headers=admin_header)
    assert response.status_code == 200


def test_update_user(client, user_id, admin_header):
    # get a user
    response = client.get('/admin/users/' + str(user_id), headers=admin_header)
    assert response.status_code == 200
    user = json.loads(response.data.decode())

    # change user first name
    old_name = user['first_name']
    new_name = user['first_name'] + str(datetime.now())
    user['first_name'] = new_name

    # update user
    response = client.put('/admin/users/' + str(user_id), data=json.dumps(user), headers=admin_header)
    assert response.status_code == 200

    # check new name after update
    response = client.get('/admin/users/' + str(user_id), headers=admin_header)
    assert response.status_code == 200
    user = json.loads(response.data.decode())
    assert user['first_name'] == new_name

    # revert changes because test connects to staging user pool
    user['first_name'] = old_name
    response = client.put('/admin/users/' + str(user_id), data=json.dumps(user), headers=admin_header)
    assert response.status_code == 200

def test_user_deletion_info(client, admin_header, user_id, brand_id):
    username = 'thisone@example.com'

    new_deal = {
        'fundingAmount' : 7000,
        'givewithCustomerUser' : str(user_id),
        'name' : 'test_user_deletion_info',
        'status' : 'PROGRAM_SELECTION_PENDING',
        'totalBudget' : 500000,
        'currency': 'USD',
        'givewithCustomerRole' : 'supplier',
        'managerName' : 'Elizabeth Chan',
        'manager' : str(user_id),
        'selectedRecommendedPrograms' : [],
        'isValid' : True,
        'clientEmails' : [
            username,
            'elizabeth.chan@givewith.com',
        ],
        'givewithCustomerEmails' : [
            'elizabeth.chan@givewith.com'
        ],
        'givewithCustomer' : str(brand_id),
        'client' : str(brand_id),
        'archived' : False,
    }

    # add the deal
    response = client.post('/admin/deals', data=json.dumps(new_deal), headers=admin_header)
    assert response.status_code == 200
    deal_id = json.loads(response.data.decode()).get('_id')

    deals = get_user_emails_in_deals(username, 'givewithCustomerEmails', 'clientEmails')

    # check if deal is included in query
    assert deals[0].get('_id') == ObjectId(deal_id)

    # check if deal email is removed

    remove_user_emails_in_deals(deals, username, 'givewithCustomerEmails', 'clientEmails')

    assert username not in deals[0].get('clientEmails')
