import logging

from threading import Lock

from research_api.logger import PipelineLogger
from research_api.mongodb import save_dataset, save_raw_dataset
from research_api.new_brands import new_brand_discovery
from research_api.patch import patch
from research_api.transformers.transformers import transform
from research_api.utils import GivewithError, PipelineError
from research_api.validators import clean
from research_api.fetchers.fetchers import fetch


def load_sasb_data():
    """
    load sasb data
    :return:
    """
    dataset = 'SASB'
    pipelines = [
        fetch,                  # Get the data from the source
        save_raw_dataset,       # If needed, saves the raw data
        clean,                  # Validate data and remove bad rows
        transform,              # Make calculations and format data
        patch,                  # Apply manual data patches
        new_brand_discovery,    # Check if there are any brands in the data that we are not aware of
        save_dataset            # Save the dataset to our DB
    ]
    lock = Lock()

    # try to acquire Lock, return error if lock is unavailable
    if not lock.acquire(blocking=False):
        raise GivewithError(f'{dataset} is currently running, please try again later', code=400)

    data = []
    current_stage = ''
    try:
        for stage in pipelines:
            current_stage = stage.__name__
            logging.info(f'Starting stage {current_stage} for dataset {dataset}')
            data = stage(dataset, data)

    except Exception as e:
        exception_str = f'{dataset} failed in stage {current_stage}'
        logging.exception(exception_str)
        raise PipelineError(exception_str, False)

    finally:
        lock.release()

    PipelineLogger.get_instance(dataset).flush()


load_sasb_data()
