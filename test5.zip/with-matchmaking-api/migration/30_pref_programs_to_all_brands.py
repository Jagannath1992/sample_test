from matchmaking import db

deal_brands = list(db().coll_brands.find())
for brand in deal_brands:
    brand_id = brand['_id']

    preferredPrograms = {
        'editing': False,
        'cart': [],
        'selected': [],
        'additional': [],
    }

    db().coll_brands.update_one({'_id' : brand_id}, {'$set': {'preferredPrograms': preferredPrograms}})
