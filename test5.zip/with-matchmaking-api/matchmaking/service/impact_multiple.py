from matchmaking.mongodb import db
from matchmaking.utils import GivewithError
from bson import ObjectId

SCC = 168
ENVIRONMENTAL_evidenceScore = 1
"""
expected program:
{
    'approach':[
        {
            '_id': '5d56e39082098a55e6ad6338',
            'evidenceScore': 1,
        },
        {
            '_id': ObjectId('123'),
            'conversionRateId': '5d56e39082098a55e6ad6336',
            'echoOutput': 123,
        }
    ],
    'participants': 123 # optional
}
"""
def calc_impact_multiple(program):
    if not ready_for_calc(program):
        return {'score': 0}

    # 1. social value / evidence score
    social_values = []
    evidenceScores = []

    for each in program['approach']:
        approach = db().coll_vocabulary.find_one({'_id': ObjectId(each['_id'])})
        if not approach:
            raise GivewithError('approach id not found: ' + str(each['_id']))

        # participant based
        if approach['category'] == 'participant':
            evidenceScore = each['evidenceScore']

            social_values.append(approach['value'] * evidenceScore * program['participants'])
            evidenceScores.append(evidenceScore)

        # environmental based
        elif approach['category'] == 'environmental':
            if 'conversionRateId' in each:
                if each['conversionRateId'] == 'N/A':
                    conversion_rate = {'value': 0}
                else:
                    conversion_rate = db().coll_program_scc_conversion.find_one({'_id': ObjectId(each['conversionRateId'])})
                    if not conversion_rate:
                        raise GivewithError('conversion rate not found: ' + each['conversionRateId'])

                social_values.append(each['echoOutput'] * SCC * conversion_rate['value'])
                evidenceScores.append(ENVIRONMENTAL_evidenceScore)

        else:
            raise GivewithError('invalid approach type. expect: participants or environmental')

    # 2. sum of social value / evidence score
    social_value_sum = 0
    for v in social_values:
        social_value_sum += v

    evidenceScore_sum = 0
    for v in evidenceScores:
        evidenceScore_sum += v

    # 3. fiscal catalyst
    fiscal_catalyst = (program.get('cashContributions', 0) + program.get('inKindContributions', 0))

    # 4. program budget
    program_budget = program['budget']

    # 5. apply discount to smaller number between fiscal and budget. if two have same value, don't change it.
    if fiscal_catalyst < program_budget:
        fiscal_catalyst = fiscal_catalyst * 0.4
    elif program_budget < fiscal_catalyst:
        program_budget = program_budget * 0.4

    # 6. divisor
    x = round((social_value_sum + fiscal_catalyst) / program_budget, 1)
    x = min(15.0, max(0.1, x))

    x_axis = round(x / 0.1 - 1)
    y_axis = round(evidenceScore_sum / len(program['approach']) * 100)

    divisor = db().coll_program_im_divisor.find_one({'index': y_axis})['value'][x_axis]

    # 7. final score
    score = round(x / divisor, 1)

    # 8. min sore is 1
    score = max(1, score)

    return {
        'score': score,
        'calculationDetails': {
            'socialValues': social_values,
            'socialValueSum': social_value_sum,
            'evidenceScores': evidenceScores,
            'evidenceScoreSum': evidenceScore_sum,
            'fiscalCatalyst': fiscal_catalyst,
            'totalProgramBudget': program_budget,
            'divisor': divisor,
            'xAxis': x_axis,
            'yAxis': y_axis,
        }
    }


def ready_for_calc(program):
    if 'budget' not in program:
        return False

    if 'approach' not in program or len(program['approach']) == 0:
        return False

    for each in program['approach']:
        approach = db().coll_vocabulary.find_one({'_id': ObjectId(each['_id'])})
        if approach:
            if approach['category'] == 'participant':
                if 'evidenceScore' not in each or 'participants' not in program:
                    return False

            if approach['category'] == 'environmental':
                if ('echoOutput' in each) != ('conversionRateId' in each):
                    return False

    return True
