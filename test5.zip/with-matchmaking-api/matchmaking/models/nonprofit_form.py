from bson.objectid import ObjectId
from datetime import datetime

"""
completed nonprofit schema form ready for approval
"""
completed_form_schema = {
    '_id': ObjectId,
    'applicationFormName': str,
    'slug': str,
    'editing': bool,
    'status': str,
    'percentComplete': int,
    'progress': {},
    'createdAt': datetime,
    'lastUpdated': datetime,
    'givewithAdmin': str,
    'createdBy': str,
    'general': {
        'name': {
            'legalOrganizationName': str,
            'publicOrganizationName': str,
        },
        'contact': {
            'name': str,
            'professionalTitle': str,
            'email': str,
            'phone': str,
        },
        'location': {
            'generalLocation': str,
            'specificLocation': str,
        },
        'missionAgreement': bool,
    },
    'overviewAndMission': {
        'historyDescription': str,
        'problemDescription': str,
        'causeAreas': {
            'selected': [str]
        },
        'initiativesDescription': str,
        'programLocations': str,
        'researchAndEvaluation': str,
        'lifetimeOutputs': [
            {
                'output': str,
                'quantity': int,
            }
        ],
    },
    'operationalInformation': {
        'staff': {
            'fullTime': str,
            'partTime':  str,
            'volunteers': str,
        },
        'partnershipsDescription': str,
        'yearlyBudget': str,
        'yearlyBudgetCurrency': str,
        'financialStatement': {},
        'supportersAndPartners': str,
    },
    'review': {
        'name': str,
        'email': str,
    }
}


"""
schema for initialize nonprofit form
"""
init_form_request_schema = {
    'applicationFormName': str,
    'givewithAdmin': str,
}
