# TODO: error check and exit for no mongo_url or mongo_database
import pandas as pd

from os import environ
from datetime import datetime, timezone

from bson import ObjectId
from pymongo import MongoClient, DESCENDING, ASCENDING, errors, UpdateOne
from pymongo.errors import BulkWriteError

from .logger import log_exception, log_info, PipelineLogger
from .utils import DatasetNotFound, GivewithError, expand_dot_fields, remove_empty
from .loggly import get_logger
from fuzzywuzzy import fuzz

DB_URL = environ.get('MONGO_URL', 'no mongo url')
if not DB_URL:
    raise GivewithError('DB_URL ENV variable not set')

MONGO_DATABASE = environ.get('MONGO_DATABASE', 'undefined_database_env_var')
if not MONGO_DATABASE:
    raise GivewithError('MONGO_DATABASE ENV variable not set')


VOCAB_V1 = {'$in': [1]}
VOCAB_V2 = {'$in': [2]}

__db = None
mongo_db = None

INDUSTRY_MAPPINGS_MEMO = {}


class DBCollections():

    vocabulary_list = []
    original_labels_map = []
    map_label_to_id = []
    map_type_label_to_id = []
    map_type_label_to_description = []
    map_id_to_label = []
    map_code_to_id = []
    map_label_to_type = []
    map_code_to_type = []
    map_id_to_dict = []
    vocabulary_typos_remove = []
    vocabulary_typos_replace = []
    vocabulary_fields = set()

    __attr_to_collection = {
        'coll_configs': 'mm_api_configs',
        'coll_brands': 'mm_brands',
        'coll_contacts': 'mm_contacts',
        'coll_nonprofits': 'mm_nonprofits',
        'coll_programs': 'mm_programs',
        'coll_settings': 'mm_settings',
        'coll_tagging_rules': 'mm_tagging_rules',
        'coll_tag_to_field': 'mm_tag_to_field',
        'coll_vocabulary': 'mm_vocabulary',
        'coll_vocabulary_typos': 'mm_vocabulary_typos',
        'coll_gics': 'gics_weights',
        'coll_comm_settings': 'comm_settings',
        'coll_user': 'user',
        'coll_counters': 'counters',
        'coll_deals': 'deals',
        'coll_nielsen_base_responses': 'nielsen_base_responses',
        'coll_nielsen_respondents': 'nielsen_respondents',
        'coll_nielsen_responses': 'nielsen_responses',
        'coll_campaigns': 'campaign',
        'coll_location_data': 'location_data',
        'coll_csrit_raw_data': 'csrit_raw_data',
        'coll_csrit_raw_data_old': 'csrit_raw_data_old',
        'coll_csrit_lookup': 'csrit_lookup',
        'coll_csrit_lookup_old': 'csrit_lookup_old',
        'coll_tvl_data': 'tvl_data',
        'coll_meta': 'meta',
        'coll_tvl_raw_data': 'tvl_raw_data',
        'coll_industry_mappings': 'gics_industry_mappings',
        'coll_new_research_brands': 'new_research_brands',
        'coll_dataset_patches': 'dataset_patches',
        'msci_industry_averages': 'msci_industry_averages',#TODO fix
        'coll_csrhub': 'csrhub',
    }

    def __init__(self, db):
        self.db = db

    def __getattr__(self, item):
        col_name = DBCollections.__attr_to_collection.get(item)
        if not col_name:
            raise Exception(f'Unknown collection {item} in MongoDB')
        return self.db.get_collection(col_name)


def init_db(app=None):
    global __db
    global mongo_db

    client = MongoClient(DB_URL)
    mongo_db = client.get_database(MONGO_DATABASE)
    __db = DBCollections(mongo_db)
    reload_vocabulary()


def db():
    return __db


def get_mongo_db():
    return mongo_db

def add_vocab(vocab_dict, vocab_type):
    vocab = {}
    for key_word, label in vocab_dict.items():
        vocab[key_word] = db().coll_vocabulary.find_one_and_update({'label': label, "type": vocab_type}, {'$set': {'label': label, "type": vocab_type}}, upsert=True)
    return vocab
    
def reload_vocabulary():
    vocabulary_typos_list = list(db().coll_vocabulary_typos.find().sort([('type', ASCENDING)]))

    vocabulary_list = db().vocabulary_list = list(db().coll_vocabulary.find({'versions': VOCAB_V1})
                                                  .sort([('type', ASCENDING), ('label', ASCENDING)]))

    db().original_labels_map = {r['label'].lower(): r['label'] for r in vocabulary_list}
    db().map_id_to_label = {r['_id']: r['label'].lower() for r in vocabulary_list}
    db().map_label_to_id = {v: k for k, v in db().map_id_to_label.items()}
    db().map_type_label_to_id = {'%s:%s' % (r['type'], r['label'].lower()): r['_id'] for r in vocabulary_list}
    db().map_type_label_to_description = {'%s:%s' % (r['type'], r['label'].lower()): r.get('description', '') for r in vocabulary_list}
    db().map_code_to_id = {r['code']: r['_id'] for r in vocabulary_list if 'code' in r}
    db().map_label_to_type = {r['label']: r['type'] for r in vocabulary_list}
    db().map_code_to_type = {r['code']: r['type'] for r in vocabulary_list if 'code' in r}
    db().map_id_to_dict = {r['_id']: r for r in vocabulary_list}
    db().vocabulary_typos_remove = [r['value'] for r in vocabulary_typos_list if r['type'] == 'remove']
    db().vocabulary_typos_replace = {r['from']: r['to'] for r in vocabulary_typos_list if r['type'] == 'replace'}

    # get_object_id_fields(schema_program, db().vocabulary_fields)
    # get_object_id_fields(schema_brand, db().vocabulary_fields)
    # get_object_id_fields(schema_nonprofit, db().vocabulary_fields)

    try:
        db().vocabulary_fields.remove('_id')
    except KeyError:
        pass

    try:
        db().vocabulary_fields.remove('nonprofit')
    except KeyError:
        pass
    # check_and_create_counters_collection()


def get_nonprofits():
    return list(db().coll_nonprofits.find({}, projection={'_id': True, 'name': True, 'tax_id': True}))


def get_lookup_data(dataset):
    if dataset == 'CSRIT':
        result = db().coll_csrit_lookup.find_one()
        result.pop('_id', None)
        return result
    else:
        raise DatasetNotFound()


def save_dataset(dataset, data):
    if dataset == 'CSRIT':
        _save_csrit(data)

    elif dataset == 'MSCI':
        _save_msci(dataset, data)

    elif dataset == 'SASB':
        _save_sasb(dataset, data)

    elif dataset == 'TVL':
        _save_tvl(data)

    elif dataset == 'CSRHUB':
        _save_csrhub(dataset, data)

    elif dataset == 'NIELSEN':
        _save_nielsen(data)

    else:
        raise DatasetNotFound('Dataset not found, no data saved')


def save_raw_dataset(dataset, data):
    if dataset == 'CSRIT':
        _save_raw_csrit(data)
        return data

    elif dataset == 'MSCI':
        get_logger().info(f'Skip save_raw_dataset for {dataset}')
        pass
        return data

    elif dataset == 'SASB':
        pass
        return data

    elif dataset == 'CSRHUB':
        pass
        return data

    elif dataset == 'TVL':
        _save_raw_tvl(data)
        return data

    elif dataset == 'NIELSEN':
        pass
        return data

    else:
        raise DatasetNotFound('Dataset not found, no data saved')


# TODO: use _overwrite_collection()
def _save_raw_csrit(data):
    """Save CsrIT data to database
    Replaces existing collections if any and reverts db state on failure

    Arguments:
        csrit_raw_data {([dict], [dict])} -- csrit data retrieved from sheets

    Returns:
        bool -- True if successful and false on failure
    """
    # TODO: Save narratives as well
    csrit_lookup, csrit_data, *_ = data

    if csrit_lookup and csrit_data:
        collection_names = db().db.list_collection_names()

        if 'csrit_raw_data' in collection_names:
            db().coll_csrit_raw_data.rename('csrit_raw_data_old')

        if 'csrit_lookup' in collection_names:
            db().coll_csrit_lookup.rename('csrit_lookup_old')

        csrit_data_result = db().coll_csrit_raw_data.insert_many(csrit_data)
        csrit_lookup_result = db().coll_csrit_lookup.insert_many(csrit_lookup)

        if csrit_data_result and csrit_lookup_result:
            db().coll_csrit_raw_data_old.drop()
            db().coll_csrit_lookup_old.drop()

        else:
            db().coll_csrit_raw_data.drop()
            db().coll_csrit_lookup.drop()

            collection_names = db().db.list_collection_names()

            # Revert Changes
            if 'csrit_raw_data_old' in collection_names:
                db().coll_csrit_raw_data_old.rename('csrit_raw_data')

            if 'csrit_lookup_old' in collection_names:
                db().coll_csrit_lookup_old.rename('csrit_lookup')

            PipelineLogger.get_instance('CSRIT').log_exception('Failed to updated csrit data, reverted to old version')
            raise GivewithError('Failed to updated csrit data, reverted to old version', code=500)

    else:
        PipelineLogger.get_instance('CSRIT').log_exception('save_csrit_data called with an invalid tuple')
        raise GivewithError('Missing required payload to update csrit data', code=500)

    return


def _save_csrit(data):
    succeeded = 0
    failed = 0

    nonprofits = get_nonprofits()
    nonprofits_by_tax_id = {nonprofit.get('tax_id'): nonprofit for nonprofit in nonprofits}
    nonprofits_by_name = {nonprofit.get('name'): nonprofit for nonprofit in nonprofits}
    sdg_vocabulary_map = {r['code']: r['label'] for r in db().vocabulary_list if r.get('type') == 'sdg'}

    for _id, doc in data.items():
        # if applicable here -> try and remove the none values por favor -> CSRIT is super dirty right now
        commitments = doc.get('researchCorpCommitments', {})

        ### Transform sdgs to vocabulary Labels ------------------------
        sdgs = commitments.get('sdgs')
        if sdgs:
            formatted_sdgs = [f'SDG {sdg}' for sdg in sdgs]
            commitments['sdgLabels'] = [sdg_vocabulary_map[code] for code in formatted_sdgs if sdg_vocabulary_map.get(code)]

        ### Transform nonprofits to Ids where possible and split into preferred and non_gw_preferred ---------
        other_nonprofit_names = list(commitments.pop('otherNonprofits', {}).values())
        nonprofits_dict = commitments.pop('nonprofits', {})

        if nonprofits_dict:
            nonprofit_ids, not_found = get_nonprofit_ids(nonprofits_dict, nonprofits_by_tax_id, nonprofits_by_name)
            other_nonprofit_names.extend(not_found.values())

            if nonprofit_ids:
                commitments.setdefault('nonprofits', {}).update({'preferred': nonprofit_ids})

        if other_nonprofit_names:
            commitments.setdefault('nonprofits', {}).update({'nonGwPreferred': other_nonprofit_names})

        try:
            update_query = {'$set': {'researchCorpCommitments': remove_empty(commitments)}}
            db().coll_brands.update_one({'_id': _id}, update_query)
            succeeded += 1

        except Exception as e:
            PipelineLogger.get_instance('CSRIT').log_exception(e)
            failed += 1

    PipelineLogger.get_instance('CSRIT').log_info('Succeeded: ' + str(succeeded))
    PipelineLogger.get_instance('CSRIT').log_info('Failed: ' + str(failed))
    return {
        'Succeeded': succeeded,
        'Failed': failed
    }


def _save_msci(dataset, data):

    get_logger().info(f'Start saving into database for {dataset}')

    averages = data[1].reset_index().to_dict('records')
    _overwrite_collection(db().msci_industry_averages, averages)

    data = data[0]
    update_msci_timestamp()

    # Move all msci data to msci_old
    db().coll_brands.update_many({'msci': {'$exists': True}}, {'$rename': {'msci': 'msci_old'}});

    try:
        # Update Brands in database
        if len(data) > 0:
            result = update_bulk_brands(dataset, data.to_dict('record'))

    except:
        # If we failed, move msci_old back
        try:
            db().coll_brands.update_many({'msci_old': {'$exists': True}}, {'$rename': {'msci_old': 'msci'}});
        except:
            raise GivewithError('MSCI couldn\'t move `msci_old` back to `msci`, please restore manually')

        raise GivewithError('Failed uploading MSCI to mongo')

    # Delete msci_old
    db().coll_brands.update_many({'msci_old': {'$exists': True}}, {'$unset': {'msci_old': ''}});
    get_logger().info(f'Finished saving into database for {dataset}')


def get_nonprofit_ids(nonprofits_dict, nonprofits_by_tax_id, nonprofits_by_name):
    """ Transforms a dictionary containing nonprofit taxIds and names to a list of nonprofit
    ObjectIds. Returns the non nonprofits that didn't exist in the db as a second value
    """
    nonprofit_ids = []
    not_found = {}  # the items in the nonprofits_dict that weren't found

    for tax_id, name in nonprofits_dict.items():
        nonprofit = nonprofits_by_tax_id.get(tax_id) or nonprofits_by_name.get(name)
        if nonprofit:
            nonprofit_ids.append(nonprofit.get('_id'))
        else:
            not_found[tax_id] = name

    return nonprofit_ids, not_found


#TODO: Only works with MSCI and SASB right now, make generic
def update_bulk_brands(dataset, update_list):
    """ Updates the brand's <DATASET> object """

    updates = []
    for document in update_list:
        update = {'$set':
            {dataset.lower(): document}
        }

        # Update a brand's top level fields
        if dataset == 'MSCI':
            update['$set']['industry'] = document['industry']

        updates.append(
            UpdateOne(
                filter={'ISIN': document['ISIN']},
                update=update,
                upsert=False
            ))

    if updates:
        try:
            result = db().coll_brands.bulk_write(updates)
            return result.bulk_api_result
        except BulkWriteError as e:
            log_exception(e.details)
            raise
        except Exception as e:
            log_exception(e)
            raise


def get_vocabulary_industries():
    # List of industry labels in vocabulary
    return set(
        filter(
            None,
            map(lambda x: x[0] if x[1] == 'industry' else None,
                db().map_label_to_type.items())
        )
    )


def update_msci_timestamp():
    timestamp = datetime.utcnow() \
                        .replace(tzinfo=timezone.utc, microsecond=0) \
                        .isoformat()

    db().coll_settings.update_many({}, {'$set': {'csv.msciLastUpdated': timestamp}})


def _save_raw_tvl(data):
    tvl_raw_collection = db().coll_tvl_raw_data

    raw_data = []
    for score_type, df in data:
        for row in df.to_dict('record'):
            raw_data.append({'type': score_type, 'data': row})

    return _overwrite_collection(tvl_raw_collection, raw_data)

def _save_tvl(data):
    data = data.to_dict('records')
    to_save = []
    for brand in data:
        brand = expand_dot_fields(brand)

        if type(brand['TICKER']) == str:
            to_save.append(brand)
        else:
            log_info('TVL doesn\'t have complete data for: ' + brand.get('ISIN'))

    result = _overwrite_collection(db().coll_tvl_data, to_save)
    return result


def _save_nielsen(data):
    panelists, responses, base_responses = data
    try:
        log_info('Updating nielsen_respondents')
        _overwrite_collection(db().coll_nielsen_respondents, panelists.values())

        log_info('Updating nielsen_responses')
        _overwrite_collection(db().coll_nielsen_responses, responses)

        log_info('Updating nielsen_base_responses')
        _overwrite_collection(db().coll_nielsen_base_responses, base_responses)

    except BulkWriteError as e:
        log_exception(e)
        raise
    except Exception as e:
        log_exception(e)
        raise


def _overwrite_collection(collection, data):
    """ Overwrites a collection and restores on failure """
    if data:
        collection_name_old = f'{collection.name}_old'

        # Save a backup if one exists
        old_indexes = []
        if collection.name in db().db.list_collection_names():
            old_indexes = collection.index_information()
            collection.rename(collection_name_old)

        result = collection.insert_many(data)

        if old_indexes:
            for name, index_info in old_indexes.items():
                collection.create_index(keys=index_info['key'], name=name)

        if result:
            db().db.get_collection(collection_name_old).drop()
            return True

        else:
            collection.drop()

            # Revert Changes
            db().db.get_collection(collection_name_old).rename(collection.name)

            raise GivewithError('Failed to updated collection, reverted to old version', code=500)

    else:
        raise GivewithError('Missing required payload to update collection', code=500)

    return False


def get_vocabulary_id(label, _type):
    """ Gets a vocabulary's id from a label"""
    result = db().coll_vocabulary.find_one({'type': _type, 'versions': VOCAB_V2, 'label': label})
    if not result:
        raise GivewithError(f'No {_type} found for in vocab with label: {label}')
    else:
        return result['_id']

def get_theme_id(label):
    """ Gets a theme's id from a theme's label """
    return get_vocabulary_id(label, _type='themes')


def get_all_brands(projection={}):
    """ Returns a cursor with all brands """
    return db().coll_brands.find(filter={}, projection=projection)


def _save_sasb(dataset, data):
    pass

def get_gics_industry(industry, dataset):
    global INDUSTRY_MAPPINGS_MEMO

    # No industry
    if not industry or pd.isna(industry):
        log_info('Warning: no industry')
        return ''

    if dataset not in INDUSTRY_MAPPINGS_MEMO:
        INDUSTRY_MAPPINGS_MEMO[dataset] = {}

    if industry not in INDUSTRY_MAPPINGS_MEMO[dataset]:
        result = db().coll_industry_mappings.find_one({
            'type': dataset.lower(),
            'industry': industry
        })

        if not result:
            raise GivewithError(f'Missing industry: {industry}')

        INDUSTRY_MAPPINGS_MEMO[dataset][industry] = result['gics_industry']

    if industry not in INDUSTRY_MAPPINGS_MEMO[dataset]:
        raise GivewithError(f'No industry found with name {industry}')

    return INDUSTRY_MAPPINGS_MEMO[dataset][industry]


def get_sasb_vocab():
    vocab = dict()

    cursor = db().coll_vocabulary.find({'type': 'sasb', 'versions': VOCAB_V2})
    for document in cursor:
        doc_id = str(document['_id'])
        vocab[document['label']] = doc_id

    return vocab

def get_dataset_patches(dataset):
    return db().coll_dataset_patches.find({'source': dataset})


def _save_csrhub(dataset, data):
    pass


