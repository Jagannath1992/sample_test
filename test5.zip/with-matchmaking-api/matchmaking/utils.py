# -*- coding: utf-8 -*-
from typing import List, Dict, Union
import locale
import random
import re
import string
import secrets
import time
import pandas as pd
import collections
import boto3
import math
import sys
import logging
import os.path
import socket

from io import BytesIO
from PIL import Image
from itertools import filterfalse, chain
from os import environ
from _decimal import Decimal
from collections import namedtuple
from datetime import datetime, date
from enum import Enum, unique
from bson import ObjectId
from deepdiff import DeepDiff
from flask.json import JSONEncoder
from pymongo.cursor import Cursor
from botocore.exceptions import ClientError
from .models.models import v, RecommendationItem, PROGRAM_SURVEY_MAP
from logging.handlers import  SysLogHandler
from flask import current_app, request
from werkzeug.utils import secure_filename
from .s3 import load_file
from bson import objectid

DATETIME_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'
AWS_REGION = environ.get('COGNITO_AWS_REGION', 'us-east-1')

DEFAULT_GIVEWITH_PERCENTAGE = 2
SERVER_IP = '127.0.0.1'

openshift_deploy = environ.get('OPENSHIFT_DEPLOY', 'False')
syslog_host = environ.get('SYSLOG_HOST', '')

class GivewithJSONEncoder(JSONEncoder):
    def default(self, obj): # pylint: disable=E0202
        if isinstance(obj, ObjectId):
            return str(obj)
        elif isinstance(obj, bytes):
            return str(obj, 'utf-8')
        elif isinstance(obj, Cursor):
            return [self.default(i) for i in obj]
        elif isinstance(obj, Decimal):
            return float(obj)
        elif isinstance(obj, (datetime, date)):
            return obj.strftime(DATETIME_FORMAT)
        elif isinstance(obj, RecommendationItem):
            return obj.tojson()
        elif isinstance(obj, GivewithErrorType):
            return obj.name
        return JSONEncoder.default(self, obj)


def set_created_at(document):
    document['createdAt'] = document['lastUpdated'] = datetime.utcnow()
    return document


def set_last_updated(document):
    document['lastUpdated'] = datetime.utcnow()
    return document


def set_last_updated_by(document):
    if hasattr(request, 'user'):
        document['lastUpdatedBy'] = {
            '_id': request.user['_id'],
            'name': request.user['name'],
            'username': request.user['username']
        }

    return document

def is_deal_link_expired(document):
    status = document.get('status')
    return DealStatus.get(status) == DealStatus.DEAL_LOST


def inject_key(entity):
    # ensure same key if the entity has an _id
    if '_id' in entity:
        random.seed(str(entity['_id']))
    elif 'slug' in entity:
        random.seed(entity['slug'])
    entity['key'] = random.getrandbits(64)
    return entity


def ensure_valid_elements(document: list, *args):
    try:
        for arg in args:
            document[arg] = [item for item in document[arg] if type(item) != dict or any(item.values())]
    except KeyError:
        pass  # ignored


# this function recursively searches for all objectIds and converts them to strings in a nested entity
# returns None, has side effects
def object_ids_to_strings(entity):
    if type(entity) == dict:
        for key, value in entity.items():
            entity[key] = object_ids_to_strings(value)
    elif type(entity) == list:
        for value in entity:
            return [object_ids_to_strings(x) for x in entity]
    elif type(entity) == ObjectId:
        return str(entity)

    return entity


# this function recursively searches all fields and converts them to object id if possible.
# returns None, has side effects
def replace_object_ids(json):
    if json is None:
        return json

    if objectid.ObjectId.is_valid(json):
        return objectid.ObjectId(json)

    if type(json) == dict:
        for key, value in json.items():
            json[key] = replace_object_ids(value)

    if type(json) == list:
        return [replace_object_ids(x) for x in json]

    return json

def get_locale_string():
    default_locale = 'en_US'
    try:
        defined_locale = locale.getlocale()[0]
        if defined_locale:
            return defined_locale
    except ValueError:
        pass

    return default_locale


def set_booleans(document):
    if type(document) == list:
        for row in document:
            set_booleans(row)
    elif type(document) == dict:
        for key, value in document.items():
            if type(value) in [dict, list]:
                set_booleans(value)
            elif type(value) == str:
                if value.lower() == 'yes':
                    document[key] = True
                elif value.lower() == 'no':
                    document[key] = False


def is_empty(value):
    if type(value) in (int, bool):
        return False
    if type(value) == str:
        return not value.strip()
    if type(value) == float:
        return math.isnan(value)

    return not value


def remove_empty(document):

    filtered = {key: value for key, value in document.items() if not is_empty(value)}

    document.clear()
    for key, value in filtered.items():
        if type(value) == list:
            if all(isinstance(n, dict) for n in value):
                value = [remove_empty(n) for n in value]
            else:
                value = list(filterfalse(is_empty, value))
        if type(value) == dict:
            value = remove_empty(value)

        if not is_empty(value):
            document[key] = value

    return document


def format_cerberus_errors_for_csv(errors, field_to_column):
    errors_dic = {}
    for key, value in errors.items():
        try:
            errors_dic[field_to_column[key]] = value
        except KeyError:
            errors_dic[key] = value

    return str(errors_dic)


def cerberus_error_messages_extractor(errors):
    messages = []

    for key, value in errors.items():
        if type(value) == list:
            if all(isinstance(n, dict) for n in value):
                [messages.extend(cerberus_error_messages_extractor(n)) for n in value]
            elif all(isinstance(n, str) for n in value):
                [messages.append(n) for n in value]
        if type(value) == dict:
            messages.extend(cerberus_error_messages_extractor(value))
        if type(value) == str:
            messages.append(value)

    return messages


def _convert_to_int_if_possible(text):
    return int(text) if text.isdigit() else text


def natural_sort(key):
    return [_convert_to_int_if_possible(c) for c in re.split(r'(\d+)', key.lower())]


def check_is_objid(value):
    if value:
        return re.match(r'^(?=[a-f\d]{24}$)(\d+[a-f]|[a-f]+\d)', value)
    return None


def ses_send_email(from_address, to_addresses, subject, body_html, body_text='', reply_to_addresses=None):
    """Send email with Amazon SES

    Args:
        name {string} -- send from display name
        from_address {string} -- send from email address
        to_addresses {list} -- list containing send to email addresses
        subject {string} -- subject of email
        body_html {string} -- html formatted message
        body_text {string} -- plain string formatted message (default: {''})
        reply_to_addresses {list} -- list containing reply to addresses (defaul: {''})

    Returns:
        Boto3 response object

    Raises:
        GiveWithError

    """
    client = boto3.client('ses', region_name=AWS_REGION)
    charset = 'UTF-8'

    try:
        response = client.send_email(
            Source=from_address,
            Destination={'ToAddresses': to_addresses},
            Message={'Body': {'Html': {'Charset': charset, 'Data': body_html},
                              'Text': {'Charset': charset, 'Data': body_text}},
                     'Subject': {'Charset': charset, 'Data': subject}},
            ReplyToAddresses=reply_to_addresses
        )
    except ClientError as exz:
        print(exz.response.get('Error', {}).get('Message'), file=sys.stderr)
        raise GivewithError('An error occurred, please try again later', code=400)
    except Exception as exz:
        print(exz, file=sys.stderr)
        raise GivewithError('A system error occurred, please try again later', code=500)
    else:
        return response.get('MessageId')


def format_to_html(*args):
    """Convert String to HTML

    Args:
    args {list} -- strings to convert to html
    Returns:
      string -- html encoded string
    """
    html_string = ''.join('<p>{}</p>'.format(text.replace('\n', '<br>')) for text in args)
    return html_string


class GivewithErrorType(str, Enum):
    ERROR = 'ERROR'
    MAINTENANCE = 'MAINTENANCE'
    SUCCESS = 'SUCCESS'


class GivewithError(Exception):
    def __init__(self, *args, **kwargs):
        super().__init__(args[0])
        self.code = kwargs.get('code', 400)
        self.type = kwargs.get('type', GivewithErrorType.ERROR)


MissingVocabularyError = namedtuple('MissingVocabularyError', ['key', 'value'])


class MissingVocabulary(Exception):
    def __init__(self, vocab_errors: List[MissingVocabularyError]):
        Exception.__init__(self)
        self.vocab_errors = vocab_errors

    def __str__(self):
        messages = []
        for ex in self.vocab_errors:
            messages.append('column {0}:{1}'.format(ex.key, ex.value))

        return 'Missing vocabularies on {0}'.format(messages)


class UnsupportedId(GivewithError):
    def __init__(self, id, *args, **kwargs):
        super().__init__(args, kwargs)
        self.id = id

    def __str__(self):
        return 'The id {0} is not valid'.format(self.id)


class UnsupportedPayload(GivewithError):
    def __str__(self):
        return 'Unable to parse payload'


class InvalidPayload(GivewithError):
    def __init__(self, validation_errors, *args, **kwargs):
        super().__init__(args, kwargs)
        self.validation_errors = validation_errors

    def __str__(self):
        return 'Payload has invalid document: {0}'.format(self.validation_errors)


class MissingAttribute(GivewithError):
    def __init__(self, attribute, *args, **kwargs):
        super().__init__(args, kwargs)
        self.attribute = attribute

    def __str__(self):
        return 'Missing required attribute "{}"'.format(self.attribute)


class EntityNotFound(GivewithError):
    def __init__(self, entity, id=None, *args, **kwargs):
        super().__init__(args, kwargs)
        self.entity = entity
        self.id = id
        self.code = 404

    def __str__(self):
        if self.id is None:
            return 'The collection {0} is either empty or does not exist'.format(self.entity)
        else:
            return 'Unable to find {0} with id {1}'.format(self.entity, self.id)


class MaintenanceMode(GivewithError):
    def __init__(self, message):
        self.code = 503
        self.type = GivewithErrorType.MAINTENANCE
        self.message = message

    def __str__(self):
        return self.message


class ValidationError(GivewithError):
    def __init__(self, errors, *args, **kwargs):
        super().__init__(args, kwargs)
        messages = cerberus_error_messages_extractor(errors)

        self.message = '. '.join(messages)

    def __str__(self):
        return self.message


@unique
class DealStatus(Enum):
    """Enum Representing deal Statuses
    Each deal status has a string value: name and an integer value: value
    String value is used for display/storing in database
    Int value specifies the weights/order for the dealstatuses
    """
    PROGRAM_SELECTION_PENDING = 1
    CONFIRMATION_PENDING = 2
    PAYMENT_PENDING = 3
    COMPLETE = 4
    DEAL_LOST = 0

    def __str__(self):
        return self.name

    def __int__(self):
        return self.value

    def __gt__(self, other):
        return self.value > other.value

    def __lt__(self, other):
        return self.value < other.value

    def __ge__(self, other):
        return self.value >= other.value

    def __le__(self, other):
        return self.value <= other.value

    @classmethod
    def get(cls, name, default=None):
        name = name.upper()
        if name in cls.__members__: # pylint: disable=unsupported-membership-test
            return cls[name]
        else:
            return default

@unique
class SurveyStatus(Enum):
    """Enum Representing survey Statuses
    Each survey status has a string value: name and an integer value: value
    String value is used for display/storing in database
    Int value specifies the weights/order for the survey statuses
    NOTE: PSF only implements the first 3 statuses, PFF has all 5 statuses
    """
    IN_PROGRESS = 0
    SUBMITTED = 1
    APPROVED = 2
    EXECUTED = 3

    def __str__(self):
        return self.name

    def __int__(self):
        return self.value

@unique
class UserDepartments(Enum):
    """Enum Representing user departments
    """
    PROCUREMENT = 'Procurement'
    SALES = 'Sales'
    CSR = 'CSR'
    MARKETING = 'Marketing'
    OTHER = 'Other'

    def __str__(self):
        return self.name

class RolesByDepartment(Enum):
    Procurement = 'buyer'
    Sales = 'supplier'
    CSR = 'supplier'
    Marketing = 'supplier'
    Other = 'supplier'

    def __str__(self):
        return self.value

def timely(f):
    def decorator(*args, **kw):
        ts = time.time()
        try:
            result = f(*args, **kw)
            return result
        except Exception:
            raise
        finally:
            te = time.time()

            if 'log_time' in kw:
                name = kw.get('log_name', f.__name__.upper())
                kw['log_time'][name] = int((te - ts) * 1000)
            else:
                from flask import current_app
                current_app.logger.debug('Method {} executed in {:.2f}ms'.format(f.__name__, (te - ts) * 1000))

    return decorator


def check_data_encoding(func):
    def decorator(data):
        if not data:
            raise GivewithError('No data to parse from file')

        try:
            csv_string = data.decode('utf-8')
        except UnicodeDecodeError:
            try:
                csv_string = data.decode('iso-8859-1')
            except UnicodeDecodeError:
                raise GivewithError('Unsupported encoding, we only support utf-8 or iso-8859-1')

        return func(csv_string)
    return decorator


def validate_documents(name, documents, schema):
    for index, document in enumerate(documents):
        v.validate(document, schema)
        # validate CSV only
        if v.errors:
            msg = format_cerberus_errors_for_csv(v.errors, {})
            current_app.logger.error(f'{name} validation error on row {index} - {msg}')
            raise GivewithError('Unable to import CSV entries, '
                                f'validation error on row {index} - {msg}')


def get_mean_std(target_df):
    all_raw_weights = pd.Series(list(chain(*target_df.values)))
    global_mean = all_raw_weights.mean()
    global_std = all_raw_weights.std()
    return global_mean, global_std


def dict_merge(dct, merge_dct, add_keys=True, in_place=False):
    """ Recursive dict merge. Inspired by :meth:``dict.update()``, instead of
    updating only top-level keys, dict_merge recurses down into dicts nested
    to an arbitrary depth, updating keys. The ``merge_dct`` is merged into
    ``dct``.

    This version will return a copy of the dictionary and leave the original
    arguments untouched.
    NOTE: this may not be true for deeply nested dictionaries with lists etc.
    careful when using this function

    The optional argument ``add_keys``, determines whether keys which are
    present in ``merge_dict`` but not ``dct`` should be included in the
    new dict.

    Args:
        dct (dict) onto which the merge is executed
        merge_dct (dict): dct merged into dct
        add_keys (bool): whether to add new keys

    Returns:
        dict: updated dict
    """
    if not in_place:
        dct = dct.copy()

    if not add_keys:
        merge_dct = {
            k: merge_dct[k]
            for k in set(dct).intersection(set(merge_dct))
        }

    for k, v in merge_dct.items():
        if isinstance(dct.get(k), dict) and isinstance(v, collections.Mapping):
            dct[k] = dict_merge(dct[k], v, add_keys=add_keys, in_place=in_place)
        else:
            dct[k] = v

    return dct


def clean_nonprofits(nonprofit):
    nonprofit.pop('imageLandscape', None)
    nonprofit.pop('imagePortrait', None)

    return nonprofit


def create_validation_error_response(field):
    raise MissingAttribute(field)


def remove_none(L):
    return list(filter(None.__ne__, L))


def generate_random_slug(length=15):
    return generate_secure_random_string(length)

def generate_secure_password(length=12):
    return generate_secure_random_string(length)

def generate_secure_random_string(length):
    """ From official python docs: https://docs.python.org/3/library/secrets.html """
    alphabet = string.ascii_letters + string.digits
    while True:
        password = ''.join(secrets.choice(alphabet) for i in range(length))
        if (any(c.islower() for c in password)
                and any(c.isupper() for c in password)
                and sum(c.isdigit() for c in password) >= 3):
            break

    return password

def get_user_role(users_brand_id, proposal):
    """
    Returns 'givewithCustomer' if user is the givewith customer,
    'client' if user is the client, and False if neither
    """
    if proposal['givewithCustomer'] == users_brand_id:
        return 'givewithCustomer'
    elif proposal['client'] == users_brand_id:
        return 'client'
    else:
        return None


def get_descendant_key(dict_item, desc_str, default_value):
    """
    Get a descendant key of a dictionary using a dot separated string
    """
    arr = desc_str.split('.')

    while arr and dict_item:
        dict_item = dict_item.get(arr.pop(0), None)

    return dict_item if dict_item is not None else default_value


def pop_descendant_key(dict_item, desc_str, default_value, pop_level=-1):
    """
    Pops a descendant key of a dictionary and returns it
    if pop_level is specified, pop happens at that level of the descendant key string
    even though the descendant key specified is still returned
    i.e if desc_str = a.b.c.d and pop_level = 1, the value of a.b.c.d is returned but
    b (position 1) is popped from the array
    NOTE: this method has side effects as expected of a pop operation
    """
    arr = desc_str.split('.')
    level = 0

    while arr and dict_item:
        if level == pop_level:
            dict_item = dict_item.pop(arr.pop(0), None)
        elif len(arr) == 1 and pop_level == -1:
            dict_item = dict_item.pop(arr.pop(0), None)
        else:
            dict_item = dict_item.get(arr.pop(0), None)

        level += 1

    return dict_item if dict_item is not None else default_value


def set_descendant_key(value, dict_item, desc_str):
    """
    Sets a descendant key of a dictionary as value
    """
    arr = desc_str.split('.')

    while len(arr) > 1:
        dict_item = dict_item.setdefault(arr.pop(0), {})

    dict_item[arr.pop(0)] = value


def init_loggly():
    logger = logging.getLogger('MM-API')
    logger.setLevel(logging.INFO)
    if os.path.exists('/dev/log'):
        handler = SysLogHandler('/dev/log')
    else:
        handler = logging.NullHandler()
    if openshift_deploy == "True":
        handler = SysLogHandler(address = (syslog_host,514))
    formatter = logging.Formatter(
        'Python: { "loggerName":"%(name)s", \
            "timestamp":"%(asctime)s", \
            "logRecordCreationTime":"%(created)f", \
            "time":"%(msecs)d", \
            "message":"%(message)s"}'
    )
    handler.formatter = formatter
    logger.addHandler(handler)
    global SERVER_IP
    SERVER_IP = str(get_ip())
    logger.info('Init logging on MM-API on ' + SERVER_IP)


def send_loggly(msg):
    msg = str(msg) + '; server_ip: ' + SERVER_IP
    logging.getLogger('MM-API').info(msg)
    current_app.logger.info(msg)


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP


def is_date(s):
    try:
        datetime.strptime(s, DATETIME_FORMAT)
        return True
    except:
        return False


def parse_date(s):
    return datetime.strptime(s, DATETIME_FORMAT)


def get_give_percentage(give_type, custom_give_percentage, budget, ranges):
    if give_type == 'custom':
        return custom_give_percentage

    elif give_type == 'graduated':
        for _range in ranges:
            _from = _range.get('from', 0)
            _to = _range.get('to', False)
            give_percentage = _range.get('givePercentage')

            # Check if budget is in between _from and _to (if _to exists)
            if _from < budget and (budget <= _to if _to else True):
                return give_percentage

        return DEFAULT_GIVEWITH_PERCENTAGE

    else:
        return DEFAULT_GIVEWITH_PERCENTAGE


def convert_program_to_survey(survey_document, program_document, stringify=True):
    # NOTE: This function modifies program_document and survey_document, refactor to work on a copy if program_document
    # is expected to be used after running this function or explicitly pass it a copy

    # the program_document is modified by the popping actions and the approach transformation
    # the survey_document is modified inadvertently by the dict_merge function (see function docstring)

    program_document.pop('createdAt', None)
    program_document.pop('lastUpdated', None)
    program_document.pop('_id', None)

    # transform approaches
    program_document['approach'] = [a['_id'] for a in program_document.get('approach', [])]

    if stringify:
        # convert objectIds to strings -> this modifies program_document
        object_ids_to_strings(program_document)

    document = dict_merge(survey_document, program_document)

    # perform the field mappings using PROGRAM_SURVEY_MAP
    for program_key, survey_key in PROGRAM_SURVEY_MAP.items():
        data = document.pop(program_key, None)

        if not is_empty(data):
            set_descendant_key(data, document, survey_key)

    return document


def get_deep_diff(dict_a, dict_b, include_dict_keys=True):
    """ Using DeepDiff, compares dict_a to dict_b and return a list of keys in
    dot notation that aren't equal. dict_b is compared to dict_a
    """
    raw_diff = DeepDiff(dict_a, dict_b, verbose_level=2, ignore_numeric_type_changes=True).to_dict()

    # 1. flatten raw_diff to dict keys only in each dict
    # 2. Pull out items added and items removed and add the immediate added keys
    # 3. parse strings to drop what we don't need and deduplicate
    # 4. Drop into a set for de-duplication

    additional_keys = []

    if include_dict_keys:
        new_items = dict(**raw_diff.pop('dictionary_item_added', {}), **raw_diff.pop('dictionary_item_removed', {}))
        additional_keys = recursive_key_pull(new_items)


    parsed_diff = [parse_diff_strings(keys) for keys in raw_diff.values()]
    flattened_diff = [key for keys in parsed_diff for key in keys] + list(parse_diff_strings(additional_keys))

    return flattened_diff


def recursive_key_pull(item_dict, parent_key=''):
    """Transforms the result of a DeepDiff dictionary_item_added and dictionary_item_removed dict
       To a DeepDiff list of keys representing the exact keys that were added / removed
       Result keys are added to all_keys list passed to function
    """
    keys = [] # keys captured in current iteration
    if isinstance(item_dict, dict):
        for key, value in item_dict.items():
            wrapped_key = f'[\'{key}\']' if parent_key else key
            keys.extend(recursive_key_pull(value, f'{parent_key}{wrapped_key}'))
    else:
        keys.append(parent_key)

    return keys


def parse_diff_strings(values):
    """ String returned by DeepDiff has the format "root['key1']['key2']['key3'][number_index]._someproperty"
    Parse into key1.key2.key3 (root and number indexes are dropped)
    """
    paths = set() # set of joined full paths that have been built so far
    for value in values:
        # 1. drop any strings after . (which indicates changes in properties of custom objects),
        # replace ] with empty string and split at ] -> ['root', "'key1'", "'key3'", "number_index"]
        # 2. drop the first item in the array (which is always 'root'),
        # 3. reverse the list for O(n) popping
        string_list = value.split('.')[0].replace(']', '').split('[')[:0:-1]

        # if current key is number and a path is built, store the path built and continue
        # Goal -> if number_index is in middle of the list, should store both key1.key2,
        # key1.key.number_index and key1.key2.number_index.key3
        # In all other case, simply ignore the number index
        built_path = [] # current in-progress preliminary path
        while string_list:
            key = string_list.pop().strip('\'')
            is_numeric = key.isnumeric()

            if is_numeric:
                # if numeric store both the string acquired, and the string to be acquired with the index
                # store key1 , key1.number and key1.number.key2
                if built_path:
                    paths.add('.'.join(built_path))

                built_path.append(key)
                paths.add('.'.join(built_path))
            else:
                built_path.append(key)
        else:  # pylint: disable=useless-else-on-loop
            if not is_numeric: # if last item was numeric, path has already been appended
                paths.add('.'.join(built_path))

    return paths


def watermark_file(file):
    '''
    Watermarks `file` with two Givewith logos (one light, one dark).
    Pulled from Jason's Jupyter Notebook
    '''

    givewith_dark = load_file('programs/givewith_dark.jpg').read()
    givewith_light = load_file('programs/givewith_white.jpg').read()

    sample = Image.open(BytesIO(givewith_dark))
    sample2 = Image.open(BytesIO(givewith_light))

    image = Image.open(file)
    if image.width > 1600 or image.height > 1600:
        image.thumbnail((1600, 1600))
    image_copy = image.copy()

    posX = -1 * int(sample.width/2)
    col_counter = 0
    while posX < image_copy.width:
        posY = -1 * int(sample.height/2)
        while posY < image_copy.height:
            position = (posX, posY)
            if col_counter % 2 == 0:
                image_copy.paste(sample, position, sample)
            else:
                image_copy.paste(sample2, position, sample2)
            posY = posY + sample.height
            col_counter += 1
        posX = posX + sample.width

    ximage = image_copy.convert('RGB')

    file_location = '/tmp/%s' % (secure_filename(file.filename)) # nosec
    ximage.save(file_location)

    return file_location

def safe_pop(array, index=-1, default=None):
    try:
        return array.pop(index)
    except IndexError:
        return default


def project_dict(dict_object: Dict, keys: Union[set, List]) -> Dict:
    return {key: value for key, value in dict_object.items() if key in keys}
