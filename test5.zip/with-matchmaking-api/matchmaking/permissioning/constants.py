from enum import Enum

class Action(Enum):
    """CRUD Actions"""
    CREATE = 'create'
    READ = 'read'
    UPDATE = 'update'
    DELETE = 'delete'

    def __repr__(self) -> str:
        return self.value

    __str__ = __repr__
