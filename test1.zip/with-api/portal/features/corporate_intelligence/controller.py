from typing import Dict

from bson import ObjectId
from flask import request
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from werkzeug.exceptions import Forbidden, NotFound, BadRequest
import requests
import json
from portal.features.corporate_intelligence.repository import CorporateEntityRepository
from portal.features.corporate_intelligence.schema import CorporateEntitySchema, CorporateEntitySearchRequest, BrandResponse, BrandSearchResponse
from portal.shared.auth.requests import role_required, token_required, subscription_tier_required
from portal.shared.auth.security import has_role
from portal.shared.enums import AccountStatus, UserRole, SubscriptionType
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.repositories import corporate_entities

namespace = Namespace('corporate-entity', description='Corporate Intelligence Related Operations')

default_selected_recommended_programs = [
    {"_id": "5b47c90e2e9ec6001ae7ac9b", "active": True, "budget": 10000, "customerPreferred": False,
     "imagePortrait":
     "<https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b47c90e2e9ec6001ae7ac9b/GW_Diversity_GRID_PRG_PRT_2880x3840_1545612869353.jpg>",
     "invalidReasons": [],
     "isValid": True, "match": 100, "matchType": "MATCH", "minimumFunding": None,
     "name": "Build a diverse and inclusive solar workforce", "nonprofit": "5b2bf32ee3dde1001ae17701",
     "nonprofitName": "GRID Alternatives",
     "outputs":
     [{"description": "Beneficiaries directly served", "quantity": 0, "scaleType": "Proportional", "value": 0},
      {"description": "Participants of hands-on training on solar installation projects", "quantity": 4025,
       "scaleType": "Proportional", "value": 12397},
      {"description": "Participants of paid cohort trainings and/or internships", "quantity": 1529, "scaleType": "Proportional",
       "value": 4709},
      {"description": "Solar installation projects completed on low-income homes", "quantity": 764, "scaleType": "Proportional",
       "value": 2353},
      {"description": "Widgets", "quantity": 10, "scaleType": "Static", "value": 10}],
     "registeredCountry": "United States", "slug": "solar-workforce-development-diversity-program-2",
     "topics": ["Environment", "Economic empowerment", "Education", "Poverty alleviation", "Veterans"]},
    {"_id": "5c387b71a08c41000a179495", "active": True, "budget": 123, "customerPreferred": False,
     "imagePortrait":
     "<https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A0177_1547205491704.jpg>",
     "invalidReasons": [],
     "isValid": True, "match": 96, "matchType": "MATCH", "minimumFunding": None, "name": "Katarina's PGRM",
     "nonprofit": "5c387a30a08c41000a17947f", "nonprofitName": "Girls Who Code Inc",
     "outputs":
     [{"description": "Beneficiaries directly served", "quantity": 0, "scaleType": "Proportional", "value": 0},
      {"description": "Beneficiaries directly served", "quantity": 2, "scaleType": "Proportional", "value": 500}],
     "registeredCountry": "United States", "slug": "katarina-s-pgrm",
     "topics":
     ["Environment", "Human rights and social justice", "Economic empowerment", "Food and hunger", "Animal welfare",
      "Diversity, equity and inclusion", "Education", "Poverty alleviation", "Women and girls", "Health and wellness",
      "Housing and homelessness", "Veterans", "People with disabilities", "Arts and culture"]},
    {"_id": "5beded370f36530008cef126", "active": True, "budget": 12920, "currency": "USD", "customerPreferred": False,
     "imagePortrait":
     "<https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5beded370f36530008cef126/GW_Safe-At-Home_Rebuilding-Together_2018_59_of_102_1568656232980.jpg>",
     "invalidReasons": [],
     "isValid": True, "match": 91, "matchType": "MATCH", "minimumFunding": None,
     "name": "Advance education for girls in Pakistan", "nonprofit": "5b30eee0e3dde1001ae17753", "nonprofitName": "Oxfam USA",
     "outcomes": [{"description": "of women graduate high school", "quantity": "100%"}],
     "outputs":
     [{"description": "Beneficiaries directly served", "quantity": 0, "scaleType": "Proportional", "value": 0},
      {"description": "Girls who transition from Primary School to Secondary School", "quantity": 1794, "scaleType":
       "Proportional", "value": 4276},
      {"description": "Girls and women who receive Education and Training", "quantity": 86133, "scaleType": "Proportional",
       "value": 205332},
      {"description": "Gender responsive and disaster resilient school infrastructure provided", "quantity": 184,
       "scaleType": "Proportional", "value": 438},
      {"description": "Women and girls receiving enhanced vocational skills and linking with financial institutions", "quantity":
       8613, "scaleType": "Proportional", "value": 20532},
      {"description": "Public officers trained or educated on policies that improve girls' education", "quantity": 430,
       "scaleType": "Proportional", "value": 1025}],
     "registeredCountry": "United States", "slug": "x-6",
     "topics":
     ["Environment", "Human rights and social justice", "Economic empowerment", "Diversity, equity and inclusion", "Education",
      "Women and girls", "Health and wellness", "People with disabilities"]},
    {"_id": "5c083bd8d9d8f30008953cdd", "active": True, "budget": 3450000, "customerPreferred": False,
     "imagePortrait":
     "<https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5c083bd8d9d8f30008953cdd/placeholder-portrait_1544547279076.png>",
     "invalidReasons": [],
     "isValid": True, "match": 87, "matchType": "MATCH", "minimumFunding": None,
     "name": "Help older adults improve their physical and financial well-being", "nonprofit": "5bae3a132c63670007fe3ac6",
     "nonprofitName": "National Council on Aging",
     "outputs":
     [{"description": "Beneficiaries directly served", "quantity": 0, "scaleType": "Proportional", "value": 0},
      {"description": "Behaviors changed", "quantity": 153333, "scaleType": "Proportional", "value": 1368},
      {"description": "Class attendance", "quantity": 153333, "scaleType": "Proportional", "value": 1368},
      {"description": "Classes offered", "quantity": 153333, "scaleType": "Proportional", "value": 1368}],
     "registeredCountry": "United States", "slug": "x-10c",
     "topics":
     ["Human rights and social justice", "Economic empowerment", "Diversity, equity and inclusion", "Education",
      "Poverty alleviation", "Women and girls", "Health and wellness"]},
    {"_id": "5bf320c60f36530008cffca4", "active": True, "budget": 300000, "customerPreferred": False,
     "imagePortrait":
     "<https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5bf320c60f36530008cffca4/GW_Black-Girls-Code_PRG_PRT_2880x3840_1545101560460.jpg>",
     "invalidReasons": [],
     "isValid": True, "match": 82, "matchType": "MATCH", "minimumFunding": None,
     "name": "Teach young women of color in Oakland key coding skills", "nonprofit": "5b2c0100e3dde1001ae1771a",
     "nonprofitName": "Black Girls CODE",
     "outputs":
     [{"description": "Beneficiaries directly served", "quantity": 0, "scaleType": "Proportional", "value": 0},
      {"description": "Girls served", "quantity": 625, "scaleType": "Proportional", "value": 64}],
     "registeredCountry": "United States", "slug": "x-8",
     "topics":
     ["Human rights and social justice", "Economic empowerment", "Diversity, equity and inclusion", "Education",
      "Poverty alleviation", "Women and girls", "Arts and culture"]},
    {"_id": "5b47c91c2e9ec6001ae7ac9d", "active": True, "budget": 100000, "currency": "GBP", "customerPreferred": False,
     "imagePortrait":
     "<https://s3.amazonaws.com/givewith-campaign-assets.production/programs/5b47c91c2e9ec6001ae7ac9d/placeholder-portrait_1544559570693.png>",
     "invalidReasons": [],
     "isValid": True, "match": 78, "matchType": "MATCH", "minimumFunding": None,
     "name": "Deliver life-skills curriculum to girls in Indonesia", "nonprofit": "5b2bf51fe3dde10019e17781",
     "nonprofitName": "Plan International USA", "outcomes": [{"description": "Percent of youth setting goals", "quantity": 70}],
     "outputs":
     [{"description": "Beneficiaries directly served", "quantity": 0, "scaleType": "Proportional"},
      {"description": "Trainings delivered", "quantity": 152, "scaleType": "Proportional"},
      {"description": "Individuals served by curriculum", "quantity": 122764, "scaleType": "Proportional"},
      {"description": "Facilitators trained and certified", "quantity": 3430, "scaleType": "Proportional"},
      {"description": "Learning centers established", "quantity": 1145, "scaleType": "Proportional"}],
     "registeredCountry": "United States", "slug": "better-life-options-and-opportunities-model-bloom-indonesia-5",
     "topics":
     ["Economic empowerment", "Diversity, equity and inclusion", "Education", "Poverty alleviation", "Women and girls",
      "Health and wellness"]}]


def _validate_access(account_id: str):
    if not has_role(GIVEWITH_ROLES, request.user) and request.user['accountId'] != ObjectId(account_id):
        raise Forbidden('You do not have permission to access this resource')


@namespace.route('')
@namespace.doc(
    security='Bearer',
    responses={
        400: 'Bad Request',
        401: 'Token is invalid or expired',
        403: 'Permission Denied'
    }
)
class CorporateEntities(Resource):
    # @subscription_tier_required(SubscriptionType.SELLWITH_SELECT)
    # @accepts(query_params_schema=CorporateEntitySearchRequest, api=namespace)
    # @responds(schema=BrandSearchResponse, api=namespace)
    def get(self):
        ''' Get all Corporate Entities matching a search fields'''
        filters = request.parsed_query_params
        total_count, accounts = corporate_entities().get_page(filters)
        return {
            'totalCount': total_count,
            'results': accounts
        }

#     @role_required(GIVEWITH_ROLES)
#     @accepts(schema=BrandRequest, api=namespace)
#     @responds(schema=BrandResponse, api=namespace)
#     def post(self):
#         new_corporate_entity = corporate_entities().insert(request.parsed_obj, request.user['username'])
#         return new_corporate_entity


@namespace.route('/<string:id>')
class BrandById(Resource):
    @token_required
    @subscription_tier_required(SubscriptionType.SELLWITH_SELECT.value)
    @namespace.doc(security="Bearer")
    @namespace.response(400, 'Bad Request')
    @namespace.response(401, 'Account not found')
    @namespace.response(404, 'Error occured in recommended service.')
    @responds(schema=BrandResponse, api=namespace)
    def get(self, id: str):
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        corporate_entity = corporate_entities().get_single(id)
        # invoke recommend end point using id recommend response
        if corporate_entity is None:
            raise NotFound('Corporate Entity not found')
        url = "https://dev.api.recommendation.scalewith.com/graph/v1/recommend"
        headers = {'Content-Type': 'application/json'}
        payload = json.dumps(
            {
                "entityName": corporate_entity.get("name"),  # "ESSENTIAL PROPERTIES REALTY TRUST, INC.",
                "include_csr_sources": ["CSRHUB", "SASB", "MSCI", "THEMES"],
                "priority_causes": [],
                "max_programs_by_sio": "2",
                "max_top_recommendation": "12",
                "include_country_mapping": True,
                "filter": {
                    "exclude_non_preferred_industry_by_sio": True,
                    "exclude_non_preferred_entity_by_sio": True,
                    "exclude_non_preferred_sio_by_entity": True,
                    "include_preferred_sio_by_entity": True,
                    "include_preferred_program_by_entity": True
                },
            })
        recommended_response = requests.request("POST", url, headers=headers, data=payload)
        if recommended_response.status_code == 200:
            corporate_entity["recommendedPrograms"] = recommended_response.json().get("results")
            return corporate_entity
        else:
            raise NotFound("Error occured in recommended service.")

#     @subscription_tier_required(SubscriptionType.SELLWITH_SELECT)
#     @role_required(GIVEWITH_ROLES)
#     @accepts(schema=BrandRequest, api=namespace)
#     @responds(schema=BrandResponse, api=namespace)
#     def put(self, id: str):
#         """Update Corporate Entity"""
#         if not ObjectId.is_valid(id):
#             raise BadRequest('Invalid id provided')
#         _validate_access(id)
#         brand = corporate_entities().get_single(id)
#         if brand is None:
#             raise NotFound('brands not found')
#         update = request.parsed_obj
#         brand.update(update)
#         account = corporate_entities().update(account, by=request.user['username'])

#         return account


#     @accepts(schema=BrandRequest(partial=True), api=namespace)
#     @responds(schema=BrandResponse, api=namespace)
#     def patch(self, id: str):
#         """Update Account from Partial"""
#         if not ObjectId.is_valid(id):
#             raise BadRequest('Invalid id provided')
#         _validate_access(id)
#         brand = corporate_entities().get_single(id)
#         if brand is None:
#             raise NotFound('Corporate Entity was not found')

#         update = request.parsed_obj
#         brand.update(update)
#         brand = corporate_entities().update(brand, request.user['username'])

#         return brand
