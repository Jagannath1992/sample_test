from html.parser import HTMLParser
from ....mongodb import get_vocabulary_label_v2, get_sdg_for_deliverables, get_gri_for_deliverables, get_sasb_for_deliverables

class MLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.fed = []
    def handle_data(self, d):
        self.fed.append(d)
    def get_data(self):
        return ''.join(self.fed)


def clean(html):
    s = MLStripper()
    s.feed(html)
    unicode_string = s.get_data()
    for i in range(0, len(unicode_string)):
        try:
            unicode_string[i].encode('ascii')
        except Exception as e:
            # means it's non-ASCII
            unicode_string = unicode_string.replace(unicode_string[i], '\'')  # replacing it with a single space

    return unicode_string.strip()


def get_sdg_master():
    return get_sdg_for_deliverables()


def get_gri_master():
    return get_gri_for_deliverables()


def get_sasb_master():
    return get_sasb_for_deliverables()


def get_strings(list_of_vocab_ids, which):
    vocab_strings = list()
    for vocab_id in list_of_vocab_ids:
        label = get_vocabulary_label_v2(vocab_id)
        if label:
            vocab_strings.append(label)
    return vocab_strings

def deduplicate_intersection(list1, list2):
    '''
    Get intersection of two lists and deduplicate
    '''
    return list(set(list1) & set(list2))
