import json

from flask import current_app, Response
from app.loggly import send_loggly


def error_response(http_status_code, message, details=[]):
    response = {
        'error': {
            'message': message
        }
    }

    if len(details) > 0:
        response['error']['details'] = details

    send_loggly(str(response))
    return Response(json.dumps(response), status=http_status_code)
