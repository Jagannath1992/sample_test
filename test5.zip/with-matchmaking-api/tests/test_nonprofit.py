import json

def test_registered_country(client, admin_header, nonprofit_id):
    # test default country
    response = client.get('/admin/nonprofits/' + str(nonprofit_id), headers=admin_header)
    assert response.status_code == 200

    nonprofit = json.loads(response.data.decode())
    assert nonprofit['general']['location']['generalLocation'] == 'United States'

    # test update
    nonprofit['general']['location']['generalLocation'] = 'UK-test'
    response = client.put('/admin/nonprofits/' + str(nonprofit_id), data=json.dumps(nonprofit), headers=admin_header)
    assert response.status_code == 200

    response = client.get('/admin/nonprofits/' + str(nonprofit_id), headers=admin_header)
    assert response.status_code == 200

    nonprofit = json.loads(response.data.decode())
    assert nonprofit['general']['location']['generalLocation'] == 'UK-test'


def test_list_nonprofits(client, admin_header):
    response = client.get('/admin/nonprofits', headers=admin_header)
    assert response.status_code == 200

    nonprofit = json.loads(response.data.decode())
    assert len(nonprofit) > 0


def test_get_nonprofit(client, admin_header):
    response = client.get('/admin/nonprofits', headers=admin_header)
    assert response.status_code == 200

    nonprofits = json.loads(response.data.decode())
    assert len(nonprofits) > 0

    _id = str(nonprofits[0]['_id'])
    response = client.get('/admin/nonprofits/' + _id, headers=admin_header)
    assert response.status_code == 200

    nonprofit = json.loads(response.data.decode())
    assert nonprofit.get('mpa').get('status') == 'SIGNATURE_PENDING'


def test_update_nonprofit(client, admin_header):
    response = client.get('/admin/nonprofits', headers=admin_header)
    nonprofit_id = str(json.loads(response.data.decode())[0]['_id'])

    response = client.get('/admin/nonprofits/' + nonprofit_id, headers=admin_header)
    nonprofit = json.loads(response.data.decode())

    response = client.put('/admin/nonprofits/' + str(nonprofit['_id']), data=json.dumps(nonprofit), headers=admin_header)
    assert response.status_code == 200


def test_validate(client, admin_header):
    response = client.post('/admin/nonprofit:validate?include_valid=true&include_invalid=true&include_diff=true', data=json.dumps({}),headers=admin_header)
    assert response.status_code == 200
