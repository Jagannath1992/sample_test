from matchmaking import db

tvl_data = list(db().coll_tvl_data.find())

for tvl_brand in tvl_data:
    isin = tvl_brand['ISIN']
    brand = db().coll_brands.find_one({'ISIN': isin})
    if brand:
        brand['tvlVisibility'] = {}
        brand['tvlVisibility']['accessAndAffordabilityVisibility'] = True
        brand['tvlVisibility']['businessEthicsAndTransparencyOfPaymentsVisibility'] = True
        brand['tvlVisibility']['humanRightsAndCommunityRelationsVisibility'] = True
        brand['tvlVisibility']['biodiversityImpactsVisibility'] = True
        brand['tvlVisibility']['gHGEmissionsVisibility'] = True
        db().coll_brands.replace_one(filter={'_id': brand["_id"]}, replacement=brand)
    