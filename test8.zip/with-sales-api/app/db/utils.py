from bson.objectid import ObjectId, InvalidId
from datetime import datetime
from flask import request

from pymongo import ReturnDocument
from app.db.database import get_db
from app.utils.query_parser import parse_sort_params, parse_filter_params, parse_pagination_params


default_blacklist = ['createdAt', 'createdBy', 'slug', '_id']


def get_document_by_id(collection, document_id, **kwargs):
    """
    get a single document by query
    """
    if isinstance(document_id, str):
        try:
            document_id = ObjectId(document_id)
        except InvalidId:
            return None

    return get_db()[collection].find_one({'_id': document_id}, **kwargs)


def get_document(collection, query={}, **kwargs):
    """
    get a single document by query
    """
    return get_db()[collection].find_one(query, **kwargs)


def get_documents(collection, query={}, **kwargs):
    """
    get a list of documents by query
    """
    return list(get_db()[collection].find(query, **kwargs))


def list_documents(collection, params={}):
    """
    get all documents from collection with filtering, sorting, pagination
    """

    sort_params = params.get('sort', [('lastUpdated', -1)])
    filter_params = params.get('filter', {})
    page_size, skip = params.get('page_size', 0), params.get('page_num', 0)

    return list(get_db()[collection].find(filter_params).skip(skip).limit(page_size).sort(sort_params))


def add_document(collection, document):
    """
    add a document with default fields.
    """
    now = datetime.utcnow()
    document['createdAt'] = now
    document['lastUpdated'] = now

    document['_id'] = str(get_db()[collection].insert_one(document).inserted_id)
    return document


def update_document_by_id(collection, document_id, changes, blacklist=[], upsert=True, unset={}):
    """
    partially update document by id
    """
    if isinstance(document_id, str):
        document_id = ObjectId(document_id)

    return update_document(collection, {'_id': document_id}, changes, blacklist, upsert, unset)


def aggregate_on(collection, pipeline):
    """
    Run an aggregation pipeline on a collection
    """
    return get_db()[collection].aggregate(pipeline)


def update_document(collection, find, updates, blacklist=[], upsert=True, unset={}):
    """
    partially update document by id
    """
    updates['lastUpdated'] = datetime.utcnow()
    updates = pop_blacklist_keys(updates, blacklist)

    update_query = build_update_query(updates)

    changes = {'$set': update_query}
    if unset:
        changes['$unset'] = unset

    return get_db()[collection].find_one_and_update(find, changes, upsert=upsert, return_document=ReturnDocument.AFTER)


def validate_existence(key_value_pairs, collection_name):
    """
    validate if document with key-value pairs exist in the collection
    """
    count = get_db()[collection_name].count_documents(key_value_pairs)
    return count > 0


def pop_blacklist_keys(changes, blacklist=[]):
    blacklist += default_blacklist
    for key in changes.copy():
        if key in blacklist:
            changes.pop(key)

    return changes


def build_update_query(document):
    """
    build a dot separated update query for nested partial update request.
    db.coll.update({'_id': 'id'}, {'$set': {'general.social.facebook': facebook.com/gw, 'general.location.city': 'new york'}})
    """
    query = {}
    build_update_query_helper(document, '', query)
    return query


def build_update_query_helper(document, parent_key, query):
    for key in document:
        value = document.get(key)

        if len(parent_key) > 0:
            key = parent_key + '.' + key

        if isinstance(value, dict):
            build_update_query_helper(value, key, query)
        else:
            query[key] = value


def merge_diff(source, change):
    for key, value in change.items():
        if isinstance(value, dict):
            if key not in source:
                source[key] = {}

            source[key] = merge_diff(source[key], change[key])
        else:
            source[key] = change[key]

    return source
