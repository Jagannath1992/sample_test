from research_api.loggly import init_logging
from research_api.utils import DatasetNotFound, GivewithError, expand_dot_fields, remove_empty
from research_api.loggly import get_logger
from dotenv import load_dotenv
from pathlib import Path
from os import environ, path
from utils import isLocalEnv, getEnvVariable
import constants


if (isLocalEnv() == True):
    # CREATE user.env and set all required environment variable while running in local
    print("This is local environment, loading user.env")
    dotenv_path = Path('user.env')

    if path.exists(dotenv_path):
        load_dotenv(dotenv_path=dotenv_path)
    else:
        print('user.env does not exists, going to rely on environment variables')

print("*********************************************************")
print("RUNNING AS ENVIRONMENT", getEnvVariable())
print("*********************************************************")

# NEED TO LOAD TRIGGERS AFTER READING ENVIRONMENT VARIABLE
# I KNOW THERE ARE BETTER WAYS BUT THIS WILL DO THE JOB JUST FINE FOR NOW
# DONT MOVE THESE TWO LINE TO TOP
import research_api.controllers.triggers as triggers
from research_api.mongodb import init_db, db
from research_api.cron.job_handler import simian
from research_api.slack import SimianSlack
import research_api.controllers.tagging.triggers as tagging

slack = SimianSlack()


init_logging()

get_logger().info(f'Starting mongoDB connect')
init_db(None)
get_logger().info(f'mongoDB connection successful')

get_logger().info(f'Starting pipeline for {environ.get(constants.ETL_SOURCE)}')
slack.send_text(f'Starting pipeline for {environ.get(constants.ETL_SOURCE)}')

if constants.DATASOURCE_SIMIAN.lower() == environ.get(constants.ETL_SOURCE).lower():
    simian()
elif constants.DATASOURCE_TAGGING.lower() == environ.get(constants.ETL_SOURCE).lower():
    tagging.start_pipeline("ALL", False)
else:
    # TRIGGER MSCI/CSRHUB/SASB PIPELINE
    triggers.start_pipeline(environ.get(constants.ETL_SOURCE))

get_logger().info(f'Finished pipeline for {environ.get(constants.ETL_SOURCE)}')
slack.send_text(f'Finished pipeline for {environ.get(constants.ETL_SOURCE)}')

