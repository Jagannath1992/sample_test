from portal.shared.repositories import locale_repository, instance_settings_repository
from werkzeug.exceptions import BadRequest
from portal.shared.enums import InstanceStatus
from collections import namedtuple


class LocaleValidator:

    def __init__(self, locale_request: dict, prev_locale: dict = {}):
        self.locale_request = locale_request
        self.prev_locale = prev_locale

    def validate_locale_name(self):
        # Only validate if name is in the request
        if not 'name' in self.locale_request:
            return
        # Only validate if name is new/changed
        if self.locale_request.get('name') == self.prev_locale.get('name'):
            return

        if locale_repository().exists_by_filter({'name': self.locale_request['name']}):
            raise BadRequest(f'A locale named {self.locale_request["name"]} already exists')

    def validate_active_instance(self):
        # Only validate if active is in the request
        if not 'active' in self.locale_request:
            return
        # Only validate if active is changed
        if self.locale_request.get('active') == self.prev_locale.get('active'):
            return
        if self.locale_request.get('active') == False:
            instance_settings_repository().populate_locale_instance_counts([self.prev_locale])
            instance_cnt = self.prev_locale.get('instanceCount', 0)
            if instance_cnt > 0:
                raise BadRequest('Locale associated with active instance')
