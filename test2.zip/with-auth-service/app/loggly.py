import logging
from logging.handlers import RotatingFileHandler, SysLogHandler
import os.path
import os
from flask import current_app

openshift_deploy = os.environ.get('OPENSHIFT_DEPLOY', 'False')
syslog_host = os.environ.get('SYSLOG_HOST', '')

def init_logging(app):
    if not app.config['config']['loggly']['enable']:
        return

    # default file logging
    formatter = logging.Formatter(
        "[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s")

    # check if we can write to auth.log at the system level - if not, just write it in the local dir
    log_path = app.config['config']['loggly']['path']
    if not os.path.isfile(log_path):
        log_path = './auth.log'

    handler = RotatingFileHandler(log_path, maxBytes=10000000, backupCount=5)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(formatter)
    app.logger.addHandler(handler)
    __init_loggly()


def __init_loggly():
    logger = logging.getLogger('AUTH')  # set this value as per your repo/project
    logger.setLevel(logging.INFO)
    handler = SysLogHandler('/var/log')
    if openshift_deploy == "True":
        handler = SysLogHandler(address = (syslog_host,514))
    formatter = logging.Formatter(
        'Python: { "loggerName":"%(name)s", \
            "timestamp":"%(asctime)s", \
            "pathName":"%(pathname)s", \
            "logRecordCreationTime":"%(created)f", \
            "functionName":"%(funcName)s", \
            "levelNo":"%(levelno)s", \
            "lineNo":"%(lineno)d", \
            "time":"%(msecs)d", \
            "levelName":"%(levelname)s", \
            "message":"%(message)s"}'
    )
    handler.formatter = formatter
    logger.addHandler(handler)
    logger.info("Init logging on Auth")


def send_loggly(msg):
    if logging.getLogger('AUTH'):
        logging.getLogger('AUTH').info(msg)
    else:
        current_app.info("can't write to loggly")
