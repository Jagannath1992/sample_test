""" rename brand_id to org_id, set org_type to brand"""
from matchmaking import db
from bson import ObjectId

users = list(db().coll_user.find())

for user in users:
    if 'brand_id' in user and 'orgId' not in user:
        user['orgType'] = 'brand'

        user['orgId'] = ObjectId(user.get['brand_id'])
        del user['brand_id']

        db().coll_user.replace_one(filter={'_id': user['_id']}, replacement=user)
