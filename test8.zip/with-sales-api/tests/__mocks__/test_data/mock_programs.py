from bson.objectid import ObjectId

programs = [
    {
        '_id' : ObjectId('5c387b71a08c41000a179495'),
        'active' : True,
        'budget' : 123,
        'cashContributions' : 54545,
        'createdAt' : '2019-01-11T11:18:09.593Z',
        'description' : '**Testing Program**',
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A1193_1547205491763.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A0177_1547205491704.jpg',
        'impactMultipleVisibility' : True,
        'inKindContributions' : 6565,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-12-10T15:50:41.445Z',
        'name' : 'Katarina\'s PGRM',
        'nonprofit' : ObjectId('5c387a30a08c41000a17947f'),
        'nonprofitPartners' : True,
        'notes' : 'Test internal notes ',
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'quantity' : 500.0,
                'description' : 'kids dead',
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            }
        ],
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/5c387b71a08c41000a179495.jpg',
        'slug' : 'katarina-s-pgrm',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'outcomes' : [
            {
                'quantity' : 20.0,
                'description' : 'homes burnt'
            },
            {
                'quantity' : 0.0,
                'description' : 'dead'
            },
            {
                'quantity' : '100%',
                'description' : 'rooms cleaned'
            }
        ]
    },
    {
        '_id' : ObjectId('5c3f9781448627000aafea8b'),
        'active' : True,
        'budget' : 100000,
        'cashContributions' : 33,
        'createdAt' : '2019-01-16T20:43:45.542Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c08'),
        'description' : 'Description',
        'givewithAdmin' : ObjectId('5d88f5a165bd7608350f40bb'),
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671538384.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671533627.jpg',
        'inKindContributions' : 22,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-02-20T22:38:48.102Z',
        'name' : 'Smoke test program',
        'nonprofit' : ObjectId('5e4da534dba98318df35a302'),
        'notes' : 'test',
        'outcomes' : [
            {
                'description' : 'yet another',
                'quantity' : '100%'
            }
        ],
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'Test',
                'quantity' : 110000,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'another test',
                'quantity' : 10,
                'scaleType' : ObjectId('5af4a134a64082a02a943c15')
            }
        ],
        'slug' : 'smoke-test-program',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/5c3f9781448627000aafea8b.jpg'
    },
    {
        '_id' : ObjectId('5c14265c6bf7b3000849f6e0'),
        'active' : True,
        'budget' : 123,
        'cashContributions' : 54545,
        'createdAt' : '2019-01-11T11:18:09.593Z',
        'description' : '**Testing Program**',
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A1193_1547205491763.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A0177_1547205491704.jpg',
        'impactMultipleVisibility' : True,
        'inKindContributions' : 6565,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-12-10T15:50:41.445Z',
        'name' : 'Katarina\'s PGRM',
        'nonprofit' : ObjectId('5c387a30a08c41000a17947f'),
        'nonprofitPartners' : True,
        'notes' : 'Test internal notes ',
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'quantity' : 500.0,
                'description' : 'kids dead',
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            }
        ],
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/5c387b71a08c41000a179495.jpg',
        'slug' : 'katarina-s-pgrm',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'outcomes' : [
            {
                'quantity' : 20.0,
                'description' : 'homes burnt'
            },
            {
                'quantity' : 0.0,
                'description' : 'dead'
            },
            {
                'quantity' : '100%',
                'description' : 'rooms cleaned'
            }
        ]
    },
    {
        '_id' : ObjectId('5c3c5973659da5000add9792'),
        'active' : True,
        'budget' : 100000,
        'cashContributions' : 33,
        'createdAt' : '2019-01-16T20:43:45.542Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c08'),
        'description' : 'Description',
        'givewithAdmin' : ObjectId('5d88f5a165bd7608350f40bb'),
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671538384.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671533627.jpg',
        'inKindContributions' : 22,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-02-20T22:38:48.102Z',
        'name' : 'Smoke test program',
        'nonprofit' : ObjectId('5e4da534dba98318df35a302'),
        'notes' : 'test',
        'outcomes' : [
            {
                'description' : 'yet another',
                'quantity' : '100%'
            }
        ],
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'Test',
                'quantity' : 110000,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'another test',
                'quantity' : 10,
                'scaleType' : ObjectId('5af4a134a64082a02a943c15')
            }
        ],
        'slug' : 'smoke-test-program',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/5c3f9781448627000aafea8b.jpg'
    },
    {
        '_id' : ObjectId('5beded370f36530008cef126'),
        'active' : True,
        'budget' : 123,
        'cashContributions' : 54545,
        'createdAt' : '2019-01-11T11:18:09.593Z',
        'description' : '**Testing Program**',
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A1193_1547205491763.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/0J3A0177_1547205491704.jpg',
        'impactMultipleVisibility' : True,
        'inKindContributions' : 6565,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-12-10T15:50:41.445Z',
        'name' : 'Katarina\'s PGRM',
        'nonprofit' : ObjectId('5c387a30a08c41000a17947f'),
        'nonprofitPartners' : True,
        'notes' : 'Test internal notes ',
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'quantity' : 500.0,
                'description' : 'kids dead',
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            }
        ],
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c387b71a08c41000a179495/5c387b71a08c41000a179495.jpg',
        'slug' : 'katarina-s-pgrm',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'outcomes' : [
            {
                'quantity' : 20.0,
                'description' : 'homes burnt'
            },
            {
                'quantity' : 0.0,
                'description' : 'dead'
            },
            {
                'quantity' : '100%',
                'description' : 'rooms cleaned'
            }
        ]
    },
    {
        '_id' : ObjectId('5ba3fd672c63670007fc28a8'),
        'active' : True,
        'budget' : 100000,
        'cashContributions' : 33,
        'createdAt' : '2019-01-16T20:43:45.542Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c08'),
        'description' : 'Description',
        'givewithAdmin' : ObjectId('5d88f5a165bd7608350f40bb'),
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671538384.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671533627.jpg',
        'inKindContributions' : 22,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-02-20T22:38:48.102Z',
        'name' : 'Smoke test program',
        'nonprofit' : ObjectId('5e4da534dba98318df35a302'),
        'notes' : 'test',
        'outcomes' : [
            {
                'description' : 'yet another',
                'quantity' : '100%'
            }
        ],
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'Test',
                'quantity' : 110000,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'another test',
                'quantity' : 10,
                'scaleType' : ObjectId('5af4a134a64082a02a943c15')
            }
        ],
        'slug' : 'smoke-test-program',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/5c3f9781448627000aafea8b.jpg'
    },
    {
        '_id' : ObjectId('5ba3fffd5d67100007023de7'),
        'active' : True,
        'budget' : 100000,
        'cashContributions' : 33,
        'createdAt' : '2019-01-16T20:43:45.542Z',
        'dataMeasurementType' : ObjectId('5af48f88a64082a02a943c08'),
        'description' : 'Description',
        'givewithAdmin' : ObjectId('5d88f5a165bd7608350f40bb'),
        'imageLandscape' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671538384.jpg',
        'imagePortrait' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/Piano_1547671533627.jpg',
        'inKindContributions' : 22,
        'isValid' : True,
        'isValidNonprofit' : True,
        'lastUpdated' : '2020-02-20T22:38:48.102Z',
        'name' : 'Smoke test program',
        'nonprofit' : ObjectId('5e4da534dba98318df35a302'),
        'notes' : 'test',
        'outcomes' : [
            {
                'description' : 'yet another',
                'quantity' : '100%'
            }
        ],
        'outputs' : [
            {
                'description' : 'Beneficiaries directly served',
                'quantity' : 0,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'Test',
                'quantity' : 110000,
                'scaleType' : ObjectId('5af4a134a64082a02a943c13')
            },
            {
                'description' : 'another test',
                'quantity' : 10,
                'scaleType' : ObjectId('5af4a134a64082a02a943c15')
            }
        ],
        'slug' : 'smoke-test-program',
        'themes' : {
            'data' : [
                ObjectId('5d44b3b4d5b3a55e9e513cd7'),
                ObjectId('5d44b3b4d5b3a55e9e513cda'),
                ObjectId('5d44b3b4d5b3a55e9e513cd8'),
            ],
            'isCustom' : False
        },
        'version' : 2,
        'previewImage' : 'https://s3.amazonaws.com/givewith-campaign-assets.staging/programs/5c3f9781448627000aafea8b/5c3f9781448627000aafea8b.jpg'
    }
]
