# -*- coding: utf-8 -*-
from matchmaking import create_app

if __name__ == '__main__':
    app = create_app()
    if app is not None:
        app.run(host='0.0.0.0', port=3000) # nosec


