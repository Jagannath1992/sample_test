from os import environ
import re
from enum import Enum
from typing import Dict, List

from research_api.utils import GivewithError
from research_api.logger import log_exception
from research_api.fetchers.constants import CSRHUB_MAPPING, VOCAB_TO_CSRHUB
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from research_api.mongodb import db


class GoogleSheetDimension(Enum):
    """Google Sheet Dimension Enum
    Describes the arrangement of data returned by the google sheet api
    ROWS describes data arranged as an array of the rows in the spreadsheet
    COLUMNS describes data arranged as an array of the columns in the spreadsheet
    """
    ROWS = 'ROWS'
    COLUMNS = 'COLUMNS'

    def __str__(self) -> str:
        return self.name


def get_google_sheet(sheet_id: str, sheet_range: str,
                     dimension: GoogleSheetDimension = GoogleSheetDimension.ROWS) -> List[Dict[str, str]]:
    """Fetch google sheet using Google api

    Arguments:
        credentials {Credentials} -- Google oAuth credential object
        sheet_id {str} -- google sheet id
        sheet_range {str} -- google sheet tab name and sheet range

    Keyword Arguments:
        dimension {GoogleSheetDimension} -- dimension to retrieve sheet in (default: {GoogleSheetDimension.ROWS})

    Returns:
        [dict] -- Array containing returned google sheet as dictionaries
    """
    scopes = ['https://www.googleapis.com/auth/spreadsheets.readonly']
    credentials = get_google_oauth_token(scopes)

    service = build('sheets', 'v4', credentials=credentials, cache_discovery=False)
    sheet = service.spreadsheets()
    result = sheet.values().get(spreadsheetId=sheet_id, range=sheet_range, majorDimension=str(dimension)).execute()
    values = result.get('values', [])

    result = []
    if values:
        if dimension == GoogleSheetDimension.ROWS:
            # gsheet returns the values a list of items grouped by rows
            # ex: 1: ['header1', 'header2'], [value1, value 2]

            # strip all keys and convert to lowercase
            keys = [str(key).strip().lower() for key in values[0]]
            result = [dict(zip(keys, row)) for row in values[1:]]

        if dimension == GoogleSheetDimension.COLUMNS:
            # gsheet returns the values as a list of items grouped by columns
            # ex 1: ['header1', value1], ['header2', 'value2']
            result = [{str(column[0]).strip().lower(): column[1:] for column in values}]
    else:
        log_exception('Google sheet returned empty values')
        raise GivewithError('Google Sheet returned empty values')

    return result


def get_google_oauth_token(scopes: List[str]) -> Credentials:
    """Creates a google oauth token object from client config

    Arguments:
        scopes {List[str]} -- google api oauth usage scopes

    Returns:
        Credentials -- Google Oauth credentials object
    """
    authorized_user_info = {
        'client_id': environ.get('GOOGLE_CLIENT_ID'),
        'client_secret': environ.get('GOOGLE_CLIENT_SECRET'),
        'refresh_token': environ.get('GOOGLE_REFRESH_TOKEN')
    }

    creds = Credentials.from_authorized_user_info(authorized_user_info, scopes=scopes)
    creds.refresh(Request())

    return creds


def request_google_oauth_token(scopes: List[str]) -> Credentials:
    """Request a new API token from a client

    Arguments:
        scopes {List[str]} -- google api oauth usage scopes

    Returns:
        Credentials -- Google Oauth credentials object
    """
    # no need to import at top level since this function will almost never be used
    from google_auth_oauthlib.flow import InstalledAppFlow

    client_config = {
        'installed': {
            'client_id': environ.get('GOOGLE_CLIENT_ID'),
            'client_secret': environ.get('GOOGLE_CLIENT_SECRET'),
            'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
            'token_uri': 'https://oauth2.googleapis.com/token',
        }
    }

    flow = InstalledAppFlow.from_client_config(client_config, scopes)
    creds = flow.run_console()

    return creds
def _get_id_to_csrhub_category():
    cursor = db().coll_vocabulary.find({'type': 'csrhub', 'versions': {'$in': [2]}})
    id_mapping = {str(vocab.get('_id')): VOCAB_TO_CSRHUB.get(vocab.get('label')) for vocab in cursor if vocab.get('label') in VOCAB_TO_CSRHUB}
    return id_mapping
        

def _clean_brand(brand, mapping):
    columns = ['name', 'namevariants', 'ISIN', 'ticker', 'industry', 'industries', 'country', 'csrhub', 'csrhubId', 'description', 'specialissuesall']
    brandvariants = brand.get('namevariants',[]) + brand.get('aliasvariants', [])+ [brand.get('name', ''), brand.get('alias', '')]
    brandvariantslower = [re.sub('[^0-9a-zA-Z]+', ' ', s).lower() for s in brandvariants]
    brandvariants.extend(brandvariantslower)
    brand['namevariants'] = brandvariants
    industries = brand.get('industries', [])
    if not isinstance(industries, list):
        print(industries, "industries not a list???")
        industries = ["N/A"]
    brand['industry'] = industries[0]
    ratings = brand.get('ratings', {})
    tagged = ratings.get('subcategories', {})
    tagged = {t: {'id': mapping.get(t, ''), 'score': tagged[t]} for t in tagged}
    ratings['tagged'] = tagged
    brand['csrhub'] = ratings
    brand['source'] = 'csrhub'
    brand['csrhubId'] = brand.get('id', '')
    cleaned_brand = {key: brand[key] for key in columns}
    return cleaned_brand

def transform_csrhub(data, mapping):
    cleaned_data = [_clean_brand(brand, mapping) for brand in data if brand.get('name') and brand.get('name') != 'NA']
    return cleaned_data
  