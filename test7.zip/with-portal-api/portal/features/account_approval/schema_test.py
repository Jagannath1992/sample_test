import pytest
from bson import ObjectId
from marshmallow import ValidationError

from portal.features.account_approval.schema import AccountApprovalRequest


class TestApprovalSchema:

    def test_default_values(self, fakers):
        account = fakers.account.insert_single()
        approver = fakers.user.insert_single()

        request = {
            'id': str(account['_id']),
            'levels': [{
                'approver': {
                    'id': str(approver['_id']),
                    'type': 'user',
                    'name': 'name',
                    'username': 'username@example.com'
                }
            }]
        }

        response = AccountApprovalRequest().load(request)

        assert response['levels'][0]['amount'] == 0.0

    def test_request_invalid_account(self, fakers):
        approver = fakers.user.insert_single()
        request = {
            'id': str(ObjectId()),
            'levels': [{
                'approver': {
                    'id': str(approver['_id']),
                    'type': 'user',
                    'name': 'name',
                    'username': 'username@example.com'
                }
            }]
        }

        with pytest.raises(ValidationError) as error:
            AccountApprovalRequest().load(request)

        assert error.value.messages == {'id': ['Account does not exist']}

    def test_request_invalid_approval(self, fakers):
        account = fakers.account.insert_single()
        request = {
            'id': str(account['_id']),
            'levels': [{
                'approver': {
                    'id': str(ObjectId()),
                    'type': 'user',
                    'name': 'name',
                    'username': 'username@example.com'
                }
            }]
        }
        with pytest.raises(ValidationError) as error:
            AccountApprovalRequest().load(request)

        assert error.value.messages == {'levels': {0: {'approver': {'id': ['Approving user does not exist']}}}}
