from flask import request


def validate_login():
    errs = []
    if 'grantType' not in request.json:
        errs.append({'target': 'grantType', 'message': 'grantType is required'})
        return errs

    grant_type = request.json.get('grantType')
    if grant_type not in ['password', 'refresh_token', 'integration']:
        errs.append({'target': 'grantType', 'message': 'grantType not supported'})

    if grant_type == 'password':
        check_for_user_pass(errs)
        
    if grant_type == 'refresh_token':
        if 'refresh_token' not in request.json:
            errs.append({'target': 'password', 'message': 'password is required when grantType is refresh_token'})
    
    if grant_type == 'integration':
        check_for_user_pass(errs)
        if 'platform' not in request.json:
            errs.append({'target': 'platform', 'message': 'platform name is required when grantType is integration'})

    scope = request.json.get('scope')
    if scope is not None:
        available_scopes = ['admin', 'impact', 'psf', 'sales']
        if scope not in available_scopes:
            errs.append({'target': 'scope', 'message': 'invalid scopes. valid scopes are: ' + ', '.join(available_scopes)})

    return errs

def check_for_user_pass(errs):
    if 'username' not in request.json:
        errs.append({'target': 'username', 'message': 'username is required when grantType is password'})

    if 'password' not in request.json:
        errs.append({'target': 'password', 'message': 'password is required when grantType is password'})
