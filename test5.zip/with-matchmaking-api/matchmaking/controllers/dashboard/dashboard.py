import sys
from datetime import timedelta
from typing import Dict, List, Union, Any
from jsondiff import diff
from bson.errors import InvalidId
from flask import jsonify, send_file
from tempfile import TemporaryFile

from matchmaking.service.recommendations import get_deal_recommended_programs, select_programs
from matchmaking.service.email import NotificationEmail
from matchmaking.dao.utils import get_documents, get_document_by_id, update_document_by_id
from matchmaking.util.forex import convert_currency
from .dash_utils import *
from matchmaking.service.slack import send_proposal_message
from matchmaking.s3 import download_file, does_file_exist, get_bucket_name_from_url

from ..commerce.deal import admin_get_deal_by_id_handler, get_deal_program, get_program_by_id, get_brand_by_id
from ..commerce.utils import get_brand_by_id_or_slug, get_nonprofit_by_id, get_insights, add_deliverables
from ..matchmaking.brands.utils import is_brand_verified_by_admin

from ...controllers import dash_bp, public_bp
from ...models.models import DASHBOARD_MODELS, GivewithValidator, Currency, to_number_without_commas, APISchema_deal
from ...mongodb import *  # TODO: change to `import * as mongo` or something to avoid name conflicts
from ...utils import (generate_secure_password, generate_random_slug, UnsupportedId, UnsupportedPayload, DealStatus,
                      EntityNotFound, get_user_role, set_last_updated, GivewithError, ValidationError,
                      send_loggly, UserDepartments, RolesByDepartment, get_give_percentage, SurveyStatus)
from ...permission_decorator import require_client_permission
from ...util import cognito, audit_logger
from ..deliverables.deliverables import download_one_deliverable
from ..commerce.utils import transform_programs
from ...validation.utils import is_uri_valid, validate_object_id

NPO_PERCENTAGE = 70

@dash_bp.route('/home', methods=['GET'])
@require_client_permission
def get_homepage_dispatch():
    brand_id = request.user['orgId']
    user_id = request.user['_id']
    result = get_homepage(brand_id, user_id)
    return jsonify(result)

@dash_bp.route('/home/user', methods=['GET'])
@require_client_permission
def get_homepage_user_dispatch():
    user_id = request.user['_id']
    result = get_homepage_user(user_id)
    return jsonify(result)

@dash_bp.route('/home/user', methods=['PATCH'])
@require_client_permission
def patch_homepage_user_dispatch():
    user_id = request.user['_id']
    result = patch_homepage_user(user_id)
    return jsonify(result)

@dash_bp.route('/assets', methods=['GET'])
@require_client_permission
def get_assets_dispatch():
    user_id = request.user['_id']
    brand_id = request.user['orgId']
    result = get_user_deals_assets(user_id, brand_id)
    return jsonify(result)

@dash_bp.route('/impact-summary', methods=['GET'])
@require_client_permission
def get_impact_summary_dispatch():
    user_id = request.user['_id']
    brand_id = request.user['orgId']
    result = get_user_impact_summary(user_id, brand_id)
    return jsonify(result)

@dash_bp.route('/download_deliverables', methods=['GET'])
@require_client_permission
def download():
    user_id = request.user['_id']
    filename = request.args.get('url')
    label = request.args.get('label')
    associated_id = filename.split('/')[-2]

    user = get_user(ObjectId(user_id), projection={'orgId': True})
    user_org_id = user.get('orgId')

    # validate user
    user_validated, program_name = validate_dashboard_user(user_org_id, filename, associated_id)

    if user_validated:
        return download_one_deliverable(filename, label, program_name)
    else:
        raise GivewithError('Insufficient permission', code=403)

@dash_bp.route('/proposal/<string:deal_id>/select-asset', methods=['POST'])
@require_client_permission
def select_asset_deal(deal_id):
    '''
    Save Asset selection choice onto deal
    '''
    data = request.get_json()
    asset_type = data.get('type', '').lower()
    asset_url = data.get('url')
    result = store_selected_asset_in_deal(deal_id, asset_type, asset_url)
    return result

@dash_bp.route('/insights', methods=['GET'])
@require_client_permission
def get_insights_dispatch():
    brand_id = request.user['orgId']
    result = get_insights(brand_id)
    return jsonify(result)

@dash_bp.route('/preferred-programs', methods=['GET'])
@require_client_permission
def get_preferred_programs_dispatch():
    brand_id = request.user['orgId']
    result = get_dashboard_preferred_programs(brand_id)
    return jsonify(result)

@public_bp.route('/buyer-landing-preferred-programs/<brand_id_or_slug>', methods=['GET'])
def get_preferred_programs_public_dispatch(brand_id_or_slug):
    result = get_dashboard_preferred_programs(brand_id_or_slug)
    return jsonify(result)

# NOTE: /proposal/<id> endpoints are for proposal summaries
@dash_bp.route('/proposal/<id>', methods=['GET'])
@require_client_permission
def get_proposal_dispatch(id):
    result = get_proposal_summary(id)
    return jsonify(result)

@dash_bp.route('/proposal/<id>', methods=['PATCH'])
@require_client_permission
def update_proposal_dispatch(id):
    result = update_proposal_summary(id)
    return jsonify(result)

@dash_bp.route('/proposal', methods=['POST'])
@require_client_permission
def create_proposal_dispatch():
    result = create_proposal(request.user)
    return jsonify(result)

@dash_bp.route('/proposal', methods=['PATCH'])
@require_client_permission
def patch_proposal_dispatch():
    brand_id = request.user['orgId']
    result = update_proposal(brand_id)
    return jsonify(result)

@dash_bp.route('/proposal/industries', methods=['GET'])
def get_proposal_industries_dispatch():
    return jsonify(get_proposal_industry_display_map())

@dash_bp.route('/confirmation', methods=['POST'])
@require_client_permission
def post_confirmation_dispatch():
    return confirm_proposal(request.user)


@dash_bp.route('/summary_doc', methods=['GET'])
@require_client_permission
def download_summary_doc():
    # download summary template from s3
    file = TemporaryFile()
    download_file('globals/Sourcing_Written_Summary.docx', file)
    response = send_file(file, as_attachment=True, attachment_filename='Sourcing_Written_Summary.docx', cache_timeout=0)
    return response


@dash_bp.route('/programs', methods=['GET'])
@require_client_permission
def get_list_programs():
    return jsonify(list_programs())


def get_homepage(brand_id, user_id):
    homepage = []
    for proposal in get_associated_proposals(user_id):
        selected_program = get_program(proposal.get('selectedProgram'), projection={'_id' : True})

        owner = None
        if proposal.get('givewithCustomerUser'):
            givewith_customer_user = ObjectId(proposal.get('givewithCustomerUser'))
            owner = get_user(givewith_customer_user)

        partner = get_mm_brand(proposal['client'])
        homepage.append({
            '_id': str(proposal.get('_id', '')),
            'slug': proposal.get('slug', ''),
            'programId': selected_program.get('_id', '') if selected_program else '',
            'name': proposal.get('name', ''),
            'description': proposal.get('description', ''),
            'currency': proposal.get('currency', str(Currency.USD)),
            'type': proposal.get('type', 'enterprise'),  # Fallback type is hard coded for now
            'size': proposal.get('givewithPortion', ''),
            'fundingAmount': proposal.get('fundingAmount', 0),
            'owner': owner.get('name', '') if owner else '-',
            'status': proposal.get('status', ''),
            'partnerBrand': (partner.get('nameLabel') or partner.get('name', '')) if partner else '-',
            'createdAt': proposal.get('createdAt', '')
        })

    return homepage


def get_user_deals_assets(user_id: Union[ObjectId, str], brand_id: ObjectId) -> List[Dict]:
    """
    Returns assets of deals completed by user
    """
    a_year_in_the_past = datetime.utcnow() - timedelta(days=365)

    def _transform(doc: Dict) -> Dict:
        # Assets expire 365 days after being moved to COMPLETE
        # TimeLine : ------doc Updated---------a year in the past ----------------today
        expired = False
        if doc.get('statusUpdatedAt') and doc.get('statusUpdatedAt') < a_year_in_the_past:
            expired = True

        assets = {} if expired else doc.get('deliverables', {}).get('givewithCustomer', {})

        # these documents will only contain one document (see aggregation pipeline in get_user_completed_deals)
        selected_program = doc['selectedProgram'][0] if doc['selectedProgram'] else {}
        partner = doc['client'][0] if doc['client'] else {}
        funding_form = doc['fundingForm'][0] if doc['fundingForm'] else {}

        # map themes to topics an de-duplicate
        program_topics = list({translate_to_topic(_id) for _id in selected_program.get('themes', {}).get('data', [])})

        return {
            'program': {
                **selected_program,
                'topics': program_topics,
                'objects': funding_form.get('objects', [])
            },
            'deal': {
                '_id': doc.get('_id', ''),
                'client': partner.get('nameLabel') or partner.get('name', '-'),
                'createdAt': doc.get('createdAt', ''),
                'completedAt': doc.get('statusUpdatedAt', ''),
            },
            'assets': assets,
            'expired': expired,
            'altLicensing': doc.get('altLicensingGivewithCustomer', ''),
        }

    data = list(map(_transform, get_user_completed_deals(user_id)))
    customer_brand = get_document_by_id('mm_brands', brand_id, projection={'name': True, 'nameLabel': True})

    return {
        'givewithCustomer': customer_brand.get('nameLabel') or customer_brand.get('name', '-'),
        'data': data
    }


def get_user_completed_deals(user_id: Union[ObjectId, str]) -> 'pymongo.cursor.Cursor':
    aggregation_pipeline = [
        # the query we'd like to execute to pull specific documents
        {
            '$match': {
                'status': str(DealStatus.COMPLETE),
                'selectedProgram': {'$exists': True, '$ne': ''},
                'givewithCustomerUser': str(user_id)
            },
        },
        # lookup collection mm_brands for documents where client == _id and call the found documents client
        {
            '$lookup': {
                'from': 'mm_brands',
                'localField': 'client',
                'foreignField': '_id',
                'as': 'client'
            }
        },
        # lookup collection mm_programs for documents where selectedProgram == '_id' and call them selectedProgram
        # and for each program, lookup nonprofit name
        {
            '$lookup': {
                'from': 'mm_programs',
                'let': {'selectedProgram': '$selectedProgram'},
                'pipeline': [
                    {'$match': {'$expr': {'$eq': ['$$selectedProgram', '$_id']}}},
                    {
                        '$lookup': {
                            'from': 'mm_nonprofits', 'localField': 'nonprofit', 'foreignField': '_id', 'as': 'nonprofit'
                        }
                    },
                    {'$project': {'nonprofit': '$nonprofit.name', 'name': True, '_id': True, 'themes': True}},
                    {'$unwind': '$nonprofit'}
                ],
                'as': 'selectedProgram'
            }
        },
        # lookup collection funding_forms for latest funding_form with deal == _id
        {
            '$lookup': {
                'from': 'program_funding_forms',
                'let': {'deal_id': '$_id'},
                'pipeline': [
                    {'$match': {'$expr': {'$eq': ['$$deal_id', '$deal']}}},
                    {'$sort': {'lastUpdated': -1}},
                    {'$limit': 1}
                ],
                'as': 'fundingForm'
            }
        },
        # project - a basic projection of the fields we'd like to see returned to us
        {
            '$project': {
                'fundingForm': {'objects': True},
                'client': {'_id': True, 'name': True, 'nameLabel': True},
                'selectedProgram': {'_id': True, 'name': True, 'themes': True, 'nonprofit': True},
                'deliverables.givewithCustomer': True,
                'altLicensingGivewithCustomer': True,
                'statusUpdatedAt': True,
                'createdAt': True
            }
        },
        # sort descending order by field
        {'$sort': {'statusUpdatedAt': -1}}
    ]

    return db().coll_deals.aggregate(aggregation_pipeline)


def _get_brand_data(brand_id):
    projection = ['name', 'slug', 'splitGiveAmount', 'allowedProposalTypes', 'isPilot', 'givewithFeePercentage',
                  'givePercentageType', 'givePercentageCurrency', 'customGivePercentage', 'graduatedGivePercentages',
                  'paymentOption', 'proposalOptions', 'customCopy', 'selectedUserRoutes', 'featureFlags', 'dealConfig',
                  'allowMultipleSelectedPrograms', 'outreachMaterials', 'minimumFunding']
    brand = get_brand_by_id_or_slug(brand_id, projection=projection)

    return {
        'brandName': brand.get('name'),
        'brandSlug': brand.get('slug'),
        'allowedProposalTypes': brand.get('allowedProposalTypes', ['normal']),
        'splitGiveAmount': brand.get('splitGiveAmount', False),
        'givePercentageType': brand.get('givePercentageType'),
        'givePercentageCurrency': brand.get('givePercentageCurrency'),
        'customGivePercentage': brand.get('customGivePercentage'),
        'graduatedGivePercentages': brand.get('graduatedGivePercentages'),
        'givewithFeePercentage': brand.get('givewithFeePercentage'),
        'paymentOption': brand.get('paymentOption', 'payAsYouGo'),
        'proposalOptions': brand.get('proposalOptions', {}),
        'isPilot': brand.get('isPilot', False),
        'customCopy': brand.get('customCopy', {}),
        'selectedUserRoutes': brand.get('selectedUserRoutes'),
        'featureFlags': brand.get('featureFlags', {}),
        'dealConfig': brand.get('dealConfig', {}),
        'allowMultipleSelectedPrograms': brand.get('allowMultipleSelectedPrograms', False),
        'outreachMaterials': brand.get('outreachMaterials', []),
        'minimumFunding': brand.get('minimumFunding', 0)
    }


def get_homepage_user(user_id):
    user = db().coll_user.find_one({'_id': user_id})
    user.pop('cognito-id', None)

    if not user:
        raise EntityNotFound('user', id)

    user_full_name = user.get('name')
    # some legacy users do not have first name or last name so need to check in order
    # to render initials
    first_name = ''
    last_name = ''
    if 'first_name' in user and 'last_name' in user:
        first_name = user.get('first_name')
        last_name = user.get('last_name')
        if not user_full_name or ' ' not in user_full_name:
            user_full_name = user.get('first_name') + ' ' + user.get('last_name')
    elif 'firstname' in user and 'lastname' in user:
        first_name = user.get('firstname')
        last_name = user.get('lastname')
        if not user_full_name or ' ' not in user_full_name:
            user_full_name = user.get('firstname') + ' ' + user.get('lastname')
    else:
        if 'name' in user:
            split_user_name = user.get('name').split(' ', 1)
            first_name = split_user_name[0]
            last_name = split_user_name[1]

    # remove empty strings from split list
    user_full_name = [string for string in user_full_name.split(' ') if string != ""]
    user['name'] = ' '.join(user_full_name)

    user_split = user['name'].split(' ')
    if len(user_split) >= 2:
        user['initials'] = user_split[0][0] + user_split[-1][0]
    else:
        user['initials'] = user_split[0][0]

    # rename keys to JS format
    user['firstName'] = first_name
    user['lastName'] = last_name

    brand_id = user.get('orgId')
    user['orgData'] = _get_brand_data(brand_id)

    return user

def patch_homepage_user(user_id):
    document = request.get_json()

    current_user = get_user(user_id)

    if not document:
        raise UnsupportedPayload()

    # remove empty strings from split list
    name = document.get('firstName') + ' ' + document.get('lastName')
    user_full_name = ' '.join([string for string in name.split(' ') if string != ""])

    user_document = {
        'username': current_user['username'],
        'name': user_full_name,
        'first_name': document.get('firstName'),
        'last_name': document.get('lastName'),
        'title': document.get('title', ''),
        'departmentName': document.get('departmentName', ''),
        'departmentType': document.get('departmentType', ''),
        'phoneNumber': document.get('phoneNumber', ''),
        'businessAddress': document.get('businessAddress', '')
    }

    if validate_fields('user', 'patch', user_document):

        username = user_document['username']
        # update cognito info
        cognito.update_user(username, user_document['first_name'], user_document['last_name'], current_user['type'])

        db().coll_user.update_one({'_id': ObjectId(user_id)}, {'$set': user_document})

        # grab the new object from the db after updating
        user = get_user(user_id)

        send_loggly(
            'USER INFO: MODIFY USER BY PUT USER_ID: ' + str(user_id) + ' edited by ' + str(request.user['_id']) +
            ': diff: ' + str(diff(current_user, user, syntax='symmetric')))
        audit_logger.log('matchmaking-api', str(user_id), 'user', str(user_id), 'update', 'PATCH - dashboard', '')

        if ' ' in user['name']:
            initials = ''.join([x[0].upper() for x in user['name'].split(' ')])
        elif 'firstname' in user and 'lastname' in user:
            initials = user['firstname'][0] + user['lastname'][0]
        elif 'firstName' in user and 'lastName' in user:
            initials = user['firstName'][0] + user['lastName'][0]

        user['initials'] = initials
        # rename keys to JS format
        user['firstName'] = user.pop('first_name')
        user['lastName'] = user.pop('last_name')

        brand_id = user.get('orgId')
        user['orgData'] = _get_brand_data(brand_id)

        return user

    else:
        return {'ERROR': 'Missing or invalid fields'}

def get_proposal_summary(_id):
    org_id = request.user['orgId']
    fields = {'id': _id}

    if validate_fields('proposal', 'get', fields):
        # Using the admin endpoint is ok as it will be filtered later
        proposal = admin_get_deal_by_id_handler(_id, include_recommendations=False).get_json()

        if not proposal or str(org_id) != proposal.get('givewithCustomer'):
            raise EntityNotFound('proposal', _id)

        client = get_mm_brand(ObjectId(proposal['client']))
        proposal['clientIsVerified'] = is_brand_verified_by_admin(client)

        if proposal.get('givewithCustomerUser'):
            givewith_customer_user = ObjectId(proposal.get('givewithCustomerUser'))
            proposal['owner'] = get_user(givewith_customer_user)['name']

        if proposal.get('manager'):
            givewith_manager = ObjectId(proposal.get('manager'))
            proposal['manager'] = get_user(givewith_manager, projection={'name': True, 'username': True})

        selected_program = proposal.get('selectedProgram')

        if selected_program:
            program = get_deal_program(proposal, get_program_by_id(selected_program), 'givewithCustomer', False)
            if program:
                proposal['selectedProgram'] = program
            else:
                raise EntityNotFound('Program', selected_program)

        gw_customer = get_mm_brand(ObjectId(proposal['givewithCustomer']), projection={'givePercentageType': True, 'customGivePercentage': True})
        if gw_customer.get('givePercentageType') == 'default':
            proposal['customerGivewithPercent'] = 2
        elif gw_customer.get('givePercentageType') == 'custom':
            proposal['customerGivewithPercent'] = gw_customer.get('customGivePercentage')

        return filter_proposal_summary(proposal)

    else:
        return {'ERROR': 'Missing or invalid fields'}


def create_proposal(user):
    fields = request.get_json()
    if not fields:
        return {'ERROR': 'Could not complete request'}

    is_covid = fields.get('type', '').lower() == 'covid'

    user_id = user.get('_id')
    user_brand_id = user.get('orgId')
    user_department = user.get('departmentType', 'Other')

    givewith_customer_role = str(RolesByDepartment[user_department])

    if 'newBrand' in fields:
        fields['clientCompany'] = create_incomplete_brand(
            fields.pop('newBrand'),
            fields.pop('newBrandIndustry', None) # industry can be optional
        )

        audit_logger.log('matchmaking-api', str(user_id), 'brand', fields['clientCompany'], 'create', 'incomplete', '')

    deal_status = str(DealStatus.PAYMENT_PENDING if is_covid else DealStatus.PROGRAM_SELECTION_PENDING)

    sap_association = fields.get('sapAssociation')

    program = fields.get('selectedProgram')
    program_selection = ObjectId(program) if program else None

    if sap_association and user_department == UserDepartments.PROCUREMENT.value and program_selection:
        deal_status = str(DealStatus.CONFIRMATION_PENDING)

    validation = validate_fields('proposal', 'post', fields)

    if user_id and user_brand_id and validation:
        reference = get_next_reference_value('deals')

        client = ObjectId(fields['clientCompany'])

        gw_customer = user_brand_id
        user_brand = get_mm_brand(user_brand_id,
                                  projection={'givePercentageType': 1,
                                              'customGivePercentage': 1,
                                              'graduatedGivePercentages': 1,
                                              'givewithManager': 1,
                                              'splitGiveAmount': 1,
                                              'name': 1,
                                              'paymentOption': 1})

        if len(fields.get('proposalName', '')) == 0:
            client_brand = get_document_by_id('mm_brands', str(client))
            fields['proposalName'] = user_brand.get('name') + ' w/ ' + client_brand.get('name')

        if is_covid:
            fields = normalize_fields('proposal', 'post', fields)

            if fields.get('giveOption') == 'percentage':
                total_budget = fields['totalBudget']
                givewith_portion = total_funding = round(total_budget * (fields['givePercent'] / 100))
            else:
                total_budget = 0
                givewith_portion = total_funding = fields['giveAmount']

        else:
            total_budget = to_number_without_commas(fields['totalBudget'])
            give_percentage = get_give_percentage(user_brand['givePercentageType'],
                                                  user_brand.get('customGivePercentage'),
                                                  total_budget,
                                                  user_brand.get('graduatedGivePercentages'))

            givewith_portion = round(total_budget * (give_percentage/100), 2)
            total_funding = round(givewith_portion * (NPO_PERCENTAGE/100), 2)

        manager = user_brand.get('givewithManager', None)

        if 'password' not in fields:
            password = generate_secure_password()

        email_fields = [user.get('username')]

        client_email_fields = []
        if is_covid:
            client_email_fields.append(fields['clientEmail'])

        if 'paymentOption' not in fields:
            fields['paymentOption'] = user_brand.get('paymentOption')

        proposal = filter_none_values({
            'name': fields.get('proposalName'),
            'givewithCustomer': gw_customer,
            'client': client,
            'type': fields.get('type', 'enterprise'),
            'sapAssociation': sap_association,
            'aribaRfpId': fields.get('aribaRfpId'),
            'paymentOption': fields.get('paymentOption'),
            'totalBudget': total_budget,
            'fundingAmount': total_funding,
            'givewithPortion': givewith_portion,
            'giveOption': fields.get('giveOption'),
            'splitGiveAmount': user_brand.get('splitGiveAmount', False),
            'currency': fields.get('currency'),
            'givewithCustomerUser': str(user_id),
            'givewithCustomerEmails': email_fields,
            'clientEmails': client_email_fields,
            'createdAt': datetime.utcnow(),
            'lastUpdated': datetime.utcnow(),
            'createdBy': user_id,
            'reference': reference,
            'selectedProgram': program_selection,
            'slug': generate_random_slug(),
            'password': password,
            'status': deal_status,
            'givewithCustomerRole': givewith_customer_role,
            'isValid': True,
            'manager': manager,
            'deliverables': add_deliverables(),
            'statusUpdatedAt':datetime.utcnow()
        })

        # get recommendations for proposal if not selected recommended program
        if is_covid:
            proposal['selectedRecommendedPrograms'] = []
        else:
            try:
                selected_programs = select_programs(get_deal_recommended_programs(proposal))

                if selected_programs:
                    proposal['selectedRecommendedPrograms'] = selected_programs
            except Exception:
                # If exceptions occur while getting recommendations, simply ignore
                proposal_name = proposal.get('name', '')
                current_app.logger.warning(f'Unable to get recommendations for proposal with name: {proposal_name}')

        deal = create_deal(proposal)
        send_proposal_message(True, proposal)
        audit_logger.log('matchmaking-api', str(user_id), 'proposal', str(deal['id']), 'create', '', '')
        NotificationEmail(objective='new_deal', roles=['manager'], data=proposal).send()

        if is_covid and (user_brand.get('splitGiveAmount', False) or givewith_customer_role == 'buyer'):
            NotificationEmail(objective='covid_client_confirm', roles=['client'], data=proposal).send()

        return deal

    else:
        send_proposal_message(False, fields)
        return {'ERROR': 'Missing or invalid fields'}


def update_proposal(user_brand_id):
    fields = request.get_json()

    if fields and validate_fields('proposal', 'patch', fields):
        fields['_id'] = ObjectId(fields.pop('id'))

        if fields.get('givewithCustomer'):
            fields['givewithCustomer'] = ObjectId(fields.pop('givewithCustomer'))

        if fields.get('client'):
            fields['client'] = ObjectId(fields.pop('client'))

        if fields.get('manager'):
            fields['manager'] = ObjectId(fields.pop('manager'))
            manager = get_manager(fields['manager'])
            fields['managerName'] = manager.get('name') if manager else ''

        status = fields.get('status')
        if status:
            db_document = db().coll_deals.find_one({'_id': fields['_id']})
            if db_document['status'] != fields.get('status'):
                audit_logger.log('matchmaking-api', str(request.user['_id']), 'proposal', str(fields['_id']), 'status', '', status)

        fields['lastUpdated'] = datetime.utcnow()

        updated_proposal = update_deal_from_users_brand_id(user_brand_id, fields['_id'], fields)

        if updated_proposal:
            audit_logger.log('matchmaking-api', str(request.user['_id']), 'proposal', str(fields['_id']), 'update', 'PATCH', '')

            return {'SUCCESS': updated_proposal}
        else:
            return {'ERROR': 'Could not find the specified proposal'}

    else:
        return {'ERROR': 'Missing or invalid fields'}


def update_proposal_summary(_id):
    """
    The proposal summary pages allow for editing the customer notes,
    so this is a small endpoint to allow that
    """
    _id = ObjectId(_id)
    fields = request.get_json()

    customer_notes = fields.get('customerNotes')
    ariba_rfp_id = fields.get('aribaRfpId')
    archived = fields.get('archived')
    lost = fields.get('lost')
    name = fields.get('name')
    total_budget = fields.get('totalBudget')
    selected_program = fields.get('selectedProgram')

    proposal = get_deal(_id)
    if not proposal:
        raise EntityNotFound('proposal', _id)

    # will log if the proposal has already been marked as lost since DEAL_LOST < PAYMENT_PENDING - that's fine :)
    if lost and DealStatus.get(proposal.get('status')) < DealStatus.PAYMENT_PENDING:
        audit_logger.log('matchmaking-api', str(request.user['_id']), 'proposal', str(_id), 'lost', '', '')

    if archived and archived != proposal.get('archived', ''):
        audit_logger.log('matchmaking-api', str(request.user['_id']), 'proposal', str(_id), 'archived', '', '')

    updated_proposal = filter_none_values({
        '_id': _id,
        'customerNotes': customer_notes,
        'aribaRfpId': ariba_rfp_id,
        'archived': archived,
        'name': name,
        'lastUpdated': datetime.utcnow(),
        'currency': fields.get('currency')
    })

    if lost and DealStatus.get(proposal.get('status')) < DealStatus.PAYMENT_PENDING:
        updated_proposal['status'] = str(DealStatus.DEAL_LOST)

    if 'totalBudget' in fields and DealStatus.get(proposal.get('status')) < DealStatus.PAYMENT_PENDING:
        user_brand_id = request.user.get('orgId')
        user_brand = get_mm_brand(user_brand_id)

        total_budget = to_number_without_commas(total_budget)
        give_percentage = get_give_percentage(user_brand['givePercentageType'],
                                              user_brand.get('customGivePercentage'),
                                              total_budget,
                                              user_brand.get('graduatedGivePercentages'))

        givewith_portion = round(total_budget * (give_percentage / 100), 2)
        total_funding = round(givewith_portion * (NPO_PERCENTAGE / 100), 2)

        updated_proposal['totalBudget'] = total_budget
        updated_proposal['fundingAmount'] = total_funding
        updated_proposal['givewithPortion'] = givewith_portion

    if selected_program and DealStatus.get(proposal.get('status')) == DealStatus.PROGRAM_SELECTION_PENDING:
        get_program_by_id(selected_program)
        updated_proposal['selectedProgram'] = ObjectId(selected_program)
        updated_proposal['status'] = str(DealStatus.CONFIRMATION_PENDING)

    result = update_deal(updated_proposal)
    audit_logger.log('matchmaking-api', str(request.user['_id']), 'proposal', str(_id), 'update', 'PATCH', '')

    return result


def confirm_proposal(user):
    fields = request.get_json()

    if not fields or not fields.get('deal-id'):
        raise UnsupportedPayload(None)

    deal_id = fields.get('deal-id')

    try:
        obj_id = ObjectId(deal_id)
    except InvalidId:
        raise UnsupportedId(deal_id)

    document = get_deal(obj_id)
    if not document:
        raise EntityNotFound('proposal', deal_id)

    # status has to be confirmation pending to confirm it
    if DealStatus.get(document.get('status')) != DealStatus.CONFIRMATION_PENDING:
        raise GivewithError('Cannot confirm a proposal in {}'.format(document.get('status')), code=400)

    try:
        copy_deliverables_and_licensing(obj_id, document)
    except Exception as exz:
        print(exz, file=sys.stderr)

    if 'supplierEmail' in fields:
        document.setdefault('expectedClientToConfirm', {}).update({'email': fields.get('supplierEmail')})

    document['status'] = str(DealStatus.PAYMENT_PENDING)
    document['statusUpdatedAt'] = datetime.utcnow()

    if 'totalBudget' in fields:
        user_brand_id = request.user.get('orgId')
        user_brand = get_mm_brand(user_brand_id)

        total_budget = to_number_without_commas(fields.get('totalBudget'))
        give_percentage = get_give_percentage(user_brand['givePercentageType'],
                                              user_brand.get('customGivePercentage'),
                                              total_budget,
                                              user_brand.get('graduatedGivePercentages'))

        givewith_portion = round(total_budget * (give_percentage / 100), 2)
        total_funding = round(givewith_portion * (NPO_PERCENTAGE / 100), 2)

        document['totalBudget'] = total_budget
        document['fundingAmount'] = total_funding
        document['givewithPortion'] = givewith_portion

    if 'currency' in fields:
        document['currency'] = fields.get('currency')

    if 'aribaRfpId' in fields:
        document['aribaRfpId'] = fields.get('aribaRfpId')

    document.setdefault('confirmation', {}).update({'confirmedAt': datetime.utcnow(),
                                                    'confirmedBy': user.get('_id')})

    if update_deal(set_last_updated(document)):
        email = NotificationEmail(objective='partially_confirmed', roles=['manager'], data=document)
        email.send()

        supplier_email = fields.get('supplierEmail')
        email = NotificationEmail(objective='confirm_transaction', roles=[], data=document, cc=[supplier_email])
        email.send()

        audit_logger.log('matchmaking-api', str(request.user['_id']), 'proposal', str(deal_id), 'confirmed', '', '')

        return jsonify(get_deal(obj_id))
    else:
        raise GivewithError('Error updating proposal record', code=500)


def get_dashboard_preferred_programs(brand_id_or_slug):
    brand = get_brand_by_id_or_slug(brand_id_or_slug, projection={'preferredPrograms': True})

    selected_programs = brand.get('preferredPrograms', {}).get('selected', [])
    programs_list = []

    if selected_programs:
        projection = {
            'name': True, 'slug': True, 'themes': True, 'isValid': True, 'imagePortrait': True,
            'imageLandscape': True, 'nonprofit': True, 'active': True, 'isValidNonprofit': True
        }
        programs_list = get_documents('mm_programs', {'_id': {'$in': selected_programs}}, projection=projection)

        for program in programs_list:
            program['isValid'] = all([
                program.pop('isValid', False),
                program.pop('isValidNonprofit', False),
                program.pop('active', False)
            ])
            program['nonprofitName'] = get_nonprofit_by_id(program.pop('nonprofit', None)).get('name')
            program['topics'] = list({translate_to_topic(_id) for _id in program.pop('themes', {}).get('data', [])})

        return {
            'selected': programs_list,
            'editing': brand['preferredPrograms'].get('editing'),
            'buyerLandingPage': brand.get('customCopy', {}).get('buyerLandingPage', ''),
        }
    else:
        return {
            'selected': [],
            'editing': False,
            'buyerLandingPage': '',
        }


def get_proposal_industry_display_map():
    """
    Gets industry
    """
    return get_industry_display_map()


def list_programs():
    projection = {
        'name': True, 'slug': True, 'nonprofit': True, 'imagePortrait': True,
        'imageLandscape': True, 'themes.data': True, 'csrhub.data': True,
        'sasb.data': True, 'sdg.data': True, 'gri.data': True, 'esg.data': True, 'isValid': True
    }
    programs = get_documents('mm_programs', {'isValid': True, 'isValidNonprofit': True, 'active': True},
                             projection=projection)

    npf_name_map = {}
    nonprofits = db().coll_nonprofits.find({}, projection={'_id':1, 'name':1})

    for npf in nonprofits:
        _id = str(npf['_id'])
        npf_name_map[_id] = npf['name']

    for program in programs:
        program['nonprofitName'] = npf_name_map.get(str(program['nonprofit']), '')

        program['topics'] = list({translate_to_topic(_id) for _id in program.pop('themes', {}).get('data', [])})
        if len(program['topics']) > 0 and program['topics'][0] == None:
            program['topics'] = []

        sdg = []
        for _id in program.get('sdg', {}).get('data', []):
            vocab = get_vocabulary_v2(_id)
            sdg.append({'code': vocab.get('code'), 'label': vocab.get('label'), '_id': _id})
        program['sdg'] = sdg

    programs = sorted(programs, key=lambda k: k['nonprofitName'])

    return {'programs': programs}


def validate_fields(obj_type, request_method, document, dash_models=DASHBOARD_MODELS, allow_unknown=False):
    schema = dash_models.get(obj_type.lower(), {}).get(request_method.lower(), {})
    if document:
        v = GivewithValidator()
        v.allow_unknown = allow_unknown
        if v.validate(document, schema):
            return True
        else:
            raise ValidationError(v.errors)

    else:
        return False

def normalize_fields(obj_type, request_method, document, dash_models=DASHBOARD_MODELS):
    schema = dash_models.get(obj_type.lower(), {}).get(request_method.lower(), {})
    if document:
        v = GivewithValidator()
        normalized_document = v.normalized(document, schema)
        if v.errors:
            raise ValidationError(v.errors)

        return normalized_document
    else:
        return document

def validate_dashboard_user(user_org_id, filename, associated_id):
    '''
        Check if user is associated with either client or customer of the deal
        param `filename` can either come from a funding form ( deliverables/<deal id>/item )
        or it can come from a program ( program/<program id>/item )
        @params:
        `user` --> user dict
        `filename` --> filename
        `associated_id` --> did the file originate from a funding form or a program?
    '''
    top_level = filename.split('/')[0]

    if 'deliverables' == top_level:
        deal = get_deal(ObjectId(associated_id), projection={'givewithCustomer': True, 'client': True, 'selectedProgram': True})
        program = get_program(deal.get('selectedProgram'), projection={'name' : True})

        if user_org_id in [deal.get('givewithCustomer'), deal.get('client')]:
            return (True, program.get('name'))

    elif 'programs' == top_level:
        deals = db().coll_deals.find({'selectedProgram': ObjectId(associated_id)}, projection={'givewithCustomer': True, 'client': True})
        program = get_program(ObjectId(associated_id), projection={'name': True})

        for deal in deals:
            if user_org_id in [deal.get('givewithCustomer'), deal.get('client')]:
                return (True, program.get('name'))

    return (False, '')


def get_user_impact_summary(user_id: Union[ObjectId, str], brand_id: ObjectId) -> Dict[str, Any]:
    summary = get_aggregated_impact_summary(user_id)
    
    # Convert currencies to user's brand's givePercentageCurrency
    user_currency = get_document_by_id('mm_brands', brand_id, projection={
        'givePercentageCurrency': True, '_id': False
    }).get('givePercentageCurrency', str(Currency.USD))
    currency_rates = get_forex_rates()

    total_transaction = total_funding = 0
    topics = sdgs = []

    if (summary.get('dealsCompleted') > 0):
        for deal in summary.pop('deals', []):
            deal_currency = deal.get('currency', str(Currency.USD))

            total_transaction += convert_currency(
                amount=deal.get('totalBudget', 0),
                _from=deal_currency,
                _to=user_currency,
                rates=currency_rates
            )

            total_funding += convert_currency(
                amount=deal.get('fundingAmount', 0),
                _from=deal_currency,
                _to=user_currency,
                rates=currency_rates
            )

        topics = sorted({translate_to_topic(_id) for _id in summary.pop('themesSupported', [])})
        sdgs = [get_vocabulary_v2(_id).get('code') for _id in summary.pop('sdgsSupported', [])]

    return {
        **summary,
        'currency': user_currency,
        'lifeTimeTransactionAmount': total_transaction,
        'lifeTimeFunding': total_funding,
        'topicsSupported': topics,
        'sdgsSupported': sdgs,
    }


def get_aggregated_impact_summary(user_id: Union[ObjectId, str]) -> Dict:
    aggregation_pipeline = [
        {
            '$facet': {
                'data': [
                    {
                        '$match': {
                            'status': str(DealStatus.COMPLETE),
                            'selectedProgram': {'$exists': True, '$ne': ''},
                            'givewithCustomerUser': str(user_id),
                        },
                    },
                    {
                        '$lookup': {
                            'from': 'mm_programs',
                            'localField': 'selectedProgram',
                            'foreignField': '_id',
                            'as': 'selectedProgram'
                        }
                    },
                    {
                        '$unwind': {'path': '$selectedProgram'}
                    },
                    {
                        '$group': {
                            '_id': None,
                            'dealsCompleted': {'$sum': 1},
                            'deals': {
                                '$push': {'currency': '$currency', 'totalBudget': '$totalBudget', 'fundingAmount': '$fundingAmount'}
                            },
                            'uniquePartners': {'$addToSet': '$client'},
                            'sdgs': {'$push': '$selectedProgram.sdg.data'}, # produces a list of lists
                            'themes': {'$push': '$selectedProgram.themes.data'} # produces a list of lists
                        }
                    },
                    # project to get the count of unique Partners, reduce sdgs and reduce themes to a single list
                    {
                        '$project': {
                            '_id': False,
                            'dealsCompleted': True,
                            'deals': True,
                            'uniquePartners': {'$size': '$uniquePartners'},
                            'sdgsSupported': {
                                '$reduce': {'input': '$sdgs', 'initialValue': [], 'in': {'$setUnion': ['$$value', '$$this']}}
                            },
                            'themesSupported': {
                                '$reduce': {'input': '$sdgs', 'initialValue': [], 'in': {'$setUnion': ['$$value', '$$this']}}
                            }
                        }
                    }
                ]
            }
        },
        {
            '$project': {
                '_id': False,
                'dealsCompleted': {
                    "$ifNull": [{ "$arrayElemAt": ["$data.dealsCompleted", 0] }, 0]
                },
                'deals': {
                    "$ifNull": [{ "$arrayElemAt": ["$data.deals", 0] }, []]
                },
                'uniquePartners': {
                    "$ifNull": [{ "$arrayElemAt": ["$data.uniquePartners", 0] }, 0]
                },
                'sdgsSupported': {
                    "$ifNull": [{ "$arrayElemAt": ["$data.sdgsSupported", 0] }, []]
                },
                'themesSupported': {
                    "$ifNull": [{ "$arrayElemAt": ["$data.themesSupported", 0] }, []]
                }
            }
        }
    ]

    # even though result will be a single document, mongo returns a cursor
    try:
        return list(db().coll_deals.aggregate(aggregation_pipeline))[0]
    except IndexError:
        return {}

def store_selected_asset_in_deal(deal_id, asset_type, asset_url):
    valid_asset_types = {'photo', 'video'}
    if asset_type not in valid_asset_types:
        raise GivewithError('Invalid type. Must be one of ' + ', '.join(valid_asset_types), code=400)

    if not (is_uri_valid(asset_url) and does_file_exist(asset_url)):
        raise GivewithError(f'File not found: {asset_url}', code=400)

    validate_object_id(deal_id, 'deals')

    deliverables = get_document_by_id('deals', deal_id, projection={
        'deliverables.givewithCustomer.deliverables': True
    }).get('deliverables', {}).get('givewithCustomer', {}).get('deliverables', [])

    user_id = request.user['_id']
    for asset_item in deliverables:
        photo_match = asset_item['name'] == 'Photos' and asset_type == 'photo'
        video_match = asset_item['name'] == 'ShortFormVideo' and asset_type == 'video'

        if photo_match or video_match:
            asset_item.setdefault('userSelections', {}).update({str(user_id): asset_url})
            break

    update_document_by_id('deals', deal_id, {
        'deliverables.givewithCustomer.deliverables': deliverables
    }, upsert=False)

    return '', 204
