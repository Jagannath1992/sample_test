from portal.shared import dates
from portal.shared.enums import ErrorLogSourceType
from portal.shared.errors import GivewithException
from portal.shared.repositories import error_log_repository


class ErrorLogService:

    def log_error(self, error: GivewithException, account: dict, order: dict = None, transaction: dict = None, by: str = None):
        if account and '_type' not in account:
            account = {
                '_id': account['_id'],
                '_type': 'account',
                'name': account['company']['name'],
            }

        if order and '_type' not in order:
            order = {
                '_id': order['_id'],
                '_type': 'order',
                'name': order['giveId'],
            }

        if transaction and '_type' not in transaction:
            transaction = {
                '_id': transaction['_id'],
                '_type': 'transaction',
                'name': transaction['memo'],
            }

        if not by:
            by = f"{error.source}@givewith.com"

        self.log(
            error.message,
            error.source,
            by,
            account,
            [{'code':err.code, 'message':err.message} for err in error.errors],
            order,
            transaction
        )

    def log(self, description: str, source: ErrorLogSourceType, created_by: str, account, messages=None, order=None, transaction=None):
        '''Adds a new error log entry'''
        error_log_entry = {
            'description': description, # internal
            'source': source,
            'messages': messages,       # 3rd party / web / internal
            'account': account,
            'order': order,
            'transaction': transaction,
            'isResolved': False,        
            'resolvedBy': None,
            'resolvedAt': None
        }

        error_log_repository().insert(error_log_entry, created_by)

        # TODO  should there be a flag to indicate a notification should go out ?
        # or an instance_setting with the notifcation info to use?
        # self.send_notification(error_message)

    def send_notification(self, error_message):
        # email_service().send_give_approved_email
        pass
