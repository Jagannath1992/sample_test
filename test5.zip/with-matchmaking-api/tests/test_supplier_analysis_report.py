import json
from datetime import datetime
from unittest import mock, TestCase

import pytest

from matchmaking.dao.supplier_analysis_report_dao import get_supplier_analysis_for_brand


def test_login_analysis_report_by_slug(client, admin_header, brand_id, default_header):
    new_report = {'brandId': str(brand_id)}

    response = client.post('admin/supplier-analysis-reports', data=json.dumps(new_report),
                           headers=admin_header)

    report = json.loads(response.data.decode())
    slug, password = report['slug'], report['password']

    response = client.post(f'/matchmaking/supplier-analysis-reports/{slug}/login',
                           data=json.dumps({'password': password}), headers=default_header)

    assert response.status_code == 200

    token = json.loads(response.data.decode()).get('token')
    assert token is not None
    assert len(token) > 15


def test_get_supplier_analysis_report_by_slug(client, admin_header, brand_id, default_header):
    new_report = {
        'brandId': str(brand_id), 'name': 'status report', 'category': 'Non IT', 'customerStatus': False,
        'suppliers': [str(brand_id)]
    }
    response = client.post('admin/supplier-analysis-reports', data=json.dumps(new_report), headers=admin_header)

    report = json.loads(response.data.decode())
    slug, password = report['slug'], report['password']
    response = client.post(f'/matchmaking/supplier-analysis-reports/{slug}/login',
                           data=json.dumps({'password': password}), headers=default_header)

    token = json.loads(response.data.decode())['token']
    response = client.get(f'/matchmaking/supplier-analysis-reports/{slug}', headers={
        **default_header,
        'Authorization': token,
    })

    assert response.status_code == 200

    client_report = json.loads(response.data.decode())
    assert client_report['name'] == new_report['name']
    assert client_report['category'] == new_report['category']

    assert client_report['topics']
    assert client_report['suppliers']
    for supplier in client_report['suppliers']:
        assert 'topics' in supplier
        assert 'matchProportion' in supplier
        assert 'inProgress' in supplier


def test_get_supplier_analysis_report_by_slug_without_token(client, admin_header, brand_id, default_header):
    new_report = {'brandId': str(brand_id)}
    response = client.post('admin/supplier-analysis-reports', data=json.dumps(new_report),
                           headers=admin_header)

    slug = json.loads(response.data.decode())['slug']
    response = client.get(f'/matchmaking/supplier-analysis-reports/{slug}', headers=default_header)

    assert response.status_code == 401


def test_get_supplier_analysis_report_by_slug_with_a_different_token(client, admin_header, brand_id, default_header):
    new_report = {'brandId': str(brand_id)}
    response_a = json.loads(client.post('admin/supplier-analysis-reports', data=json.dumps(new_report),
                                        headers=admin_header).data.decode())
    response_b = json.loads(client.post('admin/supplier-analysis-reports', data=json.dumps(new_report),
                                        headers=admin_header).data.decode())

    slug_a, password_a = response_a['slug'], response_a['password']
    slug_b = response_b['slug']

    token_a = json.loads(
        client.post(f'/matchmaking/supplier-analysis-reports/{slug_a}/login',
                    data=json.dumps({'password': password_a}), headers=default_header).data.decode()
    )['token']

    # get slug_b using token obtained from slug_a and password_a
    response = client.get(f'/matchmaking/supplier-analysis-reports/{slug_b}', headers={
        **default_header,
        'Authorization': token_a,
    })

    assert response.status_code == 401


def test_patch_supplier_analysis_report_by_slug(client, admin_header, brand_id, default_header):
    new_report = {'brandId': str(brand_id), 'notes': 'fancy a not sire?', 'customerStatus': True}

    report = json.loads(
        client.post('admin/supplier-analysis-reports', data=json.dumps(new_report), headers=admin_header).data.decode()
    )

    slug, password = report['slug'], report['password']

    token = json.loads(
        client.post(f'/matchmaking/supplier-analysis-reports/{slug}/login', data=json.dumps({'password': password}),
                    headers=default_header).data.decode()
    )['token']

    updates = {'name': 'Dell x IBM', 'category': 'NON IT', 'suppliers': [str(brand_id)]}
    response = client.patch(f'/matchmaking/supplier-analysis-reports/{slug}', data=json.dumps(updates), headers={
        **default_header,
        'Authorization': token,
    })

    assert response.status_code == 200

    updated_report = json.loads(response.data.decode())
    assert updated_report['name'] == updates['name']
    assert updated_report['category'] == updates['category']
    assert updated_report['suppliers'][0]['_id'] == updates['suppliers'][0]

    # ensure existing fields stay the same
    # NOTE: brandId and notes are admin only fields, they are not returned to client
    assert updated_report['customerStatus'] == new_report['customerStatus']


@pytest.mark.parametrize('updates', [
    {'slug': 'g33dbbsdfa'},
    {'brandId': '0b300afasdfeeaadfme32', 'category': 'IT'},
    {'password': '3ggmmas33455'},
    {'notes': 'fancy a note sire?', 'name': 'Kosher x Halal'},
    {'dummy': 'just a dummy unused field'},
    {'customerStatus': False}
])
def test_patch_supplier_analysis_report_by_slug_bad_fields(client, admin_header, brand_id, default_header, updates):
    new_report = {'brandId': str(brand_id), 'notes': 'fancy a not sire?'}

    report = json.loads(
        client.post('admin/supplier-analysis-reports', data=json.dumps(new_report), headers=admin_header).data.decode()
    )

    slug, password = report['slug'], report['password']

    token = json.loads(
        client.post(f'/matchmaking/supplier-analysis-reports/{slug}/login', data=json.dumps({'password': password}),
                    headers=default_header).data.decode()
    )['token']

    response = client.patch(f'/matchmaking/supplier-analysis-reports/{slug}', data=json.dumps(updates), headers={
        **default_header,
        'Authorization': token,
    })

    assert response.status_code == 400


def test_list_supplier_analysis_reports(client, admin_header):
    response = client.get('/admin/supplier-analysis-reports', headers=admin_header)
    assert response.status_code == 200


def test_create_supplier_analysis(client, admin_header, brand_id):
    new_analysis_report = {
        'brandId': str(brand_id),
        'customerStatus': True,
        'notes': 'some notes go here'
    }

    response = client.post('admin/supplier-analysis-reports', data=json.dumps(new_analysis_report),
                           headers=admin_header)
    assert response.status_code == 200

    report_id = json.loads(response.data.decode()).get('_id')
    response = client.get(f'admin/supplier-analysis-reports/{ report_id }', headers=admin_header)
    assert response.status_code == 200

    analysis_report = json.loads(response.data.decode())
    for key in new_analysis_report:
        assert analysis_report[key] == new_analysis_report[key]


@pytest.mark.parametrize('data', [{'slug': 'fj33mdasdfff'}, {'password': '343222211244'}, {'brandId': None}])
def test_create_supplier_analysis_bad_fields(client, admin_header, brand_id, data):
    new_analysis_report = {
        'brandId': str(brand_id),
        **data
    }

    response = client.post('admin/supplier-analysis-reports', data=json.dumps(new_analysis_report),
                           headers=admin_header)
    assert response.status_code == 400


def test_get_analysis_report_by_id(client, admin_header):
    reports = client.get('/admin/supplier-analysis-reports', headers=admin_header)
    report_id = json.loads(reports.data.decode())[0].get('_id')

    response = client.get(f'/admin/supplier-analysis-reports/{ report_id }', headers=admin_header)
    assert response.status_code == 200


def test_delete_analysis_report_by_id(client, admin_header, brand_id):
    new_analysis_report = {'brandId': str(brand_id)}
    report_id = json.loads(
        client.post('admin/supplier-analysis-reports', data=json.dumps(new_analysis_report),
                    headers=admin_header).data.decode()
    )['_id']

    response = client.delete(f'admin/supplier-analysis-reports/{report_id}', headers=admin_header)
    assert response.status_code == 204

    response = client.get(f'admin/supplier-analysis-reports/{report_id}', headers=admin_header)
    assert response.status_code == 404


@pytest.mark.parametrize('updates', [
    {'customerStatus': True, 'category': 'NON IT'},
    {'name': 'jackie goes home', 'notes': 'other notes'},
])
def test_patch_analysis_report_by_id(client, admin_header, brand_id, updates):
    report = {'brandId': str(brand_id), 'notes': 'my notes', 'customerStatus': False}

    response = client.post('admin/supplier-analysis-reports', data=json.dumps(report),
                           headers=admin_header)
    report_id = json.loads(response.data.decode()).get('_id')

    response = client.patch(f'/admin/supplier-analysis-reports/{ report_id }', data=json.dumps(updates),
                            headers=admin_header)

    assert response.status_code == 200

    updated_report = json.loads(response.data.decode())
    for key, value in {**report, **updates}.items():
        assert updated_report[key] == value


@pytest.mark.parametrize('updates', [
    {'slug': 'g33dbbsdfa'},
    {'brandId': '0b300afasdfeeaadfme32'},
    {'password': '3ggmmas33455', 'name': 'Drake x Chopper'},
    {'dummy': 'just a dummy unused field'},
])
def test_patch_analysis_report_by_id_with_bad_fields(client, admin_header, updates, brand_id):
    report = {'brandId': str(brand_id), 'notes': 'my notes', 'customerStatus': False}
    response = client.post('admin/supplier-analysis-reports', data=json.dumps(report),
                           headers=admin_header)
    report_id = json.loads(response.data.decode()).get('_id')

    response = client.patch(f'/admin/supplier-analysis-reports/{ report_id }', data=json.dumps(updates),
                            headers=admin_header)

    assert response.status_code == 400


def test_get_supplier_analysis_report_industries(client, admin_header, brand_id, default_header):
    new_report = {'brandId': str(brand_id), 'name': 'status report', 'category': 'Non IT', 'customerStatus': False}
    response = client.post('admin/supplier-analysis-reports', data=json.dumps(new_report),
                           headers=admin_header)

    report = json.loads(response.data.decode())
    slug, password = report['slug'], report['password']
    response = client.post(f'/matchmaking/supplier-analysis-reports/{slug}/login',
                           data=json.dumps({'password': password}), headers=default_header)

    token = json.loads(response.data.decode())['token']
    response = client.get(f'/matchmaking/supplier-analysis-reports/industries', headers={
        **default_header,
        'Authorization': token,
    })

    assert response.status_code == 200

    data = json.loads(response.data.decode())
    assert isinstance(data, dict)
    assert data


@pytest.mark.parametrize('auth_headers', [
    {},
    {'Authorization': 'bad_token'}
])
def test_get_supplier_analysis_report_industires_bad_auth(client, auth_headers, default_header):
    response = client.get(f'/matchmaking/supplier-analysis-reports/industries', headers={
        **default_header, **auth_headers
    })

    assert 400 <= response.status_code <= 499


def test_get_analysis(monkeypatch):
    mock_brand = {
        '_id': 'metropolitan',
        'topics': [
            {'label' : 'Diversity', 'score' : 38.095238095238, 'topic' : 'Diversity'},
            {'label' : 'Economic empowerment', 'score' : 23.8095238095238, 'topic' : 'Economic empowerment'},
            {'label' : 'Responsible business', 'score' : 21.4285714285714, 'topic' : 'Responsible business'},
            {'label' : 'Environment', 'score' : 9.52380952380952, 'topic' : 'Environment'},
            {'label' : 'Women and girls', 'score' : 7.14285714285714, 'topic' : 'Women and girls'},
            {'label' : 'Education', 'score' : 0, 'topic' : 'Education'},
            {'label' : 'Housing and homelessness', 'score' : 0, 'topic' : 'Housing and homelessness'},
            {'label' : 'Youth development', 'score' : 0, 'topic' : 'Youth development'}
        ]
    }

    mock_suppliers = [
        {
            '_id': 'delos', 'source': 'CUSTOMER', 'verifiedByAdmin': datetime.now(),
            'topics': [
                {'label' : 'Diversity', 'score' : 1.224, 'topic' : 'Diversity'},
                {'label' : 'Economic empowerment', 'score' : 7.14285714285714, 'topic' : 'Economic empowerment'},
                {'label' : 'Responsible business', 'score' : 57.1428571428571, 'topic' : 'Responsible business'},
                {'label' : 'Environment', 'score' : 0, 'topic' : 'Environment'},
                {'label' : 'Women and girls', 'score' : 17.1428571428571, 'topic' : 'Women and girls'},
                {'label' : 'Housing and homelessness', 'score' : 0, 'topic' : 'Housing and homelessness'},
                {'label' : 'Education', 'score' : 0, 'topic' : 'Education'},
                {'label' : 'Immigrants and refugees', 'score' : 11.4285714285714, 'topic' : 'Immigrants and refugees'},
                {'label' : 'Animal welfare', 'score' : 3.57142857142857, 'topic' : 'Animal welfare'},
                {'label' : 'Health and wellness', 'score' : 3.57142857142857, 'topic' : 'Health and wellness'},
            ],
        },
        {
            '_id': 'ernst_young', 'source': 'CUSTOMER',
            'topics': [
                {'label' : 'Diversity', 'score' : 0.115, 'topic' : 'Diversity'},
                {'label' : 'Economic empowerment', 'score' : 0.234, 'topic' : 'Economic empowerment'},
                {'label' : 'Responsible business', 'score' : 64.2857142857142, 'topic' : 'Responsible business'},
                {'label' : 'Environment', 'score' : 14.2857142857142, 'topic' : 'Environment'},
                {'label' : 'Women and girls', 'score' : 0, 'topic' : 'Women and girls'},
                {'label' : 'Housing and homelessness', 'score' : 3.571428571428, 'topic' : 'Housing and homelessness'},
                {'label' : 'Education', 'score' : 0, 'topic' : 'Education'},
                {'label' : 'Food and hunger', 'score' : 3.57142857142857, 'topic' : 'Food and hunger'},
                {'label' : 'Poverty alleviation', 'score' : 7.14285714285714, 'topic' : 'Poverty alleviation'},
                {'label' : 'Indigenous peoples', 'score' : 7.14285714285714, 'topic' : 'Indigenous peoples'},
            ]
        },
        {
            '_id': 'instrument', 'source': 'MSCI',
            'topics': [
                {'label' : 'Diversity', 'score' : 0.2431, 'topic' : 'Diversity'},
                {'label' : 'Responsible business', 'score' : 53.5714285714285, 'topic' : 'Responsible business'},
                {'label' : 'Environment', 'score' : 8.16326530612245, 'topic' : 'Environment'},
                {'label' : 'Housing and homelessness', 'score' : 22.959183673469, 'topic' : 'Housing and homelessness'},
                {'label' : 'Human rights', 'score' : 15.3061224489795, 'topic' : 'Human rights'},
            ]
        }
    ]

    expected_results = {
        'delos': {
            'topics': {
                'Economic empowerment': 1,
                'Responsible business': 3,
                'Women and girls': 3,
                'Immigrants and refugees': 2
            },
            'matchProportion': 0.45
        },
        'ernst_young': {
            'topics': {
                'Responsible business': 3,
                'Environment': 2,
                'Poverty alleviation': 1,
                'Indigenous peoples': 1
            },
            'matchProportion': 0.36
        },
        'instrument': {
            'topics': {
                'Responsible business': 3,
                'Environment': 1,
                'Housing and homelessness': 3,
                'Human rights': 3,
            },
            'matchProportion': 0.36
        },
    }

    report = {'brandId': 'metropolitan', 'suppliers': ['delos', 'ernst_young']}

    # Mock get brand call
    mock_dao_utils = mock.MagicMock()
    mock_dao_utils.get_document_by_id.return_value = mock_brand
    monkeypatch.setattr('matchmaking.dao.supplier_analysis_report_dao.utils', mock_dao_utils)

    # Mock get suppliers call
    mock_db = mock.MagicMock()
    mock_db.return_value.coll_brands.aggregate.return_value = mock_suppliers
    monkeypatch.setattr('matchmaking.dao.supplier_analysis_report_dao.db', mock_db)

    # Mock get_vocabulary_label (since we're not working with ObjectIds)
    mock_return_input = mock.MagicMock(side_effect=lambda *args: args[0])
    monkeypatch.setattr('matchmaking.dao.supplier_analysis_report_dao.get_vocabulary_label_v2', mock_return_input)
    monkeypatch.setattr('matchmaking.dao.supplier_analysis_report_dao.ObjectId', mock_return_input)

    topic_labels, supplier_analysis = get_supplier_analysis_for_brand(report['brandId'], report['suppliers'])

    # verify topics
    expected_topics_in_order = [topic['topic'] for topic in mock_brand['topics']]
    assert topic_labels == expected_topics_in_order

    # verify suppliers
    assert len(supplier_analysis) == len(mock_suppliers)

    for _id, supplier in supplier_analysis.items():
        TestCase().assertDictEqual(supplier['topics'], expected_results[_id]['topics'])
        TestCase().assertAlmostEqual(supplier['matchProportion'], expected_results[_id]['matchProportion'])
