from app.utils.singular_converter import *


def test_force_singular():
    word = 'Beneficiaries'
    assert force_singular(word) == 'Beneficiary'

    word = 'Beneficiary'
    assert force_singular(word) == 'Beneficiary'


def test_convert_conditionally():
    sentence = 'Group events held'
    singular = form_singular_conditionally(sentence, 1)

    assert singular == 'Group event held'


def test_convert_program_outputs():
    outputs = [
        {
            "quantity": 0,
            "description": "Beneficiaries directly served",
            "scaleType": "5af4a134a64082a02a943c13"
        },
        {
            "description": "Mentors recruited",
            "quantity": 60,
            "scaleType": "5af4a134a64082a02a943c15"
        },
        {
            "description": "Mentors-mentees matched",
            "quantity": 45,
            "scaleType": "5af4a134a64082a02a943c15"
        },
        {
            "description": "Group events held",
            "quantity": 4,
            "scaleType": "5af4a134a64082a02a943c15"
        },
        {
            "description": "Hours logged",
            "quantity": 0,
            "scaleType": "5af4a134a64082a02a943c15"
        }
    ]

    form_program_output(outputs)
    assert outputs == [
        {
            "quantity": 0,
            "description": "Beneficiary directly served",
            "scaleType": "5af4a134a64082a02a943c13"
        },
        {
            "description": "Mentors recruited",
            "quantity": 60,
            "scaleType": "5af4a134a64082a02a943c15"
        },
        {
            "description": "Mentors-mentees matched",
            "quantity": 45,
            "scaleType": "5af4a134a64082a02a943c15"
        },
        {
            "description": "Group events held",
            "quantity": 4,
            "scaleType": "5af4a134a64082a02a943c15"
        },
        {
            "description": "Hour logged",
            "quantity": 0,
            "scaleType": "5af4a134a64082a02a943c15"
        }
    ]


