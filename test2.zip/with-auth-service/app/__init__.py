from flask import Flask
from flask_cors import CORS

from app.db.database import init_db
from app.rest import register_blueprints
from app.service import init_service
from app.loggly import init_logging, send_loggly
from app.utils.JSONEncoder import CustomJSONEncoder

from config import init_config


def create_app(test_db=None):
    app = Flask(__name__)
    app.url_map.strict_slashes = False

    # load config
    init_config(app)

    # init loggly
    init_logging(app)

    # register blueprints / error handler
    register_blueprints(app)

    # init db
    init_db(app, test_db)

    # init service
    init_service(app)

    app.register_error_handler(400, bad_request_handler)
    app.register_error_handler(500, internal_server_error_handler)

    app.json_encoder = CustomJSONEncoder

    CORS(app)

    return app


def bad_request_handler(e):
    send_loggly("bad request to auth")
    send_loggly(e)

    return 'Invalid JSON!', 400


def internal_server_error_handler(e):
    send_loggly("internal server error")
    send_loggly(e)

    return 'Internal Server Error!', 500
