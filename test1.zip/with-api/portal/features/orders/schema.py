from marshmallow import ValidationError, fields, validate, post_load, validates, validates_schema, Schema

from portal.features.instances.schema import ImpactSchema
from portal.shared.custom_fields import FormattedDateTimeField, ObjectIdField
from portal.shared.email.validator import EmailValidator
from portal.shared.enums import OrderStatus
from portal.shared.repositories import account_repository, sku_repository
from portal.shared.schema import OrderedSchema, EntitySchema, SearchRequestSchema, \
    SearchResponseSchema, AccountReferenceSchema, CauseAreaReferenceSchema


class OrderDetailSchema(OrderedSchema):
    skuId = fields.String(required=True)
    skuName = fields.String(required=True)
    qty = fields.Integer(required=True)
    unitCost = fields.Number(required=True)
    totalCost = fields.Number(required=True)

    @validates_schema
    def validate_totalCost(self, data, **kwargs):
        if data['qty'] * data['unitCost'] != data['totalCost']:
            raise ValidationError(f'Invalid Total for SKU {data["skuName"]}', 'totalCost')


class OrderComment(Schema):
    comment = fields.String(required=True)
    user = fields.String()
    timestamp = FormattedDateTimeField()
    oldStatus = fields.String(validate=validate.OneOf([s.value for s in OrderStatus]))
    newStatus = fields.String(validate=validate.OneOf([s.value for s in OrderStatus]))


class OrderImpact(ImpactSchema):
    totalValue = fields.Float(required=True)


class OrderCauseArea(CauseAreaReferenceSchema):
    impact = fields.Nested(OrderImpact, required=True)


class OrderSchema(EntitySchema):
    account = fields.Nested(AccountReferenceSchema, required=True)
    causeArea = fields.Nested(OrderCauseArea, required=True)
    status = fields.String(required=True, validate=validate.OneOf([s.value for s in OrderStatus]))
    comments = fields.List(fields.Nested(OrderComment), default=[])
    giveId = fields.Integer()
    customerId = fields.String()
    customerName = fields.String(required=True)
    quoteNumber = fields.String()
    quoteAmount = fields.Float()
    description = fields.String()
    detail = fields.List(fields.Nested(OrderDetailSchema))
    grandTotal = fields.Float(required=True)
    currency = fields.String()
    customField1 = fields.String()
    customField2 = fields.String()
    customField3 = fields.String()
    customField4 = fields.String()
    sharedWith = fields.Nested(AccountReferenceSchema)


class OrderRequest(OrderSchema):
    @validates_schema
    def validate_grandTotal(self, data, **kwargs):
        if 'detail' in data and sum(d['totalCost'] for d in data['detail']) != data['grandTotal']:
            raise ValidationError('Invalid Grand Total', 'grandTotal')

    @post_load
    def post_load(self, data, **kwargs):
        if data.get('account'):
            data = self._map_custom_fields(data)

        return data

    def _map_custom_fields(self, data):
        account = account_repository().get_single(data['account']['_id'])

        custom_field_mapping = {
            'customLabel1': 'customField1',
            'customLabel2': 'customField2',
            'customLabel3': 'customField3',
            'customLabel4': 'customField4'
        }
        for key, value in custom_field_mapping.items():
            if not account.get(key) and value in data:
                del data[value]
        return data

    class Meta:
        exclude = ('id', 'createdBy', 'createdAt', 'lastUpdatedBy', 'lastUpdated', 'giveId',)


class OrderResponse(OrderSchema):
    pass


class OrderSearchRequest(SearchRequestSchema):
    id = ObjectIdField(attribute='_id', allow_none=True)
    accountId = ObjectIdField(allow_none=True)
    accountName = fields.String(allow_none=True)
    status = fields.String(allow_none=True)
    causeArea = ObjectIdField(allow_none=True)
    giveId = fields.Integer(allow_none=True)
    customerId = fields.String(allow_none=True)
    customerName = fields.String(allow_none=True)
    quoteNumber = fields.String(allow_none=True)
    quoteAmountFrom = fields.Float(allow_none=True)
    quoteAmountTo = fields.Float(allow_none=True)
    grandTotalFrom = fields.Float(allow_none=True)
    grandTotalTo = fields.Float(allow_none=True)
    customField1 = fields.String(allow_none=True)
    customField2 = fields.String(allow_none=True)
    customField3 = fields.String(allow_none=True)
    customField4 = fields.String(allow_none=True)
    description = fields.String(allow_none=True)
    sharedWithId = ObjectIdField(allow_none=True)
    shared = fields.Integer(allow_none=True)
    createdBy = fields.String(allow_none=True)
    createdAtFrom = fields.DateTime(allow_none=True)
    createdAtTo = fields.DateTime(allow_none=True)
    lastUpdatedFrom = fields.DateTime(allow_none=True)
    lastUpdatedTo = fields.DateTime(allow_none=True)
    lastUpdatedBy = fields.String(allow_none=True)

    class Meta:
        contains_fields = [


            'accountName', 'customerName', 'createdBy', 'lastUpdatedBy', 'description',

            'customField1', 'customField2', 'customField3', 'customField4'
        ]
        range_fields = ['quoteAmount', 'grandTotal', 'createdAt', 'lastUpdated']
        starts_with_fields = ['quoteNumber', 'customerId', 'giveId']

    def _convert_nested(self, key):
        if key == 'accountId':
            return 'account._id'
        elif key == 'accountName':
            return 'account.name'
        elif key == 'sharedWithId':
            return 'sharedWith._id'
        elif key == 'causeArea':
            return 'causeArea._id'
        return key


class OrderSearchResponse(SearchResponseSchema):
    results = fields.List(fields.Nested(OrderSchema))


class OrderByIdResendNotificationRequest(Schema):
    emailAddresses = fields.List(fields.String(required=True), required=True)

    @validates('emailAddresses')
    def validate_emailAddresses(self, value):
        for email_address in value:
            if not EmailValidator().validate(email_address):
                raise ValidationError(f'Invalid email address "{email_address}" provided.')


class OrderTotalsRequest(Schema):
    accountId = ObjectIdField(allow_none=True, required=False)


class OrderTotalsByStatus(Schema):
    status = fields.String(attribute='_id')
    total = fields.Float()
    count = fields.Integer()


class OrderTotalsResponse(Schema):
    currentBalance = fields.Float()
    totalsByStatus = fields.List(fields.Nested(OrderTotalsByStatus))
    completedMTD = fields.Float()
    completedYTD = fields.Float()


class OrderLoginResponse(Schema):
    customerName = fields.String(required=True)
    quoteNumber = fields.String(required=True)
    quoteAmount = fields.Float(required=True)
    programName = fields.String(required=True)
    nonProfitName = fields.String(required=True)
