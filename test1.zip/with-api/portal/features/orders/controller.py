from bson import ObjectId
from flask import request, Response
from flask_accepts import accepts, responds
from flask_restx import Namespace, Resource
from typing import Dict, List
from werkzeug.exceptions import BadRequest, NotFound, Forbidden, InternalServerError

from portal.features.orders.schema import OrderByIdResendNotificationRequest, OrderRequest, OrderResponse, \
    OrderSearchRequest, OrderSearchResponse, OrderTotalsRequest, OrderTotalsResponse, OrderLoginResponse
from portal.features.orders.validators import StatusValidator
from portal.shared import dates
from portal.shared.auth.requests import token_required, role_required
from portal.shared.auth.security import has_role, get_validated_account_id
from portal.shared.enums import AccountType, OrderStatus, UserRole
from portal.shared.constants import GIVEWITH_ROLES
from portal.shared.errors import GivewithException
from portal.shared.repositories import cause_area_repository, instance_settings_repository, order_repository, \
    account_approval_repository, account_repository, locale_repository

from portal.shared.schema import AccountIdRequest, LoginRequest

from portal.shared.services import email_service, error_log_service, order_service, stripe_service

namespace = Namespace('orders', description='Give related operations')


def _validate_access(order_id: str):
    if (
        not has_role(GIVEWITH_ROLES, request.user)
        and not order_repository().has_access(order_id, request.user['accountId'])
    ):
        raise Forbidden('You do not have permission to access this resource')


def generate_password():
    import secrets
    import string

    alphabet = string.ascii_letters + string.digits
    while True:
        password = ''.join(secrets.choice(alphabet) for i in range(10))
        if (any(c.islower() for c in password)
                and any(c.isupper() for c in password)
                and sum(c.isdigit() for c in password) >= 3):
            break

    return password


@namespace.route('/approvals')
class OrderApproval(Resource):
    @role_required(GIVEWITH_ROLES + [UserRole.ORG_ADMIN, UserRole.APPROVER])
    @accepts(query_params_schema=OrderSearchRequest, api=namespace)
    @responds(schema=OrderSearchResponse, api=namespace)
    def get(self):
        '''Get all Gives requiring approval by the requesting User'''
        user = request.user
        params = request.parsed_query_params
        account_id = get_validated_account_id(params.get('account._id'), request)

        # check to see if any approval levels are defined for the account
        approvals = account_approval_repository().get_single(account_id)
        if approvals and len(approvals.get('levels', [])) > 0:
            # if approval levels are defined, but no level assigned to current user, return empty results
            approval = account_approval_repository().get_approval_level(user['username'], account_id)
            if approval is None:
                return {
                    'totalCount': 0,
                    'results': []
                }

            # otherwise, include filter for current user's assigned approval level amount
            params['grandTotal'] = {'$lte': approval['levels'][0]['amount']}

        # always include filters for account id and pending approval status
        params['account._id'] = account_id
        params['status'] = OrderStatus.PENDING_APPROVAL.value

        total_count, orders = order_repository().get_page(params)
        return {
            'totalCount': total_count,
            'results': orders
        }


@namespace.route('')
@namespace.doc(responses={400: 'Bad Request'})
class OrderResource(Resource):
    @token_required
    @accepts(query_params_schema=OrderSearchRequest, api=namespace)
    @responds(schema=OrderSearchResponse, api=namespace)
    def get(self):
        """Search Gives"""
        params = request.parsed_query_params  # if accountId parameter not sent, check for sharedWithId, required for switch account
        params['account._id'] = get_validated_account_id(params.get('account._id', params.get('sharedWith._id')), request)
        is_procurement = False

        # check to see if a procurement org is trying to view shared gives from all suppliers
        if 'sharedWith._id' in params:
            account = account_repository().get_single(params.pop('account._id'))
            if account['type'] != AccountType.PROCUREMENT.value:
                raise BadRequest('Invalid account type')
            is_procurement = True

        # check to see if a supplier org is trying to view its shared gives
        if 'shared' in params:
            params['sharedWith'] = {'$exists': params.pop('shared') > 0}

        total_count, orders = order_repository().get_page(params)

        # do not return comments/history for shared gives
        if is_procurement:
            for order in orders:
                order.pop('comments', None)

        return {
            'totalCount': total_count,
            'results': orders
        }

    @role_required([UserRole.SUPER_ADMIN, UserRole.SALES])
    @accepts(schema=OrderRequest, api=namespace)
    @responds(schema=OrderResponse, api=namespace)
    def post(self):
        """Create Give"""
        order = request.parsed_obj
        order['account']['_id'] = get_validated_account_id(order['account']['_id'], request)

        validator = StatusValidator(None, order.get('status'), request.user)
        if not validator.is_valid():
            raise BadRequest('Invalid Give Status')

        order['comments'] = [{
            'comment': 'New Give',
            'newStatus': order.get('status'),
            'timestamp': dates.get_utcnow(),
            'user': request.user['username']
        }]

        # check account type and use procurment account giveId sequence for supplier gives
        account_id = order['account']['_id']
        account = account_repository().get_single(account_id)
        if account['type'] == AccountType.SUPPLIER.value:
            account_id = account['invitedBy']['_id']

        order['giveId'] = account_repository().get_next_give_id(account_id)

        order["password"] = generate_password()

        new_order = order_repository().insert(order, request.user['username'])
        order_service().send_notifications(new_order)
        return new_order


@namespace.route('/<string:id>')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Give not found'
    })
class OrderById(Resource):
    @token_required
    @accepts(query_params_schema=AccountIdRequest, api=namespace)
    @responds(schema=OrderResponse, api=namespace)
    def get(self, id: str):
        """Get Give by ID"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')

        params = request.parsed_query_params
        filters = {'_id': ObjectId(id)}
        is_procurement = False

        # check to see if a procurement org is trying to view shared gives from all suppliers
        if 'accountId' in params:
            if not has_role(GIVEWITH_ROLES, request.user):
                account_id = get_validated_account_id(params.get('accountId'), request)
                account = account_repository().get_single(account_id)

                if account['type'] == AccountType.PROCUREMENT.value:
                    filters['sharedWith._id'] = account['_id']
                    is_procurement = True
                else:
                    _validate_access(id)
        else:
            _validate_access(id)

        order = order_repository().get_single_by_filter(filters)

        if order is None:
            raise NotFound('Give not found')

        # do not return comments/history for shared gives
        if is_procurement:
            order.pop('comments', None)

        return order

    @token_required
    @accepts(schema=OrderRequest(partial=True), api=namespace)
    @responds(schema=OrderResponse, api=namespace)
    def put(self, id: str):
        """Update Give by ID"""
        self._validate_update(id)

        order = order_repository().get_single(id)
        update = request.parsed_obj
        is_status_changed = self._is_status_changed(update, id)
        if is_status_changed:
            if update.get('status') == OrderStatus.COMPLETED:
                update = self._handle_completed_order(id, update, request.user['username'])
            update = order_service().timestamp_comments(update, request.user['username'], id)

        order.update(update)
        order = order_repository().update(order, by=request.user['username'])
        if is_status_changed:
            order_service().send_notifications(order)
        return order

    @token_required
    @accepts(schema=OrderRequest(partial=True), api=namespace)
    @responds(schema=OrderResponse, api=namespace)
    def patch(self, id: str):
        """Update Give from Partial"""
        self._validate_update(id)

        update = request.parsed_obj
        is_status_changed = self._is_status_changed(update, id)
        if is_status_changed:
            if update.get('status') == OrderStatus.COMPLETED:
                update = self._handle_completed_order(id, update, request.user['username'])
            update = order_service().timestamp_comments(update, request.user['username'], id)

        order = order_repository().patch(id, update, by=request.user['username'])
        if is_status_changed:
            order_service().send_notifications(order)
        return order

    @role_required([UserRole.SUPER_ADMIN, UserRole.ORG_ADMIN, UserRole.SALES])
    @namespace.response(200, 'Give Deleted')
    def delete(self, id: ObjectId):
        """Delete Give by ID"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        if not order_repository().exists(id):
            raise NotFound('Give not found')
        order_repository().delete(id, by=request.user['username'])
        return Response('Give Deleted', 200)

    def _validate_update(self, order_id: str):
        if not ObjectId.is_valid(order_id):
            raise BadRequest('Invalid id provided')
        _validate_access(order_id)
        if not order_repository().exists(order_id):
            raise NotFound('Give not found')
        validator = StatusValidator(order_id, request.parsed_obj.get('status'), request.user)
        if not validator.is_authorized():
            raise Forbidden('Not authorized to update Give status')
        if not validator.is_valid():
            raise Forbidden('Invalid Give Status')

    def _is_status_changed(self, order: Dict, order_id: str):
        if 'status' not in order:
            return False
        existing = order_repository().get_single(order_id, {'status': 1})
        return existing.get('status') != order.get('status')

    def _handle_completed_order(self, order_id: str, order: Dict, username) -> Dict:
        existing_order = order_repository().get_single(order_id)
        account = account_repository().get_single(existing_order['account']['_id'])

        instance = instance_settings_repository().get_single(account['instance']['_id'])
        locale = locale_repository().get_single(instance['settings']['locale']['_id'])

        stripe = account.get('stripe', {})
        customer_id = stripe.get('customerId')
        if not customer_id:
            # TODO: Log error/send notification to givewith/finance/org_admin
            raise InternalServerError('Stripe is not set up for your account')

        automatic_payment_method_id = stripe.get('autopay', {}).get('paymentMethodId')
        if not automatic_payment_method_id:
            order['status'] = OrderStatus.FINANCIAL_HOLD.value
            return order

        amount = existing_order['grandTotal']
        currency = locale['settings']['currency']
        give_id = existing_order['giveId']

        try:
            stripe_service().create_payment_intent(instance, customer_id, automatic_payment_method_id, amount, order_id, currency, give_id)
            order['status'] = OrderStatus.PENDING_PAYMENT.value
        except GivewithException as ex:
            # Set status to financial hold to allow user to retry
            order['status'] = OrderStatus.FINANCIAL_HOLD.value
            error_log_service().log_error(ex, account, existing_order)

        return order


@namespace.route('/<string:id>/share')
@namespace.doc(
    responses={
        400: 'Bad Request',
        403: 'You do not have permission to access this resource',
        403: 'Give cannot be shared',
        404: 'Give not found',
        404: 'Supplier account not found',
        404: 'Procurement account not found',
    })
class ShareOrderById(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @responds(schema=OrderResponse, api=namespace)
    def post(self, id: ObjectId):
        """Share Give by ID"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)

        # get existing give
        order = order_repository().get_single(id)
        if not order:
            raise NotFound('Give not found')

        # only approved gives can be shared
        if order['status'] != OrderStatus.APPROVED.value:
            raise Forbidden('Give cannot be shared')

        # get supplier account for give
        supplier_filters = {
            '_id': order['account']['_id'],
            'type': AccountType.SUPPLIER.value,
        }
        supplier_account = account_repository().get_single_by_filter(supplier_filters)
        if not supplier_account:
            raise NotFound('Supplier account not found')

        # get procurement account for same instance as supplier account
        procurement_filters = {
            '_id': supplier_account['invitedBy']['_id'],
            'instance._id': supplier_account['instance']['_id'],
            'type': AccountType.PROCUREMENT.value,
        }
        procurement_account = account_repository().get_single_by_filter(procurement_filters)
        if not procurement_account:
            raise NotFound('Procurement account not found')

        # set order.sharedWith reference
        order_update = {
            'sharedWith': {
                '_id': procurement_account['_id'],
                '_type': 'account',
                'name': procurement_account['company']['name']
            }
        }
        order = order_repository().patch(id, order_update, request.user['username'])

        instance = instance_settings_repository().get_single(procurement_account['instance']['_id'])
        email_service().send_give_approved_shared_email(instance, order)

        return order

    @role_required([UserRole.SUPER_ADMIN, UserRole.FINANCE])
    @responds(schema=OrderResponse, api=namespace)
    def delete(self, id: ObjectId):
        """Unshare Give by ID"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)

        # get existing give
        order = order_repository().get_single(id)
        if not order:
            raise NotFound('Give not found')

        # only approved + shared gives can be unshared
        if order['status'] != OrderStatus.APPROVED.value or not order.get('sharedWith', None):
            raise Forbidden('Give cannot be unshared')

        # unset order.sharedWith reference
        del order['sharedWith']

        order = order_repository().update(order, request.user['username'])
        return order


@namespace.route('/<string:id>/resend-notification')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Give not found'
    })
class OrderByIdResendNotificationResource(Resource):
    @role_required([UserRole.SUPER_ADMIN, UserRole.ORG_ADMIN, UserRole.SALES, UserRole.FINANCE])
    @accepts(schema=OrderByIdResendNotificationRequest, api=namespace)
    @responds(api=namespace)
    def put(self, id):
        """Resend Give Notification"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')
        _validate_access(id)
        order = order_repository().get_single(id)
        if order is None:
            raise NotFound('Give not found')
        send_completed_notification(order, request.parsed_obj['emailAddresses'])


@namespace.route('/totals')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Account not found'
    })
class OrderTotalsResource(Resource):
    @role_required(GIVEWITH_ROLES + [UserRole.FINANCE, UserRole.EXECUTIVE])
    @accepts(query_params_schema=OrderTotalsRequest, api=namespace)
    @responds(schema=OrderTotalsResponse, api=namespace)
    def get(self):
        """Get Give Totals"""
        params = request.parsed_query_params
        accountId = get_validated_account_id(params.get('accountId'), request)
        account = account_repository().get_single(accountId)
        if not account:
            raise NotFound('Account not found')

        now = dates.get_utcnow()
        mtd = 0
        ytd = 0

        totals_by_status = order_repository().get_totals_by_status(accountId)
        totals_by_month = order_repository().get_totals_by_month(accountId, now.year)

        for item in totals_by_month:
            if item.get('_id') == now.month:
                mtd = item.get('total')
            ytd += item.get('total')

        return {
            'currentBalance': account.get('currentBalance'),
            'totalsByStatus': totals_by_status,
            'completedMTD': mtd,
            'completedYTD': ytd,
        }


def send_completed_notification(order, tos: List[str] = []):
    account = account_repository().get_single(order['account']['_id'],
                                              {'company.name': 1, 'sageCustomerId': 1, 'instance._id': 1})
    instance = instance_settings_repository().get_single(account['instance']['_id'])
    cause_area = cause_area_repository().get_single(order['causeArea']['_id'], {'tooltip': 1, 'detailImageName': 1})
    email_service().send_give_completed_won_email(instance, order, account, cause_area, tos)


@namespace.route('/<string:id>/login')
@namespace.doc(
    responses={
        400: 'Bad Request',
        404: 'Give not found'
    })
class LoginById(Resource):
    # @token_required
    @accepts(query_params_schema=LoginRequest, api=namespace)
    @responds(schema=OrderLoginResponse, api=namespace)
    def get(self, id: str):
        from portal.shared.utils import get_document_by_id
        """Get Give by ID"""
        if not ObjectId.is_valid(id):
            raise BadRequest('Invalid id provided')

        params = request.parsed_query_params
        password = params.get('password')
        filters = {'_id': ObjectId(id), 'password': password}
        order = order_repository().get_single_by_filter(filters)

        if order is None:
            raise NotFound('Give not found')

        program_id = order.get('selectedProgram')
        program, nonprofit = {}, {}
        if program_id is not None:
            program = get_document_by_id('mm_programs', program_id)
            nonprofit = get_document_by_id('mm_nonprofits', program.get('nonprofit'))

        return {
            'customerName': order.get('customerName'),
            'quoteNumber': order.get('quoteNumber'),
            'quoteAmount': order.get('quoteAmount'),
            'grandTotal': order.get('grandTotal', 0.0),
            'programName': program.get('name'),
            'nonProfitName': nonprofit.get('name')
        }
