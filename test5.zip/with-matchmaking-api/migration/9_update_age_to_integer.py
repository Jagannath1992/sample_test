from matchmaking import db

respondents = list(db().coll_nielsen_respondents.find())

for respondent in respondents:
    age_int = int(respondent["age"]) if respondent["age"] else 0
    respondent["age"] = age_int
    employment_status_int = int(respondent["employment_status"]) if respondent["employment_status"] else 0
    respondent["employment_status"] = employment_status_int
    household_income_int = int(respondent["household_income"]) if respondent["household_income"] else 0
    respondent["household_income"] = household_income_int
    household_size_index_int = int(respondent["household_size_index"]) if respondent["household_size_index"] else 0
    respondent["household_size_index"] = household_size_index_int
    age_presence_of_children_index_int = int(respondent["age_presence_of_children_index"]) if respondent["age_presence_of_children_index"] else 0
    respondent["age_presence_of_children_index"] = age_presence_of_children_index_int
    race_ethnicity_index_int = int(respondent["race_ethnicity_index"]) if respondent["race_ethnicity_index"] else 0
    respondent["race_ethnicity_index"] = race_ethnicity_index_int
    nielsen_county_size_index_int = int(respondent["nielsen_county_size_index"]) if respondent["nielsen_county_size_index"] else 0
    respondent["nielsen_county_size_index"] = nielsen_county_size_index_int
    census_division_index_int = int(respondent["census_division_index"]) if respondent["census_division_index"] else 0
    respondent["census_division_index"] = census_division_index_int
    spectra_lifestyle_index_int = int(respondent["spectra_lifestyle_index"]) if respondent["spectra_lifestyle_index"] else 0
    respondent["spectra_lifestyle_index"] = spectra_lifestyle_index_int
    spectra_behavior_stage_index_int = int(respondent["spectra_behavior_stage_index"]) if respondent["spectra_behavior_stage_index"] else 0
    respondent["spectra_behavior_stage_index"] = spectra_behavior_stage_index_int
    ageoffemale_head_index_int = int(respondent["ageoffemale_head_index"]) if respondent["ageoffemale_head_index"] else 0
    respondent["ageoffemale_head_index"] = ageoffemale_head_index_int
    employment_of_female_head_index_int = int(respondent["employment_of_female_head_index"]) if respondent["employment_of_female_head_index"] else 0
    respondent["employment_of_female_head_index"] = employment_of_female_head_index_int
    education_of_female_head_index_int = int(respondent["education_of_female_head_index"]) if respondent["education_of_female_head_index"] else 0
    respondent["education_of_female_head_index"] = education_of_female_head_index_int
    hispanic_index_int = int(respondent["hispanic_index"]) if respondent["hispanic_index"] else 0
    respondent["hispanic_index"] = hispanic_index_int
    occupation_of_household_head_index_int = int(respondent["occupation_of_household_head_index"]) if respondent["occupation_of_household_head_index"] else 0
    respondent["occupation_of_household_head_index"] = occupation_of_household_head_index_int
    db().coll_nielsen_respondents.replace_one(filter={'_id': respondent["_id"]}, replacement=respondent)